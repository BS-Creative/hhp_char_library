import bpy
from .shape_key_standard import prepare_source_shape_keys
from . import transfer_optimized_pending as optimized_pending
from copy import deepcopy
from .animation_transfer_support import (
    TransferError, TransferState, is_proportion_constraint, prepare_transfer_materials,
    is_hhp_mouth_shape_key,
    sync_proportion_distribution_ui,
    link_animation_preserving_drivers,
    is_proportion_owned, is_generated_rig_constraint,
    preserve_rig_drivers,
)
from bpy.types import Operator, PropertyGroup, UIList
from bpy.props import BoolProperty, StringProperty, EnumProperty, CollectionProperty, IntProperty
from .action_fcurve_compat import iter_fcurves_for_anim_data
from . import hhp_naming

# Kept in sync with the accepted naming standards so new ones show up in the report.
ARMATURE_NAME_HINT = " or ".join(f"'{name}'" for name in hhp_naming.CHAR_ARMATURE_NAMES)


def is_hhp_armature(obj):
    return hhp_naming.is_char_armature(obj)


def is_hhp_mesh(obj):
    return obj is not None and obj.type == 'MESH' and hhp_naming.is_char_mesh_object_name(obj.name)


def valid_armature_selection(context):
    if context is None:
        return False
    active = getattr(context, "active_object", None)
    if not is_hhp_armature(active):
        return False
    armatures = [obj for obj in getattr(context, "selected_objects", []) if obj.type == 'ARMATURE']
    if len(armatures) < 2:
        return False
    return all(is_hhp_armature(obj) for obj in armatures)


def valid_mesh_selection(context):
    if context is None:
        return False
    active = getattr(context, "active_object", None)
    if not is_hhp_mesh(active):
        return False
    meshes = [obj for obj in getattr(context, "selected_objects", []) if obj.type == 'MESH']
    if len(meshes) < 2:
        return False
    return all(is_hhp_mesh(obj) for obj in meshes)


def has_valid_hhp_selection(context):
    return valid_armature_selection(context) or valid_mesh_selection(context)

class HHP_SHAPEKEY_UL_clash_list(UIList):
    """UIList for displaying shape key clashes."""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # 'item' is a ShapeKeyClashItem from the collection.
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # Use split to create a 3-column layout with narrower middle column
            split = layout.split(factor=0.25, align=True)

            # --- Column 1: Source (property enum button to allow drag selection) ---
            col = split.column(align=True)
            col.prop_enum(item, "choice", 'SOURCE', text="", icon='TRIA_LEFT')

            # --- Column 2: Shape Key Name (Centered, narrower) ---
            split = split.split(factor=0.67, align=True)
            split.alignment = 'CENTER'
            split.label(text=item.name)

            # --- Column 3: Target (property enum button to allow drag selection) ---
            col = split.column(align=True)
            col.prop_enum(item, "choice", 'TARGET', text="", icon='TRIA_RIGHT')

class HHP_ShapeKeyClashItem(PropertyGroup):
    name: StringProperty(name="Shape Key Name")
    choice: EnumProperty(
        name="Choice",
        description="Choose whether to keep the source or target shape key data",
        items=[('SOURCE', 'Source', 'Keep source data', 'TRIA_LEFT', 0),
               ('TARGET', 'Target', 'Keep target data', 'TRIA_RIGHT', 1)],
        default='TARGET'
    )
    clash_type: StringProperty()

class HHP_OT_shapekey_clash_set_selected(Operator):
    bl_idname = "hhp.shapekey_clash_set_selected"
    bl_label = "Set Selected Shape Key Clashes"
    bl_description = "Set choice for all selected shape key clashes"
    bl_options = {'REGISTER'}
    
    choice: EnumProperty(
        name="Choice",
        items=[('SOURCE', 'Source', 'Set to Source'),
               ('TARGET', 'Target', 'Set to Target')],
        default='TARGET'
    )
    
    def execute(self, context):
        wm = context.window_manager
        
        # Apply choice to all selected items
        # Since UIList doesn't expose multi-selection easily, we'll apply to the active item
        # and provide separate "Set All" operations
        active_index = wm.hhp_shapekey_clash_active_index
        if 0 <= active_index < len(wm.hhp_shapekey_clashes):
            wm.hhp_shapekey_clashes[active_index].choice = self.choice
        
        return {'FINISHED'}

class HHP_OT_shapekey_clash_set_all(Operator):
    bl_idname = "hhp.shapekey_clash_set_all"
    bl_label = "Set All Shape Key Clashes"
    bl_description = "Set choice for all shape key clashes"
    bl_options = {'REGISTER'}
    
    choice: EnumProperty(
        name="Choice",
        items=[('SOURCE', 'Source', 'Set all to Source'),
               ('TARGET', 'Target', 'Set all to Target')],
        default='TARGET'
    )
    
    def execute(self, context):
        wm = context.window_manager
        
        # Apply choice to all items
        for item in wm.hhp_shapekey_clashes:
            item.choice = self.choice
        
        return {'FINISHED'}

class HHP_OT_shapekey_clash_resolver(Operator):
    bl_idname = "hhp.shapekey_clash_resolver"
    bl_label = "Shapekey Value Clash Analyzer"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        wm = context.window_manager
        return hasattr(wm, 'hhp_shapekey_clashes') and wm.hhp_shapekey_clashes

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        num_clashes = len(wm.hhp_shapekey_clashes)
        
        # Use a single column for left-justified text
        col = layout.column()
        col.label(text=f"Found {num_clashes} shape key clashes. Choose which version to keep.", icon='ERROR')
        col.label(text="For example, keep the source's mouth shape but use the target's feet.")
        col.label(text="Animated or driven keys are ignored as they are automatically updated.")
        col.label(text="Choosing 'Source' for a key the source doesn't have will set its value to 0.")
        
        layout.separator()

        # Header for the list, with centered labels matching the 3-column layout
        header = layout.row(align=True)
        split = header.split(factor=0.25, align=True)
        split.alignment = 'CENTER'
        split.label(text="Source")

        split = split.split(factor=0.67, align=True)
        split.alignment = 'CENTER'
        split.label(text="Shape Key", icon='SHAPEKEY_DATA')
        
        split.alignment = 'CENTER'
        split.label(text="Target")
        
        # The list itself with multi-selection enabled
        layout.template_list(
            "HHP_SHAPEKEY_UL_clash_list",
            "",
            wm, "hhp_shapekey_clashes",
            wm, "hhp_shapekey_clash_active_index",
            rows=8,
            maxrows=8,
            type='DEFAULT'
        )
        
        # Batch operation buttons
        layout.separator()
        layout.label(text="Batch Operations:")
        
        row = layout.row(align=True)
        op_source = row.operator("hhp.shapekey_clash_set_all", text="Set All to Source", icon='TRIA_LEFT')
        op_source.choice = 'SOURCE'
        
        op_target = row.operator("hhp.shapekey_clash_set_all", text="Set All to Target", icon='TRIA_RIGHT')
        op_target.choice = 'TARGET'

    def execute(self, context):
        wm = context.window_manager
        source_mesh = bpy.data.objects.get(wm.hhp_shapekey_clash_source)
        target_mesh = bpy.data.objects.get(wm.hhp_shapekey_clash_target)

        if not source_mesh or not target_mesh:
            optimized_pending.clear('animation')
            self.report({'ERROR'}, "Source or target mesh not found")
            return {'CANCELLED'}

        if not target_mesh.data.shape_keys:
            optimized_pending.clear('animation')
            return {'CANCELLED'}

        target_kb = target_mesh.data.shape_keys.key_blocks
        changed = False

        for clash in wm.hhp_shapekey_clashes:
            if clash.choice == 'SOURCE':
                target_sk = target_kb.get(clash.name)
                if not target_sk:
                    continue

                if clash.clash_type == 'TARGET_ONLY':
                    changed |= target_sk.value != 0.0
                    target_sk.value = 0.0
                else: 
                    if source_mesh.data.shape_keys:
                        source_sk = source_mesh.data.shape_keys.key_blocks.get(clash.name)
                        if source_sk:
                            before = (target_sk.value, target_sk.slider_min, target_sk.slider_max, target_sk.vertex_group)
                            target_sk.value = source_sk.value
                            target_sk.slider_min = source_sk.slider_min
                            target_sk.slider_max = source_sk.slider_max
                            target_sk.vertex_group = source_sk.vertex_group
                            changed |= before != (target_sk.value, target_sk.slider_min, target_sk.slider_max, target_sk.vertex_group)
        
        wm.hhp_shapekey_clashes.clear()
        optimized_pending.finish('animation', target_mesh, context, self.report, changed=changed)

        self.report({'INFO'}, "Clashes resolved.")
        return {'FINISHED'}

    def cancel(self, context):
        optimized_pending.clear('animation')
        context.window_manager.hhp_shapekey_clashes.clear()

def _keep_source_collection_action_compatible(operator, _context):
    """Prevent destructive source cleanup in armature replacement modes."""
    if (
        operator.transfer_modifiers in {'FULL', 'ARMATURE_SWAP'}
        and operator.source_collection_action == 'DELETE'
    ):
        operator.source_collection_action = 'DISABLE'


class HHP_OT_bs_anim_transfer(Operator):
    bl_idname = "hhp.bs_anim_transfer"
    bl_label = "Animation Transfer +"
    bl_description = "Transfer animation data from active armature to selected armatures, or from active mesh's armature to selected meshes' armatures"
    bl_options = {'REGISTER', 'UNDO'}

    # Only Swap Character Animation supplies these; never reuse them on a normal invocation.
    swap_filepath: StringProperty(
        name="Swap Character File",
        description="Character to append after confirming the transfer options",
        subtype='FILE_PATH',
        default="",
        options={'HIDDEN', 'SKIP_SAVE'},
    )

    swap_source_mesh: StringProperty(
        name="Swap Source Mesh",
        description="HHP mesh supplying animation for the character swap",
        default="",
        options={'HIDDEN', 'SKIP_SAVE'},
    )

    # Add selection mode property to track whether we're using mesh or armature selection
    selection_mode: EnumProperty(
        name="Selection Mode",
        items=[
            ('ARMATURE', 'Armature', 'Using armature selection'),
            ('MESH', 'Mesh', 'Using mesh selection')
        ],
        default='ARMATURE'
    )

    auto_find_mesh: BoolProperty(
        name="Auto Find Character Mesh",
        description="Automatically find and select the best matching mesh for each armature",
        default=True
    )

    source_mesh: StringProperty(
        name="Source Mesh",
        description="Source mesh used for mesh based transfers"
    )

    target_mesh: StringProperty(
        name="Target Mesh",
        description="Target mesh used for mesh based transfers"
    )

    transfer_object_animation: BoolProperty(
        name="Transfer object animation",
        description="Transfer object action/NLA animation between meshes while preserving existing target drivers",
        default=True
    )

    transfer_shapekeys: BoolProperty(
        name="Transfer Shapekey Animation",
        description="Transfer shape key animation data between meshes",
        default=True
    )

    transfer_unavailable_data: BoolProperty(
        name="Transfer unavailable shapekeys & vtx groups",
        description="Copy missing shape keys and vertex groups to ensure animations work correctly",
        default=True
    )

    transfer_unavailable_attributes: BoolProperty(
        name="Transfer unavailable attributes",
        description="Transfer all unavailable attributes such as UVs, vertex colors, and mesh attributes",
        default=True
    )

    transfer_unavailable_object_properties: BoolProperty(
        name="Transfer unavailable object properties",
        description="Transfer all unavailable custom properties",
        default=True
    )

    transfer_unavailable_object_properties_mode: EnumProperty(
        name="Custom Property Transfer Mode",
        description="Choose whether to transfer all missing custom properties or only those used by modifier drivers",
        items=[
            ('USED_AS_MODIFIER_DRIVERS', "Used as modifier drivers", "Transfer only unavailable custom properties used by modifier drivers"),
            ('ALL_UNAVAILABLE', "All unavailable", "Transfer all unavailable custom properties"),
        ],
        default='USED_AS_MODIFIER_DRIVERS'
    )

    shapekey_data_clash_analyzer: BoolProperty(
        name="Launch Shapekey value clash analyzer after transfer",
        description="[ADVANCED] After transfer, analyze and resolve clashes for non-animated and non-driver shape keys",
        default=False
    )

    transfer_constraints: EnumProperty(
        name="Constraints",
        description="Choose how to transfer pose bone constraints",
        items=[
            ('UNAVAILABLE', "Unavailable Only", "Only transfer constraints that don't exist on target bones"),
            ('FULL', "Full (Overwrite)", "Transfer all constraints, overwriting existing ones"),
            ('NONE', "None", "Do not transfer constraints"),
        ],
        default='UNAVAILABLE'
    )

    self_reference: BoolProperty(
        name="Self Reference",
        description="If enabled, constraints referencing the source armature will target the target armature in UNAVAILABLE mode",
        default=True
    )

    existing_constraint_values: BoolProperty(
        name="Existing Const Values",
        description="Copy values to existing target constraints with the exact same name and type in Unavailable Only mode",
        default=True
    )

    transfer_modifiers: EnumProperty(
        name="Modifiers",
        description="Choose how to transfer mesh modifiers",
        items=[
            ('UNAVAILABLE', "Unavailable Only", "Only transfer modifiers that don't exist on target mesh"),
            ('FULL', "Full (Overwrite)", "Overwrite the target modifier stack and change all Armature modifiers using the target armature to use the source armature"),
            ('ARMATURE_SWAP', "Armature Swap", "Only change all Armature modifiers using the target armature to use the source armature"),
            ('NONE', "None", "Do not transfer modifiers"),
        ],
        default='UNAVAILABLE',
        update=_keep_source_collection_action_compatible
    )

    update_binds: BoolProperty(
        name="Update Binds",
        description="Rebind mesh deform, surface deform, and corrective smooth modifiers on target meshes",
        default=False
    )

    preserve_hhp_source_mouth_shape: BoolProperty(
        name="Preserve HHP source mouth shape",
        description="After transfer, keep the copied source mouth preset with the highest source value active on the target and set its other mouth presets to 0. Leave the source character unchanged. Ignored while the shape-key value clash analyzer is enabled",
        default=False
    )

    update_mouth_shape_in_presets: BoolProperty(
        name="Update in presets",
        description="Save the preserved source mouth values in every resulting target preset; applies only when preserving the source mouth shape",
        default=True,
    )

    update_source_shapekeys: BoolProperty(
        name="Update source shapekeys to new standard",
        description="Rename the source character's legacy shape keys and preset references before transferring",
        default=True,
    )

    update_optimized_materials: BoolProperty(
        name="Update Optimized Materials",
        description="After transfer, rebuild optimized materials and normals on the receiving characters and use the source's original optimized-material display state",
        default=True,
    )

    transfer_hhp_shader_layers: BoolProperty(
        name="Transfer HHP shader layers",
        description="Relink target face shader to use the source '(HHP) Shader Layer_FINAL' node group",
        default=True
    )

    replace_armature_references: BoolProperty(
        name="Replace all references to target armature",
        description="Redirect external references from the source rig and transferred mesh to the target, including constraints, parents, drivers and node inputs. Preserve the source rig and everything in its collection. Requires one target rig. Ignored in Full Override and Armature Swap modifier modes",
        default=True
    )

    source_collection_action: EnumProperty(
        name="Source armature collection action",
        description="What to do with the source armature's collection after a successful transfer and reference replacement",
        items=[
            ('NONE', "None", "Leave the source collection unchanged", 'X', 0),
            ('DISABLE', "Disable", "Disable the source collection in the viewport and render", 'HIDE_ON', 1),
            ('DELETE', "Delete", "Delete the source collection, its child collections and all their objects from every collection and scene where they are linked; keep shared data such as transferred actions and materials", 'TRASH', 2),
        ],
        default='DISABLE',
        update=_keep_source_collection_action_compatible
    )

    purge_orphans_after_delete: BoolProperty(
        name="Purge Orphans after delete",
        description="Recursively remove unused local and linked data from the blend file after collection deletion; data still in use or marked with a fake user is kept",
        default=True,
    )

    def draw(self, context):
        layout = self.layout
        
        # Show different UI based on selection mode
        if self.selection_mode == 'MESH':
            # Mesh selection mode UI
            layout.label(text="Source and target for mesh based transfers:")
            if self.swap_filepath:
                source = bpy.data.objects.get(self.swap_source_mesh)
                layout.label(text=f"Source: {source.name if source else 'Unavailable'}", icon='MESH_DATA')
                layout.label(text="The library character will be appended after confirmation", icon='INFO')
            else:
                layout.label(text="Using selected meshes as targets", icon='INFO')
                layout.label(text="and active mesh as source")
        else:
            # Armature selection mode UI (existing functionality)
            layout.label(text="Source and target for mesh based transfers:")
            
            # Auto find mesh checkbox
            layout.prop(self, "auto_find_mesh")
            
            # Mesh selection fields (greyed out if auto find is enabled)
            row = layout.row()
            row.enabled = not self.auto_find_mesh
            row.prop_search(self, "source_mesh", context.scene, "objects", text="Source", 
                           results_are_suggestions=True)
            
            row = layout.row()
            row.enabled = not self.auto_find_mesh
            row.prop_search(self, "target_mesh", context.scene, "objects", text="Target",
                           results_are_suggestions=True)

        # Transfer options
        layout.separator()
        
        # Object animation transfer option
        row = layout.row()
        row.prop(self, "transfer_object_animation")
        
        # Shapekey transfer option
        layout.prop(self, "transfer_shapekeys")
        
        # Unavailable-data transfer options
        layout.prop(self, "transfer_unavailable_data")

        row = layout.row(align=True)
        row.enabled = self.transfer_unavailable_data
        row.prop(self, "shapekey_data_clash_analyzer", text="", toggle=True, icon='MOD_DATA_TRANSFER')
        row.label(text="Launch Shapekey value clash analyzer after transfer")

        layout.prop(self, "transfer_unavailable_attributes")
        layout.prop(self, "transfer_unavailable_object_properties")
        row = layout.row()
        row.enabled = self.transfer_unavailable_object_properties
        row.prop(self, "transfer_unavailable_object_properties_mode", text="")
        
        # Full modifier overwrite and armature-only swap replace target armature
        # references, so constraint transfer does not apply in those modes.
        constraints_column = layout.column()
        constraints_column.enabled = self.transfer_modifiers not in {'FULL', 'ARMATURE_SWAP'}
        constraints_column.label(text="Constraints:")
        row = constraints_column.row()
        row.prop(self, "transfer_constraints", expand=True)
        
        row = constraints_column.row(align=True)
        row.enabled = (self.transfer_constraints == 'UNAVAILABLE')
        row.prop(self, "self_reference")
        row.prop(self, "existing_constraint_values")
        
        # Modifiers transfer mode
        layout.label(text="Modifiers:")
        modifier_grid = layout.grid_flow(
            row_major=True,
            columns=3,
            even_columns=True,
            even_rows=True,
            align=True,
        )
        modifier_grid.prop_enum(self, "transfer_modifiers", 'UNAVAILABLE')
        modifier_grid.prop_enum(self, "transfer_modifiers", 'FULL')
        modifier_grid.prop_enum(self, "transfer_modifiers", 'NONE')
        modifier_grid.label(text="")
        modifier_grid.prop_enum(self, "transfer_modifiers", 'ARMATURE_SWAP')
        modifier_grid.label(text="")
        
        # Update binds checkbox (greyed out unless transfer_modifiers is FULL)
        row = layout.row()
        row.enabled = (self.transfer_modifiers == 'FULL')
        row.prop(self, "update_binds")

        row = layout.row(align=True)
        row.enabled = not self.shapekey_data_clash_analyzer
        row.prop(self, "preserve_hhp_source_mouth_shape")
        mouth_presets = row.row(align=True)
        mouth_presets.enabled = self.preserve_hhp_source_mouth_shape
        mouth_presets.prop(self, "update_mouth_shape_in_presets")

        row = layout.row()
        row.prop(self, "update_source_shapekeys")
        row = layout.row()
        row.prop(self, "update_optimized_materials")
        row = layout.row(align=True)
        row.prop(self, "transfer_hhp_shader_layers")

        replace_references_row = layout.row()
        replace_references_row.enabled = self.transfer_modifiers not in {'FULL', 'ARMATURE_SWAP'}
        replace_references_row.prop(self, "replace_armature_references")
        layout.label(text="Source armature collection action:", icon='OUTLINER_COLLECTION')
        source_action_row = layout.row(align=True)
        source_action_row.prop_enum(self, "source_collection_action", 'NONE')
        source_action_row.prop_enum(self, "source_collection_action", 'DISABLE')
        delete_action = source_action_row.row(align=True)
        delete_action.enabled = self.transfer_modifiers not in {'FULL', 'ARMATURE_SWAP'}
        delete_action.prop_enum(self, "source_collection_action", 'DELETE')
        purge_row = layout.row()
        purge_row.enabled = self.source_collection_action == 'DELETE'
        purge_row.prop(self, "purge_orphans_after_delete")
        if self.source_collection_action == 'DELETE':
            warning = layout.column(align=True)
            warning.alert = True
            warning.label(text="Deletes the source collection and all its objects.", icon='ERROR')
            warning.label(text="Also removes them from other collections and scenes.")
            warning.label(text="A collection containing the target cannot be deleted.")

    def invoke(self, context, event):
        if self.swap_filepath:
            if not self._validate_swap_source(context):
                return {'CANCELLED'}
            self.selection_mode = 'MESH'
            return context.window_manager.invoke_props_dialog(self, width=520)

        # Determine selection mode based on current selection so the dialog displays the right fields.
        selected_armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
        selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']

        if selected_meshes and not selected_armatures:
            self.selection_mode = 'MESH'
            if not valid_mesh_selection(context):
                self.report({'ERROR'}, "Two HHP meshes must be selected")
                return {'CANCELLED'}
        elif selected_armatures and not selected_meshes:
            self.selection_mode = 'ARMATURE'
            if not valid_armature_selection(context):
                self.report({'ERROR'}, f"Select at least two HHP armatures containing {ARMATURE_NAME_HINT} in their names")
                return {'CANCELLED'}
        else:
            self.report({'ERROR'}, "Select either armatures only or meshes only, not both")
            return {'CANCELLED'}

        # Show the popup again (this is the UI you were expecting).
        return context.window_manager.invoke_props_dialog(self, width=520)

    def execute(self, context):
        if self.swap_filepath:
            if not self._validate_swap_source(context):
                return {'CANCELLED'}
            # Import at execution time because the addon entry point imports this module.
            from .. import _append_swap_character_target
            result = _append_swap_character_target(
                context, bpy.data.objects.get(self.swap_source_mesh), self.swap_filepath, self,
            )
            if result != {'FINISHED'}:
                return result

        # Store original selection and active object
        original_selection = context.selected_objects.copy()
        original_active = context.active_object

        if not original_active or not original_selection:
            self.report({'ERROR'}, "No active object or no selection")
            return {'CANCELLED'}

        # Auto-detect selection mode every run to make the operator robust regardless of how it was invoked.
        selected_armatures = [obj for obj in original_selection if obj.type == 'ARMATURE']
        selected_meshes = [obj for obj in original_selection if obj.type == 'MESH']

        if selected_meshes and not selected_armatures:
            self.selection_mode = 'MESH'
        elif selected_armatures and not selected_meshes:
            self.selection_mode = 'ARMATURE'
        else:
            self.report({'ERROR'}, "Select either armatures only or meshes only, not both")
            return {'CANCELLED'}

        # Handle mesh selection mode
        if self.selection_mode == 'MESH':
            if not valid_mesh_selection(context):
                self.report({'ERROR'}, "Two HHP meshes must be selected")
                return {'CANCELLED'}
            return self.execute_mesh_mode(context, original_selection, original_active)

        if not valid_armature_selection(context):
            self.report({'ERROR'}, f"Select at least two HHP armatures containing {ARMATURE_NAME_HINT} in their names")
            return {'CANCELLED'}

        target_armatures = [obj for obj in original_selection
                            if obj.type == 'ARMATURE' and obj != original_active]
        if self.auto_find_mesh:
            source_mesh = self.get_best_scoring_mesh_for_armature(original_active)
            mesh_pairs = [(source_mesh, self.get_best_scoring_mesh_for_armature(target))
                          for target in target_armatures]
        else:
            mesh_pairs = [(bpy.data.objects.get(self.source_mesh),
                           bpy.data.objects.get(self.target_mesh))]
        try:
            transfer_state = TransferState(self, context, original_active, target_armatures, mesh_pairs)
            prepare_transfer_materials(mesh_pairs, context)
            if self.update_source_shapekeys:
                prepare_source_shape_keys([source for source, _ in mesh_pairs])
        except TransferError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}

        # 0. Copy pose (new step)
        self.copy_pose(context)

        # 1. Copy transformations
        self.copy_transformations(context)
        
        # 2. Enable NLA stack evaluation
        self.enable_nla_stack()
        
        # 3. Link animation data
        link_animation_preserving_drivers(target_armatures)
        
        # 4. Copy constraints (if enabled)
        if (
            self.transfer_modifiers not in {'FULL', 'ARMATURE_SWAP'}
            and self.transfer_constraints != 'NONE'
        ):
            self.copy_constraints(context)
        
        # 5. Set pose position
        self.set_pose_position()
        
        # 6. Handle mesh selection and transfers
        if self.auto_find_mesh:
            self.select_best_scoring_meshes_for_selected_armatures(context)
            
            active_mesh = context.active_object
            if active_mesh and active_mesh.type == 'MESH':
                target_meshes = [obj for obj in context.selected_objects if obj != active_mesh and obj.type == 'MESH']
                
                # Transfer object animation if enabled
                if self.transfer_object_animation:
                    for target in target_meshes:
                        self.copy_object_animation_without_drivers(active_mesh, target)
                
                for target in target_meshes:
                    # Transfer unavailable shape keys and vertex groups first if enabled
                    if self.transfer_unavailable_data:
                        self.transfer_vertex_groups(active_mesh, target)
                        self.transfer_shape_keys(active_mesh, target)
                    if self.transfer_unavailable_attributes:
                        self.transfer_unavailable_attributes_data(active_mesh, target)
                    if self.transfer_unavailable_object_properties:
                        self.transfer_unavailable_object_properties_data(active_mesh, target)
                    if self.transfer_shapekeys:
                        self.copy_shapekey_nla_tracks(active_mesh, target)
                    if self.transfer_hhp_shader_layers:
                        self.transfer_hhp_shader_layers_data(active_mesh, target)

                    # Analyze and resolve clashes for this target
                    if self.shapekey_data_clash_analyzer and self.transfer_unavailable_data:
                        if self.analyze_and_resolve_clashes(context, active_mesh, target):
                            bpy.ops.hhp.shapekey_clash_resolver('INVOKE_DEFAULT')
                
                # Transfer modifiers if enabled
                if self.transfer_modifiers != 'NONE':
                    self.copy_modifiers_to_selected(active_mesh, target_meshes)
        else:
            source = bpy.data.objects.get(self.source_mesh)
            target = bpy.data.objects.get(self.target_mesh)
            if source and target:
                # Transfer object animation if enabled
                if self.transfer_object_animation:
                    self.copy_object_animation_without_drivers(source, target)
                
                # Transfer unavailable shape keys and vertex groups first if enabled
                if self.transfer_unavailable_data:
                    self.transfer_vertex_groups(source, target)
                    self.transfer_shape_keys(source, target)
                if self.transfer_unavailable_attributes:
                    self.transfer_unavailable_attributes_data(source, target)
                if self.transfer_unavailable_object_properties:
                    self.transfer_unavailable_object_properties_data(source, target)
                if self.transfer_shapekeys:
                    self.copy_shapekey_nla_tracks(source, target)
                if self.transfer_hhp_shader_layers:
                    self.transfer_hhp_shader_layers_data(source, target)

                # Analyze and resolve clashes for this target
                if self.shapekey_data_clash_analyzer and self.transfer_unavailable_data:
                    if self.analyze_and_resolve_clashes(context, source, target):
                        bpy.ops.hhp.shapekey_clash_resolver('INVOKE_DEFAULT')

                if self.transfer_modifiers != 'NONE':
                    self.copy_modifiers_to_selected(source, [target])

        transfer_state.finish(self, context)

        return {'FINISHED'}

    def _validate_swap_source(self, context):
        source = bpy.data.objects.get(self.swap_source_mesh)
        if not is_hhp_mesh(source) or context.view_layer.objects.get(source.name) != source:
            self.report({'ERROR'}, "The source HHP character is no longer available for swapping")
            return False
        if not any(mod.type == 'ARMATURE' and mod.object for mod in source.modifiers):
            self.report({'ERROR'}, "The source HHP character does not have an armature modifier")
            return False
        return True

    def execute_mesh_mode(self, context, original_selection, original_active):
        """Execute transfer in mesh selection mode"""
        # Get selected meshes and active mesh
        selected_meshes = [obj for obj in original_selection if obj.type == 'MESH']
        active_mesh = original_active if original_active.type == 'MESH' else None
        
        if not active_mesh:
            self.report({'ERROR'}, "Active object must be a mesh in mesh selection mode")
            return {'CANCELLED'}
        
        # Find armatures for meshes
        def get_armature_from_mesh(mesh):
            for mod in mesh.modifiers:
                if mod.type == 'ARMATURE' and mod.object:
                    return mod.object
            return None
        
        source_armature = get_armature_from_mesh(active_mesh)
        if not source_armature:
            self.report({'ERROR'}, f"Active mesh '{active_mesh.name}' does not have an armature modifier")
            return {'CANCELLED'}
        
        target_armatures = []
        target_meshes = [mesh for mesh in selected_meshes if mesh != active_mesh]
        
        for mesh in target_meshes:
            armature = get_armature_from_mesh(mesh)
            if not armature:
                self.report({'ERROR'}, f"Mesh '{mesh.name}' does not have an armature modifier")
                return {'CANCELLED'}
            target_armatures.append(armature)
        
        try:
            transfer_state = TransferState(
                self, context, source_armature, target_armatures,
                [(active_mesh, mesh) for mesh in target_meshes])
            prepare_transfer_materials([(active_mesh, mesh) for mesh in target_meshes], context)
            if self.update_source_shapekeys:
                prepare_source_shape_keys([active_mesh])
        except TransferError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}

        # Set up armature selection and make source armature active
        bpy.ops.object.select_all(action='DESELECT')
        source_armature.select_set(True)
        for armature in target_armatures:
            armature.select_set(True)
        context.view_layer.objects.active = source_armature
        
        # Store original property values to restore later
        original_auto_find = self.auto_find_mesh
        original_source_mesh = self.source_mesh
        original_target_mesh = self.target_mesh
        
        # Now execute the standard armature transfer logic
        # 0. Copy pose
        self.copy_pose(context)

        # 1. Copy transformations
        self.copy_transformations(context)
        
        # 2. Enable NLA stack evaluation
        self.enable_nla_stack()
        
        # 3. Link animation data
        link_animation_preserving_drivers(target_armatures)
        
        # 4. Copy constraints (if enabled)
        if (
            self.transfer_modifiers not in {'FULL', 'ARMATURE_SWAP'}
            and self.transfer_constraints != 'NONE'
        ):
            self.copy_constraints(context)
        
        # 5. Set pose position
        self.set_pose_position()
        
        # 6. Handle mesh transfers for each target
        # Transfer object animation if enabled
        if self.transfer_object_animation:
            for target in target_meshes:
                self.copy_object_animation_without_drivers(active_mesh, target)
        
        for target_mesh in target_meshes:
            # Transfer unavailable shape keys and vertex groups first if enabled
            if self.transfer_unavailable_data:
                self.transfer_vertex_groups(active_mesh, target_mesh)
                self.transfer_shape_keys(active_mesh, target_mesh)
            if self.transfer_unavailable_attributes:
                self.transfer_unavailable_attributes_data(active_mesh, target_mesh)
            if self.transfer_unavailable_object_properties:
                self.transfer_unavailable_object_properties_data(active_mesh, target_mesh)
            if self.transfer_shapekeys:
                self.copy_shapekey_nla_tracks(active_mesh, target_mesh)
            if self.transfer_hhp_shader_layers:
                self.transfer_hhp_shader_layers_data(active_mesh, target_mesh)
            
            if self.transfer_modifiers != 'NONE':
                self.copy_modifiers_to_selected(active_mesh, [target_mesh])

        # 7. Analyze and resolve shape key clashes
        if self.shapekey_data_clash_analyzer and self.transfer_unavailable_data:
            for target_mesh in target_meshes:
                if self.analyze_and_resolve_clashes(context, active_mesh, target_mesh):
                    bpy.ops.hhp.shapekey_clash_resolver('INVOKE_DEFAULT')
                    # This will pop up for each target with clashes

        transfer_state.finish(self, context)

        # Restore original property values so UI is not affected
        self.auto_find_mesh = original_auto_find
        self.source_mesh = original_source_mesh
        self.target_mesh = original_target_mesh

        return {'FINISHED'}

    def copy_pose(self, context):
        source_armature = context.active_object
        if not source_armature or source_armature.type != 'ARMATURE':
            return
            
        for target in context.selected_objects:
            if target != source_armature and target.type == 'ARMATURE':
                # Copy pose from source to target
                for bone_name, source_bone in source_armature.pose.bones.items():
                    if bone_name in target.pose.bones:
                        target_bone = target.pose.bones[bone_name]
                        target_bone.matrix = source_bone.matrix.copy()
                        target_bone.rotation_quaternion = source_bone.rotation_quaternion.copy()
                        target_bone.rotation_euler = source_bone.rotation_euler.copy()
                        target_bone.scale = source_bone.scale.copy()
                        target_bone.location = source_bone.location.copy()

    def copy_transformations(self, context):
        active_obj = context.active_object
        if active_obj is None or len(context.selected_objects) <= 1:
            self.report({'WARNING'}, "Please select an active object and at least one other object.")
            return

        for obj in context.selected_objects:
            if obj == active_obj:
                continue
            obj.location = active_obj.location.copy()
            obj.rotation_euler = active_obj.rotation_euler.copy()
            obj.scale = active_obj.scale.copy()

    def enable_nla_stack(self):
        active_object = bpy.context.view_layer.objects.active
        for obj in bpy.context.selected_objects:
            if obj != active_object and obj.type == 'ARMATURE':
                if obj.animation_data is None:
                    obj.animation_data_create()
                obj.animation_data.use_nla = True

    def clear_nla_tracks(self, anim_data):
        while anim_data and anim_data.nla_tracks:
            anim_data.nla_tracks.remove(anim_data.nla_tracks[0])

    def copy_object_transforms(self, source, target):
        if not source or not target:
            return

        try:
            target.location = source.location.copy()
        except Exception:
            pass

        try:
            target.scale = source.scale.copy()
        except Exception:
            pass

        try:
            target.rotation_mode = source.rotation_mode
        except Exception:
            pass

        try:
            if source.rotation_mode == 'QUATERNION':
                target.rotation_quaternion = source.rotation_quaternion.copy()
            elif source.rotation_mode == 'AXIS_ANGLE':
                target.rotation_axis_angle = source.rotation_axis_angle[:]
            else:
                target.rotation_euler = source.rotation_euler.copy()
        except Exception:
            pass

    def copy_object_animation_without_drivers(self, source, target):
        if not source or not target:
            return

        # Ensure base object transforms are transferred even when no transform keys exist.
        self.copy_object_transforms(source, target)

        source_anim = source.animation_data
        if not source_anim:
            return

        if target.animation_data is None:
            target.animation_data_create()
        target_anim = target.animation_data

        # Copy animation-data evaluation settings so NLA/action blending behavior matches source.
        for attr in ('use_nla', 'action_blend_type', 'action_extrapolation', 'action_influence'):
            try:
                setattr(target_anim, attr, getattr(source_anim, attr))
            except Exception:
                pass

        # Preserve target drivers by only replacing action/NLA content.
        self.clear_nla_tracks(target_anim)
        target_anim.action = None

        if source_anim.action:
            new_action = source_anim.action.copy()
            new_action.use_fake_user = True
            target_anim.action = new_action

            # Blender 5 slotted actions: preserve slot selection so all channels evaluate.
            if hasattr(target_anim, 'action_slot'):
                target_slot = None
                source_slot = getattr(source_anim, 'action_slot', None)
                if source_slot and hasattr(new_action, 'slots'):
                    source_slot_id = getattr(source_slot, 'identifier', None)
                    if source_slot_id:
                        for slot in new_action.slots:
                            if getattr(slot, 'identifier', None) == source_slot_id:
                                target_slot = slot
                                break
                    if target_slot is None and len(new_action.slots) > 0:
                        target_slot = new_action.slots[0]
                try:
                    target_anim.action_slot = target_slot
                except Exception:
                    pass

        for source_track in source_anim.nla_tracks:
            new_track = target_anim.nla_tracks.new()
            new_track.name = source_track.name
            try:
                new_track.mute = source_track.mute
                new_track.lock = source_track.lock
                new_track.is_solo = source_track.is_solo
            except Exception:
                pass

            for source_strip in source_track.strips:
                if not source_strip.action:
                    continue
                strip_action = source_strip.action.copy()
                strip_action.use_fake_user = True
                new_strip = new_track.strips.new(
                    name=source_strip.name,
                    start=int(source_strip.frame_start),
                    action=strip_action,
                )

                if hasattr(new_strip, 'action_slot'):
                    strip_slot = None
                    source_strip_slot = getattr(source_strip, 'action_slot', None)
                    if source_strip_slot and hasattr(strip_action, 'slots'):
                        source_strip_slot_id = getattr(source_strip_slot, 'identifier', None)
                        if source_strip_slot_id:
                            for slot in strip_action.slots:
                                if getattr(slot, 'identifier', None) == source_strip_slot_id:
                                    strip_slot = slot
                                    break
                        if strip_slot is None and len(strip_action.slots) > 0:
                            strip_slot = strip_action.slots[0]
                    try:
                        new_strip.action_slot = strip_slot
                    except Exception:
                        pass

                for attr in (
                    'frame_start', 'frame_end', 'blend_type', 'extrapolation', 'influence',
                    'use_animated_influence', 'use_animated_time', 'use_auto_blend',
                    'blend_in', 'blend_out', 'use_reverse', 'repeat', 'scale', 'mute',
                ):
                    try:
                        setattr(new_strip, attr, getattr(source_strip, attr))
                    except Exception:
                        pass

    def find_material_by_substring(self, obj, substring):
        if not obj or not getattr(obj, "data", None) or not getattr(obj.data, "materials", None):
            return None
        for mat in obj.data.materials:
            if mat and substring in mat.name:
                return mat
        return None

    def find_group_node_by_label_in_tree(self, node_tree, label_substring):
        if not node_tree:
            return None
        for node in node_tree.nodes:
            if getattr(node, "type", None) != 'GROUP':
                continue
            node_label = getattr(node, "label", "") or ""
            node_name = getattr(node, "name", "") or ""
            node_tree_name = getattr(getattr(node, "node_tree", None), "name", "") or ""
            if (
                label_substring in node_label
                or label_substring in node_name
                or label_substring in node_tree_name
            ):
                return node
        return None

    def find_group_node_in_material(self, material, label_substring):
        if not material or not material.use_nodes or not material.node_tree:
            return None
        return self.find_group_node_by_label_in_tree(material.node_tree, label_substring)

    def transfer_hhp_shader_layers_data(self, source, target):
        if not source or not target:
            return

        src_face_mat = self.find_material_by_substring(source, "Genesis 8 Female_Face")
        tgt_face_mat = self.find_material_by_substring(target, "Genesis 8 Female_Face")
        if not src_face_mat or not tgt_face_mat:
            return

        src_shader_layers = self.find_group_node_in_material(src_face_mat, "(HHP)_Shader Layers")
        tgt_shader_layers = self.find_group_node_in_material(tgt_face_mat, "(HHP)_Shader Layers")
        if not src_shader_layers or not tgt_shader_layers:
            return

        src_layers_tree = getattr(src_shader_layers, "node_tree", None)
        tgt_layers_tree = getattr(tgt_shader_layers, "node_tree", None)
        if not src_layers_tree or not tgt_layers_tree:
            return

        src_final = self.find_group_node_by_label_in_tree(src_layers_tree, "(HHP) Shader Layer_FINAL")
        tgt_final = self.find_group_node_by_label_in_tree(tgt_layers_tree, "(HHP) Shader Layer_FINAL")
        if not src_final or not tgt_final:
            return

        src_final_tree = getattr(src_final, "node_tree", None)
        if not src_final_tree:
            return

        try:
            tgt_final.node_tree = src_final_tree
        except Exception:
            pass

    def sync_proportion_distribution_ui(self, armature):
        sync_proportion_distribution_ui(armature)

    def remap_constraint_self_references(
        self,
        source_constraint,
        target_constraint,
        source_armature,
        target_armature,
    ):
        """Remap every direct constraint object slot that references the source rig."""
        for prop in source_constraint.bl_rna.properties:
            if prop.identifier == 'rna_type' or prop.type != 'POINTER' or prop.is_readonly:
                continue
            try:
                if getattr(source_constraint, prop.identifier) == source_armature:
                    setattr(target_constraint, prop.identifier, target_armature)
            except (AttributeError, TypeError, RuntimeError):
                pass

    def copy_constraints(self, context):
        armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
        with preserve_rig_drivers(armatures):
            self._copy_constraints(context)

    def _copy_constraints(self, context):
        original_selection = context.selected_objects.copy()
        original_active = context.view_layer.objects.active
        bpy.ops.object.mode_set(mode='OBJECT')
        source_armature = original_active
        
        if source_armature.type != 'ARMATURE':
            self.report({'WARNING'}, "Source is not an armature. Skipping.")
            return

        target_armatures = [obj for obj in original_selection if obj != source_armature]

        for target_armature in target_armatures:
            if target_armature.type != 'ARMATURE':
                self.report({'INFO'}, f"Target {target_armature.name} is not an armature. Skipping.")
                continue

            context.view_layer.objects.active = target_armature
            bpy.ops.object.mode_set(mode='POSE')

            for bone_name, source_bone in source_armature.pose.bones.items():
                if bone_name in target_armature.pose.bones:
                    target_bone = target_armature.pose.bones[bone_name]
                    
                    # In FULL mode, remove existing constraints first
                    if self.transfer_constraints == 'FULL':
                        for c in list(target_bone.constraints):
                            if not (is_proportion_owned(c) or is_generated_rig_constraint(c)):
                                target_bone.constraints.remove(c)
                    
                    for source_constraint in source_bone.constraints:
                        # Always synchronized separately, including absent constraints.
                        if (is_proportion_owned(source_constraint)
                                or is_generated_rig_constraint(source_constraint)):
                            continue
                        protected_match = next((c for c in target_bone.constraints
                                                if c.name == source_constraint.name
                                                and is_generated_rig_constraint(c)), None)
                        if protected_match:
                            continue
                        # In UNAVAILABLE mode, optionally update an exact existing
                        # constraint match instead of creating a duplicate.
                        if self.transfer_constraints == 'UNAVAILABLE':
                            existing_constraint = next(
                                (
                                    constraint
                                    for constraint in target_bone.constraints
                                    if (
                                        constraint.type == source_constraint.type
                                        and constraint.name == source_constraint.name
                                    )
                                ),
                                None,
                            )
                            if existing_constraint:
                                if self.existing_constraint_values:
                                    for prop in source_constraint.bl_rna.properties:
                                        attr = prop.identifier
                                        if attr in {'rna_type', 'name'} or prop.is_readonly:
                                            continue
                                        try:
                                            setattr(existing_constraint, attr, getattr(source_constraint, attr))
                                        except Exception as e:
                                            print(f"Could not copy attribute {attr} due to: {e}")

                                    if self.self_reference:
                                        self.remap_constraint_self_references(
                                            source_constraint,
                                            existing_constraint,
                                            source_armature,
                                            target_armature,
                                        )
                                continue

                        new_constraint = target_bone.constraints.copy(source_constraint)
                        
                        # Remap all self-referencing object slots, including secondary
                        # slots such as an IK constraint's pole_target.
                        if self.transfer_constraints == 'UNAVAILABLE' and self.self_reference:
                            self.remap_constraint_self_references(
                                source_constraint,
                                new_constraint,
                                source_armature,
                                target_armature,
                            )

            bpy.ops.object.mode_set(mode='OBJECT')
            self.sync_proportion_distribution_ui(target_armature)

        for obj in context.view_layer.objects:
            obj.select_set(obj in original_selection)
        context.view_layer.objects.active = original_active

    def set_pose_position(self):
        for obj in bpy.context.scene.objects:
            if obj.type == 'ARMATURE':
                obj.data.pose_position = 'POSE'
        bpy.context.view_layer.update()

    def score_by_attribute_descending(self, values):
        scores = {}
        n = len(values)
        if n == 1:
            scores[0] = 1.0
            return scores
        
        step = 1.0 / (n - 1)
        for i in range(n):
            scores[i] = 1.0 - (i * step)
        return scores

    def get_best_scoring_mesh_for_armature(self, armature_obj):
        candidates = []
        for obj in bpy.data.objects:
            if (obj.type == 'MESH' and 
                obj.visible_get() and 
                obj.display_type != 'WIRE' and 
                not obj.hide_render):
                for mod in obj.modifiers:
                    if mod.type == 'ARMATURE' and mod.object == armature_obj:
                        longest_dim = max(obj.dimensions.x, obj.dimensions.y, obj.dimensions.z)
                        modifier_count = len(obj.modifiers)
                        bounding_box_volume = obj.dimensions.x * obj.dimensions.y * obj.dimensions.z
                        candidates.append((obj, longest_dim, modifier_count, bounding_box_volume))
                        break

        if not candidates:
            return None

        sorted_by_dim = sorted(candidates, key=lambda c: c[1], reverse=True)
        dim_ranks = self.score_by_attribute_descending([c[1] for c in sorted_by_dim])

        sorted_by_mod_count = sorted(candidates, key=lambda c: c[2], reverse=True)
        mod_count_ranks = self.score_by_attribute_descending([c[2] for c in sorted_by_mod_count])

        sorted_by_volume = sorted(candidates, key=lambda c: c[3], reverse=True)
        volume_ranks = self.score_by_attribute_descending([c[3] for c in sorted_by_volume])

        final_scores = {}

        for i, c in enumerate(sorted_by_dim):
            obj = c[0]
            final_scores[obj] = {
                "dim": dim_ranks[i],
                "mod": 0.0,
                "vol": 0.0
            }

        for i, c in enumerate(sorted_by_mod_count):
            obj = c[0]
            if obj not in final_scores:
                final_scores[obj] = {"dim": 0.0, "mod": 0.0, "vol": 0.0}
            final_scores[obj]["mod"] = mod_count_ranks[i]

        for i, c in enumerate(sorted_by_volume):
            obj = c[0]
            if obj not in final_scores:
                final_scores[obj] = {"dim": 0.0, "mod": 0.0, "vol": 0.0}
            final_scores[obj]["vol"] = volume_ranks[i]

        best_obj = None
        best_score = float('-inf')

        for obj, ranks in final_scores.items():
            total_score = ranks["dim"] + ranks["mod"] + ranks["vol"]
            if total_score > best_score:
                best_score = total_score
                best_obj = obj

        return best_obj

    def auto_find_and_transfer_shapekeys(self, context):
        selected_armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
        active_armature = context.active_object if context.active_object in selected_armatures else None

        best_mesh_map = {}
        for armature in selected_armatures:
            best_mesh_map[armature] = self.get_best_scoring_mesh_for_armature(armature)

        if active_armature:
            source_mesh = best_mesh_map.get(active_armature)
            if source_mesh:
                for armature in selected_armatures:
                    if armature != active_armature:
                        target_mesh = best_mesh_map.get(armature)
                        if target_mesh:
                            self.copy_shapekey_nla_tracks(source_mesh, target_mesh)

    def copy_shapekey_nla_tracks(self, source, target):
        source_shape_keys = source.data.shape_keys
        if not source_shape_keys:
            return

        target_shape_keys = target.data.shape_keys
        if not target_shape_keys:
            self.report({'WARNING'}, f"Target object '{target.name}' does not have shape keys.")
            return

        if not source_shape_keys.animation_data:
            return

        # Key datablocks use the same action/NLA system as objects. Reuse the
        # Blender 5-aware copier so copied actions and NLA strips receive the
        # correct action slots; without those slots their F-Curves do not
        # evaluate on the target shape keys.
        self.copy_object_animation_without_drivers(source_shape_keys, target_shape_keys)

    def select_best_scoring_meshes_for_selected_armatures(self, context):
        """
        For each selected Armature, determine which Mesh wins by the combined
        sum of ranks for (longest axis, number of modifiers, bounding box volume).
        Select those winning meshes, and if the active object is an Armature,
        make its winning mesh the new active object.
        """
        selected_objs = context.selected_objects
        active_obj = context.active_object

        # Filter the selection to only Armatures
        selected_armatures = [obj for obj in selected_objs if obj.type == 'ARMATURE']

        # Identify the active Armature (if the active object is one)
        active_armature = active_obj if active_obj in selected_armatures else None

        # Gather the "best scoring" mesh for each selected Armature
        best_mesh_map = {}
        for armature in selected_armatures:
            best_mesh_map[armature] = self.get_best_scoring_mesh_for_armature(armature)

        # Deselect everything
        bpy.ops.object.select_all(action='DESELECT')

        # Select the winning mesh for each Armature (if any)
        for armature in selected_armatures:
            mesh_obj = best_mesh_map[armature]
            if mesh_obj is not None:
                mesh_obj.select_set(True)

        # If there's an active Armature, make its best mesh the active object
        if active_armature is not None:
            active_mesh = best_mesh_map[active_armature]
            if active_mesh is not None:
                context.view_layer.objects.active = active_mesh
                active_mesh.select_set(True)

    def rebind_modifiers(self, obj):
        # Store original active object
        original_active = bpy.context.view_layer.objects.active
        
        # Make the object active
        bpy.context.view_layer.objects.active = obj
        
        # First unbind
        for modifier in obj.modifiers:
            if modifier.show_viewport and modifier.show_render:
                if modifier.type == 'MESH_DEFORM' and modifier.is_bound:
                    bpy.ops.object.meshdeform_bind(modifier=modifier.name)
                elif modifier.type == 'SURFACE_DEFORM' and modifier.is_bound:
                    bpy.ops.object.surfacedeform_bind(modifier=modifier.name)
                elif modifier.type == 'CORRECTIVE_SMOOTH' and modifier.is_bind:
                    bpy.ops.object.correctivesmooth_bind(modifier=modifier.name)
        
        # Then rebind
        for modifier in obj.modifiers:
            if modifier.show_viewport and modifier.show_render:
                if modifier.type == 'MESH_DEFORM' and not modifier.is_bound:
                    bpy.ops.object.meshdeform_bind(modifier=modifier.name)
                elif modifier.type == 'SURFACE_DEFORM' and not modifier.is_bound:
                    bpy.ops.object.surfacedeform_bind(modifier=modifier.name)
                elif modifier.type == 'CORRECTIVE_SMOOTH' and not modifier.is_bind:
                    bpy.ops.object.correctivesmooth_bind(modifier=modifier.name)
        
        # Restore original active object
        bpy.context.view_layer.objects.active = original_active

    def get_mesh_armature_target(self, obj):
        if not obj or obj.type != 'MESH':
            return None
        arm_mod = next((m for m in obj.modifiers if m.type == 'ARMATURE' and m.object), None)
        return arm_mod.object if arm_mod else None

    def swap_armature_modifier_targets(self, source_armature, target_armature):
        """Point every Armature modifier using target_armature at source_armature."""
        if not source_armature or not target_armature or source_armature == target_armature:
            return

        for obj in bpy.data.objects:
            for modifier in obj.modifiers:
                if modifier.type == 'ARMATURE' and modifier.object == target_armature:
                    modifier.object = source_armature

    def copy_driver_struct(self, src_driver, dst_driver):
        dst_driver.type = src_driver.type
        dst_driver.expression = src_driver.expression
        dst_driver.use_self = src_driver.use_self

        while dst_driver.variables:
            dst_driver.variables.remove(dst_driver.variables[0])

        for src_var in src_driver.variables:
            dst_var = dst_driver.variables.new()
            dst_var.name = src_var.name
            dst_var.type = src_var.type
            for i, src_target in enumerate(src_var.targets):
                if i >= len(dst_var.targets):
                    continue
                dst_target = dst_var.targets[i]
                for prop in src_target.bl_rna.properties:
                    prop_id = prop.identifier
                    if prop_id == 'rna_type' or prop.is_readonly:
                        continue
                    try:
                        setattr(dst_target, prop_id, getattr(src_target, prop_id))
                    except Exception:
                        pass

    def copy_modifier_drivers_with_remap(self, source_obj, target_obj, source_modifier_name, target_modifier_name, source_armature, target_armature):
        source_anim = getattr(source_obj, "animation_data", None)
        if not source_anim or not getattr(source_anim, "drivers", None):
            return

        source_prefix = f'modifiers["{source_modifier_name}"]'
        target_prefix = f'modifiers["{target_modifier_name}"]'

        for source_fcurve in source_anim.drivers:
            if not source_fcurve.data_path.startswith(source_prefix):
                continue

            target_data_path = source_fcurve.data_path.replace(source_prefix, target_prefix, 1)

            try:
                target_obj.driver_remove(target_data_path, source_fcurve.array_index)
            except Exception:
                pass

            try:
                target_fcurve = target_obj.driver_add(target_data_path, source_fcurve.array_index)
            except TypeError:
                target_fcurve = target_obj.driver_add(target_data_path)
                if isinstance(target_fcurve, (list, tuple)):
                    continue

            self.copy_driver_struct(source_fcurve.driver, target_fcurve.driver)

            for var in target_fcurve.driver.variables:
                for target in var.targets:
                    if not isinstance(getattr(target, "id", None), bpy.types.Object):
                        continue
                    if target.id == source_obj:
                        target.id = target_obj
                    elif source_armature and target_armature and target.id == source_armature:
                        target.id = target_armature

    def copy_modifiers_to_selected(self, source_obj, target_objs):
        if not source_obj or source_obj.type != 'MESH' or not source_obj.modifiers:
            return

        # Use the source's entire modifier list as the template for order.
        source_modifiers_template = list(source_obj.modifiers)

        def find_modifier(obj, name, mod_type):
            return next((mod for mod in obj.modifiers if mod.name == name and mod.type == mod_type), None)

        original_selection = bpy.context.selected_objects.copy()
        original_active = bpy.context.view_layer.objects.active

        def copy_modifier_with_operator(target_obj, modifier_name):
            before_modifier_names = {mod.name for mod in target_obj.modifiers}
            bpy.ops.object.select_all(action='DESELECT')
            source_obj.select_set(True)
            target_obj.select_set(True)
            bpy.context.view_layer.objects.active = source_obj
            bpy.ops.object.modifier_copy_to_selected(modifier=modifier_name)

            for mod in target_obj.modifiers:
                if mod.name not in before_modifier_names:
                    return mod.name

            copied_mod = target_obj.modifiers.get(modifier_name)
            return copied_mod.name if copied_mod else None

        for obj in target_objs:
            if obj.type != 'MESH':
                continue

            source_armature = self.get_mesh_armature_target(source_obj)
            target_armature = self.get_mesh_armature_target(obj)
            
            # --- FULL Mode ---
            if self.transfer_modifiers == 'FULL':
                self.swap_armature_modifier_targets(source_armature, target_armature)

                # Nuke and pave: Remove all existing modifiers from the target
                obj.modifiers.clear()

                # Clone the entire modifier stack from the source
                for source_mod in source_modifiers_template:
                    copied_modifier_name = copy_modifier_with_operator(obj, source_mod.name)
                    if copied_modifier_name:
                        self.copy_modifier_drivers_with_remap(
                            source_obj,
                            obj,
                            source_mod.name,
                            copied_modifier_name,
                            source_armature,
                            target_armature,
                        )
                
                # Rebind if requested
                if self.update_binds:
                    original_frame = bpy.context.scene.frame_current
                    bpy.context.scene.frame_set(bpy.context.scene.frame_start)
                    self.rebind_modifiers(obj)
                    bpy.context.scene.frame_set(original_frame)

            # --- ARMATURE SWAP Mode ---
            elif self.transfer_modifiers == 'ARMATURE_SWAP':
                self.swap_armature_modifier_targets(source_armature, target_armature)

            # --- UNAVAILABLE Mode ---
            elif self.transfer_modifiers == 'UNAVAILABLE':
                copied_any = False
                # First, copy any missing modifiers
                for source_mod in source_modifiers_template:
                    if not find_modifier(obj, source_mod.name, source_mod.type):
                        copied_any = True
                        copied_modifier_name = copy_modifier_with_operator(obj, source_mod.name)
                        if copied_modifier_name:
                            self.copy_modifier_drivers_with_remap(
                                source_obj,
                                obj,
                                source_mod.name,
                                copied_modifier_name,
                                source_armature,
                                target_armature,
                            )
                
                # Now, only if we added something, reorder the entire stack
                if copied_any:
                    self.reorder_modifiers(obj, source_modifiers_template)

        bpy.ops.object.select_all(action='DESELECT')
        for selected_obj in original_selection:
            if selected_obj.name in bpy.data.objects:
                selected_obj.select_set(True)
        bpy.context.view_layer.objects.active = original_active

    def reorder_modifiers(self, obj, source_order_template):
        """Reorders modifiers on obj to match the source_order_template,
           appending any modifiers not in the template to the end."""
           
        current_modifiers = obj.modifiers[:]
        new_order = []

        # 1. Build the new order list: start with modifiers from the template
        for source_mod in source_order_template:
            target_mod = next((m for m in current_modifiers if m.name == source_mod.name and m.type == source_mod.type), None)
            if target_mod:
                new_order.append(target_mod)
        
        # 2. Add any remaining modifiers from the target that weren't in the template
        for mod in current_modifiers:
            if mod not in new_order:
                new_order.append(mod)

        # 3. Apply the new order by moving modifiers to their final positions
        for i, mod in enumerate(new_order):
            # Find the current index of the modifier we want to move
            from_index = -1
            for idx, m in enumerate(obj.modifiers):
                if m == mod:
                    from_index = idx
                    break
            
            # Move it to the correct position `i` if it's not already there
            if from_index != -1 and from_index != i:
                obj.modifiers.move(from_index, i)

    def collection_contains_object(self, collection, obj):
        """Recursively determine if the given collection or any of its children contains the object."""
        if obj.name in collection.objects:
            return True
        for child in collection.children:
            if self.collection_contains_object(child, obj):
                return True
        return False

    def transfer_vertex_groups(self, source, target):
        """Transfer missing vertex groups from source to target mesh"""
        if not source.vertex_groups:
            return
        if len(source.data.vertices) != len(target.data.vertices):
            self.report({'WARNING'}, f"Cannot transfer vertex groups to '{target.name}': Vertex count does not match source.")
            return
        existing = {vg.name for vg in target.vertex_groups}
        for src_vg in source.vertex_groups:
            if src_vg.name in existing:
                continue
            tgt_vg = target.vertex_groups.new(name=src_vg.name)
            # only non-zero weights; uses src_vg.weight() under the hood
            for v in source.data.vertices:
                try:
                    w = src_vg.weight(v.index)
                    if w:
                        tgt_vg.add([v.index], w, 'REPLACE')
                except RuntimeError:
                    # vertex not in group → skip
                    pass

    def transfer_shape_keys(self, source, target):
        """Transfer missing shape keys from source to target mesh"""
        sk_src = source.data.shape_keys
        if not sk_src or len(sk_src.key_blocks) <= 1:
            return

        # Prevent crash if meshes have different vertex counts
        if len(source.data.vertices) != len(target.data.vertices):
            self.report({'WARNING'}, f"Cannot transfer shape keys to '{target.name}': Vertex count does not match source.")
            return

        # ensure target has at least a Basis
        if not target.data.shape_keys:
            target.shape_key_add(name="Basis", from_mix=False)
        tgt_kb = target.data.shape_keys.key_blocks
        existing = {kb.name for kb in tgt_kb}
        for src_kb in sk_src.key_blocks:
            name = src_kb.name
            if name == "Basis" or name in existing:
                continue
            new_kb = target.shape_key_add(name=name, from_mix=False)
            # IMPORTANT: Newly created "unavailable" keys must start at 0.0.
            # (They may be driven/animated after transfer, but the base value should be neutral.)
            new_kb.value = 0.0
            # fast copy of all verts
            coords = [coord for vert in src_kb.data for coord in vert.co]
            new_kb.data.foreach_set("co", coords)
            # copy slider range, mask group, and mute state
            new_kb.slider_min   = src_kb.slider_min
            new_kb.slider_max   = src_kb.slider_max
            new_kb.vertex_group = src_kb.vertex_group
            new_kb.mute         = src_kb.mute

    def transfer_unavailable_attributes_data(self, source, target):
        """Transfer missing UV maps, color attributes, and generic mesh attributes."""
        if not source or not target or source.type != 'MESH' or target.type != 'MESH':
            return
        if len(source.data.vertices) != len(target.data.vertices):
            self.report({'WARNING'}, f"Cannot transfer unavailable attributes to '{target.name}': Vertex count does not match source.")
            return

        src_mesh = source.data
        tgt_mesh = target.data

        def copy_layer_data(src_layer, tgt_layer, prop_name):
            if src_layer is None or tgt_layer is None:
                return
            if not hasattr(src_layer, "data") or not hasattr(tgt_layer, "data"):
                return
            if len(src_layer.data) != len(tgt_layer.data):
                return
            for src_item, tgt_item in zip(src_layer.data, tgt_layer.data):
                try:
                    setattr(tgt_item, prop_name, getattr(src_item, prop_name))
                except Exception:
                    pass

        # UV maps
        tgt_uv_names = {uv.name for uv in tgt_mesh.uv_layers}
        for src_uv in src_mesh.uv_layers:
            if src_uv.name in tgt_uv_names:
                continue
            tgt_uv = tgt_mesh.uv_layers.new(name=src_uv.name, do_init=False)
            copy_layer_data(src_uv, tgt_uv, "uv")

        # Vertex color / color attributes
        src_color_attrs = getattr(src_mesh, "color_attributes", None)
        tgt_color_attrs = getattr(tgt_mesh, "color_attributes", None)
        if src_color_attrs is not None and tgt_color_attrs is not None:
            tgt_color_names = {attr.name for attr in tgt_color_attrs}
            for src_attr in src_color_attrs:
                if src_attr.name in tgt_color_names:
                    continue
                tgt_attr = tgt_color_attrs.new(name=src_attr.name, type=src_attr.data_type, domain=src_attr.domain)
                copy_layer_data(src_attr, tgt_attr, "color")

        # Generic geometry attributes
        src_attrs = getattr(src_mesh, "attributes", None)
        tgt_attrs = getattr(tgt_mesh, "attributes", None)
        if src_attrs is None or tgt_attrs is None:
            return

        tgt_attr_names = {attr.name for attr in tgt_attrs}
        data_field_map = {
            'FLOAT': 'value',
            'INT': 'value',
            'BOOLEAN': 'value',
            'FLOAT_VECTOR': 'vector',
            'FLOAT2': 'vector',
            'FLOAT_COLOR': 'color',
            'BYTE_COLOR': 'color',
        }

        for src_attr in src_attrs:
            if src_attr.name in tgt_attr_names:
                continue
            if src_attr.name in {"position", ".edge_verts", ".corner_vert", ".corner_edge"}:
                continue

            try:
                tgt_attr = tgt_attrs.new(name=src_attr.name, type=src_attr.data_type, domain=src_attr.domain)
            except Exception:
                continue

            data_prop = data_field_map.get(src_attr.data_type)
            if data_prop:
                copy_layer_data(src_attr, tgt_attr, data_prop)

    def transfer_unavailable_object_properties_data(self, source, target):
        """Transfer missing custom properties from source object to target object."""
        if not source or not target:
            return

        def parse_custom_prop_key(data_path):
            if not isinstance(data_path, str):
                return None
            if data_path.startswith('["') and data_path.endswith('"]') and len(data_path) > 4:
                return data_path[2:-2]
            return None

        def get_modifier_driver_custom_prop_keys(obj):
            keys = set()
            anim_data = getattr(obj, "animation_data", None)
            if not anim_data:
                return keys

            for fcurve in getattr(anim_data, "drivers", []):
                fcurve_path = getattr(fcurve, "data_path", "")
                if not isinstance(fcurve_path, str) or not fcurve_path.startswith('modifiers['):
                    continue

                driver = getattr(fcurve, "driver", None)
                if not driver:
                    continue

                for var in getattr(driver, "variables", []):
                    for tgt in getattr(var, "targets", []):
                        if getattr(tgt, "id", None) != obj:
                            continue
                        key = parse_custom_prop_key(getattr(tgt, "data_path", ""))
                        if key:
                            keys.add(key)

            return keys

        def safe_copy_val(value):
            try:
                return deepcopy(value)
            except Exception:
                if hasattr(value, "to_list"):
                    return value.to_list()
                try:
                    return type(value)(value)
                except Exception:
                    return value

        source_rna_ui = source.get("_RNA_UI", {})
        transfer_mode = getattr(self, "transfer_unavailable_object_properties_mode", 'ALL_UNAVAILABLE')
        if transfer_mode == 'USED_AS_MODIFIER_DRIVERS' and self.transfer_modifiers == 'NONE':
            return

        allowed_keys = None
        if transfer_mode == 'USED_AS_MODIFIER_DRIVERS':
            allowed_keys = get_modifier_driver_custom_prop_keys(source)

        for key in source.keys():
            key_lower = key.lower()
            if key == "_RNA_UI" or key in target.keys() or "pubic hair" in key_lower:
                continue
            if allowed_keys is not None and key not in allowed_keys:
                continue

            try:
                target[key] = safe_copy_val(source[key])
            except Exception:
                continue

            try:
                src_ui = source.id_properties_ui(key)
                meta = src_ui.as_dict()
                dst_ui = target.id_properties_ui(key)
                dst_ui.update(**meta)
            except Exception:
                if key in source_rna_ui:
                    if "_RNA_UI" not in target:
                        target["_RNA_UI"] = {}
                    target["_RNA_UI"][key] = {}
                    for attr, val in source_rna_ui[key].items():
                        target["_RNA_UI"][key][attr] = safe_copy_val(val)

            prop_path = f'["{key}"]'
            try:
                overridable = source.is_property_overridable_library(prop_path)
                target.property_overridable_library_set(prop_path, overridable)
            except Exception:
                pass

    def is_shapekey_animated(self, obj, shapekey):
        if not obj.data.shape_keys or not obj.data.shape_keys.animation_data:
            return False

        anim_data = obj.data.shape_keys.animation_data
        data_path = shapekey.path_from_id('value')

        # Check for drivers
        for driver in anim_data.drivers:
            if driver.data_path == data_path:
                return True

        # Check for keyframes on an action
        if anim_data.action:
            for fcurve in iter_fcurves_for_anim_data(anim_data):
                if fcurve.data_path == data_path:
                    return True
        
        return False

    def analyze_and_resolve_clashes(self, context, source_mesh, target_mesh):
        if not (source_mesh and target_mesh and source_mesh.data.shape_keys and target_mesh.data.shape_keys):
            return False

        source_kb = source_mesh.data.shape_keys.key_blocks
        target_kb = target_mesh.data.shape_keys.key_blocks
        
        clashes = []
        for sk_t in target_kb:
            if sk_t.name == 'Basis' or self.is_shapekey_animated(target_mesh, sk_t):
                continue

            sk_s = source_kb.get(sk_t.name)
            
            if sk_s:
                # Also skip if the source shapekey is animated
                if self.is_shapekey_animated(source_mesh, sk_s):
                    continue
                    
                if (sk_t.value != sk_s.value or
                    sk_t.slider_min != sk_s.slider_min or
                    sk_t.slider_max != sk_s.slider_max or
                    sk_t.vertex_group != sk_s.vertex_group):
                    clashes.append({'name': sk_t.name, 'clash_type': 'VALUE_MISMATCH'})
            else:
                clashes.append({'name': sk_t.name, 'clash_type': 'TARGET_ONLY'})

        if clashes:
            wm = context.window_manager
            wm.hhp_shapekey_clashes.clear()
            wm.hhp_shapekey_clash_source = source_mesh.name
            wm.hhp_shapekey_clash_target = target_mesh.name
            
            # Prioritize keys: Mouth first, then Head (case-insensitive)
            def is_head(name):
                n = name.lower()
                n2 = n.replace(" ", "")
                return ("head preset" in n) or ("char-head" in n2)

            mouth = [c for c in clashes if is_hhp_mouth_shape_key(c['name'])]
            head = [c for c in clashes if (not is_hhp_mouth_shape_key(c['name'])) and is_head(c['name'])]
            others = [c for c in clashes if (not is_hhp_mouth_shape_key(c['name'])) and (not is_head(c['name']))]
            ordered = mouth + head + others

            for clash_data in ordered:
                item = wm.hhp_shapekey_clashes.add()
                item.name = clash_data['name']
                item.clash_type = clash_data['clash_type']

            return True
        return False

def register():
    # --- Register Operators and Properties with guards just like Project Studio ---
    if not hasattr(bpy.types, "HHP_OT_shapekey_clash_resolver"):
        bpy.utils.register_class(HHP_OT_shapekey_clash_resolver)
    if not hasattr(bpy.types, "HHP_OT_shapekey_clash_set_all"):
        bpy.utils.register_class(HHP_OT_shapekey_clash_set_all)
    if not hasattr(bpy.types, "HHP_OT_shapekey_clash_set_selected"):
        bpy.utils.register_class(HHP_OT_shapekey_clash_set_selected)
    if not hasattr(bpy.types, "HHP_SHAPEKEY_UL_clash_list"):
        bpy.utils.register_class(HHP_SHAPEKEY_UL_clash_list)
    # PropertyGroup subclasses are never exposed on bpy.types, so this one guard
    # has to ask the class itself rather than the bpy.types namespace.
    if not HHP_ShapeKeyClashItem.is_registered:
        bpy.utils.register_class(HHP_ShapeKeyClashItem)

    bpy.utils.register_class(HHP_OT_bs_anim_transfer)

    # --- Register WindowManager properties (namespaced to avoid addon clashes) ---
    if not hasattr(bpy.types.WindowManager, "hhp_shapekey_clashes"):
        bpy.types.WindowManager.hhp_shapekey_clashes = CollectionProperty(type=HHP_ShapeKeyClashItem)
    if not hasattr(bpy.types.WindowManager, "hhp_shapekey_clash_source"):
        bpy.types.WindowManager.hhp_shapekey_clash_source = StringProperty()
    if not hasattr(bpy.types.WindowManager, "hhp_shapekey_clash_target"):
        bpy.types.WindowManager.hhp_shapekey_clash_target = StringProperty()
    if not hasattr(bpy.types.WindowManager, "hhp_shapekey_clash_active_index"):
        bpy.types.WindowManager.hhp_shapekey_clash_active_index = IntProperty(name="Active Shape Key Clash Index")


def unregister():
    # --- Unregister in reverse order ---
    # Remove the namespaced WindowManager properties first: hhp_shapekey_clashes is a
    # CollectionProperty of HHP_ShapeKeyClashItem, so that class cannot be unregistered
    # while the property still points at it.
    if hasattr(bpy.types.WindowManager, "hhp_shapekey_clashes"):
        del bpy.types.WindowManager.hhp_shapekey_clashes
    if hasattr(bpy.types.WindowManager, "hhp_shapekey_clash_source"):
        del bpy.types.WindowManager.hhp_shapekey_clash_source
    if hasattr(bpy.types.WindowManager, "hhp_shapekey_clash_target"):
        del bpy.types.WindowManager.hhp_shapekey_clash_target
    if hasattr(bpy.types.WindowManager, "hhp_shapekey_clash_active_index"):
        del bpy.types.WindowManager.hhp_shapekey_clash_active_index

    bpy.utils.unregister_class(HHP_OT_bs_anim_transfer)

    # Check before unregistering to prevent errors on reload. PropertyGroup subclasses
    # are never exposed on bpy.types, so that one guard asks the class itself.
    if hasattr(bpy.types, "HHP_OT_shapekey_clash_resolver"):
        bpy.utils.unregister_class(HHP_OT_shapekey_clash_resolver)
    if hasattr(bpy.types, "HHP_OT_shapekey_clash_set_all"):
        bpy.utils.unregister_class(HHP_OT_shapekey_clash_set_all)
    if hasattr(bpy.types, "HHP_OT_shapekey_clash_set_selected"):
        bpy.utils.unregister_class(HHP_OT_shapekey_clash_set_selected)
    if HHP_ShapeKeyClashItem.is_registered:
        bpy.utils.unregister_class(HHP_ShapeKeyClashItem)
    if hasattr(bpy.types, "HHP_SHAPEKEY_UL_clash_list"):
        bpy.utils.unregister_class(HHP_SHAPEKEY_UL_clash_list)
