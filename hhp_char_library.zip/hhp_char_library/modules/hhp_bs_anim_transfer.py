import bpy
from bpy.types import Operator, PropertyGroup, UIList
from bpy.props import BoolProperty, StringProperty, EnumProperty, CollectionProperty, IntProperty

ARMATURE_NAME_TOKEN = "Genesis8Female"
MESH_NAME_TOKEN = "Genesis8Female.Shape"


def is_hhp_armature(obj):
    return obj is not None and obj.type == 'ARMATURE' and ARMATURE_NAME_TOKEN in obj.name


def is_hhp_mesh(obj):
    return obj is not None and obj.type == 'MESH' and MESH_NAME_TOKEN in obj.name


def valid_armature_selection(context):
    if context is None:
        return False
    active = getattr(context, "active_object", None)
    if not is_hhp_armature(active):
        return False
    armatures = [obj for obj in getattr(context, "selected_objects", []) if obj.type == 'ARMATURE']
    if len(armatures) < 2:
        return False
    return all(is_hhp_armature(obj) for obj in armatures)


def valid_mesh_selection(context):
    if context is None:
        return False
    active = getattr(context, "active_object", None)
    if not is_hhp_mesh(active):
        return False
    meshes = [obj for obj in getattr(context, "selected_objects", []) if obj.type == 'MESH']
    if len(meshes) < 2:
        return False
    return all(is_hhp_mesh(obj) for obj in meshes)


def has_valid_hhp_selection(context):
    return valid_armature_selection(context) or valid_mesh_selection(context)

class SHAPEKEY_UL_clash_list(UIList):
    """UIList for displaying shape key clashes."""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # 'item' is a ShapeKeyClashItem from the collection.
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # Use split to create a 3-column layout with narrower middle column
            split = layout.split(factor=0.25, align=True)

            # --- Column 1: Source (property enum button to allow drag selection) ---
            col = split.column(align=True)
            col.prop_enum(item, "choice", 'SOURCE', text="", icon='TRIA_LEFT')

            # --- Column 2: Shape Key Name (Centered, narrower) ---
            split = split.split(factor=0.67, align=True)
            split.alignment = 'CENTER'
            split.label(text=item.name)

            # --- Column 3: Target (property enum button to allow drag selection) ---
            col = split.column(align=True)
            col.prop_enum(item, "choice", 'TARGET', text="", icon='TRIA_RIGHT')

class ShapeKeyClashItem(PropertyGroup):
    name: StringProperty(name="Shape Key Name")
    choice: EnumProperty(
        name="Choice",
        description="Choose whether to keep the source or target shape key data",
        items=[('SOURCE', 'Source', 'Keep source data', 'TRIA_LEFT', 0),
               ('TARGET', 'Target', 'Keep target data', 'TRIA_RIGHT', 1)],
        default='TARGET'
    )
    clash_type: StringProperty()

class WM_OT_shapekey_clash_set_selected(Operator):
    bl_idname = "wm.shapekey_clash_set_selected"
    bl_label = "Set Selected Shape Key Clashes"
    bl_description = "Set choice for all selected shape key clashes"
    bl_options = {'REGISTER'}
    
    choice: EnumProperty(
        name="Choice",
        items=[('SOURCE', 'Source', 'Set to Source'),
               ('TARGET', 'Target', 'Set to Target')],
        default='TARGET'
    )
    
    def execute(self, context):
        wm = context.window_manager
        
        # Apply choice to all selected items
        # Since UIList doesn't expose multi-selection easily, we'll apply to the active item
        # and provide separate "Set All" operations
        active_index = wm.shapekey_clash_active_index
        if 0 <= active_index < len(wm.shapekey_clashes):
            wm.shapekey_clashes[active_index].choice = self.choice
        
        return {'FINISHED'}

class WM_OT_shapekey_clash_set_all(Operator):
    bl_idname = "wm.shapekey_clash_set_all"
    bl_label = "Set All Shape Key Clashes"
    bl_description = "Set choice for all shape key clashes"
    bl_options = {'REGISTER'}
    
    choice: EnumProperty(
        name="Choice",
        items=[('SOURCE', 'Source', 'Set all to Source'),
               ('TARGET', 'Target', 'Set all to Target')],
        default='TARGET'
    )
    
    def execute(self, context):
        wm = context.window_manager
        
        # Apply choice to all items
        for item in wm.shapekey_clashes:
            item.choice = self.choice
        
        return {'FINISHED'}

class WM_OT_shapekey_clash_resolver(Operator):
    bl_idname = "wm.shapekey_clash_resolver"
    bl_label = "Resolve Shape Key Clashes"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        wm = context.window_manager
        return hasattr(wm, 'shapekey_clashes') and wm.shapekey_clashes

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        num_clashes = len(wm.shapekey_clashes)
        
        # Use a single column for left-justified text
        col = layout.column()
        col.label(text=f"Found {num_clashes} shape key clashes. Choose which version to keep.", icon='ERROR')
        col.label(text="For example, keep the source's mouth shape but use the target's feet.")
        col.label(text="Animated or driven keys are ignored as they are automatically updated.")
        col.label(text="Choosing 'Source' for a key the source doesn't have will set its value to 0.")
        
        layout.separator()

        # Header for the list, with centered labels matching the 3-column layout
        header = layout.row(align=True)
        split = header.split(factor=0.25, align=True)
        split.alignment = 'CENTER'
        split.label(text="Source")

        split = split.split(factor=0.67, align=True)
        split.alignment = 'CENTER'
        split.label(text="Shape Key", icon='SHAPEKEY_DATA')
        
        split.alignment = 'CENTER'
        split.label(text="Target")
        
        # The list itself with multi-selection enabled
        layout.template_list(
            "SHAPEKEY_UL_clash_list",
            "",
            wm, "shapekey_clashes",
            wm, "shapekey_clash_active_index",
            rows=8,
            maxrows=8,
            type='DEFAULT'
        )
        
        # Batch operation buttons
        layout.separator()
        layout.label(text="Batch Operations:")
        
        row = layout.row(align=True)
        op_source = row.operator("wm.shapekey_clash_set_all", text="Set All to Source", icon='TRIA_LEFT')
        op_source.choice = 'SOURCE'
        
        op_target = row.operator("wm.shapekey_clash_set_all", text="Set All to Target", icon='TRIA_RIGHT')
        op_target.choice = 'TARGET'

    def execute(self, context):
        wm = context.window_manager
        source_mesh = bpy.data.objects.get(wm.shapekey_clash_source)
        target_mesh = bpy.data.objects.get(wm.shapekey_clash_target)

        if not source_mesh or not target_mesh:
            self.report({'ERROR'}, "Source or target mesh not found")
            return {'CANCELLED'}

        if not target_mesh.data.shape_keys:
            return {'CANCELLED'}

        target_kb = target_mesh.data.shape_keys.key_blocks

        for clash in wm.shapekey_clashes:
            if clash.choice == 'SOURCE':
                target_sk = target_kb.get(clash.name)
                if not target_sk:
                    continue

                if clash.clash_type == 'TARGET_ONLY':
                    target_sk.value = 0.0
                else: 
                    if source_mesh.data.shape_keys:
                        source_sk = source_mesh.data.shape_keys.key_blocks.get(clash.name)
                        if source_sk:
                            target_sk.value = source_sk.value
                            target_sk.slider_min = source_sk.slider_min
                            target_sk.slider_max = source_sk.slider_max
                            target_sk.vertex_group = source_sk.vertex_group
        
        wm.shapekey_clashes.clear()

        self.report({'INFO'}, "Clashes resolved.")
        return {'FINISHED'}

class ARMATURE_OT_bs_anim_transfer(Operator):
    bl_idname = "armature.bs_anim_transfer"
    bl_label = "Animation Transfer +"
    bl_description = "Transfer animation data from active armature to selected armatures, or from active mesh's armature to selected meshes' armatures"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return has_valid_hhp_selection(context)

    # Add selection mode property to track whether we're using mesh or armature selection
    selection_mode: EnumProperty(
        name="Selection Mode",
        items=[
            ('ARMATURE', 'Armature', 'Using armature selection'),
            ('MESH', 'Mesh', 'Using mesh selection')
        ],
        default='ARMATURE'
    )

    auto_find_mesh: BoolProperty(
        name="Auto Find Character Mesh",
        description="Automatically find and select the best matching mesh for each armature",
        default=True
    )

    source_mesh: StringProperty(
        name="Source Mesh",
        description="Source mesh used for mesh based transfers"
    )

    target_mesh: StringProperty(
        name="Target Mesh",
        description="Target mesh used for mesh based transfers"
    )

    transfer_object_animation: BoolProperty(
        name="Transfer object animation",
        description="Transfer object animation data between meshes",
        default=True
    )

    transfer_shapekeys: BoolProperty(
        name="Transfer Shapekey Animation",
        description="Transfer shape key animation data between meshes",
        default=True
    )

    transfer_unavailable_data: BoolProperty(
        name="Transfer unavailable shapekeys & vtx groups",
        description="Copy missing shape keys and vertex groups to ensure animations work correctly",
        default=True
    )

    shapekey_data_clash_analyzer: BoolProperty(
        name="Launch Shapekey clash analyzer after transfer",
        description="[ADVANCED] After transfer, analyze and resolve clashes for non-animated and non-driver shape keys",
        default=False
    )

    transfer_constraints: EnumProperty(
        name="Constraints",
        description="Choose how to transfer pose bone constraints",
        items=[
            ('UNAVAILABLE', "Unavailable Only", "Only transfer constraints that don't exist on target bones"),
            ('FULL', "Full (Overwrite)", "Transfer all constraints, overwriting existing ones"),
            ('NONE', "None", "Do not transfer constraints"),
        ],
        default='UNAVAILABLE'
    )

    self_reference: BoolProperty(
        name="Self Reference",
        description="If enabled, constraints referencing the source armature will target the target armature in UNAVAILABLE mode",
        default=True
    )

    transfer_modifiers: EnumProperty(
        name="Modifiers",
        description="Choose how to transfer mesh modifiers",
        items=[
            ('UNAVAILABLE', "Unavailable Only", "Only transfer modifiers that don't exist on target mesh"),
            ('FULL', "Full (Overwrite)", "Transfer all modifiers except Armature modifiers"),
            ('NONE', "None", "Do not transfer modifiers"),
        ],
        default='NONE'
    )

    update_binds: BoolProperty(
        name="Update Binds",
        description="Rebind mesh deform, surface deform, and corrective smooth modifiers on target meshes",
        default=False
    )

    disable_source_collection: BoolProperty(
        name="Disable collection of source armature after transfer",
        description="Disable viewport and render visibility of the source armature's parent collection after transfer",
        default=True
    )

    def draw(self, context):
        layout = self.layout
        
        # Show different UI based on selection mode
        if self.selection_mode == 'MESH':
            # Mesh selection mode UI
            layout.label(text="Source and target for mesh based transfers:")
            layout.label(text="Using selected meshes as targets", icon='INFO')
            layout.label(text="and active mesh as source")
        else:
            # Armature selection mode UI (existing functionality)
            layout.label(text="Source and target for mesh based transfers:")
            
            # Auto find mesh checkbox
            layout.prop(self, "auto_find_mesh")
            
            # Mesh selection fields (greyed out if auto find is enabled)
            row = layout.row()
            row.enabled = not self.auto_find_mesh
            row.prop_search(self, "source_mesh", context.scene, "objects", text="Source", 
                           results_are_suggestions=True)
            
            row = layout.row()
            row.enabled = not self.auto_find_mesh
            row.prop_search(self, "target_mesh", context.scene, "objects", text="Target",
                           results_are_suggestions=True)

        # Transfer options
        layout.separator()
        
        # Object animation transfer option
        layout.prop(self, "transfer_object_animation")
        
        # Shapekey transfer option
        layout.prop(self, "transfer_shapekeys")
        
        # Transfer unavailable data checkbox (greyed out unless transfer_shapekeys is enabled)
        row = layout.row()
        row.enabled = self.transfer_shapekeys
        row.prop(self, "transfer_unavailable_data")
        
        row = layout.row(align=True)
        row.enabled = self.transfer_shapekeys and self.transfer_unavailable_data
        # Use a toggle button for the checkbox to properly handle the icon
        row.prop(self, "shapekey_data_clash_analyzer", text="", toggle=True, icon='MOD_DATA_TRANSFER')
        row.label(text="Launch Shapekey clash analyzer after transfer")
        
        # Constraints transfer mode
        layout.label(text="Constraints:")
        row = layout.row()
        row.prop(self, "transfer_constraints", expand=True)
        
        row = layout.row()
        row.enabled = (self.transfer_constraints == 'UNAVAILABLE')
        row.prop(self, "self_reference")
        
        # Modifiers transfer mode
        layout.label(text="Modifiers:")
        row = layout.row()
        row.prop(self, "transfer_modifiers", expand=True)
        
        # Update binds checkbox (greyed out unless transfer_modifiers is FULL)
        row = layout.row()
        row.enabled = (self.transfer_modifiers == 'FULL')
        row.prop(self, "update_binds")

        # Add the new checkbox
        layout.prop(self, "disable_source_collection")

    def invoke(self, context, event):
        # Check what type of objects are selected
        selected_armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
        selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        # Determine selection mode based on what's selected
        if selected_meshes and not selected_armatures:
            # Pure mesh selection
            self.selection_mode = 'MESH'
            if len(selected_meshes) < 2:
                self.report({'ERROR'}, "A minimum of two meshes must be selected")
                return {'CANCELLED'}

            active_mesh = context.active_object if context.active_object and context.active_object.type == 'MESH' else None
            if not active_mesh or MESH_NAME_TOKEN not in active_mesh.name:
                self.report({'ERROR'}, "Active mesh must be an HHP mesh containing 'Genesis8Female.Shape' in its name")
                return {'CANCELLED'}

            for mesh in selected_meshes:
                if MESH_NAME_TOKEN not in mesh.name:
                    self.report({'ERROR'}, f"Mesh '{mesh.name}' is not an HHP mesh (requires 'Genesis8Female.Shape' in the name)")
                    return {'CANCELLED'}
            
            # Check if meshes have armature modifiers
            for mesh in selected_meshes:
                has_armature = any(mod.type == 'ARMATURE' for mod in mesh.modifiers)
                if not has_armature:
                    self.report({'ERROR'}, f"Mesh '{mesh.name}' does not have an armature modifier")
                    return {'CANCELLED'}
                    
        elif selected_armatures and not selected_meshes:
            # Pure armature selection
            self.selection_mode = 'ARMATURE'
            if len(selected_armatures) < 2:
                self.report({'ERROR'}, "A minimum of two armatures must be selected")
                return {'CANCELLED'}

            active_armature = context.active_object if context.active_object and context.active_object.type == 'ARMATURE' else None
            if not active_armature or ARMATURE_NAME_TOKEN not in active_armature.name:
                self.report({'ERROR'}, "Active armature must contain 'Genesis8Female' in its name")
                return {'CANCELLED'}

            for armature in selected_armatures:
                if ARMATURE_NAME_TOKEN not in armature.name:
                    self.report({'ERROR'}, f"Armature '{armature.name}' must contain 'Genesis8Female' in its name")
                    return {'CANCELLED'}
        else:
            # Mixed selection or no valid selection
            self.report({'ERROR'}, "Select either armatures only or meshes only, not both")
            return {'CANCELLED'}

        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        # Store original selection and active object
        original_selection = context.selected_objects.copy()
        original_active = context.active_object

        if not original_active or not original_selection:
            self.report({'ERROR'}, "No active object or no selection")
            return {'CANCELLED'}

        # Handle mesh selection mode
        if self.selection_mode == 'MESH':
            if not valid_mesh_selection(context):
                self.report({'ERROR'}, "Select at least two HHP meshes containing 'Genesis8Female.Shape' in their names")
                return {'CANCELLED'}
            return self.execute_mesh_mode(context, original_selection, original_active)

        if not valid_armature_selection(context):
            self.report({'ERROR'}, "Select at least two HHP armatures containing 'Genesis8Female' in their names")
            return {'CANCELLED'}

        # 0. Copy pose (new step)
        self.copy_pose(context)

        # 1. Copy transformations
        self.copy_transformations(context)
        
        # 2. Enable NLA stack evaluation
        self.enable_nla_stack()
        
        # 3. Link animation data
        bpy.ops.object.make_links_data(type='ANIMATION')
        
        # 4. Copy constraints (if enabled)
        if self.transfer_constraints != 'NONE':
            self.copy_constraints(context)
        
        # 5. Set pose position
        self.set_pose_position()
        
        # 6. Handle mesh selection and transfers
        if self.auto_find_mesh:
            self.select_best_scoring_meshes_for_selected_armatures(context)
            
            active_mesh = context.active_object
            if active_mesh and active_mesh.type == 'MESH':
                target_meshes = [obj for obj in context.selected_objects if obj != active_mesh and obj.type == 'MESH']
                
                # Transfer object animation if enabled
                if self.transfer_object_animation:
                    # Store original selection and active object
                    original_selection = context.selected_objects.copy()
                    original_active = context.active_object
                    
                    # Select active mesh and target meshes for animation transfer
                    bpy.ops.object.select_all(action='DESELECT')
                    active_mesh.select_set(True)
                    for target in target_meshes:
                        target.select_set(True)
                    context.view_layer.objects.active = active_mesh
                    
                    # Transfer object animation data
                    bpy.ops.object.make_links_data(type='ANIMATION')
                    
                    # Restore original selection
                    for obj in context.view_layer.objects:
                        obj.select_set(obj in original_selection)
                    context.view_layer.objects.active = original_active
                
                # Transfer shape keys if enabled
                if self.transfer_shapekeys:
                    for target in target_meshes:
                        # Transfer unavailable shape keys and vertex groups first if enabled
                        if self.transfer_unavailable_data:
                            self.transfer_vertex_groups(active_mesh, target)
                            self.transfer_shape_keys(active_mesh, target)
                        self.copy_shapekey_nla_tracks(active_mesh, target)
                        
                        # Analyze and resolve clashes for this target
                        if self.shapekey_data_clash_analyzer:
                            if self.analyze_and_resolve_clashes(context, active_mesh, target):
                                bpy.ops.wm.shapekey_clash_resolver('INVOKE_DEFAULT')
                
                # Transfer modifiers if enabled
                if self.transfer_modifiers != 'NONE':
                    self.copy_modifiers_to_selected(active_mesh, target_meshes)
        else:
            source = bpy.data.objects.get(self.source_mesh)
            target = bpy.data.objects.get(self.target_mesh)
            if source and target:
                # Transfer object animation if enabled
                if self.transfer_object_animation:
                    # Store original selection and active object
                    original_selection = context.selected_objects.copy()
                    original_active = context.active_object
                    
                    # Select source and target meshes for animation transfer
                    bpy.ops.object.select_all(action='DESELECT')
                    source.select_set(True)
                    target.select_set(True)
                    context.view_layer.objects.active = source
                    
                    # Transfer object animation data
                    bpy.ops.object.make_links_data(type='ANIMATION')
                    
                    # Restore original selection
                    for obj in context.view_layer.objects:
                        obj.select_set(obj in original_selection)
                    context.view_layer.objects.active = original_active
                
                if self.transfer_shapekeys:
                    # Transfer unavailable shape keys and vertex groups first if enabled
                    if self.transfer_unavailable_data:
                        self.transfer_vertex_groups(source, target)
                        self.transfer_shape_keys(source, target)
                    self.copy_shapekey_nla_tracks(source, target)

                    # Analyze and resolve clashes for this target
                    if self.shapekey_data_clash_analyzer:
                        if self.analyze_and_resolve_clashes(context, source, target):
                            bpy.ops.wm.shapekey_clash_resolver('INVOKE_DEFAULT')

                if self.transfer_modifiers != 'NONE':
                    self.copy_modifiers_to_selected(source, [target])

        # 7. Analyze and resolve shape key clashes (This block is now handled inside the loops above)
        # if self.shapekey_data_clash_analyzer and self.transfer_shapekeys and self.transfer_unavailable_data:
        #     if self.auto_find_mesh:
        #         # Active object is the source armature
        #         source_mesh = self.get_best_scoring_mesh_for_armature(original_active)
        #         target_armatures = [obj for obj in original_selection if obj.type == 'ARMATURE' and obj != original_active]
                
        #         for target_armature in target_armatures:
        #             target_mesh = self.get_best_scoring_mesh_for_armature(target_armature)
        #             if self.analyze_and_resolve_clashes(context, source_mesh, target_mesh):
        #                 bpy.ops.wm.shapekey_clash_resolver('INVOKE_DEFAULT')
        #                 # This will pop up for each target with clashes.

        #     else: # Manual mode
        #         source = bpy.data.objects.get(self.source_mesh)
        #         target = bpy.data.objects.get(self.target_mesh)
        #         if self.analyze_and_resolve_clashes(context, source, target):
        #             bpy.ops.wm.shapekey_clash_resolver('INVOKE_DEFAULT')

        # Handle disabling source collection if enabled
        if self.disable_source_collection:
            source_armature = original_active # Use original_active to be safe
            if source_armature:
                top_collection = None
                for col in context.scene.collection.children:
                    if self.collection_contains_object(col, source_armature):
                        top_collection = col
                        break
                if top_collection:
                    top_collection.hide_viewport = True
                    top_collection.hide_render = True

        return {'FINISHED'}

    def execute_mesh_mode(self, context, original_selection, original_active):
        """Execute transfer in mesh selection mode"""
        # Get selected meshes and active mesh
        selected_meshes = [obj for obj in original_selection if obj.type == 'MESH']
        active_mesh = original_active if original_active.type == 'MESH' else None
        
        if not active_mesh:
            self.report({'ERROR'}, "Active object must be a mesh in mesh selection mode")
            return {'CANCELLED'}
        
        # Find armatures for meshes
        def get_armature_from_mesh(mesh):
            for mod in mesh.modifiers:
                if mod.type == 'ARMATURE' and mod.object:
                    return mod.object
            return None
        
        source_armature = get_armature_from_mesh(active_mesh)
        if not source_armature:
            self.report({'ERROR'}, f"Active mesh '{active_mesh.name}' does not have an armature modifier")
            return {'CANCELLED'}
        
        target_armatures = []
        target_meshes = [mesh for mesh in selected_meshes if mesh != active_mesh]
        
        for mesh in target_meshes:
            armature = get_armature_from_mesh(mesh)
            if not armature:
                self.report({'ERROR'}, f"Mesh '{mesh.name}' does not have an armature modifier")
                return {'CANCELLED'}
            target_armatures.append(armature)
        
        # Set up armature selection and make source armature active
        bpy.ops.object.select_all(action='DESELECT')
        source_armature.select_set(True)
        for armature in target_armatures:
            armature.select_set(True)
        context.view_layer.objects.active = source_armature
        
        # Store original property values to restore later
        original_auto_find = self.auto_find_mesh
        original_source_mesh = self.source_mesh
        original_target_mesh = self.target_mesh
        
        # Now execute the standard armature transfer logic
        # 0. Copy pose
        self.copy_pose(context)

        # 1. Copy transformations
        self.copy_transformations(context)
        
        # 2. Enable NLA stack evaluation
        self.enable_nla_stack()
        
        # 3. Link animation data
        bpy.ops.object.make_links_data(type='ANIMATION')
        
        # 4. Copy constraints (if enabled)
        if self.transfer_constraints != 'NONE':
            self.copy_constraints(context)
        
        # 5. Set pose position
        self.set_pose_position()
        
        # 6. Handle mesh transfers for each target
        # Transfer object animation if enabled
        if self.transfer_object_animation:
            # Store original selection and active object
            original_selection = context.selected_objects.copy()
            original_active = context.active_object
            
            # Select active mesh and target meshes for animation transfer
            bpy.ops.object.select_all(action='DESELECT')
            active_mesh.select_set(True)
            for target in target_meshes:
                target.select_set(True)
            context.view_layer.objects.active = active_mesh
            
            # Transfer object animation data
            bpy.ops.object.make_links_data(type='ANIMATION')
            
            # Restore original selection
            for obj in context.view_layer.objects:
                obj.select_set(obj in original_selection)
            context.view_layer.objects.active = original_active
        
        for target_mesh in target_meshes:
            # Transfer shape keys if enabled
            if self.transfer_shapekeys:
                # Transfer unavailable shape keys and vertex groups first if enabled
                if self.transfer_unavailable_data:
                    self.transfer_vertex_groups(active_mesh, target_mesh)
                    self.transfer_shape_keys(active_mesh, target_mesh)
                self.copy_shapekey_nla_tracks(active_mesh, target_mesh)
            
            # Transfer modifiers if enabled
            if self.transfer_modifiers != 'NONE':
                self.copy_modifiers_to_selected(active_mesh, [target_mesh])

        # 7. Analyze and resolve shape key clashes
        if self.shapekey_data_clash_analyzer and self.transfer_shapekeys and self.transfer_unavailable_data:
            for target_mesh in target_meshes:
                if self.analyze_and_resolve_clashes(context, active_mesh, target_mesh):
                    bpy.ops.wm.shapekey_clash_resolver('INVOKE_DEFAULT')
                    # This will pop up for each target with clashes

        # Handle disabling source collection if enabled
        if self.disable_source_collection:
            if source_armature:
                top_collection = None
                for col in context.scene.collection.children:
                    if self.collection_contains_object(col, source_armature):
                        top_collection = col
                        break
                if top_collection:
                    top_collection.hide_viewport = True
                    top_collection.hide_render = True

        # Restore original property values so UI is not affected
        self.auto_find_mesh = original_auto_find
        self.source_mesh = original_source_mesh
        self.target_mesh = original_target_mesh

        return {'FINISHED'}

    def copy_pose(self, context):
        source_armature = context.active_object
        if not source_armature or source_armature.type != 'ARMATURE':
            return
            
        for target in context.selected_objects:
            if target != source_armature and target.type == 'ARMATURE':
                # Copy pose from source to target
                for bone_name, source_bone in source_armature.pose.bones.items():
                    if bone_name in target.pose.bones:
                        target_bone = target.pose.bones[bone_name]
                        target_bone.matrix = source_bone.matrix.copy()
                        target_bone.rotation_quaternion = source_bone.rotation_quaternion.copy()
                        target_bone.rotation_euler = source_bone.rotation_euler.copy()
                        target_bone.scale = source_bone.scale.copy()
                        target_bone.location = source_bone.location.copy()

    def copy_transformations(self, context):
        active_obj = context.active_object
        if active_obj is None or len(context.selected_objects) <= 1:
            self.report({'WARNING'}, "Please select an active object and at least one other object.")
            return

        for obj in context.selected_objects:
            if obj == active_obj:
                continue
            obj.location = active_obj.location.copy()
            obj.rotation_euler = active_obj.rotation_euler.copy()
            obj.scale = active_obj.scale.copy()

    def enable_nla_stack(self):
        active_object = bpy.context.view_layer.objects.active
        for obj in bpy.context.selected_objects:
            if obj != active_object and obj.type == 'ARMATURE':
                if obj.animation_data is None:
                    obj.animation_data_create()
                obj.animation_data.use_nla = True

    def copy_constraints(self, context):
        original_selection = context.selected_objects.copy()
        original_active = context.view_layer.objects.active
        bpy.ops.object.mode_set(mode='OBJECT')
        source_armature = original_active
        
        if source_armature.type != 'ARMATURE':
            self.report({'WARNING'}, "Source is not an armature. Skipping.")
            return

        target_armatures = [obj for obj in original_selection if obj != source_armature]

        for target_armature in target_armatures:
            if target_armature.type != 'ARMATURE':
                self.report({'INFO'}, f"Target {target_armature.name} is not an armature. Skipping.")
                continue

            context.view_layer.objects.active = target_armature
            bpy.ops.object.mode_set(mode='POSE')

            for bone_name, source_bone in source_armature.pose.bones.items():
                if bone_name in target_armature.pose.bones:
                    target_bone = target_armature.pose.bones[bone_name]
                    
                    # In FULL mode, remove existing constraints first
                    if self.transfer_constraints == 'FULL':
                        for c in target_bone.constraints:
                            target_bone.constraints.remove(c)
                    
                    for source_constraint in source_bone.constraints:
                        # In UNAVAILABLE mode, skip if constraint already exists
                        if self.transfer_constraints == 'UNAVAILABLE':
                            if any(c.type == source_constraint.type and c.name == source_constraint.name 
                                   for c in target_bone.constraints):
                                continue

                        new_constraint = target_bone.constraints.new(type=source_constraint.type)
                        new_constraint.name = source_constraint.name
                        for attr in dir(source_constraint):
                            try:
                                if not attr.startswith("_") and hasattr(new_constraint, attr):
                                    setattr(new_constraint, attr, getattr(source_constraint, attr))
                            except Exception as e:
                                print(f"Could not copy attribute {attr} due to: {e}")
                        
                        # Handle self reference: in UNAVAILABLE mode with self_reference enabled,
                        # if the source constraint's target is the source armature, then set the new constraint's target
                        # to the target armature
                        if self.transfer_constraints == 'UNAVAILABLE' and self.self_reference:
                            if hasattr(source_constraint, 'target') and source_constraint.target == source_armature:
                                new_constraint.target = target_armature

            bpy.ops.object.mode_set(mode='OBJECT')

        for obj in context.view_layer.objects:
            obj.select_set(obj in original_selection)
        context.view_layer.objects.active = original_active

    def set_pose_position(self):
        for obj in bpy.context.scene.objects:
            if obj.type == 'ARMATURE':
                obj.data.pose_position = 'POSE'
        bpy.context.view_layer.update()

    def score_by_attribute_descending(self, values):
        scores = {}
        n = len(values)
        if n == 1:
            scores[0] = 1.0
            return scores
        
        step = 1.0 / (n - 1)
        for i in range(n):
            scores[i] = 1.0 - (i * step)
        return scores

    def get_best_scoring_mesh_for_armature(self, armature_obj):
        candidates = []
        for obj in bpy.data.objects:
            if (obj.type == 'MESH' and 
                obj.visible_get() and 
                obj.display_type != 'WIRE' and 
                not obj.hide_render):
                for mod in obj.modifiers:
                    if mod.type == 'ARMATURE' and mod.object == armature_obj:
                        longest_dim = max(obj.dimensions.x, obj.dimensions.y, obj.dimensions.z)
                        modifier_count = len(obj.modifiers)
                        bounding_box_volume = obj.dimensions.x * obj.dimensions.y * obj.dimensions.z
                        candidates.append((obj, longest_dim, modifier_count, bounding_box_volume))
                        break

        if not candidates:
            return None

        sorted_by_dim = sorted(candidates, key=lambda c: c[1], reverse=True)
        dim_ranks = self.score_by_attribute_descending([c[1] for c in sorted_by_dim])

        sorted_by_mod_count = sorted(candidates, key=lambda c: c[2], reverse=True)
        mod_count_ranks = self.score_by_attribute_descending([c[2] for c in sorted_by_mod_count])

        sorted_by_volume = sorted(candidates, key=lambda c: c[3], reverse=True)
        volume_ranks = self.score_by_attribute_descending([c[3] for c in sorted_by_volume])

        final_scores = {}

        for i, c in enumerate(sorted_by_dim):
            obj = c[0]
            final_scores[obj] = {
                "dim": dim_ranks[i],
                "mod": 0.0,
                "vol": 0.0
            }

        for i, c in enumerate(sorted_by_mod_count):
            obj = c[0]
            if obj not in final_scores:
                final_scores[obj] = {"dim": 0.0, "mod": 0.0, "vol": 0.0}
            final_scores[obj]["mod"] = mod_count_ranks[i]

        for i, c in enumerate(sorted_by_volume):
            obj = c[0]
            if obj not in final_scores:
                final_scores[obj] = {"dim": 0.0, "mod": 0.0, "vol": 0.0}
            final_scores[obj]["vol"] = volume_ranks[i]

        best_obj = None
        best_score = float('-inf')

        for obj, ranks in final_scores.items():
            total_score = ranks["dim"] + ranks["mod"] + ranks["vol"]
            if total_score > best_score:
                best_score = total_score
                best_obj = obj

        return best_obj

    def auto_find_and_transfer_shapekeys(self, context):
        selected_armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
        active_armature = context.active_object if context.active_object in selected_armatures else None

        best_mesh_map = {}
        for armature in selected_armatures:
            best_mesh_map[armature] = self.get_best_scoring_mesh_for_armature(armature)

        if active_armature:
            source_mesh = best_mesh_map.get(active_armature)
            if source_mesh:
                for armature in selected_armatures:
                    if armature != active_armature:
                        target_mesh = best_mesh_map.get(armature)
                        if target_mesh:
                            self.copy_shapekey_nla_tracks(source_mesh, target_mesh)

    def copy_shapekey_nla_tracks(self, source, target):
        if source.data.shape_keys:
            if not target.data.shape_keys:
                self.report({'WARNING'}, f"Target object '{target.name}' does not have shape keys.")
                return

            if not target.data.shape_keys.animation_data:
                target.data.shape_keys.animation_data_create()

            source_animation_data = source.data.shape_keys.animation_data

            if source_animation_data:
                # Clear existing NLA tracks if any
                while target.data.shape_keys.animation_data.nla_tracks:
                    target.data.shape_keys.animation_data.nla_tracks.remove(target.data.shape_keys.animation_data.nla_tracks[0])

                if source_animation_data.nla_tracks:
                    for src_track in source_animation_data.nla_tracks:
                        new_track = target.data.shape_keys.animation_data.nla_tracks.new()
                        new_track.name = src_track.name
                        
                        # Calculate total length of all strips
                        max_end = 0
                        for src_strip in src_track.strips:
                            strip_length = int(src_strip.frame_end - src_strip.frame_start)
                            new_action = src_strip.action.copy()
                            new_action.use_fake_user = True
                            
                            # Place new strip after the last one
                            new_strip = new_track.strips.new(
                                name=src_strip.name, 
                                start=int(max_end + 1),  # Convert to integer
                                action=new_action
                            )
                            
                            # Copy strip properties
                            new_strip.frame_start = int(src_strip.frame_start)
                            new_strip.frame_end = int(src_strip.frame_end)
                            new_strip.blend_type = src_strip.blend_type
                            new_strip.use_reverse = src_strip.use_reverse
                            new_strip.use_auto_blend = src_strip.use_auto_blend
                            new_strip.blend_in = src_strip.blend_in
                            new_strip.blend_out = src_strip.blend_out
                            new_strip.mute = src_strip.mute
                            
                            max_end = new_strip.frame_end
                            
                elif source_animation_data.action:
                    new_action = source_animation_data.action.copy()
                    new_action.use_fake_user = True
                    target.data.shape_keys.animation_data.action = new_action

    def select_best_scoring_meshes_for_selected_armatures(self, context):
        """
        For each selected Armature, determine which Mesh wins by the combined
        sum of ranks for (longest axis, number of modifiers, bounding box volume).
        Select those winning meshes, and if the active object is an Armature,
        make its winning mesh the new active object.
        """
        selected_objs = context.selected_objects
        active_obj = context.active_object

        # Filter the selection to only Armatures
        selected_armatures = [obj for obj in selected_objs if obj.type == 'ARMATURE']

        # Identify the active Armature (if the active object is one)
        active_armature = active_obj if active_obj in selected_armatures else None

        # Gather the "best scoring" mesh for each selected Armature
        best_mesh_map = {}
        for armature in selected_armatures:
            best_mesh_map[armature] = self.get_best_scoring_mesh_for_armature(armature)

        # Deselect everything
        bpy.ops.object.select_all(action='DESELECT')

        # Select the winning mesh for each Armature (if any)
        for armature in selected_armatures:
            mesh_obj = best_mesh_map[armature]
            if mesh_obj is not None:
                mesh_obj.select_set(True)

        # If there's an active Armature, make its best mesh the active object
        if active_armature is not None:
            active_mesh = best_mesh_map[active_armature]
            if active_mesh is not None:
                context.view_layer.objects.active = active_mesh
                active_mesh.select_set(True)

    def rebind_modifiers(self, obj):
        # Store original active object
        original_active = bpy.context.view_layer.objects.active
        
        # Make the object active
        bpy.context.view_layer.objects.active = obj
        
        # First unbind
        for modifier in obj.modifiers:
            if modifier.show_viewport and modifier.show_render:
                if modifier.type == 'MESH_DEFORM' and modifier.is_bound:
                    bpy.ops.object.meshdeform_bind(modifier=modifier.name)
                elif modifier.type == 'SURFACE_DEFORM' and modifier.is_bound:
                    bpy.ops.object.surfacedeform_bind(modifier=modifier.name)
                elif modifier.type == 'CORRECTIVE_SMOOTH' and modifier.is_bind:
                    bpy.ops.object.correctivesmooth_bind(modifier=modifier.name)
        
        # Then rebind
        for modifier in obj.modifiers:
            if modifier.show_viewport and modifier.show_render:
                if modifier.type == 'MESH_DEFORM' and not modifier.is_bound:
                    bpy.ops.object.meshdeform_bind(modifier=modifier.name)
                elif modifier.type == 'SURFACE_DEFORM' and not modifier.is_bound:
                    bpy.ops.object.surfacedeform_bind(modifier=modifier.name)
                elif modifier.type == 'CORRECTIVE_SMOOTH' and not modifier.is_bind:
                    bpy.ops.object.correctivesmooth_bind(modifier=modifier.name)
        
        # Restore original active object
        bpy.context.view_layer.objects.active = original_active

    def copy_modifiers_to_selected(self, source_obj, target_objs):
        if not source_obj or source_obj.type != 'MESH' or not source_obj.modifiers:
            return

        # Use the source's entire modifier list as the template for order.
        source_modifiers_template = list(source_obj.modifiers)

        def find_modifier(obj, name, mod_type):
            return next((mod for mod in obj.modifiers if mod.name == name and mod.type == mod_type), None)

        for obj in target_objs:
            if obj.type != 'MESH':
                continue
            
            # --- FULL Mode ---
            if self.transfer_modifiers == 'FULL':
                # Nuke and pave: Remove all existing modifiers from the target
                obj.modifiers.clear()

                # Clone the entire modifier stack from the source
                for source_mod in source_modifiers_template:
                    new_mod = obj.modifiers.new(name=source_mod.name, type=source_mod.type)
                    for prop in dir(source_mod):
                        if not prop.startswith("_") and not callable(getattr(source_mod, prop)):
                            try: setattr(new_mod, prop, getattr(source_mod, prop))
                            except AttributeError: pass
                
                # Rebind if requested
                if self.update_binds:
                    original_frame = bpy.context.scene.frame_current
                    bpy.context.scene.frame_set(bpy.context.scene.frame_start)
                    self.rebind_modifiers(obj)
                    bpy.context.scene.frame_set(original_frame)

            # --- UNAVAILABLE Mode ---
            elif self.transfer_modifiers == 'UNAVAILABLE':
                copied_any = False
                # First, copy any missing modifiers
                for source_mod in source_modifiers_template:
                    if not find_modifier(obj, source_mod.name, source_mod.type):
                        copied_any = True
                        new_mod = obj.modifiers.new(name=source_mod.name, type=source_mod.type)
                        for prop in dir(source_mod):
                            if not prop.startswith("_") and not callable(getattr(source_mod, prop)):
                                try: setattr(new_mod, prop, getattr(source_mod, prop))
                                except AttributeError: pass
                
                # Now, only if we added something, reorder the entire stack
                if copied_any:
                    self.reorder_modifiers(obj, source_modifiers_template)

    def reorder_modifiers(self, obj, source_order_template):
        """Reorders modifiers on obj to match the source_order_template,
           appending any modifiers not in the template to the end."""
           
        current_modifiers = obj.modifiers[:]
        new_order = []

        # 1. Build the new order list: start with modifiers from the template
        for source_mod in source_order_template:
            target_mod = next((m for m in current_modifiers if m.name == source_mod.name and m.type == source_mod.type), None)
            if target_mod:
                new_order.append(target_mod)
        
        # 2. Add any remaining modifiers from the target that weren't in the template
        for mod in current_modifiers:
            if mod not in new_order:
                new_order.append(mod)

        # 3. Apply the new order by moving modifiers to their final positions
        for i, mod in enumerate(new_order):
            # Find the current index of the modifier we want to move
            from_index = -1
            for idx, m in enumerate(obj.modifiers):
                if m == mod:
                    from_index = idx
                    break
            
            # Move it to the correct position `i` if it's not already there
            if from_index != -1 and from_index != i:
                obj.modifiers.move(from_index, i)

    def collection_contains_object(self, collection, obj):
        """Recursively determine if the given collection or any of its children contains the object."""
        if obj.name in collection.objects:
            return True
        for child in collection.children:
            if self.collection_contains_object(child, obj):
                return True
        return False

    def transfer_vertex_groups(self, source, target):
        """Transfer missing vertex groups from source to target mesh"""
        if not source.vertex_groups:
            return
        existing = {vg.name for vg in target.vertex_groups}
        for src_vg in source.vertex_groups:
            if src_vg.name in existing:
                continue
            tgt_vg = target.vertex_groups.new(name=src_vg.name)
            # only non-zero weights; uses src_vg.weight() under the hood
            for v in source.data.vertices:
                try:
                    w = src_vg.weight(v.index)
                    if w:
                        tgt_vg.add([v.index], w, 'REPLACE')
                except RuntimeError:
                    # vertex not in group → skip
                    pass

    def transfer_shape_keys(self, source, target):
        """Transfer missing shape keys from source to target mesh"""
        sk_src = source.data.shape_keys
        if not sk_src or len(sk_src.key_blocks) <= 1:
            return

        # Prevent crash if meshes have different vertex counts
        if len(source.data.vertices) != len(target.data.vertices):
            self.report({'WARNING'}, f"Cannot transfer shape keys to '{target.name}': Vertex count does not match source.")
            return

        # ensure target has at least a Basis
        if not target.data.shape_keys:
            target.shape_key_add(name="Basis", from_mix=False)
        tgt_kb = target.data.shape_keys.key_blocks
        existing = {kb.name for kb in tgt_kb}
        for src_kb in sk_src.key_blocks:
            name = src_kb.name
            if name == "Basis" or name in existing:
                continue
            new_kb = target.shape_key_add(name=name, from_mix=False)
            # fast copy of all verts
            coords = [coord for vert in src_kb.data for coord in vert.co]
            new_kb.data.foreach_set("co", coords)
            # copy slider range, mask group, and mute state
            new_kb.slider_min   = src_kb.slider_min
            new_kb.slider_max   = src_kb.slider_max
            new_kb.vertex_group = src_kb.vertex_group
            new_kb.mute         = src_kb.mute

    def is_shapekey_animated(self, obj, shapekey):
        if not obj.data.shape_keys or not obj.data.shape_keys.animation_data:
            return False

        anim_data = obj.data.shape_keys.animation_data
        data_path = shapekey.path_from_id('value')

        # Check for drivers
        for driver in anim_data.drivers:
            if driver.data_path == data_path:
                return True

        # Check for keyframes on an action
        if anim_data.action:
            for fcurve in anim_data.action.fcurves:
                if fcurve.data_path == data_path:
                    return True
        
        return False

    def analyze_and_resolve_clashes(self, context, source_mesh, target_mesh):
        if not (source_mesh and target_mesh and source_mesh.data.shape_keys and target_mesh.data.shape_keys):
            return False

        source_kb = source_mesh.data.shape_keys.key_blocks
        target_kb = target_mesh.data.shape_keys.key_blocks
        
        clashes = []
        for sk_t in target_kb:
            if sk_t.name == 'Basis' or self.is_shapekey_animated(target_mesh, sk_t):
                continue

            sk_s = source_kb.get(sk_t.name)
            
            if sk_s:
                # Also skip if the source shapekey is animated
                if self.is_shapekey_animated(source_mesh, sk_s):
                    continue
                    
                if (sk_t.value != sk_s.value or
                    sk_t.slider_min != sk_s.slider_min or
                    sk_t.slider_max != sk_s.slider_max or
                    sk_t.vertex_group != sk_s.vertex_group):
                    clashes.append({'name': sk_t.name, 'clash_type': 'VALUE_MISMATCH'})
            else:
                clashes.append({'name': sk_t.name, 'clash_type': 'TARGET_ONLY'})

        if clashes:
            wm = context.window_manager
            wm.shapekey_clashes.clear()
            wm.shapekey_clash_source = source_mesh.name
            wm.shapekey_clash_target = target_mesh.name
            
            # Prioritize keys: Mouth first, then Head (case-insensitive)
            def is_mouth(name):
                n = name.lower()
                n2 = n.replace(" ", "")
                return ("mouth preset" in n) or ("char-mouth" in n2)
            def is_head(name):
                n = name.lower()
                n2 = n.replace(" ", "")
                return ("head preset" in n) or ("char-head" in n2)

            mouth = [c for c in clashes if is_mouth(c['name'])]
            head = [c for c in clashes if (not is_mouth(c['name'])) and is_head(c['name'])]
            others = [c for c in clashes if (not is_mouth(c['name'])) and (not is_head(c['name']))]
            ordered = mouth + head + others

            for clash_data in ordered:
                item = wm.shapekey_clashes.add()
                item.name = clash_data['name']
                item.clash_type = clash_data['clash_type']

            return True
        return False

def register():
    # --- Register Operators and Properties ---
    # To avoid re-registration errors, check if the classes exist first.
    
    if not hasattr(bpy.types, "WM_OT_shapekey_clash_resolver"):
        bpy.utils.register_class(WM_OT_shapekey_clash_resolver)
    if not hasattr(bpy.types, "WM_OT_shapekey_clash_set_all"):
        bpy.utils.register_class(WM_OT_shapekey_clash_set_all)
    if not hasattr(bpy.types, "WM_OT_shapekey_clash_set_selected"):
        bpy.utils.register_class(WM_OT_shapekey_clash_set_selected)
    if not hasattr(bpy.types, "SHAPEKEY_UL_clash_list"):
        bpy.utils.register_class(SHAPEKEY_UL_clash_list)
    if not hasattr(bpy.types, "ShapeKeyClashItem"):
         bpy.utils.register_class(ShapeKeyClashItem)

    bpy.utils.register_class(ARMATURE_OT_bs_anim_transfer)

    # --- Register WindowManager properties ---
    if not hasattr(bpy.types.WindowManager, "shapekey_clashes"):
        bpy.types.WindowManager.shapekey_clashes = CollectionProperty(type=ShapeKeyClashItem)
    if not hasattr(bpy.types.WindowManager, "shapekey_clash_source"):
        bpy.types.WindowManager.shapekey_clash_source = StringProperty()
    if not hasattr(bpy.types.WindowManager, "shapekey_clash_target"):
        bpy.types.WindowManager.shapekey_clash_target = StringProperty()
    if not hasattr(bpy.types.WindowManager, "shapekey_clash_active_index"):
        bpy.types.WindowManager.shapekey_clash_active_index = IntProperty(name="Active Shape Key Clash Index")


def unregister():
    # --- Unregister in reverse order ---
    bpy.utils.unregister_class(ARMATURE_OT_bs_anim_transfer)
    
    # Check before unregistering and deleting properties to prevent errors on reload
    if hasattr(bpy.types, "WM_OT_shapekey_clash_resolver"):
        bpy.utils.unregister_class(WM_OT_shapekey_clash_resolver)
    if hasattr(bpy.types, "WM_OT_shapekey_clash_set_all"):
        bpy.utils.unregister_class(WM_OT_shapekey_clash_set_all)
    if hasattr(bpy.types, "WM_OT_shapekey_clash_set_selected"):
        bpy.utils.unregister_class(WM_OT_shapekey_clash_set_selected)
    if hasattr(bpy.types, "SHAPEKEY_UL_clash_list"):
        bpy.utils.unregister_class(SHAPEKEY_UL_clash_list)
    if hasattr(bpy.types, "ShapeKeyClashItem"):
        bpy.utils.unregister_class(ShapeKeyClashItem)
        
    # It's safer to check before deleting properties
    if hasattr(bpy.types.WindowManager, "shapekey_clashes"):
        del bpy.types.WindowManager.shapekey_clashes
    if hasattr(bpy.types.WindowManager, "shapekey_clash_source"):
        del bpy.types.WindowManager.shapekey_clash_source
    if hasattr(bpy.types.WindowManager, "shapekey_clash_target"):
        del bpy.types.WindowManager.shapekey_clash_target
    if hasattr(bpy.types.WindowManager, "shapekey_clash_active_index"):
        del bpy.types.WindowManager.shapekey_clash_active_index 