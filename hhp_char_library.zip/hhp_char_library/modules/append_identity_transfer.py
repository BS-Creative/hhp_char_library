"""Choose an existing source before transferring a library character's identity."""
from pathlib import Path

import bpy
from bpy.props import StringProperty

from . import hhp_naming


def _show_source_picker(context, filepath, sources):
    names = [source.name for source in sources]

    def draw(menu, _context):
        menu.layout.label(text='Choose the character that receives the identity:', icon='INFO')
        menu.layout.separator()
        for name in names:
            operator = menu.layout.operator('hhp.append_identity_transfer', text=name, icon='MESH_DATA')
            operator.filepath = filepath
            operator.source_mesh = name

    context.window_manager.popup_menu(draw, title='Select HHP Character for Identity Transfer', icon='USER')


class HHP_OT_append_identity_transfer(bpy.types.Operator):
    bl_idname = 'hhp.append_identity_transfer'
    bl_label = 'HHP Identity Transfer'
    bl_description = 'Choose an existing HHP character if needed, then open Identity Transfer options before appending the library character'

    filepath: StringProperty(
        name='Identity Character File',
        description='Library character whose identity will be transferred',
        subtype='FILE_PATH',
        options={'HIDDEN', 'SKIP_SAVE'},
    )
    source_mesh: StringProperty(
        name='Source Character',
        description='Existing character chosen to receive the library identity',
        options={'HIDDEN', 'SKIP_SAVE'},
    )

    def execute(self, context):
        from .. import _get_hhp_character_meshes, _hhp_select_make_active

        filepath = self.filepath
        if not filepath:
            entries = getattr(context.scene, 'blend_file_list', ())
            index = getattr(context.scene, 'blend_file_list_index', -1)
            if 0 <= index < len(entries):
                filepath = entries[index].file_path
        if not filepath or not Path(bpy.path.abspath(filepath)).is_file():
            self.report({'ERROR'}, 'Select an available character blend file from the library')
            return {'CANCELLED'}

        if self.source_mesh:
            source = bpy.data.objects.get(self.source_mesh)
            if source not in _get_hhp_character_meshes(context) or not hhp_naming.is_char_mesh(source):
                self.report({'WARNING'}, 'The chosen HHP character is no longer available')
                return {'CANCELLED'}
        else:
            source = context.active_object
            if not hhp_naming.is_char_mesh(source) or source not in context.selected_objects:
                sources = [obj for obj in _get_hhp_character_meshes(context) if hhp_naming.is_char_mesh(obj)]
                if not sources:
                    self.report({'WARNING'}, 'No HHP character meshes found in the scene')
                    return {'CANCELLED'}
                _show_source_picker(context, filepath, sources)
                return {'FINISHED'}

        _hhp_select_make_active(context, source)
        result = bpy.ops.hhp.identity_transfer('INVOKE_DEFAULT', append_filepath=filepath)
        return {'FINISHED'} if result in ({'RUNNING_MODAL'}, {'FINISHED'}) else {'CANCELLED'}


def register():
    bpy.utils.register_class(HHP_OT_append_identity_transfer)


def unregister():
    bpy.utils.unregister_class(HHP_OT_append_identity_transfer)
