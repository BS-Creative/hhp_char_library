"""Actual Rigify generation on a transient scaffold derived from Daz rest data.

Generates controls separately; the binding module preserves the supplied Daz skeleton.
"""
import json
import time
import bpy
from mathutils import Vector


def matrix_rows(m):
    return [[float(v) for v in row] for row in m]


def generate_from_daz(source, *, name='Rigify HHP', remove_scaffold=True):
    from .rigify_compat_loader import generation_context
    with generation_context() as engine:
        return _generate_from_daz(source, engine, name=name, remove_scaffold=remove_scaffold)


def _generate_from_daz(source, engine, *, name, remove_scaffold):
    Generator = engine.Generator
    BaseGenerator = engine.BaseGenerator
    SuperFingerRig = engine.SuperFingerRig

    class AnatomicalFingerRig(SuperFingerRig):
        def build_ik_parent_switch(self, parent_builder):
            super().build_ik_parent_switch(parent_builder)
            if self.base_bone.startswith('ORG-tongue.'):
                parent, title = 'ORG-jaw_ctrl', 'Jaw'
            else:
                parent, title = 'DEF-hand.' + self.base_bone[-1], 'Hand'
            # Native parent switching generates all its constraints, metadata,
            # and snap operators. Only the anatomical default is supplied here.
            parent_builder.amend_child(self, self.bones.ctrl.ik,
                extra_parents=[(parent, title)], select_parent=parent,
                select_tags=[], only_selected=False)

    class AnatomicalGenerator(Generator):
        def find_rig_class(self, rig_type):
            if rig_type == 'limbs.super_finger':
                return AnatomicalFingerRig
            return super().find_rig_class(rig_type)
    started = time.perf_counter()
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    original_rest = {b.name: matrix_rows(b.matrix_local) for b in source.data.bones}
    data = bpy.data.armatures.new('Transient Daz Rigify Input')
    meta = bpy.data.objects.new('Transient Daz Rigify Input', data)
    bpy.context.scene.collection.objects.link(meta)
    meta.matrix_world = source.matrix_world.copy()
    data.rigify_rig_basename = name
    color_specs = [
        ('Root', (.4353,.1843,.4157)), ('IK', (.6039,0,0)),
        ('Special', (.9569,.7882,.0471)), ('Tweak', (.0392,.2118,.5804)),
        ('FK', (.1176,.5686,.0353)), ('Extra', (.9686,.2510,.0941)),
    ]
    for title, normal in color_specs:
        color = data.rigify_colors.add()
        color.name = title
        color.normal = normal
        color.select = (.3137,.7843,1.0)
        color.active = (.549,1.0,1.0)
        color.standard_colors_lock = True
    bpy.ops.object.select_all(action='DESELECT')
    meta.select_set(True)
    bpy.context.view_layer.objects.active = meta
    for old in list(data.collections_all):
        data.collections.remove(old)
    colls = {}
    for i, cname in enumerate(['Torso', 'Torso Detail', 'Head', 'Arms IK', 'Arms FK', 'Arms Detail',
                               'Legs IK', 'Legs FK', 'Legs Detail', 'Fingers', 'Fingers FK',
                               'Fingers IK', 'Toes', 'Tongue', 'Root']):
        coll = data.collections.new(cname)
        coll.rigify_ui_row = i + 1
        coll.rigify_color_set_id = (1 if cname == 'Root' else 2 if 'IK' in cname else
            5 if 'FK' in cname else 4 if 'Detail' in cname else 3 if cname == 'Torso' else 6)
        colls[cname] = coll
    settings, native_map, input_map = {}, {}, {}
    bpy.ops.object.mode_set(mode='EDIT')

    def add(name, native, *, end=None, parent=None, connect=False, kind='', coll='Torso', params=None):
        old = source.data.bones[native]
        b = data.edit_bones.new(name)
        b.head = old.head_local
        b.tail = old.tail_local if end is None else Vector(end)
        b.align_roll(old.matrix_local.to_3x3().col[2])
        if parent:
            b.parent = data.edit_bones[parent]
        b.use_connect = connect
        b.use_deform = False
        colls[coll].assign(b)
        settings[name] = (kind, params or {})
        input_map.setdefault(native, name)
        return b

    def head(native):
        return source.data.bones[native].head_local.copy()

    def chain(names, natives, *, parent, kind, coll, params=None, last_end=None):
        for i, (name, native) in enumerate(zip(names, natives)):
            end = head(natives[i+1]) if i+1 < len(natives) else last_end
            add(name, native, end=end, parent=parent if i == 0 else names[i-1],
                connect=i > 0, kind=kind if i == 0 else '', coll=coll,
                params=params if i == 0 else None)
            native_map[native] = 'DEF-' + name

    add('root', 'root', kind='basic.raw_copy', coll='Root')
    spine_native = ['abdomenLower', 'abdomenUpper', 'chestLower', 'chestUpper']
    spine_names = ['spine', 'spine.001', 'spine.002', 'spine.003']
    chain(spine_names, spine_native, parent='root', kind='spines.basic_spine', coll='Torso',
          params={'pivot_pos': 2, 'make_fk_controls': True, 'make_custom_pivot': True,
                  'fk_coll': 'Torso Detail', 'tweak_coll': 'Torso Detail'}, last_end=head('neckLower'))
    native_map['hip'] = 'torso'
    native_map['pelvis'] = 'ORG-spine'
    chain(['neck.01', 'neck.02', 'neck.03'], ['neckLower', 'neckUpper', 'head'],
          parent='spine.003', kind='spines.super_head', coll='Head',
          params={'connect_chain': True, 'tweak_coll': 'Head'})
    add('jaw_ctrl', 'lowerJaw', parent='neck.03', kind='basic.super_copy', coll='Head')
    native_map['lowerJaw'] = 'DEF-jaw_ctrl'
    add('teeth_lower_ctrl', 'lowerTeeth', parent='jaw_ctrl', kind='basic.super_copy', coll='Head')
    native_map['lowerTeeth'] = 'DEF-teeth_lower_ctrl'
    chain(['tongue.01', 'tongue.02', 'tongue.03', 'tongue.04'],
          ['tongue01', 'tongue02', 'tongue03', 'tongue04'], parent='jaw_ctrl',
          kind='limbs.super_finger', coll='Tongue', params={'make_extra_ik_control': True,
          'bbones': 1, 'primary_rotation_axis': 'X', 'ik_local_location': False,
          'extra_ik_coll': 'Tongue', 'tweak_coll': 'Tongue'})

    for side, cap in [('l', 'L'), ('r', 'R')]:
        add('shoulder.'+cap, side+'Collar', parent='spine.003', kind='basic.super_copy', coll='Arms IK')
        native_map[side+'Collar'] = 'DEF-shoulder.'+cap
        arm_names = ['upper_arm.'+cap, 'forearm.'+cap, 'hand.'+cap]
        chain(arm_names, [side+'ShldrBend', side+'ForearmBend', side+'Hand'], parent='shoulder.'+cap,
              kind='limbs.arm', coll='Arms IK', params={'segments': 2, 'bbones': 1,
              'rotation_axis': 'automatic', 'make_ik_wrist_pivot': True, 'make_custom_pivot': True,
              'ik_local_location': False, 'fk_coll': 'Arms FK', 'tweak_coll': 'Arms Detail'})
        native_map[side+'ShldrTwist'] = 'DEF-upper_arm.'+cap+'.001'
        native_map[side+'ForearmTwist'] = 'DEF-forearm.'+cap+'.001'
        for i in range(1, 5):
            add(f'palm.{i:02d}.{cap}', f'{side}Carpal{i}', parent='hand.'+cap,
                kind='limbs.super_palm' if i == 1 else '', coll='Fingers',
                params={'palm_both_sides': True, 'make_extra_control': True})
            native_map[f'{side}Carpal{i}'] = f'DEF-palm.{i:02d}.{cap}'
        for title, slug, palm in [('Thumb', 'thumb', None), ('Index', 'f_index', 1),
                                   ('Mid', 'f_middle', 2), ('Ring', 'f_ring', 3), ('Pinky', 'f_pinky', 4)]:
            names = [f'{slug}.{i:02d}.{cap}' for i in range(1, 4)]
            chain(names, [f'{side}{title}{i}' for i in range(1, 4)],
                  parent=f'palm.{palm:02d}.{cap}' if palm else 'hand.'+cap,
                  kind='limbs.super_finger', coll='Fingers', params={'make_extra_ik_control': True,
                  'bbones': 1, 'primary_rotation_axis': 'X', 'ik_local_location': False,
                  'extra_ik_coll': 'Fingers IK', 'tweak_coll': 'Fingers FK'})
        add('breast.'+cap, side+'Pectoral', parent='spine.002', kind='basic.super_copy', coll='Torso')
        native_map[side+'Pectoral'] = 'DEF-breast.'+cap
        leg_names = ['thigh.'+cap, 'shin.'+cap, 'foot.'+cap, 'toe.'+cap]
        chain(leg_names, [side+'ThighBend', side+'Shin', side+'Foot', side+'Toe'], parent='spine',
              kind='limbs.leg', coll='Legs IK', params={'segments': 2, 'bbones': 1,
              'rotation_axis': 'x', 'auto_align_extremity': True, 'foot_pivot_type': 'ANKLE_TOE', 'extra_ik_toe': True,
              'extra_toe_roll': True, 'make_custom_pivot': True, 'ik_local_location': False,
              'fk_coll': 'Legs FK', 'tweak_coll': 'Legs Detail'})
        native_map[side+'ThighTwist'] = 'DEF-thigh.'+cap+'.001'
        add('forefoot.'+cap, side+'Metatarsals', parent='foot.'+cap,
            kind='basic.super_copy', coll='Legs IK')
        native_map[side+'Metatarsals'] = 'DEF-forefoot.'+cap
        heel = add('heel.02.'+cap, side+'Foot', parent='foot.'+cap, coll='Legs IK')
        # Transverse ground contact marker needed by Rigify's reverse foot.
        foot = source.data.bones[side+'Foot']
        toe = source.data.bones[side+'Toe']
        width = max(0.025, (toe.head_local-foot.head_local).length*0.22)
        y = max(foot.head_local.y, foot.tail_local.y) + 0.025
        z = min(toe.head_local.z, toe.tail_local.z)
        heel.head = (foot.head_local.x-width, y, z)
        heel.tail = (foot.head_local.x+width, y, z)
        heel.roll = 0
        for title, slug in [('BigToe','bigtoe'), ('SmallToe1','smalltoe1'), ('SmallToe2','smalltoe2'),
                            ('SmallToe3','smalltoe3'), ('SmallToe4','smalltoe4')]:
            prev = 'toe.'+cap
            for i, suffix in [(1, ''), (2, '_2')]:
                native = side+title+suffix
                name = f'{slug}.{i:02d}.{cap}'
                add(name, native, parent=prev, kind='basic.super_copy', coll='Toes')
                native_map[native] = 'DEF-'+name
                prev = name
    bpy.ops.object.mode_set(mode='OBJECT')
    for name, (kind, params) in settings.items():
        pb = meta.pose.bones[name]
        pb.rigify_type = kind
        pb.rotation_mode = 'QUATERNION'
        for key, value in params.items():
            if key.endswith('_coll'):
                ref_attr = key[:-5]+'_coll_refs'
                refs = getattr(pb.rigify_parameters, ref_attr)
                refs.add().set_collection(colls[value])
                setattr(pb.rigify_parameters, key[:-5]+'_layers_extra', True)
            else:
                setattr(pb.rigify_parameters, key, value)
    generator = AnatomicalGenerator(bpy.context, meta)
    try:
        BaseGenerator.instance = generator
        generator.generate()
    finally:
        BaseGenerator.instance = None
    rig = generator.obj
    limb_settings = []
    finger_settings = []
    instances = []
    for item in generator.rig_list:
        rec = {'type': 'rigify.rigs.limbs.super_finger' if isinstance(item, SuperFingerRig)
               else type(item).__module__, 'base_bone': item.base_bone,
               'bones': item.bones}
        instances.append(rec)
        if hasattr(item, 'get_ik_fk_position_chains'):
            ik, tail, fk = item.get_ik_fk_position_chains()
            limb_settings.append({'base': item.base_bone, 'master': item.bones.ctrl.master,
                'ik_bones': ik, 'tail_bones': tail, 'fk_bones': fk,
                'ik_ctrl_bones': item.get_ik_control_chain(),
                'ik_extra_ctrls': item.get_extra_ik_controls(),
                'heel_control': getattr(item.bones.ctrl, 'heel', None)})
            snap = limb_settings[-1]
            to_ik = {'operator': 'pose.rigify_limb_ik2fk_'+generator.rig_id,
                'prop_bone': snap['master'], 'fk_bones': json.dumps(fk), 'ik_bones': json.dumps(ik),
                'ctrl_bones': json.dumps(snap['ik_ctrl_bones']), 'tail_bones': json.dumps(tail),
                'extra_ctrls': json.dumps(snap['ik_extra_ctrls'])}
            if snap['heel_control']:
                to_ik['operator'] = 'pose.rigify_leg_roll_ik2fk_'+generator.rig_id
                to_ik['heel_control'] = snap['heel_control']
            snap['to_ik'] = to_ik
            snap['to_fk'] = {'operator': 'pose.rigify_generic_snap_'+generator.rig_id,
                'output_bones': json.dumps(fk), 'input_bones': json.dumps(ik+tail),
                'ctrl_bones': json.dumps(item.get_all_ik_controls())}
            # Rigify defaults to 3.5 percent reserve even at IK_Stretch=0;
            # the character requirement is a very small stretch reserve.
            for con in rig.pose.bones[item.bones.mch.ik_target].constraints:
                if con.type == 'LIMIT_DISTANCE':
                    con.distance *= 1.002 / 1.035
        elif isinstance(item, SuperFingerRig):
            ctrl = item.bones.ctrl
            axis = item.axis_options[item.params.primary_rotation_axis]['id']
            finger_settings.append({'base': item.base_bone,
                'to_fk': {'operator': 'pose.rigify_finger_fk2ik_'+generator.rig_id,
                    'fk_master': ctrl.master, 'fk_chain': json.dumps(ctrl.fk),
                    'ik_chain': json.dumps(item.bones.org), 'ik_control': ctrl.ik,
                    'constraint_bone': item.bones.org[-1], 'axis': axis},
                'to_ik': {'operator': 'pose.rigify_generic_snap_'+generator.rig_id,
                    'output_bones': json.dumps([ctrl.ik]), 'input_bones': json.dumps(ctrl.fk[-1:]),
                    'ctrl_bones': json.dumps([ctrl.master, *ctrl.fk]),
                    'locks': (False, True, True)},
                'ik_control': ctrl.ik, 'master': ctrl.master})
    for pb in rig.pose.bones:
        if 'IK_FK' in pb:
            pb['IK_FK'] = 0.0
        if 'IK_Stretch' in pb:
            pb['IK_Stretch'] = 0.0
        if 'pole_vector' in pb:
            # Direct limb rotation is the default; optional poles remain available.
            pb['pole_vector'] = False
            pb.id_properties_ui('pole_vector').update(default=False)
        if 'FK_IK' in pb:
            pb['FK_IK'] = 1.0
    bpy.context.view_layer.update()
    missing = {n: t for n, t in native_map.items() if t not in rig.data.bones}
    if missing:
        raise RuntimeError(f'Missing generated targets: {missing}')
    offsets = {n: matrix_rows(rig.data.bones[t].matrix_local.inverted() @ source.data.bones[n].matrix_local)
               for n, t in native_map.items()}
    # Rigify's iterative finger IK converges very close to the input rest but
    # can differ by a small angle. This evaluated neutral offset permits the
    # adapter to keep the Daz neutral pose exactly without changing any rest bone.
    neutral_offsets = {n: matrix_rows(rig.pose.bones[t].matrix.inverted() @ source.data.bones[n].matrix_local)
                       for n, t in native_map.items()}
    default_pose_error = {n: max(abs(float(v)) for row in (rig.pose.bones[t].matrix @
         rig.data.bones[t].matrix_local.inverted() @ source.data.bones[n].matrix_local - source.data.bones[n].matrix_local)
         for v in row) for n, t in native_map.items()}
    assert original_rest == {b.name: matrix_rows(b.matrix_local) for b in source.data.bones}, 'Source rest changed'
    info = {'native_map': native_map, 'input_map': input_map, 'offsets': offsets,
            'neutral_offsets': neutral_offsets,
            'limbs': limb_settings, 'fingers': finger_settings, 'instances': instances,
            'rig_id': generator.rig_id, 'ui_text': rig['rig_ui'].name,
            'default_poles': False,
            'source_bones': len(original_rest), 'generated_bones': len(rig.data.bones),
            'default_pose_error': default_pose_error,
            'generation_seconds': time.perf_counter()-started}
    if remove_scaffold:
        bpy.data.objects.remove(meta, do_unlink=True)
        if data.users == 0:
            bpy.data.armatures.remove(data)
    return rig, info
