import bpy
import os
from bpy.types import Operator
from bpy.props import BoolProperty

class HHP_OT_UpdateShapekeyNames(Operator):
    """Update shapekey names from old standard to new standard"""
    bl_idname = "hhp.update_shapekey_names"
    bl_label = "Update Shapekeys to New Standard"
    bl_description = "This will update old SK names to new ones so they work with the new shapekey character shaper panel"
    bl_options = {'REGISTER', 'UNDO'}
    
    reverse_conversion: BoolProperty(
        name="Reverse Update",
        description="Convert new names back to old names instead of old to new",
        default=False
    )
    
    def get_shapekey_mapping_and_valid_names(self, reverse=False):
        """Create mapping dictionary and valid new names list from reference files"""
        # Get the addon directory
        addon_dir = os.path.dirname(os.path.dirname(__file__))
        ref_dir = os.path.join(addon_dir, "remapping")
        
        old_file = os.path.join(ref_dir, "HHP4 old SK names.txt")
        new_file = os.path.join(ref_dir, "HHP4 New SK names.txt")
        
        mapping = {}
        valid_new_names = set()
        
        try:
            # Read old names
            with open(old_file, 'r', encoding='utf-8') as f:
                old_lines = f.readlines()
            
            # Read new names
            with open(new_file, 'r', encoding='utf-8') as f:
                new_lines = f.readlines()
            
            # Create mapping from old to new and collect valid new names
            for i, (old_line, new_line) in enumerate(zip(old_lines, new_lines)):
                old_name = old_line.strip()
                new_name = new_line.strip()
                
                # Skip empty lines and header lines
                if not old_name or not new_name:
                    continue
                if old_name.startswith('Shapekeys:') or old_name.startswith('Object:'):
                    continue
                if old_name in ['Phonemes', 'Expressions', 'Morphs (Body)', 'Morphs (Facial)', 
                               'Shapers (Main)', 'Shapers (Build a Bod)', 'Feet', 'Custom Correctives',
                               'Morphs (Facial RIG)', 'Morphs (iPhone Mocap)', 'Left Eye', 'Right Eye',
                               'Mouth and Jaw', 'Eyebrows, Cheeks, and Nose', 'Morphs (Genitals)',
                               'Multi_Expression_Mesh', 'Correctives (HHP)', 'Tongue']:
                    continue
                
                # Remove leading spaces
                old_clean = old_name.lstrip()
                new_clean = new_name.lstrip()
                
                if old_clean and new_clean:
                    if not reverse:
                        # Normal conversion: old -> new
                        valid_new_names.add(new_clean)
                        if old_clean != new_clean:
                            mapping[old_clean] = new_clean
                    else:
                        # Reverse conversion: new -> old
                        valid_new_names.add(old_clean)
                        if old_clean != new_clean:
                            mapping[new_clean] = old_clean
            
            return mapping, valid_new_names
            
        except Exception as e:
            self.report({'ERROR'}, f"Error reading reference files: {str(e)}")
            return {}, set()
    
    def update_presets(self, obj, name_changes):
        """Update preset shapekey references to use new names and add missing categorized shapekeys"""
        try:
            # Import the categorized shapekeys function from parent module
            from .. import Customize_HHP
            
            presets = obj["presets"]
            updated_presets = 0
            updated_keys = 0
            added_keys = 0
            
            # Get all current categorized shapekeys
            if obj.data and obj.data.shape_keys and obj.data.shape_keys.key_blocks:
                all_categorized = set(Customize_HHP.get_all_categorized_shapekeys(obj.data.shape_keys.key_blocks))
            else:
                all_categorized = set()
            
            for preset_name, preset_data in presets.items():
                if "shapekeys" in preset_data:
                    shapekey_data = preset_data["shapekeys"]
                    
                    # Create a new shapekey dict with updated names
                    new_shapekey_data = {}
                    preset_updated = False
                    
                    # First pass: Update existing shapekey names
                    for old_sk_name, value in shapekey_data.items():
                        if old_sk_name in name_changes:
                            # Use new name
                            new_sk_name = name_changes[old_sk_name]
                            new_shapekey_data[new_sk_name] = value
                            preset_updated = True
                            updated_keys += 1
                            print(f"Updated preset '{preset_name}': '{old_sk_name}' → '{new_sk_name}'")
                        else:
                            # Keep original name
                            new_shapekey_data[old_sk_name] = value
                    
                    # Second pass: Add any missing categorized shapekeys with current values
                    existing_keys = set(new_shapekey_data.keys())
                    missing_keys = all_categorized - existing_keys
                    
                    for missing_key in missing_keys:
                        if missing_key in obj.data.shape_keys.key_blocks:
                            # Add the missing shapekey with its current value
                            current_value = obj.data.shape_keys.key_blocks[missing_key].value
                            new_shapekey_data[missing_key] = current_value
                            preset_updated = True
                            added_keys += 1
                            print(f"Added missing shapekey to preset '{preset_name}': '{missing_key}' = {current_value}")
                    
                    # Update the preset data
                    preset_data["shapekeys"] = new_shapekey_data
                    
                    if preset_updated:
                        updated_presets += 1
            
            if updated_presets > 0:
                print(f"Updated {updated_keys} shapekey references and added {added_keys} missing shapekeys across {updated_presets} presets")
                
        except Exception as e:
            print(f"Error updating presets: {str(e)}")
    
    def execute(self, context):
        # Get the shapekey mapping and valid new names
        mapping, valid_new_names = self.get_shapekey_mapping_and_valid_names(reverse=self.reverse_conversion)
        
        if not mapping and not valid_new_names:
            self.report({'WARNING'}, "No mapping data found or error reading reference files")
            return {'CANCELLED'}
        
        # Get selected mesh objects
        selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        if not selected_meshes:
            self.report({'WARNING'}, "No mesh objects selected")
            return {'CANCELLED'}
        
        total_renamed = 0
        updated_objects = []
        
        for obj in selected_meshes:
            if not obj.data.shape_keys:
                continue
                
            obj_renamed = 0
            shape_keys = obj.data.shape_keys.key_blocks
            
            # Create a list of renames to avoid modifying while iterating
            renames = []
            
            # First pass: Handle special case - Convert between "Torso -" and "Char -" prefixes
            if not self.reverse_conversion:
                # Normal: Convert "Torso -" to "Char -" for hot list
                # Only convert "Torso -" shapekeys that are NOT in the valid new names list
                for sk in shape_keys:
                    if sk.name.startswith("Torso -") and sk.name not in valid_new_names:
                        new_name = "Char -" + sk.name[7:]  # Replace "Torso -" with "Char -"
                        # Make sure new name doesn't already exist
                        if new_name not in [s.name for s in shape_keys]:
                            renames.append((sk, new_name))
            else:
                # Reverse: Convert "Char -" back to "Torso -"
                # Only convert "Char -" shapekeys that are NOT in the valid names list
                for sk in shape_keys:
                    if sk.name.startswith("Char -") and sk.name not in valid_new_names:
                        new_name = "Torso -" + sk.name[6:]  # Replace "Char -" with "Torso -"
                        # Make sure new name doesn't already exist
                        if new_name not in [s.name for s in shape_keys]:
                            renames.append((sk, new_name))
            
            # Second pass: Handle regular mapping (skip if already renamed in first pass)
            for sk in shape_keys:
                # Skip if this shapekey is already scheduled for rename from Torso -> Char
                if any(rename_sk == sk for rename_sk, _ in renames):
                    continue
                    
                if sk.name in mapping:
                    new_name = mapping[sk.name]
                    # Make sure new name doesn't already exist
                    if new_name not in [s.name for s in shape_keys]:
                        renames.append((sk, new_name))
            
            # Apply the renames and track name changes for preset updates
            name_changes = {}
            for sk, new_name in renames:
                old_name = sk.name
                sk.name = new_name
                name_changes[old_name] = new_name
                obj_renamed += 1
                total_renamed += 1
                print(f"Renamed: '{old_name}' → '{new_name}'")
            
            # Update presets if any names were changed
            if name_changes and "presets" in obj:
                self.update_presets(obj, name_changes)
            
            if obj_renamed > 0:
                updated_objects.append(f"{obj.name} ({obj_renamed} shapekeys)")
        
        if total_renamed > 0:
            objects_text = "\n".join(updated_objects)
            conversion_type = "reversed to old standard" if self.reverse_conversion else "updated to new standard"
            self.report({'INFO'}, f"Successfully {conversion_type} - {total_renamed} shapekey names across {len(updated_objects)} objects:\n{objects_text}\n\nPresets have been updated with renamed shapekeys and any missing categorized shapekeys.")
        else:
            current_type = "old standard" if self.reverse_conversion else "new standard" 
            self.report({'INFO'}, f"No shapekeys needed updating (all names are already at {current_type})")
        
        return {'FINISHED'}
    
    def invoke(self, context, event):
        # Show confirmation dialog
        return context.window_manager.invoke_props_dialog(self, width=400)
    
    def draw(self, context):
        layout = self.layout
        
        # Get selected mesh objects for preview
        selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
        mesh_count = len(selected_meshes)
        
        # Get mapping to show count
        mapping, valid_new_names = self.get_shapekey_mapping_and_valid_names(reverse=self.reverse_conversion)
        mapping_count = len(mapping)
        
        layout.label(text="Update Shapekey Names", icon='SHAPEKEY_DATA')
        layout.separator()
        
        # Reverse conversion checkbox
        layout.prop(self, "reverse_conversion")
        layout.separator()
        
        # Warning box
        warning_box = layout.box()
        warning_box.alert = True
        warning_col = warning_box.column(align=True)
        warning_col.label(text="⚠ SAVE YOUR FILE BEFORE PROCEEDING!", icon='ERROR')
        warning_col.label(text="This operation cannot be undone automatically.")
        warning_col.label(text="Presets will also be updated to match renamed shapekeys.")
        
        layout.separator()
        
        # Information section
        info_box = layout.box()
        info_col = info_box.column(align=True)
        info_col.label(text="What this will do:", icon='INFO')
        
        if not self.reverse_conversion:
            info_col.label(text="• Rename old shapekey names to new standard")
            info_col.label(text="• Convert unmapped 'Torso -' keys to 'Char -' (Hot List)")
            info_col.label(text="• Update all presets to use new shapekey names")
            info_col.label(text="• Add missing categorized shapekeys to existing presets")
            info_col.label(text="• Make shapekeys work with character shaper panel")
        else:
            info_col.label(text="• Rename new shapekey names back to old standard")
            info_col.label(text="• Convert unmapped 'Char -' keys back to 'Torso -'")
            info_col.label(text="• Update all presets to use old shapekey names")
            info_col.label(text="• Add missing categorized shapekeys to existing presets")
            info_col.label(text="• Revert shapekeys to old naming system")
        
        layout.separator()
        
        # Selected objects info
        if mesh_count == 0:
            layout.label(text="⚠ No mesh objects selected", icon='ERROR')
        else:
            layout.label(text=f"Selected objects: {mesh_count}")
            
            # Show which objects have shapekeys
            for obj in selected_meshes:
                if obj.data.shape_keys:
                    sk_count = len(obj.data.shape_keys.key_blocks)
                    layout.label(text=f"  • {obj.name}: {sk_count} shapekeys")
                else:
                    layout.label(text=f"  • {obj.name}: No shapekeys")
        
        layout.separator()
        layout.label(text=f"Mapping database: {mapping_count} name conversions")

def register():
    bpy.utils.register_class(HHP_OT_UpdateShapekeyNames)

def unregister():
    bpy.utils.unregister_class(HHP_OT_UpdateShapekeyNames)

if __name__ == "__main__":
    register() 