"""Shared transfer behavior, shipped independently with each add-on."""

import json
from contextlib import contextmanager

import bpy
from idprop.types import IDPropertyGroup
from . import transfer_optimized_materials as optimized_materials
from . import transfer_optimized_pending as optimized_pending


PROPORTION_NAME = "(HHP) Limit Scale - Proportions"
PROPORTION_FOLLOW_PREFIX = '(HHP) Proportion Follow - '
RIGIFY_PROPORTION_PREFIX = '(HHP) Rigify Proportion - '
PROPORTION_MUTES = 'hhp_proportion_mutes'
PROPORTION_GATE = 'hhp_proportion_rig'
PROPORTION_PROPERTIES = {
    "Metatarsals.r": ("metatarsals_r", 1.1),
    "Metatarsals.l": ("metatarsals_l", 1.1),
    "neckLower": ("neckLower", 1.1),
    "root": ("root", 0.9),
    "hip": ("hip", 0.9),
}


def purge_transfer_orphans(operator):
    """Optionally purge unused data after a successful character collection deletion."""
    if not getattr(operator, 'purge_orphans_after_delete', False):
        return
    try:
        bpy.data.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
    except RuntimeError as error:
        operator.report({'WARNING'}, f'Collection deleted, but orphan data could not be purged: {error}')


def proportion_rig_version(armature):
    """Resolve HHP5 from its associated mesh, with an anatomy fallback."""
    if armature is None or getattr(armature, "type", None) != 'ARMATURE':
        return 4
    for obj in bpy.data.objects:
        if obj.type != 'MESH' or "HHP Version" not in obj:
            continue
        if not (obj.parent == armature or any(
                modifier.type == 'ARMATURE' and modifier.object == armature
                for modifier in obj.modifiers)):
            continue
        try:
            return 5 if float(obj["HHP Version"]) >= 5 else 4
        except (TypeError, ValueError):
            continue
    bones = armature.data.bones
    return 5 if all(name in bones for name in ("lMetatarsals", "rMetatarsals", "hip(drv)")) else 4


def proportion_bone_map(armature):
    """Map persistent proportion settings to the rig's actual pose bones."""
    names = {name: name for name in PROPORTION_PROPERTIES}
    if proportion_rig_version(armature) >= 5:
        names.update({"Metatarsals.r": "rMetatarsals", "Metatarsals.l": "lMetatarsals"})
    return names


def proportion_anchor_bone(armature, selection):
    """Return the actual body-scale pivot selected by the user."""
    return "root" if selection == 'ROOT' else "hip"


def supports_proportions(armature):
    if armature is None or getattr(armature, "type", None) != 'ARMATURE' or not armature.pose:
        return False
    mapping = proportion_bone_map(armature)
    return (all(mapping[name] in armature.pose.bones
                for name in ("Metatarsals.r", "Metatarsals.l", "neckLower"))
            and ("root" in armature.pose.bones if proportion_rig_version(armature) >= 5
                 else any(name in armature.pose.bones for name in ("root", "hip"))))


class TransferError(ValueError):
    """An unsafe or ambiguous transfer, reported before changing the scene."""


def prepare_transfer_materials(mesh_pairs, context):
    """Use the stored original materials before confirmed transfer operations."""
    meshes = {mesh for pair in mesh_pairs for mesh in pair
              if mesh is not None and mesh.type == 'MESH'}
    to_change = [mesh for mesh in meshes
                 if any(slot.link != 'DATA' for slot in mesh.material_slots)]
    if any(not mesh.is_editable for mesh in to_change):
        raise TransferError("Source and target materials must be editable to use Data linking")
    for mesh in to_change:
        for slot in mesh.material_slots:
            # HHP stores its original shaders on mesh data and optimized proxies
            # in object overrides. Never overwrite the originals with proxies.
            slot.link = 'DATA'
    if to_change:
        context.view_layer.update()


@contextmanager
def preserve_rig_drivers(armatures):
    """Preserve driver paths and definitions through native animation/RNA edits."""
    backups = []
    try:
        for target in dict.fromkeys(armatures):
            storage = bpy.data.objects.new('Animation Transfer Driver Backup', None)
            backups.append((target, storage))
            saved = storage.animation_data_create().drivers
            if target.animation_data:
                for curve in target.animation_data.drivers:
                    saved.from_existing(src_driver=curve)
        try:
            yield
        finally:
            # The native operator also copies source drivers. Those refer to
            # the source skeleton and would replace the target's control rig.
            for target, storage in backups:
                animation = target.animation_data_create()
                for curve in list(animation.drivers):
                    animation.drivers.remove(curve)
                for curve in storage.animation_data.drivers:
                    animation.drivers.from_existing(src_driver=curve)
                target.update_tag()
    finally:
        for _, storage in backups:
            bpy.data.objects.remove(storage)


def link_animation_preserving_drivers(targets):
    """Keep native Action/NLA linking while retaining each target rig's drivers."""
    with preserve_rig_drivers(targets):
        bpy.ops.object.make_links_data(type='ANIMATION')


def is_hhp_mouth_shape_key(name):
    """Use the same mouth-preset filter as the shape-key clash list."""
    lowered = name.lower()
    return 'mouth preset' in lowered or 'char-mouth' in lowered.replace(' ', '')


def preserve_mouth_shape_enabled(operator):
    return (getattr(operator, 'preserve_hhp_source_mouth_shape', False)
            and not getattr(operator, 'shapekey_data_clash_analyzer', False))


def update_presets_mouth_shapes(presets, mouth_values):
    """Store the preserved mouth in every preset without changing other values."""
    for preset in presets.values():
        if 'shapekeys' not in preset:
            preset['shapekeys'] = {}
        values = preset['shapekeys']
        for name in set(values) | set(mouth_values):
            if is_hhp_mouth_shape_key(name):
                values[name] = mouth_values.get(name, 0.0)


def preserve_transferred_source_mouth_shape(source, target, update_in_presets=False):
    """On the target, retain the winning source preset and zero other presets.

    Match the copied source preset by its exact name, not just the broad mouth
    filter. The original source object and its shape-key values are never edited.
    """
    if source == target or source.type != 'MESH' or target.type != 'MESH':
        return
    source_keys = source.data.shape_keys
    source_presets = [key for key in source_keys.key_blocks
                      if is_hhp_mouth_shape_key(key.name)] if source_keys else []
    winner = max(source_presets, key=lambda key: key.value, default=None)
    winner_name = winner.name if winner is not None else None
    winner_value = winner.value if winner is not None else 0.0
    target_keys = target.data.shape_keys
    if winner_name is not None and (target_keys is None or winner_name not in target_keys.key_blocks):
        return ("The source mouth preset was not transferred. Enable Transfer unavailable "
                "shapekeys & vtx groups; mouth values and the source collection were kept unchanged")
    if target_keys is None:
        return
    names = tuple(key.name for key in target_keys.key_blocks if is_hhp_mouth_shape_key(key.name))
    if not names:
        return
    # Shape-key values live on the mesh's Key datablock, not on the object.
    # Preserve the original character when the target shares its mesh data.
    if target.data.shape_keys == source.data.shape_keys:
        target.data = target.data.copy()
    for name in names:
        key = target.data.shape_keys.key_blocks.get(name)
        if key is None:
            continue
        value = winner_value if name == winner_name else 0.0
        if key.slider_min > value:
            key.slider_min = value
        if key.slider_max < value:
            key.slider_max = value
        key.value = value
    target.data.shape_keys.update_tag()
    target.update_tag()
    if update_in_presets:
        update_presets_mouth_shapes(target.get('presets', {}),
                                   {name: winner_value if name == winner_name else 0.0
                                    for name in names})


def is_proportion_constraint(constraint):
    return constraint.type == 'LIMIT_SCALE' and PROPORTION_NAME in constraint.name


def is_proportion_follower(constraint):
    return constraint.type == 'TRANSFORM' and constraint.name.startswith(PROPORTION_FOLLOW_PREFIX)


def is_proportion_settings_only(armature, bone_name, constraint):
    """Regional settings multiply the pose scale instead of clamping it away."""
    return (bone_name in {'hip', 'neckLower', 'lMetatarsals', 'rMetatarsals'}
            and is_proportion_constraint(constraint)
            and proportion_rig_version(armature) >= 5)


def proportion_saved_mutes(bone):
    """Read older saved native toggles while migrating to the common key."""
    saved = dict(bone.get('hhp5_proportion_mutes', {}))
    saved.update(dict(bone.get(PROPORTION_MUTES, {})))
    return saved


def _save_proportion_mutes(bone, values):
    if dict(bone.get(PROPORTION_MUTES, {})) != values:
        bone[PROPORTION_MUTES] = values
    if 'hhp5_proportion_mutes' in bone:
        del bone['hhp5_proportion_mutes']


def _prepare_proportion_settings(armature, bone, constraint):
    logical_mute = proportion_constraint_muted(armature, bone.name, constraint)
    saved = proportion_saved_mutes(bone)
    if saved.get(constraint.name) != logical_mute:
        saved[constraint.name] = logical_mute
    _save_proportion_mutes(bone, saved)
    _ensure_proportion_mute_driver(armature, constraint, '1')
    _set_proportion_value(constraint, 'mute', True)


def _set_proportion_value(owner, name, value):
    """Avoid tagging dependency relations when an RNA value already matches."""
    current = getattr(owner, name)
    if current != value:
        setattr(owner, name, value)


def _ensure_proportion_mute_driver(armature, constraint, expression, active_property=None):
    animation = armature.animation_data
    curve = animation.drivers.find(constraint.path_from_id('mute')) if animation else None
    valid = False
    if curve and curve.driver.type == 'SCRIPTED' and not active_property:
        valid = not curve.driver.variables
    elif curve and curve.driver.type == 'SCRIPTED' and len(curve.driver.variables) == 1:
        variable = curve.driver.variables[0]
        valid = (variable.name == PROPORTION_GATE and variable.type == 'SINGLE_PROP'
                 and variable.targets[0].id == armature
                 and variable.targets[0].data_path == '["' + active_property + '"]')
    if not valid:
        curve = constraint.driver_add('mute')
        curve.driver.type = 'SCRIPTED'
        for variable in tuple(curve.driver.variables):
            curve.driver.variables.remove(variable)
        if active_property:
            variable = curve.driver.variables.new()
            variable.name, variable.type = PROPORTION_GATE, 'SINGLE_PROP'
            variable.targets[0].id = armature
            variable.targets[0].data_path = '["' + active_property + '"]'
    _set_proportion_value(curve.driver, 'expression', expression)


def proportion_constraint_muted(armature, bone_name, constraint):
    """Read the user's toggle independently of the optional control-rig gate."""
    saved = proportion_saved_mutes(armature.pose.bones[bone_name])
    animation = armature.animation_data
    driver = animation.drivers.find(constraint.path_from_id('mute')) if animation else None
    if driver and (any(v.name in {PROPORTION_GATE, 'hhp5_prop_rig'} for v in driver.driver.variables)
                   or (constraint.name in saved and driver.driver.expression == '1')):
        return bool(saved.get(constraint.name, constraint.mute))
    return bool(constraint.mute)


def proportion_constraint_influence(armature, bone_name, constraint):
    """Read the proportion strength before an existing ragdoll gate."""
    saved = armature.pose.bones[bone_name].get('hhp_rd_base_influences', {})
    animation = armature.animation_data
    if constraint.name in saved and animation:
        curve = animation.drivers.find(constraint.path_from_id('influence'))
        if curve and any(v.name == 'ragdoll' and v.targets[0].id == armature.data
                         for v in curve.driver.variables):
            return float(saved[constraint.name])
    return float(constraint.influence)


def set_proportion_influence(armature, bone, constraint, influence):
    """Keep an existing ragdoll's restoration value aligned with an edit."""
    saved = bone.get('hhp_rd_base_influences')
    if saved is not None and saved.get(constraint.name) != influence:
        saved[constraint.name] = influence
    _set_proportion_value(constraint, 'influence', influence)


def proportion_follow_factor(armature, bone_name):
    """Uniform proportion multiplier on a native bone that rejects inherited scale."""
    bone = armature.data.bones.get(bone_name)
    if bone is None or (bone.inherit_scale != 'NONE' and bone_name not in {'hip', 'neckLower', 'lMetatarsals', 'rMetatarsals'}) or bone_name.endswith('(drv)'):
        return 1.0
    ancestors = {parent.name for parent in bone.parent_recursive}
    factor = 1.0
    for role in ('hip', 'neckLower', 'Metatarsals.l', 'Metatarsals.r'):
        name = proportion_bone_map(armature)[role]
        if name not in ancestors and name != bone_name:
            continue
        source = next((c for c in armature.pose.bones[name].constraints
                       if is_proportion_constraint(c)), None)
        if source and not proportion_constraint_muted(armature, name, source):
            factor *= 1.0 + (source.max_x - 1.0) * proportion_constraint_influence(armature, name, source)
    return factor


def sync_proportion_followers(armature):
    """Carry regional proportions across HHP5's scale-isolated bone branches.

    Original inheritance settings remain intact. A constant scale multiplier
    repeats only the proportion adjustment at each NONE boundary; ordinary
    descendants inherit that adjustment from their existing parent.
    """
    if proportion_rig_version(armature) < 5 or not armature.pose:
        return
    mapping = proportion_bone_map(armature)
    rigify = rigify_proportion_manifest(armature)
    native_names = set(rigify.get('native_bones', ()))
    sources = {}
    source_mutes = {}
    for role in ('hip', 'neckLower', 'Metatarsals.l', 'Metatarsals.r'):
        name = mapping[role]
        bone = armature.pose.bones.get(name)
        if bone is None:
            continue
        source = next((c for c in bone.constraints if is_proportion_constraint(c)), None)
        if source is None:
            continue
        sources[name] = source
        if is_proportion_settings_only(armature, name, source):
            _prepare_proportion_settings(armature, bone, source)
        source_mutes[name] = proportion_constraint_muted(armature, name, source)
        # The regional value describes local body proportions. The common
        # root multiplier must follow it so a short character stays short.
        global_scale = bone.constraints.get('(HHP) Global Root Scale')
        if global_scale and list(bone.constraints).index(source) > list(bone.constraints).index(global_scale):
            bone.constraints.move(list(bone.constraints).index(source), list(bone.constraints).index(global_scale))
    for bone in armature.pose.bones:
        wanted = set()
        if (bone.bone.inherit_scale == 'NONE'
                and not bone.name.endswith('(drv)')
                and (not native_names or bone.name in native_names)
                and not bone.name.startswith(('HHP5 ', 'HHP5-MCH ', 'HHP_RD_'))):
            # Generated Rigify chains and Daz driver branches do not need a
            # native follower. Avoid walking every generated parent chain on
            # every slider edit; this is a significant cost on a full rig.
            wanted = sources.keys() & {parent.name for parent in bone.bone.parent_recursive}
        if bone.name in sources and is_proportion_settings_only(armature, bone.name, sources[bone.name]):
            wanted.add(bone.name)
        for constraint in list(bone.constraints):
            if is_proportion_follower(constraint) and constraint.name[len(PROPORTION_FOLLOW_PREFIX):] not in wanted:
                remove_proportion_constraint(armature, bone, constraint)
        for source_name in wanted:
            source = sources[source_name]
            name = PROPORTION_FOLLOW_PREFIX + source_name
            follower = bone.constraints.get(name) or bone.constraints.new('TRANSFORM')
            _set_proportion_value(follower, 'name', name)
            _set_proportion_value(follower, 'target', armature)
            _set_proportion_value(follower, 'subtarget', 'root')
            _set_proportion_value(follower, 'owner_space', 'LOCAL')
            _set_proportion_value(follower, 'target_space', 'LOCAL')
            _set_proportion_value(follower, 'map_from', 'LOCATION')
            _set_proportion_value(follower, 'map_to', 'SCALE')
            _set_proportion_value(follower, 'mix_mode_scale', 'MULTIPLY')
            _set_proportion_value(follower, 'use_motion_extrapolate', False)
            for axis in 'xyz':
                _set_proportion_value(follower, 'from_min_' + axis, -1.0)
                _set_proportion_value(follower, 'from_max_' + axis, 1.0)
                _set_proportion_value(follower, 'to_min_' + axis + '_scale', source.max_x)
                _set_proportion_value(follower, 'to_max_' + axis + '_scale', source.max_x)
            set_proportion_influence(armature, bone, follower,
                                     proportion_constraint_influence(armature, source_name, source))
            _set_proportion_value(follower, 'mute', source_mutes[source_name])
    hip = sources.get('hip')
    factor = (1.0 + (hip.max_x - 1.0) * proportion_constraint_influence(armature, 'hip', hip)
              if hip and not source_mutes['hip'] else 1.0)
    if armature.get('hhp5_hip_proportion_factor') != factor:
        armature['hhp5_hip_proportion_factor'] = factor
    sync_proportion_smoothing(armature)


def _proportion_smoothing_records(obj, armature):
    """Recover missing metadata from intact drivers written by HHP5."""
    try:
        records = json.loads(obj.get('hhp5_root_modifier_scale', '{}'))
    except (TypeError, ValueError):
        records = {}
    if not isinstance(records, dict):
        records = {}
    changed = False
    for modifier in obj.modifiers:
        if modifier.type != 'CORRECTIVE_SMOOTH':
            continue
        path = modifier.path_from_id('scale')
        record = records.get(path)
        if isinstance(record, dict) and isinstance(record.get('variable'), str):
            continue
        curve = obj.animation_data.drivers.find(path)
        if curve is None or curve.driver.type != 'SCRIPTED':
            continue
        root = next((v for v in curve.driver.variables
                     if v.name.startswith('hhp_global_root_scale') and v.type == 'TRANSFORMS'
                     and v.targets[0].id == armature and v.targets[0].bone_target == 'root'
                     and v.targets[0].transform_type == 'SCALE_X'
                     and v.targets[0].transform_space == 'LOCAL_SPACE'), None)
        if root is None:
            continue
        expression = curve.driver.expression
        record = {'variable': root.name}
        hip = next((v for v in curve.driver.variables
                    if v.name.startswith('hhp_hip_proportion_scale') and v.type == 'SINGLE_PROP'
                    and v.targets[0].data_path == '["hhp5_hip_proportion_factor"]'
                    and v.name in expression), None)
        if hip is not None:
            record['hip_variable'] = hip.name
            suffix = ')*' + hip.name
            if expression.startswith('(') and expression.endswith(suffix):
                expression = expression[1:-len(suffix)]
                record['hip_expression'] = expression
        suffix = ')*' + root.name
        if expression.startswith('(') and expression.endswith(suffix):
            expression = expression[1:-len(suffix)]
            record['expression'] = expression
            try:
                record['value'] = float(expression)
                record['driver_type'] = None
            except ValueError:
                record['driver_type'] = 'SCRIPTED'
        records[path] = record
        changed = True
    return records, changed


def sync_proportion_smoothing(armature):
    """Include hip proportions in smoothing drivers already owned by HHP5."""
    if proportion_rig_version(armature) < 5:
        return
    property_name = 'hhp5_hip_proportion_factor'
    if property_name not in armature:
        armature[property_name] = 1.0
    marker = 'hhp5_root_modifier_scale'
    for obj in bpy.data.objects:
        if obj.type != 'MESH' or marker not in obj or not obj.animation_data:
            continue
        records, changed = _proportion_smoothing_records(obj, armature)
        for path, record in records.items():
            if not isinstance(record, dict):
                continue
            curve = obj.animation_data.drivers.find(path)
            if curve is None or curve.driver.type != 'SCRIPTED':
                continue
            root_variable = curve.driver.variables.get(record.get('variable', ''))
            if (root_variable is None or root_variable.type != 'TRANSFORMS'
                    or root_variable.targets[0].id != armature
                    or root_variable.targets[0].bone_target != 'root'):
                continue
            variable = curve.driver.variables.get(record.get('hip_variable', ''))
            if variable is not None:
                if variable.type == 'SINGLE_PROP':
                    target = variable.targets[0]
                    target_path = '["' + property_name + '"]'
                    if target.id != armature or target.data_path != target_path:
                        target.id, target.data_path = armature, target_path
                        changed = True
                continue
            name = 'hhp_hip_proportion_scale'
            while name in curve.driver.variables:
                name += '_'
            base_expression = curve.driver.expression
            expression = '(' + base_expression + ')*' + name
            if len(expression) > 256:
                raise ValueError('The smoothing driver is too long to include hip proportions')
            variable = curve.driver.variables.new()
            variable.name, variable.type = name, 'SINGLE_PROP'
            variable.targets[0].id = armature
            variable.targets[0].data_path = '["' + property_name + '"]'
            curve.driver.expression = expression
            record['hip_variable'] = name
            record['hip_expression'] = base_expression
            changed = True
        if changed:
            obj[marker] = json.dumps(records)
            obj.update_tag()



def sync_proportion_distribution_ui(armature):
    if armature.pose is None:
        return
    sync_proportion_followers(armature)
    constraints = {
        bone.name: next((c for c in bone.constraints if is_proportion_constraint(c)), None)
        for bone in armature.pose.bones
    }
    present = [(name, c) for name, c in constraints.items() if c is not None]
    values = {"proportion_influence": proportion_constraint_influence(
        armature, *present[0]) if present else 0.0}
    mapping = proportion_bone_map(armature)
    for bone_name, (suffix, default_scale) in PROPORTION_PROPERTIES.items():
        constraint = constraints.get(mapping.get(bone_name))
        values["propdist_enable_" + suffix] = (
            constraint is not None and not proportion_constraint_muted(
                armature, mapping[bone_name], constraint))
        values["propdist_scale_" + suffix] = constraint.max_x if constraint else default_scale
    anchor = 'HIP' if constraints.get("hip") else 'ROOT'
    props = getattr(armature, "hhp_anim_preview_props", None)
    if props is None:
        # Blender stores registered RNA groups separately from ordinary custom
        # groups. The constraints preserve these values until Char Library's
        # registration/load hook can refresh its own property group.
        armature["hhp_proportion_ui_pending"] = True
        return
    previous_guard = props.get("_syncing_from_constraints")
    props["_syncing_from_constraints"] = True
    try:
        for name, value in values.items():
            setattr(props, name, value)
        props.propdist_anchor_bone = anchor
        if "hhp_proportion_ui_pending" in armature:
            del armature["hhp_proportion_ui_pending"]
    finally:
        if previous_guard is None:
            del props["_syncing_from_constraints"]
        else:
            props["_syncing_from_constraints"] = previous_guard


def is_proportion_owned(constraint):
    """Primary settings and derived constraints are synchronized together."""
    return (is_proportion_constraint(constraint) or is_proportion_follower(constraint)
            or constraint.name.startswith(RIGIFY_PROPORTION_PREFIX))


def is_generated_rig_constraint(constraint):
    """These constraints implement the receiving rig, not the source action."""
    if (constraint.name.startswith('(HHP) Rigify ')
            or constraint.name == '(HHP) Global Root Scale'):
        return True
    armature = constraint.id_data
    manifest = rigify_proportion_manifest(armature)
    if manifest:
        # Protect all generated constraints, including undriven tweak/follow
        # constraints that are part of Rigify's original implementation.
        bone_path = constraint.path_from_id().partition('.constraints[')[0]
        try:
            owner = armature.path_resolve(bone_path)
        except (ValueError, AttributeError):
            owner = None
        if owner is not None and owner.name not in manifest.get('native_bones', ()):
            return True
    if supports_proportions(armature) and armature.animation_data:
        path = constraint.path_from_id() + '.'
        return any(curve.data_path.startswith(path) for curve in armature.animation_data.drivers)
    return False


def remove_proportion_constraint(armature, bone, constraint):
    animation = armature.animation_data
    curve = animation.drivers.find(constraint.path_from_id('mute')) if animation else None
    if curve and (any(variable.name in {PROPORTION_GATE, 'hhp5_prop_rig'} for variable in curve.driver.variables)
                  or (constraint.name in proportion_saved_mutes(bone)
                      and curve.driver.expression == '1')):
        constraint.driver_remove('mute')
    saved = proportion_saved_mutes(bone)
    if constraint.name in saved:
        del saved[constraint.name]
    _save_proportion_mutes(bone, saved)
    bone.constraints.remove(constraint)


def capture_proportions(source):
    """Keep logical settings stable while other transfer modes edit the target."""
    constraints = []
    for bone in source.pose.bones:
        for index, constraint in enumerate(bone.constraints):
            if not is_proportion_constraint(constraint):
                continue
            values = {}
            for prop in constraint.bl_rna.properties:
                if prop.identifier in {'rna_type', 'enabled'} or prop.is_readonly:
                    continue
                value = getattr(constraint, prop.identifier)
                values[prop.identifier] = tuple(value) if getattr(prop, 'is_array', False) else value
            values['mute'] = proportion_constraint_muted(source, bone.name, constraint)
            values['influence'] = proportion_constraint_influence(source, bone.name, constraint)
            constraints.append((bone.name, index, values))
    return dict(mapping=proportion_bone_map(source), constraints=constraints)


def proportion_transfer_plan(source, target, settings):
    validate_proportion_controls(target)
    mapping = settings['mapping']
    target_mapping = proportion_bone_map(target)
    destinations = {mapping[role]: target_mapping[role]
                    for role in mapping.keys() & target_mapping.keys()}
    plan = [(destinations.get(name, name), index, values)
            for name, index, values in settings['constraints']]
    missing = {name for name, _, _ in plan if name not in target.pose.bones}
    if missing:
        raise TransferError('Target is missing proportion bones: ' + ', '.join(sorted(missing)))
    return plan


def rigify_proportion_manifest(armature):
    """Read the saved integration map without importing or registering Rigify."""
    raw = armature.get('hhp_rigify_manifest') if armature else None
    if not raw:
        return {}
    try:
        result = json.loads(raw) if isinstance(raw, str) else dict(raw)
    except (TypeError, ValueError):
        return {}
    return result if isinstance(result, dict) else {}


def _proportion_source(armature, name):
    bone = armature.pose.bones.get(name)
    return next((c for c in bone.constraints if is_proportion_constraint(c)), None) if bone else None


def validate_proportion_controls(armature, data=None):
    """Reject a broken generated map before a transfer replaces any settings."""
    data = rigify_proportion_manifest(armature) if data is None else data
    native_names = set(data.get('native_bones', ()))
    for role, names in data.get('proportion_controls', {}).items():
        if role not in armature.pose.bones:
            raise TransferError('The native proportion bone is missing: ' + role)
        names = [names] if isinstance(names, str) else names
        for name in names:
            if name not in armature.pose.bones:
                raise TransferError('The Rigify proportion control is missing: ' + name)
            if name in native_names:
                raise TransferError('A Rigify proportion control must be separate from the native bone: ' + name)
    for role, name in data.get('proportion_pivots', {}).items():
        if name not in armature.pose.bones or name in native_names:
            raise TransferError('The independent proportion pivot is missing or invalid: ' + name)
        body = data.get('proportion_controls', {}).get(role, ())
        body = {body} if isinstance(body, str) else set(body)
        if body.intersection(b.name for b in armature.data.bones[name].parent_recursive):
            raise TransferError('The proportion pivot cannot inherit from the region it controls: ' + name)
    world_name = data.get('proportion_world')
    if world_name and (world_name not in armature.pose.bones or world_name in native_names):
        raise TransferError('The independent world proportion space is missing or invalid: ' + world_name)
    return data


def proportion_factor(armature, name):
    """Return the final regional multiplier, including partial strength and mute."""
    source = _proportion_source(armature, name)
    if source is None or proportion_constraint_muted(armature, name, source):
        return 1.0
    return 1.0 + (source.max_x - 1.0) * proportion_constraint_influence(armature, name, source)


def _set_rigify_proportion_multiplier(armature, bone, role, factor):
    """Multiply a generated control's scale without replacing its pose channels."""
    name = RIGIFY_PROPORTION_PREFIX + role
    constraint = bone.constraints.get(name)
    if constraint is not None and constraint.type != 'TRANSFORM':
        raise TransferError('Unexpected constraint named ' + name + ' on ' + bone.name)
    if constraint is None:
        constraint = bone.constraints.new('TRANSFORM')
        constraint.name = name
    for key, value in {
            'target': armature, 'subtarget': 'root',
            'owner_space': 'LOCAL', 'target_space': 'LOCAL',
            'map_from': 'LOCATION', 'map_to': 'SCALE',
            'mix_mode_scale': 'MULTIPLY', 'use_motion_extrapolate': False,
            'influence': 1.0, 'mute': False}.items():
        _set_proportion_value(constraint, key, value)
    for axis in 'xyz':
        _set_proportion_value(constraint, 'from_min_' + axis, -1.0)
        _set_proportion_value(constraint, 'from_max_' + axis, 1.0)
        _set_proportion_value(constraint, 'to_min_' + axis + '_scale', factor)
        _set_proportion_value(constraint, 'to_max_' + axis + '_scale', factor)
    return name


def _set_rigify_body_pivot(armature, bone, factor, pivot_name=None, world=False):
    """Scale the generated root around Daz hip while native root stays global."""
    from mathutils import Vector
    hip = armature.data.bones.get('hip')
    if hip is None:
        raise TransferError('The Rigify body proportion pivot requires the Daz hip')
    # The generated root is a child of the native root. Its rest origin may
    # differ from zero; express the hip offset in this bone's own local axes.
    pivot = bone.bone.matrix_local.inverted_safe() @ hip.head_local
    offset = Vector(pivot) * (1.0 - factor)
    name = RIGIFY_PROPORTION_PREFIX + 'Hip Pivot'
    constraint = bone.constraints.get(name)
    if constraint is not None and constraint.type != 'TRANSFORM':
        raise TransferError('Unexpected constraint named ' + name + ' on ' + bone.name)
    if constraint is None:
        constraint = bone.constraints.new('TRANSFORM')
        constraint.name = name
    for key, value in {
            'target': armature, 'subtarget': pivot_name or 'root',
            'owner_space': 'LOCAL', 'target_space': ('POSE' if world else 'CUSTOM') if pivot_name else 'LOCAL',
            'space_object': armature if pivot_name and not world else None,
            'space_subtarget': 'root' if pivot_name and not world else '',
            'map_from': 'LOCATION', 'map_to': 'LOCATION',
            'mix_mode': 'ADD', 'use_motion_extrapolate': bool(pivot_name),
            'influence': 1.0, 'mute': False}.items():
        _set_proportion_value(constraint, key, value)
    for index, axis in enumerate('xyz'):
        _set_proportion_value(constraint, 'from_min_' + axis, -1.0)
        _set_proportion_value(constraint, 'from_max_' + axis, 1.0)
        _set_proportion_value(constraint, 'to_min_' + axis, -(1.0 - factor) if pivot_name else offset[index])
        _set_proportion_value(constraint, 'to_max_' + axis, 1.0 - factor if pivot_name else offset[index])
    return name


def sync_proportion_controls(armature, data=None):
    """Update native ownership gates and Rigify's regional spaces in place.

    This runs only when settings change or are transferred, never on a pose
    update handler. All runtime following is handled by Blender constraints.
    The manifest's proportion_controls may map a role to one bone or to a
    list of scale-isolated controls (for example neck plus head).
    """
    data = validate_proportion_controls(armature, data)
    if not data:
        return
    active_property = data.get('active_property', 'hhp_rigify_active')
    if active_property not in armature:
        armature[active_property] = 0.0
    driven = set(data.get('driven', data.get('bindings', {}).keys()))
    native_names = set(data.get('native_bones', ()))
    controls = data.get('proportion_controls', {})
    expected = {}
    for role, names in controls.items():
        names = [names] if isinstance(names, str) else names
        factor = proportion_factor(armature, role)
        for name in names:
            bone = armature.pose.bones.get(name)
            if bone is None:
                raise TransferError('The Rigify proportion control is missing: ' + name)
            expected.setdefault(name, set()).add(
                _set_rigify_proportion_multiplier(armature, bone, role, factor))
            if role == 'hip':
                expected[name].add(_set_rigify_body_pivot(
                    armature, bone, factor, data.get('proportion_pivots', {}).get(role)))
    world_name = data.get('proportion_world')
    if world_name:
        bone = armature.pose.bones.get(world_name)
        if bone is None:
            raise TransferError('The Rigify world proportion space is missing: ' + world_name)
        factor = proportion_factor(armature, 'hip')
        expected.setdefault(world_name, set()).add(_set_rigify_proportion_multiplier(armature, bone, 'hip', factor))
        expected[world_name].add(_set_rigify_body_pivot(
            armature, bone, factor, data.get('proportion_pivots', {}).get('hip'), world=True))
    donor_mutes = {}
    for bone in armature.pose.bones:
        # Retain unrelated Rigify constraints exactly; remove only stale
        # regional constraints written by this integration.
        for constraint in tuple(bone.constraints):
            if (constraint.name.startswith(RIGIFY_PROPORTION_PREFIX)
                    and constraint.name not in expected.get(bone.name, ())):
                bone.constraints.remove(constraint)
        if bone.name not in native_names:
            continue
        previous = proportion_saved_mutes(bone)
        saved = dict(previous)
        for source in bone.constraints:
            if not (is_proportion_constraint(source) or is_proportion_follower(source)):
                continue
            if is_proportion_settings_only(armature, bone.name, source):
                _prepare_proportion_settings(armature, bone, source)
                saved[source.name] = proportion_constraint_muted(armature, bone.name, source)
                continue
            if is_proportion_constraint(source):
                muted = proportion_constraint_muted(armature, bone.name, source)
            else:
                donor_name = source.name[len(PROPORTION_FOLLOW_PREFIX):]
                if donor_name not in donor_mutes:
                    donor = _proportion_source(armature, donor_name)
                    donor_mutes[donor_name] = (donor is None or proportion_constraint_muted(
                        armature, donor_name, donor))
                muted = donor_mutes[donor_name]
            saved[source.name] = muted
            if bone.name in driven:
                _ensure_proportion_mute_driver(
                    armature, source, PROPORTION_GATE + ' or ' + str(int(muted)), active_property)
            else:
                animation = armature.animation_data
                curve = animation.drivers.find(source.path_from_id('mute')) if animation else None
                if curve and any(v.name in {PROPORTION_GATE, 'hhp5_prop_rig'}
                                 for v in curve.driver.variables):
                    source.driver_remove('mute')
                _set_proportion_value(source, 'mute', muted)
        _save_proportion_mutes(bone, saved)



def sync_proportions(source, target, settings=None):
    """Map primary settings by rig role, then regenerate target-owned effects."""
    if source == target:
        return 0
    settings = capture_proportions(source) if settings is None else settings
    plan = proportion_transfer_plan(source, target, settings)
    originals = [(bone, constraint) for bone in target.pose.bones
                 for constraint in bone.constraints if is_proportion_constraint(constraint)]
    staged = []
    try:
        for name, index, values in plan:
            bone = target.pose.bones[name]
            copied = bone.constraints.new('LIMIT_SCALE')
            staged.append((bone, index, values['name'], copied))
            for prop, value in values.items():
                if isinstance(value, bpy.types.ID) and value == source:
                    value = target
                setattr(copied, prop, value)
    except Exception:
        for bone, _, _, copied in reversed(staged):
            bone.constraints.remove(copied)
        raise
    for bone, constraint in originals:
        remove_proportion_constraint(target, bone, constraint)
    for bone, index, name, copied in staged:
        copied.name = name
        bone.constraints.move(list(bone.constraints).index(copied), min(index, len(bone.constraints) - 1))
    sync_proportion_distribution_ui(target)
    sync_proportion_controls(target)
    target.update_tag()
    return len(staged)


def collection_tree(collection):
    result = set()
    pending = [collection]
    while pending:
        current = pending.pop()
        if current not in result:
            result.add(current)
            pending.extend(current.children)
    return result


def source_collection(context, source, targets):
    """Keep the old top-level boundary, descending if it also contains a target."""
    def find(collection):
        if source.name not in collection.all_objects:
            return None
        if not any(target.name in collection.all_objects for target in targets):
            return collection
        for child in collection.children:
            found = find(child)
            if found:
                return found
        return None

    for collection in context.scene.collection.children:
        found = find(collection)
        if found:
            return found
    # With action None, a shared collection is still a reference-exclusion boundary.
    return next((c for c in source.users_collection if c != context.scene.collection), None)


# Do not descend into computed back-references or bulk geometry arrays. ID links
# in attributes/geometry are not Object pointers; modifiers and nodes hold those.
_SKIP_RNA = {
    'rna_type', 'id_data', 'original', 'library', 'override_library',
    'library_weak_reference', 'users_collection', 'users_scene',
    'children', 'children_recursive', 'all_objects', 'objects',
    'vertices', 'edges', 'loops', 'polygons', 'loop_triangles',
    'loop_triangle_polygons', 'vertex_normals', 'polygon_normals',
    'corner_normals', 'attributes', 'color_attributes', 'uv_layers',
    'vertex_colors', 'points', 'bezier_points', 'data',
}


def reference_slots(root):
    """Yield (container, key, is_custom, ID) without crossing another ID owner.

    Includes nested driver targets, constraints, pose bones, node sockets and
    nested custom properties. Collection membership is never a reference slot.
    """
    visited = set()

    def custom_slots(group):
        try:
            keys = list(group.keys())
        except (AttributeError, TypeError):
            return
        for key in keys:
            value = group[key]
            if isinstance(value, bpy.types.ID):
                yield group, key, True, value
            elif isinstance(value, IDPropertyGroup):
                yield from custom_slots(value)

    def walk(struct):
        pointer = struct.as_pointer()
        if pointer in visited:
            return
        visited.add(pointer)
        yield from custom_slots(struct)
        for prop in struct.bl_rna.properties:
            key = prop.identifier
            # Object.data is an editable ID link, unlike vertex/key-block data.
            if key in _SKIP_RNA and not (key == 'data' and isinstance(struct, bpy.types.Object)):
                continue
            if prop.type not in {'POINTER', 'COLLECTION'}:
                continue
            try:
                value = getattr(struct, key)
            except (AttributeError, RuntimeError):
                continue
            if prop.type == 'POINTER':
                if isinstance(value, bpy.types.ID):
                    if not prop.is_readonly:
                        yield struct, key, False, value
                    elif value.is_embedded_data:
                        yield from walk(value)
                elif isinstance(value, bpy.types.bpy_struct):
                    owner = getattr(value, 'id_data', None)
                    if owner is None or owner == struct.id_data:
                        yield from walk(value)
            else:
                for index, item in enumerate(value):
                    if isinstance(item, bpy.types.ID):
                        if key == 'materials':
                            yield value, index, True, item
                    elif isinstance(item, bpy.types.bpy_struct):
                        owner = getattr(item, 'id_data', None)
                        if owner is None or owner == struct.id_data:
                            yield from walk(item)

    yield from walk(root)


def _assign_slot(container, key, custom, value):
    if custom:
        container[key] = value
    else:
        setattr(container, key, value)


def replace_external_references(replacements, protected_objects, protected_collections):
    """Selective ID remapping with copies for affected shared source data.

    Blender's global ID.user_remap cannot honor collection exclusions. Use its
    user graph to limit traversal, and keep the source's data/material/node tree
    branches intact when those branches are also used by an external object.
    """
    users = bpy.data.user_map()
    dependencies = {}
    for dependency, owners in users.items():
        for owner in owners:
            dependencies.setdefault(owner, set()).add(dependency)
    boundaries = (bpy.types.Object, bpy.types.Collection, bpy.types.Scene)
    protected = set(protected_objects) | set(protected_collections)
    pending = list(protected_objects)
    while pending:
        for dependency in dependencies.get(pending.pop(), ()):
            if not isinstance(dependency, boundaries) and dependency not in protected:
                protected.add(dependency)
                pending.append(dependency)

    affected = set(replacements)
    pending = list(affected)
    while pending:
        for owner in users.get(pending.pop(), ()):
            if owner not in affected:
                affected.add(owner)
                if not isinstance(owner, boundaries):
                    pending.append(owner)

    copies = {}
    failures = []
    changed = 0

    def rewrite_slot(container, key, custom, value):
        nonlocal changed
        replacement = replacements.get(value)
        if replacement is None and value in protected and value in affected:
            if isinstance(value, boundaries):
                return
            replacement = copies.get(value)
            if replacement is None:
                try:
                    replacement = value.copy()
                except (AttributeError, RuntimeError, TypeError):
                    failures.append("Data that cannot be copied")
                    return
                copies[value] = replacement
                rewrite(replacement)
                # Mesh.copy also copies its otherwise read-only Key datablock.
                shape_keys = getattr(replacement, 'shape_keys', None)
                if shape_keys is not None:
                    rewrite(shape_keys)
        if replacement is None or replacement == value:
            return
        try:
            _assign_slot(container, key, custom, replacement)
            changed += 1
        except (AttributeError, RuntimeError, TypeError, ValueError):
            failures.append("A read-only or incompatible reference")

    def rewrite(owner):
        if not owner.is_editable:
            failures.append("Linked or read-only data")
            return
        # MaterialSlot and active_material are views onto the current geometry.
        # Remap geometry before capturing those views, or a source proxy can
        # write its old materials into the destination mesh after a data swap.
        is_object = isinstance(owner, bpy.types.Object)
        if is_object and owner.data is not None:
            rewrite_slot(owner, 'data', False, owner.data)
        for container, key, custom, value in list(reference_slots(owner)):
            if is_object and container == owner and key == 'data' and not custom:
                continue
            rewrite_slot(container, key, custom, value)
        owner.update_tag()

    for owner in affected - protected - set(replacements):
        rewrite(owner)
    return changed, failures


def remap_collection_shape_key_drivers(object_replacements):
    """Retarget shape-key driver variables, isolating data shared outside scope."""
    failures = []
    groups = {}
    for obj, replacements in object_replacements.items():
        if getattr(getattr(obj, 'data', None), 'shape_keys', None) is None:
            continue
        groups.setdefault((obj.data, frozenset(replacements.items())), []).append(obj)

    for (mesh, mapping_items), objects in groups.items():
        replacements = dict(mapping_items)
        keys = mesh.shape_keys
        animation = keys.animation_data
        if animation is None:
            continue
        if not any(
            target.id in replacements
            for fcurve in animation.drivers
            for variable in fcurve.driver.variables
            for target in variable.targets
        ):
            continue
        try:
            if any(not obj.is_editable for obj in objects):
                raise ValueError("The asset object is read-only")
            # Data copies carry their shape keys and drivers with them. Preserve
            # other characters when their objects share this mesh datablock.
            outside_users = any(
                getattr(obj, 'data', None) == mesh and obj not in objects
                for obj in bpy.data.objects
            )
            if outside_users:
                mesh = mesh.copy()
                for obj in objects:
                    obj.data = mesh
                keys = mesh.shape_keys
            if not keys.is_editable:
                raise ValueError("The asset shape keys are read-only")
            for fcurve in keys.animation_data.drivers:
                for variable in fcurve.driver.variables:
                    for target in variable.targets:
                        replacement = replacements.get(target.id)
                        if replacement is not None:
                            target.id = replacement
            keys.update_tag()
            for obj in objects:
                obj.update_tag()
        except (AttributeError, RuntimeError, TypeError, ValueError) as error:
            failures.append(
                f"Could not remap shape-key drivers on '{objects[0].name}': {error}"
            )
    return failures


def remap_collection_shader_drivers(object_replacements):
    """Copy affected shader branches and retarget their armature driver inputs."""
    failures = []
    scopes = {}
    for obj, replacements in object_replacements.items():
        if getattr(obj, 'material_slots', None):
            scopes.setdefault(frozenset(replacements.items()), []).append(obj)

    def driver_targets(owner):
        animation = getattr(owner, 'animation_data', None)
        if animation is not None:
            for curve in animation.drivers:
                for variable in curve.driver.variables:
                    yield from variable.targets

    def remap(owner, replacements):
        if owner is None:
            return
        for target in driver_targets(owner):
            replacement = replacements.get(target.id)
            if replacement is not None:
                target.id = replacement
        owner.update_tag()

    for mapping_items, objects in scopes.items():
        replacements = dict(mapping_items)
        materials = {slot.material for obj in objects for slot in obj.material_slots
                     if slot.material is not None}
        materials.update(material for obj in objects
                         for material in getattr(getattr(obj, 'data', None), 'materials', ())
                         if material is not None)
        # Discover the graph iteratively: groups may be reused at any depth.
        parents = {}
        groups = set()
        trees = set()
        pending = [mat.node_tree for mat in materials if mat.node_tree is not None]
        while pending:
            tree = pending.pop()
            if tree in trees:
                continue
            trees.add(tree)
            for node in tree.nodes:
                child = getattr(node, 'node_tree', None)
                if child is not None:
                    groups.add(child)
                    parents.setdefault(child, set()).add(tree)
                    pending.append(child)
        affected = {tree for tree in trees
                    if any(target.id in replacements for target in driver_targets(tree))}
        pending = list(affected)
        while pending:
            for parent in parents.get(pending.pop(), ()):
                if parent not in affected:
                    affected.add(parent)
                    pending.append(parent)
        material_copies = {}
        try:
            # Copy only branches leading to drivers that reference the old rig.
            # Originals stay usable by other characters, worlds, or materials.
            group_copies = {tree: tree.copy() for tree in groups & affected}

            def update_tree(tree):
                if tree is None:
                    return
                for node in tree.nodes:
                    child = getattr(node, 'node_tree', None)
                    if child in group_copies:
                        node.node_tree = group_copies[child]
                remap(tree, replacements)

            for copied_tree in group_copies.values():
                update_tree(copied_tree)
            for material in materials:
                if material.node_tree not in affected and not any(
                    target.id in replacements for target in driver_targets(material)
                ):
                    continue
                copied_material = material.copy()
                remap(copied_material, replacements)
                update_tree(copied_material.node_tree)
                material_copies[material] = copied_material
        except (AttributeError, RuntimeError, TypeError, ValueError) as error:
            failures.append(f"Could not prepare shader driver remapping: {error}")
            continue

        # Install corrected originals on the geometry, not in temporary object
        # overrides. Optimized-material rebuilds read these data-linked slots.
        data_groups = {}
        for obj in objects:
            data = getattr(obj, 'data', None)
            if getattr(data, 'materials', None) is not None:
                data_groups.setdefault(data, []).append(obj)
        for data, data_objects in data_groups.items():
            replacements_by_index = {
                index: material_copies[material]
                for index, material in enumerate(data.materials)
                if material in material_copies
            }
            if not replacements_by_index:
                continue
            try:
                if any(not obj.is_editable for obj in data_objects):
                    raise ValueError("The asset object is read-only")
                # Keep sharing within this character. Isolate geometry only
                # when another character/object outside this scope also uses it.
                if any(getattr(obj, 'data', None) == data and obj not in data_objects
                       for obj in bpy.data.objects) or not data.is_editable:
                    data = data.copy()
                    for obj in data_objects:
                        obj.data = data
                for index, material in replacements_by_index.items():
                    data.materials[index] = material
                data.update_tag()
            except (AttributeError, RuntimeError, TypeError, ValueError) as error:
                failures.append(
                    f"Could not remap data-linked shader materials on '{data_objects[0].name}': {error}"
                )
        for obj in objects:
            for slot in obj.material_slots:
                # Existing object overrides are independent of the originals.
                if slot.link != 'OBJECT':
                    continue
                replacement = material_copies.get(slot.material)
                if replacement is None:
                    continue
                try:
                    if not obj.is_editable:
                        raise ValueError("The asset object is read-only")
                    slot.material = replacement
                    obj.update_tag()
                except (AttributeError, RuntimeError, TypeError, ValueError) as error:
                    failures.append(
                        f"Could not remap shader drivers on '{obj.name}': {error}"
                    )
    return failures


class TransferState:
    """Snapshot mappings before modifier modes can change armature associations."""

    def __init__(self, operator, context, source, targets, mesh_pairs):
        optimized_pending.clear('animation')
        self.source = source
        self.targets = list(dict.fromkeys(targets))
        self.mesh_pairs = [(a, b) for a, b in mesh_pairs if a is not None and b is not None]
        self.optimized_states = [
            (a, b, optimized_materials.capture_state(a)) for a, b in self.mesh_pairs
        ] if getattr(operator, 'update_optimized_materials', False) else []
        self.replace_armature_references = (
            operator.replace_armature_references
            and operator.transfer_modifiers not in {'FULL', 'ARMATURE_SWAP'}
        )
        if source.type != 'ARMATURE' or any(target.type != 'ARMATURE' for target in self.targets):
            raise TransferError("Select armatures, or meshes with armature modifiers")
        if not self.targets or source in self.targets:
            raise TransferError("Select a different source and target armature")
        if any(not target.is_editable for target in self.targets):
            raise TransferError("The target armature must be editable; make it local or use a library override")
        self.proportion_settings = capture_proportions(source)
        for target in self.targets:
            proportion_transfer_plan(source, target, self.proportion_settings)
        if self.replace_armature_references and len(self.targets) != 1:
            raise TransferError("Reference replacement needs one target armature; select one target or turn the checkbox off")
        self.collection = source_collection(context, source, self.targets)
        self.collection_visibility = ((self.collection.hide_viewport, self.collection.hide_render)
                                      if self.collection else None)
        self.collections = collection_tree(self.collection) if self.collection else set()
        self.protected_objects = {source}
        for collection in self.collections:
            self.protected_objects.update(collection.objects)
        # Membership in another collection must not protect unrelated objects in
        # that collection. Reference exclusions use the same source subtree as
        # the collection action; objects in it stay protected wherever else linked.

        action = operator.source_collection_action
        if action != 'NONE' and self.collection is not None:
            contents = set(self.collection.all_objects)
            destinations = set(self.targets) | {b for a, b in self.mesh_pairs}
            if contents & destinations:
                raise TransferError("Source and target share a collection; separate them or choose collection action None")
            if action == 'DELETE':
                if (getattr(operator, 'shapekey_data_clash_analyzer', False)
                        and getattr(operator, 'transfer_unavailable_data', False)):
                    raise TransferError("The shape-key clash dialog needs the source; turn it off or choose None/Disable")
                tree = collection_tree(self.collection)
                if any(not item.is_editable for item in tree | contents):
                    raise TransferError("Cannot delete linked or read-only source collection contents")
                # Delete means remove these objects/collections globally, even
                # when they are linked into other collections or scenes.

        self.replacements = {source: self.targets[0]}
        for old, new in self.mesh_pairs:
            if old in self.replacements and self.replacements[old] != new:
                if self.replace_armature_references:
                    raise TransferError("Reference replacement needs one target for each source mesh")
            self.replacements[old] = new
        self.object_replacements = dict(self.replacements)
        self.refresh_data_replacements()
        self.shape_key_driver_swaps = []
        if operator.transfer_modifiers in {'FULL', 'ARMATURE_SWAP'}:
            for source_mesh, target_mesh in self.mesh_pairs:
                new_armature = next((m.object for m in source_mesh.modifiers
                                     if m.type == 'ARMATURE' and m.object), None)
                old_armature = next((m.object for m in target_mesh.modifiers
                                     if m.type == 'ARMATURE' and m.object), None)
                if not old_armature or not new_armature or old_armature == new_armature:
                    continue
                objects = {target_mesh}
                for collection in target_mesh.users_collection:
                    objects.update(collection.all_objects)
                self.shape_key_driver_swaps.append(
                    (target_mesh, old_armature, new_armature, objects))

    def refresh_data_replacements(self):
        # Shape-key transfer may have just created a target Key datablock.
        self.replacements = dict(self.object_replacements)
        for old, new in self.object_replacements.items():
            if old.data is not None and new.data is not None and old.data != new.data:
                self.replacements[old.data] = new.data
                old_keys = getattr(old.data, 'shape_keys', None)
                new_keys = getattr(new.data, 'shape_keys', None)
                if old_keys is not None and new_keys is not None and old_keys != new_keys:
                    self.replacements[old_keys] = new_keys

    def finish(self, operator, context):
        for target in self.targets:
            sync_proportions(self.source, target, self.proportion_settings)
        failures = []
        if preserve_mouth_shape_enabled(operator):
            # Missing-key transfer has now finished. Discover the target keys
            # here so newly copied presets and newly created Key data qualify.
            # Run before cleanup so shared mesh data can be separated safely.
            for source_mesh, target_mesh in self.mesh_pairs:
                warning = preserve_transferred_source_mouth_shape(
                    source_mesh, target_mesh, getattr(operator, 'update_mouth_shape_in_presets', True))
                if warning:
                    operator.report({'WARNING'}, warning)
                    failures.append(warning)
        driver_replacements = {}
        for mesh, old_armature, new_armature, objects in self.shape_key_driver_swaps:
            if not any(m.type == 'ARMATURE' and m.object == new_armature
                       for m in mesh.modifiers):
                continue
            for obj in objects:
                replacements = driver_replacements.setdefault(obj, {})
                replacements[old_armature] = new_armature
                if old_armature.data != new_armature.data:
                    replacements[old_armature.data] = new_armature.data
        driver_failures = remap_collection_shape_key_drivers(driver_replacements)
        driver_failures.extend(remap_collection_shader_drivers(driver_replacements))
        for warning in driver_failures:
            operator.report({'WARNING'}, warning)
        failures.extend(driver_failures)
        if self.replace_armature_references:
            self.refresh_data_replacements()
            _, reference_failures = replace_external_references(
                self.replacements, self.protected_objects, self.collections)
            failures.extend(reference_failures)
        if self.optimized_states:
            result_meshes = list(dict.fromkeys(b for _, b, _ in self.optimized_states))
            try:
                context.view_layer.update()
                optimized_materials.refresh(context, result_meshes)
                for source_mesh, target_mesh, enabled in self.optimized_states:
                    optimized_materials.set_state(target_mesh, enabled)
                if (getattr(operator, 'shapekey_data_clash_analyzer', False)
                        and getattr(operator, 'transfer_unavailable_data', False)):
                    optimized_pending.remember_animation(
                        context, self.optimized_states, self.collection, self.collection_visibility, 'hhp_')
            except (RuntimeError, ValueError, TypeError) as error:
                for mesh in result_meshes:
                    optimized_materials.set_state(mesh, False)
                warning = f"Optimized materials could not be updated: {error}"
                operator.report({'WARNING'}, warning)
                failures.append(warning)
            finally:
                for source_mesh, _, enabled in self.optimized_states:
                    if source_mesh not in result_meshes:
                        optimized_materials.set_state(source_mesh, enabled)
        if failures:
            operator.report({'WARNING'},
                            "Some transfer updates could not be completed; source collection was kept unchanged")
        elif self.collection is not None:
            if operator.source_collection_action == 'DISABLE':
                self.collection.hide_viewport = True
                self.collection.hide_render = True
            elif operator.source_collection_action == 'DELETE':
                tree = collection_tree(self.collection)
                for obj in list(self.collection.all_objects):
                    # Remove the object itself, not just its source-collection link.
                    bpy.data.objects.remove(obj, do_unlink=True)
                # Shared actions/materials remain in use by the target and survive
                # the optional orphan purge after the collections are removed.
                for collection in tree:
                    bpy.data.collections.remove(collection)
                purge_transfer_orphans(operator)
        context.view_layer.update()
