"""HHP5 global-root hierarchy and scale inheritance support.

The Daz bones deliberately ignore inherited scale so that an individual
proportion control does not resize its descendants. These helpers preserve
that behavior while applying the global root scale once to the whole rig.
"""

import json
from contextlib import contextmanager

import bpy
from bpy.props import FloatProperty
from mathutils import Vector


SCALE_CONSTRAINT = '(HHP) Global Root Scale'
HIDDEN_COLLECTION = '(HHP) Hidden'
UNIFORM_SCALE = 'Uniform Scale'
UNIFORM_MARKER = 'hhp5_uniform_root'
_KEYMAPS = []
FOLLOW_HELPERS = {
    'Genitals': ('Genitalspull', 'HHP Root Follow Genitals'),
    'Anus': ('AnusPull', 'HHP Root Follow Anus'),
}


@contextmanager
def _edit_armature(arm):
    active = bpy.context.view_layer.objects.active
    mode = active.mode if active else 'OBJECT'
    selected = list(bpy.context.selected_objects)
    hidden, viewport_hidden = arm.hide_get(), arm.hide_viewport
    try:
        if active and active.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        for obj in selected:
            obj.select_set(False)
        arm.hide_viewport = False
        arm.hide_set(False)
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode='EDIT')
        yield arm.data.edit_bones
    finally:
        if bpy.context.object and bpy.context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        arm.select_set(False)
        for obj in selected:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = active
        arm.hide_set(hidden)
        arm.hide_viewport = viewport_hidden
        if active and mode != 'OBJECT':
            bpy.ops.object.mode_set(mode=mode)


def _remove_child_of(arm, child, target):
    removed = 0
    for constraint in list(arm.pose.bones[child].constraints):
        if (constraint.type == 'CHILD_OF' and constraint.target == arm
                and constraint.subtarget == target):
            arm.pose.bones[child].constraints.remove(constraint)
            removed += 1
    return removed


def _ensure_uniform_root(arm):
    """Keep global scale uniform without a transform-channel dependency cycle."""
    root = arm.pose.bones['root']
    scale_path = root.path_from_id('scale')
    property_path = root.path_from_id() + '["' + UNIFORM_SCALE + '"]'
    existing = {fc.array_index: fc for fc in arm.animation_data.drivers
                if fc.data_path == scale_path} if arm.animation_data else {}
    for curve in existing.values():
        variables = curve.driver.variables
        owned = (len(variables) == 1 and variables[0].type == 'SINGLE_PROP'
                 and variables[0].targets[0].id == arm
                 and variables[0].targets[0].data_path == property_path)
        if not owned:
            raise ValueError('The root already has an unrelated scale driver')
    if UNIFORM_MARKER not in arm:
        arm['hhp5_uniform_root_original_locks'] = json.dumps(list(root.lock_scale))
    if UNIFORM_SCALE not in root:
        root[UNIFORM_SCALE] = max(float(root.scale.x), .001)
    root.id_properties_ui(UNIFORM_SCALE).update(
        default=1.0, min=.001, soft_min=.1, soft_max=3.0,
        description='Uniform size of the whole character; press S with the root selected')
    for axis in range(3):
        curve = root.driver_add('scale', axis)
        driver = curve.driver
        driver.type = 'SCRIPTED'
        driver.use_self = False
        while driver.variables:
            driver.variables.remove(driver.variables[0])
        variable = driver.variables.new()
        variable.name, variable.type = 'global_scale', 'SINGLE_PROP'
        variable.targets[0].id = arm
        variable.targets[0].data_path = property_path
        driver.expression = 'max(global_scale, 0.001)'
    root.lock_scale = (True, True, True)
    arm[UNIFORM_MARKER] = 1


def repair_hierarchy(arm):
    """Repair an HHP5 template in place, leaving anatomical rest positions intact.

    This explicit template migration is separate from control-rig building.
    Genital Pull controls retain their authored location/rotation behavior and
    continue to ignore Pull scale, which their former Child Of constraints did.
    Repeated calls do not add bones, constraints, or display offsets.
    """
    required = {'root', 'hip', 'hip(drv)', 'pelvis', 'head', 'Eye Controller'}
    required.update(FOLLOW_HELPERS)
    required.update(item[0] for item in FOLLOW_HELPERS.values())
    if arm.type != 'ARMATURE' or not required.issubset(arm.data.bones.keys()):
        raise ValueError('The HHP5 template is missing required root/body bones')
    root = arm.data.bones['root']
    old_head = root.head_local.copy()
    # Custom shape translation is in bone units, before shape/bone-size scaling.
    # Keep the existing shared widget visually centered when relocating its bone.
    display_offset = root.matrix_local.to_3x3().inverted_safe() @ old_head
    helper_collection = (arm.data.collections.get(HIDDEN_COLLECTION)
                         or arm.data.collections.new(HIDDEN_COLLECTION))
    helper_collection.is_visible = False
    needs_edit = old_head.length > 1e-8 or root.parent is not None
    needs_edit |= arm.data.bones['Eye Controller'].parent != arm.data.bones['head']
    for child, (_, helper_name) in FOLLOW_HELPERS.items():
        helper = arm.data.bones.get(helper_name)
        needs_edit |= helper is None or arm.data.bones[child].parent != helper
        if helper:
            needs_edit |= helper.parent != arm.data.bones['pelvis']
    created = []
    if needs_edit:
        with _edit_armature(arm) as bones:
            root = bones['root']
            direction = root.tail - root.head
            root.parent = None
            root.use_connect = False
            root.head = (0, 0, 0)
            root.tail = direction if direction.length > 1e-6 else Vector((0, .4, 0))
            root.use_deform = False
            for child, (pull, helper_name) in FOLLOW_HELPERS.items():
                helper = bones.get(helper_name)
                if helper is None:
                    source = bones[pull]
                    helper = bones.new(helper_name)
                    helper.head, helper.tail, helper.roll = source.head, source.tail, source.roll
                    created.append(helper_name)
                helper.parent = bones['pelvis']
                helper.use_connect = False
                helper.inherit_scale = 'FULL'
                helper.use_deform = False
                for collection in list(helper.collections):
                    collection.unassign(helper)
                helper_collection.assign(helper)
                bones[child].use_connect = False
                bones[child].parent = helper
            bones['Eye Controller'].use_connect = False
            bones['Eye Controller'].parent = bones['head']
        root_pose = arm.pose.bones['root']
        if root_pose.custom_shape and root_pose.custom_shape_transform is None:
            root_pose.custom_shape_translation += display_offset
    removed = _remove_child_of(arm, 'Eye Controller', 'head')
    for child, (pull, helper_name) in FOLLOW_HELPERS.items():
        removed += _remove_child_of(arm, child, pull)
        pb = arm.pose.bones[helper_name]
        if hasattr(pb, 'hide'):
            pb.hide = True
        else:
            pb.bone.hide = True
        pb.bone.hide_select = True
        for kind in ('COPY_LOCATION', 'COPY_ROTATION'):
            name = '(HHP) Follow ' + pull + (' Location' if kind == 'COPY_LOCATION' else ' Rotation')
            constraint = pb.constraints.get(name)
            if constraint is None:
                constraint = pb.constraints.new(kind)
                constraint.name = name
            if constraint.type != kind:
                raise ValueError('Unexpected constraint at ' + helper_name + ': ' + name)
            constraint.target, constraint.subtarget = arm, pull
            constraint.owner_space = constraint.target_space = 'POSE'
            constraint.influence = 1.0
            if kind == 'COPY_ROTATION':
                constraint.mix_mode = 'REPLACE'
    _ensure_uniform_root(arm)
    arm.update_tag()
    bpy.context.view_layer.update()
    return {'created_helpers': created, 'removed_redundant_child_of': removed}


def ensure_scale_compensation(arm):
    """Add/refresh global scale constraints without modifying any bone hierarchy.

    Call after storing a new control-rig manifest. Original driven bones then
    receive root scale in Daz mode; Rigify bindings supply it in control mode.
    Refreshing existing constraints is necessary when building on a repaired
    template that already has Daz-only root compensation.
    """
    if arm.type != 'ARMATURE' or 'root' not in arm.pose.bones:
        raise ValueError('The HHP5 armature has no root bone')
    data = json.loads(arm['hhp_rigify_manifest']) if arm.get('hhp_rigify_manifest') else {}
    driven = set(data.get('driven', ()))
    native = set(data.get('native_bones', ()))
    created, gated = 0, 0
    for pb in arm.pose.bones:
        if ((native and pb.name not in native) or pb.name == 'root' or pb.bone.inherit_scale != 'NONE'
                or pb.name.endswith('(drv)') or pb.name in set(data.get('generated_bones', ()))):
            continue
        constraint = pb.constraints.get(SCALE_CONSTRAINT)
        if constraint is None:
            constraint = pb.constraints.new('COPY_SCALE')
            constraint.name = SCALE_CONSTRAINT
            created += 1
        if constraint.type != 'COPY_SCALE':
            raise ValueError('Unexpected constraint using reserved name: ' + SCALE_CONSTRAINT)
        constraint.target, constraint.subtarget = arm, 'root'
        constraint.owner_space = constraint.target_space = 'POSE'
        constraint.use_offset = True
        constraint.use_x = constraint.use_y = constraint.use_z = True
        constraint.use_make_uniform = False
        constraint.mute = False
        # Only this module's reserved constraint/driver is rewritten.
        constraint.driver_remove('influence')
        if pb.name in driven:
            fc = constraint.driver_add('influence')
            driver = fc.driver
            driver.type = 'SCRIPTED'
            while driver.variables:
                driver.variables.remove(driver.variables[0])
            variable = driver.variables.new()
            variable.name, variable.type = 'rig', 'SINGLE_PROP'
            variable.targets[0].id = arm
            variable.targets[0].data_path = '["hhp_rigify_active"]'
            driver.expression = '1-rig'
            gated += 1
        else:
            constraint.influence = 1.0
    arm.update_tag()
    bpy.context.view_layer.update()
    return {'created_scale_constraints': created, 'gated_native_constraints': gated}


def root_scale(arm):
    """Return evaluated armature-space root scale, excluding object scale."""
    evaluated = arm.evaluated_get(bpy.context.evaluated_depsgraph_get())
    return evaluated.pose.bones['root'].matrix.to_scale()


def uncompensated_basis(arm, pb, basis, force=False):
    """Remove this module's scale contribution when assigning a visual matrix.

    ``basis`` is the result of Bone.convert_local_to_pose(..., invert=True).
    ``force`` applies the compensation even while a mode gate disables it,
    allowing a caller to prepare channels before changing the rig mode.
    """
    result = basis.copy()
    constraint = pb.constraints.get(SCALE_CONSTRAINT)
    if constraint is None or constraint.mute:
        return result
    influence = 1.0 if force else constraint.influence
    factors = root_scale(arm)
    for axis in range(3):
        factor = 1.0 + influence * (factors[axis] - 1.0)
        if abs(factor) < 1e-8:
            raise ValueError('A zero root scale cannot be inverted for pose snapping')
        for row in range(3):
            result[row][axis] /= factor
    return result


def _root_for_scale(context):
    arm = context.object
    if not arm or arm.type != 'ARMATURE' or arm.mode != 'POSE' or not arm.get(UNIFORM_MARKER):
        return None
    root = context.active_pose_bone
    if root is None or root.name != 'root' or UNIFORM_SCALE not in root:
        return None
    selected = root.select if hasattr(root, 'select') else root.bone.select
    return root if selected else None


def _apply_uniform_value(arm, root, value):
    root[UNIFORM_SCALE] = max(.001, float(value))
    arm.update_tag()
    bpy.context.view_layer.update()


def _key_uniform_scale(context, root):
    if context.scene.tool_settings.use_keyframe_insert_auto:
        # Imported here because the runtime also registers this module.
        from .hhp_rigify import _keying_action_slot
        with _keying_action_slot(root.id_data):
            root.keyframe_insert(data_path='["' + UNIFORM_SCALE + '"]', group='HHP5 Root')


class HHP_OT_root_uniform_scale(bpy.types.Operator):
    """Scale the whole character uniformly with the selected root"""
    bl_idname = 'hhp.root_uniform_scale'
    bl_label = 'Scale HHP5 Root'
    bl_description = ('Scale the entire character uniformly; move the mouse or type a factor, '
                      'hold Shift for precision, and press Enter to confirm')
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}

    factor: FloatProperty(name='Scale Factor', default=1.0, min=.001, max=1e6, soft_max=3.0)

    @classmethod
    def poll(cls, context):
        return _root_for_scale(context) is not None

    def execute(self, context):
        root = _root_for_scale(context)
        if root is None:
            return {'CANCELLED'}
        _apply_uniform_value(context.object, root, root[UNIFORM_SCALE] * self.factor)
        _key_uniform_scale(context, root)
        return {'FINISHED'}

    def invoke(self, context, event):
        self._root = _root_for_scale(context)
        if self._root is None:
            return {'CANCELLED'}
        self._arm = context.object
        self._initial = float(self._root[UNIFORM_SCALE])
        self._mouse_x = event.mouse_x
        self._number = ''
        self.factor = 1.0
        context.window_manager.modal_handler_add(self)
        if context.window:
            context.window.cursor_modal_set('SCROLL_X')
        self._header(context)
        return {'RUNNING_MODAL'}

    def _header(self, context):
        if context.area:
            context.area.header_text_set(
                'Root Scale: %.4f  |  Factor: %s  |  Shift: precise  |  Enter/LMB: confirm  |  Esc/RMB: cancel'
                % (self._root[UNIFORM_SCALE], self._number or ('%.4f' % self.factor)))
            context.area.tag_redraw()

    def _finish(self, context, cancel=False):
        try:
            if cancel:
                _apply_uniform_value(self._arm, self._root, self._initial)
            else:
                _key_uniform_scale(context, self._root)
        except ReferenceError:
            cancel = True
        finally:
            try:
                if context.area:
                    context.area.header_text_set(None)
                    context.area.tag_redraw()
                if context.window:
                    context.window.cursor_modal_restore()
            except ReferenceError:
                pass
        return {'CANCELLED'} if cancel else {'FINISHED'}

    def modal(self, context, event):
        try:
            return self._modal(context, event)
        except ReferenceError:
            return self._finish(context, cancel=True)

    def _modal(self, context, event):
        if event.type == 'WINDOW_DEACTIVATE':
            return self._finish(context, cancel=True)
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            return self._finish(context, cancel=True)
        if event.type in {'RET', 'NUMPAD_ENTER', 'LEFTMOUSE'} and event.value == 'PRESS':
            return self._finish(context)
        if event.type == 'MOUSEMOVE':
            delta = event.mouse_x - self._mouse_x
            self._mouse_x = event.mouse_x
            if not self._number:
                self.factor = min(1e6, max(.001, self.factor * 2.0 ** max(-20, min(20,
                    delta / 200.0 * (.1 if event.shift else 1.0)))))
                _apply_uniform_value(self._arm, self._root, self._initial * self.factor)
                self._header(context)
            return {'RUNNING_MODAL'}
        if event.value == 'PRESS':
            character = getattr(event, 'unicode', '')
            keypad = {'NUMPAD_' + str(n): str(n) for n in range(10)}
            character = keypad.get(event.type, '.' if event.type == 'NUMPAD_PERIOD' else character)
            if event.type in {'BACK_SPACE', 'DEL'}:
                self._number = self._number[:-1] if event.type == 'BACK_SPACE' else ''
            elif character and (character in '0123456789' or (character == '.' and '.' not in self._number)):
                if len(self._number) < 12:
                    self._number += character
            else:
                return {'RUNNING_MODAL'}
            if self._number and self._number != '.':
                self.factor = min(1e6, max(.001, float(self._number)))
            elif not self._number:
                self.factor = 1.0
            _apply_uniform_value(self._arm, self._root, self._initial * self.factor)
            self._header(context)
        return {'RUNNING_MODAL'}


def register():
    bpy.utils.register_class(HHP_OT_root_uniform_scale)
    config = bpy.context.window_manager.keyconfigs.addon
    if config:
        keymap = config.keymaps.new(name='Pose', space_type='EMPTY')
        item = keymap.keymap_items.new(HHP_OT_root_uniform_scale.bl_idname, 'S', 'PRESS', head=True)
        _KEYMAPS.append((keymap, item))


def unregister():
    for keymap, item in _KEYMAPS:
        try:
            keymap.keymap_items.remove(item)
        except (ReferenceError, RuntimeError):
            pass
    _KEYMAPS.clear()
    bpy.utils.unregister_class(HHP_OT_root_uniform_scale)


def setup_proxy_scale(arm):
    """Scale post-deformation smoothing corrections with the character root.

    The modifier's original factor and any existing driver remain the base
    factor. The added transform variable reads bone-local evaluated scale,
    including root proportion constraints but excluding object scale.
    """
    if arm.type != 'ARMATURE' or 'root' not in arm.pose.bones:
        raise ValueError('The HHP5 armature has no root bone')
    marker = 'hhp5_root_modifier_scale'
    plans = []
    for obj in bpy.data.objects:
        if obj.type != 'MESH':
            continue
        armature_indices = [i for i, mod in enumerate(obj.modifiers)
                            if mod.type == 'ARMATURE' and mod.object == arm]
        if not armature_indices:
            continue
        records = json.loads(obj.get(marker, '{}'))
        for index, mod in enumerate(obj.modifiers):
            if mod.type != 'CORRECTIVE_SMOOTH' or index < min(armature_indices):
                continue
            path = mod.path_from_id('scale')
            curve = next((fc for fc in obj.animation_data.drivers if fc.data_path == path), None) \
                if obj.animation_data else None
            record = records.get(path)
            if record:
                if curve is None:
                    raise ValueError('The root scale driver was removed from ' + obj.name + ': ' + mod.name)
                variable = curve.driver.variables.get(record['variable'])
                if (variable is None or variable.type != 'TRANSFORMS'
                        or variable.targets[0].id != arm
                        or variable.targets[0].bone_target != 'root'):
                    raise ValueError('The root scale driver was changed on ' + obj.name + ': ' + mod.name)
                continue
            value = float(mod.scale)
            kind = curve.driver.type if curve else None
            variables = [variable.name for variable in curve.driver.variables] if curve else []
            if curve and kind == 'SCRIPTED':
                base = curve.driver.expression
            elif curve and variables:
                values = ','.join(variables)
                base = ('(' + '+'.join(variables) + ')/' + str(len(variables)) if kind == 'AVERAGE'
                        else '+'.join(variables) if kind == 'SUM'
                        else variables[0] if len(variables) == 1
                        else ('min' if kind == 'MIN' else 'max') + '(' + values + ')')
            else:
                base = repr(value)
            variable_name = 'hhp_global_root_scale'
            while variable_name in variables:
                variable_name += '_'
            expression = '(' + base + ')*' + variable_name
            if len(expression) > 256:
                raise ValueError('The smoothing driver is too long to extend on ' + obj.name)
            plans.append((obj, mod, curve, path, records, value, kind, base, variable_name, expression))
    changed_objects = set()
    for obj, mod, curve, path, records, value, kind, base, variable_name, expression in plans:
        curve = curve or mod.driver_add('scale')
        driver = curve.driver
        variable = driver.variables.new()
        variable.name, variable.type = variable_name, 'TRANSFORMS'
        target = variable.targets[0]
        target.id = arm
        target.bone_target = 'root'
        target.transform_type = 'SCALE_X'
        target.transform_space = 'LOCAL_SPACE'
        driver.type = 'SCRIPTED'
        driver.expression = expression
        records[path] = {'value': value, 'driver_type': kind, 'expression': base,
                         'variable': variable_name}
        obj[marker] = json.dumps(records)
        obj.update_tag()
        changed_objects.add(obj.name)
    return {'scaled_modifiers': len(plans), 'changed_objects': sorted(changed_objects)}
