"""Asset clash choices and collection consolidation for Identity Transfer."""
import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty

from . import identity_transfer_data as data
from .animation_transfer_support import TransferError, collection_tree, reference_slots

CHOICES = [
    ('SOURCE', 'Keep Source', 'Keep the asset already on the active source character', 'TRIA_LEFT', 0),
    ('BOTH', 'Keep Both', 'Keep both assets inside the merged collection', 'DUPLICATE', 1),
    ('TARGET', 'Keep Target', 'Keep the asset coming from the selected target character', 'TRIA_RIGHT', 2),
]
FLAGS = ('hide_viewport', 'hide_render')


class HHP_IdentityAssetClash(bpy.types.PropertyGroup):
    category: StringProperty(name='Category')
    source_name: StringProperty(name='Source asset')
    target_name: StringProperty(name='Target asset')
    is_surface_deform_target: BoolProperty(
        name='Surface Deform Target',
        description='The selected asset is used as a Surface Deform target',
        default=False,
    )
    choice: EnumProperty(name='Keep', description='Choose which clashing identity assets to retain',
                         items=CHOICES, default='BOTH')

    @property
    def source_obj(self):
        return bpy.data.objects.get(self.source_name)

    @property
    def target_obj(self):
        return bpy.data.objects.get(self.target_name)


def asset_roots(mesh):
    root = data.get_top_parent_collection(mesh)
    groups = data.source_asset_collection_groups(mesh)
    roots = {coll for group in groups.values() for coll in group}
    roots.update(coll for coll in collection_tree(root)
                 if data.get_base_object_name(coll.name) in {'Clothes', 'Appendages'})
    return {coll for coll in roots if not any(coll in collection_tree(other)
                                            for other in roots if other != coll)}


def _order(item):
    base = data.get_base_object_name(item.name)
    return (base, 0 if item.name == base else int(item.name.rsplit('.', 1)[1]), item.name)


def incoming_deformers(target):
    return {mod.target for root in asset_roots(target) for obj in root.all_objects
            if obj.type == 'MESH' for mod in obj.modifiers
            if mod.type == 'SURFACE_DEFORM' and mod.target}


def analyze_clashes(source, target):
    """Separate real mesh choices from redundant incoming body-linked meshes."""
    existing = data.source_asset_collection_groups(source)
    incoming = data.source_asset_collection_groups(target)
    deformers = incoming_deformers(target)
    found, replacements, taken, seen = [], {}, set(), set()
    for category, roots in incoming.items():
        candidates = {}
        for obj in sorted({obj for coll in existing[category] for obj in coll.all_objects}, key=_order):
            if obj.type == 'MESH':
                candidates.setdefault(data.get_base_object_name(obj.name), []).append(obj)
        for obj in sorted({obj for coll in roots for obj in coll.all_objects}, key=_order):
            if obj.type != 'MESH' or obj in seen:
                continue
            for peer in candidates.get(data.get_base_object_name(obj.name), []):
                if peer not in taken and peer != obj:
                    seen.add(obj)
                    if obj.data == target.data and obj not in deformers:
                        # Several redundant linked instances can reuse the same
                        # existing mesh; only an actual clash consumes a match.
                        replacements[obj] = peer
                    else:
                        found.append((category, peer, obj))
                        taken.add(peer)
                    break
    return found, replacements


def find_clashes(source, target):
    return analyze_clashes(source, target)[0]


def populate(operator, source, target):
    operator.asset_clashes.clear()
    deformers = incoming_deformers(target)
    for category, existing, incoming in find_clashes(source, target):
        item = operator.asset_clashes.add()
        item.name = incoming.name
        item.category = category
        item.source_name, item.target_name = existing.name, incoming.name
        item.is_surface_deform_target = incoming in deformers
        item.choice = 'BOTH'
    operator.asset_clashes_ready = True


def preflight(operator, source, target, source_root, target_root):
    if not operator.asset_clashes_ready:
        populate(operator, source, target)
    clashes, replacements = analyze_clashes(source, target)
    expected = {(a, b) for _, a, b in clashes}
    if {(item.source_obj, item.target_obj) for item in operator.asset_clashes} != expected:
        raise TransferError('The selected assets changed; reopen Identity Transfer to analyze them again')
    # Consolidation removes empty duplicate folders. They must be owned by these characters.
    for mesh, root in ((source, source_root), (target, target_root)):
        tree = collection_tree(root)
        assets = {coll for branch in asset_roots(mesh) for coll in collection_tree(branch)}
        parents = list(bpy.data.collections) + [scene.collection for scene in bpy.data.scenes]
        if any(coll.name in parent.children for coll in assets for parent in parents
               if parent not in tree):
            raise TransferError('An asset collection is linked outside its character; make it independent before transferring')
        if any(assets & collection_tree(scene.collection) for scene in bpy.data.scenes
               if scene != bpy.context.scene):
            raise TransferError('Asset collections are shared with another scene; make them independent before transferring')
    for item in operator.asset_clashes:
        if item.choice == 'SOURCE':
            replacements[item.target_obj] = item.source_obj
        elif item.choice == 'TARGET':
            replacements[item.source_obj] = item.target_obj
    # An explicit choice may replace a keeper used by an automatic linked-mesh
    # replacement. Resolve the chain before rewriting references or deleting.
    for old, kept in list(replacements.items()):
        while kept in replacements:
            kept = replacements[kept]
        replacements[old] = kept
    owned = collection_tree(source_root) | collection_tree(target_root)
    for obj in replacements:
        if any(coll not in owned for coll in obj.users_collection):
            raise TransferError(f'Asset "{obj.name}" is linked outside these characters; make it independent before transferring')
    return replacements


def effective_states(roots, states):
    """Bake inherited collection visibility into members before folders combine."""
    result = {}

    def store(item, flags):
        if item in result:  # Multiple collection links: any visible path keeps it visible.
            flags = {flag: result[item][flag] and flags[flag] for flag in FLAGS}
        result[item] = flags

    def visit(coll, inherited):
        flags = {flag: inherited[flag] or states.get(coll, {}).get(flag, True) for flag in FLAGS}
        store(coll, flags)
        for obj in coll.objects:
            store(obj, {flag: flags[flag] or states.get(obj, {}).get(flag, True) for flag in FLAGS})
        for child in coll.children:
            visit(child, flags)

    for root in roots:
        visit(root, dict.fromkeys(FLAGS, False))
    return result


def apply_target_hair_eyes(source, target, source_presets, outfits, live_states):
    """Use the donor's live hair/eyes in all existing presets, preserving outfits."""
    def members(mesh):
        groups = data.source_asset_collection_groups(mesh)
        collections = {coll for category in ('Hair', 'Eyes') for branch in groups[category]
                       for coll in collection_tree(branch)}
        return collections | {obj for coll in collections for obj in coll.objects}, collections

    old_members, _ = members(source)
    new_members, new_collections = members(target)
    # Open the donor's ancestor folders according to its live state. Object states
    # are already inherited, so this cannot accidentally enable other appendages.
    root = data.get_top_parent_collection(target)
    tree = collection_tree(root)
    parents, pending = set(), list(new_collections)
    while pending:
        child = pending.pop()
        for parent in tree:
            if parent != root and child.name in parent.children and parent not in parents:
                parents.add(parent)
                pending.append(parent)
    for name in source_presets:
        states = outfits[name]
        states.update({item: dict.fromkeys(FLAGS, True) for item in old_members})
        states.update({item: dict(live_states.get(item, dict.fromkeys(FLAGS, True)))
                       for item in new_members | parents})


def consolidate(root, roots):
    """Merge equal-base-name sibling folders; return aliases before deleting empties."""
    aliases = {}

    def merge(old, kept):
        aliases[old] = kept
        for obj in list(old.objects):
            if obj.name not in kept.objects:
                kept.objects.link(obj)
            old.objects.unlink(obj)
        for child in list(old.children):
            if child.name not in kept.children:
                kept.children.link(child)
            old.children.unlink(child)

    def visit(parent, allowed=None):
        canonical = {}
        for coll in sorted(list(parent.children), key=_order):
            if allowed is not None and coll not in allowed:
                continue
            base = data.get_base_object_name(coll.name)
            if base in canonical:
                merge(coll, canonical[base])
                parent.children.unlink(coll)
            else:
                canonical[base] = coll
        for coll in canonical.values():
            visit(coll)

    visit(root, roots)
    return aliases


def remap_states(states, aliases):
    result = {}
    for item, values in states.items():
        while item in aliases:
            item = aliases[item]
        if item in result:
            values = {flag: result[item][flag] and values[flag] for flag in FLAGS}
        result[item] = dict(values)
    return result


def replace_objects(root, replacements):
    if not replacements:
        return
    # Preserve collection membership and local references when one version replaces another.
    for old, kept in replacements.items():
        for coll in old.users_collection:
            if kept.name not in coll.objects:
                coll.objects.link(kept)
    owners = set(root.all_objects)
    for obj in list(owners):
        mesh = getattr(obj, 'data', None)
        if mesh:
            owners.add(mesh)
        if getattr(mesh, 'shape_keys', None):
            owners.add(mesh.shape_keys)
        for mat in getattr(mesh, 'materials', ()):
            if mat:
                owners.add(mat)
                pending = [mat.node_tree] if mat.node_tree else []
                while pending:
                    tree = pending.pop()
                    if tree in owners:
                        continue
                    owners.add(tree)
                    pending.extend(node.node_tree for node in tree.nodes if node.type == 'GROUP' and node.node_tree)
    for owner in owners:
        for container, key, custom, value in list(reference_slots(owner)):
            if value in replacements:
                if custom:
                    container[key] = replacements[value]
                else:
                    setattr(container, key, replacements[value])
    for old in replacements:
        bpy.data.objects.remove(old, do_unlink=True)


def resolve_post_transfer(context, source, entries):
    """Resolve transferred duplicates and rewrite presets to the surviving assets."""
    from . import identity_transfer as identity
    from .. import Customize_HHP as presets
    root = data.get_top_parent_collection(source) if source else None
    if root is None or not source.is_editable:
        raise TransferError('The transferred source character is no longer available or editable')
    tree, owned = collection_tree(root), set(root.all_objects)
    replacements = {}
    keeper_names = {}
    for item in entries:
        existing, incoming = item.source_obj, item.target_obj
        if existing not in owned or incoming not in owned:
            raise TransferError('The transferred assets changed; keep both or undo before retrying')
        if item.choice == 'SOURCE':
            replacements[incoming] = existing
        elif item.choice == 'TARGET':
            replacements[existing] = incoming
            keeper_names[incoming] = existing.name
    if not replacements:
        return len(entries)
    if any(obj in scene.objects.values() for obj in replacements for scene in bpy.data.scenes
           if scene != context.scene):
        raise TransferError('A clashing asset is shared with another scene; choose Both')
    for obj in replacements:
        if not obj.is_editable or any(coll not in tree for coll in obj.users_collection):
            raise TransferError(f'Asset "{obj.name}" is shared outside this character or not editable; choose Both')
    merged = data.safe_copy_val(source.get('presets', {}))
    roots = identity._outfit_roots(root)
    outfits = {name: remap_states(effective_states(roots, identity.resolve_outfit(preset, root)), replacements)
               for name, preset in merged.items()}
    with context.temp_override(active_object=source, object=source):
        captured = {'collections': presets.capture_outfit_preset(context)}
    current = remap_states(effective_states(roots, identity.resolve_outfit(captured, root)), replacements)
    replace_objects(root, replacements)
    for keeper, name in keeper_names.items():
        keeper.name = name
    for name, preset in merged.items():
        preset['collections'] = identity.complete_outfit(root, outfits[name])
    source['presets'] = merged
    # Preserve live mouth/shader values and the active preset selection; only outfit
    # references and visibility need updating after the chosen object is removed.
    presets.apply_outfit_preset(identity.complete_outfit(root, current), source)
    context.view_layer.update()
    return len(entries)


def register():
    bpy.utils.register_class(HHP_IdentityAssetClash)


def unregister():
    bpy.utils.unregister_class(HHP_IdentityAssetClash)
