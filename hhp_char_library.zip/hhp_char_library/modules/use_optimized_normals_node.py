import bpy
import os


PROP_NAME = "hhp_use_optimized_normals"
NORMAL_OPTIMIZED_GROUP_PARTIAL_NAME = "Normal Map Optimized"


def _get_addon_root_dir():
    # modules/ -> addon root
    return os.path.dirname(os.path.dirname(__file__))


def get_hhp_library_blend_path():
    """Return the absolute path to the shipped HHP library blend in /assets."""
    return os.path.join(_get_addon_root_dir(), "assets", "HHP_library.blend")


def _find_node_group_by_partial_name(partial_name):
    """Return the first node group whose name contains partial_name."""
    for node_group in bpy.data.node_groups:
        if partial_name in node_group.name:
            return node_group
    return None


def _find_node_groups_by_partial_name(partial_name):
    """Return all node groups whose name contains partial_name."""
    return [ng for ng in bpy.data.node_groups if partial_name in ng.name]


def _load_node_group_from_library_by_partial_name(blend_path, partial_name):
    """
    Load (append) the first node group whose name contains partial_name from blend_path.
    Returns the loaded node group datablock, or None on failure.
    """
    if not os.path.exists(blend_path):
        print(f"Library blend not found: {blend_path}")
        return None

    # If already present, reuse it.
    existing = _find_node_group_by_partial_name(partial_name)
    if existing:
        return existing

    with bpy.data.libraries.load(blend_path, link=False) as (data_from, data_to):
        match_name = next((n for n in data_from.node_groups if partial_name in n), None)
        if not match_name:
            print(f"Node group containing '{partial_name}' not found in '{blend_path}'")
            return None
        data_to.node_groups = [match_name]

    return _find_node_group_by_partial_name(partial_name)


def _mirror_node_properties(new_node, old_node):
    new_node.name = old_node.name
    new_node.label = old_node.label
    new_node.location = old_node.location
    new_node.select = old_node.select
    new_node.mute = old_node.mute
    new_node.hide = old_node.hide


def _copy_socket_defaults_and_links(node_tree, old_node, new_node):
    links = node_tree.links

    # Inputs
    for old_input, new_input in zip(old_node.inputs, new_node.inputs):
        if hasattr(new_input, "default_value") and hasattr(old_input, "default_value"):
            try:
                new_input.default_value = old_input.default_value
            except Exception:
                pass
        if old_input.is_linked:
            for link in list(old_input.links):
                try:
                    links.new(link.from_socket, new_input)
                except Exception:
                    pass

    # Outputs
    for old_output, new_output in zip(old_node.outputs, new_node.outputs):
        if hasattr(new_output, "default_value") and hasattr(old_output, "default_value"):
            try:
                new_output.default_value = old_output.default_value
            except Exception:
                pass
        if old_output.is_linked:
            for link in list(old_output.links):
                try:
                    links.new(new_output, link.to_socket)
                except Exception:
                    pass


def _replace_node(node_tree, old_node, to_custom, custom_node_group):
    nodes = node_tree.nodes

    if to_custom:
        new_node = nodes.new(type='ShaderNodeGroup')
        new_node.node_tree = custom_node_group
    else:
        new_node = nodes.new(type='ShaderNodeNormalMap')

    _mirror_node_properties(new_node, old_node)
    _copy_socket_defaults_and_links(node_tree, old_node, new_node)
    nodes.remove(old_node)


def replace_normal_map_nodes(blend_path, partial_group_name, optimize_normals):
    """
    If optimize_normals is True, replace ShaderNodeNormalMap with the custom group node.
    If optimize_normals is False, revert custom group nodes back to ShaderNodeNormalMap.
    """
    custom_node_group = (
        _load_node_group_from_library_by_partial_name(blend_path, partial_group_name)
        if optimize_normals
        else _find_node_group_by_partial_name(partial_group_name)
    )

    if optimize_normals and not custom_node_group:
        return

    def _is_custom_group_node(node):
        return (
            isinstance(node, bpy.types.ShaderNodeGroup)
            and getattr(node, "node_tree", None) is not None
            and partial_group_name in node.node_tree.name
        )

    # Materials
    for material in bpy.data.materials:
        if not material.node_tree:
            continue
        for node in list(material.node_tree.nodes):
            if optimize_normals and isinstance(node, bpy.types.ShaderNodeNormalMap):
                _replace_node(material.node_tree, node, True, custom_node_group)
            elif (not optimize_normals) and _is_custom_group_node(node):
                _replace_node(material.node_tree, node, False, None)

    # Node groups
    for node_group in bpy.data.node_groups:
        for node in list(node_group.nodes):
            if optimize_normals and isinstance(node, bpy.types.ShaderNodeNormalMap):
                _replace_node(node_group, node, True, custom_node_group)
            elif (not optimize_normals) and _is_custom_group_node(node):
                _replace_node(node_group, node, False, None)


def revert_custom_normal_map_nodes(partial_group_name):
    """Replace any custom group node using a group containing partial_group_name back to ShaderNodeNormalMap."""
    custom_groups = _find_node_groups_by_partial_name(partial_group_name)
    if not custom_groups:
        return

    def _is_target_custom_group_node(node):
        return (
            isinstance(node, bpy.types.ShaderNodeGroup)
            and getattr(node, "node_tree", None) in custom_groups
        )

    # Materials
    for material in bpy.data.materials:
        if not material.node_tree:
            continue
        for node in list(material.node_tree.nodes):
            if _is_target_custom_group_node(node):
                _replace_node(material.node_tree, node, False, None)

    # Node groups
    for node_group in bpy.data.node_groups:
        for node in list(node_group.nodes):
            if _is_target_custom_group_node(node):
                _replace_node(node_group, node, False, None)


def apply_use_optimized_normals(use_optimized_normals):
    """
    Apply behavior used by the UI toggle:
    - If True: force optimized normals (replace normal map nodes with the custom group).
    - If False: revert any custom group nodes back to normal map nodes.
    """
    if use_optimized_normals:
        replace_normal_map_nodes(
            get_hhp_library_blend_path(),
            NORMAL_OPTIMIZED_GROUP_PARTIAL_NAME,
            optimize_normals=True,
        )
    else:
        revert_custom_normal_map_nodes(NORMAL_OPTIMIZED_GROUP_PARTIAL_NAME)


def register_properties():
    """Register the Scene property that drives the icon-only checkbox in the UI."""
    def _on_toggle_update(scene, context):
        try:
            apply_use_optimized_normals(getattr(scene, PROP_NAME, False))
        except Exception as e:
            print(f"Use Optimized Normals update failed: {e}")

    if hasattr(bpy.types.Scene, PROP_NAME):
        delattr(bpy.types.Scene, PROP_NAME)

    setattr(
        bpy.types.Scene,
        PROP_NAME,
        bpy.props.BoolProperty(
            name="Use Optimized Normals (Recommended)",
            description=(
                "Replace all Normal Map nodes with the Optimized Normals node, which runs normal "
                "map calculations on the GPU for greatly enhanced playback performance. Visual "
                "difference is near identical to the original (non-optimized) normals. "
                "If you import/create new assets which use Blender's default Normal Map node, "
                "toggle this off and on to refresh new assets into using the Optimized Normals node."
            ),
            default=False,
            update=_on_toggle_update,
        ),
    )


def unregister_properties():
    if hasattr(bpy.types.Scene, PROP_NAME):
        delattr(bpy.types.Scene, PROP_NAME)

