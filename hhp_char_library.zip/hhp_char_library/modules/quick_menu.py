import bpy
from bpy.types import Menu, Operator, AddonPreferences
from bpy.props import StringProperty

# Dictionary to store keymap items
addon_keymaps = {}

def find_user_keyconfig(key):
    """Find the user's keymap configuration"""
    km, kmi = addon_keymaps[key]
    for item in bpy.context.window_manager.keyconfigs.user.keymaps[km.name].keymap_items:
        found_item = False
        if kmi.idname == item.idname:
            found_item = True
            for name in dir(kmi.properties):
                if not name in ["bl_rna", "rna_type"] and not name[0] == "_":
                    if name in kmi.properties and name in item.properties and not kmi.properties[name] == item.properties[name]:
                        found_item = False
        if found_item:
            return item
    print(f"Couldn't find keymap item for {key}, using addon keymap instead. This won't be saved across sessions!")
    return kmi


class HHP_MT_PieMenu(Menu):
    bl_idname = "HHP_MT_pie_menu"
    bl_label = "HHP Quick Access"
    
    def draw(self, context):
        layout = self.layout.menu_pie()
        
        # RIGHT direction - left empty
        layout.separator()
        
        # LEFT direction - left empty
        layout.separator()
        
        # DOWN direction: Scene (HHP)
        op = layout.operator('hhp.open_scene_panel', text='Scene (HHP)', icon='SCENE_DATA')
        
        # UP direction: Char (HHP)
        op = layout.operator('hhp.open_char_panel', text='Char (HHP)', icon='OUTLINER_OB_ARMATURE')
        
        # Add four more empty items to complete the 8-direction pie menu
        layout.separator()  # TOP-RIGHT
        layout.separator()  # TOP-LEFT
        layout.separator()  # BOTTOM-LEFT
        layout.separator()  # BOTTOM-RIGHT


class HHP_OT_OpenCharPanel(Operator):
    bl_idname = "hhp.open_char_panel"
    bl_label = "Open Char Panel"
    bl_description = "Open the Char (HHP) panel"
    bl_options = {"REGISTER"}
    
    def execute(self, context):
        # Get the area to display the panel
        area = None
        for a in context.screen.areas:
            if a.type == 'VIEW_3D':
                area = a
                break
        
        if area:
            # Pass the panel to display using the UI panel command
            bpy.ops.wm.call_panel(name="CHAR_HHP_PT_Panel", keep_open=True)
            
        return {"FINISHED"}


class HHP_OT_OpenScenePanel(Operator):
    bl_idname = "hhp.open_scene_panel"
    bl_label = "Open Scene Panel"
    bl_description = "Open the Scene (HHP) panel"
    bl_options = {"REGISTER"}
    
    def execute(self, context):
        # Get the area to display the panel
        area = None
        for a in context.screen.areas:
            if a.type == 'VIEW_3D':
                area = a
                break
        
        if area:
            # Pass the panel to display using the UI panel command
            bpy.ops.wm.call_panel(name="SCENE_HHP_PT_Panel", keep_open=True)
            
        return {"FINISHED"}


# Extending the existing addon preferences
def draw_keymap_item(self, context):
    layout = self.layout
    
    # Add a new section for extra options
    box = layout.box()
    box.label(text="Extra Options:")
    
    # Display the keymap configuration for the quick menu shortcut
    if 'HHP_PIE_MENU' in addon_keymaps:
        box.prop(find_user_keyconfig('HHP_PIE_MENU'), 'type', text='Pie Menu', full_event=True)
    else:
        box.label(text="Shortcut not available. Try restarting Blender.")

    # Draw the debug mode checkbox (from the preferences)
    box.prop(self, "debug_mode", text="Debug mode / Dev extras")


def register():
    bpy.utils.register_class(HHP_MT_PieMenu)
    bpy.utils.register_class(HHP_OT_OpenCharPanel)
    bpy.utils.register_class(HHP_OT_OpenScenePanel)
    
    # Create keymap entry
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='Window', space_type='EMPTY')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'T', 'PRESS', 
                                  ctrl=False, shift=True, alt=False, repeat=False)
        kmi.properties.name = 'HHP_MT_pie_menu'
        addon_keymaps['HHP_PIE_MENU'] = (km, kmi)
    
    # Add the keymap draw function to the addon preferences
    from .. import HHPCharLibraryPreferences
    if not hasattr(HHPCharLibraryPreferences, "draw_original"):
        HHPCharLibraryPreferences.draw_original = HHPCharLibraryPreferences.draw
        def draw_with_keymap(self, context):
            self.draw_original(context)
            draw_keymap_item(self, context)
        HHPCharLibraryPreferences.draw = draw_with_keymap


def unregister():
    # Restore original draw function
    from .. import HHPCharLibraryPreferences
    if hasattr(HHPCharLibraryPreferences, "draw_original"):
        HHPCharLibraryPreferences.draw = HHPCharLibraryPreferences.draw_original
        del HHPCharLibraryPreferences.draw_original
    
    # Remove keymap entry
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        for km, kmi in addon_keymaps.values():
            km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    
    bpy.utils.unregister_class(HHP_OT_OpenScenePanel)
    bpy.utils.unregister_class(HHP_OT_OpenCharPanel)
    bpy.utils.unregister_class(HHP_MT_PieMenu) 