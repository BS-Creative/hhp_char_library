"""Finish optional material refreshes after a transfer's asynchronous clash dialog."""
from . import transfer_optimized_materials as materials


_pending = {}


def clear(kind):
    _pending.pop(kind, None)


def remember(kind, owner, enabled, collection=None, visibility=None):
    _pending.setdefault(kind, {})[owner.as_pointer()] = (owner, enabled, collection, visibility)


def remember_animation(context, states, collection, visibility, prefix):
    wm = context.window_manager
    if not getattr(wm, prefix + 'shapekey_clashes', ()):
        return
    target_name = getattr(wm, prefix + 'shapekey_clash_target', '')
    for _, target, enabled in states:
        if target.name == target_name:
            remember('animation', target, enabled, collection, visibility)


def finish(kind, owner, context, report, changed=True):
    """Refresh the recorded recipient, independent of the current selection."""
    records = _pending.get(kind, {})
    entry = records.pop(owner.as_pointer(), None) if owner else None
    if not records:
        clear(kind)
    if entry is None or not changed:
        return True
    mesh, enabled, collection, visibility = entry
    try:
        context.view_layer.update()
        materials.refresh(context, [mesh])
        materials.set_state(mesh, enabled)
        context.view_layer.update()
        return True
    except (RuntimeError, ValueError, TypeError, ReferenceError) as error:
        materials.set_state(mesh, False)
        if collection is not None and visibility is not None:
            try:
                collection.hide_viewport, collection.hide_render = visibility
            except ReferenceError:
                pass
        report({'WARNING'}, f'Clashes resolved, but optimized materials could not be updated; original materials remain active: {error}')
        context.view_layer.update()
        return False
