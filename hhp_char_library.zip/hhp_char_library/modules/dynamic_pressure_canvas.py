import bpy

from . import hhp_naming

_FACE_MATERIAL_SUBSTRING = "Genesis 8 Female_Face"
_SHADER_LAYERS_GROUP_SUBSTRING = "(HHP)_Shader Layers"
_SHADER_LAYER_FINAL_GROUP_SUBSTRING = "(HHP) Shader Layer_FINAL"
_VERTEX_COLOR_ATTRIBUTE_NAME = "(HHP)_Col"


def _has_selected_genesis_shape_mesh(context):
    return any(
        obj
        and obj.type == 'MESH'
        and hhp_naming.is_char_mesh_object_name(obj.name)
        for obj in getattr(context, "selected_objects", []) or []
    )


def _find_material_by_substring(obj, substring):
    if not obj or obj.type != 'MESH' or not obj.data:
        return None
    for mat in getattr(obj.data, "materials", []) or []:
        if mat and substring in mat.name:
            return mat
    return None


def _find_group_node_by_tree_name_in_tree(node_tree, tree_name_substring):
    if not node_tree:
        return None
    for node in node_tree.nodes:
        if getattr(node, "type", None) == 'GROUP' and getattr(node, "node_tree", None):
            if tree_name_substring in node.node_tree.name:
                return node
    return None


def _find_shader_layer_vfx_nodes(obj):
    face_material = _find_material_by_substring(obj, _FACE_MATERIAL_SUBSTRING)
    if not face_material or not getattr(face_material, "use_nodes", False):
        return None, None, None

    shader_layers_node = _find_group_node_by_tree_name_in_tree(
        face_material.node_tree,
        _SHADER_LAYERS_GROUP_SUBSTRING,
    )
    if not shader_layers_node or not getattr(shader_layers_node, "node_tree", None):
        return face_material, None, None

    final_node = _find_group_node_by_tree_name_in_tree(
        shader_layers_node.node_tree,
        _SHADER_LAYER_FINAL_GROUP_SUBSTRING,
    )
    if not final_node or not getattr(final_node, "node_tree", None):
        return face_material, shader_layers_node, None

    return face_material, shader_layers_node, final_node


def _get_window_pointer(window):
    try:
        return window.as_pointer()
    except Exception:
        return id(window)


def _set_active_material(obj, material):
    if not obj or not material:
        return
    for index, slot in enumerate(getattr(obj, "material_slots", []) or []):
        if slot.material == material:
            obj.active_material_index = index
            break


def _set_node_editor_nested_group_path(space, material, shader_layers_node, final_node):
    if not space or not material or not getattr(material, "node_tree", None):
        return False
    if not shader_layers_node or not getattr(shader_layers_node, "node_tree", None):
        return False
    if not final_node or not getattr(final_node, "node_tree", None):
        return False

    try:
        space.path.start(material.node_tree)
        space.path.append(shader_layers_node.node_tree, shader_layers_node)
        space.path.append(final_node.node_tree, final_node)
    except TypeError:
        try:
            space.path.start(material.node_tree)
            space.path.append(shader_layers_node.node_tree)
            space.path.append(final_node.node_tree)
        except Exception:
            return False
    except Exception:
        return False

    return getattr(space, "edit_tree", None) == final_node.node_tree


def _open_shader_layer_vfx_window(context, obj, material, shader_layers_node, final_node):
    window_manager = context.window_manager
    before_windows = {_get_window_pointer(window) for window in window_manager.windows}
    result = bpy.ops.wm.window_new()
    if 'FINISHED' not in result:
        return False

    new_window = next(
        (
            window
            for window in window_manager.windows
            if _get_window_pointer(window) not in before_windows
        ),
        context.window,
    )
    if not new_window or not getattr(new_window, "screen", None):
        return False

    screen = new_window.screen
    area = max(screen.areas, key=lambda screen_area: screen_area.width * screen_area.height)
    area.type = 'NODE_EDITOR'
    region = next((reg for reg in area.regions if reg.type == 'WINDOW'), None)
    space = area.spaces.active
    if not region or not space:
        return False

    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass
    _set_active_material(obj, material)

    try:
        space.tree_type = 'ShaderNodeTree'
    except Exception:
        pass
    try:
        space.shader_type = 'OBJECT'
    except Exception:
        pass
    try:
        space.id = material
    except Exception:
        pass

    entered_group = _set_node_editor_nested_group_path(space, material, shader_layers_node, final_node)
    try:
        area.tag_redraw()
    except Exception:
        pass

    return entered_group


def _add_vertex_color_node_to_node_tree(node_tree, vcol_name):
    if not node_tree:
        return None, False

    nodes = node_tree.nodes
    for node in nodes:
        if node.type == 'VERTEX_COLOR' and node.layer_name == vcol_name:
            node.select = True
            nodes.active = node
            return node, False

    vcol_node = nodes.new(type='ShaderNodeVertexColor')
    vcol_node.layer_name = vcol_name
    vcol_node.location = (-300, 300)
    vcol_node.label = "Dynamic Paint Color"

    for node in nodes:
        if node != vcol_node:
            node.select = False
    vcol_node.select = True
    nodes.active = vcol_node
    return vcol_node, True


# --- PropertyGroup for storing materials ---
class DynamicPressureMaterialItem(bpy.types.PropertyGroup):
    material: bpy.props.PointerProperty(type=bpy.types.Material)
    selected: bpy.props.BoolProperty(default=False)

# --- UIList for displaying materials with checkboxes ---
class DYNAMIC_PRESSURE_UL_MaterialList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.prop(item, "selected", text=item.material.name, icon='MATERIAL', toggle=True)
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.prop(item, "selected", text=item.material.name, toggle=True)

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        ui_search = (getattr(self, "filter_name", "") or "").strip().lower()
        flags = []

        for item in items:
            material_name = item.material.name.lower() if item.material else ""
            if not ui_search or ui_search in material_name:
                flags.append(self.bitflag_filter_item)
            else:
                flags.append(0)

        return flags, []

# --- Operators for selecting/deselecting all materials ---
class DYNAMIC_PRESSURE_OT_SelectAllMaterials(bpy.types.Operator):
    bl_idname = "object.dynamic_pressure_select_all_materials"
    bl_label = "Select All"
    bl_description = "Select all materials in the list"
    bl_options = {'INTERNAL'}
    
    def execute(self, context):
        op = context.window_manager.dynamic_pressure_canvas
        for item in op.material_list:
            item.selected = True
        return {'FINISHED'}

class DYNAMIC_PRESSURE_OT_DeselectAllMaterials(bpy.types.Operator):
    bl_idname = "object.dynamic_pressure_deselect_all_materials"
    bl_label = "Deselect All"
    bl_description = "Deselect all materials in the list"
    bl_options = {'INTERNAL'}
    
    def execute(self, context):
        op = context.window_manager.dynamic_pressure_canvas
        for item in op.material_list:
            item.selected = False
        return {'FINISHED'}


# --- Main operator properties ---
class DynamicPressureCanvasProperties(bpy.types.PropertyGroup):
    material_list: bpy.props.CollectionProperty(type=DynamicPressureMaterialItem)
    material_index: bpy.props.IntProperty(default=0)

class DYNAMIC_PRESSURE_CANVAS_OT_Operator(bpy.types.Operator):
    bl_idname = "object.dynamic_pressure_canvas"
    bl_label = "Canvas Displace Method"
    bl_description = "Drains blood from the character's skin when high-pressure contact occurs."
    bl_options = {'REGISTER', 'UNDO'}

    displace_method: bpy.props.EnumProperty(
        name="Displacement Method",
        description="Displacement method:",
        items=[
            ('DISPLACE_LEGACY', "Displace (Legacy)", 
                "Vertex color (Face Corner / Byte Color) and displacement.\nExample: Displacing human skin on contact (e.g. lipstick/touch causing blood drain).", 
                'MOD_DISPLACE', 0),
            ('WAVES', "Fluid waves", 
                "Vertex color (Face Corner / Byte Color) and waves.\nExample: Creating ripples in a bathtub, pool, or from a boat.", 
                'MOD_WAVE', 1),
            ('NONE', "Vtx color only", 
                "Vertex color only with no displacement (Face Corner / Byte Color).", 
                'GROUP_VCOL', 2),
            ('DISPLACE', "Displace", 
                "Vertex color (Face Corner / Byte Color) and displacement canvas without the displacement modifier, corrective smooth modifier, or vertex group.", 
                'MOD_DISPLACE', 3)
        ],
        default='DISPLACE_LEGACY'
    )

    # Hidden property to control the multi-stage confirmation process.
    step: bpy.props.StringProperty(
        default='CHECK',
        options={'HIDDEN'}
    )

    add_to_open_shader_layer_vfx: bpy.props.BoolProperty(
        name="Add to & open Shader Layer - VFX",
        description="Add the dynamic paint vertex color node to Shader Layer - VFX and open that node group",
        default=True,
    )

    def invoke(self, context, event):
        # Always reset the confirmation step so that the warning popup shows every time.
        self.step = 'CHECK'
        # Check each selected mesh for any Dynamic Paint modifier or modifier with "(HHP-DP)" in its name.
        has_existing_modifiers = False
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                for mod in obj.modifiers:
                    if mod.type == 'DYNAMIC_PAINT' or "(HHP-DP)" in mod.name:
                        has_existing_modifiers = True
                        break
                if has_existing_modifiers:
                    break
        if has_existing_modifiers:
            # Show a concise warning popup.
            return context.window_manager.invoke_props_dialog(self, width=300)
        else:
            # No modifiers to warn about; go directly to displacement method selection.
            self.step = 'METHOD'
            return context.window_manager.invoke_props_dialog(self, width=300)

    def draw(self, context):
        layout = self.layout
        if self.step == 'CHECK':
            layout.label(text="Warning: Existing dynamic paint modifiers found.", icon='ERROR')
            layout.label(text="Remove and continue?")
        elif self.step == 'METHOD':
            col = layout.column()
            col.prop(self, "displace_method", expand=True)
        elif self.step == 'MATERIALS':
            layout.label(text="Select materials to add vertex color nodes:", icon='MATERIAL')

            props = context.window_manager.dynamic_pressure_canvas
            if _has_selected_genesis_shape_mesh(context):
                layout.prop(self, "add_to_open_shader_layer_vfx", text="Add to & open Shader Layer - VFX")

            # Add buttons for selecting/deselecting all
            row = layout.row(align=True)
            row.operator("object.dynamic_pressure_select_all_materials", icon='CHECKBOX_HLT')
            row.operator("object.dynamic_pressure_deselect_all_materials", icon='CHECKBOX_DEHLT')
            
            # Display the materials in a scrollable list
            layout.template_list(
                "DYNAMIC_PRESSURE_UL_MaterialList", 
                "", 
                props, 
                "material_list", 
                props, 
                "material_index",
                rows=8  # Show 8 items at once
            )

    def collect_materials(self, context):
        # Get the window manager property group
        props = context.window_manager.dynamic_pressure_canvas
        
        # Clear existing materials
        props.material_list.clear()
        
        # Collect all unique materials from selected objects
        unique_materials = set()
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                for slot in obj.material_slots:
                    if slot.material and slot.material not in unique_materials:
                        unique_materials.add(slot.material)
                        item = props.material_list.add()
                        item.material = slot.material
                        item.selected = False  # Default to deselected

    def execute(self, context):
        if self.step == 'CHECK':
            # When the warning is confirmed, move to method selection.
            self.step = 'METHOD'
            return context.window_manager.invoke_props_dialog(self, width=300)
        elif self.step == 'METHOD':
            # After method selection, move to material selection
            self.step = 'MATERIALS'
            self.add_to_open_shader_layer_vfx = _has_selected_genesis_shape_mesh(context)
            self.collect_materials(context)
            return context.window_manager.invoke_props_dialog(self, width=400)
        elif self.step == 'MATERIALS':
            scene = context.scene
            framerate = scene.render.fps
            dissolve_time = int(framerate / 4)
            dry_time = int(framerate)

            for obj in context.selected_objects:
                if obj.type != 'MESH':
                    continue

                context.view_layer.objects.active = obj

                # Remove any Dynamic Paint modifier or any modifier with "(HHP-DP)" in its name.
                mods_to_remove = []
                for mod in obj.modifiers:
                    if mod.type == 'DYNAMIC_PAINT' or "(HHP-DP)" in mod.name:
                        mods_to_remove.append(mod)
                for mod in reversed(mods_to_remove):
                    mod_name = mod.name  # Save the name before removal.
                    obj.modifiers.remove(mod)
                    self.report({'INFO'}, f"Removed modifier '{mod_name}' from {obj.name}")

                # --- Create Vertex Color Attribute for Canvas 1 ---
                mesh = obj.data
                vcol_name = "(HHP)_Col"
                if vcol_name not in mesh.attributes:
                    vcol_attr = mesh.attributes.new(name=vcol_name, type='BYTE_COLOR', domain='CORNER')
                    # Initialize all colors to black
                    for i in range(len(vcol_attr.data)):
                        vcol_attr.data[i].color = (0.0, 0.0, 0.0, 1.0)
                    self.report({'INFO'}, f"Created vertex color attribute '{vcol_name}' on {obj.name} (initialized to black)")
                else:
                    # Set existing attribute to black
                    vcol_attr = mesh.attributes.get(vcol_name)
                    for i in range(len(vcol_attr.data)):
                        vcol_attr.data[i].color = (0.0, 0.0, 0.0, 1.0)
                    self.report({'INFO'}, f"Vertex color attribute '{vcol_name}' already exists on {obj.name} (set to black)")

                # --- Create Vertex Group for Canvas 2 ONLY if displace legacy mode is selected ---
                vgroup_name = "(HHP)_Disp"
                if self.displace_method == 'DISPLACE_LEGACY':
                    if vgroup_name not in obj.vertex_groups:
                        obj.vertex_groups.new(name=vgroup_name)
                        self.report({'INFO'}, f"Created vertex group '{vgroup_name}' on {obj.name}")
                    else:
                        self.report({'INFO'}, f"Vertex group '{vgroup_name}' already exists on {obj.name}")

                # --- Add and Setup Dynamic Paint Modifier ---
                bpy.ops.object.modifier_add(type='DYNAMIC_PAINT')
                bpy.ops.dpaint.type_toggle(type='CANVAS')
                dp_mod = obj.modifiers.get("Dynamic Paint")
                if dp_mod:
                    dp_mod.name = "(HHP-DP) - Canvas"
                else:
                    self.report({'WARNING'}, f"Dynamic Paint modifier not found on {obj.name}.")
                    continue

                canvas = dp_mod.canvas_settings
                if not canvas.canvas_surfaces:
                    self.report({'WARNING'}, f"No canvas surfaces found on {obj.name}.")
                    continue

                # --- Configure First Canvas Surface: Vertex Color Output ---
                surface1 = canvas.canvas_surfaces[0]
                surface1.name = vcol_name
                surface1.surface_format   = 'VERTEX'
                surface1.use_antialiasing = True
                surface1.frame_start      = scene.frame_start
                surface1.frame_end        = scene.frame_end
                surface1.frame_substeps   = 0
                surface1.surface_type     = 'PAINT'
                surface1.use_dissolve     = False
                surface1.use_drying       = True
                surface1.dry_speed        = dry_time
                surface1.init_color_type  = 'COLOR'
                surface1.init_color       = (0.0, 0.0, 0.0, 1.0)
                surface1.output_name_b    = vcol_name
                surface1.use_antialiasing = True
                surface1.shrink_speed     = 1
                surface1.use_shrink       = True
                surface1.use_spread       = True
                surface1.point_cache.name = f"{obj.name}_{vcol_name}"
                self.report({'INFO'}, f"Configured canvas surface '{surface1.name}' on {obj.name}.")

                # --- Configure Second Canvas Surface ---
                if self.displace_method == 'DISPLACE_LEGACY':
                    bpy.ops.dpaint.surface_slot_add()
                    surface2 = canvas.canvas_surfaces[-1]
                    surface2.name = vgroup_name
                    surface2.surface_format   = 'VERTEX'
                    surface2.use_antialiasing = True
                    surface2.frame_start      = scene.frame_start
                    surface2.frame_end        = scene.frame_end
                    surface2.frame_substeps   = 0
                    surface2.use_dissolve     = True
                    surface2.dissolve_speed   = dissolve_time
                    surface2.use_drying       = True
                    surface2.dry_speed        = dry_time
                    surface2.init_color_type  = 'COLOR'
                    surface2.init_color       = (0.0, 0.0, 0.0, 1.0)
                    surface2.use_antialiasing = True
                    surface2.surface_type     = 'WEIGHT'
                    surface2.output_name_a    = vgroup_name
                    surface2.use_antialiasing = True
                    surface2.point_cache.name = f"{obj.name}_{vgroup_name}"
                    self.report({'INFO'}, f"Configured canvas surface '{surface2.name}' on {obj.name}.")
                # For the new Displace mode, we don't create a vertex group or weight output here.

                # --- Add displacement behavior if requested ---
                if self.displace_method == 'DISPLACE_LEGACY':
                    # Find the bottom-most subdivision modifier in the stack.
                    last_subdiv_index = -1
                    last_subdiv_mod = None
                    for i, mod in enumerate(obj.modifiers):
                        if mod.type == 'SUBSURF':
                            last_subdiv_index = i
                            last_subdiv_mod = mod

                    # Temporarily disable subdivision for modifier setup.
                    original_subdiv_level = 0
                    if last_subdiv_mod:
                        original_subdiv_level = last_subdiv_mod.levels
                        last_subdiv_mod.levels = 0
                        self.report({'INFO'}, "Temporarily disabled subdivision for modifier setup")

                    # Add corrective smooth and bind it.
                    bpy.ops.object.modifier_add(type='CORRECTIVE_SMOOTH')
                    corr_mod = obj.modifiers.get("CorrectiveSmooth")
                    if corr_mod:
                        corr_mod.name = "(HHP-DP) - Corrective"
                        corr_mod.iterations = 20
                        corr_mod.smooth_type = 'SIMPLE'
                        corr_mod.rest_source = 'BIND'
                        corr_mod.vertex_group = vgroup_name
                        bpy.ops.object.correctivesmooth_bind(modifier=corr_mod.name)
                        self.report({'INFO'}, f"Added and bound corrective smooth modifier on {obj.name}.")

                    # Add the displacement modifier.
                    bpy.ops.object.modifier_add(type='DISPLACE')
                    disp_mod = obj.modifiers.get("Displace")
                    if disp_mod:
                        disp_mod.name = "(HHP-DP) - Disp"
                        disp_mod.strength = -0.02
                        disp_mod.vertex_group = vgroup_name
                        self.report({'INFO'}, f"Added displacement modifier on {obj.name}.")

                    # Ensure corrective smooth modifier is after displacement modifier.
                    if disp_mod and corr_mod:
                        disp_index = list(obj.modifiers).index(disp_mod)
                        corr_index = list(obj.modifiers).index(corr_mod)
                        if corr_index < disp_index:
                            moves_needed = disp_index - corr_index
                            for _ in range(moves_needed):
                                bpy.ops.object.modifier_move_down(modifier=corr_mod.name)

                    # Restore the original subdivision level.
                    if last_subdiv_mod:
                        last_subdiv_mod.levels = original_subdiv_level
                        self.report({'INFO'}, f"Restored subdivision level to {original_subdiv_level}")

                    # Adjust modifier ordering for displace legacy mode (leave unchanged).
                    dp_mod = obj.modifiers.get("(HHP-DP) - Canvas")
                    if last_subdiv_index >= 0 and dp_mod:
                        dp_name = dp_mod.name
                        disp_name = disp_mod.name if disp_mod else ""
                        corr_name = corr_mod.name if corr_mod else ""
                        our_mods = []
                        for i, mod in enumerate(obj.modifiers):
                            if mod.name in [dp_name, disp_name, corr_name]:
                                our_mods.append((i, mod.name))
                        our_mods.sort(reverse=True)
                        for idx, name in our_mods:
                            if idx > last_subdiv_index:
                                moves_needed = idx - last_subdiv_index
                                for _ in range(moves_needed):
                                    bpy.ops.object.modifier_move_up(modifier=name)
                            elif idx < last_subdiv_index:
                                moves_needed = last_subdiv_index - idx - 1
                                for _ in range(moves_needed):
                                    bpy.ops.object.modifier_move_down(modifier=name)
                        dp_index = disp_index = corr_index = -1
                        for i, mod in enumerate(obj.modifiers):
                            if mod.name == dp_name:
                                dp_index = i
                            elif mod.name == disp_name:
                                disp_index = i
                            elif mod.name == corr_name:
                                corr_index = i
                        if dp_index > disp_index and disp_index >= 0:
                            bpy.ops.object.modifier_move_up(modifier=dp_name)
                        if dp_index > corr_index and corr_index >= 0:
                            bpy.ops.object.modifier_move_up(modifier=dp_name)
                        for i, mod in enumerate(obj.modifiers):
                            if mod.name == disp_name:
                                disp_index = i
                            elif mod.name == corr_name:
                                corr_index = i
                        if disp_index > corr_index and corr_index >= 0:
                            bpy.ops.object.modifier_move_up(modifier=disp_name)

                elif self.displace_method == 'DISPLACE':
                    # New Displace mode: no displacement modifier, corrective smooth, or vertex group.
                    # Just add a new canvas surface with the specified disp canvas settings.
                    bpy.ops.dpaint.surface_slot_add()
                    surface2 = canvas.canvas_surfaces[-1]
                    surface2.name = vgroup_name
                    surface2.surface_type = 'DISPLACE'
                    surface2.use_antialiasing = True
                    surface2.use_dissolve = True
                    surface2.dissolve_speed = dissolve_time
                    surface2.frame_start = scene.frame_start
                    surface2.frame_end = scene.frame_end
                    surface2.frame_substeps = 0
                    surface2.use_drying = True
                    surface2.dry_speed = dry_time
                    surface2.init_color_type  = 'COLOR'
                    surface2.init_color       = (0.0, 0.0, 0.0, 1.0)
                    surface2.point_cache.name = f"{obj.name}_{vgroup_name}"
                    self.report({'INFO'}, f"Configured canvas surface '{surface2.name}' on {obj.name} for new Displace mode.")

                elif self.displace_method == 'WAVES':
                    # For WAVES mode, add an extra canvas for waves.
                    bpy.ops.dpaint.surface_slot_add()
                    wave_canvas = canvas.canvas_surfaces[-1]
                    wave_canvas.name = "(HHP)_Wave"
                    wave_canvas.surface_type = 'WAVE'
                    wave_canvas.point_cache.name = f"{obj.name}_{'(HHP)_Wave'}"
                    self.report({'INFO'}, f"Added wave canvas '{wave_canvas.name}' on {obj.name}.")
                elif self.displace_method == 'NONE':
                    # For NONE mode, nothing additional is added.
                    pass

                # For non-displace modes, ensure the dynamic paint canvas modifier is placed
                # immediately before the last SUBSURF modifier (calculated before subdiv).
                if self.displace_method in {'WAVES', 'NONE', 'DISPLACE'}:
                    dp_mod = obj.modifiers.get("(HHP-DP) - Canvas")
                    if dp_mod:
                        last_subdiv_index = -1
                        for i, mod in enumerate(obj.modifiers):
                            if mod.type == 'SUBSURF':
                                last_subdiv_index = i
                        if last_subdiv_index >= 0:
                            current_index = None
                            for i, mod in enumerate(obj.modifiers):
                                if mod.name == dp_mod.name:
                                    current_index = i
                                    break
                            if current_index is not None:
                                if current_index > last_subdiv_index:
                                    moves_needed = current_index - last_subdiv_index
                                    for _ in range(moves_needed):
                                        bpy.ops.object.modifier_move_up(modifier=dp_mod.name)
                                elif current_index < last_subdiv_index - 1:
                                    moves_needed = (last_subdiv_index - 1) - current_index
                                    for _ in range(moves_needed):
                                        bpy.ops.object.modifier_move_down(modifier=dp_mod.name)

            # --- Add Color Attribute Node to selected materials ---
            self.add_vertex_color_nodes_to_materials(context)
            if self.add_to_open_shader_layer_vfx and _has_selected_genesis_shape_mesh(context):
                self.add_vertex_color_node_to_shader_layer_vfx(context)
            
            self.report({'INFO'}, "Processing complete.")
            return {'FINISHED'}
            
    def add_vertex_color_nodes_to_materials(self, context):
        """Add Vertex Color nodes to the selected materials"""
        vcol_name = _VERTEX_COLOR_ATTRIBUTE_NAME
        props = context.window_manager.dynamic_pressure_canvas
        
        # Process each selected material
        for item in props.material_list:
            if not item.selected:
                continue
            
            material = item.material
            
            # Only process materials with nodes
            if not material.use_nodes:
                material.use_nodes = True
            
            # Get the material nodes and links
            nodes = material.node_tree.nodes
            
            # First, deselect all nodes in this material
            for node in nodes:
                node.select = False
            
            vcol_node, created = _add_vertex_color_node_to_node_tree(material.node_tree, vcol_name)
            if created:
                # Position it nicely in the node tree
                output_node = None
                for node in nodes:
                    if node.type == 'OUTPUT_MATERIAL':
                        output_node = node
                        break
                
                if output_node:
                    # Position the vertex color node to the left of the output
                    vcol_node.location = (output_node.location.x - 400, output_node.location.y)
                
                self.report({'INFO'}, f"Added Vertex Color node for '{vcol_name}' to material '{material.name}'")
            else:
                self.report({'INFO'}, f"Vertex Color node for '{vcol_name}' already exists in material '{material.name}'")

    def add_vertex_color_node_to_shader_layer_vfx(self, context):
        """Add the dynamic paint Vertex Color node to Shader Layer - VFX for selected HHP character meshes."""
        vcol_name = _VERTEX_COLOR_ATTRIBUTE_NAME
        opened_vfx = False
        found_vfx = False

        for obj in getattr(context, "selected_objects", []) or []:
            if not obj or obj.type != 'MESH' or not hhp_naming.is_char_mesh_object_name(obj.name):
                continue

            material, shader_layers_node, final_node = _find_shader_layer_vfx_nodes(obj)
            if not material or not shader_layers_node or not final_node:
                self.report({'WARNING'}, f"Shader Layer - VFX not found on {obj.name}")
                continue

            found_vfx = True
            _add_vertex_color_node_to_node_tree(final_node.node_tree, vcol_name)
            self.report({'INFO'}, f"Added Vertex Color node for '{vcol_name}' to Shader Layer - VFX on {obj.name}")

            if not opened_vfx:
                opened_vfx = _open_shader_layer_vfx_window(
                    context,
                    obj,
                    material,
                    shader_layers_node,
                    final_node,
                )

        if found_vfx and not opened_vfx:
            self.report({'WARNING'}, "Added Vertex Color node, but could not open Shader Layer - VFX")

def register():
    bpy.utils.register_class(DynamicPressureMaterialItem)
    bpy.utils.register_class(DYNAMIC_PRESSURE_UL_MaterialList)
    bpy.utils.register_class(DYNAMIC_PRESSURE_OT_SelectAllMaterials)
    bpy.utils.register_class(DYNAMIC_PRESSURE_OT_DeselectAllMaterials)
    bpy.utils.register_class(DynamicPressureCanvasProperties)
    bpy.utils.register_class(DYNAMIC_PRESSURE_CANVAS_OT_Operator)
    
    # Register window manager property for storing the material list
    bpy.types.WindowManager.dynamic_pressure_canvas = bpy.props.PointerProperty(type=DynamicPressureCanvasProperties)

def unregister():
    # Unregister in reverse order
    del bpy.types.WindowManager.dynamic_pressure_canvas
    
    bpy.utils.unregister_class(DYNAMIC_PRESSURE_CANVAS_OT_Operator)
    bpy.utils.unregister_class(DynamicPressureCanvasProperties)
    bpy.utils.unregister_class(DYNAMIC_PRESSURE_OT_DeselectAllMaterials)
    bpy.utils.unregister_class(DYNAMIC_PRESSURE_OT_SelectAllMaterials)
    bpy.utils.unregister_class(DYNAMIC_PRESSURE_UL_MaterialList)
    bpy.utils.unregister_class(DynamicPressureMaterialItem)

if __name__ == "__main__":
    register()
