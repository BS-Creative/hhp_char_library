import bpy

def self_report(message):
    """Show error messages (no success pop-ups)."""
    print(message)
    bpy.context.window_manager.popup_menu(
        lambda self, ctx: self.layout.label(text=message),
        title="Error", icon='ERROR'
    )

class HHP_OT_create_mask(bpy.types.Operator):
    """Mask selected vertices by modifier & assign as HHP Misc property"""
    bl_idname = "hhp.create_mask"
    bl_label = "Create HHP Mask"
    bl_description = "Create a mask from selected vertices that can be toggled as a custom property from the misc panel inside of the customize panel"
    bl_options = {'REGISTER', 'UNDO'}

    mask_name: bpy.props.StringProperty(
        name="Mask Name",
        description="Name for the mask setup",
        default="New"
    )
    
    # Store the original name to handle updates
    _original_name: str = ""

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH' and 
                context.active_object and 
                context.active_object.type == 'MESH')

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = context.active_object
        
        # If this is the first execution (not an update)
        if not self._original_name:
            prop_name = f"Mask - {self.mask_name}"
            vgroup_name = f"(HHP) Mask - {self.mask_name}"
            mod_name = f"(HHP) Mask - {self.mask_name}"
            
            # Check if any of the data already exists
            if (prop_name in obj or 
                vgroup_name in obj.vertex_groups or 
                mod_name in obj.modifiers):
                self_report("Data already exists. Select a different name.")
                return {'CANCELLED'}

            # Create custom property
            obj[prop_name] = True
            ui_data = obj.id_properties_ui(prop_name)
            ui_data.update(description=f"Toggle for {self.mask_name} mask")
            rna_ui = obj.get('_RNA_UI', {})
            rna_ui[prop_name] = {
                "min": 0.0,
                "max": 1.0,
                "soft_min": 0.0,
                "soft_max": 1.0,
                "description": f"Toggle for {self.mask_name} mask"
            }
            obj['_RNA_UI'] = rna_ui

            # Create vertex group from selection and assign selected vertices
            mask_group = obj.vertex_groups.new(name=vgroup_name)
            obj.vertex_groups.active = mask_group  # Set this vertex group as active
            bpy.ops.object.vertex_group_assign()

            # Add mask modifier
            mask_mod = obj.modifiers.new(name=mod_name, type='MASK')
            mask_mod.vertex_group = vgroup_name
            mask_mod.invert_vertex_group = True
            # Turn on "on cage" and "edit mode" display for the mask modifier
            mask_mod.show_on_cage = True
            mask_mod.show_in_editmode = True

            # Move modifier above last subdivision (lower index, calculated before)
            last_subsurf_idx = -1
            for i, mod in enumerate(obj.modifiers):
                if mod.type == 'SUBSURF':
                    last_subsurf_idx = i

            if last_subsurf_idx >= 0:
                current_idx = len(obj.modifiers) - 1
                positions_to_move = current_idx - last_subsurf_idx
                for _ in range(positions_to_move):
                    bpy.ops.object.modifier_move_up(modifier=mask_mod.name)

            # Add drivers
            for state in ['show_viewport', 'show_render']:
                # Always try to remove any existing driver first
                try:
                    mask_mod.driver_remove(state)
                except:
                    pass
                
                # Create new driver
                driver = mask_mod.driver_add(state).driver
                driver.type = 'SCRIPTED'
                
                # Clear any existing variables
                for var in driver.variables:
                    driver.variables.remove(var)
                
                # Create new variable
                var = driver.variables.new()
                var.name = 'mask_toggle'
                var.type = 'SINGLE_PROP'
                
                target = var.targets[0]
                target.id_type = 'OBJECT'
                target.id = obj
                target.data_path = f'["{prop_name}"]'
                
                # Set expression to use the variable directly
                driver.expression = 'mask_toggle'

            # Store the original name for future updates
            self._original_name = self.mask_name

            # Reassign selected vertices to the updated vertex group
            vgroup = obj.vertex_groups.get(vgroup_name)
            if vgroup:
                obj.vertex_groups.active = vgroup
                bpy.ops.object.vertex_group_assign()

        else:
            # This is an update - rename existing items
            old_prop_name = f"Mask - {self._original_name}"
            old_vgroup_name = f"(HHP) Mask - {self._original_name}"
            old_mod_name = f"(HHP) Mask - {self._original_name}"

            new_prop_name = f"Mask - {self.mask_name}"
            new_vgroup_name = f"(HHP) Mask - {self.mask_name}"
            new_mod_name = f"(HHP) Mask - {self.mask_name}"

            # Check if new names would conflict with existing items
            if ((new_prop_name in obj and new_prop_name != old_prop_name) or 
                (new_vgroup_name in obj.vertex_groups and new_vgroup_name != old_vgroup_name) or 
                (new_mod_name in obj.modifiers and new_mod_name != old_mod_name)):
                self_report("Cannot rename: target names already exist.")
                return {'CANCELLED'}

            # Rename the custom property
            if old_prop_name in obj:
                value = obj[old_prop_name]
                rna_ui = obj.get('_RNA_UI', {})
                prop_ui = rna_ui.get(old_prop_name, {})
                
                del obj[old_prop_name]
                obj[new_prop_name] = value
                
                if prop_ui:
                    rna_ui[new_prop_name] = prop_ui
                    del rna_ui[old_prop_name]
                    obj['_RNA_UI'] = rna_ui

            # Rename the vertex group
            vgroup = obj.vertex_groups.get(old_vgroup_name)
            if vgroup:
                vgroup.name = new_vgroup_name

            # Rename the modifier and update its vertex group reference
            mod = obj.modifiers.get(old_mod_name)
            if mod:
                mod.name = new_mod_name
                mod.vertex_group = new_vgroup_name

                # Turn on "on cage" and "edit mode" display for the mask modifier
                mod.show_on_cage = True
                mod.show_in_editmode = True

                # Update drivers to point to new property
                for state in ['show_viewport', 'show_render']:
                    try:
                        mod.driver_remove(state)
                    except:
                        pass
                    
                    driver = mod.driver_add(state).driver
                    driver.type = 'SCRIPTED'
                    
                    # Clear any existing variables
                    for var in driver.variables:
                        driver.variables.remove(var)
                    
                    # Create new variable
                    var = driver.variables.new()
                    var.name = 'mask_toggle'
                    var.type = 'SINGLE_PROP'
                    
                    target = var.targets[0]
                    target.id_type = 'OBJECT'
                    target.id = obj
                    target.data_path = f'["{new_prop_name}"]'
                    
                    # Set expression to use the variable directly
                    driver.expression = 'mask_toggle'

                # Move modifier above last subdivision (lower index, calculated before)
                last_subsurf_idx = -1
                for i, modifier in enumerate(obj.modifiers):
                    if modifier.type == 'SUBSURF':
                        last_subsurf_idx = i

                if last_subsurf_idx >= 0:
                    # Find current position of our mask modifier
                    current_idx = -1
                    for i, modifier in enumerate(obj.modifiers):
                        if modifier == mod:
                            current_idx = i
                            break
                    
                    if current_idx > last_subsurf_idx:
                        positions_to_move = current_idx - last_subsurf_idx
                        for _ in range(positions_to_move):
                            bpy.ops.object.modifier_move_up(modifier=mod.name)

            # Update the stored original name
            self._original_name = self.mask_name

            # Reassign selected vertices to the updated vertex group
            vgroup = obj.vertex_groups.get(new_vgroup_name)
            if vgroup:
                obj.vertex_groups.active = vgroup
                bpy.ops.object.vertex_group_assign()

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "mask_name")

def register():
    bpy.utils.register_class(HHP_OT_create_mask)

def unregister():
    bpy.utils.unregister_class(HHP_OT_create_mask) 