import bpy
import json
import os
import re

_BS_COMPOSITING_HANDLER_TAG = "_bs_compositing_enforcer"
_HHP_COMPOSITOR_NAME = "HHP Compositor"


def _bs_is_blender_5_plus():
    try:
        return bpy.app.version >= (5, 0, 0)
    except Exception:
        return False


def _bs_get_scene_compositor_tree(scene):
    """
    Blender < 5:
      - Compositor nodes live on `scene.node_tree` when `scene.use_nodes = True`.

    Blender 5+:
      - Compositor nodes live in a compositor node group datablock assigned to the scene.
      - Different builds may expose different RNA names; we probe a few.
    """
    if not scene:
        return None

    # Blender 5+: prefer assigned compositor group/node tree
    if _bs_is_blender_5_plus():
        # Common experimental/property naming variants.
        for attr in ("compositing_node_group", "compositor_node_group", "compositor_node_tree"):
            try:
                ng = getattr(scene, attr, None)
            except Exception:
                ng = None
            if ng is not None:
                return ng

        # Some builds expose a `scene.compositor` object that holds the node group/tree.
        comp = getattr(scene, "compositor", None)
        if comp is not None:
            for attr in ("node_group", "node_tree"):
                try:
                    ng = getattr(comp, attr, None)
                except Exception:
                    ng = None
                if ng is not None:
                    return ng

    # Fallback (legacy)
    return getattr(scene, "node_tree", None)


def _bs_assign_scene_compositor_tree(scene, tree):
    """Assign a compositor node tree/group to the scene (Blender 5+) when possible."""
    if not scene:
        return False

    if _bs_is_blender_5_plus():
        for attr in ("compositing_node_group", "compositor_node_group", "compositor_node_tree"):
            if hasattr(scene, attr):
                try:
                    setattr(scene, attr, tree)
                    return True
                except Exception:
                    pass

        comp = getattr(scene, "compositor", None)
        if comp is not None:
            for attr in ("node_group", "node_tree"):
                if hasattr(comp, attr):
                    try:
                        setattr(comp, attr, tree)
                        return True
                    except Exception:
                        pass

    return False


def _bs_find_any_node_editor_override():
    """
    Try to find a NODE_EDITOR area we can use for operator context overrides.
    Some node operators require a node editor context.
    """
    wm = bpy.context.window_manager
    if not wm:
        return None

    for win in wm.windows:
        screen = getattr(win, "screen", None)
        if not screen:
            continue
        for area in getattr(screen, "areas", []):
            if area.type != 'NODE_EDITOR':
                continue
            region = None
            for r in getattr(area, "regions", []):
                if r.type == 'WINDOW':
                    region = r
                    break
            override = {"window": win, "screen": screen, "area": area}
            if region is not None:
                override["region"] = region
            return override
    return None


def _bs_ensure_hhp_compositor_tree(scene, context=None):
    """
    Blender 5+: ensure the scene has the dedicated "HHP Compositor" node tree assigned.

    Important:
      - We must NOT modify whatever compositor tree the user already had assigned.
      - Instead, we create/use a separate compositing tree named "HHP Compositor" and
        assign it while the toggle is enabled. On toggle OFF, we restore the previous tree.

    Requirement from user: create via
      bpy.ops.node.new_compositing_node_group(name="Compositor Nodes")
    then name it "HHP Compositor".
    """
    if not scene:
        return None

    if not _bs_is_blender_5_plus():
        return None

    # If the scene already has our dedicated tree assigned, reuse it.
    current = _bs_get_scene_compositor_tree(scene)
    if current is not None and getattr(current, "name", "") == _HHP_COMPOSITOR_NAME:
        try:
            current.use_fake_user = True
        except Exception:
            pass
        return current

    # If an HHP compositor tree datablock already exists, assign it and return it.
    existing = None
    try:
        existing = bpy.data.node_groups.get(_HHP_COMPOSITOR_NAME)
    except Exception:
        existing = None
    if existing is not None:
        _bs_assign_scene_compositor_tree(scene, existing)
        try:
            existing.use_fake_user = True
        except Exception:
            pass
        return existing

    # Try the requested operator first (may fail without a NODE_EDITOR context).
    created_tree = None
    try:
        before_tree = _bs_get_scene_compositor_tree(scene)
        res = bpy.ops.node.new_compositing_node_group(name="Compositor Nodes")
        after_tree = _bs_get_scene_compositor_tree(scene)
        # IMPORTANT: Some builds return {'CANCELLED'} without raising an exception, leaving the
        # current compositor tree unchanged. In that case, DO NOT rename/modify the user's tree.
        if ('FINISHED' in res) and (after_tree is not None) and (after_tree != before_tree):
            created_tree = after_tree
        else:
            created_tree = None
    except Exception:
        created_tree = None

    if created_tree is None:
        override = _bs_find_any_node_editor_override()
        if override and hasattr(bpy.context, "temp_override"):
            try:
                with bpy.context.temp_override(**override):
                    before_tree = _bs_get_scene_compositor_tree(scene)
                    res = bpy.ops.node.new_compositing_node_group(name="Compositor Nodes")
                    after_tree = _bs_get_scene_compositor_tree(scene)
                if ('FINISHED' in res) and (after_tree is not None) and (after_tree != before_tree):
                    created_tree = after_tree
                else:
                    created_tree = None
            except Exception:
                created_tree = None

    # Fallback: create a compositor node tree datablock directly and assign it.
    if created_tree is None:
        try:
            created_tree = bpy.data.node_groups.new(name=_HHP_COMPOSITOR_NAME, type="CompositorNodeTree")
        except Exception:
            created_tree = None
        if created_tree is not None:
            _bs_assign_scene_compositor_tree(scene, created_tree)

    # Enforce naming requirement.
    if created_tree is not None:
        try:
            created_tree.name = _HHP_COMPOSITOR_NAME
        except Exception:
            pass
        # Ensure the scene is using this dedicated tree (operator creation should have done it,
        # but we enforce it here in case naming changes confused the assignment).
        _bs_assign_scene_compositor_tree(scene, created_tree)
        # Mark as Fake User ("F") so it is kept even if unlinked.
        try:
            created_tree.use_fake_user = True
        except Exception:
            pass

    return created_tree


def _bs_add_node_to_tree(tree, node_type: str, use_transform: bool = True):
    """
    Try to add a node via bpy.ops.node.add_node (user requested for Blender 5),
    but fall back to direct API creation if operator context isn't available.
    Returns the created node or None.
    """
    if not tree:
        return None

    # Operator path (requires a NODE_EDITOR + correct node tree in context)
    try:
        override = _bs_find_any_node_editor_override()
        if override and hasattr(bpy.context, "temp_override"):
            with bpy.context.temp_override(**override):
                # Ensure the node editor is looking at this tree
                try:
                    for space in override["area"].spaces:
                        if space.type == 'NODE_EDITOR':
                            space.node_tree = tree
                            break
                except Exception:
                    pass

                res = bpy.ops.node.add_node(use_transform=use_transform, type=node_type)
                if 'FINISHED' in res:
                    try:
                        node = getattr(bpy.context, "active_node", None)
                    except Exception:
                        node = None
                    if node is not None:
                        return node
    except Exception:
        pass

    # Direct API fallback
    try:
        return tree.nodes.new(node_type)
    except Exception:
        try:
            return tree.nodes.new(type=node_type)
        except Exception:
            return None


def _bs_ensure_group_output_socket(tree, name="Image", socket_type="NodeSocketColor"):
    """Ensure the compositor node group has an output socket called `name`."""
    if not tree:
        return None
    iface = getattr(tree, "interface", None)
    if iface is None:
        return None

    try:
        # Blender 4.0+ node group interface API
        for s in iface.items_tree:
            try:
                if getattr(s, "in_out", None) == 'OUTPUT' and getattr(s, "name", None) == name:
                    return s
            except Exception:
                continue
    except Exception:
        pass

    try:
        return iface.new_socket(name=name, in_out='OUTPUT', socket_type=socket_type)
    except Exception:
        return None


def _bs_set_viewport_use_compositor(value: str):
    """Set viewport shading compositor mode for all 3D view spaces."""
    wm = bpy.context.window_manager
    if not wm:
        return

    for win in wm.windows:
        screen = win.screen
        if not screen:
            continue
        for area in screen.areas:
            if area.type != 'VIEW_3D':
                continue
            for space in area.spaces:
                if space.type != 'VIEW_3D':
                    continue
                shading = getattr(space, "shading", None)
                if shading and hasattr(shading, "use_compositor"):
                    try:
                        shading.use_compositor = value
                    except Exception:
                        pass


def _bs_snapshot_viewport_use_compositor():
    """
    Snapshot compositor mode per VIEW_3D space so we can restore accurately.
    Key format: "{screen_name}|{area_index}|{space_index}"
    """
    wm = bpy.context.window_manager
    snapshot = {"__default__": "AUTO", "spaces": {}}
    if not wm:
        return snapshot

    default = None
    for win in wm.windows:
        screen = win.screen
        if not screen:
            continue
        for area_index, area in enumerate(screen.areas):
            if area.type != 'VIEW_3D':
                continue
            for space_index, space in enumerate(area.spaces):
                if space.type != 'VIEW_3D':
                    continue
                shading = getattr(space, "shading", None)
                if shading and hasattr(shading, "use_compositor"):
                    try:
                        mode = shading.use_compositor
                        if default is None:
                            default = mode
                        key = f"{screen.name}|{area_index}|{space_index}"
                        snapshot["spaces"][key] = mode
                    except Exception:
                        pass

    snapshot["__default__"] = default if default is not None else "AUTO"
    return snapshot


def _bs_restore_viewport_use_compositor(snapshot):
    """Restore compositor mode per VIEW_3D space from snapshot created by _bs_snapshot_viewport_use_compositor()."""
    wm = bpy.context.window_manager
    if not wm:
        return

    spaces = snapshot.get("spaces", {}) if isinstance(snapshot, dict) else {}
    default = snapshot.get("__default__", "AUTO") if isinstance(snapshot, dict) else "AUTO"

    for win in wm.windows:
        screen = win.screen
        if not screen:
            continue
        for area_index, area in enumerate(screen.areas):
            if area.type != 'VIEW_3D':
                continue
            for space_index, space in enumerate(area.spaces):
                if space.type != 'VIEW_3D':
                    continue
                shading = getattr(space, "shading", None)
                if shading and hasattr(shading, "use_compositor"):
                    key = f"{screen.name}|{area_index}|{space_index}"
                    mode = spaces.get(key, default)
                    try:
                        shading.use_compositor = mode
                    except Exception:
                        pass


def _bs_enforce_compositing(_dummy=None):
    """
    Keep compositing settings ON while the toggle is enabled.
    This prevents manual edits from making the toggle feel "broken".
    """
    try:
        scene = bpy.context.scene
        if not scene or not getattr(scene, "bs_toggle_compositing", False):
            return

        if scene.render.use_compositing is False:
            scene.render.use_compositing = True
        # Blender 5+ needs a compositor node tree datablock first.
        if _bs_is_blender_5_plus():
            _bs_ensure_hhp_compositor_tree(scene, context=bpy.context)
        else:
            if scene.use_nodes is False:
                scene.use_nodes = True

        vl = scene.view_layers.get("ViewLayer") if hasattr(scene, "view_layers") else None
        if vl is None:
            vl = getattr(bpy.context, "view_layer", None)
        if vl is not None:
            if hasattr(vl, "use_pass_z") and vl.use_pass_z is False:
                vl.use_pass_z = True
            if hasattr(vl, "use_pass_ambient_occlusion") and vl.use_pass_ambient_occlusion is False:
                vl.use_pass_ambient_occlusion = True

        _bs_set_viewport_use_compositor('ALWAYS')
    except Exception:
        pass


def _bs_parse_composite_magic_version(name: str):
    m = re.match(r"^Composite Magic\s+(\d+(?:\.\d+)*)\b", name.strip())
    if not m:
        return None
    try:
        return tuple(int(p) for p in m.group(1).split("."))
    except Exception:
        return None


def _bs_pick_latest_composite_magic_name(names):
    best = None
    best_ver = None
    for n in names:
        ver = _bs_parse_composite_magic_version(n)
        if ver is None:
            continue
        if best_ver is None or ver > best_ver:
            best_ver = ver
            best = n
    return best, best_ver


def _bs_get_asset_blend_path():
    addon_root = os.path.dirname(os.path.dirname(__file__))
    return os.path.join(addon_root, "assets", "HHP_library.blend")


def _bs_ensure_latest_composite_magic_node_group():
    """
    Ensure the newest 'Composite Magic x.y' node group exists in the current file.
    If it already exists, reuse it (no append). Otherwise append the newest from the asset blend.
    """
    blend_path = _bs_get_asset_blend_path()
    if not os.path.exists(blend_path):
        print(f"[HHP] Composite Magic: asset blend not found: {blend_path}")
        return None

    try:
        with bpy.data.libraries.load(blend_path, link=False) as (data_from, _data_to):
            lib_names = list(getattr(data_from, "node_groups", []))
    except Exception as e:
        print(f"[HHP] Composite Magic: failed to read asset blend: {e}")
        return None

    lib_best_name, lib_best_ver = _bs_pick_latest_composite_magic_name(lib_names)
    if not lib_best_name:
        print("[HHP] Composite Magic: no matching node group found in asset blend")
        return None

    existing_names = [ng.name for ng in bpy.data.node_groups if _bs_parse_composite_magic_version(ng.name)]
    exist_best_name, exist_best_ver = _bs_pick_latest_composite_magic_name(existing_names)

    if exist_best_ver is not None and lib_best_ver is not None and exist_best_ver >= lib_best_ver:
        return bpy.data.node_groups.get(exist_best_name)

    if bpy.data.node_groups.get(lib_best_name):
        return bpy.data.node_groups.get(lib_best_name)

    try:
        with bpy.data.libraries.load(blend_path, link=False) as (data_from, data_to):
            if lib_best_name in data_from.node_groups:
                data_to.node_groups = [lib_best_name]
    except Exception as e:
        print(f"[HHP] Composite Magic: failed to append '{lib_best_name}': {e}")
        return None

    return bpy.data.node_groups.get(lib_best_name)


def _bs_setup_composite_magic(scene, view_layer_name: str):
    """
    Create/ensure compositor graph:
      Render Layers (Image/Depth/AO) -> Composite Magic (Image/Depth/AO) -> Composite + Viewer
    """
    if not scene:
        return

    if _bs_is_blender_5_plus():
        tree = _bs_ensure_hhp_compositor_tree(scene, context=bpy.context)
    else:
        scene.use_nodes = True
        tree = scene.node_tree
    if not tree:
        return

    ng = _bs_ensure_latest_composite_magic_node_group()
    if not ng:
        return

    rl = None
    for n in tree.nodes:
        if n.bl_idname == "CompositorNodeRLayers":
            if getattr(n, "scene", None) is None or getattr(n, "scene", None) == scene:
                rl = n
                break
    if rl is None:
        rl = tree.nodes.new("CompositorNodeRLayers")
    rl.scene = scene
    try:
        rl.layer = view_layer_name
    except Exception:
        pass
    rl.location = (-400, 200)

    cm = None
    for n in tree.nodes:
        if n.bl_idname == "CompositorNodeGroup" and getattr(n, "node_tree", None) == ng:
            cm = n
            break
    if cm is None:
        cm = tree.nodes.new("CompositorNodeGroup")
        cm.node_tree = ng
    cm.location = (0, 200)

    # Output + Viewer:
    # Blender < 5 uses CompositorNodeComposite.
    # Blender 5+ uses a compositor node group tree, so we must use NodeGroupOutput.
    if _bs_is_blender_5_plus():
        _bs_ensure_group_output_socket(tree, name="Image", socket_type="NodeSocketColor")

        group_out = next((n for n in tree.nodes if n.bl_idname == "NodeGroupOutput"), None)
        if group_out is None:
            # User requested ops usage for these nodes
            group_out = _bs_add_node_to_tree(tree, node_type="NodeGroupOutput", use_transform=True)
        if group_out is None:
            group_out = tree.nodes.new("NodeGroupOutput")
        group_out.location = (350, 240)

        viewer = next((n for n in tree.nodes if n.bl_idname == "CompositorNodeViewer"), None)
        if viewer is None:
            viewer = _bs_add_node_to_tree(tree, node_type="CompositorNodeViewer", use_transform=True)
        if viewer is None:
            viewer = tree.nodes.new("CompositorNodeViewer")
        viewer.location = (350, 80)
    else:
        comp = next((n for n in tree.nodes if n.bl_idname == "CompositorNodeComposite"), None)
        if comp is None:
            comp = tree.nodes.new("CompositorNodeComposite")
        comp.location = (350, 240)

        viewer = next((n for n in tree.nodes if n.bl_idname == "CompositorNodeViewer"), None)
        if viewer is None:
            viewer = tree.nodes.new("CompositorNodeViewer")
        viewer.location = (350, 80)

    def _socket(node_sockets, name, fallback=None):
        s = node_sockets.get(name)
        if s is not None:
            return s
        if not fallback:
            return None
        # Allow a single fallback name or a list/tuple of fallback names
        if isinstance(fallback, (list, tuple)):
            for fb in fallback:
                s2 = node_sockets.get(fb)
                if s2 is not None:
                    return s2
            return None
        return node_sockets.get(fallback)

    def _link(from_socket, to_socket):
        if not from_socket or not to_socket:
            return
        if hasattr(to_socket, "is_linked") and to_socket.is_linked:
            for l in list(to_socket.links):
                try:
                    tree.links.remove(l)
                except Exception:
                    pass
        try:
            tree.links.new(from_socket, to_socket)
        except Exception:
            pass

    _link(_socket(rl.outputs, "Image"), _socket(cm.inputs, "Image"))
    _link(_socket(rl.outputs, "Depth", fallback="Z"), _socket(cm.inputs, "Depth"))
    # Blender versions use either "AO" or "Ambient Occlusion" for this pass socket name.
    _link(_socket(rl.outputs, "AO", fallback=["Ambient Occlusion"]), _socket(cm.inputs, "AO"))

    if _bs_is_blender_5_plus():
        # NodeGroupOutput has inputs created from the group's interface (we ensure "Image" exists).
        _link(_socket(cm.outputs, "Image"), _socket(group_out.inputs, "Image") or (group_out.inputs[0] if group_out.inputs else None))
        _link(_socket(cm.outputs, "Image"), _socket(viewer.inputs, "Image"))
    else:
        _link(_socket(cm.outputs, "Image"), _socket(comp.inputs, "Image"))
        _link(_socket(cm.outputs, "Image"), _socket(viewer.inputs, "Image"))


def _bs_find_best_composite_magic_group_node(tree):
    best_node = None
    best_ver = None
    if not tree:
        return None
    for n in tree.nodes:
        if n.bl_idname != "CompositorNodeGroup":
            continue
        ng = getattr(n, "node_tree", None)
        if not ng:
            continue
        ver = _bs_parse_composite_magic_version(ng.name)
        if ver is None:
            continue
        if best_ver is None or ver > best_ver:
            best_ver = ver
            best_node = n
    return best_node


def _draw_composite_magic_inputs_clean(layout, scene, exclude_sockets=None):
    tree = _bs_get_scene_compositor_tree(scene)
    if not scene or not tree:
        layout.label(text="Compositor nodes are not enabled for this scene.", icon='INFO')
        return

    node = _bs_find_best_composite_magic_group_node(tree)
    if not node:
        layout.label(text="Composite Magic node not found (toggle ON to set it up).", icon='INFO')
        return

    exclude_sockets = set(exclude_sockets or [])
    inputs = node.inputs
    existing_sockets = [s for s in inputs if s.name not in exclude_sockets]
    if not existing_sockets:
        layout.label(text="No Composite Magic inputs to display.", icon='INFO')
        return

    ordered = []
    current_row = []
    for sock in existing_sockets:
        current_row.append(sock)
        if len(current_row) == 2:
            ordered.append(current_row)
            current_row = []
    if current_row:
        ordered.append(current_row)

    col = layout.column(align=True)
    for row_socks in ordered:
        row = col.row(align=True)
        for sock in row_socks:
            if sock.is_linked and sock.links:
                linked_node = sock.links[0].from_node
                out = linked_node.outputs[0] if getattr(linked_node, "outputs", None) else None
                if out and hasattr(out, "default_value"):
                    try:
                        if sock.type == 'RGBA':
                            row.prop(out, 'default_value', text="")
                        elif out.bl_rna.properties.get('default_value').type == 'BOOLEAN':
                            row.prop(out, 'default_value', text=sock.name, toggle=True)
                        else:
                            row.prop(out, 'default_value', text=sock.name)
                    except Exception:
                        row.label(text=sock.name)
                else:
                    row.label(text=sock.name)
            else:
                if sock.type == 'RGBA':
                    row.prop(sock, 'default_value', text="")
                elif hasattr(sock, 'default_value') and isinstance(sock.default_value, bool):
                    row.prop(sock, 'default_value', text=sock.name, toggle=True)
                else:
                    row.prop(sock, 'default_value', text=sock.name)


def _update_toggle(self, context):
    scene = context.scene if context else None
    if not scene:
        return

    if self.bs_toggle_compositing:
        # Fresh snapshot each ON
        scene.bs_prev_compositing_stored = False

        scene.bs_prev_use_compositing = bool(scene.render.use_compositing)
        scene.bs_prev_use_nodes = bool(getattr(scene, "use_nodes", False))
        # Blender 5+: remember existing compositor group so we can restore it.
        try:
            prev_tree = _bs_get_scene_compositor_tree(scene)
            scene.bs_prev_compositor_tree_name = (prev_tree.name if prev_tree else "")
        except Exception:
            scene.bs_prev_compositor_tree_name = ""
        scene.bs_prev_viewport_use_compositor_json = json.dumps(_bs_snapshot_viewport_use_compositor())

        vl = scene.view_layers.get("ViewLayer") if hasattr(scene, "view_layers") else None
        if vl is None:
            vl = context.view_layer if context else None
        scene.bs_prev_pass_layer_name = vl.name if vl else ""
        scene.bs_prev_use_pass_z = bool(getattr(vl, "use_pass_z", False)) if vl else False
        scene.bs_prev_use_pass_ambient_occlusion = bool(getattr(vl, "use_pass_ambient_occlusion", False)) if vl else False

        scene.bs_prev_compositing_stored = True

        scene.render.use_compositing = True
        if _bs_is_blender_5_plus():
            _bs_ensure_hhp_compositor_tree(scene, context=context)
        else:
            scene.use_nodes = True
        _bs_set_viewport_use_compositor('ALWAYS')

        if vl is not None:
            if hasattr(vl, "use_pass_z"):
                vl.use_pass_z = True
            if hasattr(vl, "use_pass_ambient_occlusion"):
                vl.use_pass_ambient_occlusion = True

        try:
            _bs_setup_composite_magic(scene, view_layer_name=(vl.name if vl else "ViewLayer"))
        except Exception as e:
            print(f"[HHP] Composite Magic setup failed: {e}")
    else:
        if scene.bs_prev_compositing_stored:
            scene.render.use_compositing = bool(scene.bs_prev_use_compositing)
            if _bs_is_blender_5_plus():
                # Restore previous compositor group if it still exists; otherwise keep current.
                prev_name = getattr(scene, "bs_prev_compositor_tree_name", "") or ""
                if prev_name:
                    try:
                        prev_tree = bpy.data.node_groups.get(prev_name)
                    except Exception:
                        prev_tree = None
                    if prev_tree is not None:
                        _bs_assign_scene_compositor_tree(scene, prev_tree)
            else:
                scene.use_nodes = bool(scene.bs_prev_use_nodes)

            try:
                snapshot = json.loads(scene.bs_prev_viewport_use_compositor_json) if scene.bs_prev_viewport_use_compositor_json else {}
            except Exception:
                snapshot = {}
            _bs_restore_viewport_use_compositor(snapshot)

            vl = scene.view_layers.get(scene.bs_prev_pass_layer_name) if scene.bs_prev_pass_layer_name else None
            if vl is None:
                vl = context.view_layer if context else None
            if vl is not None:
                if hasattr(vl, "use_pass_z"):
                    vl.use_pass_z = bool(scene.bs_prev_use_pass_z)
                if hasattr(vl, "use_pass_ambient_occlusion"):
                    vl.use_pass_ambient_occlusion = bool(scene.bs_prev_use_pass_ambient_occlusion)

            scene.bs_prev_compositing_stored = False
            scene.bs_prev_viewport_use_compositor_json = ""
            scene.bs_prev_pass_layer_name = ""
            scene.bs_prev_compositor_tree_name = ""


def draw_ui(layout, context):
    """Draw the toggle and (when enabled) the Composite Magic node-group controls."""
    scene = context.scene
    row = layout.row(align=True)
    if scene and hasattr(scene, "bs_toggle_compositing"):
        row.prop(scene, "bs_toggle_compositing", text="Toggle Compositing (HHP)", toggle=True)
        # Reference Blender's own Motion Blur checkbox (Render Properties > Motion Blur).
        row.prop(scene.render, "use_motion_blur", text="", icon='ONIONSKIN_ON', toggle=True)

        # Cycles note: viewport compositor won't show, only final render will.
        try:
            if getattr(scene.render, "engine", "") == 'CYCLES':
                layout.label(
                    text="Compositing only shows on final render for Cycles engine",
                    icon='ERROR'
                )
        except Exception:
            pass

        if scene.bs_toggle_compositing:
            _draw_composite_magic_inputs_clean(layout, scene, exclude_sockets={"Image", "Depth", "AO"})
    else:
        row.label(text="Compositing toggle unavailable.", icon='ERROR')


def register():
    bpy.types.Scene.bs_toggle_compositing = bpy.props.BoolProperty(
        name="Toggle Compositing (HHP)",
        description="Toggle BS-style compositing. In Blender 5+, this will create/assign an 'HHP Compositor' node tree if needed.",
        default=False,
        update=_update_toggle
    )

    bpy.types.Scene.bs_prev_compositing_stored = bpy.props.BoolProperty(
        name="Compositing Previous State Stored",
        description="Internal: whether previous compositing states have been stored",
        default=False
    )
    bpy.types.Scene.bs_prev_use_compositing = bpy.props.BoolProperty(
        name="Previous Use Compositing",
        description="Internal: previous value of render.use_compositing",
        default=False
    )
    bpy.types.Scene.bs_prev_use_nodes = bpy.props.BoolProperty(
        name="Previous Use Nodes",
        description="Internal: previous value of scene.use_nodes",
        default=False
    )
    bpy.types.Scene.bs_prev_compositor_tree_name = bpy.props.StringProperty(
        name="Previous Compositor Tree Name",
        description="Internal: Blender 5+ previous compositor node tree/group name to restore",
        default="",
        options={'HIDDEN'}
    )
    bpy.types.Scene.bs_prev_pass_layer_name = bpy.props.StringProperty(
        name="Previous Pass Layer Name",
        description="Internal: view layer name used for pass snapshot/restore",
        default="",
        options={'HIDDEN'}
    )
    bpy.types.Scene.bs_prev_use_pass_z = bpy.props.BoolProperty(
        name="Previous Use Pass Z",
        description="Internal: previous value of view_layer.use_pass_z",
        default=False,
        options={'HIDDEN'}
    )
    bpy.types.Scene.bs_prev_use_pass_ambient_occlusion = bpy.props.BoolProperty(
        name="Previous Use Pass Ambient Occlusion",
        description="Internal: previous value of view_layer.use_pass_ambient_occlusion",
        default=False,
        options={'HIDDEN'}
    )
    bpy.types.Scene.bs_prev_viewport_use_compositor_json = bpy.props.StringProperty(
        name="Previous Viewport Use Compositor (JSON)",
        description="Internal: JSON snapshot of viewport shading compositor modes",
        default="",
        options={'HIDDEN'}
    )

    handlers = bpy.app.handlers.depsgraph_update_post
    if getattr(_bs_enforce_compositing, _BS_COMPOSITING_HANDLER_TAG, False) is False:
        try:
            handlers.append(_bs_enforce_compositing)
            setattr(_bs_enforce_compositing, _BS_COMPOSITING_HANDLER_TAG, True)
        except Exception:
            pass


def unregister():
    for prop in (
        "bs_toggle_compositing",
        "bs_prev_compositing_stored",
        "bs_prev_use_compositing",
        "bs_prev_use_nodes",
        "bs_prev_compositor_tree_name",
        "bs_prev_pass_layer_name",
        "bs_prev_use_pass_z",
        "bs_prev_use_pass_ambient_occlusion",
        "bs_prev_viewport_use_compositor_json",
    ):
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)

    try:
        handlers = bpy.app.handlers.depsgraph_update_post
        if _bs_enforce_compositing in handlers:
            handlers.remove(_bs_enforce_compositing)
        setattr(_bs_enforce_compositing, _BS_COMPOSITING_HANDLER_TAG, False)
    except Exception:
        pass


