"""Shared membership prompt for characters without breast modifiers."""

import bpy

from . import hhp_naming


MEMBERSHIP_URL = "https://www.patreon.com/BS_Creative/membership"


class HHP_OT_UnlockFullCharacter(bpy.types.Operator):
    bl_idname = "hhp.unlock_full_character"
    bl_label = "Unlock Full Character"
    bl_description = "Unlock full-featured character with full animation and full physics features"

    def execute(self, context):
        return bpy.ops.wm.url_open(url=MEMBERSHIP_URL)


def needs_full_character(context):
    """Only the active HHP body can trigger the prompt, never other scene meshes.

    Disabled Breast modifiers still count as present.
    """
    active = context.active_object
    return hhp_naming.is_char_mesh(active) and not any(
        "breast" in modifier.name.casefold()
        for modifier in active.modifiers
    )


def draw_unlock_button(layout):
    """Draw the same full-width alert link in both character and physics UI."""
    row = layout.row()
    row.alert = True
    row.scale_y = 2.0
    row.operator(
        HHP_OT_UnlockFullCharacter.bl_idname, text="Unlock Full Character", icon='UNLOCKED'
    )


def register():
    bpy.utils.register_class(HHP_OT_UnlockFullCharacter)


def unregister():
    bpy.utils.unregister_class(HHP_OT_UnlockFullCharacter)
