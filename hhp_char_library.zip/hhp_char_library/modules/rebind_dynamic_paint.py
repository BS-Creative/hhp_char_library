import bpy

class REBIND_DYNAMIC_PAINT_OT_Operator(bpy.types.Operator):
    bl_idname = "object.rebind_dynamic_paint"
    bl_label = "Rebind Dynamic Paint"
    bl_description = "Update and rebind dynamic paint to scene"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        
        # Stop animation playback
        bpy.ops.screen.animation_cancel(restore_frame=False)
        
        # Go to start frame
        scene.frame_set(scene.frame_start)
        
        updated_objects = 0
        updated_surfaces = 0
        
        # Store the original active object and mode
        original_active = context.view_layer.objects.active
        original_mode = context.mode
        
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                # Set this object as active
                context.view_layer.objects.active = obj
                
                # Toggle in and out of edit mode to refresh the mesh
                if obj.mode != 'EDIT':
                    bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.object.mode_set(mode='OBJECT')
                
                # Look for Dynamic Paint modifiers in Canvas mode
                for mod in obj.modifiers:
                    if mod.type == 'DYNAMIC_PAINT' and hasattr(mod, 'canvas_settings'):
                        canvas = mod.canvas_settings
                        if canvas and canvas.canvas_surfaces:
                            # Update each canvas surface
                            for surface in canvas.canvas_surfaces:
                                # Update frame range
                                surface.frame_start = scene.frame_start
                                surface.frame_end = scene.frame_end
                                # Update cache name to be unique based on object and canvas names
                                surface.point_cache.name = f"{obj.name}_{surface.name}"
                                updated_surfaces += 1
                            updated_objects += 1

        # Restore the original active object and mode
        context.view_layer.objects.active = original_active
        if original_mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode=original_mode)
            except:
                # If we can't set back to the original mode, just stay in object mode
                pass

        if updated_surfaces > 0:
            self.report({'INFO'}, f"Rebound {updated_surfaces} canvas surfaces on {updated_objects} objects")
        else:
            self.report({'WARNING'}, "No Dynamic Paint canvas surfaces found on selected objects")
            
        return {'FINISHED'}

def register():
    bpy.utils.register_class(REBIND_DYNAMIC_PAINT_OT_Operator)

def unregister():
    bpy.utils.unregister_class(REBIND_DYNAMIC_PAINT_OT_Operator) 