import bpy

class REBIND_DYNAMIC_PAINT_OT_Operator(bpy.types.Operator):
    bl_idname = "object.rebind_dynamic_paint"
    bl_label = "Rebind Dynamic Paint"
    bl_description = "Update and rebind dynamic paint to scene"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return {'FINISHED'}

def register():
    bpy.utils.register_class(REBIND_DYNAMIC_PAINT_OT_Operator)

def unregister():
    bpy.utils.unregister_class(REBIND_DYNAMIC_PAINT_OT_Operator) 