import bpy
import json
import os

from bpy_extras.io_utils import ImportHelper
from bpy.props import BoolProperty, StringProperty, CollectionProperty, EnumProperty
from bpy.types import Operator


class HHP_OT_Import_FACS_JSON(bpy.types.Operator, ImportHelper):
    bl_idname = "hhp.import_facs_json"
    bl_label = "Import FACS Json"
    bl_description = "Import JSON files as shapekey animations for use with HHP characters. Compatible with Nvidia Omniverse Audio2Face"
    bl_options = {'REGISTER', 'UNDO'}

    # File selection properties
    files: CollectionProperty(
        type=bpy.types.OperatorFileListElement,
        options={'HIDDEN', 'SKIP_SAVE'}
    )
    directory: StringProperty(
        subtype='DIR_PATH',
        options={'HIDDEN'}
    )
    filename_ext = ".json"
    filter_glob: StringProperty(
        default="*.json",
        options={'HIDDEN'},
    )

    # Mouth-only shapekeys list
    MOUTH_SHAPEKEYS = []
    
    # Import mode
    import_mode: EnumProperty(
        name="Import Mode",
        description="Select which shapekeys to import",
        items=[
            ('FULL', "Full Face", "Import full shapekey animation from the JSON file"),
            ('MOUTH_ONLY', "Lip Sync Only", "Import only mouth-related shapekey animation")
        ],
        default='FULL'
    )

    # ImportHelper adds a "filepath" property.
    update_scene_fps: BoolProperty(
        name="Match Scene FPS",
        description="Update the scene's FPS to match the file",
        default=False,
    )
    update_scene_frame_range: BoolProperty(
        name="Match Scene Frame Range",
        description="Update the scene's start/end frames to match the file",
        default=False,
    )
    apply_to_active_mesh: BoolProperty(
        name="Apply to Active Mesh",
        description="Automatically apply the imported action to the active mesh as a shapekey animation",
        default=True,
    )
    import_to_active_action: BoolProperty(
        name="Import to Active Action",
        description="Import keyframes directly into the active shapekey action on the current frame instead of creating a new action",
        default=False,
    )

    def execute(self, context):
        return {'FINISHED'}
    
    def process_json_file(self, context, filepath):
        return None

    def draw(self, context):
        pass


def register():
    bpy.utils.register_class(HHP_OT_Import_FACS_JSON)


def unregister():
    bpy.utils.unregister_class(HHP_OT_Import_FACS_JSON) 