import bpy
import json
import os
import numpy as np
from math import exp, ceil

from bpy_extras.io_utils import ImportHelper
from bpy.props import BoolProperty, StringProperty, CollectionProperty, EnumProperty, FloatProperty
from bpy.types import Operator
from .action_fcurve_compat import ensure_fcurve_for_datablock
from .action_fcurve_compat import set_fcurve_handles_auto_clamped


def gaussian_filter_weights(x: np.ndarray, sigma_frames: float = 1.97):
    """
    Apply a one-dimensional Gaussian blur to each blend-shape track.
    
    x : 2-D array of shape (frames, channels)
    returns filtered array of the same shape
    """
    R = int(ceil(4.0 * sigma_frames))       # kernel radius
    offs = np.arange(-R, R+1, dtype=np.float32)
    kernel = np.exp(-(offs**2) / (2 * sigma_frames**2))
    kernel /= kernel.sum()                  # normalise

    # pad by repeating edge values (SciPy mode='nearest')
    pad_left  = np.repeat(x[0:1], R, axis=0)
    pad_right = np.repeat(x[-1:], R, axis=0)
    x_padded  = np.vstack([pad_left, x, pad_right])

    # 1-D convolution along time for every channel
    y = np.array([np.sum(kernel[:,None] * 
                         x_padded[i : i+2*R+1], axis=0)
                  for i in range(x.shape[0])], dtype=x.dtype)
    return y

def resample_animation(action, facs_names, weight_mat, import_fps, scene_fps):
    """Resamples the animation data from import_fps to scene_fps."""
    if not weight_mat or import_fps == scene_fps:
        return weight_mat

    import_duration = len(weight_mat) / import_fps
    num_scene_frames = int(import_duration * scene_fps)
    resampled_weights = []

    for i in range(num_scene_frames):
        time_in_scene = i / scene_fps
        import_frame_float = time_in_scene * import_fps
        import_frame_index = int(import_frame_float)

        if import_frame_index >= len(weight_mat) - 1:
            resampled_weights.append(weight_mat[-1])
            continue
        
        # Linear interpolation between two frames
        t = import_frame_float - import_frame_index
        frame1_weights = weight_mat[import_frame_index]
        frame2_weights = weight_mat[import_frame_index + 1]
        
        interpolated_frame = [
            (1 - t) * w1 + t * w2 for w1, w2 in zip(frame1_weights, frame2_weights)
        ]
        resampled_weights.append(interpolated_frame)
        
    return resampled_weights


class HHP_OT_Import_FACS_JSON(bpy.types.Operator, ImportHelper):
    bl_idname = "hhp.import_facs_json"
    bl_label = "Import FACS Json"
    bl_description = "Import JSON files as shapekey animations for use with HHP characters. Compatible with Nvidia Omniverse Audio2Face"
    bl_options = {'REGISTER', 'UNDO'}

    # File selection properties
    files: CollectionProperty(
        type=bpy.types.OperatorFileListElement,
        options={'HIDDEN', 'SKIP_SAVE'}
    )
    directory: StringProperty(
        subtype='DIR_PATH',
        options={'HIDDEN'}
    )
    filename_ext = ".json"
    filter_glob: StringProperty(
        default="*.json",
        options={'HIDDEN'},
    )

    # Mouth-only shapekeys list
    MOUTH_SHAPEKEYS = [
        "jawForward",
        "jawLeft",
        "jawRight",
        "jawOpen",
        "mouthClose",
        "mouthFunnel",
        "mouthPucker",
        "mouthLeft",
        "mouthRight",
        "mouthSmileLeft",
        "mouthSmileRight",
        "mouthFrownLeft",
        "mouthFrownRight",
        "mouthDimpleLeft",
        "mouthDimpleRight",
        "mouthStretchLeft",
        "mouthStretchRight",
        "mouthRollLower",
        "mouthRollUpper",
        "mouthShrugLower",
        "mouthShrugUpper",
        "mouthPressLeft",
        "mouthPressRight",
        "mouthLowerDownLeft",
        "mouthLowerDownRight",
        "mouthUpperUpLeft",
        "mouthUpperUpRight",
        "cheekPuff",
        "tongueOut"
    ]
    
    # Import mode
    import_mode: EnumProperty(
        name="Import Mode",
        description="Select which shapekeys to import",
        items=[
            ('FULL', "Full Face", "Import full shapekey animation from the JSON file", 'SHAPEKEY_DATA', 0),
            ('MOUTH_ONLY', "Lip Sync Only", "Import only mouth-related shapekey animation", 'OUTLINER_OB_FONT', 1)
        ],
        default='FULL'
    )
    
    fps_handling: EnumProperty(
        name="Framerate Handling",
        description="How to handle the framerate of the imported file",
        items=[
            ('SCENE', "Match to Scene", "Resample animation to match the scene's framerate"),
            ('IMPORTED', "Match to Imported", "Change the scene's framerate to match the imported file")
        ],
        default='SCENE'
    )

    update_scene_frame_range: BoolProperty(
        name="Match Frame Range to Imported",
        description="Update the scene's start/end frames to match the imported file",
        default=False,
    )
    import_on_current_frame: BoolProperty(
        name="Import on Current Frame",
        description="Use the current scene frame as the first frame of the imported animation",
        default=True,
    )
    apply_to_active_mesh: BoolProperty(
        name="Apply to Active Mesh",
        description="Automatically apply the imported action to the active mesh as a shapekey animation",
        default=True,
    )
    import_to_active_action: BoolProperty(
        name="Import to Active Action",
        description="Import keyframes directly into the active shapekey action on the current frame instead of creating a new action",
        default=False,
    )
    
    # Filtering properties
    use_filtering: BoolProperty(
        name="Filter (Smooth)",
        description="Apply Gaussian filtering to smooth the imported animation data",
        default=True,
    )
    
    filtering_factor: FloatProperty(
        name="Filtering Factor",
        description="Smoothing intensity (0% = no filtering, 100% = full filtering, >100% = extra smoothing)",
        default=100.0,
        min=0.0,
        soft_max=100.0,
        subtype='PERCENTAGE',
    )

    def execute(self, context):
        # Check if any files are selected
        if not self.files:
            self.report({'ERROR'}, "No files selected")
            return {'CANCELLED'}
            
        # Process all selected files
        actions_created = []
        
        for file in self.files:
            filepath = os.path.join(self.directory, file.name)
            
            # Process this file
            action_name = self.process_json_file(context, filepath)
            if action_name:
                actions_created.append(action_name)
        
        # Report success
        if actions_created:
            self.report({'INFO'}, f"Successfully imported {len(actions_created)} FACS action(s)")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, "No actions were imported")
            return {'CANCELLED'}
    
    def process_json_file(self, context, filepath):
        """Process a single JSON file and return the action name if successful"""
        if not os.path.exists(filepath):
            self.report({'ERROR'}, f"File not found: {filepath}")
            return None
            
        try:
            with open(filepath, "r") as f:
                data = json.load(f)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load JSON from {os.path.basename(filepath)}: {e}")
            return None

        export_fps = data.get("exportFps", 60)
        num_frames = data.get("numFrames")
        facs_names = data.get("facsNames", [])
        weight_mat = data.get("weightMat", [])

        if not (num_frames and facs_names and weight_mat):
            self.report({'ERROR'}, f"Missing required data in {os.path.basename(filepath)}")
            return None

        # Apply filtering if enabled
        if self.use_filtering and self.filtering_factor > 0.0 and len(weight_mat) > 1:
            weight_array = np.array(weight_mat, dtype=np.float32)
            # Apply filtering based on the factor (0-100%)
            sigma_frames = 1.97 * (self.filtering_factor / 100.0)
            if sigma_frames > 0.01:  # Only filter if sigma is meaningful
                filtered_array = gaussian_filter_weights(weight_array, sigma_frames)
                weight_mat = filtered_array.tolist()

        # Check if we should import to active action
        using_active_action = False
        active_action = None
        
        if (self.apply_to_active_mesh and self.import_to_active_action and 
            context.active_object and context.active_object.type == 'MESH'):
            obj = context.active_object
            if (obj.data.shape_keys and 
                obj.data.shape_keys.animation_data and 
                obj.data.shape_keys.animation_data.action):
                active_action = obj.data.shape_keys.animation_data.action
                using_active_action = True
                action_name = active_action.name
                action = active_action
                # No need to set fake user here since we're using an existing action

        # If not using active action, create a new one
        if not using_active_action:
            # Derive the action name from the filename
            base_name = os.path.basename(filepath)
            name_no_ext = os.path.splitext(base_name)[0]
            if "_export_bsweight" in name_no_ext:
                name_no_ext = name_no_ext.replace("_export_bsweight", "")
            
            # Add mode indicator to the action name if Mouth Only mode
            if self.import_mode == 'MOUTH_ONLY':
                action_name = f"(FACS-LipSync) HHP_{name_no_ext}"
            else:
                action_name = f"(FACS) HHP_{name_no_ext}"
            
            # Check if the action already exists and create a unique name if needed
            original_name = action_name
            counter = 1
            while action_name in bpy.data.actions:
                action_name = f"{original_name}.{counter:03d}"
                counter += 1

            # Create a new Action with fake user enabled
            action = bpy.data.actions.new(name=action_name)
            action.use_fake_user = True
        
        # Framerate handling
        scene_fps = context.scene.render.fps
        if self.fps_handling == 'SCENE':
            weight_mat = resample_animation(action, facs_names, weight_mat, export_fps, scene_fps)

        # Place the imported animation at the requested timeline position.
        start_frame = context.scene.frame_current if self.import_on_current_frame else 1

        # Filter shapekeys based on import mode
        filtered_indices = []
        if self.import_mode == 'MOUTH_ONLY':
            # Only include indices of mouth-related shapekeys
            for idx, sk_name in enumerate(facs_names):
                if sk_name in self.MOUTH_SHAPEKEYS:
                    filtered_indices.append((idx, sk_name))
        else:
            # Include all shapekeys
            filtered_indices = [(idx, sk_name) for idx, sk_name in enumerate(facs_names)]

        # Blender 5 requires datablock-aware curve creation, and the action must be assigned
        # to the datablock before ensuring curves. We use the active mesh's Shape Keys datablock.
        needs_datablock_curves = hasattr(action, "fcurve_ensure_for_datablock")
        shape_keys = None
        prev_action = None
        active_mesh = context.active_object if (context.active_object and context.active_object.type == 'MESH') else None

        if needs_datablock_curves:
            if not active_mesh:
                self.report({'ERROR'}, "Blender 5 requires an active mesh to import FACS shapekey actions.")
                return None
            if not active_mesh.data.shape_keys:
                active_mesh.shape_key_add(name="Basis")
            shape_keys = active_mesh.data.shape_keys
            if not shape_keys.animation_data:
                shape_keys.animation_data_create()
            prev_action = shape_keys.animation_data.action
            shape_keys.animation_data.action = action

        try:
            # For each filtered shapekey, ensure an F-Curve and insert keyframes
            skipped = []
            touched_fcurves = []
            for idx, sk_name in filtered_indices:
                data_path = f'key_blocks["{sk_name}"].value'
                try:
                    if needs_datablock_curves:
                        fcurve = ensure_fcurve_for_datablock(action, shape_keys, data_path, index=0)
                    else:
                        fcurve = ensure_fcurve_for_datablock(action, None, data_path, index=0)
                except Exception:
                    skipped.append(sk_name)
                    continue

                touched_fcurves.append(fcurve)
                for frame_idx, frame_weights in enumerate(weight_mat):
                    frame_num = start_frame + frame_idx
                    weight = frame_weights[idx] if idx < len(frame_weights) else 0.0
                    fcurve.keyframe_points.insert(frame=frame_num, value=weight, options={'FAST'})

            # Make imported curves smooth like Blender 4.x used to do automatically.
            for fc in touched_fcurves:
                set_fcurve_handles_auto_clamped(fc)

            # Best-effort: also try the operator (may fail without a Graph Editor context).
            try:
                bpy.ops.action.handle_type(type='AUTO_CLAMPED')
            except Exception:
                pass

            if skipped:
                self.report({'WARNING'}, f"Skipped {len(skipped)} shapekey tracks that don't exist on the active mesh.")
        finally:
            # Restore previous action if we only assigned temporarily (i.e., we're not applying it).
            if needs_datablock_curves and shape_keys and shape_keys.animation_data and not using_active_action and not self.apply_to_active_mesh:
                shape_keys.animation_data.action = prev_action

        # Apply the action to the active mesh if requested and not already using active action
        # Only apply the last imported action if multiple files are selected
        if self.apply_to_active_mesh and context.active_object and context.active_object.type == 'MESH' and not using_active_action:
            obj = context.active_object
            
            # Check if the object has shape keys
            if not obj.data.shape_keys:
                # Create a basis shape key if needed
                obj.shape_key_add(name="Basis")
            
            # Set animation data
            if not obj.data.shape_keys.animation_data:
                obj.data.shape_keys.animation_data_create()
            
            # Store the current action if it exists
            current_action = None
            if obj.data.shape_keys.animation_data.action:
                current_action = obj.data.shape_keys.animation_data.action
                
            # Apply the new action
            obj.data.shape_keys.animation_data.action = action
            self.report({'INFO'}, f"Applied action '{action_name}' to {obj.name}")

        # Optionally update scene settings (only from the last file if multiple)
        if filepath == os.path.join(self.directory, self.files[-1].name):
            scene = context.scene
            if not using_active_action and self.fps_handling == 'IMPORTED':
                scene.render.fps = round(export_fps)
            if self.update_scene_frame_range:
                scene.frame_start = start_frame
                scene.frame_end = start_frame + len(weight_mat) - 1

        if using_active_action:
            self.report({'INFO'}, f"Imported into existing action '{action_name}' starting at frame {start_frame}")
        
        return action_name

    def draw(self, context):
        layout = self.layout
        
        # Mode selector (Full Face/Lip Sync Only) - vertical arrangement
        col = layout.column()
        col.prop(self, "import_mode", expand=True)
        
        layout.separator()

        
        
        # Check if active object is a mesh
        has_active_mesh = (context.active_object and context.active_object.type == 'MESH')
        
        col = layout.column()
        col.prop(self, "fps_handling", expand=True)
        
        layout.prop(self, "update_scene_frame_range")

        layout.prop(self, "import_on_current_frame")
        
        # Apply to active mesh option
        row = layout.row()
        row.enabled = has_active_mesh
        row.prop(self, "apply_to_active_mesh")
        
        # Show warning if no mesh is selected
        if not has_active_mesh:
            layout.label(text="A mesh must be active for this option", icon='INFO')
            
        # Check if active mesh has an active action
        has_active_action = False
        if has_active_mesh and self.apply_to_active_mesh:
            obj = context.active_object
            if (obj.data.shape_keys and 
                obj.data.shape_keys.animation_data and 
                obj.data.shape_keys.animation_data.action):
                has_active_action = True
        
        # Reset import_to_active_action to False if conditions aren't met
        if not has_active_action and self.import_to_active_action:
            self.import_to_active_action = False
        
        # Import to active action option (at the bottom)
        row = layout.row()
        row.enabled = has_active_action
        row.prop(self, "import_to_active_action")
        
        # Filtering section
        layout.separator()
        filter_box = layout.box()
        filter_box.prop(self, "use_filtering")
        
        if self.use_filtering:
            slider_row = filter_box.row()
            slider_row.prop(self, "filtering_factor", slider=True)


def register():
    bpy.utils.register_class(HHP_OT_Import_FACS_JSON)


def unregister():
    bpy.utils.unregister_class(HHP_OT_Import_FACS_JSON)
