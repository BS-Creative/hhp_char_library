"""Native finger and tongue control refinements for the generated HHP rig."""
import bpy
import json
import math
from mathutils import Matrix, Vector


def _drive(owner, path, arm, expression, variables, index=None):
    curve = owner.driver_add(path) if index is None else owner.driver_add(path,index)
    driver=curve.driver;driver.type='SCRIPTED'
    while driver.variables:driver.variables.remove(driver.variables[0])
    for name,data_path in variables.items():
        variable=driver.variables.new();variable.name=name;variable.type='SINGLE_PROP'
        variable.targets[0].id=arm;variable.targets[0].data_path=data_path
    driver.expression=expression
    return curve


def _update(arm):
    arm.update_tag(refresh={'OBJECT'});bpy.context.view_layer.update()


def upgrade(arm):
    data=json.loads(arm['hhp_rigify_manifest'])
    if data.get('finger_orientation_version'):return {}
    specs=[]
    initial_first={}
    tongue=next(item for item in data['fingers'] if 'tongue' in item['base'])
    tongue_chain=json.loads(tongue['to_fk']['ik_chain'])
    tongue_snap='MCH-HHP-tongue-FK-snap'
    for item in data['fingers']:
        if 'tongue' in item['base']:continue
        chain=json.loads(item['to_fk']['ik_chain'])
        initial_first[chain[0]]=arm.pose.bones[chain[0]].matrix.copy()
        tag=item['ik_control']
        specs.append(dict(control=tag,chain=chain,master=item['master'],
            first_fk=json.loads(item['to_fk']['fk_chain'])[0],
            pivot='MCH-HHP-finger-plane-'+tag,pole='MCH-HHP-finger-pole-'+tag,
            tip='MCH-HHP-finger-tip-'+tag))
    bpy.context.view_layer.objects.active=arm
    if arm.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.mode_set(mode='EDIT')
    bones=arm.data.edit_bones
    collection=arm.data.collections['HHP Rigify Bindings']
    source=bones[tongue_chain[-1]]
    snap=bones.new(tongue_snap);snap.head=source.tail;snap.tail=source.tail+source.vector*.3;snap.roll=source.roll
    snap.parent=bones['MCH-tongue.04'];snap.use_deform=False;collection.assign(snap)
    for spec in specs:
        chain=[bones[name] for name in spec['chain']]
        control=bones[spec['control']]
        control.head=chain[-1].head;control.tail=control.head+chain[-1].vector*.7
        control.roll=chain[-1].roll
        total=chain[1].tail-chain[0].head
        lower=chain[1].vector
        offset=lower.project(total)-lower
        if offset.length<1e-7:offset=-chain[0].z_axis
        offset.normalize();offset*=total.length
        normal=total.cross(offset)
        projected=normal.cross(chain[0].vector).normalized()
        axis=chain[0].y_axis.normalized();xaxis=chain[0].x_axis.normalized()
        angle=-math.atan2(axis.dot(xaxis.cross(projected)),xaxis.dot(projected))
        pivot=bones.new(spec['pivot']);pivot.head=chain[0].head;pivot.tail=pivot.head+total
        pivot.align_roll(chain[0].z_axis);pivot.parent=chain[0].parent
        pole=bones.new(spec['pole']);pole.head=chain[0].head+total*.5+offset
        pole.tail=pole.head+Vector((0,0,total.length*.1));pole.parent=pivot
        tip=bones.new(spec['tip']);tip.head,tip.tail,tip.roll=chain[-1].head,chain[-1].tail,chain[-1].roll
        tip.parent=chain[-1].parent;tip.inherit_scale=chain[-1].inherit_scale
        spec['pole_angle']=angle
        spec['pole_local']=list(pivot.matrix.inverted()@pole.head)
        for bone in (pivot,pole,tip):bone.use_deform=False;collection.assign(bone)
    bpy.ops.object.mode_set(mode='OBJECT')
    # Tip rotation combines non-uniform scale with rest-axis offsets.
    # Align scale on generated digit adapters to avoid shear amplification
    # during an explicit FK/IK match. Native Daz inheritance is untouched.
    digit_chain={name for item in data['fingers'] for name in json.loads(item['to_fk']['ik_chain'])}
    for native,scaffold in data['input_map'].items():
        if 'ORG-'+scaffold in digit_chain:
            arm.data.bones[data['bindings'][native]].inherit_scale='ALIGNED'
    tongue_control=arm.pose.bones[tongue['ik_control']]
    tongue_control.lock_location=(False,False,False)
    tongue_control.lock_rotation=(False,False,False);tongue_control.lock_rotation_w=False
    tongue_control.lock_scale=(False,True,True)
    tongue_control['IK_parent']=5
    tongue_control.id_properties_ui('IK_parent').update(default=5)
    tongue_ik=arm.pose.bones[tongue_chain[-1]].constraints['FingerIK']
    tongue_ik.use_rotation=True;tongue_ik.use_location=True;tongue_ik.use_stretch=True;tongue_ik.iterations=500
    for index,name in enumerate(tongue_chain):
        bone=arm.pose.bones[name]
        bone.ik_stretch=0.0
        bone.ik_stiffness_x=bone.ik_stiffness_y=bone.ik_stiffness_z=0.0
        bone.lock_ik_x=bone.lock_ik_y=bone.lock_ik_z=False
        bone.use_ik_limit_x=bone.use_ik_limit_y=bone.use_ik_limit_z=False
        if index:
            con=bone.constraints.new('COPY_SCALE');con.name='(HHP) Tongue Width'
            con.target=arm;con.subtarget=tongue_control.name
            con.owner_space=con.target_space='WORLD'
            con.use_x=True;con.use_y=con.use_z=False
            _drive(con,'influence',arm,str((.33,.66,1.)[index-1])+'*ik',{'ik':tongue_control.path_from_id()+'["FK_IK"]'})
    reference=bpy.data.objects.get('Genesis8Female')
    reference=reference.pose.bones.get('Tongue Controller') if reference else None
    if reference and reference.custom_shape:
        widget=reference.custom_shape.copy()
        if reference.custom_shape.data:widget.data=reference.custom_shape.data.copy()
        widget.name='HHP Tongue IK Widget';widget.hide_render=True
        bpy.data.collections['HHP Bone Widgets'].objects.link(widget)
        tongue_control.custom_shape=widget
        for prop in ('custom_shape_translation','custom_shape_rotation_euler','custom_shape_scale_xyz','use_custom_shape_bone_size'):
            setattr(tongue_control,prop,getattr(reference,prop))
    arm.pose.bones[tongue_snap].hide=True
    tongue['to_ik']['input_bones']=json.dumps([tongue_snap])
    tongue['to_ik']['locks']=(False,False,False)
    for spec in specs:
        ctrl=arm.pose.bones[spec['control']];ctrl.rotation_mode='XYZ'
        ctrl.lock_rotation=(False,False,True);ctrl.lock_rotation_w=True
        ctrl.lock_scale=(True,True,True)
        ctrl.rotation_euler=(0,0,0)
        pivot=arm.pose.bones[spec['pivot']];pivot.rotation_mode='XYZ'
        con=pivot.constraints.new('COPY_LOCATION');con.target=arm;con.subtarget=spec['first_fk']
        con=pivot.constraints.new('DAMPED_TRACK');con.target=arm;con.subtarget=spec['control'];con.track_axis='TRACK_Y'
        _drive(pivot,'rotation_euler',arm,'plane',{'plane':ctrl.path_from_id('rotation_euler')+'[1]'},index=1)
        tip=arm.pose.bones[spec['tip']];tip.rotation_mode='XYZ'
        _drive(tip,'rotation_euler',arm,'curl',{'curl':ctrl.path_from_id('rotation_euler')+'[0]'},index=0)
        last=arm.pose.bones[spec['chain'][-1]]
        old=last.constraints['FingerIK'];old.driver_remove('influence');last.constraints.remove(old)
        middle=arm.pose.bones[spec['chain'][1]]
        con=middle.constraints.new('IK');con.name='FingerIK';con.target=arm;con.subtarget=spec['control']
        con.chain_count=2;con.use_stretch=False;con.iterations=500
        con.pole_target=arm;con.pole_subtarget=spec['pole'];con.pole_angle=spec['pole_angle']
        _drive(con,'influence',arm,'ik',{'ik':ctrl.path_from_id()+'["FK_IK"]'})
        con=last.constraints.new('COPY_TRANSFORMS');con.name='(HHP) Finger Tip Orientation'
        con.target=arm;con.subtarget=spec['tip'];con.owner_space=con.target_space='LOCAL'
        _drive(con,'influence',arm,'ik',{'ik':ctrl.path_from_id()+'["FK_IK"]'})
        for name in (spec['pivot'],spec['pole'],spec['tip']):arm.pose.bones[name].hide=True
        item=next(item for item in data['fingers'] if item['ik_control']==spec['control'])
        item['to_fk']['constraint_bone']=spec['chain'][1]
        item['to_ik']['input_bones']=json.dumps([json.loads(item['to_fk']['fk_chain'])[-2]])
        item['orientation_spec']=spec
        data['neutral_basis'][spec['control']]=[list(row) for row in ctrl.matrix_basis]
    _update(arm)
    for spec in specs:
        pose=arm.pose.bones[spec['chain'][0]].matrix.to_3x3()
        desired=initial_first[spec['chain'][0]].to_3x3()
        axis=pose.col[1].normalized();current=pose.col[0].normalized()
        wanted=desired.col[0]-desired.col[0].project(axis);wanted.normalize()
        delta=math.atan2(axis.dot(current.cross(wanted)),current.dot(wanted))
        con=arm.pose.bones[spec['chain'][1]].constraints['FingerIK']
        con.pole_angle-=delta
        spec['pole_angle']=con.pole_angle
    _update(arm)
    data['finger_orientation_version']=1
    data['finger_orientation_specs']=specs
    data['extension_helpers']=list(dict.fromkeys(data.get('extension_helpers',[])+[tongue_snap]
        +[spec[key] for spec in specs for key in ('pivot','pole','tip')]))
    data['neutral_basis'][tongue_control.name]=[list(row) for row in tongue_control.matrix_basis]
    arm['hhp_rigify_manifest']=json.dumps(data,separators=(',',':'))
    _update(arm)
    return {'finger_orientation_version':1,'finger_orientation_specs':specs,'fingers':data['fingers'],
            'extension_helpers':data['extension_helpers'],
            'neutral_basis':data['neutral_basis']}


def snap_ik_from_fk(arm,item):
    """Explicit orientation/plane snap; never called by a dependency handler."""
    spec=item['orientation_spec'];chain=[arm.pose.bones[n] for n in spec['chain']]
    matrices=[bone.matrix.copy() for bone in chain]
    ctrl=arm.pose.bones[spec['control']]
    desired=ctrl.matrix.copy();desired.translation=matrices[-1].translation
    ctrl.matrix=desired
    basis=chain[-1].bone.convert_local_to_pose(matrices[-1],chain[-1].bone.matrix_local,
        parent_matrix=matrices[-2],parent_matrix_local=chain[-2].bone.matrix_local,invert=True)
    ctrl.rotation_euler.x=basis.to_euler('XYZ').x
    ctrl.rotation_euler.y=0.
    _update(arm)
    start,joint,end=[matrix.translation for matrix in matrices]
    line=end-start
    radial=joint-start-(joint-start).project(line)
    if radial.length>1e-7:
        local=arm.pose.bones[spec['pivot']].matrix.to_3x3().inverted_safe()@radial
        ref=Vector(spec['pole_local'])
        ctrl.rotation_euler.y=math.atan2(local.x,local.z)-math.atan2(ref.x,ref.z)
    _update(arm)


def digit_native_bones(arm,item):
    from . import hhp_rigify as core
    data=core.manifest(arm)
    chain=set(json.loads(item['to_fk']['ik_chain']))
    names=[native for native,scaffold in data['input_map'].items()
           if 'ORG-'+scaffold in chain and native in data['bindings']]
    if len(names)!=len(chain):
        raise RuntimeError('The finger or tongue native mapping is incomplete')
    return names


def digit_key_bones(arm,item,ik):
    """Channels changed by a deliberate digit snap or explicit animation bake."""
    from . import hhp_rigify as core
    controls=[item['ik_control']]
    if ik and item.get('base_control'):controls.append(item['base_control'])
    if not ik:controls += [item['master']] + json.loads(item['to_fk']['fk_chain'])
    bindings=core.manifest(arm)['bindings']
    return list(dict.fromkeys(controls+[bindings[n] for n in digit_native_bones(arm,item)]))


def save_digit_state(arm,item,ik):
    """Capture before a bake deletes receiving curves; no changes or keyframes."""
    from . import hhp_rigify as core
    desired=core.matrices(arm,digit_native_bones(arm,item)) if core.control_rig_active(arm) else None
    return dict(pose=core._state(arm),desired=desired)


def apply_digit_state(arm,item,ik,state):
    """Apply one cached bake frame using the same explicit snap as the UI."""
    from . import hhp_rigify as core
    core._restore(arm,state['pose'])
    snap_digit(arm,item,ik,desired=state['desired'])


def snap_digit(arm,item,ik,desired=None):
    """Match one chain without inserting keys or evaluating continuously."""
    from . import hhp_rigify as core
    if desired is None and core.control_rig_active(arm):
        desired=core.matrices(arm,digit_native_bones(arm,item))
    with core._pose_context(arm):
        if ik and item.get('orientation_spec'):
            snap_ik_from_fk(arm,item)
        else:
            if ik and item.get('base_control'):
                from .hhp_rigify_tongue_base import prepare_ik_snap
                prepare_ik_snap(arm,item)
            core._generated_snap(arm,item['to_ik' if ik else 'to_fk'])
        arm.pose.bones[item['ik_control']]['FK_IK']=float(bool(ik))
        core.update(arm)
    if desired is not None:core._fit_bindings(arm,desired)
    core.refresh_visibility(arm)


class HHP_OT_rigify_digit_snap(bpy.types.Operator):
    bl_idname='pose.hhp_rigify_digit_snap'
    bl_label='Match Finger or Tongue Controls'
    bl_description='Match this finger or tongue chain and switch its IK/FK mode, preserving the current pose'
    bl_options={'REGISTER','UNDO'}

    control:bpy.props.StringProperty(name='IK Control',options={'HIDDEN'})
    ik:bpy.props.BoolProperty(name='Use IK',default=True)

    @classmethod
    def poll(cls,context):
        from . import hhp_rigify as core, rigify_compat_loader
        return core.control_rig_active(core.get_armature(context)) and rigify_compat_loader.is_available()

    def execute(self,context):
        from . import hhp_rigify as core
        arm=core.get_armature(context)
        item=next((item for item in core.manifest(arm)['fingers'] if item['ik_control']==self.control),None)
        if item is None:
            self.report({'ERROR'},'This rig has no matching finger or tongue control')
            return {'CANCELLED'}
        state=core._state(arm)
        native=core.native_action_owns_pose(arm)
        paused=core._pause_preview_action(arm)
        try:
            snap_digit(arm,item,self.ik)
            props=getattr(arm,'hhp_anim_preview_props',None)
            if bool(getattr(props,'keyframe_ik_fk_switch',False)) and not native:
                core._key_controls(arm,digit_key_bones(arm,item,self.ik))
                core._resume_preview_action(arm)
        except Exception as exc:
            core._restore(arm,state)
            if paused:core._resume_preview_action(arm)
            core.refresh_visibility(arm)
            self.report({'ERROR'},str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


def register():
    if not HHP_OT_rigify_digit_snap.is_registered:
        bpy.utils.register_class(HHP_OT_rigify_digit_snap)


def unregister():
    if HHP_OT_rigify_digit_snap.is_registered:
        bpy.utils.unregister_class(HHP_OT_rigify_digit_snap)
