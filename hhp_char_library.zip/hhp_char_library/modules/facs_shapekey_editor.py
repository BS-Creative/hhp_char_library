import bpy
from bpy.types import UIList, Operator

# List of relevant FACS shapekeys
FACS_SHAPEKEYS = []

class HHP_UL_FACSShapekeysList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        pass
    
    def filter_items(self, context, data, propname):
        shape_keys = getattr(data, propname)
        flags = [0] * len(shape_keys)
        return flags, []


def draw_facs_editor(layout, context):
    pass


class HHP_OT_SetFACSValues(Operator):
    bl_idname = "hhp.set_facs_values"
    bl_label = "Set FACS Values"
    bl_description = "Set all FACS shapekeys to the specified value"
    bl_options = {'REGISTER', 'UNDO'}
    
    # Move properties to the operator for the popup
    value: bpy.props.FloatProperty(
        name="Value",
        description="Value to set for all FACS shapekeys",
        default=0.0,
        min=0.0,
        soft_max=1.0,
        max=10.0,
        precision=3
    )
    keyframe: bpy.props.BoolProperty(
        name="Keyframe Values",
        description="If enabled, keyframe the FACS shapekeys when setting values",
        default=False
    )
    lipsync_only: bpy.props.BoolProperty(
        description="Limit to Lipsync Shapekeys Only",
        default=False
    )
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        pass
    
    def execute(self, context):
        return {'FINISHED'}


class HHP_OT_ToggleAllFACSMute(Operator):
    bl_idname = "hhp.toggle_all_facs_mute"
    bl_label = "Toggle All FACS Mute"
    bl_description = "Toggle mute state for all FACS shapekeys"
    bl_options = {'REGISTER', 'UNDO'}
    
    # Track the current state to know whether to mute or unmute
    mute_state: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.data.shape_keys
    
    def execute(self, context):
        return {'FINISHED'}


class HHP_OT_MuteSectionFACS(Operator):
    bl_idname = "hhp.mute_section_facs"
    bl_label = "Mute Section of FACS"
    bl_description = "Mute specific categories of FACS shapekeys"
    bl_options = {'REGISTER', 'UNDO'}
    
    # Category booleans
    blink_and_eyes: bpy.props.BoolProperty(
        name="Blink and Eyes",
        description="Mute eye-related FACS shapekeys",
        default=True
    )
    
    tongue: bpy.props.BoolProperty(
        name="Tongue",
        description="Mute tongue-related FACS shapekeys",
        default=True
    )
    
    non_lipsync_facs: bpy.props.BoolProperty(
        name="Non-Lipsync FACS",
        description="Mute FACS shapekeys not related to lipsync",
        default=False
    )
    
    lipsync_facs: bpy.props.BoolProperty(
        name="Lipsync FACS",
        description="Mute FACS shapekeys related to lipsync",
        default=False
    )
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.data.shape_keys
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        pass
    
    def execute(self, context):
        return {'FINISHED'}


def register():
    bpy.utils.register_class(HHP_UL_FACSShapekeysList)
    bpy.utils.register_class(HHP_OT_SetFACSValues)
    bpy.utils.register_class(HHP_OT_ToggleAllFACSMute)
    bpy.utils.register_class(HHP_OT_MuteSectionFACS)


def unregister():
    bpy.utils.unregister_class(HHP_UL_FACSShapekeysList)
    bpy.utils.unregister_class(HHP_OT_SetFACSValues)
    bpy.utils.unregister_class(HHP_OT_ToggleAllFACSMute)
    bpy.utils.unregister_class(HHP_OT_MuteSectionFACS) 