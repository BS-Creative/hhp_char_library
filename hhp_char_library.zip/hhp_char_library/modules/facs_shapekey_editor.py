import bpy
from bpy.types import UIList, Operator

# List of relevant FACS shapekeys
FACS_SHAPEKEYS = [
    "eyeBlinkLeft",
    "eyeLookDownLeft",
    "eyeLookInLeft",
    "eyeLookOutLeft",
    "eyeLookUpLeft",
    "eyeSquintLeft",
    "eyeWideLeft",
    "eyeBlinkRight",
    "eyeLookDownRight",
    "eyeLookInRight",
    "eyeLookOutRight",
    "eyeLookUpRight",
    "eyeSquintRight",
    "eyeWideRight",
    "jawForward",
    "jawLeft",
    "jawRight",
    "jawOpen",
    "mouthClose",
    "mouthFunnel",
    "mouthPucker",
    "mouthLeft",
    "mouthRight",
    "mouthSmileLeft",
    "mouthSmileRight",
    "mouthFrownLeft",
    "mouthFrownRight",
    "mouthDimpleLeft",
    "mouthDimpleRight",
    "mouthStretchLeft",
    "mouthStretchRight",
    "mouthRollLower",
    "mouthRollUpper",
    "mouthShrugLower",
    "mouthShrugUpper",
    "mouthPressLeft",
    "mouthPressRight",
    "mouthLowerDownLeft",
    "mouthLowerDownRight",
    "mouthUpperUpLeft",
    "mouthUpperUpRight",
    "browDownLeft",
    "browDownRight",
    "browInnerUp",
    "browOuterUpLeft",
    "browOuterUpRight",
    "cheekPuff",
    "cheekSquintLeft",
    "cheekSquintRight",
    "noseSneerLeft",
    "noseSneerRight",
    "tongueOut"
]

class HHP_UL_FACSShapekeysList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # Make the shape key list look like Blender's standard UI
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # Split layout to separate name from value and mute
            split = layout.split(factor=0.5)
            
            # Left side - shape key name
            row = split.row()
            # Force the shapekey icon to SHAPEKEY_DATA to avoid vertex color icon issues
            row.label(text=item.name, icon='SHAPEKEY_DATA')
            
            # Right side - value and mute
            row = split.row(align=True)
            row.alignment = 'RIGHT'
            
            # Value slider - always editable but with visual indication of mute state
            slider_row = row.row(align=True)
            
            # Make the slider always editable (no disabled states)
            slider_row.enabled = True
            
            # For muted state, we use active property which grays out visually but keeps interactivity
            if item.mute:
                slider_row.active = False  # This grays out visually but keeps functionality
            else:
                slider_row.active = True
            
            # Control the width of the slider
            slider_row.ui_units_x = 4  # Reduced width (default is around 8-10)
                
            # The slider itself - always functional
            slider_row.prop(item, "value", text="", emboss=False, slider=True)
                
            # Checkbox without text label and no emboss
            row.prop(item, "mute", text="", emboss=False, toggle=True)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='SHAPEKEY_DATA')
    
    def filter_items(self, context, data, propname):
        """ Filter and order items in the list """
        shape_keys = getattr(data, propname)
        
        # Default flags and order
        flags = [0] * len(shape_keys)
        
        # Filter by FACS shapekeys
        for i, key in enumerate(shape_keys):
            if key.name in FACS_SHAPEKEYS:
                flags[i] = self.bitflag_filter_item
        
        # Handle search - only search within already visible keys
        if self.filter_name:
            for i, key in enumerate(shape_keys):
                if flags[i]:
                    if self.filter_name.lower() not in key.name.lower():
                        flags[i] = 0
        
        return flags, []


def draw_facs_editor(layout, context):
    """Draw FACS shapekey list in Blender style"""
    obj = context.active_object
    if not obj or obj.type != 'MESH':
        layout.label(text="Select a mesh object")
        return
        
    if not obj.data.shape_keys:
        layout.label(text="Object has no shape keys")
        return
        
    shape_keys = obj.data.shape_keys
    
    # Create a single column for all elements - this ensures vertical alignment
    main_col = layout.column(align=True)
    
    # Draw the list in the main column
    rows = 5  # Increased from 4 to 5 to show more items
    main_col.template_list(
        "HHP_UL_FACSShapekeysList", "",
        shape_keys, "key_blocks",
        obj, "active_shape_key_index",
        rows=rows
    )
    
    # Create a 2-column layout for controls
    if obj.data.shape_keys:  # Only show if there are shape keys
        controls_row = main_col.row(align=True)
        
        # Column 1: Mute FACS and Set FACS (stacked vertically, with Mute above Set FACS)
        left_col = controls_row.column(align=True)
        
        # Add dynamic mute toggle button first (above Set FACS)
        # Check if any FACS shapekeys are muted to determine current state
        any_muted = False  # Assume none are muted by default
        if obj.data.shape_keys:
            for sk in obj.data.shape_keys.key_blocks:
                if sk.name in FACS_SHAPEKEYS:
                    if sk.mute:
                        any_muted = True
                        break
        
        # Create separate row for mute button to handle the alert state
        mute_row = left_col.row(align=True)
        if any_muted:
            mute_row.alert = True  # This makes the button blue
        
        # Create the mute toggle button with dynamic appearance
        mute_op = mute_row.operator("hhp.toggle_all_facs_mute", 
                                text="Unmute FACS" if any_muted else "Mute FACS",
                                icon='HIDE_ON' if any_muted else 'HIDE_OFF')
        mute_op.mute_state = not any_muted  # Set to the opposite state (what it will become)
        
        # Add Mute Section of FACS button
        mute_section_row = left_col.row(align=True)
        mute_section_row.operator("hhp.mute_section_facs", text="Mute Section of FACS", icon='HIDE_OFF')
        
        # Column 2: Shapekey Lock and Edit Mode (stacked vertically)
        right_col = controls_row.column(align=True)
        right_col.prop(obj, "show_only_shape_key", text="Shapekey Lock")
        right_col.prop(obj, "use_shape_key_edit_mode", text="Edit Mode")
        
        # Add Set FACS Value button as its own full-width row
        set_facs_row = main_col.row(align=True)
        set_facs_row.operator("hhp.set_facs_values", text="Set FACS Value", icon='RNA')
        
        # Only show Min/Max controls if we have a valid FACS shapekey to reference
        control_key = None
        if obj.active_shape_key and obj.active_shape_key.name in FACS_SHAPEKEYS:
            control_key = obj.active_shape_key
        else:
            # Find the first FACS shape key to use as a reference
            for sk in obj.data.shape_keys.key_blocks:
                if sk.name in FACS_SHAPEKEYS:
                    control_key = sk
                    break
        
        # Add Max and Min in a row side by side below the set FACS value button
        if control_key:
            min_max_row = main_col.row(align=True)
            min_max_row.prop(control_key, "slider_min", text="Range Min")
            min_max_row.prop(control_key, "slider_max", text="Max")
            
            # Vertex Group (full width row)
            main_col.prop_search(control_key, "vertex_group", obj, "vertex_groups", text="")


class HHP_OT_SetFACSValues(Operator):
    bl_idname = "hhp.set_facs_values"
    bl_label = "Set FACS Values"
    bl_description = "Set all FACS shapekeys to the specified value"
    bl_options = {'REGISTER', 'UNDO'}
    
    # Move properties to the operator for the popup
    value: bpy.props.FloatProperty(
        name="Value",
        description="Value to set for all FACS shapekeys",
        default=0.0,
        min=0.0,
        soft_max=1.0,
        max=10.0,
        precision=3
    )
    keyframe: bpy.props.BoolProperty(
        name="Keyframe Values",
        description="If enabled, keyframe the FACS shapekeys when setting values",
        default=False
    )
    lipsync_only: bpy.props.BoolProperty(
        description="Limit to Lipsync Shapekeys Only",
        default=False
    )
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        
        # Put value, keyframe, and lipsync controls on the same row with alignment
        row = layout.row(align=True)
        row.prop(self, "value", slider=True)
        row.prop(self, "keyframe", text="", icon='KEYINGSET')
        row.prop(self, "lipsync_only", text="", icon='OUTLINER_OB_SPEAKER')
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        value = self.value
        keyframe = self.keyframe
        lipsync_only = self.lipsync_only
        current_frame = context.scene.frame_current
        
        # Lipsync-related shapekeys
        lipsync_shapekeys = [
            "jawOpen", "jawForward", "jawLeft", "jawRight", 
            "mouthClose", "mouthFunnel", "mouthPucker",
            "mouthLeft", "mouthRight", "mouthSmileLeft", "mouthSmileRight",
            "mouthFrownLeft", "mouthFrownRight", "mouthDimpleLeft", "mouthDimpleRight",
            "mouthStretchLeft", "mouthStretchRight", "mouthRollLower", "mouthRollUpper",
            "mouthShrugLower", "mouthShrugUpper", "mouthPressLeft", "mouthPressRight",
            "mouthLowerDownLeft", "mouthLowerDownRight", "mouthUpperUpLeft", "mouthUpperUpRight",
            "tongueOut", "cheekPuff"
        ]
        
        # Set values for all FACS shapekeys (or just lipsync ones)
        for sk in obj.data.shape_keys.key_blocks:
            should_set = False
            
            if lipsync_only:
                # Only set if in lipsync shapekeys
                if sk.name in lipsync_shapekeys:
                    should_set = True
            else:
                # Set all FACS shapekeys
                if sk.name in FACS_SHAPEKEYS:
                    should_set = True
                    
            if should_set:
                sk.value = value
                # Keyframe if enabled
                if keyframe:
                    sk.keyframe_insert("value", frame=current_frame)
        
        return {'FINISHED'}


class HHP_OT_ToggleAllFACSMute(Operator):
    bl_idname = "hhp.toggle_all_facs_mute"
    bl_label = "Toggle All FACS Mute"
    bl_description = "Toggle mute state for all FACS shapekeys"
    bl_options = {'REGISTER', 'UNDO'}
    
    # Track the current state to know whether to mute or unmute
    mute_state: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.data.shape_keys
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
            
        # Use the mute_state passed from the UI
        new_mute_state = self.mute_state
        
        # Apply the mute state to all FACS shapekeys
        for sk in obj.data.shape_keys.key_blocks:
            if sk.name in FACS_SHAPEKEYS:
                sk.mute = new_mute_state
                
        return {'FINISHED'}


class HHP_OT_MuteSectionFACS(Operator):
    bl_idname = "hhp.mute_section_facs"
    bl_label = "Mute Section of FACS"
    bl_description = "Mute specific categories of FACS shapekeys"
    bl_options = {'REGISTER', 'UNDO'}
    
    # Category booleans
    blink_and_eyes: bpy.props.BoolProperty(
        name="Blink and Eyes",
        description="Mute eye-related FACS shapekeys",
        default=True
    )
    
    tongue: bpy.props.BoolProperty(
        name="Tongue",
        description="Mute tongue-related FACS shapekeys",
        default=True
    )
    
    non_lipsync_facs: bpy.props.BoolProperty(
        name="Non-Lipsync FACS",
        description="Mute FACS shapekeys not related to lipsync",
        default=False
    )
    
    lipsync_facs: bpy.props.BoolProperty(
        name="Lipsync FACS",
        description="Mute FACS shapekeys related to lipsync",
        default=False
    )
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.data.shape_keys
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        
        # Create a row for each category boolean option
        # Using clickable booleans rather than checkboxes
        row = layout.row()
        row.prop(self, "blink_and_eyes")
        
        row = layout.row()
        row.prop(self, "tongue")
        
        row = layout.row()
        row.prop(self, "non_lipsync_facs")
        
        row = layout.row()
        row.prop(self, "lipsync_facs")
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        # Eye-related shapekeys
        eye_shapekeys = [
            "eyeLookDownLeft", "eyeLookInLeft", "eyeLookOutLeft", 
            "eyeLookUpLeft", "eyeSquintLeft", "eyeWideLeft", "eyeBlinkLeft",
            "eyeBlinkRight", "eyeLookDownRight", "eyeLookInRight", 
            "eyeLookOutRight", "eyeLookUpRight", "eyeSquintRight", "eyeWideRight"
        ]
        
        # Tongue shapekey
        tongue_shapekey = ["tongueOut"]
        
        # Lipsync-related shapekeys (from existing definition)
        lipsync_shapekeys = [
            "jawOpen", "jawForward", "jawLeft", "jawRight", 
            "mouthClose", "mouthFunnel", "mouthPucker",
            "mouthLeft", "mouthRight", "mouthSmileLeft", "mouthSmileRight",
            "mouthFrownLeft", "mouthFrownRight", "mouthDimpleLeft", "mouthDimpleRight",
            "mouthStretchLeft", "mouthStretchRight", "mouthRollLower", "mouthRollUpper",
            "mouthShrugLower", "mouthShrugUpper", "mouthPressLeft", "mouthPressRight",
            "mouthLowerDownLeft", "mouthLowerDownRight", "mouthUpperUpLeft", "mouthUpperUpRight",
            "tongueOut", "cheekPuff"
        ]
        
        # Derive non-lipsync FACS by excluding lipsync shapekeys from all FACS
        non_lipsync = [key for key in FACS_SHAPEKEYS if key not in lipsync_shapekeys]
        
        # Process each shapekey based on the selected categories
        for sk in obj.data.shape_keys.key_blocks:
            # Skip non-FACS shapekeys
            if sk.name not in FACS_SHAPEKEYS:
                continue
                
            # Apply muting based on category selection
            if self.blink_and_eyes and sk.name in eye_shapekeys:
                sk.mute = True
            elif self.tongue and sk.name in tongue_shapekey:
                sk.mute = True
            elif self.lipsync_facs and sk.name in lipsync_shapekeys:
                sk.mute = True
            elif self.non_lipsync_facs and sk.name in non_lipsync:
                sk.mute = True
                
        return {'FINISHED'}


def register():
    bpy.utils.register_class(HHP_UL_FACSShapekeysList)
    bpy.utils.register_class(HHP_OT_SetFACSValues)
    bpy.utils.register_class(HHP_OT_ToggleAllFACSMute)
    bpy.utils.register_class(HHP_OT_MuteSectionFACS)


def unregister():
    bpy.utils.unregister_class(HHP_UL_FACSShapekeysList)
    bpy.utils.unregister_class(HHP_OT_SetFACSValues)
    bpy.utils.unregister_class(HHP_OT_ToggleAllFACSMute)
    bpy.utils.unregister_class(HHP_OT_MuteSectionFACS) 