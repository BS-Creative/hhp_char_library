"""Build a dependency-safe hip pivot using Rigify's raw torso channels."""
import bpy
import json


def build_hip_pivot(arm, torso_name='torso', root_name='root', binding_name=None):
    torso = arm.pose.bones[torso_name]
    if binding_name is None:
        binding_name = json.loads(arm.get('hhp_rigify_manifest', '{}')).get('bindings', {}).get('hip')
    names = ('MCH-HHP-proportion-torso', 'MCH-HHP-proportion-hip')
    parent_name, world_name = 'MCH-HHP-proportion-parent', 'MCH-HHP-proportion-world'
    parent_source = torso.parent
    if parent_source is None:
        raise RuntimeError('Rigify torso has no generated parent switch mechanism')
    if any(name in arm.data.bones for name in (*names, parent_name, world_name)):
        raise RuntimeError('Rigify hip proportion helpers already exist')
    bpy.context.view_layer.objects.active = arm
    bpy.ops.object.mode_set(mode='EDIT')
    bones = arm.data.edit_bones
    for name, donor, parent in [(parent_name, parent_source.name, None), (names[0], torso_name, parent_name), (names[1], binding_name or 'hip', names[0])]:
        source = bones[donor]
        bone = bones.new(name)
        bone.head, bone.tail, bone.roll = source.head, source.tail, source.roll
        bone.parent = bones[parent] if parent else None
        bone.use_deform = False
        bone.inherit_scale = 'FULL'
        arm.data.collections['HHP Rigify Bindings'].assign(bone)
    world = bones.new(world_name)
    world.head, world.tail = (0, 0, 0), (0, .1, 0)
    world.use_deform = False
    arm.data.collections['HHP Rigify Bindings'].assign(world)
    bpy.ops.object.mode_set(mode='OBJECT')
    # Reproduce only the torso's unscaled Root/None choice. Reading its evaluated
    # generated parent would recurse through the proportion transform itself.
    parent = arm.pose.bones[parent_name]
    source_switch = next(c for c in parent_source.constraints if c.type == 'ARMATURE' and c.name == 'SWITCH_PARENT')
    if len(source_switch.targets) != 1:
        raise RuntimeError('Unexpected Rigify torso parent choices')
    shadow_switch = parent.constraints.copy(source_switch)
    shadow_switch.targets[0].subtarget = root_name
    _copy_weight_driver(arm, source_switch, 0, shadow_switch, 0)
    # None means no global parent transform, but character proportions still
    # change anatomical size. Existing selectors and Rigify snap metadata remain
    # unchanged: selector zero drives this hidden hip-only affine space.
    for bone in tuple(arm.pose.bones):
        if bone.name.startswith('MCH-HHP-proportion-'):
            continue
        for switch in bone.constraints:
            if switch.type != 'ARMATURE' or switch.name != 'SWITCH_PARENT' or not switch.targets:
                continue
            new_index = len(switch.targets)
            target = switch.targets.new()
            target.target, target.subtarget, target.weight = arm, world_name, 0.
            _copy_weight_driver(arm, switch, 0, switch, new_index, 'var == 0')
    # Single-property variables reference raw animation channels. Reading the
    # evaluated torso pose here would create a dependency cycle through root.
    pairs = [(arm.pose.bones[names[0]], torso)]
    if binding_name:
        pairs.append((arm.pose.bones[names[1]], arm.pose.bones[binding_name]))
    for target, source in pairs:
        for path, size in [('rotation_mode', None), ('location', 3), ('rotation_euler', 3),
                           ('rotation_quaternion', 4), ('rotation_axis_angle', 4), ('scale', 3)]:
            for index in range(size or 1):
                curve = target.driver_add(path) if size is None else target.driver_add(path, index)
                driver = curve.driver
                driver.type = 'SCRIPTED'
                variable = driver.variables.new()
                variable.name, variable.type = 'channel', 'SINGLE_PROP'
                variable.targets[0].id = arm
                variable.targets[0].data_path = source.path_from_id(path) + ('[%d]' % index if size else '')
                driver.expression = 'channel'
    # The Daz hip morph branch is independent of the generated body root.
    # Apply its native local composition after the binding's raw channels.
    for source in arm.pose.bones['hip'].constraints:
        if (source.type == 'COPY_TRANSFORMS' and source.target == arm
                and source.subtarget == 'hip(drv)' and source.owner_space == source.target_space == 'LOCAL'):
            copy = arm.pose.bones[names[1]].constraints.copy(source)
            copy.name = '(HHP) Hip Morph Pivot'
    return names[1]



def _copy_weight_driver(arm, source, source_index, destination, destination_index, expression=None):
    source_path = source.path_from_id() + '.targets[%d].weight' % source_index
    original = arm.animation_data.drivers.find(source_path)
    if original is None or len(original.driver.variables) != 1:
        raise RuntimeError('Unexpected Rigify parent switch driver')
    source_var = original.driver.variables[0]
    if source_var.type != 'SINGLE_PROP':
        raise RuntimeError('Rigify parent switch selector must be a raw property')
    path = destination.path_from_id() + '.targets[%d].weight' % destination_index
    driver = arm.driver_add(path).driver
    driver.type = 'SCRIPTED'
    variable = driver.variables.new()
    variable.name, variable.type = source_var.name, source_var.type
    variable.targets[0].id = source_var.targets[0].id
    variable.targets[0].data_path = source_var.targets[0].data_path
    driver.expression = (expression.replace('var', variable.name) if expression else original.driver.expression)
