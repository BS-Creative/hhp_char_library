"""Keep native metatarsal morph drivers separate from editable pose channels."""
import bpy


def build_native_driver_helpers(arm):
    """Move the two native YZX X-rotation drivers intact into hidden helpers.

    In YZX order, the X rotation is applied last: Rx @ Rz @ Ry. A LOCAL
    Copy Rotation using BEFORE reproduces that same composition while leaving
    the original bone's rotation channels available for a visual pose or Action.
    """
    names = ('lMetatarsals', 'rMetatarsals')
    drivers = arm.animation_data.drivers if arm.animation_data else None
    if drivers is None:
        return {}
    planned = []
    for name in names:
        source = arm.pose.bones.get(name)
        if source is None:
            continue
        curve = drivers.find(source.path_from_id('rotation_euler'), index=0)
        if curve is None:
            continue
        helper_name = 'MCH-HHP-native-driver-'+name
        if helper_name in arm.data.bones:
            raise ValueError('The native metatarsal driver helper already exists: '+name)
        if source.rotation_mode != 'YZX':
            raise ValueError('The native metatarsal driver requires its original YZX rotation order: '+name)
        planned.append((name, helper_name, curve))
    if not planned:
        return {}
    bpy.context.view_layer.objects.active = arm
    if arm.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.mode_set(mode='EDIT')
    bones = arm.data.edit_bones
    collection = arm.data.collections.get('HHP Rigify Bindings')
    if collection is None:
        collection = arm.data.collections.new('HHP Rigify Bindings')
        collection.is_visible = False
    for name, helper_name, _curve in planned:
        source = bones[name]
        helper = bones.new(helper_name)
        helper.head, helper.tail, helper.roll = source.head, source.tail, source.roll
        helper.parent = source.parent
        helper.inherit_scale = source.inherit_scale
        helper.use_inherit_rotation = source.use_inherit_rotation
        helper.use_local_location = source.use_local_location
        helper.use_deform = False
        collection.assign(helper)
    bpy.ops.object.mode_set(mode='OBJECT')
    result = {}
    for name, helper_name, curve in planned:
        source, helper = arm.pose.bones[name], arm.pose.bones[helper_name]
        helper.rotation_mode = source.rotation_mode
        helper.rotation_euler.x = source.rotation_euler.x
        copied = drivers.from_existing(src_driver=curve)
        copied.data_path = helper.path_from_id('rotation_euler')
        copied.array_index = 0
        drivers.remove(curve)
        source.rotation_euler.x = 0.0
        constraint = source.constraints.new('COPY_ROTATION')
        constraint.name = '(HHP) Native Metatarsal Morph'
        constraint.target, constraint.subtarget = arm, helper_name
        constraint.owner_space = constraint.target_space = 'LOCAL'
        constraint.euler_order = 'YZX'
        constraint.mix_mode = 'BEFORE'
        constraint.use_x, constraint.use_y, constraint.use_z = True, False, False
        control_index = next((index for index, item in enumerate(source.constraints)
                              if item.name == '(HHP) Rigify Control'), -1)
        source.constraints.move(len(source.constraints)-1, control_index+1)
        # Even a zero-angle Copy Rotation decomposes/recomposes the pose.
        # Skip that numerical no-op so neutral deformation remains bit-exact.
        gate = constraint.driver_add('mute').driver
        gate.type = 'SCRIPTED'
        variable = gate.variables.new()
        variable.name, variable.type = 'morph', 'SINGLE_PROP'
        variable.targets[0].id = arm
        variable.targets[0].data_path = helper.path_from_id('rotation_euler')+'[0]'
        gate.expression = 'morph == 0.0'
        if hasattr(helper, 'hide'):
            helper.hide = True
        else:
            helper.bone.hide = True
        result[name] = helper_name
    arm.update_tag(refresh={'OBJECT'})
    bpy.context.view_layer.update()
    return result
