import bpy

class DYNAMIC_PRESSURE_BRUSH_OT_Operator(bpy.types.Operator):
    bl_idname = "object.dynamic_pressure_brush"
    bl_label = "Dynamic Pressure (Brush)"
    bl_description = "Configures selected objects as contact brushes that apply pressure to canvas surfaces"
    bl_options = {'REGISTER', 'UNDO'}

    confirmed: bpy.props.BoolProperty(
        default=False,
        options={'HIDDEN'}
    )
    
    # Add properties for proxy creation
    step: bpy.props.StringProperty(
        default='CHECK',
        options={'HIDDEN'}
    )
    
    create_proxy: bpy.props.BoolProperty(
        name="Create proxy brush from selected",
        description="Creates a separate water-tight mesh that acts as a proxy for the original. This is a cleaner way of handling the brush instead of using the original mesh itself, allowing for better collision handling.",
        default=True
    )
    
    decimate_proxy: bpy.props.BoolProperty(
        name="Decimate Proxy",
        description="Apply decimation to the proxy mesh",
        default=False
    )
    
    decimation_ratio: bpy.props.FloatProperty(
        name="Decimation Ratio",
        description="Ratio for mesh decimation (lower = more decimation)",
        default=0.25,
        min=0.0,
        max=1.0,
        soft_min=0.1,
        soft_max=0.5
    )

    def invoke(self, context, event):
        # Always reset the step and confirmed flag
        self.step = 'CHECK'
        self.confirmed = False
        
        has_existing_modifiers = False
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                for mod in obj.modifiers:
                    # Check for any Dynamic Paint or any modifier with "(HHP-DP)" in its name.
                    if mod.type == 'DYNAMIC_PAINT' or "(HHP-DP)" in mod.name:
                        has_existing_modifiers = True
                        break
                if has_existing_modifiers:
                    break

        # Only show the warning if at least one mesh has a relevant modifier.
        if has_existing_modifiers:
            return context.window_manager.invoke_props_dialog(self, width=400)
        else:
            # Skip to proxy options
            self.step = 'PROXY'
            return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        
        if self.step == 'CHECK':
            layout.label(text="Warning: Existing dynamic paint modifiers found.", icon='ERROR')
            layout.label(text="Remove and continue?")
            self.confirmed = True
        
        elif self.step == 'PROXY':
            col = layout.column(align=True)
            col.prop(self, "create_proxy")
            
            # Combined row for decimate checkbox and ratio slider
            decimate_row = col.row(align=True)
            decimate_row.active = self.create_proxy
            
            # Make checkbox look like a button
            decimate_btn = decimate_row.row(align=True)
            decimate_btn.prop(self, "decimate_proxy", toggle=True, icon='MOD_DECIM')
            
            # Add slider to same row
            decimate_row.prop(self, "decimation_ratio", text="")

    def execute(self, context):
        if self.step == 'CHECK':
            # Move to proxy options
            self.step = 'PROXY'
            return context.window_manager.invoke_props_dialog(self, width=400)
            
        # If proxy creation is enabled, run the proxy creation code
        objects_to_process = context.selected_objects.copy()
        
        if self.create_proxy:
            self.create_proxy_brushes(context, self.decimate_proxy, self.decimation_ratio)
            # Now the selected objects are the proxies, which we'll configure as brushes
        
        # Process selected objects (either originals or newly created proxies)
        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue

            context.view_layer.objects.active = obj

            # Gather any modifiers that are Dynamic Paint or have "(HHP-DP)" in their name.
            mods_to_remove = []
            for mod in obj.modifiers:
                if mod.type == 'DYNAMIC_PAINT' or "(HHP-DP)" in mod.name:
                    mods_to_remove.append(mod)
            # Remove them in reverse order (saving each name first).
            for mod in reversed(mods_to_remove):
                mod_name = mod.name
                obj.modifiers.remove(mod)
                self.report({'INFO'}, f"Removed modifier '{mod_name}' from {obj.name}")

            # Add a Dynamic Paint modifier and switch it to BRUSH mode.
            bpy.ops.object.modifier_add(type='DYNAMIC_PAINT')
            bpy.ops.dpaint.type_toggle(type='BRUSH')
            dp_mod = obj.modifiers.get("Dynamic Paint")
            if not dp_mod:
                self.report({'WARNING'}, f"Dynamic Paint modifier not found on {obj.name}.")
                continue

            dp_mod.name = "(HHP-DP) - Brush"
            dp_mod.ui_type = 'BRUSH'

            # Configure brush settings.
            dp_mod.brush_settings.paint_color = (0, 0, 0)
            dp_mod.brush_settings.paint_source = 'VOLUME_DISTANCE'
            dp_mod.brush_settings.paint_distance = 0.001

            self.report({'INFO'}, f"Configured Dynamic Paint brush on {obj.name}.")

        self.report({'INFO'}, "Processing complete.")
        return {'FINISHED'}
        
    def create_proxy_brushes(self, context, decimate_proxy, decimation_ratio):
        """Create proxy brushes from selected objects"""
        
        ##############################
        # Proxy Creation and Helpers #
        ##############################

        def clear_custom_properties(obj):
            """Clear all custom properties of the object."""
            keys = list(obj.keys())
            for key in keys:
                if key != '_RNA_UI':
                    del obj[key]

        def add_driver(source, target, prop, data_path, index=-1):
            """Add a driver to a property."""
            if index == -1:
                fcurve = source.driver_add(data_path)
            else:
                fcurve = source.driver_add(data_path, index)
            driver = fcurve.driver
            driver.type = 'AVERAGE'
            var = driver.variables.new()
            var.name = 'var'
            var.type = 'SINGLE_PROP'
            var.targets[0].id = target
            var.targets[0].data_path = prop
            return driver

        def remove_drivers_from_visibility(obj):
            """Remove drivers from 'hide_viewport' and 'hide_render' properties."""
            if obj.animation_data:
                for prop in ['hide_viewport', 'hide_render']:
                    try:
                        fcurve = obj.animation_data.drivers.find(f'{prop}')
                        if fcurve:
                            obj.driver_remove(f'{prop}')
                    except AttributeError:
                        pass

        def create_vertex_group_from_selection(obj):
            """Create a vertex group from the current selection."""
            group = obj.vertex_groups.new(name="MaskGroup")
            selected_vertices = [v for v in obj.data.vertices if v.select]
            for v in selected_vertices:
                group.add([v.index], 1.0, 'ADD')
            return group.name

        def remove_subdiv_and_multires_modifiers(obj):
            """Remove all Subdivision Surface and Multiresolution modifiers from the object."""
            for modifier in obj.modifiers[:]:
                if modifier.type in {'SUBSURF', 'MULTIRES'}:
                    obj.modifiers.remove(modifier)

        def create_proxy_for_object(obj, vertex_selection_required):
            """
            Create a proxy object for the given object with specified modifiers and drivers.
            """
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            context.view_layer.objects.active = obj
            bpy.ops.object.duplicate(linked=True)
            
            duplicate_obj = context.active_object
            duplicate_obj.name = "(BS)_Proxy_" + obj.name
            clear_custom_properties(duplicate_obj)
            duplicate_obj["BS_Inflate"] = 0.0
            duplicate_obj["_RNA_UI"] = {"BS_Inflate": {"min": 0.0, "max": 1.0, "soft_min": 0.0, "soft_max": 1.0}}
            duplicate_obj.display_type = 'WIRE'
            remove_subdiv_and_multires_modifiers(duplicate_obj)
            
            # Set visibility properties
            duplicate_obj.visible_camera = False
            duplicate_obj.visible_diffuse = False
            duplicate_obj.visible_glossy = False
            duplicate_obj.visible_transmission = False
            duplicate_obj.visible_volume_scatter = False
            duplicate_obj.visible_shadow = False
            
            if vertex_selection_required:
                create_vertex_group_from_selection(obj)
                self.report({'INFO'}, f"Vertex group created for {obj.name} but mask modifier not added.")
                
            displace_modifier = duplicate_obj.modifiers.new(name="Displace", type='DISPLACE')
            displace_modifier.mid_level = 0.990
            add_driver(displace_modifier, duplicate_obj, '["BS_Inflate"]', 'strength')
            remove_drivers_from_visibility(duplicate_obj)
            
            # Disable in renders
            duplicate_obj.hide_render = True
            
            self.report({'INFO'}, f"Duplicate proxy created for {obj.name} with materials unlinked and link set to 'OBJECT'.")
            return duplicate_obj

        def make_proxy_single_user(proxy):
            """Make the proxy's mesh data single user."""
            proxy.data = proxy.data.copy()
            self.report({'INFO'}, f"Mesh data for {proxy.name} made single user.")

        def process_proxy(proxy, edit_mode_with_selection):
            """
            Process each proxy individually with operations based on selection state.
            """
            context.view_layer.objects.active = proxy
            proxy.select_set(True)
            bpy.ops.object.mode_set(mode='EDIT')
            
            if edit_mode_with_selection:
                bpy.ops.mesh.split()
                bpy.ops.mesh.select_all(action='INVERT')
                bpy.ops.mesh.reveal()
                if any(v.select for v in proxy.data.vertices):
                    bpy.ops.mesh.delete(type='VERT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.fill_holes()
                context.scene.tool_settings.mesh_select_mode = (False, False, True)  # Face select mode
                bpy.ops.mesh.fill_holes(sides=0)
                bpy.ops.mesh.select_all(action='DESELECT')
                bpy.ops.mesh.select_face_by_sides(number=4, type='GREATER')
                bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')
            else:
                bpy.ops.mesh.reveal()
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.fill_holes()
                context.scene.tool_settings.mesh_select_mode = (False, False, True)  # Face select mode
                bpy.ops.mesh.fill_holes(sides=0)
                bpy.ops.mesh.select_all(action='DESELECT')
                bpy.ops.mesh.select_face_by_sides(number=4, type='GREATER')
                bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')
            
            bpy.ops.object.mode_set(mode='OBJECT')

        ############################
        # Main Processing Routine  #
        ############################

        selected_objs = context.selected_objects.copy()
        active_obj = context.active_object
        vertex_selection_required = False
        edit_mode_with_selection = False
        proxy_map = {}  # To store the mapping of original objects and their proxies

        # Determine if any selected mesh in Edit mode has vertex selections
        for obj in selected_objs:
            if obj.type == 'MESH' and obj.mode == 'EDIT':
                context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode='OBJECT')
                if any(v.select for v in obj.data.vertices):
                    vertex_selection_required = True
                    edit_mode_with_selection = True
                bpy.ops.object.mode_set(mode='EDIT')

        if selected_objs:
            bpy.ops.object.mode_set(mode='OBJECT')
            for obj in selected_objs:
                if obj.type == 'MESH':
                    proxy = create_proxy_for_object(obj, vertex_selection_required)
                    make_proxy_single_user(proxy)
                    proxy_map[obj] = proxy
                    process_proxy(proxy, edit_mode_with_selection)
            
            bpy.ops.object.select_all(action='DESELECT')
            for original, proxy in proxy_map.items():
                proxy.select_set(True)
                # Set the active proxy if its corresponding original was active
                if original == active_obj:
                    context.view_layer.objects.active = proxy
            
            self.report({'INFO'}, "Proxies created, processed, and selection restored for all selected meshes.")
        else:
            self.report({'INFO'}, "No selected meshes to process.")

        ##################################
        # Clear Materials from Proxies   #
        ##################################

        # Iterate over selected objects (now proxies) and clear their material slots
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                obj.data.materials.clear()
        self.report({'INFO'}, "All materials removed from selected objects.")

        ##################################
        # Conditional Mesh Decimation    #
        ##################################

        # Apply decimation if enabled
        if decimate_proxy:
            bpy.ops.object.editmode_toggle()  # Enter Edit Mode.
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.decimate(ratio=decimation_ratio)
            bpy.ops.object.editmode_toggle()  # Exit Edit Mode.
            self.report({'INFO'}, f"Decimation applied with a ratio of {decimation_ratio}.")
        else:
            self.report({'INFO'}, "Decimation skipped.")

def register():
    bpy.utils.register_class(DYNAMIC_PRESSURE_BRUSH_OT_Operator)

def unregister():
    bpy.utils.unregister_class(DYNAMIC_PRESSURE_BRUSH_OT_Operator)

if __name__ == "__main__":
    register()
