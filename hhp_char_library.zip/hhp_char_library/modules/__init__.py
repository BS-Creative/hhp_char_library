# This file can be empty - it just needs to exist 
from . import shapekey_name_updater_HHP4
from . import inflate_sk_by_active
from . import create_hhp_mask

def register():
    shapekey_name_updater_HHP4.register()
    inflate_sk_by_active.register()
    create_hhp_mask.register()

def unregister():
    create_hhp_mask.unregister()
    inflate_sk_by_active.unregister()
    shapekey_name_updater_HHP4.unregister() 