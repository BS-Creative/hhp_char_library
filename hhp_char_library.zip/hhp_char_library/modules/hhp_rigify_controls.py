"""Undoable Preview Animation controls and the Daz rotation-limit choice."""
import bpy


def _core():
    from . import hhp_rigify
    return hhp_rigify


def available():
    from . import rigify_compat_loader
    return rigify_compat_loader.is_available()


class HHP_OT_SetRigType(bpy.types.Operator):
    bl_idname = 'hhp.set_rig_type'
    bl_label = 'Change Rig Type'
    bl_description = 'Match the current pose and switch between Daz and Rigify controls'
    bl_options = {'REGISTER', 'UNDO'}

    rig_type: bpy.props.EnumProperty(items=[
        ('DAZ', 'Daz', 'Pose the original Daz bones'),
        ('RIGIFY', 'Rigify', 'Pose the generated Rigify controls')])
    rotation_limits: bpy.props.EnumProperty(name='Daz Rotation Limits', items=[
        ('DISABLE', 'Disable Daz Rotation Limits (Recommended)', 'Keep transferred rotations beyond the Daz rotation limits'),
        ('USE', 'Use Daz Rotation Limits', 'Clamp rotations to the original Daz limits; this can change the pose')],
        default='DISABLE', options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return _core().is_built(_core().get_armature(context))

    def invoke(self, context, event):
        if self.rig_type == 'DAZ':
            return context.window_manager.invoke_props_dialog(self, width=440)
        return self.execute(context)

    def draw(self, context):
        col = self.layout.column()
        col.label(text='Daz has rotation limits. Rigify does not use these limits.')
        col.label(text='Enabling the Daz limits may change the transferred pose.')
        col.label(text='Daz breast movement limits still apply.')
        col.prop(self, 'rotation_limits', expand=True)

    def execute(self, context):
        core = _core()
        arm = core.get_armature(context)
        if self.rig_type == 'RIGIFY' and not available():
            self.report({'ERROR'}, 'Rigify Compat is unavailable. Restore that folder to use Rigify pose matching.')
            return {'CANCELLED'}
        key = bool(arm.hhp_anim_preview_props.keyframe_ik_fk_switch)
        try:
            core.switch_rig(arm, self.rig_type == 'RIGIFY', key,
                            use_daz_limits=self.rotation_limits == 'USE')
        except (RuntimeError, ValueError, KeyError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class HHP_MT_RigType(bpy.types.Menu):
    bl_idname = 'HHP_MT_rig_type'
    bl_label = 'Rig Type'

    def draw(self, context):
        self.layout.operator_context = 'INVOKE_DEFAULT'
        self.layout.operator('hhp.set_rig_type', text='Daz', icon='ARMATURE_DATA').rig_type = 'DAZ'
        row = self.layout.row()
        row.enabled = available()
        row.operator('hhp.set_rig_type', text='Rigify', icon='OUTLINER_DATA_ARMATURE').rig_type = 'RIGIFY'


class HHP_OT_SetRigMode(bpy.types.Operator):
    bl_idname = 'hhp.set_rig_mode'
    bl_label = 'Change IK/FK Mode'
    bl_description = 'Match the current pose and switch Rigify limbs, fingers and tongue between IK and FK'
    bl_options = {'REGISTER', 'UNDO'}
    mode: bpy.props.EnumProperty(items=[('IK', 'IK', 'Use IK targets'), ('FK', 'FK', 'Use FK controls')])

    @classmethod
    def poll(cls, context):
        return _core().control_rig_active(_core().get_armature(context)) and available()

    def execute(self, context):
        arm = _core().get_armature(context)
        try:
            _core().switch_kinematics(arm, self.mode == 'IK', arm.hhp_anim_preview_props.keyframe_ik_fk_switch)
        except (RuntimeError, ValueError, KeyError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


CLASSES = (HHP_OT_SetRigType, HHP_MT_RigType, HHP_OT_SetRigMode)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
