"""Show the relevant bone collections while retaining the user's visibility choices."""


def refresh(arm, data, active, show_daz):
    native = set(data['native_bones'])
    controls = set(data['controls'])
    owned = set(data['generated_bones']) | controls
    for key in ('bindings', 'outputs', 'channels', 'native_driver_helpers'):
        owned.update(data.get(key, {}).values())
    owned.update(data.get('proportion_helpers', []))
    owned.update(data.get('extension_helpers', []))
    for helpers in data.get('forefoot_helpers', {}).values():
        owned.update(helpers.values() if isinstance(helpers, dict) else helpers)

    def members(collection):
        yield from collection.bones
        for child in collection.children:
            yield from members(child)

    def visible(bone):
        pb = arm.pose.bones[bone.name]
        return not (pb.hide if hasattr(pb, 'hide') else bone.hide)

    for collection in arm.data.collections_all:
        bones = list(members(collection))
        generated = bool(bones) and all(b.name in owned for b in bones)
        is_daz = collection.name.startswith('(DAZ)')
        # Native face/body/root collections retain their existing controls.
        if not generated and not is_daz and bones:
            continue
        if 'hhp_user_visible' not in collection:
            collection['hhp_user_visible'] = collection.is_visible
        elif collection.is_visible != collection.get('hhp_auto_visible', collection.is_visible):
            collection['hhp_user_visible'] = collection.is_visible
        if generated:
            relevant = active and any(b.name in controls and visible(b) for b in bones)
        elif is_daz:
            relevant = bool(bones) and (not active or show_daz)
        else:
            relevant = False
        value = bool(relevant and collection['hhp_user_visible'])
        if collection.is_visible != value:
            collection.is_visible = value
        # A previously soloed collection must not defeat a rig switch.
        if not relevant and collection.is_solo:
            collection.is_solo = False
        collection['hhp_auto_visible'] = value
