"""Resolve transferred asset name clashes after applying the character identity."""
import bpy
from bpy.props import CollectionProperty, EnumProperty, IntProperty, PointerProperty

from . import identity_transfer_assets as assets
from . import transfer_optimized_pending as optimized_pending
from .animation_transfer_support import TransferError


class HHP_UL_identity_post_transfer_clashes(bpy.types.UIList):
    """Choose incoming, existing, or both versions of each transferred asset."""

    bl_idname = 'HHP_UL_identity_post_transfer_clashes'

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type not in {'DEFAULT', 'COMPACT'}:
            return
        layout.use_property_split = False
        layout.use_property_decorate = False
        row = layout.row(align=True)
        row.alert = item.is_surface_deform_target
        split = row.split(factor=0.2, align=True)
        selected = split.column(align=True)
        selected.prop_enum(item, 'choice', 'TARGET', text='', icon='TRIA_LEFT')

        split = split.split(factor=0.75, align=True)
        info = split.column(align=True)
        base_name = assets.data.get_base_object_name(item.source_name or item.target_name)
        base_name = base_name or '(Unnamed Asset)'
        if item.is_surface_deform_target:
            info.label(text=f'{base_name} (Deformer. Keep it)', icon='MOD_MESHDEFORM')
        else:
            info.label(text=base_name, icon='OUTLINER_OB_MESH')
        choices = split.split(factor=0.35, align=True)
        choices.prop_enum(item, 'choice', 'BOTH', text='', icon='DUPLICATE')
        choices.prop_enum(item, 'choice', 'SOURCE', text='', icon='TRIA_RIGHT')


class HHP_OT_identity_clash_set_all(bpy.types.Operator):
    bl_idname = 'hhp.identity_clash_set_all'
    bl_label = 'Set All Identity Asset Clashes'
    bl_description = 'Set the same choice for every transferred asset clash'
    bl_options = {'REGISTER'}

    choice: EnumProperty(
        name='Choice',
        description='Choose which transferred assets to retain',
        items=[('TARGET', 'Selected', 'Keep all assets from the selected target character'),
               ('BOTH', 'Both', 'Keep all selected and existing assets'),
               ('SOURCE', 'Existing', 'Keep all assets already on the active source character')],
        default='BOTH',
    )

    def execute(self, context):
        entries = context.window_manager.hhp_identity_clashes
        if not entries:
            return {'CANCELLED'}
        for item in entries:
            item.choice = self.choice
        return {'FINISHED'}


def clear(context):
    optimized_pending.clear('identity')
    wm = context.window_manager
    wm.hhp_identity_clashes.clear()
    wm.hhp_identity_clash_index = 0
    wm.hhp_identity_clash_owner = None


class HHP_OT_identity_clash_resolver(bpy.types.Operator):
    bl_idname = 'hhp.identity_clash_resolver'
    bl_label = 'Resolve Asset Name Clashes'
    bl_description = 'Resolve transferred asset name clashes on the source character'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        wm = context.window_manager
        return bool(getattr(wm, 'hhp_identity_clashes', ()))

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=460)

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        col = layout.column()
        col.label(text=f'Found {len(wm.hhp_identity_clashes)} asset name clash(es). Choose which version to keep.',
                  icon='ERROR')
        layout.separator()
        header = layout.split(factor=0.5, align=True)
        left = header.column(align=True)
        left.alignment = 'LEFT'
        left.label(text='Selected (Update from)')
        right = header.column(align=True)
        right.alignment = 'RIGHT'
        right.label(text='Existing (Active / Update to)')
        layout.template_list('HHP_UL_identity_post_transfer_clashes', '',
                             wm, 'hhp_identity_clashes', wm, 'hhp_identity_clash_index',
                             rows=6, maxrows=10)
        layout.separator()
        layout.label(text='Batch Operations:')
        row = layout.row(align=True)
        row.operator('hhp.identity_clash_set_all', text='Set All to Selected',
                     icon='TRIA_LEFT').choice = 'TARGET'
        row.operator('hhp.identity_clash_set_all', text='All to Both',
                     icon='DUPLICATE').choice = 'BOTH'
        row.operator('hhp.identity_clash_set_all', text='Set All to Existing',
                     icon='TRIA_RIGHT').choice = 'SOURCE'

    def execute(self, context):
        wm = context.window_manager
        entries = wm.hhp_identity_clashes
        if not entries:
            clear(context)
            self.report({'WARNING'}, 'No asset clashes to resolve.')
            return {'CANCELLED'}
        owner = wm.hhp_identity_clash_owner
        if owner is None:
            self.report({'ERROR'}, 'The transferred source character is no longer available.')
            clear(context)
            return {'CANCELLED'}
        count = len(entries)
        changed = any(item.choice != 'BOTH' for item in entries)
        try:
            assets.resolve_post_transfer(context, owner, entries)
        except (TransferError, RuntimeError, ValueError, KeyError) as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        optimized_pending.finish('identity', owner, context, self.report, changed=changed)
        clear(context)
        self.report({'INFO'}, f'Resolved {count} asset clash(es).')
        return {'FINISHED'}

    def cancel(self, context):
        # The completed transfer already keeps both; dismissing this dialog preserves it.
        clear(context)
        return {'CANCELLED'}


def open_after_transfer(context, source, entries, optimized_state=None):
    """Record the completed transfer's clashes and open their resolver when interactive."""
    fields = ('category', 'source_name', 'target_name', 'is_surface_deform_target')
    saved = []
    for entry in entries:
        values = {}
        for field in fields:
            default = False if field == 'is_surface_deform_target' else ''
            values[field] = entry.get(field, default) if isinstance(entry, dict) else getattr(entry, field, default)
        saved.append(values)
    clear(context)
    wm = context.window_manager
    for values in saved:
        item = wm.hhp_identity_clashes.add()
        for name, value in values.items():
            setattr(item, name, value)
        item.name = item.target_name
        item.choice = 'BOTH'
    if not wm.hhp_identity_clashes:
        return
    wm.hhp_identity_clash_owner = source
    if optimized_state is not None:
        optimized_pending.remember('identity', source, optimized_state)
    if not bpy.app.background:
        bpy.ops.hhp.identity_clash_resolver('INVOKE_DEFAULT')


_CLASSES = (HHP_UL_identity_post_transfer_clashes, HHP_OT_identity_clash_set_all,
            HHP_OT_identity_clash_resolver)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.hhp_identity_clashes = CollectionProperty(
        type=assets.HHP_IdentityAssetClash, options={'HIDDEN', 'SKIP_SAVE'})
    bpy.types.WindowManager.hhp_identity_clash_index = IntProperty(
        name='Active Identity Asset Clash', default=0, options={'HIDDEN', 'SKIP_SAVE'})
    bpy.types.WindowManager.hhp_identity_clash_owner = PointerProperty(
        name='Identity Transfer Source', description='Character receiving the transferred assets',
        type=bpy.types.Object, options={'HIDDEN', 'SKIP_SAVE'})


def unregister():
    optimized_pending.clear('identity')
    for name in ('hhp_identity_clash_owner', 'hhp_identity_clash_index', 'hhp_identity_clashes'):
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
