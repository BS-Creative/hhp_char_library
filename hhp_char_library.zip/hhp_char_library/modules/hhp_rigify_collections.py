"""Independent control visibility through bone collections, without hiding bones."""
import json

RULE = 'hhp_visibility_rule'
REVISION = 'visibility_collections_revision'


def _owned(data):
    names = set(data['generated_bones']) | set(data['controls'])
    for key in ('bindings', 'outputs', 'channels', 'native_driver_helpers'):
        names.update(data.get(key, {}).values())
    for key in ('proportion_helpers', 'extension_helpers'):
        names.update(data.get(key, []))
    for group in data.get('forefoot_helpers', {}).values():
        names.update(group.values() if isinstance(group, dict) else group)
    return names


def _rules(data):
    rules = {name: ('HELPERS', '') for name in _owned(data)}
    rules.update({name: ('SHARED', '') for name in data['controls']})
    for item in data['limbs']:
        selector = item['master']
        for name in item['fk_bones']:
            rules[name] = ('LIMB_FK', selector)
        for name in item['ik_ctrl_bones'] + item['ik_extra_ctrls'] + item['tail_bones']:
            rules[name] = ('LIMB_IK', selector)
        rules[item['ik_ctrl_bones'][1]] = ('POLE', selector)
    for item in data['instances']:
        if not item['type'].endswith('.super_finger'):
            continue
        controls = item['bones']['ctrl']
        rules[controls['ik']] = ('DIGIT_IK', controls['ik'])
        for name in controls['fk']:
            rules[name] = ('DIGIT_FK', controls['ik'])
    return rules


def _label(rule):
    kind, selector = rule
    if kind in {'HELPERS', 'SHARED'}:
        return kind.title()
    if kind.startswith('LIMB') or kind == 'POLE':
        side = selector.rsplit('.', 1)[-1]
        return ('Poles' if kind == 'POLE' else kind.split('_')[-1]) + '.' + side
    if selector.startswith('tongue'):
        return kind.split('_')[-1]
    finger = selector.split('.')[0].removeprefix('f_').title()
    return finger + '.' + selector.rsplit('.', 1)[-1]


def upgrade(arm):
    """Partition collections once; no bone, constraint or driver transforms change."""
    from . import hhp_rigify as core
    data = core.manifest(arm)
    if data.get(REVISION, 0) >= 1:
        return False
    rules = _rules(data)
    collections = arm.data.collections
    originals = list(arm.data.collections_all)
    membership = {name: [c.name for c in arm.data.bones[name].collections] for name in rules}
    canonical = {name: names[0] if names else None for name, names in membership.items()}
    if any(name is None for name in canonical.values()):
        raise RuntimeError('A generated bone has no source collection')
    destinations = {}
    for collection in originals:
        groups = {}
        for bone in collection.bones:
            if bone.name in rules and canonical[bone.name] == collection.name:
                groups.setdefault(rules[bone.name], []).append(bone.name)
        if not groups:
            continue
        # Keep original collection names/identifiers and generated UI buttons.
        exclusive = all(b.name in rules for b in collection.bones)
        for rule, names in groups.items():
            if len(groups) == 1 and exclusive:
                target = collection
            else:
                target = collections.new(collection.name + ' / ' + _label(rule), parent=collection)
                target['hhp_user_visible'] = rule[0] != 'HELPERS'
                collection['hhp_visibility_parent'] = True
            target[RULE] = json.dumps(rule)
            if rule[0] == 'HELPERS':
                target['hhp_user_visible'] = False
            elif 'hhp_user_visible' not in target:
                target['hhp_user_visible'] = target.is_visible
            target['hhp_auto_visible'] = target.is_visible
            destinations.update({name: target for name in names})
    if set(destinations) != set(rules):
        raise RuntimeError('A generated bone could not be assigned a visibility collection')
    for name, destination in destinations.items():
        bone = arm.data.bones[name]
        for collection in list(bone.collections):
            collection.unassign(bone)
        destination.assign(bone)
        arm.pose.bones[name].hide = False
        bone.hide = False
    for name in data['driven']:
        # Native collections already provide the Daz visibility boundary.
        arm.pose.bones[name].hide = bool(data['native_hidden'].get(name, False))
        arm.data.bones[name].hide = bool(data['native_hidden'].get(name, False))
    data[REVISION] = 1
    data['visibility_original_membership'] = membership
    arm['hhp_rigify_manifest'] = json.dumps(data, separators=(',', ':'))
    refresh(arm, data, core.control_rig_active(arm),
            bool(getattr(getattr(arm, 'hhp_anim_preview_props', None), 'show_daz_bones', False)))
    return True


def _relevant(arm, rule, active):
    if not active:
        return False
    kind, selector = rule
    if kind in {'HELPERS', 'SHARED'}:
        return True
    pb = arm.pose.bones[selector]
    if kind.startswith('DIGIT'):
        ik = pb.get('FK_IK', 0) >= .5
    else:
        ik = pb.get('IK_FK', 0) < .5
    if kind == 'POLE':
        return ik and bool(pb.get('pole_vector', False))
    return ik if kind.endswith('_IK') else not ik


def refresh(arm, data, active, show_daz):
    """Only change collection visibility; preserve individual user bone hiding."""
    def relevance(collection):
        if RULE in collection:
            return _relevant(arm, json.loads(collection[RULE]), active)
        return any(relevance(child) for child in collection.children)

    for collection in arm.data.collections_all:
        managed = RULE in collection or collection.get('hhp_visibility_parent', False)
        is_daz = collection.name.startswith('(DAZ)')
        empty = not collection.bones and not collection.children
        if not managed and not is_daz and not empty:
            continue
        if 'hhp_user_visible' not in collection:
            collection['hhp_user_visible'] = collection.is_visible
        elif collection.is_visible != collection.get('hhp_auto_visible', collection.is_visible):
            collection['hhp_user_visible'] = collection.is_visible
        relevant = relevance(collection) if managed else (not empty and (not active or show_daz) if is_daz else False)
        value = bool(relevant and collection['hhp_user_visible'])
        if collection.is_visible != value:
            collection.is_visible = value
        if not relevant and collection.is_solo:
            collection.is_solo = False
        collection['hhp_auto_visible'] = value
