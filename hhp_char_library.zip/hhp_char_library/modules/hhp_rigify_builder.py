"""Attach an actual generated Rigify rig without rewriting the Daz skeleton."""
import json
import bpy
from mathutils import Matrix
from pathlib import Path

RIG_ID='hhp_rigify_v1'
CONTROL_CONSTRAINT='(HHP) Rigify Control'


def _snapshot(arm):
    return {b.name:(tuple(tuple(r) for r in b.matrix_local),b.parent.name if b.parent else None,
                    b.length,b.use_deform,b.inherit_scale) for b in arm.data.bones}


def _driver(owner,path,arm,expression,variables):
    fc=owner.driver_add(path)
    driver=fc.driver;driver.type='SCRIPTED'
    while driver.variables:driver.variables.remove(driver.variables[0])
    for name,data_path in variables.items():
        variable=driver.variables.new();variable.name=name;variable.type='SINGLE_PROP'
        variable.targets[0].id=arm;variable.targets[0].data_path=data_path
    driver.expression=expression
    return fc


def _rename_info(value,renames):
    if isinstance(value,str):
        for old,new in renames.items():
            if value==old:return new
            value=value.replace('"'+old+'"','"'+new+'"')
        return value
    if isinstance(value,list):return [_rename_info(v,renames) for v in value]
    if isinstance(value,dict):return {k:_rename_info(v,renames) for k,v in value.items()}
    return value


def _fk_map(info):
    result={'hip':'torso','pelvis':'hips','neckLower':'neck','neckUpper':'tweak_neck.02','head':'head_ctrl'}
    native_by_input={value:key for key,value in info['input_map'].items()}
    for item in info['instances']:
        bones=item['bones'];ctrl=bones['ctrl'];org=bones['org']
        if item['type'].endswith('.super_copy'):
            native=native_by_input.get(item['base_bone'].removeprefix('ORG-'))
            if native:result[native]=ctrl
        elif item['type'].endswith(('.arm','.leg')):
            for source,control in zip(org['main'],ctrl['fk']):
                native=native_by_input.get(source.removeprefix('ORG-'))
                if native:result[native]=control
        elif item['type'].endswith('.basic_spine'):
            for source,control in zip(org,ctrl['fk']['hips']+ctrl['fk']['chest']):
                native=native_by_input.get(source.removeprefix('ORG-'))
                if native:result[native]=control
        elif item['type'].endswith(('.super_finger','.super_palm')):
            for source,control in zip(org,ctrl['fk']):
                native=native_by_input.get(source.removeprefix('ORG-'))
                if native:result[native]=control
    return result


def build(arm):
    from .hhp_rigify_generate import generate_from_daz
    if arm.get('hhp_rigify_built'):
        raise ValueError('This character already has its generated Rigify controls')
    if 'root' not in arm.data.bones or 'hip' not in arm.data.bones:
        raise ValueError('The character needs its original Daz hip and HHP root')
    before=_snapshot(arm)
    native_hidden={pb.name:pb.hide if hasattr(pb,'hide') else pb.bone.hide for pb in arm.pose.bones}
    driver_count=len(arm.animation_data.drivers) if arm.animation_data else 0
    rig,info=generate_from_daz(arm)
    generated_driver_count=len(rig.animation_data.drivers) if rig.animation_data else 0
    renames={'root':'MCH-rigify-root','head':'head_ctrl'}
    collisions=(set(rig.data.bones.keys())-set(renames)) & set(arm.data.bones.keys())
    if collisions:raise ValueError('Control bone names already exist: '+', '.join(collisions))
    ui=rig['rig_ui']
    original_rig_id=info['rig_id']
    for old,new in renames.items():rig.data.bones[old].name=new
    info=_rename_info(info,renames)
    # All generated HHP instances use the same verified UI module/topology.
    info=json.loads(json.dumps(info).replace(original_rig_id,RIG_ID))
    text=ui.as_string().replace(original_rig_id,RIG_ID)
    for old,new in renames.items():
        text=text.replace('"'+old+'"','"'+new+'"').replace("'"+old+"'","'"+new+"'")
    from .rigify_compat_loader import require_ui
    packaged_ui=Path(require_ui().__file__)
    if packaged_ui.exists():text=packaged_ui.read_text(encoding='utf8')+'\nregister()\n'
    ui.clear();ui.write(text);ui.name='HHP Rigify UI'
    ui.use_module=False  # The installed trusted module registers the UI.
    info['ui_text']=ui.name
    generated=list(rig.data.bones.keys())
    controls=[pb.name for pb in rig.pose.bones if pb.custom_shape and not pb.name.startswith(('MCH-','ORG-','DEF-','VIS_'))]
    widgets={pb.custom_shape for pb in rig.pose.bones if pb.custom_shape}
    old_data=rig.data
    old_rig_name=rig.name
    bpy.ops.object.select_all(action='DESELECT')
    arm.select_set(True);rig.select_set(True);bpy.context.view_layer.objects.active=arm
    bpy.ops.object.join()
    joined=_snapshot(arm)
    assert {n:joined[n] for n in before}==before,'Original Daz rest changed during joining'
    assert len(arm.animation_data.drivers)==driver_count+generated_driver_count,'Generated drivers were not preserved'
    # Rigify's original pole-hide driver observes only pole_vector. The HHP
    # mode observer also handles Daz/FK ownership and owns these four hides.
    for limb in info['limbs']:
        pole=arm.pose.bones[limb['ik_ctrl_bones'][1]]
        owner=pole if hasattr(pole,'hide') else pole.bone
        owner.driver_remove('hide')
    for name in generated:
        if name.startswith('VIS_'):
            pb=arm.pose.bones[name]
            (pb if hasattr(pb,'hide') else pb.bone).driver_remove('hide')
    orphan=bpy.data.objects.get(old_rig_name)
    if orphan and orphan!=arm:
        if orphan.users_collection:raise RuntimeError('Generated temporary rig is still linked after joining')
        bpy.data.objects.remove(orphan,do_unlink=True)
    if old_data.users==0 or (old_data.use_fake_user and old_data.users==1):
        bpy.data.armatures.remove(old_data)
    arm.data['rig_id']=RIG_ID
    if hasattr(arm.data,'rigify_rig_ui'):arm.data.rigify_rig_ui=ui
    arm['rig_ui']=ui
    binding_collection=arm.data.collections.new('HHP Rigify Bindings')
    binding_collection.is_visible=False
    bindings={};outputs={};forefoot_helpers={};channels={}
    bpy.ops.object.mode_set(mode='EDIT')
    bones=arm.data.edit_bones
    bones['MCH-rigify-root'].parent=bones['root']
    for name in generated:bones[name].use_deform=False
    def helper(name,native,parent,matrix=None):
        source=bones[native];bone=bones.new(name)
        bone.head,bone.tail=source.head,source.tail
        bone.matrix=source.matrix if matrix is None else matrix
        bone.length=source.length;bone.parent=bones[parent]
        bone.use_deform=False;bone.inherit_scale='FULL'
        binding_collection.assign(bone)
        return bone.name
    for native,target in info['native_map'].items():
        binding=helper('MCH-HHP-bind-'+native,native,target,
                       bones[target].matrix @ Matrix(info['neutral_offsets'][native]))
        bindings[native]=binding;outputs[native]=binding
        if len(native)>1 and native[0] in 'lr' and ('Toe' in native) and native[1:]!='Metatarsals':
            cap=native[0].upper()
            reader=helper('MCH-HHP-foot-read-'+native,native,'DEF-foot.'+cap)
            final=helper('MCH-HHP-foot-out-'+native,native,'DEF-forefoot.'+cap)
            forefoot_helpers[native]=[reader,final]
            outputs[native]=final
    for native in bindings:
        source=bones[native]
        name=helper('MCH-HHP-channel-'+native,native,source.parent.name)
        bone=bones[name]
        bone.inherit_scale=source.inherit_scale
        bone.use_inherit_rotation=source.use_inherit_rotation
        bone.use_local_location=source.use_local_location
        channels[native]=name
    bpy.ops.object.mode_set(mode='OBJECT')
    for native,(reader,final) in forefoot_helpers.items():
        for name,target,space in [(reader,bindings[native],'POSE'),(final,reader,'LOCAL')]:
            con=arm.pose.bones[name].constraints.new('COPY_TRANSFORMS')
            con.name='(HHP) Forefoot Proportion Space'
            con.target=arm;con.subtarget=target;con.owner_space=con.target_space=space
    for native,name in channels.items():
        con=arm.pose.bones[name].constraints.new('COPY_TRANSFORMS')
        con.name='(HHP) Daz Channel Space'
        con.target=arm;con.subtarget=outputs[native];con.owner_space=con.target_space='POSE'
    arm['hhp_rigify_active']=0.0
    arm.id_properties_ui('hhp_rigify_active').update(min=0.,max=1.,description='Use the generated Rigify controls')
    arm['hhp_native_limit_override']=0.0
    original_limits=[]
    for native,output in outputs.items():
        pb=arm.pose.bones[native]
        con=pb.constraints.new('COPY_TRANSFORMS');con.name=CONTROL_CONSTRAINT
        con.target=arm;con.subtarget=channels[native];con.owner_space=con.target_space='LOCAL'
        con.remove_target_shear=True
        pb.constraints.move(len(pb.constraints)-1,0)
        _driver(con,'influence',arm,'active',{'active':'["hhp_rigify_active"]'})
        for constraint in pb.constraints:
            if constraint.type=='LIMIT_ROTATION':
                original_limits.append({'bone':native,'name':constraint.name,'mute':constraint.mute})
                if arm.animation_data.drivers.find(constraint.path_from_id('mute')):
                    raise ValueError('The Daz rotation limit has an unsupported existing driver: '+native)
                _driver(constraint,'mute',arm,'active or override or '+str(int(constraint.mute)),
                    {'active':'["hhp_rigify_active"]','override':'["hhp_native_limit_override"]'})
    from .hhp_rigify_channel_drivers import build_native_driver_helpers
    native_driver_helpers=build_native_driver_helpers(arm)
    from .hhp_rigify_proportions import build_hip_pivot
    hip_pivot=build_hip_pivot(arm,binding_name=bindings['hip'])
    data=dict(info,bindings=bindings,outputs=outputs,driven=list(bindings),native_bones=list(before),
              native_hidden=native_hidden,generated_bones=generated,controls=controls,
              active_property='hhp_rigify_active',forefoot_helpers=forefoot_helpers,channels=channels,
              fk_map=_fk_map(info),original_limits=original_limits,native_driver_helpers=native_driver_helpers,
              proportion_controls={'hip':'MCH-rigify-root','neckLower':['neck','head_ctrl'],
                                   'lMetatarsals':'forefoot.L','rMetatarsals':'forefoot.R'},
              proportion_pivots={'hip':hip_pivot},
              proportion_world='MCH-HHP-proportion-world',
              proportion_helpers=['MCH-HHP-proportion-torso',hip_pivot,
                                  'MCH-HHP-proportion-parent','MCH-HHP-proportion-world'],
              neutral_basis={n:[list(r) for r in arm.pose.bones[n].matrix_basis] for n in controls+list(bindings.values())})
    arm['hhp_rigify_manifest']=json.dumps(data,separators=(',',':'))
    arm['hhp_rigify_built']=1
    from .hhp5_root import ensure_scale_compensation
    ensure_scale_compensation(arm)
    from .hhp_rigify import sync_proportions,refresh_visibility
    sync_proportions(arm)
    widget_collection=bpy.data.collections.get('HHP Bone Widgets') or bpy.data.collections.new('HHP Bone Widgets')
    if not widget_collection.users:bpy.context.scene.collection.children.link(widget_collection)
    emptied=set()
    for widget in widgets:
        if widget.name not in widget_collection.objects:widget_collection.objects.link(widget)
        for collection in list(widget.users_collection):
            if collection!=widget_collection:
                collection.objects.unlink(widget);emptied.add(collection)
        widget.hide_render=True
    for collection in emptied:
        if not collection.objects and not collection.children and collection.name.startswith('WGTS_'):
            bpy.data.collections.remove(collection)
    arm['hhp_rigify_active']=0.0
    for name in ('Torso Detail','Arms Detail','Legs Detail'):
        collection=arm.data.collections.get(name)
        if collection:collection.is_visible=False
    refresh_visibility(arm)
    # New templates use the same verified extensions as the saved revision.
    # Their neutral calibration is a build-time operation, never a pose handler.
    from . import hhp_rigify as runtime
    from .hhp_rigify_leg_breast_upgrade import upgrade as upgrade_legs
    from .hhp_rigify_fingers_tongue import upgrade as upgrade_digits
    desired=runtime.matrices(arm,data['native_bones'])
    upgrade_legs(arm)
    upgrade_digits(arm)
    data=runtime.manifest(arm)
    arm['hhp_rigify_active']=1.0
    runtime.sync_proportions(arm)
    runtime._fit_bindings(arm,{name:desired[name] for name in data['driven']})
    data['neutral_basis']={n:[list(row) for row in arm.pose.bones[n].matrix_basis]
                          for n in data['controls']+list(data['bindings'].values())}
    arm['hhp_rigify_manifest']=json.dumps(data,separators=(',',':'))
    arm['hhp_rigify_active']=0.0
    runtime.sync_proportions(arm)
    from .hhp_rigify_collections import upgrade as upgrade_collections
    upgrade_collections(arm)
    refresh_visibility(arm)
    bound=_snapshot(arm)
    assert {n:bound[n] for n in before}==before,'Original Daz rest changed during binding'
    return runtime.manifest(arm)
