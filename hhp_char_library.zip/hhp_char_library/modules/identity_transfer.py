"""Transfer a selected character's identity onto the active HHP character."""
import hashlib
import json
import re

import bpy
from bpy.props import BoolProperty, EnumProperty, CollectionProperty, StringProperty
from . import hhp_naming, identity_transfer_data as data, identity_transfer_assets as assets
from . import identity_transfer_clash_ui as clash_ui
from . import identity_shader_versions as shader_versions
from . import transfer_optimized_materials as optimized_materials
from . import transfer_optimized_pending as optimized_pending
from .animation_transfer_support import (
    TransferError, collection_tree, prepare_transfer_materials, reference_slots,
    capture_proportions, proportion_transfer_plan, sync_proportions,
    is_hhp_mouth_shape_key, update_presets_mouth_shapes, purge_transfer_orphans,
)
from .shape_key_standard import prepare_source_shape_keys, _isolate_actions

_PREFIX = re.compile(r'^HHP (\d+) \| (.*)$', re.DOTALL)
_IDENTITY = ('head preset -', 'mouth preset -', 'char - head', 'char - mouth')
_SELECTORS = ('(HHP) Albedo Select', '(HHP) Normal Select')
_NAME_METADATA = '_hhp_identity_names'
_NEXT_ID = '_hhp_identity_next'


def is_identity_shape(name):
    return any(token in name.casefold() for token in _IDENTITY)


def armature(mesh):
    return next((mod.object for mod in mesh.modifiers
                 if mod.type == 'ARMATURE' and mod.object), None)


def ensure_original_preset(context, body):
    """Preserve the live file state when a character has no saved presets."""
    if body.get('presets'):
        return
    from .. import Customize_HHP as presets
    with context.temp_override(active_object=body, object=body):
        captured = presets.capture_preset(context)
    # The initial file snapshot also retains uncategorized/custom shape keys.
    if body.data.shape_keys:
        captured['shapekeys'] = {key.name: key.value for key in body.data.shape_keys.key_blocks}
    body['presets'] = {'Original File': captured}
    # The sole dynamic enum item is index zero. Set its stored selection without
    # applying the preset: its callback would edit still-shared shader instances.
    body['active_preset'] = 0


def safe_preset_name(name, used):
    """IDProperty keys allow 63 UTF-8 bytes, including the identity prefix."""
    if len(name.encode('utf8')) <= 63 and name not in used:
        return name
    digest = hashlib.sha256(name.encode('utf8')).hexdigest()[:8]
    index = 0
    while True:
        suffix = f' ~{digest}' + (f'.{index:03d}' if index else '')
        prefix = name.encode('utf8')[:63-len(suffix)].decode('utf8', errors='ignore')
        candidate = prefix + suffix
        if candidate not in used:
            return candidate
        index += 1


def preset_name_metadata(obj):
    try:
        value = json.loads(obj.get(_NAME_METADATA, '{}'))
        return value if isinstance(value, dict) else {}
    except (TypeError, ValueError):
        return {}


def merge_presets(source, target, identity_values):
    """Keep existing groups stable and allocate fresh groups to each donor."""
    result, labels, target_names = {}, {}, {}
    source_labels, target_labels = preset_name_metadata(source), preset_name_metadata(target)
    occupied = [int(m.group(1)) for name in source.get('presets', {})
                if (m := _PREFIX.match(name))]
    next_id = max([1, int(source.get(_NEXT_ID, 1))] + [n+1 for n in occupied])
    for name, preset in source.get('presets', {}).items():
        full = source_labels.get(name, name)
        desired = full if _PREFIX.match(full) else 'HHP 0 | ' + full
        # Retain a previous shortened key to keep preset references stable.
        key = name if _PREFIX.match(name) and name not in result else safe_preset_name(desired, result)
        item = data.safe_copy_val(preset)
        values = item.setdefault('shapekeys', {})
        for shape in set(values) | set(identity_values):
            if is_identity_shape(shape):
                values[shape] = identity_values.get(shape, 0.0)
        result[key] = item
        labels[key] = desired
    groups = {}
    for name, preset in target.get('presets', {}).items():
        full = target_labels.get(name, name)
        match = _PREFIX.match(full)
        old_group = match.group(1) if match else None
        if old_group not in groups:
            groups[old_group] = next_id
            next_id += 1
        desired = f'HHP {groups[old_group]} | ' + (match.group(2) if match else full)
        key = safe_preset_name(desired, result)
        result[key] = data.safe_copy_val(preset)
        labels[key] = desired
        target_names[name] = key
    # Even a donor without presets consumes an identity number.
    if not groups:
        next_id += 1
    return result, labels, target_names, next_id


def _outfit_roots(root):
    roots = {coll for coll in collection_tree(root)
             if data.get_base_object_name(coll.name) in {'Clothes', 'Appendages'}}
    return [coll for coll in roots if not any(coll in collection_tree(other)
                                            for other in roots if other != coll)]


def resolve_outfit(preset, root):
    """Resolve enumerated saved names before combining character hierarchies."""
    from .. import Customize_HHP as presets
    tree = collection_tree(root)
    states = {}
    for coll in _outfit_roots(root):
        for child in collection_tree(coll):
            states[child] = {'hide_viewport': True, 'hide_render': True}
            for obj in child.objects:
                states[obj] = {'hide_viewport': True, 'hide_render': True}

    def resolve(entries, candidates):
        allowed = {coll.name for coll in candidates}
        for saved, coll in presets.find_matching_collections_by_enumeration_mapping(list(entries), allowed):
            state = entries[saved]
            states[coll] = {key: bool(state.get(key, getattr(coll, key)))
                            for key in ('hide_viewport', 'hide_render')}
            for saved_obj, obj in presets.find_matching_object_by_enumeration_mapping(
                    list(state.get('objects', {})), coll):
                values = state['objects'][saved_obj]
                states[obj] = {key: bool(values.get(key, getattr(obj, key)))
                               for key in ('hide_viewport', 'hide_render')}
            resolve(state.get('child_collections', {}), coll.children)

    for entries in preset.get('collections', {}).values():
        resolve(entries, tree)
    return states


def complete_outfit(root, states):
    """Store every merged item so enumeration cannot enable the wrong outfit."""
    hidden = {'hide_viewport': True, 'hide_render': True}

    def capture(coll):
        result = dict(states.get(coll, hidden))
        result['objects'] = {obj.name: dict(states.get(obj, hidden)) for obj in coll.objects}
        if coll.children:
            result['child_collections'] = {child.name: capture(child) for child in coll.children}
        return result

    result = {'Clothes': {}, 'Appendages': {}}
    for coll in _outfit_roots(root):
        result[data.get_base_object_name(coll.name)][coll.name] = capture(coll)
    return result


def copy_tree(tree, copies):
    if tree is None:
        return None
    if tree in copies:
        return copies[tree]
    result = tree.copy()
    copies[tree] = result
    for node in result.nodes:
        if node.type == 'GROUP' and node.node_tree:
            node.node_tree = copy_tree(node.node_tree, copies)
    return result


def remap_owned_references(owners, replacements):
    """Retarget ID links, including driver variables, only on the supplied owners."""
    for owner in owners:
        for container, key, custom, value in list(reference_slots(owner)):
            if value in replacements and value != replacements[value]:
                if custom:
                    container[key] = replacements[value]
                else:
                    setattr(container, key, replacements[value])


def isolate_materials(objects):
    """Copy shader trees once per transfer without changing other characters."""
    materials, trees, meshes = {}, {}, set()
    for obj in objects:
        mesh = getattr(obj, 'data', None)
        if not hasattr(mesh, 'materials') or mesh in meshes:
            continue
        meshes.add(mesh)
        for index, material in enumerate(mesh.materials):
            if material is None:
                continue
            if material not in materials:
                copied = material.copy()
                if copied.node_tree:
                    trees[material.node_tree] = copied.node_tree
                    for node in copied.node_tree.nodes:
                        if node.type == 'GROUP' and node.node_tree:
                            node.node_tree = copy_tree(node.node_tree, trees)
                materials[material] = copied
            mesh.materials[index] = materials[material]
    # Cross-material and group driver variables must reference the corresponding
    # private copies, rather than retaining controls from the original shaders.
    copies = {**materials, **trees}
    remap_owned_references(set(copies.values()), copies)


def use_target_materials(source, target):
    """Adopt the donor's slots and face assignments on the isolated source mesh."""
    materials = list(target.data.materials)
    indices = [polygon.material_index for polygon in target.data.polygons]
    source.data.materials.clear()
    for material in materials:
        source.data.materials.append(material)
    source.data.polygons.foreach_set('material_index', indices)
    source.active_material_index = target.active_material_index
    for slot in source.material_slots:
        slot.link = 'DATA'


def _shader_group_matches(node, token):
    return (node.type == 'GROUP' and node.node_tree
            and any(token in value for value in (node.name, node.label, node.node_tree.name)))


def capture_source_shader_layers(source):
    """Keep the authored final layer stack before replacing the body's shaders."""
    face = next((mat for mat in source.data.materials
                 if mat and 'Genesis 8 Female_Face' in mat.name and mat.node_tree), None)
    if face:
        for layers in group_nodes(face.node_tree):
            if _shader_group_matches(layers, '(HHP)_Shader Layers'):
                final = next((node for node in group_nodes(layers.node_tree)
                              if _shader_group_matches(node, '(HHP) Shader Layer_FINAL')), None)
                if final:
                    return final.node_tree, source.data, source.data.shape_keys
    return None


def restore_source_shader_layers(source, saved):
    """Put private source layer trees into the copied target shader layout."""
    if saved is None:
        return
    original, old_mesh, old_keys = saved
    final_nodes = set()
    for mat in source.data.materials:
        if not mat or not mat.node_tree:
            continue
        for layers in group_nodes(mat.node_tree):
            if _shader_group_matches(layers, '(HHP)_Shader Layers'):
                final_nodes.update(node for node in group_nodes(layers.node_tree)
                                   if _shader_group_matches(node, '(HHP) Shader Layer_FINAL'))
    if not final_nodes:
        return
    copies = {}
    copied = copy_tree(original, copies)
    replacements = {**copies, old_mesh: source.data}
    if old_keys and source.data.shape_keys:
        replacements[old_keys] = source.data.shape_keys
    remap_owned_references(set(copies.values()), replacements)
    for node in final_nodes:
        node.node_tree = copied


def isolate_geometry(objects):
    objects = set(objects)
    for mesh in {obj.data for obj in objects if getattr(obj, 'data', None) is not None}:
        if any(obj not in objects and getattr(obj, 'data', None) == mesh for obj in bpy.data.objects):
            copied = mesh.copy()
            for obj in objects:
                if getattr(obj, 'data', None) == mesh:
                    obj.data = copied


def remove_source_delta_correctives(source):
    """Discard old corrective geometry and animation before importing replacements."""
    keys = source.data.shape_keys
    if keys is None:
        return
    obsolete = [key for key in keys.key_blocks if 'DeltaCorrective_' in key.name]
    if not obsolete:
        return
    # Blender removes a deleted key's drivers, but leaves its action curves behind.
    # Those curves would animate a same-named replacement with the old identity.
    prefixes = tuple(key.path_from_id() + '.' for key in obsolete)
    if keys.animation_data:
        _isolate_actions(keys)
        animation = keys.animation_data
        owners = [animation] + [strip for track in animation.nla_tracks for strip in track.strips]
        for owner in owners:
            action = getattr(owner, 'action', None)
            if action is None:
                continue
            if getattr(action, 'is_action_layered', False):
                collections = [bag.fcurves for layer in action.layers for strip in layer.strips
                               for bag in strip.channelbags
                               if bag.slot_handle == owner.action_slot_handle]
            else:
                collections = [action.fcurves]
            for curves in collections:
                for curve in list(curves):
                    if curve.data_path.startswith(prefixes):
                        curves.remove(curve)
    # Snapshot first: removing a key mutates key_blocks and its drivers.
    for key in obsolete:
        source.shape_key_remove(key)


def selector_kind(node):
    tree = getattr(node, 'node_tree', None)
    if tree:
        return next((token for token in _SELECTORS if token.casefold() in tree.name.casefold()), None)
    return None


def material_role(material):
    name = material.name.casefold()
    return next((role for role in ('fingernails', 'toenails', 'face', 'torso', 'arms', 'legs', 'teeth', 'mouth')
                 if role in name), re.sub(r'\.\d+$', '', name))


def group_nodes(tree, visited=None):
    visited = set() if visited is None else visited
    if tree is None or tree in visited:
        return
    visited.add(tree)
    for node in tree.nodes:
        if node.type == 'GROUP' and node.node_tree:
            yield node
            yield from group_nodes(node.node_tree, visited)


def selector_plan(source, target):
    donors, unique = {}, {}
    for mat in target.data.materials:
        if mat is None:
            continue
        for node in group_nodes(mat.node_tree):
            kind = selector_kind(node)
            if kind:
                donors.setdefault((material_role(mat), kind), []).append(node)
                unique.setdefault(kind, []).append(node)
    result = []
    for mat in source.data.materials:
        if mat is None:
            continue
        for node in group_nodes(mat.node_tree):
            kind = selector_kind(node)
            if not kind:
                continue
            choices = donors.get((material_role(mat), kind), [])
            if not choices:
                choices = unique.get(kind, [])
            distinct = {candidate.node_tree for candidate in choices}
            if len(distinct) != 1:
                raise TransferError(f'Cannot uniquely match target {kind} for material {mat.name}')
            result.append((node, choices[0]))
    return result


def isolate_donor_groups(source, target):
    """Keep directly transferred auxiliary groups private before driver remapping."""
    donor_trees = {node.node_tree for material in target.data.materials if material
                   for node in group_nodes(material.node_tree)}
    copies, visited = {}, set()

    def visit(tree):
        if tree is None or tree in visited:
            return
        visited.add(tree)
        for node in tree.nodes:
            if node.type != 'GROUP' or not node.node_tree:
                continue
            if node.node_tree in donor_trees:
                node.node_tree = copy_tree(node.node_tree, copies)
            else:
                visit(node.node_tree)

    for material in source.data.materials:
        if material:
            visit(material.node_tree)


def _socket(sockets, name, index):
    matching = [socket for socket in sockets if socket.name == name]
    if len(matching) == 1:
        return matching[0]
    return sockets[index] if index < len(sockets) else None


def _peer(tree, node):
    base = re.sub(r'\.\d+$', '', node.name)
    exact = tree.nodes.get(node.name)
    if exact and exact.type == node.type:
        return exact
    matches = [n for n in tree.nodes if n.type == node.type and re.sub(r'\.\d+$', '', n.name) == base]
    if len(matches) == 1:
        return matches[0]
    if node.type == 'GROUP' and node.node_tree:
        base = re.sub(r'\.\d+$', '', node.node_tree.name)
        matches = [n for n in tree.nodes if n.type == 'GROUP' and n.node_tree
                   and re.sub(r'\.\d+$', '', n.node_tree.name) == base]
        if len(matches) == 1:
            return matches[0]
    return None


def replace_selectors(source, target):
    copies = {}
    for node, donor in selector_plan(source, target):
        tree = node.id_data
        links = []
        for link in list(tree.links):
            if link.to_node == node:
                links.append(('IN', link.from_socket, link.to_socket.name, list(node.inputs).index(link.to_socket)))
            elif link.from_node == node:
                links.append(('OUT', link.to_socket, link.from_socket.name, list(node.outputs).index(link.from_socket)))
        node.node_tree = copy_tree(donor.node_tree, copies)
        for direction, peer_socket, name, index in links:
            socket = _socket(node.inputs if direction == 'IN' else node.outputs, name, index)
            if socket:
                tree.links.new(peer_socket, socket) if direction == 'IN' else tree.links.new(socket, peer_socket)
        for index, socket in enumerate(donor.inputs):
            other = _socket(node.inputs, socket.name, index)
            if other is not None and hasattr(socket, 'default_value') and hasattr(other, 'default_value'):
                other.default_value = socket.default_value
        # Include donor texture branches that were absent from the old interface.
        for link in donor.id_data.links:
            if link.from_node != donor:
                continue
            peer = _peer(tree, link.to_node)
            if peer is None:
                continue
            output = _socket(node.outputs, link.from_socket.name, list(donor.outputs).index(link.from_socket))
            input_socket = _socket(peer.inputs, link.to_socket.name, list(link.to_node.inputs).index(link.to_socket))
            if output is not None and input_socket is not None:
                tree.links.new(output, input_socket)
    return len(copies)


def move_assets(source, target, source_root, target_root, material_versions=None):
    """Move target assets before consolidating folders and resolving duplicates."""
    roots = assets.asset_roots(target)
    moved_objects = {obj for coll in roots for obj in coll.all_objects}
    isolate_geometry(moved_objects)
    isolate_materials(moved_objects)
    if material_versions:
        shader_versions.remap(moved_objects, armature(source), armature(target), *material_versions)
    data.remove_pubic_hair_drivers(roots)
    # Keep donor asset deformers until the analyzer's explicit choices are applied.
    data.apply_remapping_to_collections(list(roots), target, source, data.get_surface_deform_target(source),
                                       {obj.as_pointer() for obj in moved_objects})
    donor_tree = collection_tree(target_root)
    for coll in roots:
        if coll.name not in source_root.children:
            source_root.children.link(coll)
        for parent in donor_tree:
            if coll.name in parent.children:
                parent.children.unlink(coll)
    return moved_objects


def remap_character_references(source_root, source, target):
    """Retarget copied/moved data while preserving all external users."""
    replacements = {target: source, target.data: source.data}
    source_arm, target_arm = armature(source), armature(target)
    if source_arm and target_arm and source_arm != target_arm:
        replacements.update({target_arm: source_arm, target_arm.data: source_arm.data})
    if target.data.shape_keys and source.data.shape_keys:
        replacements[target.data.shape_keys] = source.data.shape_keys
    owners = set(source_root.all_objects)
    for obj in list(owners):
        mesh = getattr(obj, 'data', None)
        if mesh:
            owners.add(mesh)
        if getattr(mesh, 'shape_keys', None):
            owners.add(mesh.shape_keys)
        for mat in getattr(mesh, 'materials', ()):
            if mat:
                owners.add(mat)
                if mat.node_tree:
                    owners.add(mat.node_tree)
                    owners.update(node.node_tree for node in group_nodes(mat.node_tree))
    remap_owned_references(owners, replacements)


def validate_pair(context, action, material_mode='TARGET', proportion_mode='SOURCE'):
    from ..Customize_HHP import find_character_hhp_collection
    source = context.active_object
    selected = list(context.selected_objects)
    if context.mode != 'OBJECT' or source not in selected or len(selected) != 2:
        raise TransferError('Select exactly two HHP body meshes in Object Mode; the active source receives the identity')
    if any(not hhp_naming.is_char_mesh(obj) for obj in selected):
        raise TransferError('Select two HHP character body meshes')
    target = next(obj for obj in selected if obj != source)
    source_root, target_root = (find_character_hhp_collection(obj) for obj in (source, target))
    if not source_root or not target_root or source_root == target_root:
        raise TransferError('The characters need separate HHP character collections')
    source_tree, target_tree = collection_tree(source_root), collection_tree(target_root)
    if source_tree & target_tree or set(source_root.all_objects) & set(target_root.all_objects):
        raise TransferError('Source and target character hierarchies must not share objects or collections')
    if any(len(getattr(source.data, attr)) != len(getattr(target.data, attr))
           for attr in ('vertices', 'edges', 'loops', 'polygons')):
        raise TransferError('The two HHP meshes must have matching topology')
    editable = source_tree | target_tree | set(source_root.all_objects) | set(target_root.all_objects)
    if any(not item.is_editable for item in editable):
        raise TransferError('Make both characters and their collections local/editable before transferring')
    if not source.data.is_editable or not target.data.is_editable:
        raise TransferError('Both character meshes must be editable')
    if source.data.shape_keys and not source.data.shape_keys.is_editable:
        raise TransferError('The source shape keys must be editable')
    if armature(source) and armature(target) == armature(source):
        raise TransferError('The two characters must use separate armatures')
    if action == 'DELETE':
        # Collection deletion is limited to this character, never shared scene data.
        for obj in target_root.all_objects:
            if any(coll not in target_tree for coll in obj.users_collection):
                raise TransferError('Target objects are also linked outside its character; choose None or Disable')
        if any(coll.name in parent.children for coll in target_tree if coll != target_root
               for parent in bpy.data.collections if parent not in target_tree):
            raise TransferError('Target child collections are shared; choose None or Disable')
        if any(target_tree & collection_tree(scene.collection)
               for scene in bpy.data.scenes if scene != context.scene):
            raise TransferError('The target is also used in another scene; choose None or Disable')
    data._preflight_hhp5_asset_weight_renames(context)
    source_arm, target_arm = armature(source), armature(target)
    if proportion_mode == 'TARGET' and source_arm and target_arm:
        proportion_transfer_plan(target_arm, source_arm, capture_proportions(target_arm))
    # Inspect stored DATA materials, including when optimized object overrides are active.
    if material_mode == 'SOURCE':
        selector_plan(source, target)
    else:
        incoming_shaders = {target} | {obj for coll in assets.asset_roots(target) for obj in coll.all_objects}
        shader_versions.remap(incoming_shaders, source_arm, target_arm,
                              shader_versions.version(source), shader_versions.version(target), check_only=True)
    return source, target, source_root, target_root


def transfer(context, operator):
    from .. import Customize_HHP as presets
    operator._optimized_refresh_state = None
    source, target, source_root, target_root = validate_pair(
        context, operator.target_collection_action, operator.material_mode, operator.proportion_mode)
    replacements = assets.preflight(operator, source, target, source_root, target_root)
    optimized_state = optimized_materials.capture_state(source) if operator.update_optimized_materials else None
    material_versions = ((shader_versions.version(source), shader_versions.version(target))
                         if operator.material_mode == 'TARGET' else None)
    source_shader_layers = capture_source_shader_layers(source) if material_versions else None
    # DATA materials are HHP's original shaders; OBJECT slots hold optimized proxies.
    prepare_transfer_materials([(source, target)], context)
    for body in (source, target):
        ensure_original_preset(context, body)
    if operator.update_source_shapekeys:
        prepare_source_shape_keys([source])
    isolate_geometry(source_root.all_objects)
    remove_source_delta_correctives(source)
    source_mouth = ([key for key in source.data.shape_keys.key_blocks if is_hhp_mouth_shape_key(key.name)]
                    if source.data.shape_keys else [])
    mouth_winner = max(source_mouth, key=lambda key: key.value, default=None)
    preserved_mouth = (mouth_winner.name, mouth_winner.value) if mouth_winner else (None, 0.0)
    if operator.material_mode == 'TARGET':
        use_target_materials(source, target)
    isolate_materials(source_root.all_objects)
    if material_versions:
        shader_versions.remap([source], armature(source), armature(target), *material_versions)
        restore_source_shader_layers(source, source_shader_layers)
    identity_values = {key.name: key.value for key in target.data.shape_keys.key_blocks
                       if is_identity_shape(key.name)} if target.data.shape_keys else {}
    for key in source.data.shape_keys.key_blocks if source.data.shape_keys else ():
        if is_identity_shape(key.name):
            identity_values.setdefault(key.name, 0.0)
    active_target = getattr(target, 'active_preset', 'NONE')
    merged, labels, target_names, next_id = merge_presets(source, target, identity_values)
    outfits = {}
    for new_name, preset in zip(merged, source.get('presets', {}).values()):
        outfits[new_name] = resolve_outfit(preset, source_root)
    source_presets = list(outfits)
    for old, preset in target.get('presets', {}).items():
        outfits[target_names[old]] = resolve_outfit(preset, target_root)
    current_outfit = resolve_outfit({'collections': presets.capture_outfit_preset(context)}, source_root)
    with context.temp_override(active_object=target, object=target):
        current_outfit.update(resolve_outfit({'collections': presets.capture_outfit_preset(context)}, target_root))
    outfit_roots = set(_outfit_roots(source_root)) | set(_outfit_roots(target_root))
    # Shared folders cannot retain contradictory visibility flags. Record what each
    # member actually shows before merging, including hidden parent collections.
    outfits = {name: assets.effective_states(outfit_roots, states) for name, states in outfits.items()}
    current_outfit = assets.effective_states(outfit_roots, current_outfit)
    assets.apply_target_hair_eyes(source, target, source_presets, outfits, current_outfit)
    collection_roots = assets.asset_roots(source) | assets.asset_roots(target)
    source_arm, target_arm = armature(source), armature(target)
    # This metadata belongs to the retained rig's existing smoothing drivers.
    proportion_properties = {'hhp5_root_modifier_scale'} if operator.proportion_mode == 'SOURCE' else ()
    data.transfer_identity_data(context, transfer_shader_data=operator.material_mode == 'SOURCE',
                                excluded_properties=proportion_properties)
    if operator.material_mode == 'SOURCE':
        isolate_donor_groups(source, target)
        replace_selectors(source, target)
    move_assets(source, target, source_root, target_root, material_versions)
    remap_character_references(source_root, source, target)
    if operator.proportion_mode == 'TARGET' and source_arm and target_arm:
        sync_proportions(target_arm, source_arm)
    collection_aliases = assets.consolidate(source_root, collection_roots)
    aliases = {**collection_aliases, **replacements}
    outfits = {name: assets.remap_states(states, aliases) for name, states in outfits.items()}
    current_outfit = assets.remap_states(current_outfit, aliases)
    assets.replace_objects(source_root, replacements)
    for coll in collection_aliases:
        bpy.data.collections.remove(coll)
    for name, preset in merged.items():
        preset['collections'] = complete_outfit(source_root, outfits[name])
    if operator.preserve_hhp_source_mouth_shape and operator.update_mouth_shape_in_presets:
        winner_name, winner_value = preserved_mouth
        update_presets_mouth_shapes(
            merged, {key.name: winner_value if key.name == winner_name else 0.0
                     for key in source.data.shape_keys.key_blocks
                     if is_hhp_mouth_shape_key(key.name)} if source.data.shape_keys else {})
    source['presets'] = merged
    source[_NAME_METADATA] = json.dumps(labels, ensure_ascii=False)
    source[_NEXT_ID] = next_id
    if active_target in target_names:
        source.active_preset = target_names[active_target]
    else:
        # A character without an active saved preset still supplies its live identity.
        presets.apply_outfit_preset(complete_outfit(source_root, current_outfit), source)
    if operator.preserve_hhp_source_mouth_shape and source.data.shape_keys:
        winner_name, winner_value = preserved_mouth
        for key in source.data.shape_keys.key_blocks:
            if is_hhp_mouth_shape_key(key.name):
                value = winner_value if key.name == winner_name else 0.0
                key.slider_min = min(key.slider_min, value)
                key.slider_max = max(key.slider_max, value)
                key.value = value
        source.data.shape_keys.update_tag()
        source.update_tag()
    optimized_updated = True
    if optimized_state is not None:
        try:
            context.view_layer.update()
            optimized_materials.refresh(context, [source])
            optimized_materials.set_state(source, optimized_state)
            # Use the full normals update independently of the restored material
            # display state, including newly transferred outfit shader trees.
            from . import use_optimized_normals_node as normals
            if (hasattr(context.scene, normals.PROP_NAME)
                    and not getattr(context.scene, normals.PROP_NAME)):
                setattr(context.scene, normals.PROP_NAME, True)
            else:
                normals.apply_use_optimized_normals(True)
            operator._optimized_refresh_state = optimized_state
        except (RuntimeError, ValueError, TypeError) as error:
            optimized_updated = False
            optimized_materials.set_state(source, False)
            operator.report({'WARNING'}, f'Identity transferred; target collection kept because optimized materials could not be updated: {error}')
    if optimized_updated and operator.target_collection_action == 'DISABLE':
        target_root.hide_viewport = True
        target_root.hide_render = True
    elif optimized_updated and operator.target_collection_action == 'DELETE':
        for obj in list(target_root.all_objects):
            bpy.data.objects.remove(obj, do_unlink=True)
        for coll in collection_tree(target_root):
            bpy.data.collections.remove(coll)
        purge_transfer_orphans(operator)
    for obj in list(context.selected_objects):
        obj.select_set(False)
    source.select_set(True)
    context.view_layer.objects.active = source
    context.view_layer.update()
    return len(merged)


class HHP_OT_identity_transfer(bpy.types.Operator):
    bl_idname = 'hhp.identity_transfer'
    bl_label = 'HHP Identity Transfer'
    bl_description = "Apply the selected target character's identity to the active source while preserving both characters' presets"
    bl_options = {'REGISTER', 'UNDO'}

    append_filepath: StringProperty(
        name='Identity Character File',
        description='Library character to append after confirming the identity transfer options',
        subtype='FILE_PATH',
        default='',
        options={'HIDDEN', 'SKIP_SAVE'},
    )
    append_source_mesh: StringProperty(
        name='Identity Source Mesh',
        description='Existing HHP character that receives the appended identity',
        default='',
        options={'HIDDEN', 'SKIP_SAVE'},
    )

    update_source_shapekeys: BoolProperty(
        name='Update source shapekeys to new standard',
        description='Rename legacy source shape keys and their preset references before transferring the identity',
        default=True,
    )
    update_optimized_materials: BoolProperty(
        name='Update Optimized Materials',
        description="Rebuild optimized materials and update normals after transfer. Keep the source's previous optimized materials setting and always leave optimized normals on",
        default=True,
    )
    preserve_hhp_source_mouth_shape: BoolProperty(
        name='Preserve HHP source mouth shape',
        description='After transfer, retain the source mouth preset with the highest source value and zero other mouth presets on the resulting character',
        default=False,
    )
    update_mouth_shape_in_presets: BoolProperty(
        name='Update in presets',
        description='Save the preserved source mouth values in all retained source and target presets; applies only when preserving the source mouth shape',
        default=True,
    )
    material_mode: EnumProperty(
        name='Materials',
        description='Choose which character supplies the resulting body materials',
        items=[
            ('SOURCE', 'Keep Source Materials', 'Keep the source shaders and update their identity texture selectors from the target', 'MATERIAL', 0),
            ('TARGET', 'Keep Target Materials', 'Replace source materials with independent copies of the target shaders and retarget their drivers to the source mesh and armature', 'MATERIAL_DATA', 1),
        ],
        default='TARGET',
    )
    proportion_mode: EnumProperty(
        name='Proportions',
        description='Choose which character supplies the rig proportion distribution',
        items=[
            ('SOURCE', 'Keep Source Proportions', 'Preserve the active source rig proportion distribution', 'ARMATURE_DATA', 0),
            ('TARGET', 'Keep Target Proportions', 'Copy the selected target rig proportion distribution onto the active source', 'CON_SIZELIMIT', 1),
        ],
        default='SOURCE',
    )
    asset_clashes: CollectionProperty(type=assets.HHP_IdentityAssetClash, options={'HIDDEN', 'SKIP_SAVE'})
    asset_clashes_ready: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})
    target_collection_action: EnumProperty(
        name='Target collection action',
        description='What to do with the remaining target character collection after its assets and identity transfer',
        items=[('NONE', 'None', 'Keep the remaining target collection', 'OUTLINER_COLLECTION', 0),
               ('DISABLE', 'Disable', 'Hide the remaining target collection in the viewport and renders', 'HIDE_ON', 1),
               ('DELETE', 'Delete', 'Delete the remaining target collection after transferring its assets', 'TRASH', 2)],
        default='DELETE',
    )

    purge_orphans_after_delete: BoolProperty(
        name='Purge Orphans after delete',
        description='Recursively remove unused local and linked data from the blend file after collection deletion; data still in use or marked with a fake user is kept',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and hhp_naming.is_char_mesh(context.active_object)

    @classmethod
    def description(cls, context, properties):
        if properties.append_filepath:
            return 'Choose Identity Transfer options, then append the library character and apply its identity to the active source'
        return cls.bl_description

    def invoke(self, context, event):
        try:
            # Shader matching is validated at execution so either mode remains selectable.
            if self.append_filepath:
                self.append_source_mesh = context.active_object.name
                self._validate_append_source(context)
            else:
                validate_pair(context, 'NONE', 'TARGET')
            self.asset_clashes.clear()
            self.asset_clashes_ready = False
        except (TransferError, ValueError) as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        return context.window_manager.invoke_props_dialog(self, width=510)

    def _validate_append_source(self, context):
        from pathlib import Path
        source = bpy.data.objects.get(self.append_source_mesh)
        if (context.mode != 'OBJECT' or not hhp_naming.is_char_mesh(source)
                or source.name not in context.view_layer.objects):
            raise TransferError('The source HHP character is no longer available in Object Mode')
        if not Path(bpy.path.abspath(self.append_filepath)).is_file():
            raise TransferError('The selected character file is no longer available')
        return source

    def draw(self, context):
        col = self.layout.column(align=True)
        col.label(text='Active source receives the selected target identity', icon='USER')
        col.prop(self, 'update_source_shapekeys')
        col.prop(self, 'update_optimized_materials')
        mouth_row = col.row(align=True)
        mouth_row.prop(self, 'preserve_hhp_source_mouth_shape')
        mouth_presets = mouth_row.row(align=True)
        mouth_presets.enabled = self.preserve_hhp_source_mouth_shape
        mouth_presets.prop(self, 'update_mouth_shape_in_presets')
        col.label(text='Materials:', icon='MATERIAL')
        col.row(align=True).prop(self, 'material_mode', expand=True)
        col.label(text='Proportions:', icon='ARMATURE_DATA')
        col.row(align=True).prop(self, 'proportion_mode', expand=True)
        col.label(text='Target collection action:', icon='OUTLINER_COLLECTION')
        col.row(align=True).prop(self, 'target_collection_action', expand=True)
        purge_row = col.row()
        purge_row.enabled = self.target_collection_action == 'DELETE'
        purge_row.prop(self, 'purge_orphans_after_delete')
        if self.target_collection_action == 'DELETE':
            col.label(text='The remaining target collection will be deleted.', icon='TRASH')

    def execute(self, context):
        optimized_pending.clear('identity')
        try:
            if self.append_filepath:
                from .. import _append_swap_character_target
                source = self._validate_append_source(context)
                result = _append_swap_character_target(
                    context, source, bpy.path.abspath(self.append_filepath), self)
                if result != {'FINISHED'}:
                    return result
            count = transfer(context, self)
        except (TransferError, RuntimeError, ValueError, KeyError) as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        clash_ui.open_after_transfer(context, context.active_object,
                                     [item for item in self.asset_clashes if item.source_obj and item.target_obj],
                                     optimized_state=getattr(self, '_optimized_refresh_state', None))
        self.report({'INFO'}, f'Identity transferred; {count} presets retained')
        return {'FINISHED'}


def register():
    from . import append_identity_transfer
    assets.register()
    clash_ui.register()
    bpy.utils.register_class(HHP_OT_identity_transfer)
    append_identity_transfer.register()


def unregister():
    from . import append_identity_transfer
    append_identity_transfer.unregister()
    bpy.utils.unregister_class(HHP_OT_identity_transfer)
    clash_ui.unregister()
    assets.unregister()
