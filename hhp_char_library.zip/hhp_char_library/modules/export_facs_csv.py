import bpy
import csv
import os

from bpy_extras.io_utils import ExportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty
from ..modules.import_facs_csv import CUSTOM_52_MAPPING

# Mouth-only shapekeys list
MOUTH_SHAPEKEYS = [
    "jawForward",
    "jawLeft",
    "jawRight",
    "jawOpen",
    "mouthClose",
    "mouthFunnel",
    "mouthPucker",
    "mouthLeft",
    "mouthRight",
    "mouthSmileLeft",
    "mouthSmileRight",
    "mouthFrownLeft",
    "mouthFrownRight",
    "mouthDimpleLeft",
    "mouthDimpleRight",
    "mouthStretchLeft",
    "mouthStretchRight",
    "mouthRollLower",
    "mouthRollUpper",
    "mouthShrugLower",
    "mouthShrugUpper",
    "mouthPressLeft",
    "mouthPressRight",
    "mouthLowerDownLeft",
    "mouthLowerDownRight",
    "mouthUpperUpLeft",
    "mouthUpperUpRight",
    "cheekPuff",
    "tongueOut"
]

class HHP_OT_Export_FACS_CSV(bpy.types.Operator, ExportHelper):
    """Export the active shapekey action to a CSV file"""
    bl_idname = "hhp.export_facs_csv"
    bl_label = "Export FACS to CSV"
    bl_options = {'PRESET'}

    filename_ext = ".csv"
    filter_glob: StringProperty(default="*.csv", options={'HIDDEN'})

    export_mode: EnumProperty(
        name="Export Mode",
        description="Select which shapekeys to export",
        items=[
            ('FULL', "Full Face", "Export full shapekey animation"),
            ('MOUTH_ONLY', "Lip Sync Only", "Export only mouth-related shapekey animation")
        ],
        default='FULL'
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.data.shape_keys or not obj.data.shape_keys.animation_data or not obj.data.shape_keys.animation_data.action:
            self.report({'ERROR'}, "No active shapekey action on the active mesh.")
            return {'CANCELLED'}

        action = obj.data.shape_keys.animation_data.action
        
        frame_start = int(action.frame_range[0])
        frame_end = int(action.frame_range[1])
        
        facs_data = {}
        shapekey_order = []
        
        # Create a reverse mapping to get the CSV header names
        reverse_mapping = {v: k for k, v in CUSTOM_52_MAPPING.items()}

        for fcurve in action.fcurves:
            if 'key_blocks' in fcurve.data_path and '.value' in fcurve.data_path:
                shapekey_name = fcurve.data_path.split('"')[1]

                if self.export_mode == 'MOUTH_ONLY' and shapekey_name not in MOUTH_SHAPEKEYS:
                    continue

                if shapekey_name not in facs_data:
                    shapekey_order.append(shapekey_name)
                    facs_data[shapekey_name] = {}
                for keyframe in fcurve.keyframe_points:
                    frame = int(keyframe.co.x)
                    value = keyframe.co.y
                    facs_data[shapekey_name][frame] = value
        
        if not shapekey_order:
            self.report({'ERROR'}, "No shapekeys to export for the selected mode.")
            return {'CANCELLED'}

        # Use the reverse mapping to create the header
        header = ['Timecode'] + [reverse_mapping.get(sk, sk) for sk in shapekey_order]
        header[0] = f"Timecode, FPS={context.scene.render.fps}"


        with open(self.filepath, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(header)

            for frame in range(frame_start, frame_end + 1):
                timecode = f"00:00:{frame/context.scene.render.fps:06.3f}".replace('.', ':')
                row = [timecode]
                for shapekey_name in shapekey_order:
                    value = facs_data[shapekey_name].get(frame, 0.0)
                    row.append(value)
                writer.writerow(row)

        self.report({'INFO'}, f"Exported to {self.filepath}")
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.prop(self, "export_mode", expand=True)

def register():
    bpy.utils.register_class(HHP_OT_Export_FACS_CSV)

def unregister():
    bpy.utils.unregister_class(HHP_OT_Export_FACS_CSV)
