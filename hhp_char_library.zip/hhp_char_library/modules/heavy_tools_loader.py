"""Safe discovery and registration for optional HHP heavy tools."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from types import ModuleType
from typing import Optional


_ADDON_PACKAGE = __package__.rsplit(".modules", 1)[0]
_TOOL_PACKAGE = f"{_ADDON_PACKAGE}._heavy_audio_to_mocap"
_TOOL_DIRECTORY = Path(__file__).resolve().parent.parent / "heavy_tools" / "Audio to mocap"
_TOOL_ENTRY = _TOOL_DIRECTORY / "__init__.py"

_tool_module: Optional[ModuleType] = None
_tool_registered = False
_load_error = ""


def _discard_loaded_package() -> None:
    """Remove only this optional tool's dynamically loaded modules."""
    prefix = f"{_TOOL_PACKAGE}."
    for module_name in tuple(sys.modules):
        if module_name == _TOOL_PACKAGE or module_name.startswith(prefix):
            sys.modules.pop(module_name, None)


def _load_tool() -> Optional[ModuleType]:
    """Load the optional package without making it a hard addon dependency."""
    global _tool_module, _load_error

    if _tool_module is not None:
        return _tool_module
    if not _TOOL_ENTRY.is_file():
        _load_error = ""
        return None

    try:
        spec = importlib.util.spec_from_file_location(
            _TOOL_PACKAGE,
            str(_TOOL_ENTRY),
            submodule_search_locations=[str(_TOOL_DIRECTORY)],
        )
        if spec is None or spec.loader is None:
            raise ImportError("Could not create the Audio to mocap module specification")

        module = importlib.util.module_from_spec(spec)
        sys.modules[_TOOL_PACKAGE] = module
        spec.loader.exec_module(module)

        availability_check = getattr(module, "is_available", None)
        if not callable(availability_check) or not availability_check():
            reason_getter = getattr(module, "get_unavailable_reason", None)
            _load_error = reason_getter() if callable(reason_getter) else "Required processing assets are missing"
            _discard_loaded_package()
            return None

        _tool_module = module
        _load_error = ""
        return module
    except Exception as exc:
        _load_error = str(exc)
        _tool_module = None
        _discard_loaded_package()
        print(f"HHP optional Audio to mocap tool is unavailable: {exc}")
        return None


def register() -> None:
    """Register the audio tool when its complete optional package is present."""
    global _tool_registered, _load_error

    module = _load_tool()
    if module is None or _tool_registered:
        return

    try:
        module.register()
        _tool_registered = True
    except Exception as exc:
        _load_error = str(exc)
        _tool_registered = False
        cleanup = getattr(module, "unregister", None)
        if callable(cleanup):
            try:
                cleanup()
            except Exception:
                pass
        print(f"HHP optional Audio to mocap tool could not register: {exc}")


def unregister() -> None:
    """Unregister the optional tool without affecting the main addon."""
    global _tool_module, _tool_registered, _load_error

    module = _tool_module
    if module is not None and _tool_registered:
        try:
            module.unregister()
        except Exception as exc:
            print(f"HHP optional Audio to mocap tool could not unregister cleanly: {exc}")

    _tool_registered = False
    _tool_module = None
    _load_error = ""
    _discard_loaded_package()


def is_audio_mocap_available() -> bool:
    """Return whether the audio importer is registered and safe to draw."""
    return _tool_registered and _tool_module is not None


def is_audio_mocap_model_loaded() -> bool:
    """Return whether this tool currently holds processing models in memory."""
    if not is_audio_mocap_available():
        return False
    checker = getattr(_tool_module, "is_model_loaded", None)
    try:
        return bool(checker()) if callable(checker) else False
    except Exception:
        return False


def get_audio_mocap_load_error() -> str:
    """Return a diagnostic reason without exposing unavailable UI controls."""
    return _load_error
