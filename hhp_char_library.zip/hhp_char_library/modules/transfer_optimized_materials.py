"""Refresh transfer recipients' material proxies and normal nodes without global toggles."""
from pathlib import Path
from contextlib import contextmanager

import bpy

PROXY_PREFIX = '(BS)_Proxy_'
NORMAL_GROUP = 'Normal Map Optimized'


def capture_state(mesh):
    """Match the HHP optimized-material toggle: every material slot uses Object."""
    return bool(mesh and mesh.type == 'MESH' and mesh.material_slots
                and all(slot.link == 'OBJECT' for slot in mesh.material_slots))


def set_state(mesh, enabled):
    """Show rebuilt proxies or original shaders without changing other meshes."""
    if mesh and mesh.type == 'MESH':
        for slot in mesh.material_slots:
            slot.link = 'OBJECT' if enabled else 'DATA'


def _normal_group():
    for group in bpy.data.node_groups:
        if (NORMAL_GROUP in group.name and not group.name.startswith(PROXY_PREFIX)
                and group.bl_idname == 'ShaderNodeTree'):
            return group
    library = Path(__file__).resolve().parents[1] / 'assets' / 'transfer_optimized_normals.blend'
    if not library.is_file():
        raise RuntimeError('The optimized normals asset is missing; reinstall the add-on assets')
    with bpy.data.libraries.load(str(library), link=False) as (available, requested):
        name = next((name for name in available.node_groups if NORMAL_GROUP in name), None)
        if name is None:
            raise RuntimeError('The optimized normals asset does not contain its shader group')
        requested.node_groups = [name]
    group = requested.node_groups[0]
    if group is None:
        raise RuntimeError('Could not load the optimized normals shader group')
    return group


def _trees(materials):
    seen, pending = set(), [material.node_tree for material in materials if material and material.node_tree]
    while pending:
        tree = pending.pop()
        pointer = tree.as_pointer()
        if pointer in seen:
            continue
        seen.add(pointer)
        yield tree
        pending.extend(node.node_tree for node in tree.nodes if node.type == 'GROUP' and node.node_tree)


def _normal_materials(meshes):
    materials = {material for mesh in meshes for material in mesh.data.materials if material}
    materials.update(slot.material for mesh in meshes for slot in mesh.material_slots if slot.material)
    return materials


@contextmanager
def preserve_node_animation(tree, node):
    """Protect exact node paths while Blender removes and recreates a shader node."""
    animation = tree.animation_data
    if animation is None:
        yield
        return
    prefix = node.path_from_id() + '.'
    curves = [curve for curve in animation.drivers if curve.data_path.startswith(prefix)]
    backup = bpy.data.node_groups.new('HHP Transfer Driver Backup', 'ShaderNodeTree') if curves else None
    bindings = []
    try:
        if backup:
            saved = backup.animation_data_create().drivers
            for curve in curves:
                saved.from_existing(src_driver=curve)
                animation.drivers.remove(curve)
        owners = [animation] + [strip for track in animation.nla_tracks for strip in track.strips]
        for owner in owners:
            action = getattr(owner, 'action', None)
            if action is not None:
                bindings.append((owner, action, getattr(owner, 'action_slot', None)))
                owner.action = None
        yield
    finally:
        for owner, action, slot in bindings:
            owner.action = action
            if slot is not None:
                owner.action_slot = slot
        if backup:
            for curve in backup.animation_data.drivers:
                animation.drivers.from_existing(src_driver=curve)
            bpy.data.node_groups.remove(backup)


def _replace_normal(tree, old, group):
    name, parent, location = old.name, old.parent, old.location.copy()
    new = tree.nodes.new('ShaderNodeGroup')
    new.node_tree = group
    new.parent = parent
    for field in ('label', 'select', 'mute', 'hide', 'width', 'use_custom_color', 'color'):
        setattr(new, field, getattr(old, field))
    new.location = location
    for before, after in zip(old.inputs, new.inputs):
        if hasattr(before, 'default_value') and hasattr(after, 'default_value'):
            after.default_value = before.default_value
        for link in list(before.links):
            tree.links.new(link.from_socket, after)
    for before, after in zip(old.outputs, new.outputs):
        for link in list(before.links):
            tree.links.new(after, link.to_socket)
    with preserve_node_animation(tree, old):
        tree.nodes.remove(old)
        # Assign after deletion: Blender otherwise enumerates the replacement's
        # name, invalidating driver and action paths addressing the original.
        new.name = name


def _optimize_normals(materials, group):
    for tree in list(_trees(materials)):
        if tree == group:
            continue
        for node in list(tree.nodes):
            if node.type == 'NORMAL_MAP':
                _replace_normal(tree, node, group)


def _clear_local_proxies(meshes):
    """Remove hidden Object overrides and only their newly orphaned proxy data."""
    retired, candidates = set(), set()
    for mesh in meshes:
        for slot in mesh.material_slots:
            slot.link = 'OBJECT'
            material = slot.material
            if material and material.name.startswith(PROXY_PREFIX):
                retired.add(material)
                candidates.update(tree.as_pointer() for tree in _trees([material]))
            slot.material = None
            slot.link = 'DATA'
    for material in retired:
        material.use_fake_user = False
        if material.users == 0:
            bpy.data.materials.remove(material)
    while True:
        orphaned = [tree for tree in bpy.data.node_groups if tree.as_pointer() in candidates
                    and tree.name.startswith(PROXY_PREFIX) and tree.users == 0]
        if not orphaned:
            break
        for tree in orphaned:
            bpy.data.node_groups.remove(tree)


def _freeze_proxy_trees(materials):
    """Freeze shader inputs without touching the clipboard or original trees."""
    for tree in _trees(materials):
        animation = tree.animation_data
        if animation:
            for curve in list(animation.drivers):
                animation.drivers.remove(curve)
            tree.animation_data_clear()
    for material in materials:
        material.animation_data_clear()
        material.use_fake_user = True


def _rebuild(meshes):
    # The two add-ons each use their own local implementation; neither requires
    # the other add-on to be installed or registered.
    if (Path(__file__).resolve().parents[1] / 'Optimize_HHP.py').is_file():
        from .. import Optimize_HHP as optimize
        optimize.hhp_clear_proxified_materials_from_objects(meshes, purge_unrelated_groups=False)
        optimize.hhp_proxify_materials(meshes)
    else:
        from . import proxify_materials as optimize
        _clear_local_proxies(meshes)
        for mesh in meshes:
            for material in mesh.data.materials:
                if material:
                    material.use_fake_user = True
        optimize.node_group_cache.clear()
        optimize.adjust_material_slots(meshes)
        optimize.process_materials(meshes)


def refresh(context, meshes):
    """Rebuild supplied recipients, then update their original and proxy normals.

    Returns None and raises on failure. Leaves successful recipients on Object
    links so the caller can restore each requested display state. Shared DATA
    material/node-tree links retain their existing sharing semantics.
    """
    meshes = tuple(dict.fromkeys(mesh for mesh in meshes
                                if mesh and mesh.type == 'MESH' and mesh.material_slots))
    if not meshes:
        return
    if any(not mesh.is_editable or not mesh.data.is_editable for mesh in meshes):
        raise ValueError('The transferred meshes must be editable to refresh optimized materials')
    group = _normal_group()  # Fail before clearing usable proxies if assets are unavailable.
    context.view_layer.update()  # Capture the final preset, mouth, and shader values.
    try:
        _rebuild(meshes)
        proxies = {slot.material for mesh in meshes for slot in mesh.material_slots
                   if slot.material and slot.material.name.startswith(PROXY_PREFIX)}
        _freeze_proxy_trees(proxies)
        _optimize_normals(_normal_materials(meshes), group)
        if hasattr(context.scene, 'hhp_use_optimized_normals'):
            # Store the status without invoking the global normal-replacement callback.
            context.scene['hhp_use_optimized_normals'] = True
        context.view_layer.update()
    except Exception:
        for mesh in meshes:
            set_state(mesh, False)
        context.view_layer.update()
        raise
