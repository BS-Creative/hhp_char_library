import bpy


def ensure_fcurve_for_datablock(action, datablock, data_path: str, index: int = 0):
    """
    Ensure an F-Curve exists for a datablock-aware action system (Blender 5 slotted actions),
    while remaining compatible with legacy Blender versions.

    Notes for Blender 5:
    - FCurves are stored in a slot/channelbag, not on action.fcurves.
    - Creation must be datablock-aware via Action.fcurve_ensure_for_datablock(...).
    - Blender requires the action to be assigned to the datablock before calling it.
      (The caller is responsible for ensuring that.)
    """
    if action is None:
        raise ValueError("action is None")

    # Blender 5: slotted actions API
    if hasattr(action, "fcurve_ensure_for_datablock"):
        if datablock is None:
            raise ValueError("datablock is None (required on Blender 5 slotted actions)")
        # Blender 5 enforces index to be passed as a keyword-only argument.
        return action.fcurve_ensure_for_datablock(datablock, data_path, index=index)

    # Legacy Blender: regular action.fcurves
    fcurve = action.fcurves.find(data_path, index=index)
    if fcurve is None:
        fcurve = action.fcurves.new(data_path=data_path, index=index)
    return fcurve


def iter_fcurves_for_anim_data(anim_data):
    """
    Iterate FCurves for the given anim_data, compatible with both legacy actions and
    Blender 5 slotted actions.
    """
    if anim_data is None:
        return

    action = getattr(anim_data, "action", None)
    if action is None:
        return

    # Legacy Blender: action.fcurves exists
    if hasattr(action, "fcurves"):
        for fcurve in action.fcurves:
            yield fcurve
        return

    # Blender 5: slotted actions. Curves live in a channelbag for the anim_data.action_slot.
    slot = getattr(anim_data, "action_slot", None)
    if slot is None:
        return

    try:
        from bpy_extras import anim_utils
        channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)
    except Exception:
        channelbag = None

    if channelbag is None:
        return

    fcurves = getattr(channelbag, "fcurves", None)
    if fcurves is None:
        return

    for fcurve in fcurves:
        yield fcurve


def set_fcurve_handles_auto_clamped(fcurve):
    """
    Force keyframe handles to Auto Clamped for smoother interpolation.
    This is a direct-data approach (not operator-based) so it works even when
    there's no Graph Editor context available.
    """
    if fcurve is None:
        return
    kps = getattr(fcurve, "keyframe_points", None)
    if not kps:
        return
    try:
        for kp in kps:
            kp.handle_left_type = 'AUTO_CLAMPED'
            kp.handle_right_type = 'AUTO_CLAMPED'
        # Ensure curve recalculates handles where applicable
        if hasattr(fcurve, "update"):
            fcurve.update()
    except Exception:
        # Fail gracefully if Blender changes handle semantics.
        pass


