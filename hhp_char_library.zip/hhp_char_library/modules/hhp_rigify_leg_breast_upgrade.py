"""Upgrade generated leg hinge axes and add independent breast controls."""
import json
import bpy
from mathutils import Matrix, Vector

RENAME = {'root': 'MCH-rigify-root', 'head': 'head_ctrl'}
REVISION = 60

def _name(name):
    return RENAME.get(name, name)

def _snapshot(arm, names):
    return {n: (tuple(v for row in arm.data.bones[n].matrix_local for v in row),
                arm.data.bones[n].length, arm.data.bones[n].parent.name if arm.data.bones[n].parent else None,
                arm.data.bones[n].use_deform, arm.data.bones[n].use_connect) for n in names}

def _driver(owner, path, arm, expression, variables):
    curve=owner.driver_add(path);driver=curve.driver;driver.type='SCRIPTED'
    for variable in list(driver.variables):driver.variables.remove(variable)
    for name,data_path in variables.items():
        variable=driver.variables.new();variable.name=name;variable.type='SINGLE_PROP'
        variable.targets[0].id=arm;variable.targets[0].data_path=data_path
    driver.expression=expression

def _constraint_fields(source, target, arm, prototype):
    for prop in source.bl_rna.properties:
        key=prop.identifier
        if key in {'rna_type','name','type','targets'} or prop.is_readonly:continue
        value=getattr(source,key)
        if isinstance(value,bpy.types.ID):value=arm if value==prototype else value
        elif key in {'subtarget','pole_subtarget','space_subtarget'}:value=_name(value)
        elif prop.type=='COLLECTION':continue
        try:setattr(target,key,value)
        except (AttributeError,TypeError,ValueError):pass

def _copy_driver(source, target):
    target.driver.type=source.driver.type;target.driver.expression=source.driver.expression
    target.driver.use_self=source.driver.use_self
    # Existing generated variable paths/IDs are already retargeted to this arm.
    # Only the scalar generator coefficients can differ when a heel axis changes.
    for index,mod in enumerate(source.modifiers):
        if index < len(target.modifiers) and mod.type==target.modifiers[index].type:
            other=target.modifiers[index]
            if mod.type=='GENERATOR':
                other.mode=mod.mode;other.poly_order=mod.poly_order;other.coefficients=mod.coefficients


def upgrade(arm, prototype=None):
    """Migrate a neutral template; return its updated manifest.

    An optional (generated_object, generator_info) pair supports isolated tests.
    Generated controls and bind helpers may change; native weighted bones never do.
    """
    data=json.loads(arm['hhp_rigify_manifest'])
    if data.get('leg_breast_revision',0)>=REVISION:return data
    native=data['native_bones'];before=_snapshot(arm,native)
    saved_active=arm.get('hhp_rigify_active',0.)
    if prototype is None:
        from .hhp_rigify_generate import generate_from_daz
        prototype=generate_from_daz(arm,name='HHP Control Upgrade')
    rig,info=prototype
    prototype_widgets={pb.custom_shape for pb in rig.pose.bones if pb.custom_shape}
    prototype_ui=rig.get('rig_ui')
    kept_widgets=set()
    if info.get('default_poles',True):raise ValueError('Control upgrade requires poles-off calibration')
    for cap,side in [('L','l'),('R','r')]:
        if 'breast.'+cap not in rig.pose.bones:raise ValueError('Control prototype has no breast controls')
        axis=rig.data.bones['ORG-shin.'+cap].matrix_local.to_3x3().col[0]
        if axis.angle(arm.data.bones[side+'Shin'].matrix_local.to_3x3().col[0]) > .04:
            raise ValueError('Control prototype does not use native knee axes')
    arm['hhp_rigify_active']=0.
    leg_names=set()
    for item in info['instances']:
        if item['type'].endswith('.leg'):
            def collect(value):
                if isinstance(value,str):leg_names.add(value)
                elif isinstance(value,dict):
                    for child in value.values():collect(child)
                elif isinstance(value,list):
                    for child in value:collect(child)
            collect(item['bones'])
    changed=[]
    for name in leg_names:
        if name in arm.data.bones and name in rig.data.bones:
            old,new=arm.data.bones[name],rig.data.bones[name]
            if max(abs(old.matrix_local[i][j]-new.matrix_local[i][j]) for i in range(4) for j in range(4))>1e-6:
                changed.append(name)
    new_bones=[name for name in ['ORG-breast.'+cap for cap in 'LR']+['breast.'+cap for cap in 'LR']+['DEF-breast.'+cap for cap in 'LR'] if name not in arm.data.bones]
    bindings=data['bindings'];channels=data['channels'];outputs=data['outputs']
    add_breasts={side+'Pectoral' for side in 'lr' if side+'Pectoral' not in bindings}
    hinge_specs={}
    for side,cap in [('l','L'),('r','R')]:
        for role,org,tweak in [('ThighBend','ORG-thigh.','thigh_tweak.'),('ThighTwist','ORG-thigh.','thigh_tweak.'),('Shin','ORG-shin.','shin_tweak.')]:
            name=side+role
            hinge_specs[name]={'position':'MCH-HHP-leg-position-'+name,'orientation':'MCH-HHP-leg-orientation-'+name,
                              'org':org+cap,'tweak':tweak+cap+('.001' if role=='ThighTwist' else '')}
        name=side+'Pectoral';bindings[name]='MCH-HHP-bind-'+name;channels[name]='MCH-HHP-channel-'+name;outputs[name]=bindings[name]
    collection=arm.data.collections.get('HHP Rigify Bindings') or arm.data.collections.new('HHP Rigify Bindings')
    bpy.context.view_layer.objects.active=arm
    if arm.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT');arm.select_set(True)
    bpy.ops.object.mode_set(mode='EDIT');bones=arm.data.edit_bones
    for name in changed:
        source=rig.data.bones[name];target=bones[name]
        target.matrix=source.matrix_local;target.length=source.length
    for name in new_bones:
        source=rig.data.bones[name];target=bones.new(name)
        target.head=source.head_local;target.tail=source.tail_local
        target.matrix=source.matrix_local;target.length=source.length;target.use_deform=False
        target.parent=bones[_name(source.parent.name)] if source.parent else None
        target.inherit_scale=source.inherit_scale
        for coll in source.collections:
            dest=arm.data.collections.get(coll.name) or arm.data.collections.new(coll.name);dest.assign(target)
    for name,spec in hinge_specs.items():
        bind=bones[bindings[name]]
        pos=bones.new(spec['position']);pos.head=bind.head;pos.tail=bind.tail;pos.matrix=rig.data.bones[info['native_map'][name]].matrix_local@Matrix(info['neutral_offsets'][name]);pos.length=bind.length
        pos.parent=bones[info['native_map'][name]];pos.use_deform=False;collection.assign(pos)
        orient=bones.new(spec['orientation']);donor=rig.data.bones[spec['tweak']]
        orient.head=donor.head_local;orient.tail=donor.tail_local;orient.matrix=donor.matrix_local
        axis=orient.y_axis.copy();orient.head=bones[name].head;orient.tail=orient.head+axis*bind.length
        orient.parent=bones[spec['org']];orient.use_deform=False;collection.assign(orient)
        bind.parent=orient
    for side,cap in [('l','L'),('r','R')]:
        name=side+'Pectoral'
        if name not in add_breasts:continue
        source=bones[name]
        bind=bones.new(bindings[name]);bind.head=source.head;bind.tail=source.tail;bind.matrix=source.matrix;bind.length=source.length;bind.parent=bones['DEF-breast.'+cap];bind.use_deform=False;collection.assign(bind)
        channel=bones.new(channels[name]);channel.head=source.head;channel.tail=source.tail;channel.matrix=source.matrix;channel.length=source.length
        channel.parent=source.parent;channel.inherit_scale=source.inherit_scale
        channel.use_inherit_rotation=source.use_inherit_rotation;channel.use_local_location=source.use_local_location
        channel.use_deform=False;collection.assign(channel)
    bpy.ops.object.mode_set(mode='OBJECT')
    # Keep existing special parent-space targets and visibility ownership. Copy
    # generator changes onto matching leg constraints instead of replacing them.
    for name in leg_names:
        if name not in arm.pose.bones or name not in rig.pose.bones:continue
        for source in rig.pose.bones[name].constraints:
            dest=arm.pose.bones[name].constraints.get(source.name)
            if dest and dest.type==source.type:_constraint_fields(source,dest,arm,rig)
    for source in rig.animation_data.drivers:
        if not any(source.data_path.startswith(rig.pose.bones[n].path_from_id()) for n in leg_names if n in rig.pose.bones):continue
        path=source.data_path
        for old,new in RENAME.items():path=path.replace('pose.bones["'+old+'"]','pose.bones["'+new+'"]')
        dest=arm.animation_data.drivers.find(path,index=source.array_index)
        if dest:_copy_driver(source,dest)
    for name,spec in hinge_specs.items():
        bone=arm.pose.bones[spec['orientation']]
        for kind,title,target,space in [('COPY_ROTATION','Manual Tweak Rotation',spec['tweak'],'LOCAL'),
                                        ('COPY_LOCATION','Deformation Position',spec['position'],'POSE'),
                                        ('COPY_SCALE','Deformation Scale',spec['position'],'POSE')]:
            con=bone.constraints.new(kind);con.name='(HHP) '+title;con.target=arm;con.subtarget=target
            con.owner_space=con.target_space=space
            if kind=='COPY_ROTATION':con.mix_mode='AFTER'
    widgets=bpy.data.collections.get('HHP Bone Widgets') or bpy.data.collections.new('HHP Bone Widgets')
    if not widgets.users:bpy.context.scene.collection.children.link(widgets)
    for name in new_bones:
        source=rig.pose.bones[name];dest=arm.pose.bones[name]
        for source_con in source.constraints:
            con=dest.constraints.new(source_con.type);con.name=source_con.name;_constraint_fields(source_con,con,arm,rig)
        if name.startswith('breast.'):
            dest.custom_shape=source.custom_shape;dest.rotation_mode='QUATERNION';dest.use_custom_shape_bone_size=False
            dest.custom_shape_scale_xyz=(.055,)*3;dest.custom_shape_translation=(0.,.185,0.)
            dest.color.palette='THEME04';dest.custom_shape_wire_width=2.
            if dest.custom_shape:
                widget=dest.custom_shape;kept_widgets.add(widget)
                if widget.name not in widgets.objects:widgets.objects.link(widget)
                for coll in list(widget.users_collection):
                    if coll!=widgets:coll.objects.unlink(widget)
                widget.hide_render=True
    for cap in 'LR':
        dest=arm.pose.bones['breast.'+cap]
        dest.rotation_mode='QUATERNION';dest.use_custom_shape_bone_size=False
        dest.custom_shape_scale_xyz=(.055,)*3;dest.custom_shape_translation=(0.,.185,0.)
        dest.color.palette='THEME04';dest.custom_shape_wire_width=2.
    for side,cap in [('l','L'),('r','R')]:
        name=side+'Pectoral'
        if name not in add_breasts:continue
        bone=arm.pose.bones[name]
        channel=arm.pose.bones[channels[name]];con=channel.constraints.new('COPY_TRANSFORMS')
        con.name='(HHP) Daz Channel Space';con.target=arm;con.subtarget=bindings[name];con.owner_space=con.target_space='POSE'
        con=bone.constraints.new('COPY_TRANSFORMS');con.name='(HHP) Rigify Control';con.target=arm;con.subtarget=channels[name]
        con.owner_space=con.target_space='LOCAL';con.remove_target_shear=True;bone.constraints.move(len(bone.constraints)-1,0)
        _driver(con,'influence',arm,'active',{'active':'["hhp_rigify_active"]'})
        for limit in bone.constraints:
            if limit.type in {'LIMIT_ROTATION','LIMIT_LOCATION'}:
                data['original_limits'].append({'bone':name,'name':limit.name,'mute':limit.mute})
                variables={'active':'["hhp_rigify_active"]'}
                expression='active or '+str(int(limit.mute))
                if limit.type=='LIMIT_ROTATION':
                    variables['override']='["hhp_native_limit_override"]'
                    expression='active or override or '+str(int(limit.mute))
                _driver(limit,'mute',arm,expression,variables)
        data['native_map'][name]='DEF-breast.'+cap;data['input_map'][name]='breast.'+cap
        data['fk_map'][name]='breast.'+cap;data['driven'].append(name);data['controls'].append('breast.'+cap)
    # A fresh builder may already have the breast binding. Ensure its optional
    # native location limit has the same ownership rule without duplicating it.
    for name in ['lPectoral','rPectoral']:
        for limit in arm.pose.bones[name].constraints:
            if limit.type not in {'LIMIT_ROTATION','LIMIT_LOCATION'}:continue
            if not any(item['bone']==name and item['name']==limit.name for item in data['original_limits']):
                data['original_limits'].append({'bone':name,'name':limit.name,'mute':limit.mute})
                variables={'active':'["hhp_rigify_active"]'}
                expression='active or '+str(int(limit.mute))
                if limit.type=='LIMIT_ROTATION':
                    variables['override']='["hhp_native_limit_override"]'
                    expression='active or override or '+str(int(limit.mute))
                _driver(limit,'mute',arm,expression,variables)
    data['generated_bones'].extend(new_bones)
    helpers=[value for spec in hinge_specs.values() for key,value in spec.items() if key in {'position','orientation'}]
    helpers += [value for name in add_breasts for value in (bindings[name],channels[name])]
    data['extension_helpers']=list(dict.fromkeys(data.get('extension_helpers',[])+helpers))
    data['leg_hinges']=hinge_specs;data['leg_breast_revision']=REVISION;data['default_poles']=False
    for item in info['instances']:
        if item['base_bone'].startswith('ORG-breast.') and not any(i['base_bone']==item['base_bone'] for i in data['instances']):
            data['instances'].append(item)
    # Establish the current combined armature's actual neutral, not another
    # object's IK numerical solution, before recomputing each bind rest offset.
    for name in data['controls']:
        arm.pose.bones[name].matrix_basis=Matrix.Identity(4)
    for name in bindings.values():arm.pose.bones[name].matrix_basis=Matrix.Identity(4)
    for item in data['limbs']:
        bone=arm.pose.bones[item['master']];bone['IK_FK']=0.;bone['pole_vector']=False
        bone.id_properties_ui('pole_vector').update(default=False)
    for item in data['fingers']:arm.pose.bones[item['ik_control']]['FK_IK']=1.
    arm.update_tag();bpy.context.view_layer.update()
    evaluated=arm.evaluated_get(bpy.context.evaluated_depsgraph_get())
    # Calibrate position readers first, so the hinge orientation's copied origin
    # is already exact when the final binding offsets are captured.
    edits={spec['position']:arm.data.bones[spec['position']].parent.matrix_local @ evaluated.pose.bones[arm.data.bones[spec['position']].parent.name].matrix.inverted_safe() @ arm.data.bones[name].matrix_local for name,spec in hinge_specs.items()}
    bpy.ops.object.mode_set(mode='EDIT')
    for name,matrix in edits.items():bones=arm.data.edit_bones;length=bones[name].length;bones[name].matrix=matrix;bones[name].length=length
    bpy.ops.object.mode_set(mode='OBJECT');arm.update_tag();bpy.context.view_layer.update();evaluated=arm.evaluated_get(bpy.context.evaluated_depsgraph_get())
    edits={binding:arm.data.bones[binding].parent.matrix_local @ evaluated.pose.bones[arm.data.bones[binding].parent.name].matrix.inverted_safe() @ arm.data.bones[name].matrix_local for name,binding in bindings.items()}
    bpy.ops.object.mode_set(mode='EDIT')
    for name,matrix in edits.items():bones=arm.data.edit_bones;length=bones[name].length;bones[name].matrix=matrix;bones[name].length=length
    bpy.ops.object.mode_set(mode='OBJECT')
    data['neutral_basis']={n:[list(row) for row in arm.pose.bones[n].matrix_basis] for n in data['controls']+list(bindings.values())}
    for name,target in data['native_map'].items():data['offsets'][name]=[list(row) for row in arm.data.bones[target].matrix_local.inverted_safe()@arm.data.bones[name].matrix_local]
    for name,binding in bindings.items():data['neutral_offsets'][name]=[list(row) for row in arm.data.bones[arm.data.bones[binding].parent.name].matrix_local.inverted_safe()@arm.data.bones[binding].matrix_local]
    arm['hhp_rigify_manifest']=json.dumps(data,separators=(',',':'))
    from .hhp5_root import ensure_scale_compensation
    from .animation_transfer_support import sync_proportion_followers, sync_proportion_controls
    ensure_scale_compensation(arm);sync_proportion_followers(arm);sync_proportion_controls(arm)
    arm['hhp_rigify_active']=saved_active
    assert _snapshot(arm,native)==before,'Native bone rest changed in control upgrade'
    # Temporary generation output is discarded; transferred breast widget IDs
    # remain owned by HHP Bone Widgets and the controls in this armature.
    rig_data=rig.data;bpy.data.objects.remove(rig,do_unlink=True)
    rig_data.use_fake_user=False
    if rig_data.users==0:bpy.data.armatures.remove(rig_data)
    for widget in prototype_widgets-kept_widgets:
        if not any(pb.custom_shape==widget for obj in bpy.data.objects if obj.type=='ARMATURE' for pb in obj.pose.bones):
            bpy.data.objects.remove(widget,do_unlink=True)
    for coll in list(bpy.data.collections):
        if coll.name.startswith('WGTS_') and not coll.objects and not coll.children:
            bpy.data.collections.remove(coll)
    if prototype_ui and prototype_ui!=arm.get('rig_ui'):
        prototype_ui.use_fake_user=False
        if prototype_ui.users==0:bpy.data.texts.remove(prototype_ui)
    arm.update_tag();bpy.context.view_layer.update()
    return data
