"""Character data, asset references, and shader transfer primitives."""
import bpy
import re
from copy import deepcopy

PROTECTED_ASSET_COLLECTION_BASES = {
    "Clothes",
    "Char Specific Proxies",
    "Char Appendage",
    "Hair",
    "Eyes",
    "Collision",
}

EFFECTS_SHADER_GROUP_TRANSFERS = (
    {
        "label": "Makeup",
        "material_keyword": None,
        "group_keyword": "Makeup_HHP",
        "excluded_sockets": {"Base Color", "Roughness"},
    },
    {
        "label": "Fingernails",
        "material_keyword": "Genesis 8 Female_Fingernails",
        "group_keyword": "Fingernails (HHP)",
        "excluded_sockets": set(),
    },
    {
        "label": "Toenails",
        "material_keyword": "Genesis 8 Female_Toenails",
        "group_keyword": "Toenails (HHP)",
        "excluded_sockets": set(),
    },
)

def zero_shape_keys(obj):
    """Set every shape‐key value on obj to 0.0."""
    sk = getattr(obj.data, "shape_keys", None)
    if not sk:
        return
    for kb in sk.key_blocks:
        kb.value = 0.0


def safe_copy_val(v):
    """Deep-copy IDProperty values (including arrays & dicts)."""
    if hasattr(v, 'to_dict'):
        return {key: safe_copy_val(value) for key, value in v.to_dict().items()}
    try:
        return deepcopy(v)
    except Exception:
        if hasattr(v, "to_list"):
            return v.to_list()
        try:
            return type(v)(v)
        except Exception:
            return v


def copy_missing_custom_props(src_obj, dst_obj, excluded_properties=()):
    """
    Copy any custom properties from src_obj → dst_obj that don't
    already exist on dst_obj, including:
      - the raw value
      - all UI metadata (min, max, soft_min, soft_max, use_soft_limits,
        step, precision, subtype, default, description, etc.)
      - the library‐override flag
    """
    # fallback UI data block if id_properties_ui() is unavailable
    src_rna_ui = src_obj.get("_RNA_UI", {})

    for key in src_obj.keys():
        if key in excluded_properties:
            continue
        if key in {"_RNA_UI", "HHP Version", "presets", "active_preset", "_hhp_identity_next", "_hhp_identity_names"} or key in dst_obj.keys() or "pubic hair" in key.lower():
            continue

        # 1) copy the raw value
        dst_obj[key] = safe_copy_val(src_obj[key])

        # 2) copy the UI metadata
        try:
            # Blender ≥ 3.0
            src_ui = src_obj.id_properties_ui(key)
            meta = src_ui.as_dict()
            dst_ui = dst_obj.id_properties_ui(key)
            dst_ui.update(**meta)
        except Exception:
            # fallback for older Blenders
            if key in src_rna_ui:
                if "_RNA_UI" not in dst_obj:
                    dst_obj["_RNA_UI"] = {}
                dst_obj["_RNA_UI"][key] = {}
                for attr, val in src_rna_ui[key].items():
                    dst_obj["_RNA_UI"][key][attr] = safe_copy_val(val)

        # 3) copy the library‐override flag
        prop_path = f'["{key}"]'
        try:
            overridable = src_obj.is_property_overridable_library(prop_path)
            dst_obj.property_overridable_library_set(prop_path, overridable)
        except Exception:
            # if the API isn't available, just skip
            pass


def transfer_existing_custom_properties(ctx, excluded_properties=()):
    """Transfer existing custom property values from selected objects to active object."""
    target_obj = ctx.active_object
    selected_objs = [obj for obj in ctx.selected_objects if obj != target_obj]

    if not selected_objs:
        print("No source objects for property transfer.")
        return

    for source_obj in selected_objs:
        for prop_name, prop_value in source_obj.items():
            if prop_name in excluded_properties:
                continue
            if prop_name in {"_RNA_UI", "HHP Version", "presets", "active_preset", "_hhp_identity_next", "_hhp_identity_names"} or "pubic hair" in prop_name.lower():
                continue
            if prop_name in target_obj.keys():
                try:
                    # Use the safe copy function to handle complex IDProperty types
                    target_obj[prop_name] = safe_copy_val(prop_value)
                    pass
                except Exception as e:
                    print(f"Failed to transfer property '{prop_name}': {e}")
            else:
                print(f"Skipped property '{prop_name}' as it does not exist on the target object")


def _find_effects_shader_group_node(obj, material_keyword, group_keyword):
    """Find the node-group instance exposed by the Effects & Shaders panel."""
    if not obj or getattr(obj, "type", None) != 'MESH':
        return None

    for slot in getattr(obj, "material_slots", []) or []:
        material = getattr(slot, "material", None)
        if not material:
            continue
        if material_keyword and material_keyword not in material.name:
            continue
        if not getattr(material, "use_nodes", False) or not material.node_tree:
            continue

        for node in material.node_tree.nodes:
            if (
                getattr(node, "type", None) == 'GROUP'
                and getattr(node, "node_tree", None)
                and group_keyword in node.node_tree.name
            ):
                return node
    return None


def _get_effects_shader_value_socket(group_input):
    """Return the actual socket edited by the Effects & Shaders panel."""
    if not group_input:
        return None
    if group_input.is_linked and group_input.links:
        linked_node = group_input.links[0].from_node
        outputs = getattr(linked_node, "outputs", None)
        if outputs and len(outputs) > 0 and hasattr(outputs[0], "default_value"):
            return outputs[0]
        return None
    return group_input if hasattr(group_input, "default_value") else None


def transfer_effects_shader_group_values(ctx):
    """Transfer exposed Makeup, Fingernails, and Toenails shader values."""
    target_obj = ctx.active_object
    source_objects = [
        obj
        for obj in ctx.selected_objects
        if obj != target_obj and getattr(obj, "type", None) == 'MESH'
    ]
    if not target_obj or getattr(target_obj, "type", None) != 'MESH':
        print("Active object is not a mesh for Effects & Shaders transfer.")
        return
    if not source_objects:
        print("No source mesh found for Effects & Shaders transfer.")
        return

    source_obj = source_objects[0]
    transferred = 0

    for config in EFFECTS_SHADER_GROUP_TRANSFERS:
        source_group = _find_effects_shader_group_node(
            source_obj,
            config["material_keyword"],
            config["group_keyword"],
        )
        target_group = _find_effects_shader_group_node(
            target_obj,
            config["material_keyword"],
            config["group_keyword"],
        )
        if not source_group or not target_group:
            print(
                f"Could not find the exposed {config['label']} shader group "
                "on both selected and active meshes."
            )
            continue

        for source_input in source_group.inputs:
            if (
                source_input.name in config["excluded_sockets"]
                or getattr(source_input, "hide_value", False)
            ):
                continue

            target_input = target_group.inputs.get(source_input.name)
            if not target_input or getattr(target_input, "hide_value", False):
                continue

            source_value_socket = _get_effects_shader_value_socket(source_input)
            target_value_socket = _get_effects_shader_value_socket(target_input)
            if not source_value_socket or not target_value_socket:
                continue

            try:
                target_value_socket.default_value = safe_copy_val(
                    source_value_socket.default_value
                )
                transferred += 1
            except Exception as exc:
                print(
                    f"Failed to transfer {config['label']} input "
                    f"'{source_input.name}': {exc}"
                )

    if transferred:
        print(
            f"Transferred {transferred} exposed Effects & Shaders "
            f"node-group value(s) from '{source_obj.name}' to '{target_obj.name}'."
        )


def transfer_vertex_groups(ctx):
    """Transfer vertex groups from selected objects to active object."""
    active_obj = ctx.active_object
    selected_objects = [obj for obj in ctx.selected_objects if obj != active_obj and obj.type == 'MESH']

    if not selected_objects:
        print("No source mesh objects for vertex group transfer.")
        return

    for obj in selected_objects:
        if not obj.vertex_groups:
            print(f"No vertex groups on {obj.name}")
            continue

        if len(obj.data.vertices) != len(active_obj.data.vertices):
            print(f"Cannot transfer vertex groups from {obj.name} - mesh topology mismatch")
            continue

        target_vertex_groups_names = [vg.name for vg in active_obj.vertex_groups]

        for src_group in obj.vertex_groups:
            if src_group.name not in target_vertex_groups_names:
                tgt_group = active_obj.vertex_groups.new(name=src_group.name)

                # Transferring the weights
                for v in obj.data.vertices:
                    try:
                        weight = src_group.weight(v.index)
                        tgt_group.add([v.index], weight, 'REPLACE')
                    except RuntimeError:
                        # This happens if the vertex is not part of the src_group.
                        pass

    print("Vertex groups transferred!")


def transfer_unavailable_shape_keys(ctx):
    """Transfer unavailable shape keys from selected objects to active object."""
    selected_objects = ctx.selected_objects
    active_object = ctx.active_object

    # Validate selection
    if len(selected_objects) < 2 or active_object is None:
        print("Please select at least two objects with one active object.")
        return

    # Process each selected object (excluding active)
    for source_object in selected_objects:
        if source_object == active_object or source_object.type != 'MESH':
            continue

        # Check if the source object has shape keys
        if not source_object.data.shape_keys or len(source_object.data.shape_keys.key_blocks) <= 1:
            print(f"No shape keys to transfer from {source_object.name}")
            continue

        # Create a basis shape key for the target if it doesn't exist
        if not active_object.data.shape_keys:
            active_object.shape_key_add(name='Basis', from_mix=False)

        # Get all shape key names in the target object
        existing_shape_keys = {key.name for key in active_object.data.shape_keys.key_blocks} if active_object.data.shape_keys else set()
        copied_keys = []

        # Transfer shape keys from source to target
        for key in source_object.data.shape_keys.key_blocks:
            if key.name not in existing_shape_keys:
                if len(key.data) != len(active_object.data.vertices):
                    print(f"Cannot transfer shape key '{key.name}' from {source_object.name} - mesh topology mismatch")
                    continue

                new_key = active_object.shape_key_add(name=key.name, from_mix=False)
                try:
                    new_key.data.foreach_set("co", [co for vertex in key.data for co in vertex.co])
                except Exception as e:
                    active_object.shape_key_remove(new_key)
                    print(f"Failed to copy shape key '{key.name}' from {source_object.name}: {e}")
                    continue

                existing_shape_keys.add(new_key.name)
                new_key.interpolation = key.interpolation
                new_key.mute = key.mute
                copied_keys.append((new_key, key.relative_key.name))
                print(f"Transferred shape key '{key.name}' from {source_object.name}")
            else:
                print(f"Skipping '{key.name}' as it already exists in the target object.")

        # A relative key can appear later in the donor stack.
        for copied, relative_name in copied_keys:
            relative = active_object.data.shape_keys.key_blocks.get(relative_name)
            if relative is not None:
                copied.relative_key = relative

    print("Shape keys transferred successfully.")


def transfer_shape_key_min_max(ctx):
    """Transfer min/max values of shape keys by name from selected objects to active object."""
    selected_objects = ctx.selected_objects
    target_mesh = ctx.active_object

    if not target_mesh or target_mesh.type != 'MESH':
        print("Active object must be a mesh.")
        return

    if not target_mesh.data.shape_keys:
        print("Target mesh has no shape keys.")
        return

    for source_mesh in selected_objects:
        if source_mesh == target_mesh or source_mesh.type != 'MESH':
            continue

        if not source_mesh.data.shape_keys:
            print(f"Source mesh {source_mesh.name} has no shape keys.")
            continue

        # Copy min/max values of shape keys from source to target by name
        for source_shape_key in source_mesh.data.shape_keys.key_blocks:
            target_shape_key = target_mesh.data.shape_keys.key_blocks.get(source_shape_key.name)
            if target_shape_key:
                target_shape_key.slider_min = source_shape_key.slider_min
                target_shape_key.slider_max = source_shape_key.slider_max
                print(f"Copied min/max values for shape key '{source_shape_key.name}' from {source_mesh.name} to target.")

    print("Min/max values for shape keys copied successfully.")


def transfer_shape_key_values_and_masks(ctx):
    """Transfer shape key values and their vertex group masks by name from selected objects to active object."""
    selected_objects = ctx.selected_objects
    target_mesh = ctx.active_object

    if not target_mesh or target_mesh.type != 'MESH':
        print("Active object must be a mesh.")
        return

    if not target_mesh.data.shape_keys:
        print("Target mesh has no shape keys.")
        return

    for source_mesh in selected_objects:
        if source_mesh == target_mesh or source_mesh.type != 'MESH':
            continue

        if not source_mesh.data.shape_keys:
            print(f"Source mesh {source_mesh.name} has no shape keys.")
            continue

        # Transfer shape key values and vertex group masks by name
        for source_shape_key in source_mesh.data.shape_keys.key_blocks:
            target_shape_key = target_mesh.data.shape_keys.key_blocks.get(source_shape_key.name)
            if target_shape_key:
                # Transfer the value only if the source shape key is not muted
                if not source_shape_key.mute:
                    target_shape_key.value = source_shape_key.value
                    print(f"Transferred value and mask for shape key '{source_shape_key.name}' from {source_mesh.name} to target.")
                else:
                    print(f"Skipped value transfer for muted shape key '{source_shape_key.name}' from {source_mesh.name}")

                # Always transfer the vertex group mask if it exists
                if source_shape_key.vertex_group:
                    target_shape_key.vertex_group = source_shape_key.vertex_group

    print("Shape key values and vertex group masks transferred successfully.")


def copy_delta_corrective_shapekey_drivers(ctx):
    """Copy DeltaCorrective shapekey drivers from the selected mesh(es) to the active mesh."""
    active_obj = ctx.active_object
    if not active_obj or active_obj.type != 'MESH':
        print("Active object is not a mesh - skipping DeltaCorrective driver copy.")
        return

    target_shape_keys = getattr(active_obj.data, "shape_keys", None)
    if not target_shape_keys:
        print(f"Active mesh '{active_obj.name}' has no shape keys - skipping DeltaCorrective driver copy.")
        return

    sources = [obj for obj in ctx.selected_objects if obj != active_obj and obj.type == 'MESH']
    if not sources:
        print("No source meshes to copy DeltaCorrective drivers from.")
        return

    if not getattr(target_shape_keys, "animation_data", None):
        try:
            target_shape_keys.animation_data_create()
        except Exception:
            pass

    def _copy_rna_properties(src, dst):
        rna = getattr(src, "bl_rna", None)
        if not rna:
            return
        for prop in rna.properties:
            ident = getattr(prop, "identifier", None)
            if not ident or ident == "rna_type" or getattr(prop, "is_readonly", False):
                continue
            try:
                setattr(dst, ident, getattr(src, ident))
            except Exception:
                pass

    def _get_armature(mesh_obj):
        for mod in getattr(mesh_obj, "modifiers", []) or []:
            if getattr(mod, "type", None) == 'ARMATURE' and getattr(mod, "object", None) and getattr(mod.object, "type", None) == 'ARMATURE':
                return mod.object
        return None

    def _extract_key_name(data_path):
        if not data_path:
            return None
        match = re.search(r'key_blocks\["([^"]+)"\]\.value', data_path)
        return match.group(1) if match else None

    def _ensure_target_count(targets, desired):
        if desired <= 0:
            while len(targets) > 0:
                try:
                    targets.remove(targets[len(targets) - 1])
                except Exception:
                    break
            return
        while len(targets) < desired:
            try:
                targets.new()
            except Exception:
                break
        while len(targets) > desired and len(targets) > 0:
            try:
                targets.remove(targets[len(targets) - 1])
            except Exception:
                break

    def _copy_driver_target(src_target, dst_target, source_mesh, target_mesh, source_armature, target_armature):
        target_id = getattr(src_target, "id", None)
        if target_id == source_mesh:
            target_id = target_mesh
        elif source_armature and target_id == source_armature and target_armature:
            target_id = target_armature

        for attr in ("id_type", "data_path", "bone_target", "transform_type", "transform_space", "rotation_mode"):
            if hasattr(src_target, attr):
                try:
                    setattr(dst_target, attr, getattr(src_target, attr))
                except Exception:
                    pass

        try:
            dst_target.id = target_id
        except Exception:
            pass

    def _copy_driver_variables(src_driver, dst_driver, source_mesh, target_mesh, source_armature, target_armature):
        for var in list(dst_driver.variables):
            try:
                dst_driver.variables.remove(var)
            except Exception:
                pass

        for src_var in getattr(src_driver, "variables", []) or []:
            try:
                new_var = dst_driver.variables.new()
            except Exception:
                continue

            for attr in ("name", "type", "use_self"):
                if hasattr(src_var, attr):
                    try:
                        setattr(new_var, attr, getattr(src_var, attr))
                    except Exception:
                        pass

            src_targets = getattr(src_var, "targets", []) or []
            _ensure_target_count(new_var.targets, len(src_targets))

            for dst_target, src_target in zip(new_var.targets, src_targets):
                _copy_driver_target(src_target, dst_target, source_mesh, target_mesh, source_armature, target_armature)

    def _copy_driver_fcurve(source_fcurve, target_keys, source_mesh, target_mesh, source_armature, target_armature):
        data_path = getattr(source_fcurve, "data_path", "")
        if not data_path:
            return False

        array_index = getattr(source_fcurve, "array_index", -1)
        try:
            if array_index is not None and array_index >= 0:
                target_keys.driver_remove(data_path, array_index)
            else:
                target_keys.driver_remove(data_path)
        except Exception:
            pass

        try:
            if array_index is not None and array_index >= 0:
                new_fcurve = target_keys.driver_add(data_path, array_index)
            else:
                new_fcurve = target_keys.driver_add(data_path)
        except TypeError:
            # Some Blender builds don't like the explicit array index; fall back to path‑only
            new_fcurve = target_keys.driver_add(data_path)
        except Exception as e:
            print(f"Failed to add driver for '{data_path}' on '{target_mesh.name}': {e}")
            return False

        # Ensure there is at least one keyframe so Blender keeps the F‑Curve/driver alive.
        # This mirrors the behavior relied on by the clothing/accessories driver tools.
        try:
            if not getattr(new_fcurve, "keyframe_points", None) or len(new_fcurve.keyframe_points) == 0:
                frame = getattr(bpy.context.scene, "frame_current", 1.0)
                # Use a neutral value; the driver expression will override evaluation anyway.
                new_fcurve.keyframe_points.insert(frame, 0.0)
        except Exception:
            # If keyframe creation fails we still continue; later copy logic may add them.
            pass

        for attr in (
            "mute",
            "lock",
            "select",
            "hide",
            "color_mode",
            "auto_smoothing",
            "use_smoothing",
            "active",
        ):
            if hasattr(source_fcurve, attr):
                try:
                    setattr(new_fcurve, attr, getattr(source_fcurve, attr))
                except Exception:
                    pass

        src_driver = getattr(source_fcurve, "driver", None)
        dst_driver = getattr(new_fcurve, "driver", None)
        if not src_driver or not dst_driver:
            return False

        for attr in ("type", "expression", "use_self", "show_debug_info"):
            if hasattr(src_driver, attr):
                try:
                    setattr(dst_driver, attr, getattr(src_driver, attr))
                except Exception:
                    pass

        _copy_driver_variables(src_driver, dst_driver, source_mesh, target_mesh, source_armature, target_armature)

        keyframes = getattr(source_fcurve, "keyframe_points", None)
        if keyframes:
            dest_keyframes = getattr(new_fcurve, "keyframe_points", None)
            if dest_keyframes:
                try:
                    dest_keyframes.clear()
                except Exception:
                    for kf in list(dest_keyframes):
                        try:
                            dest_keyframes.remove(kf)
                        except Exception:
                            pass

                for src_kf in keyframes:
                    try:
                        new_kf = dest_keyframes.insert(src_kf.co.x, src_kf.co.y)
                    except Exception:
                        continue
                    for attr in (
                        "interpolation",
                        "handle_left",
                        "handle_right",
                        "handle_left_type",
                        "handle_right_type",
                        "easing",
                        "back",
                        "amplitude",
                        "period",
                    ):
                        if hasattr(src_kf, attr) and hasattr(new_kf, attr):
                            try:
                                setattr(new_kf, attr, getattr(src_kf, attr))
                            except Exception:
                                pass

        if hasattr(source_fcurve, "extrapolation") and hasattr(new_fcurve, "extrapolation"):
            try:
                new_fcurve.extrapolation = source_fcurve.extrapolation
            except Exception:
                pass

        dest_mods = getattr(new_fcurve, "modifiers", None)
        src_mods = getattr(source_fcurve, "modifiers", None)
        if dest_mods is not None and src_mods is not None:
            try:
                dest_mods.clear()
            except Exception:
                for mod in list(dest_mods):
                    try:
                        dest_mods.remove(mod)
                    except Exception:
                        pass

            for src_mod in src_mods:
                try:
                    new_mod = dest_mods.new(type=src_mod.type)
                except Exception:
                    continue
                _copy_rna_properties(src_mod, new_mod)

        return True

    target_armature = _get_armature(active_obj)
    copied = 0
    processed_shapekeys = set()

    for source_obj in sources:
        source_shape_keys = getattr(source_obj.data, "shape_keys", None)
        if not source_shape_keys:
            continue

        source_anim = getattr(source_shape_keys, "animation_data", None)
        if not source_anim or not getattr(source_anim, "drivers", None):
            continue

        source_armature = _get_armature(source_obj)

        for fcurve in source_anim.drivers:
            shapekey_name = _extract_key_name(getattr(fcurve, "data_path", ""))
            if not shapekey_name or "DeltaCorrective" not in shapekey_name:
                continue

            if shapekey_name in processed_shapekeys:
                continue

            if not target_shape_keys.key_blocks.get(shapekey_name):
                print(f"Target mesh '{active_obj.name}' is missing DeltaCorrective shapekey '{shapekey_name}' - skipping driver copy.")
                continue

            if _copy_driver_fcurve(fcurve, target_shape_keys, source_obj, active_obj, source_armature, target_armature):
                processed_shapekeys.add(shapekey_name)
                copied += 1

    if copied:
        print(f"Copied {copied} DeltaCorrective shapekey driver(s) to '{active_obj.name}'.")
    else:
        print("No DeltaCorrective shapekey drivers were copied.")


def transfer_missing_vertex_colors(ctx):
    """Transfer missing color attributes from selected objects to the active object."""

    def _color_attributes(mesh):
        attrs = getattr(mesh, "color_attributes", None)
        if attrs is not None:
            return attrs
        return getattr(mesh, "vertex_colors", None)

    def _new_color_attribute(target_attrs, source_attr):
        if hasattr(source_attr, "data_type") and hasattr(source_attr, "domain"):
            try:
                return target_attrs.new(
                    name=source_attr.name,
                    type=source_attr.data_type,
                    domain=source_attr.domain,
                )
            except TypeError:
                pass

        return target_attrs.new(name=source_attr.name)

    target_obj = ctx.active_object

    if not target_obj or target_obj.type != 'MESH':
        print("Active object is not a mesh.")
        return

    target_color_attrs = _color_attributes(target_obj.data)
    if target_color_attrs is None:
        print(f"Color attributes are not available on {target_obj.name}.")
        return

    selected_objects = [obj for obj in ctx.selected_objects if obj != target_obj and obj.type == 'MESH']

    if not selected_objects:
        print("No source mesh objects for color attribute transfer.")
        return

    existing_names = {attr.name for attr in target_color_attrs}

    for source_obj in selected_objects:
        source_color_attrs = _color_attributes(source_obj.data)

        if source_color_attrs is None or len(source_color_attrs) == 0:
            print(f"No color attributes on {source_obj.name}")
            continue

        for source_attr in source_color_attrs:
            if source_attr.name in existing_names:
                continue

            new_color_attr = _new_color_attribute(target_color_attrs, source_attr)
            if new_color_attr is None:
                print(f"Failed to create color attribute '{source_attr.name}' on {target_obj.name}")
                continue

            if len(new_color_attr.data) != len(source_attr.data):
                target_color_attrs.remove(new_color_attr)
                print(f"Cannot transfer color attribute '{source_attr.name}' from {source_obj.name} - mesh topology mismatch")
                continue

            for target_color, source_color in zip(new_color_attr.data, source_attr.data):
                target_color.color = source_color.color

            existing_names.add(new_color_attr.name)
            print(f"Transferred color attribute '{source_attr.name}' from {source_obj.name}")

    print("Missing color attributes transferred.")


def transfer_missing_uv_maps(ctx):
    """Transfer only missing UV maps from selected objects to active object without overwriting existing ones."""
    target_obj = ctx.active_object

    if not target_obj or target_obj.type != 'MESH':
        print("Active object is not a mesh.")
        return

    selected_objects = [obj for obj in ctx.selected_objects if obj != target_obj and obj.type == 'MESH']

    if not selected_objects:
        print("No source mesh objects for UV map transfer.")
        return

    # Store the names of existing UV maps in the target object
    existing_uv_maps = {uv.name for uv in target_obj.data.uv_layers}

    # Iterate over selected objects
    for source_obj in selected_objects:
        # Check if source has UV maps
        if not source_obj.data.uv_layers:
            print(f"No UV maps on {source_obj.name}")
            continue

        # Copy only missing UV maps from source to target
        for source_uv_map in source_obj.data.uv_layers:
            if source_uv_map.name not in existing_uv_maps:
                # Verify we can transfer (same vertex count)
                if len(source_obj.data.loops) != len(target_obj.data.loops):
                    print(f"Cannot transfer UV map '{source_uv_map.name}' from {source_obj.name} - mesh topology mismatch")
                    continue

                # Create new UV map
                new_uv_map = target_obj.data.uv_layers.new(name=source_uv_map.name)

                if new_uv_map is None:
                    print(f"Failed to create UV map '{source_uv_map.name}' on {target_obj.name}")
                    continue

                # Verify the new UV map has data before trying to copy
                if not hasattr(new_uv_map, 'data') or not hasattr(source_uv_map, 'data'):
                    target_obj.data.uv_layers.remove(new_uv_map)
                    print(f"UV map data not accessible for '{source_uv_map.name}' - skipping")
                    continue

                # Check data length consistency
                if len(source_uv_map.data) != len(new_uv_map.data):
                    target_obj.data.uv_layers.remove(new_uv_map)
                    print(f"UV data length mismatch for '{source_uv_map.name}' - skipping transfer")
                    continue

                # Copy UV coordinates
                try:
                    for i, source_loop in enumerate(source_uv_map.data):
                        new_uv_map.data[i].uv = source_loop.uv

                    existing_uv_maps.add(source_uv_map.name)  # Update the set to avoid duplicates
                    print(f"Transferred UV map '{source_uv_map.name}' from {source_obj.name} to {target_obj.name}")

                except Exception as e:
                    target_obj.data.uv_layers.remove(new_uv_map)
                    print(f"Failed to copy UV data for '{source_uv_map.name}': {e}")
            else:
                print(f"Skipped UV map '{source_uv_map.name}' - already exists on target object")

    print("UV map transfer complete.")


def get_top_parent_collection(obj):
    """Resolve the character boundary even when characters share a scene folder."""
    from ..Customize_HHP import find_character_hhp_collection
    return find_character_hhp_collection(obj)



def find_collections_by_prefix_in_parent(source_mesh, prefix):
    """Find category roots, ignoring similarly named folders inside asset packs."""
    if not source_mesh:
        return []

    # Get the top parent collection of the source mesh
    parent_collection = get_top_parent_collection(source_mesh)
    if not parent_collection:
        return []

    # Match canonical category names with optional Blender numerical suffixes.
    found_collections = []
    category_names = {name.lower() for name in PROTECTED_ASSET_COLLECTION_BASES}
    visited = set()

    def search_collection(collection):
        for child in collection.children:
            if child in visited:
                continue
            visited.add(child)
            category = get_base_object_name(child.name).lower()
            if category == prefix.lower():
                found_collections.append(child)
            # A Clothes pack can contain Hair, Hair Mesh and Hair Materials
            # folders. They belong to that pack, not to the character Hair root.
            if category not in category_names:
                search_collection(child)

    # Start the search from the parent collection
    search_collection(parent_collection)

    return found_collections


def source_asset_collection_groups(source_mesh):
    """Include custom folders directly under the character's Appendages root."""
    groups = {category: find_collections_by_prefix_in_parent(source_mesh, category)
              for category in ("Clothes", "Char Specific Proxies", "Char Appendage",
                               "Hair", "Eyes", "Collision")}
    root = get_top_parent_collection(source_mesh)
    if root is None:
        return groups
    category_names = {name.lower() for name in PROTECTED_ASSET_COLLECTION_BASES}
    visited = set()

    def visit(collection):
        if collection in visited:
            return
        visited.add(collection)
        for child in collection.children:
            name = get_base_object_name(child.name).lower()
            if name in category_names:
                continue
            if name == "appendages":
                for asset in child.children:
                    asset_name = get_base_object_name(asset.name).lower()
                    if asset_name in category_names:
                        continue
                    if re.search(r"\bhair\b", asset_name):
                        category = "Hair"
                    elif re.search(r"\beyes?\b", asset_name):
                        category = "Eyes"
                    else:
                        category = "Char Appendage"
                    if asset not in groups[category]:
                        groups[category].append(asset)
            else:
                visit(child)

    visit(root)
    return groups


def get_base_object_name(name):
    """Strips numerical suffixes like .001 from an object name."""
    return re.sub(r'\.\d+$', '', name)


def find_object_in_hierarchy(start_collection, base_name):
    """Recursively search for an object with a given base name in a collection hierarchy."""
    # Check objects in the current collection
    for obj in start_collection.objects:
        if get_base_object_name(obj.name) == base_name:
            return obj

    # Recurse into child collections
    for child_collection in start_collection.children:
        found_obj = find_object_in_hierarchy(child_collection, base_name)
        if found_obj:
            return found_obj

    return None


def retarget_shapekey_driver_targets(obj, old_mesh, new_mesh, old_armature, new_armature):
    """
    Update any shapekey driver variables on obj that still reference the old mesh or armature.
    Returns the number of driver targets that were updated.
    """
    if not obj or obj.type != 'MESH':
        return 0

    data = getattr(obj, "data", None)
    if not data:
        return 0

    shape_keys = getattr(data, "shape_keys", None)
    if not shape_keys:
        return 0

    anim = getattr(shape_keys, "animation_data", None)
    if not anim or not getattr(anim, "drivers", None):
        return 0

    updated = 0
    for fcurve in anim.drivers:
        driver = getattr(fcurve, "driver", None)
        if not driver or not getattr(driver, "variables", None):
            continue
        for var in driver.variables:
            targets = getattr(var, "targets", None)
            if not targets:
                continue
            for target in targets:
                if not target:
                    continue
                target_id = getattr(target, "id", None)
                if target_id is None:
                    continue

                if target_id == old_mesh and new_mesh:
                    target.id = new_mesh
                    updated += 1
                elif old_armature and target_id == old_armature and new_armature:
                    target.id = new_armature
                    updated += 1

    if updated:
        print(f"Retargeted {updated} shapekey driver target(s) on '{obj.name}'")
    return updated


def retarget_node_tree_driver_targets(node_tree, old_mesh, new_mesh, old_armature, new_armature, visited=None):
    """
    Update driver variables on a material/node group tree and any nested group trees.
    Returns the number of driver targets that were updated.
    """
    if not node_tree:
        return 0
    if visited is None:
        visited = set()

    tree_key = node_tree.as_pointer() if hasattr(node_tree, "as_pointer") else id(node_tree)
    if tree_key in visited:
        return 0
    visited.add(tree_key)

    replacements = (
        (old_mesh, new_mesh),
        (getattr(old_mesh, "data", None), getattr(new_mesh, "data", None) if new_mesh else None),
        (old_armature, new_armature),
        (getattr(old_armature, "data", None), getattr(new_armature, "data", None) if new_armature else None),
    )

    updated = 0
    anim = getattr(node_tree, "animation_data", None)
    if anim and getattr(anim, "drivers", None):
        for fcurve in anim.drivers:
            driver = getattr(fcurve, "driver", None)
            if not driver or not getattr(driver, "variables", None):
                continue

            for var in driver.variables:
                for target in getattr(var, "targets", []) or []:
                    target_id = getattr(target, "id", None)
                    if target_id is None:
                        continue

                    for old_id, new_id in replacements:
                        if old_id and new_id and target_id == old_id:
                            try:
                                target.id = new_id
                                updated += 1
                            except Exception as e:
                                print(f"Failed to retarget driver in node tree '{node_tree.name}': {e}")
                            break

    for node in getattr(node_tree, "nodes", []) or []:
        if getattr(node, "type", None) == 'GROUP' and getattr(node, "node_tree", None):
            updated += retarget_node_tree_driver_targets(
                node.node_tree,
                old_mesh,
                new_mesh,
                old_armature,
                new_armature,
                visited,
            )

    return updated


def retarget_material_node_driver_targets(obj, old_mesh, new_mesh, old_armature, new_armature):
    """
    Update material and nested node group driver variables on obj to reference the new mesh/armature.
    Returns the number of driver targets that were updated.
    """
    if not obj:
        return 0

    data = getattr(obj, "data", None)
    materials = getattr(data, "materials", None) if data else None
    if not materials:
        return 0

    updated = 0
    visited = set()
    for mat in materials:
        if not mat or not getattr(mat, "use_nodes", False) or not getattr(mat, "node_tree", None):
            continue
        updated += retarget_node_tree_driver_targets(
            mat.node_tree,
            old_mesh,
            new_mesh,
            old_armature,
            new_armature,
            visited,
        )

    if updated:
        print(f"Retargeted {updated} material node driver target(s) on '{obj.name}'")
    return updated


def _hhp5_asset_weight_rename_plan(obj, source_mesh, target_mesh):
    """Validate directional deform-group renames without changing any data."""
    if (
        not source_mesh or not target_mesh
        or source_mesh == target_mesh
        or source_mesh.type != 'MESH' or target_mesh.type != 'MESH'
        or source_mesh.get("HHP Version", 4) != 4
        or target_mesh.get("HHP Version") != 5
        or not obj or obj.type != 'MESH'
        or obj == source_mesh or obj == target_mesh
        or obj.data.users > 1 or obj.library or obj.data.library
    ):
        return []

    backup = bpy.data.collections.get("HHP4 Backup")
    if backup and obj.name in backup.all_objects:
        return []

    source_arm = next((m.object for m in source_mesh.modifiers
                       if m.type == 'ARMATURE' and m.object), None)
    target_arm = next((m.object for m in target_mesh.modifiers
                       if m.type == 'ARMATURE' and m.object), None)
    asset_mod = next((m for m in obj.modifiers if m.type == 'ARMATURE'), None)
    if (
        not source_arm or not target_arm or source_arm == target_arm
        or not asset_mod or asset_mod.object != source_arm
    ):
        return []

    plan = []
    reserved = set(obj.vertex_groups.keys())
    for old_name, new_name in _HHP4_TO_HHP5_VERTEX_GROUP_NAMES.items():
        if obj.vertex_groups.get(old_name) is None:
            continue
        old_bone = source_arm.data.bones.get(old_name)
        new_bone = target_arm.data.bones.get(new_name)
        old_target_bone = target_arm.data.bones.get(old_name)
        if (
            not old_bone or not old_bone.use_deform
            or not new_bone or not new_bone.use_deform
            or (old_target_bone and old_target_bone.use_deform)
        ):
            raise ValueError(
                f"Cannot verify HHP5 deform mapping '{old_name}' -> "
                f"'{new_name}' for '{obj.name}'. Check the character rigs."
            )
        if obj.vertex_groups.get(new_name) is not None:
            source_named_bone = source_arm.data.bones.get(new_name)
            if source_named_bone and source_named_bone.use_deform:
                raise ValueError(
                    f"'{obj.name}' has weights for both deform bones '{old_name}' "
                    f"and '{new_name}' on its source rig. Choose the intended "
                    "deformation groups before converting this asset."
                )
            # Some HHP4 clothes retain their original Daz groups alongside
            # the renamed groups that actually deform them. Preserve those
            # inactive groups and their references without merging weights.
            base = 'HHP4 Stored - ' + new_name
            backup_name = base
            suffix = 1
            while backup_name in reserved or backup_name in target_arm.data.bones:
                backup_name = f'{base}.{suffix:03d}'
                suffix += 1
            reserved.add(backup_name)
            plan.append((new_name, backup_name))
        plan.append((old_name, new_name))
    if plan and (not obj.is_editable or not obj.data.is_editable or obj.mode != 'OBJECT'):
        raise ValueError(
            f"'{obj.name}' must have editable mesh data and be in Object Mode "
            "before converting its HHP5 vertex groups."
        )
    return plan


def _preflight_hhp5_asset_weight_renames(ctx):
    """Check all transfer categories before Update to Active changes the scene."""
    target = ctx.active_object
    if not target or target.type != 'MESH' or target.get("HHP Version") != 5:
        return
    for source in ctx.selected_objects:
        if source == target or source.type != 'MESH' or source.get("HHP Version", 4) != 4:
            continue
        seen = set()
        for category, collections in source_asset_collection_groups(source).items():
            for collection in collections:
                is_eyes = category == "Eyes"
                for obj in collection.all_objects:
                    if obj.as_pointer() in seen:
                        continue
                    seen.add(obj.as_pointer())
                    if is_eyes and "Genesis8FemaleEyelashes.Shape" in obj.name:
                        continue
                    _hhp5_asset_weight_rename_plan(obj, source, target)


def _retarget_asset_vertex_group_references(obj, renamed):
    """Keep this asset's masks, simulation settings, shape keys and drivers valid."""
    holders = list(obj.modifiers) + list(obj.particle_systems)
    for modifier in obj.modifiers:
        for attribute in ("settings", "collision_settings"):
            settings = getattr(modifier, attribute, None)
            if settings:
                holders.append(settings)
    keys = obj.data.shape_keys
    if keys:
        holders.extend(keys.key_blocks)
    for holder in holders:
        for prop in holder.bl_rna.properties:
            if (prop.type == 'STRING' and not prop.is_readonly
                    and prop.identifier.startswith("vertex_group")):
                name = getattr(holder, prop.identifier)
                if name in renamed:
                    setattr(holder, prop.identifier, renamed[name])

    # Only paths that address this asset's group collection are rewritten.
    replacements = {
        'vertex_groups["' + bpy.utils.escape_identifier(old) + '"]':
        'vertex_groups["' + bpy.utils.escape_identifier(new) + '"]'
        for old, new in renamed.items()
    }
    for owner in (obj, obj.data, keys):
        animation = getattr(owner, "animation_data", None) if owner else None
        if not animation:
            continue
        for curve in animation.drivers:
            for variable in curve.driver.variables:
                for target in variable.targets:
                    if target.id != obj and target.id != obj.data:
                        continue
                    path = target.data_path
                    for old, new in replacements.items():
                        if path.startswith(old) and (len(path) == len(old) or path[len(old)] in ".["):
                            target.data_path = new + path[len(old):]
                            break


def _rename_hhp5_asset_weight_groups(obj, source_mesh, target_mesh):
    """Rename verified asset groups, retaining every original weight and index."""
    plan = _hhp5_asset_weight_rename_plan(obj, source_mesh, target_mesh)
    if not plan:
        return 0
    # Linked/shared meshes are excluded by the plan; never make them single-user.
    renamed = dict(plan)
    for old_name, new_name in plan:
        obj.vertex_groups[old_name].name = new_name
    _retarget_asset_vertex_group_references(obj, renamed)
    print(f"Renamed {len(plan)} HHP4 vertex groups for HHP5 on '{obj.name}'")
    return len(plan)


def apply_remapping_to_collections(
    collections,
    source_mesh,
    target_mesh,
    sd_target,
    preserved_surface_deform_targets=None,
):
    """Apply armature and surface deform remapping to collections"""
    if not source_mesh or not target_mesh or not sd_target:
        return
    preserved_surface_deform_targets = preserved_surface_deform_targets or set()

    # Get the armature from the target mesh (active mesh), not the source mesh
    arm_mod = next((m for m in target_mesh.modifiers if m.type == 'ARMATURE' and m.object), None)
    if not arm_mod:
        print(f"No armature modifier found on target mesh '{target_mesh.name}'")
        return

    arm_obj = arm_mod.object
    source_arm_obj = next((m.object for m in source_mesh.modifiers if m.type == 'ARMATURE' and m.object), None)
    print(f"Using armature: {arm_obj.name}")
    arm_count = 0
    sd_smart_count = 0
    constraint_count = 0
    lattice_childof_count = 0
    shapekey_driver_retarget_count = 0
    material_driver_retarget_count = 0
    character_collection = get_top_parent_collection(target_mesh)

    def process_collection(collection, is_hair_collection=False, is_eyes_collection=False, is_char_specific_collection=False):
        nonlocal arm_count, sd_smart_count, constraint_count, lattice_childof_count, shapekey_driver_retarget_count, material_driver_retarget_count
        for obj in collection.objects:
            # Retarget material/node group drivers that still reference the source mesh/armature.
            material_driver_retarget_count += retarget_material_node_driver_targets(
                obj,
                source_mesh,
                target_mesh,
                source_arm_obj,
                arm_obj
            )

            if obj.type == 'MESH':
                # Skip Genesis8FemaleEyelashes objects in eyes collections
                if is_eyes_collection and "Genesis8FemaleEyelashes.Shape" in obj.name:
                    print(f"Skipping Genesis8FemaleEyelashes object: {obj.name}")
                    continue

                # Apply armature modifier
                existing_arm_mod = next((m for m in obj.modifiers if m.type == 'ARMATURE'), None)
                if existing_arm_mod:
                    _rename_hhp5_asset_weight_groups(obj, source_mesh, target_mesh)
                    existing_arm_mod.object = arm_obj
                    arm_count += 1

                # Retarget shapekey drivers that still reference the source mesh/armature
                shapekey_driver_retarget_count += retarget_shapekey_driver_targets(
                    obj,
                    source_mesh,
                    target_mesh,
                    source_arm_obj,
                    arm_obj
                )

                # Retarget only when the active character contains an
                # equivalent mesh. Otherwise preserve the selected
                # character asset's original Surface Deform target.
                for mod in obj.modifiers:
                    if mod.type == 'SURFACE_DEFORM':
                        original_target = mod.target
                        if not original_target or not character_collection:
                            continue
                        if original_target.as_pointer() in preserved_surface_deform_targets:
                            continue

                        base_name = get_base_object_name(original_target.name)
                        equivalent_target = find_object_in_hierarchy(character_collection, base_name)
                        if (
                            equivalent_target
                            and equivalent_target.type == 'MESH'
                            and equivalent_target != original_target
                        ):
                            mod.target = equivalent_target
                            sd_smart_count += 1

                # Apply object constraint remapping
                for constraint in obj.constraints:
                    if hasattr(constraint, 'target') and constraint.target:
                        constraint.target = target_mesh
                        constraint_count += 1
            elif obj.type == 'LATTICE' and is_char_specific_collection:
                # Retarget Child Of constraints on lattices in Char Specific Proxies to the active armature
                for constraint in obj.constraints:
                    if getattr(constraint, 'type', None) == 'CHILD_OF':
                        constraint.target = arm_obj
                        lattice_childof_count += 1

        # Process child collections recursively
        for child in collection.children:
            # Check if child collection is a hair or eyes collection
            child_is_hair = child.name.lower().startswith("hair")
            child_is_eyes = child.name.lower().startswith("eyes")
            child_is_char_specific = child.name.lower().startswith("char specific proxies") or is_char_specific_collection
            process_collection(child, is_hair_collection or child_is_hair, is_eyes_collection or child_is_eyes, child_is_char_specific)

    for collection in collections:
        # Check if this collection is a hair or eyes collection
        is_hair = collection.name.lower().startswith("hair")
        is_eyes = collection.name.lower().startswith("eyes")
        is_char_specific = collection.name.lower().startswith("char specific proxies")
        process_collection(collection, is_hair, is_eyes, is_char_specific)

    # Print report
    report_parts = []
    if arm_count > 0:
        report_parts.append(f"{arm_count} Armature modifiers")
    if sd_smart_count > 0:
        report_parts.append(f"{sd_smart_count} Surface Deform modifiers to equivalent targets")
    if constraint_count > 0:
        report_parts.append(f"{constraint_count} Object constraints to '{target_mesh.name}'")
    if lattice_childof_count > 0:
        report_parts.append(f"{lattice_childof_count} Lattice 'Child Of' constraints to armature '{arm_obj.name}'")
    if shapekey_driver_retarget_count > 0:
        report_parts.append(f"{shapekey_driver_retarget_count} shapekey driver target(s) retargeted")
    if material_driver_retarget_count > 0:
        report_parts.append(f"{material_driver_retarget_count} material node driver target(s) retargeted")

    if report_parts:
        print(f"Remapped {', '.join(report_parts)}")


def find_primary_fullbody_proxy(source_mesh):
    """Find 'Deform Proxy - Primary (Fullbody)' meshes in the same parent collection as the source mesh"""
    if not source_mesh:
        return []

    # Get the top parent collection of the source mesh
    parent_collection = get_top_parent_collection(source_mesh)
    if not parent_collection:
        return []

    # Find all objects in this collection and its children that match the criteria
    primary_fullbody_candidates = []

    def search_collection(collection):
        for obj in collection.objects:
            if (obj.type == 'MESH' and
                "Deform Proxy" in obj.name and
                "Primary" in obj.name and
                "Fullbody" in obj.name):
                primary_fullbody_candidates.append(obj)

        # Search in child collections
        for child in collection.children:
            search_collection(child)

    # Start the search from the parent collection
    search_collection(parent_collection)

    return primary_fullbody_candidates


def get_surface_deform_target(active_obj):
    """Get the proper surface deform target following the same logic as append_clothing.py"""
    # First, check for "Deform Proxy - Primary (Fullbody)" objects in the same parent collection
    primary_fullbody_candidates = find_primary_fullbody_proxy(active_obj)

    if len(primary_fullbody_candidates) == 1:
        return primary_fullbody_candidates[0]
    elif len(primary_fullbody_candidates) > 1:
        # Sort candidates: primary fullbody proxies by numerical order
        def get_sort_key(obj):
            import re
            match = re.search(r'(\d+)', obj.name)
            num = int(match.group(1)) if match else 0
            return num

        primary_fullbody_candidates.sort(key=get_sort_key)
        return primary_fullbody_candidates[0]  # Use the first sorted one

    # If no primary fullbody proxies found, fall back to meshes sharing the same mesh data
    data_candidates = [
        o for o in bpy.context.scene.objects
        if o.type == 'MESH' and o.data == active_obj.data and o != active_obj
    ]

    if len(data_candidates) >= 1:
        return data_candidates[0]

    # Fallback to the active object itself
    return active_obj


def transfer_unavailable_modifiers(ctx):
    """Transfer unavailable MASK modifiers from selected meshes to active mesh"""
    active_obj = ctx.active_object
    selected_objects = [obj for obj in ctx.selected_objects if obj != active_obj and obj.type == 'MESH']

    if not selected_objects:
        print("No source mesh objects for mask modifier transfer.")
        return

    if not active_obj or active_obj.type != 'MESH':
        print("Active object is not a mesh.")
        return

    # Function to find modifier by name and type
    def find_modifier(obj, name, mod_type):
        return next((mod for mod in obj.modifiers if mod.name == name and mod.type == mod_type), None)

    # Process each selected source mesh
    for source_obj in selected_objects:
        if not source_obj.modifiers:
            print(f"No modifiers on {source_obj.name}.")
            continue

        # Collect only MASK modifiers from the source object in the correct order
        source_mask_modifiers = [mod for mod in source_obj.modifiers if mod.type == 'MASK']

        if not source_mask_modifiers:
            print(f"No mask modifiers on {source_obj.name}.")
            continue

        existing_modifiers = {mod.name: mod for mod in active_obj.modifiers}  # Store current modifiers in target

        # Copy missing mask modifiers from the source object to the active object
        for source_mod in source_mask_modifiers:
            if not find_modifier(active_obj, source_mod.name, source_mod.type):
                # Create a new modifier in the active object
                new_mod = active_obj.modifiers.new(name=source_mod.name, type=source_mod.type)

                # Copy properties from the source object's modifier
                for prop in dir(source_mod):
                    if not prop.startswith("_") and not callable(getattr(source_mod, prop)):
                        try:
                            setattr(new_mod, prop, getattr(source_mod, prop))
                        except AttributeError:
                            pass  # Some attributes can't be copied, like links to other objects or specific data

                print(f"Copied mask modifier '{source_mod.name}' from {source_obj.name} to {active_obj.name}")

        # Now reorder the mask modifiers to match the source order (only affecting mask modifiers)
        current_modifiers = active_obj.modifiers[:]
        new_order = []

        # First, add all non-mask modifiers in their current order
        for mod in current_modifiers:
            if mod.type != 'MASK':
                new_order.append(mod)

        # Then add mask modifiers from the source in the correct order
        for source_mod in source_mask_modifiers:
            target_mod = find_modifier(active_obj, source_mod.name, source_mod.type)
            if target_mod:
                new_order.append(target_mod)

        # Add any remaining mask modifiers that were in the target but not in the source
        for mod in current_modifiers:
            if mod.type == 'MASK' and mod not in new_order:
                new_order.append(mod)

        # Reorder the active object's modifiers to match the new_order list
        for i, mod in enumerate(new_order):
            current_index = active_obj.modifiers.find(mod.name)
            if current_index != i:
                active_obj.modifiers.move(current_index, i)
                print(f"Reordered mask modifier '{mod.name}' to position {i+1} on {active_obj.name}")

    print("Mask modifier transfer complete.")


def move_mask_modifiers_after_subdivision(ctx):
    """Move all mask modifiers on the active mesh just above (before) the last subdivision modifier"""
    active_obj = ctx.active_object

    if not active_obj or active_obj.type != 'MESH':
        print("Active object is not a mesh.")
        return

    if not active_obj.modifiers:
        print("No modifiers on active object.")
        return

    # Find the last subdivision modifier
    last_subsurf_idx = -1
    for i, mod in enumerate(active_obj.modifiers):
        if mod.type == 'SUBSURF':
            last_subsurf_idx = i

    if last_subsurf_idx == -1:
        print("No subdivision surface modifiers found - mask modifiers will remain in their current positions.")
        return

    # Find all mask modifiers and store their data in their current order
    mask_modifier_data = []
    for i, mod in enumerate(active_obj.modifiers):
        if mod.type == 'MASK':
            # Store modifier data before removal
            mod_data = {
                'name': mod.name,
                'position': i
            }
            # Store all copyable properties
            mod_data['properties'] = {}
            for prop in dir(mod):
                if not prop.startswith("_") and not callable(getattr(mod, prop)):
                    try:
                        mod_data['properties'][prop] = getattr(mod, prop)
                    except (AttributeError, TypeError):
                        pass  # Some attributes can't be accessed

            mask_modifier_data.append(mod_data)

    if not mask_modifier_data:
        print("No mask modifiers found on active object.")
        return

    # Remove all mask modifiers from their current positions (in reverse order to avoid index issues)
    for mod_data in reversed(mask_modifier_data):
        # Find the modifier by name and remove it
        for mod in active_obj.modifiers:
            if mod.name == mod_data['name'] and mod.type == 'MASK':
                current_idx = active_obj.modifiers.find(mod.name)
                active_obj.modifiers.remove(mod)
                print(f"Temporarily removed mask modifier '{mod_data['name']}' from position {current_idx + 1}")
                break

    # Find the new position of the last subdivision modifier (may have shifted)
    last_subsurf_idx = -1
    for i, mod in enumerate(active_obj.modifiers):
        if mod.type == 'SUBSURF':
            last_subsurf_idx = i

    # Insert all mask modifiers just before the last subdivision modifier (maintaining their original order)
    for i, mod_data in enumerate(mask_modifier_data):
        # Insert each mask modifier at the target position
        target_position = last_subsurf_idx + i
        new_mask = active_obj.modifiers.new(name=mod_data['name'], type='MASK')

        # Copy all properties from the stored data
        for prop, value in mod_data['properties'].items():
            try:
                setattr(new_mask, prop, value)
            except (AttributeError, TypeError):
                pass  # Some attributes can't be set

        # Move the new modifier to the correct position
        current_pos = active_obj.modifiers.find(new_mask.name)
        active_obj.modifiers.move(current_pos, target_position)
        print(f"Moved mask modifier '{mod_data['name']}' to position {target_position + 1} (before last subdivision)")

    print("Mask modifier positioning complete.")


def remove_pubic_hair_drivers(collections):
    """Remove drivers from pubic hair mesh objects in the given collections"""
    if not collections:
        return

    pubic_hair_objects = []

    def find_pubic_hair_objects(collection):
        """Recursively find objects with 'Pubic Hair' in their name"""
        for obj in collection.objects:
            if obj.type == 'MESH' and "Pubic Hair" in obj.name:
                pubic_hair_objects.append(obj)

        # Search in child collections
        for child in collection.children:
            find_pubic_hair_objects(child)

    # Search all collections for pubic hair objects
    for collection in collections:
        find_pubic_hair_objects(collection)

    # Remove drivers from found objects
    for obj in pubic_hair_objects:
        drivers_removed = 0

        # Remove drivers for hide_viewport and hide_render properties
        for property_name in ['hide_viewport', 'hide_render']:
            try:
                obj.driver_remove(property_name)
                drivers_removed += 1
                print(f"Removed {property_name} driver from pubic hair object '{obj.name}'")
            except:
                # Driver doesn't exist or couldn't be removed
                pass

        if drivers_removed > 0:
            print(f"Removed {drivers_removed} drivers from pubic hair object '{obj.name}'")

    if pubic_hair_objects:
        print(f"Processed {len(pubic_hair_objects)} pubic hair objects for driver removal")


def create_mask_modifier_drivers(ctx):
    """Create drivers for mask modifiers based on custom object properties"""
    active_obj = ctx.active_object

    if not active_obj or active_obj.type != 'MESH':
        print("Active object is not a mesh.")
        return

    if not active_obj.modifiers:
        print("No modifiers on active object.")
        return

    # Find all mask modifiers
    mask_modifiers = []
    for mod in active_obj.modifiers:
        if mod.type == 'MASK':
            mask_modifiers.append(mod)

    if not mask_modifiers:
        print("No mask modifiers found on active object.")
        return

    # Look for matching custom properties and create drivers
    drivers_created = 0

    for mask_mod in mask_modifiers:
        # Check if this is a standard named mask modifier (starting with "(HHP) Mask - ")
        if not mask_mod.name.startswith("(HHP) Mask - "):
            continue

        # Extract the mask name (remove "(HHP) " prefix)
        mask_name = mask_mod.name.replace("(HHP) ", "")

        # Look for corresponding custom property
        if mask_name in active_obj.keys():
            prop_value = active_obj[mask_name]

            # Check if it's a boolean property
            if isinstance(prop_value, (bool, int, float)):
                print(f"Found matching property '{mask_name}' for modifier '{mask_mod.name}'")

                # Add drivers for both viewport and render visibility
                for state in ['show_viewport', 'show_render']:
                    # Always try to remove any existing driver first
                    try:
                        mask_mod.driver_remove(state)
                    except:
                        pass

                    # Create new driver
                    driver = mask_mod.driver_add(state).driver
                    driver.type = 'SCRIPTED'

                    # Clear any existing variables
                    for var in driver.variables:
                        driver.variables.remove(var)

                    # Create new variable
                    var = driver.variables.new()
                    var.name = 'mask_toggle'
                    var.type = 'SINGLE_PROP'

                    target = var.targets[0]
                    target.id_type = 'OBJECT'
                    target.id = active_obj
                    target.data_path = f'["{mask_name}"]'

                    # Set expression to use the variable directly
                    driver.expression = 'mask_toggle'

                drivers_created += 1
                print(f"Created drivers for mask modifier '{mask_mod.name}' using property '{mask_name}'")
            else:
                print(f"Property '{mask_name}' exists but is not a boolean/numeric type - skipping")
        else:
            print(f"No matching property found for mask modifier '{mask_mod.name}' (looking for '{mask_name}')")

    if drivers_created > 0:
        print(f"Created drivers for {drivers_created} mask modifiers.")
    else:
        print("No mask modifier drivers were created.")


def _eyeball_rotation_reference_rest(armature, bone_name):
    """Return the rest rotation used by a supported eye Copy Rotation setup.

    Only an unambiguous, full world-space replacement within the same rig
    is supported. Other constraint setups retain the original transfer.
    """
    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return None

    active_constraints = [
        constraint for constraint in pose_bone.constraints
        if not constraint.mute and constraint.influence > 0.0
    ]
    if len(active_constraints) != 1:
        return None

    constraint = active_constraints[0]
    if (
        constraint.type != 'COPY_ROTATION'
        or constraint.influence != 1.0
        or constraint.mix_mode != 'REPLACE'
        or constraint.owner_space != 'WORLD'
        or constraint.target_space != 'WORLD'
        or constraint.target != armature
        or not all((constraint.use_x, constraint.use_y, constraint.use_z))
        or any((constraint.invert_x, constraint.invert_y, constraint.invert_z))
    ):
        return None

    reference = armature.data.bones.get(constraint.subtarget)
    if reference is None or reference.name == bone_name:
        return None
    return reference.matrix_local.to_quaternion().normalized().to_matrix()


def _eyeball_align_transfer_rest_matrix(source_armature, destination_armature, bone_name):
    """Keep the fitted pivot and neutral deformation across eye-driver rolls.

    Matching or unsupported rotation references return the original source
    matrix unchanged, preserving existing same-rig transfers.
    """
    source_bone = source_armature.data.bones.get(bone_name)
    if source_bone is None:
        return None
    source_matrix = source_bone.matrix_local.copy()
    source_reference = _eyeball_rotation_reference_rest(source_armature, bone_name)
    destination_reference = _eyeball_rotation_reference_rest(destination_armature, bone_name)
    if source_reference is None or destination_reference is None:
        return source_matrix

    # Ignore floating-point noise and leave compatible rigs exactly unchanged.
    if max(
        abs(source_reference[row][column] - destination_reference[row][column])
        for row in range(3) for column in range(3)
    ) < 1.0e-5:
        return source_matrix

    source_rotation = source_matrix.to_quaternion().normalized().to_matrix()
    # Neutral skinning is reference @ rest^-1. Preserve that deformation:
    # new_rest = old_rest @ old_reference^-1 @ new_reference.
    # The order matters for fitted eye rotations that do not commute with roll.
    destination_rotation = source_rotation @ source_reference.transposed() @ destination_reference
    result = destination_rotation.to_4x4()
    result.translation = source_matrix.translation
    return result


def copy_eyeball_align_bone_rest_from_selected_to_active(ctx):
    """Copy the rest pose (base position) of the eyeball align bones
    from the selected mesh's armature to the active mesh's armature.

    Bones considered:
      - "head eyeball left (Align)"
      - "head eyeball right (Align)"

    If a bone doesn't exist on either side, it is ignored. Compensate for
    different eye-driver rest orientations without changing fitted pivots.
    """
    active_mesh = ctx.active_object
    if not active_mesh or active_mesh.type != 'MESH':
        return

    # Find one source mesh (any selected mesh other than active)
    source_meshes = [o for o in ctx.selected_objects if o != active_mesh and o.type == 'MESH']
    if not source_meshes:
        return

    def get_armature_for_mesh(mesh_obj):
        for mod in getattr(mesh_obj, 'modifiers', []) or []:
            if getattr(mod, 'type', None) == 'ARMATURE' and getattr(mod, 'object', None) and getattr(mod.object, 'type', None) == 'ARMATURE':
                return mod.object
        return None

    def to_mode_arg(prev_mode):
        return 'EDIT' if str(prev_mode).startswith('EDIT') else str(prev_mode)

    dest_arm = get_armature_for_mesh(active_mesh)
    if not dest_arm:
        return

    bone_names = [
        "head eyeball left (Align)",
        "head eyeball right (Align)",
    ]

    # Try each selected source until one works
    for source_mesh in source_meshes:
        src_arm = get_armature_for_mesh(source_mesh)
        if not src_arm:
            continue

        # Collect source rest matrices for bones that exist
        bone_matrices = {}
        for name in bone_names:
            src_bone = src_arm.data.bones.get(name)
            if src_bone is not None:
                bone_matrices[name] = _eyeball_align_transfer_rest_matrix(src_arm, dest_arm, name)

        if not bone_matrices:
            # This source doesn't have the required bones
            continue

        # Ensure destination has at least one of these bones
        if not any(dest_arm.data.bones.get(name) is not None for name in bone_matrices.keys()):
            continue

        # Switch to edit mode on the destination armature and apply
        prev_active = ctx.view_layer.objects.active
        prev_mode = ctx.mode
        try:
            # Go to OBJECT mode first
            try:
                if ctx.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

            # Activate destination armature
            if ctx.view_layer.objects.active != dest_arm:
                ctx.view_layer.objects.active = dest_arm
            try:
                dest_arm.select_set(True)
            except Exception:
                pass

            # Enter EDIT mode for the armature
            try:
                bpy.ops.object.mode_set(mode='EDIT')
            except Exception as e:
                print(f"Failed to enter EDIT mode for armature '{dest_arm.name}': {e}")
                # Restore active object before returning
                if ctx.view_layer.objects.active != prev_active:
                    ctx.view_layer.objects.active = prev_active
                try:
                    bpy.ops.object.mode_set(mode=to_mode_arg(prev_mode))
                except Exception:
                    pass
                return

            edit_bones = dest_arm.data.edit_bones
            applied_count = 0
            for name, mat in bone_matrices.items():
                eb = edit_bones.get(name)
                if eb is not None:
                    try:
                        eb.matrix = mat
                        applied_count += 1
                    except Exception as e:
                        print(f"Failed to copy rest pose for '{name}': {e}")

            print(f"Copied rest pose for {applied_count} eyeball align bone(s) to '{dest_arm.name}'")
        finally:
            # Return to OBJECT mode and restore previous active and mode
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

            if ctx.view_layer.objects.active != prev_active:
                ctx.view_layer.objects.active = prev_active
            try:
                bpy.ops.object.mode_set(mode=to_mode_arg(prev_mode))
            except Exception:
                pass

        # Done after first suitable source
        return

    # No selected source with required bones was found
    return


def transfer_identity_data(ctx, transfer_shader_data=True, excluded_properties=()):
    """Copy character data from the selected donor to the active mesh."""
    active = ctx.active_object

    # 1) zero all shape-key values on the active mesh
    zero_shape_keys(active)

    # 2) copy missing custom props from all other selected meshes
    sources = [o for o in ctx.selected_objects if o != active and o.type == 'MESH']
    if not sources:
        print("⚠️ No source meshes selected.")
        return False

    for src in sources:
        copy_missing_custom_props(src, active, excluded_properties)

    print("✅ Done: shape-keys zeroed on active, missing custom props (with UI & override flags) copied.")

    # Continue with additional operations
    transfer_existing_custom_properties(ctx, excluded_properties)
    if transfer_shader_data:
        transfer_effects_shader_group_values(ctx)
    transfer_vertex_groups(ctx)
    transfer_unavailable_shape_keys(ctx)
    transfer_shape_key_min_max(ctx)
    transfer_shape_key_values_and_masks(ctx)
    copy_delta_corrective_shapekey_drivers(ctx)
    transfer_missing_vertex_colors(ctx)
    transfer_missing_uv_maps(ctx)
    transfer_unavailable_modifiers(ctx)
    move_mask_modifiers_after_subdivision(ctx)
    create_mask_modifier_drivers(ctx)

    # Copy eyeball align bones' rest poses from the selected mesh's armature to the active mesh's armature
    copy_eyeball_align_bone_rest_from_selected_to_active(ctx)

    # Whole-material transfers already carry the donor shader values and trees.
    if not transfer_shader_data:
        return True

    # Sync WRAP head images from selected mesh to active mesh
    def _find_material_by_substring(obj, substring):
        if not obj or not obj.data or not getattr(obj.data, "materials", None):
            return None
        for mat in obj.data.materials:
            if mat and substring in mat.name:
                return mat
        return None

    def _find_group_node_by_tree_name(material, tree_name_substring):
        if not material or not material.use_nodes or not material.node_tree:
            return None
        for node in material.node_tree.nodes:
            if getattr(node, "type", None) == 'GROUP' and getattr(node, "node_tree", None):
                if tree_name_substring in node.node_tree.name:
                    return node
        return None

    def _find_image_node_by_names(node_tree, preferred_names):
        if not node_tree:
            return None
        # Prefer exact name matches first
        for name in preferred_names:
            for node in node_tree.nodes:
                if getattr(node, "type", None) == 'TEX_IMAGE' and node.name == name:
                    return node
        # Fallback: try matching by label hints
        for node in node_tree.nodes:
            if getattr(node, "type", None) == 'TEX_IMAGE':
                label = getattr(node, "label", "") or ""
                if any(hint in (node.name or "") for hint in ("Albedo", "Base Color", "Diffuse")):
                    return node
                if any(hint in label for hint in ("Albedo", "Base Color", "Diffuse")):
                    return node
        return None

    def _get_armature_for_mesh(mesh_obj):
        for mod in getattr(mesh_obj, "modifiers", []) or []:
            if getattr(mod, "type", None) == 'ARMATURE' and getattr(mod, "object", None) and getattr(mod.object, "type", None) == 'ARMATURE':
                return mod.object
        return None

    def _strip_blender_enum_suffix(name):
        return re.sub(r"\.\d{3}$", "", name or "")

    def _name_active_node_tree_copy(source_tree, copied_tree):
        active_name = _strip_blender_enum_suffix(getattr(source_tree, "name", ""))
        if not active_name or not copied_tree:
            return

        try:
            copied_tree.name = f"{active_name}__HHP_ACTIVE_COPY_TEMP__"
        except Exception:
            pass

        existing_tree = bpy.data.node_groups.get(active_name)
        if existing_tree and existing_tree != copied_tree:
            try:
                existing_tree.name = f"{active_name}.001"
            except Exception as e:
                print(f"Failed to enumerate source node tree '{active_name}': {e}")

        try:
            copied_tree.name = active_name
        except Exception as e:
            print(f"Failed to name active node tree copy '{active_name}': {e}")

    def _copy_node_tree_hierarchy(node_tree, copied_trees=None):
        if not node_tree:
            return None
        if copied_trees is None:
            copied_trees = {}

        tree_key = node_tree.as_pointer() if hasattr(node_tree, "as_pointer") else id(node_tree)
        if tree_key in copied_trees:
            return copied_trees[tree_key]

        try:
            copied_tree = node_tree.copy()
        except Exception as e:
            print(f"Failed to copy node tree '{node_tree.name}': {e}")
            return None

        copied_trees[tree_key] = copied_tree
        _name_active_node_tree_copy(node_tree, copied_tree)

        for node in getattr(copied_tree, "nodes", []) or []:
            if getattr(node, "type", None) != 'GROUP' or not getattr(node, "node_tree", None):
                continue

            nested_copy = _copy_node_tree_hierarchy(node.node_tree, copied_trees)
            if nested_copy:
                try:
                    node.node_tree = nested_copy
                except Exception as e:
                    print(f"Failed to relink nested node tree '{node.name}': {e}")

        return copied_tree

    def _retarget_driver_targets_on_node_trees(node_tree, old_mesh, new_mesh, old_armature, new_armature, visited=None):
        if not node_tree:
            return 0
        if visited is None:
            visited = set()

        tree_key = node_tree.as_pointer() if hasattr(node_tree, "as_pointer") else id(node_tree)
        if tree_key in visited:
            return 0
        visited.add(tree_key)

        replacements = (
            (old_mesh, new_mesh),
            (getattr(old_mesh, "data", None), getattr(new_mesh, "data", None) if new_mesh else None),
            (old_armature, new_armature),
            (getattr(old_armature, "data", None), getattr(new_armature, "data", None) if new_armature else None),
        )

        updated = 0
        anim = getattr(node_tree, "animation_data", None)
        if anim and getattr(anim, "drivers", None):
            for fcurve in anim.drivers:
                driver = getattr(fcurve, "driver", None)
                if not driver or not getattr(driver, "variables", None):
                    continue

                for var in driver.variables:
                    for target in getattr(var, "targets", []) or []:
                        target_id = getattr(target, "id", None)
                        if target_id is None:
                            continue

                        for old_id, new_id in replacements:
                            if old_id and new_id and target_id == old_id:
                                try:
                                    target.id = new_id
                                    updated += 1
                                except Exception as e:
                                    print(f"Failed to retarget driver in node tree '{node_tree.name}': {e}")
                                break

        for node in getattr(node_tree, "nodes", []) or []:
            if getattr(node, "type", None) == 'GROUP' and getattr(node, "node_tree", None):
                updated += _retarget_driver_targets_on_node_trees(
                    node.node_tree,
                    old_mesh,
                    new_mesh,
                    old_armature,
                    new_armature,
                    visited,
                )

        return updated

    # Perform the sync
    active_obj = ctx.active_object
    sources = [o for o in ctx.selected_objects if o != active_obj and o.type == 'MESH']
    if sources:
        source_obj = sources[0]
        mat_name_sub = "Genesis 8 Female_Face"
        group_tree_name_sub = "(HHP) Mix WRAP head"

        src_mat = _find_material_by_substring(source_obj, mat_name_sub)
        tgt_mat = _find_material_by_substring(active_obj, mat_name_sub)

        if src_mat and tgt_mat:
            src_group = _find_group_node_by_tree_name(src_mat, group_tree_name_sub)
            tgt_group = _find_group_node_by_tree_name(tgt_mat, group_tree_name_sub)

            if src_group and tgt_group and getattr(src_group, "node_tree", None) and getattr(tgt_group, "node_tree", None):
                # Base color image nodes
                base_names = ["Image Texture - Head Albedo", "Image Texture"]
                # Normal map image nodes
                normal_names = ["Image Texture - Head Normal", "Image Texture.001"]

                src_base_node = _find_image_node_by_names(src_group.node_tree, base_names)
                src_normal_node = _find_image_node_by_names(src_group.node_tree, normal_names)

                tgt_base_node = _find_image_node_by_names(tgt_group.node_tree, base_names)
                tgt_normal_node = _find_image_node_by_names(tgt_group.node_tree, normal_names)

                # Assign images if both sides have nodes and source has an image
                if src_base_node and getattr(src_base_node, "image", None) and tgt_base_node:
                    tgt_base_node.image = src_base_node.image
                    print("Synchronized WRAP head Base Color image to active mesh")
                if src_normal_node and getattr(src_normal_node, "image", None) and tgt_normal_node:
                    tgt_normal_node.image = src_normal_node.image
                    print("Synchronized WRAP head Normal map image to active mesh")
            else:
                print("Could not find WRAP head node groups on both meshes - skipping image sync")
        else:
            print("Could not find required 'Genesis 8 Female_Face' materials on both meshes - skipping image sync")
    else:
        print("No source mesh found to sync WRAP head images from - skipping image sync")

    # Copy '(BS) Channel Inverter' slider values (Invert R/G/B) from selected to active
    def _find_group_node_by_tree_name_in_tree(node_tree, tree_name_substring):
        if not node_tree:
            return None
        for node in node_tree.nodes:
            if getattr(node, "type", None) == 'GROUP' and getattr(node, "node_tree", None):
                if tree_name_substring in node.node_tree.name:
                    return node
        return None

    def _find_inverter_node_for_object(obj):
        inverter_sub = "(BS) Channel Inverter"
        # Try inside the WRAP head group first if present on the face material
        face_mat = _find_material_by_substring(obj, "Genesis 8 Female_Face")
        if face_mat:
            wrap_group = _find_group_node_by_tree_name(face_mat, "(HHP) Mix WRAP head")
            if wrap_group and getattr(wrap_group, "node_tree", None):
                node = _find_group_node_by_tree_name_in_tree(wrap_group.node_tree, inverter_sub)
                if node:
                    return node
        # Fallback: scan all materials' top-level node trees
        if obj and obj.data and getattr(obj.data, "materials", None):
            for mat in obj.data.materials:
                if mat and mat.use_nodes and mat.node_tree:
                    node = _find_group_node_by_tree_name_in_tree(mat.node_tree, inverter_sub)
                    if node:
                        return node
        return None

    if sources:
        source_obj = sources[0]
        src_inv = _find_inverter_node_for_object(source_obj)
        tgt_inv = _find_inverter_node_for_object(active_obj)
        if src_inv and tgt_inv:
            for socket_name in ("Invert (R)", "Invert (G)", "Invert (B)"):
                src_socket = src_inv.inputs.get(socket_name) if hasattr(src_inv, "inputs") else None
                tgt_socket = tgt_inv.inputs.get(socket_name) if hasattr(tgt_inv, "inputs") else None
                if src_socket and tgt_socket and hasattr(src_socket, "default_value") and hasattr(tgt_socket, "default_value"):
                    try:
                        tgt_socket.default_value = src_socket.default_value
                        print(f"Synchronized Channel Inverter '{socket_name}' to active mesh")
                    except Exception as e:
                        print(f"Failed to set Channel Inverter '{socket_name}' on active: {e}")
        else:
            print("Could not locate '(BS) Channel Inverter' nodes on both meshes - skipping value sync")

    # Copy SSS Mask slider and relink to the source '(HHP) Mix SSS Mask' node tree
    sss_group_tree_sub = "(HHP) Mix SSS Mask"
    sss_socket_name = "SSS Mask (Weight)"
    if sources:
        source_obj = sources[0]
        src_face_mat = _find_material_by_substring(source_obj, "Genesis 8 Female_Face")
        tgt_face_mat = _find_material_by_substring(active_obj, "Genesis 8 Female_Face")
        if src_face_mat and tgt_face_mat:
            src_sss_node = _find_group_node_by_tree_name(src_face_mat, sss_group_tree_sub)
            tgt_sss_node = _find_group_node_by_tree_name(tgt_face_mat, sss_group_tree_sub)
            if src_sss_node and tgt_sss_node:
                # 1) Transfer the instance input value
                src_sock = src_sss_node.inputs.get(sss_socket_name) if hasattr(src_sss_node, "inputs") else None
                tgt_sock = tgt_sss_node.inputs.get(sss_socket_name) if hasattr(tgt_sss_node, "inputs") else None
                if src_sock and tgt_sock and hasattr(src_sock, "default_value") and hasattr(tgt_sock, "default_value"):
                    try:
                        tgt_sock.default_value = src_sock.default_value
                        print("Synchronized 'SSS Mask (Weight)' value to active mesh")
                    except Exception as e:
                        print(f"Failed to set 'SSS Mask (Weight)' on active: {e}")
                else:
                    print("SSS Mask sockets not found on one of the nodes - skipping value copy")

                # 2) Relink the target node to the source's node group datablock
                if getattr(src_sss_node, "node_tree", None):
                    try:
                        tgt_sss_node.node_tree = src_sss_node.node_tree
                        print("Relinked active mesh SSS Mask node to source '(HHP) Mix SSS Mask' node tree")
                    except Exception as e:
                        print(f"Failed to relink SSS Mask node tree on active: {e}")
                else:
                    print("Source SSS Mask node has no node_tree - skipping relink")
            else:
                print("Could not find '(HHP) Mix SSS Mask' group node on both meshes - skipping SSS sync")
        else:
            print("Could not find 'Genesis 8 Female_Face' materials on both meshes for SSS sync")

    # Copy active mesh character attribute groups from the source, then retarget their drivers.
    if sources:
        source_obj = sources[0]
        source_armature = _get_armature_for_mesh(source_obj)
        target_armature = _get_armature_for_mesh(active_obj)
        char_attrib_groups = (
            ("Genesis 8 Female_Face", "(HHP) Char attribs_Face"),
            ("Genesis 8 Female_Torso", "(HHP) Char attribs_Torso"),
            ("Genesis 8 Female_Arms", "(HHP) Char attribs_Arms"),
            ("Genesis 8 Female_Legs", "(HHP) Char attribs_Legs"),
        )

        for mat_name_sub, group_tree_sub in char_attrib_groups:
            src_mat = _find_material_by_substring(source_obj, mat_name_sub)
            tgt_mat = _find_material_by_substring(active_obj, mat_name_sub)
            if not src_mat or not tgt_mat:
                print(f"Could not find '{mat_name_sub}' materials on both meshes for character attribute sync")
                continue

            src_group_node = _find_group_node_by_tree_name(src_mat, group_tree_sub)
            tgt_group_node = _find_group_node_by_tree_name(tgt_mat, group_tree_sub)
            if not src_group_node or not tgt_group_node:
                print(f"Could not find '{group_tree_sub}' group node on both meshes - skipping character attribute sync")
                continue

            if not getattr(src_group_node, "node_tree", None):
                print(f"Source '{group_tree_sub}' group node has no node_tree - skipping copy")
                continue

            copied_tree = _copy_node_tree_hierarchy(src_group_node.node_tree)
            if not copied_tree:
                print(f"Could not copy '{group_tree_sub}' node tree - skipping character attribute sync")
                continue

            try:
                tgt_group_node.node_tree = copied_tree
                retargeted = _retarget_driver_targets_on_node_trees(
                    copied_tree,
                    source_obj,
                    active_obj,
                    source_armature,
                    target_armature,
                )
                print(f"Copied active mesh '{group_tree_sub}' node tree from source")
                if retargeted:
                    print(f"Retargeted {retargeted} driver target(s) inside '{group_tree_sub}' to active mesh")
            except Exception as e:
                print(f"Failed to copy '{group_tree_sub}' node tree on active: {e}")

    # Copy Utility Maps_HHP (Face) values: 'Sneer Contrast' and 'Brow Compression Contrast'
    util_tree_sub = "Utility Maps_HHP (Face)"
    util_socket_names = ("Sneer Contrast", "Brow Compression Contrast")
    if sources:
        source_obj = sources[0]
        src_face_mat = _find_material_by_substring(source_obj, "Genesis 8 Female_Face")
        tgt_face_mat = _find_material_by_substring(active_obj, "Genesis 8 Female_Face")
        if src_face_mat and tgt_face_mat:
            src_util_node = _find_group_node_by_tree_name(src_face_mat, util_tree_sub)
            tgt_util_node = _find_group_node_by_tree_name(tgt_face_mat, util_tree_sub)
            if src_util_node and tgt_util_node:
                for socket_name in util_socket_names:
                    src_sock = src_util_node.inputs.get(socket_name) if hasattr(src_util_node, "inputs") else None
                    tgt_sock = tgt_util_node.inputs.get(socket_name) if hasattr(tgt_util_node, "inputs") else None
                    if src_sock and tgt_sock and hasattr(src_sock, "default_value") and hasattr(tgt_sock, "default_value"):
                        try:
                            tgt_sock.default_value = src_sock.default_value
                            print(f"Synchronized Utility Maps '{socket_name}' to active mesh")
                        except Exception as e:
                            print(f"Failed to set Utility Maps '{socket_name}' on active: {e}")
                    else:
                        print(f"Utility Maps socket '{socket_name}' missing on one of the nodes - skipping")
            else:
                print("Could not find 'Utility Maps_HHP (Face)' group node on both meshes - skipping Utility Maps sync")
        else:
            print("Could not find 'Genesis 8 Female_Face' materials on both meshes for Utility Maps sync")

    return True


_HHP4_TO_HHP5_VERTEX_GROUP_NAMES = {
    "Metatarsals.l": "lMetatarsals",
    "Toe.l": "lToe",
    "SmallToe4.l": "lSmallToe4",
    "SmallToe4_2.l": "lSmallToe4_2",
    "SmallToe3.l": "lSmallToe3",
    "SmallToe3_2.l": "lSmallToe3_2",
    "SmallToe2.l": "lSmallToe2",
    "SmallToe2_2.l": "lSmallToe2_2",
    "SmallToe1.l": "lSmallToe1",
    "SmallToe1_2.l": "lSmallToe1_2",
    "BigToe.l": "lBigToe",
    "BigToe_2.l": "lBigToe_2",
    "Metatarsals.r": "rMetatarsals",
    "Toe.r": "rToe",
    "SmallToe4.r": "rSmallToe4",
    "SmallToe4_2.r": "rSmallToe4_2",
    "SmallToe3.r": "rSmallToe3",
    "SmallToe3_2.r": "rSmallToe3_2",
    "SmallToe2.r": "rSmallToe2",
    "SmallToe2_2.r": "rSmallToe2_2",
    "SmallToe1.r": "rSmallToe1",
    "SmallToe1_2.r": "rSmallToe1_2",
    "BigToe.r": "rBigToe",
    "BigToe_2.r": "rBigToe_2"
}
