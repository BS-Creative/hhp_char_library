"""Finish HHP point-cache bakes during playback without changing selection."""

import bpy

_BAKING = False
_PENDING_PLAYBACK_RESUMES = set()


def playing_window(scene):
    return next((window for window in bpy.context.window_manager.windows
                 if window.scene == scene and window.screen is not None
                 and window.screen.is_animation_playing), None)


def bake_completed_caches(context, entries):
    """Bake only caches whose end frame is reached; never rebake existing bakes."""
    global _BAKING
    if _BAKING:
        return 0, []
    failures = []
    successful_bakes = 0
    seen = set()
    _BAKING = True
    try:
        for obj, cache, end_frame in entries:
            pointer = cache.as_pointer()
            if (pointer in seen or cache.is_baked or cache.is_baking
                    or context.scene.frame_current != end_frame
                    or obj.name not in context.view_layer.objects):
                continue
            seen.add(pointer)
            try:
                with context.temp_override(object=obj, active_object=obj, point_cache=cache):
                    result = bpy.ops.ptcache.bake_from_cache()
                if 'FINISHED' not in result or not cache.is_baked:
                    failures.append((obj.name, "Current cache could not be baked"))
                else:
                    successful_bakes += 1
            except RuntimeError as exc:
                failures.append((obj.name, str(exc)))
    finally:
        _BAKING = False
    return successful_bakes, failures


def resume_playback_after_bake(window):
    """After auto-bake finalization, restart audio-synced playback at scene start."""
    window_pointer = window.as_pointer()
    scene = window.scene
    if window_pointer in _PENDING_PLAYBACK_RESUMES:
        return
    _PENDING_PLAYBACK_RESUMES.add(window_pointer)

    def restart_from_scene_start():
        try:
            if window.screen is None or window.scene != scene:
                return None
            with bpy.context.temp_override(window=window):
                scene.sync_mode = 'AUDIO_SYNC'
                if window.screen.is_animation_playing:
                    # Do not restore the frame where the previous playback began.
                    bpy.ops.screen.animation_cancel(restore_frame=False)
                scene.frame_set(scene.frame_start)
                bpy.ops.screen.animation_play(reverse=False)
        except ReferenceError:
            pass
        except RuntimeError as exc:
            print(f"HHP auto bake playback restart failed: {exc}")
        finally:
            _PENDING_PLAYBACK_RESUMES.discard(window_pointer)
        return None

    # Defer until frame-change handlers and cache finalization have returned.
    bpy.app.timers.register(restart_from_scene_start, first_interval=0.0)


def bake_at_playback_end(scene, collect_caches):
    """Match ragdoll autobake: playback only, in the playing window's scope."""
    if _BAKING:
        return
    window = playing_window(scene)
    if window is None:
        return
    was_playing = bool(window.screen and window.screen.is_animation_playing)
    with bpy.context.temp_override(window=window):
        successful_bakes, failures = bake_completed_caches(
            bpy.context,
            list(collect_caches(bpy.context)),
        )
        if successful_bakes and not failures:
            # This path is auto-bake-only. Manual/current/offline bake operators keep
            # the user's existing playback sync preference.
            scene.sync_mode = 'AUDIO_SYNC'

            # bake_from_cache can stop playback after this handler returns.
            # Defer the explicit stop/rewind/play sequence one UI tick, and only
            # restart playback that was running when auto-bake began.
            if was_playing:
                resume_playback_after_bake(window)
    for name, reason in failures:
        print(f"HHP auto bake failed for {name}: {reason}")
