"""Neutral animation channels for the generated control rig, excluding mechanisms."""
import bpy
from mathutils import Matrix


def create_base_layer(arm):
    from . import hhp_rigify as core
    data = core.manifest(arm)
    names = list(dict.fromkeys(data['native_bones'] + data['controls'] + list(data['bindings'].values())))
    bones = [arm.pose.bones[n] for n in names]
    saved = core._state(arm)
    arm.animation_data_create()
    ad = arm.animation_data
    old_action, old_slot = ad.action, ad.action_slot
    new_action = track = None
    try:
        if ad.action is not None:
            ad.action_slot = None
        ad.action = new_action = bpy.data.actions.new('Preview_BaseLayer')
        for pb in bones:
            neutral = data.get('neutral_basis', {}).get(pb.name)
            pb.matrix_basis = Matrix(neutral) if neutral else Matrix.Identity(4)
            for name in saved['bones'][pb.name]:
                # Kinematic and parent choices stay in the user's current mode.
                if name in {'IK_FK', 'FK_IK', 'pole_vector'} or 'parent' in name.lower():
                    continue
                default = pb.id_properties_ui(name).as_dict().get('default')
                if isinstance(default, (bool, int, float)):
                    pb[name] = default
            rotation = ('rotation_quaternion' if pb.rotation_mode == 'QUATERNION' else
                        'rotation_axis_angle' if pb.rotation_mode == 'AXIS_ANGLE' else 'rotation_euler')
            for frame in {bpy.context.scene.frame_start, bpy.context.scene.frame_end}:
                for path in ('location', rotation, 'scale'):
                    pb.keyframe_insert(path, frame=frame, group=pb.name)
                for name in saved['bones'][pb.name]:
                    pb.keyframe_insert('["' + bpy.utils.escape_identifier(name) + '"]', frame=frame, group=pb.name)
        slot = ad.action_slot
        if ad.action is not None:
            ad.action_slot = None
        ad.action = None
        track = ad.nla_tracks.new()
        track.name = new_action.name
        strip = track.strips.new(new_action.name, bpy.context.scene.frame_start, new_action)
        strip.action_slot = slot
        strip.blend_type = 'REPLACE'
        strip.extrapolation = 'HOLD'
        return new_action
    except Exception:
        if track is not None:
            ad.nla_tracks.remove(track)
        if new_action is not None:
            if ad.action is not None:
                ad.action_slot = None
            ad.action = None
            bpy.data.actions.remove(new_action)
        raise
    finally:
        if ad.action is not None:
            ad.action_slot = None
        ad.action = old_action
        if old_action is not None:
            ad.action_slot = old_slot
        core._restore(arm, saved)
