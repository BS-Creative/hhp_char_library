"""Compatibility entry point for the optional bundled generated UI."""
from . import rigify_compat_loader as _loader


def register():
    return _loader.register()


def unregister():
    return _loader.unregister()


def is_registered():
    return _loader.is_available() and _loader.require_ui().is_registered()


def __getattr__(name):
    # Preserve the former generated module interface for integrations/tests.
    if name.startswith('__'):
        raise AttributeError(name)
    if not _loader.is_available():
        if name in ('GENERATED_CLASSES', '_OWNED_CLASSES'):
            return ()
        raise AttributeError(name)
    return getattr(_loader.require_ui(), name)
