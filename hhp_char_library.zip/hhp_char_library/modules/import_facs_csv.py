import bpy
import csv
import os
import numpy as np
from math import exp, ceil

from bpy_extras.io_utils import ImportHelper
from .action_fcurve_compat import ensure_fcurve_for_datablock
from .action_fcurve_compat import set_fcurve_handles_auto_clamped
from bpy.props import (
    BoolProperty,
    StringProperty,
    CollectionProperty,
    EnumProperty,
    IntProperty,
    FloatProperty,
)
from bpy.types import Operator

# Mapping for the 52 relevant shapekeys (default behavior)
CUSTOM_52_MAPPING = {
    "EyeBlinkLeft": "eyeBlinkLeft",
    "EyeLookDownLeft": "eyeLookDownLeft",
    "EyeLookInLeft": "eyeLookInLeft",
    "EyeLookOutLeft": "eyeLookOutLeft",
    "EyeLookUpLeft": "eyeLookUpLeft",
    "EyeSquintLeft": "eyeSquintLeft",
    "EyeWideLeft": "eyeWideLeft",
    "EyeBlinkRight": "eyeBlinkRight",
    "EyeLookDownRight": "eyeLookDownRight",
    "EyeLookInRight": "eyeLookInRight",
    "EyeLookOutRight": "eyeLookOutRight",
    "EyeLookUpRight": "eyeLookUpRight",
    "EyeSquintRight": "eyeSquintRight",
    "EyeWideRight": "eyeWideRight",
    "JawForward": "jawForward",
    "JawLeft": "jawLeft",
    "JawRight": "jawRight",
    "JawOpen": "jawOpen",
    "MouthClose": "mouthClose",
    "MouthFunnel": "mouthFunnel",
    "MouthPucker": "mouthPucker",
    "MouthLeft": "mouthLeft",
    "MouthRight": "mouthRight",
    "MouthSmileLeft": "mouthSmileLeft",
    "MouthSmileRight": "mouthSmileRight",
    "MouthFrownLeft": "mouthFrownLeft",
    "MouthFrownRight": "mouthFrownRight",
    "MouthDimpleLeft": "mouthDimpleLeft",
    "MouthDimpleRight": "mouthDimpleRight",
    "MouthStretchLeft": "mouthStretchLeft",
    "MouthStretchRight": "mouthStretchRight",
    "MouthRollLower": "mouthRollLower",
    "MouthRollUpper": "mouthRollUpper",
    "MouthShrugLower": "mouthShrugLower",
    "MouthShrugUpper": "mouthShrugUpper",
    "MouthPressLeft": "mouthPressLeft",
    "MouthPressRight": "mouthPressRight",
    "MouthLowerDownLeft": "mouthLowerDownLeft",
    "MouthLowerDownRight": "mouthLowerDownRight",
    "MouthUpperUpLeft": "mouthUpperUpLeft",
    "MouthUpperUpRight": "mouthUpperUpRight",
    "BrowDownLeft": "browDownLeft",
    "BrowDownRight": "browDownRight",
    "BrowInnerUp": "browInnerUp",
    "BrowOuterUpLeft": "browOuterUpLeft",
    "BrowOuterUpRight": "browOuterUpRight",
    "CheekPuff": "cheekPuff",
    "CheekSquintLeft": "cheekSquintLeft",
    "CheekSquintRight": "cheekSquintRight",
    "NoseSneerLeft": "noseSneerLeft",
    "NoseSneerRight": "noseSneerRight",
    "TongueOut": "tongueOut",
}

# List for the original 61 shapekeys
ORIGINAL_61_LIST = [
    "EyeBlinkLeft",
    "EyeLookDownLeft",
    "EyeLookInLeft",
    "EyeLookOutLeft",
    "EyeLookUpLeft",
    "EyeSquintLeft",
    "EyeWideLeft",
    "EyeBlinkRight",
    "EyeLookDownRight",
    "EyeLookInRight",
    "EyeLookOutRight",
    "EyeLookUpRight",
    "EyeSquintRight",
    "EyeWideRight",
    "JawForward",
    "JawRight",
    "JawLeft",
    "JawOpen",
    "MouthClose",
    "MouthFunnel",
    "MouthPucker",
    "MouthRight",
    "MouthLeft",
    "MouthSmileLeft",
    "MouthSmileRight",
    "MouthFrownLeft",
    "MouthFrownRight",
    "MouthDimpleLeft",
    "MouthDimpleRight",
    "MouthStretchLeft",
    "MouthStretchRight",
    "MouthRollLower",
    "MouthRollUpper",
    "MouthShrugLower",
    "MouthShrugUpper",
    "MouthPressLeft",
    "MouthPressRight",
    "MouthLowerDownLeft",
    "MouthLowerDownRight",
    "MouthUpperUpLeft",
    "MouthUpperUpRight",
    "BrowDownLeft",
    "BrowDownRight",
    "BrowInnerUp",
    "BrowOuterUpLeft",
    "BrowOuterUpRight",
    "CheekPuff",
    "CheekSquintLeft",
    "CheekSquintRight",
    "NoseSneerLeft",
    "NoseSneerRight",
    "TongueOut",
    "HeadYaw",
    "HeadPitch",
    "HeadRoll",
    "LeftEyeYaw",
    "LeftEyePitch",
    "LeftEyeRoll",
    "RightEyeYaw",
    "RightEyePitch",
    "RightEyeRoll",
]


def gaussian_filter_weights(x: np.ndarray, sigma_frames: float = 1.97):
    """
    Apply a one-dimensional Gaussian blur to each blend-shape track.
    
    x : 2-D array of shape (frames, channels)
    returns filtered array of the same shape
    """
    R = int(ceil(4.0 * sigma_frames))       # kernel radius
    offs = np.arange(-R, R+1, dtype=np.float32)
    kernel = np.exp(-(offs**2) / (2 * sigma_frames**2))
    kernel /= kernel.sum()                  # normalise

    # pad by repeating edge values (SciPy mode='nearest')
    pad_left  = np.repeat(x[0:1], R, axis=0)
    pad_right = np.repeat(x[-1:], R, axis=0)
    x_padded  = np.vstack([pad_left, x, pad_right])

    # 1-D convolution along time for every channel
    y = np.array([np.sum(kernel[:,None] * 
                         x_padded[i : i+2*R+1], axis=0)
                  for i in range(x.shape[0])], dtype=x.dtype)
    return y

def resample_animation(action, facs_names, weight_mat, import_fps, scene_fps):
    """Resamples the animation data from import_fps to scene_fps."""
    if not weight_mat or import_fps == scene_fps:
        return weight_mat

    import_duration = len(weight_mat) / import_fps
    num_scene_frames = int(import_duration * scene_fps)
    resampled_weights = []

    for i in range(num_scene_frames):
        time_in_scene = i / scene_fps
        import_frame_float = time_in_scene * import_fps
        import_frame_index = int(import_frame_float)

        if import_frame_index >= len(weight_mat) - 1:
            resampled_weights.append(weight_mat[-1])
            continue
        
        # Linear interpolation between two frames
        t = import_frame_float - import_frame_index
        frame1_weights = weight_mat[import_frame_index]
        frame2_weights = weight_mat[import_frame_index + 1]
        
        interpolated_frame = [
            (1 - t) * w1 + t * w2 for w1, w2 in zip(frame1_weights, frame2_weights)
        ]
        resampled_weights.append(interpolated_frame)
        
    return resampled_weights


class HHP_OT_Import_FACS_CSV(bpy.types.Operator, ImportHelper):
    bl_idname = "hhp.import_facs_csv"
    bl_label = "Import FACS CSV"
    bl_description = (
        "Import CSV files from Live Link Face (iPhone app) as shapekey animations for HHP characters."
    )
    bl_options = {'REGISTER', 'UNDO'}

    # File selection properties
    files: CollectionProperty(
        type=bpy.types.OperatorFileListElement,
        options={'HIDDEN', 'SKIP_SAVE'}
    )
    directory: StringProperty(
        subtype='DIR_PATH',
        options={'HIDDEN'}
    )
    filename_ext = ".csv"
    filter_glob: StringProperty(
        default="*.csv",
        options={'HIDDEN'},
    )
    
    # Renamed option for using original 61 keys (off by default)
    import_original_61: BoolProperty(
        name="Import Livelink data as SK (Advanced)",
        description="If enabled, imports the original 61 LiveLink motion shapekeys format. Use this for advanced compatibility with LiveLink CSV exports.",
        default=False,
    )
    
    # Import mode
    import_mode: EnumProperty(
        name="Import Mode",
        description="Select which shapekeys to import",
        items=[
            ('FULL', "Full Face", "Import full shapekey animation from the CSV file"),
            ('MOUTH_ONLY', "Lip Sync Only", "Import only mouth-related shapekey animation")
        ],
        default='FULL'
    )
    
    fps_handling: EnumProperty(
        name="Framerate Handling",
        description="How to handle the framerate of the imported file",
        items=[
            ('SCENE', "Match to Scene", "Resample animation to match the scene's framerate"),
            ('IMPORTED', "Match to Imported", "Change the scene's framerate to match the imported file")
        ],
        default='SCENE'
    )

    update_scene_frame_range: BoolProperty(
        name="Match Frame Range to Imported",
        description="Update the scene's start/end frames to match the imported file",
        default=False,
    )
    apply_to_active_mesh: BoolProperty(
        name="Apply to Active Mesh",
        description="Automatically apply the imported action to the active mesh as a shapekey animation",
        default=True,
    )
    import_to_active_action: BoolProperty(
        name="Import to Active Action",
        description="Import keyframes directly into the active shapekey action on the current frame instead of creating a new action",
        default=False,
    )
    
    # Filtering properties
    use_filtering: BoolProperty(
        name="Filter (Smooth)",
        description="Apply Gaussian filtering to smooth the imported animation data",
        default=True,
    )
    
    filtering_factor: FloatProperty(
        name="Filtering Factor",
        description="Smoothing intensity (0% = no filtering, 100% = full filtering, >100% = extra smoothing)",
        default=100.0,
        min=0.0,
        soft_max=100.0,
        subtype='PERCENTAGE',
    )

    def execute(self, context):
        if not self.files:
            self.report({'ERROR'}, "No files selected")
            return {'CANCELLED'}
            
        actions_created = []
        for file in self.files:
            filepath = os.path.join(self.directory, file.name)
            action_name = self.process_csv_file(context, filepath)
            if action_name:
                actions_created.append(action_name)
        
        if actions_created:
            self.report({'INFO'}, f"Successfully imported {len(actions_created)} FACS action(s)")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, "No actions were imported")
            return {'CANCELLED'}
    
    def process_csv_file(self, context, filepath):
        """Process a single CSV file and return the action name if successful"""
        if not os.path.exists(filepath):
            self.report({'ERROR'}, f"File not found: {filepath}")
            return None
            
        try:
            with open(filepath, "r", newline="") as f:
                reader = csv.reader(f)
                rows = list(reader)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to read CSV from {os.path.basename(filepath)}: {e}")
            return None

        if not rows or len(rows) < 2:
            self.report({'ERROR'}, f"CSV file {os.path.basename(filepath)} does not contain enough data")
            return None

        export_fps = 60  # Default value
        if rows:
            first_header = rows[0][0]
            if "FPS=" in first_header:
                try:
                    fps_str = first_header.split('FPS=')[1].split(',')[0]
                    export_fps = float(fps_str)
                    rows[0][0] = "Timecode" # Clean up header for processing
                except (ValueError, IndexError):
                    pass # Keep default if parsing fails

        # If the first data row's first cell isn't numeric, assume it's a timestamp column and skip it.
        try:
            float(rows[1][0])
        except ValueError:
            rows = [row[1:] for row in rows]

        # The CSV header contains the shapekey names.
        csv_header = rows[0]
        filtered_indices = []
        facs_names = []

        # Decide which mapping to use based on the import_original_61 checkbox.
        if self.import_original_61:
            # Use the original 61 list.
            allowed_keys = set(ORIGINAL_61_LIST)
            if self.import_mode == 'MOUTH_ONLY':
                allowed_keys = {k for k in allowed_keys if k.startswith("Jaw") or k.startswith("Mouth") or k == "CheekPuff"}
            # Identity mapping (header name remains the same).
            mapping = {k: k for k in allowed_keys}
        else:
            # Use the custom 52 mapping.
            mapping = CUSTOM_52_MAPPING.copy()
            if self.import_mode == 'MOUTH_ONLY':
                mapping = {k: v for k, v in mapping.items() if k.startswith("Jaw") or k.startswith("Mouth") or k == "CheekPuff"}

        # Build filtered_indices from the CSV header.
        for idx, header_name in enumerate(csv_header):
            if header_name in mapping:
                sk_name = mapping[header_name]
                filtered_indices.append((idx, sk_name))
                facs_names.append(sk_name)


        if not filtered_indices:
            self.report({'ERROR'}, "No relevant shapekey columns found in CSV")
            return None

        # Build the weight matrix for only the filtered columns.
        weight_mat = []
        for row in rows[1:]:
            try:
                weights = []
                for idx, _ in filtered_indices:
                    if idx < len(row) and row[idx] != "":
                        weights.append(float(row[idx]))
                    else:
                        weights.append(0.0)
            except Exception as e:
                self.report({'ERROR'}, f"Invalid data in CSV file {os.path.basename(filepath)}: {e}")
                return None
            weight_mat.append(weights)



        # Determine if we should import to an active action on an active mesh
        using_active_action = False
        active_action = None
        if (self.apply_to_active_mesh and self.import_to_active_action and 
            context.active_object and context.active_object.type == 'MESH'):
            obj = context.active_object
            if (obj.data.shape_keys and 
                obj.data.shape_keys.animation_data and 
                obj.data.shape_keys.animation_data.action):
                active_action = obj.data.shape_keys.animation_data.action
                using_active_action = True
                action_name = active_action.name
                action = active_action

        if not using_active_action:
            base_name = os.path.basename(filepath)
            name_no_ext = os.path.splitext(base_name)[0]
            if self.import_mode == 'MOUTH_ONLY':
                action_name = f"(FACS-LipSync) HHP_{name_no_ext}"
            else:
                action_name = f"(FACS) HHP_{name_no_ext}"
            
            original_name = action_name
            counter = 1
            while action_name in bpy.data.actions:
                action_name = f"{original_name}.{counter:03d}"
                counter += 1

            action = bpy.data.actions.new(name=action_name)
            action.use_fake_user = True
            
        # Framerate handling
        scene_fps = context.scene.render.fps
        if self.fps_handling == 'SCENE':
            weight_mat = resample_animation(action, facs_names, weight_mat, export_fps, scene_fps)

        # Apply filtering if enabled.
        #
        # Important: to match the JSON importer's "feel" (and your reference CSV that is smoothed
        # at 60 FPS), we apply smoothing AFTER any resampling-to-scene step. Also, we interpret the
        # smoothing strength as a time constant equivalent to "1.97 frames at 60 FPS", so the
        # smoothing looks consistent across different source/export FPS.
        if self.use_filtering and self.filtering_factor > 0.0 and len(weight_mat) > 1:
            # Target FPS for smoothing: if we resampled to the scene, smooth at scene fps.
            # Otherwise, smooth at the imported/export fps.
            target_fps = float(scene_fps if self.fps_handling == 'SCENE' else export_fps)
            base_sigma_at_60fps = 1.97
            sigma_frames = (base_sigma_at_60fps * (target_fps / 60.0)) * (self.filtering_factor / 100.0)

            if sigma_frames > 0.01:  # Only filter if sigma is meaningful
                weight_array = np.array(weight_mat, dtype=np.float32)
                filtered_array = gaussian_filter_weights(weight_array, sigma_frames)
                weight_mat = filtered_array.tolist()

        if using_active_action:
            start_frame = context.scene.frame_current
        else:
            start_frame = 1

        # Blender 5 requires datablock-aware curve creation, and the action must be assigned
        # to the datablock before ensuring curves. We use the active mesh's Shape Keys datablock.
        needs_datablock_curves = hasattr(action, "fcurve_ensure_for_datablock")
        shape_keys = None
        prev_action = None
        active_mesh = context.active_object if (context.active_object and context.active_object.type == 'MESH') else None

        if needs_datablock_curves:
            if not active_mesh:
                self.report({'ERROR'}, "Blender 5 requires an active mesh to import FACS shapekey actions.")
                return None
            if not active_mesh.data.shape_keys:
                active_mesh.shape_key_add(name="Basis")
            shape_keys = active_mesh.data.shape_keys
            if not shape_keys.animation_data:
                shape_keys.animation_data_create()
            prev_action = shape_keys.animation_data.action
            shape_keys.animation_data.action = action

        try:
            # Create/update F-Curves for each filtered shapekey.
            skipped = []
            touched_fcurves = []
            for col_order, (_col_idx, sk_name) in enumerate(filtered_indices):
                data_path = f'key_blocks["{sk_name}"].value'
                try:
                    if needs_datablock_curves:
                        fcurve = ensure_fcurve_for_datablock(action, shape_keys, data_path, index=0)
                    else:
                        # Legacy Blender: datablock is ignored in the compat helper.
                        fcurve = ensure_fcurve_for_datablock(action, None, data_path, index=0)
                except Exception:
                    skipped.append(sk_name)
                    continue

                touched_fcurves.append(fcurve)
                for frame_idx, frame_weights in enumerate(weight_mat):
                    frame_num = start_frame + frame_idx
                    weight = frame_weights[col_order]
                    fcurve.keyframe_points.insert(frame=frame_num, value=weight, options={'FAST'})

            # Make imported curves smooth like Blender 4.x used to do automatically.
            for fc in touched_fcurves:
                set_fcurve_handles_auto_clamped(fc)

            # Best-effort: also try the operator (may fail without a Graph Editor context).
            try:
                bpy.ops.action.handle_type(type='AUTO_CLAMPED')
            except Exception:
                pass

            if skipped:
                self.report({'WARNING'}, f"Skipped {len(skipped)} shapekey tracks that don't exist on the active mesh.")
        finally:
            # Restore previous action if we only assigned temporarily (i.e., we're not applying it).
            if needs_datablock_curves and shape_keys and shape_keys.animation_data and not using_active_action and not self.apply_to_active_mesh:
                shape_keys.animation_data.action = prev_action

        # Apply the action to the active mesh if requested and not already using active action
        if self.apply_to_active_mesh and context.active_object and context.active_object.type == 'MESH' and not using_active_action:
            obj = context.active_object
            if not obj.data.shape_keys:
                obj.shape_key_add(name="Basis")
            if not obj.data.shape_keys.animation_data:
                obj.data.shape_keys.animation_data_create()
            current_action = None
            if obj.data.shape_keys.animation_data.action:
                current_action = obj.data.shape_keys.animation_data.action
            obj.data.shape_keys.animation_data.action = action
            self.report({'INFO'}, f"Applied action '{action_name}' to {obj.name}")

        # Optionally update scene settings (only from the last file if multiple)
        if filepath == os.path.join(self.directory, self.files[-1].name):
            scene = context.scene
            if not using_active_action:
                if self.fps_handling == 'IMPORTED':
                    scene.render.fps = round(export_fps)
                if self.update_scene_frame_range:
                    scene.frame_start = start_frame
                    scene.frame_end = start_frame + len(weight_mat) - 1

        if using_active_action:
            self.report({'INFO'}, f"Imported into existing action '{action_name}' starting at frame {start_frame}")
        
        return action_name

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.prop(self, "import_mode", expand=True)

        layout.separator()

        
        col = layout.column()
        col.prop(self, "fps_handling", expand=True)

        row = layout.row()
        row.enabled = not self.import_to_active_action
        row.prop(self, "update_scene_frame_range")

        # Add renamed import_original_61 checkbox
        layout.prop(self, "import_original_61")
        
        layout.separator()
        has_active_mesh = (context.active_object and context.active_object.type == 'MESH')
        
        row = layout.row()
        row.enabled = has_active_mesh
        row.prop(self, "apply_to_active_mesh")
        
        if not has_active_mesh:
            layout.label(text="A mesh must be active for this option", icon='INFO')
            
        has_active_action = False
        if has_active_mesh and self.apply_to_active_mesh:
            obj = context.active_object
            if (obj.data.shape_keys and 
                obj.data.shape_keys.animation_data and 
                obj.data.shape_keys.animation_data.action):
                has_active_action = True
        
        if not has_active_action and self.import_to_active_action:
            self.import_to_active_action = False
        
        row = layout.row()
        row.enabled = has_active_action
        row.prop(self, "import_to_active_action")
        
        if self.import_to_active_action:
            layout.label(text="Match Frame Range to Imported is disabled", icon='INFO')
        
        # Filtering section
        layout.separator()
        filter_box = layout.box()
        filter_box.prop(self, "use_filtering")
        
        if self.use_filtering:
            slider_row = filter_box.row()
            slider_row.prop(self, "filtering_factor", slider=True)

def register():
    bpy.utils.register_class(HHP_OT_Import_FACS_CSV)


def unregister():
    bpy.utils.unregister_class(HHP_OT_Import_FACS_CSV)
