import bpy
import csv
import os

from bpy_extras.io_utils import ImportHelper
from bpy.props import (
    BoolProperty,
    StringProperty,
    CollectionProperty,
    EnumProperty,
    IntProperty,
)
from bpy.types import Operator

# Mapping for the 52 relevant shapekeys (default behavior)
CUSTOM_52_MAPPING = {}

# List for the original 61 shapekeys
ORIGINAL_61_LIST = []


class HHP_OT_Import_FACS_CSV(bpy.types.Operator, ImportHelper):
    bl_idname = "hhp.import_facs_csv"
    bl_label = "Import FACS CSV"
    bl_description = (
        "Import CSV files from Live Link Face (iPhone app) as shapekey animations for HHP characters."
    )
    bl_options = {'REGISTER', 'UNDO'}

    # File selection properties
    files: CollectionProperty(
        type=bpy.types.OperatorFileListElement,
        options={'HIDDEN', 'SKIP_SAVE'}
    )
    directory: StringProperty(
        subtype='DIR_PATH',
        options={'HIDDEN'}
    )
    filename_ext = ".csv"
    filter_glob: StringProperty(
        default="*.csv",
        options={'HIDDEN'},
    )
    
    # Renamed option for using original 61 keys (off by default)
    import_original_61: BoolProperty(
        name="Import Livelink data as SK (Advanced)",
        description="If enabled, imports the original 61 LiveLink motion shapekeys format. Use this for advanced compatibility with LiveLink CSV exports.",
        default=False,
    )
    
    # Import mode
    import_mode: EnumProperty(
        name="Import Mode",
        description="Select which shapekeys to import",
        items=[
            ('FULL', "Full Face", "Import full shapekey animation from the CSV file"),
            ('MOUTH_ONLY', "Lip Sync Only", "Import only mouth-related shapekey animation")
        ],
        default='FULL'
    )

    # ImportHelper adds a "filepath" property.
    update_scene_fps: BoolProperty(
        name="Match Scene FPS",
        description="Update the scene's FPS to match the CSV file",
        default=False,
    )
    update_scene_frame_range: BoolProperty(
        name="Match Scene Frame Range",
        description="Update the scene's start/end frames to match the CSV file",
        default=False,
    )
    apply_to_active_mesh: BoolProperty(
        name="Apply to Active Mesh",
        description="Automatically apply the imported action to the active mesh as a shapekey animation",
        default=True,
    )
    import_to_active_action: BoolProperty(
        name="Import to Active Action",
        description="Import keyframes directly into the active shapekey action on the current frame instead of creating a new action",
        default=False,
    )

    def execute(self, context):
        return {'FINISHED'}
    
    def process_csv_file(self, context, filepath):
        return None

    def draw(self, context):
        pass

def register():
    bpy.utils.register_class(HHP_OT_Import_FACS_CSV)


def unregister():
    bpy.utils.unregister_class(HHP_OT_Import_FACS_CSV) 