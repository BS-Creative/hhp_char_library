"""Native Rigify controls integrated with the unchanged Daz deformation skeleton."""
import json
from contextlib import contextmanager
from functools import wraps
from itertools import chain
import bpy
from bpy.app.handlers import persistent
from mathutils import Matrix, Vector

_PAUSE_ACTION = '_hhp_preview_action'
_PAUSE_STATE = '_hhp_preview_state'
_KEYING_PAUSED = set()
_VISIBILITY_MAPS = {}
_VISIBILITY_SIGNATURES = {}
_VISIBILITY_PENDING = set()


def _pause_preview_action(arm):
    """Release an object or armature-data slot; shared Action channels stay intact."""
    ad = arm.animation_data
    if not ad or not ad.action or not ad.action_slot:
        return False
    if _PAUSE_STATE in arm:
        _resume_preview_action(arm)
    arm[_PAUSE_ACTION] = ad.action
    arm[_PAUSE_STATE] = json.dumps(dict(slot=ad.action_slot_handle,
                                      frame=bpy.context.scene.frame_current_final))
    ad.action_slot = None
    return True


def _resume_preview_action(arm):
    """Restore the released slot without assigning it to a different Action."""
    if _PAUSE_STATE not in arm:
        return False
    state = json.loads(arm[_PAUSE_STATE])
    action = arm.get(_PAUSE_ACTION)
    ad = arm.animation_data
    restored = False
    if ad and ad.action == action and ad.action_slot_handle == 0:
        slot = next((slot for slot in action.slots if slot.handle == state['slot']), None)
        if slot:
            ad.action_slot = slot
            restored = True
    del arm[_PAUSE_STATE]
    if _PAUSE_ACTION in arm:
        del arm[_PAUSE_ACTION]
    if restored:
        arm.update_tag()
    return restored


@contextmanager
def _keying_action_slot(arm):
    """Use the original slot for explicit key insertion, then keep posing paused."""
    ad = arm.animation_data
    temporary = bool(ad and ad.action and ad.action_slot_handle == 0
                     and _PAUSE_STATE in arm and arm.get(_PAUSE_ACTION) == ad.action)
    if temporary:
        state = json.loads(arm[_PAUSE_STATE])
        slot = next((slot for slot in ad.action.slots if slot.handle == state['slot']), None)
        if slot is None:
            raise RuntimeError('The original animation slot is no longer available')
        _KEYING_PAUSED.add(arm.as_pointer())
        ad.action_slot = slot
    try:
        yield
    finally:
        if temporary:
            ad.action_slot = None
            _KEYING_PAUSED.discard(arm.as_pointer())


def _with_keying_slot(function):
    @wraps(function)
    def wrapped(arm, *args, **kwargs):
        with _keying_action_slot(arm):
            return function(arm, *args, **kwargs)
    return wrapped


def _preview_animation_ids(scene):
    """Include animated rig flags stored on data shared by armature objects."""
    seen = set()
    for arm in scene.objects:
        if arm.type != 'ARMATURE':
            continue
        for owner in (arm, arm.data):
            pointer = owner.as_pointer()
            if pointer not in seen:
                seen.add(pointer)
                yield owner


@persistent
def _resume_preview_frame(scene, depsgraph=None):
    for arm in _preview_animation_ids(scene):
        if _PAUSE_STATE in arm:
            if json.loads(arm[_PAUSE_STATE])['frame'] != scene.frame_current_final:
                _resume_preview_action(arm)


@persistent
def _resume_preview_changes(scene, depsgraph=None):
    for arm in _preview_animation_ids(scene):
        if _PAUSE_STATE not in arm or arm.as_pointer() in _KEYING_PAUSED:
            continue
        ad = arm.animation_data
        if not ad or ad.action != arm.get(_PAUSE_ACTION) or ad.action_slot_handle != 0:
            _resume_preview_action(arm)


@persistent
def _resume_all_previews(_dummy=None):
    objects = (obj for obj in getattr(bpy.data, 'objects', ()) if obj.type == 'ARMATURE')
    for arm in chain(objects, getattr(bpy.data, 'armatures', ())):
        if _PAUSE_STATE in arm:
            _resume_preview_action(arm)


_PREVIEW_HANDLERS = (
    ('frame_change_pre', _resume_preview_frame),
    ('depsgraph_update_post', _resume_preview_changes),
    ('save_pre', _resume_all_previews),
    ('load_pre', _resume_all_previews),
    ('load_post', _resume_all_previews),
)


def get_armature(context):
    obj = context.active_object
    return obj if obj and obj.type == 'ARMATURE' else obj.find_armature() if obj and obj.type == 'MESH' else None


def is_built(arm):
    return bool(arm and arm.get('hhp_rigify_built') and arm.get('hhp_rigify_manifest'))


def manifest(arm):
    return json.loads(arm['hhp_rigify_manifest'])


def native_action_owns_pose(arm):
    from ..EXPERIMENTAL import hhp_ragdoll
    return bool(arm and hhp_ragdoll.portable_action_bones(arm))


def control_rig_active(arm):
    return bool(is_built(arm) and arm.get('hhp_rigify_active') and not native_action_owns_pose(arm))


def update(arm):
    arm.update_tag(refresh={'OBJECT'})
    bpy.context.view_layer.update()


def matrices(arm, names):
    update(arm)
    evaluated = arm.evaluated_get(bpy.context.evaluated_depsgraph_get())
    return {name: evaluated.pose.bones[name].matrix.copy() for name in names}


def matrix_error(a, b):
    return max(abs(x-y) for ra, rb in zip(a,b) for x,y in zip(ra,rb))


def _sync_ragdoll(arm, refresh=False):
    from ..EXPERIMENTAL import hhp_ragdoll
    if getattr(arm.data, 'hhp_ragdoll_built', False):
        if refresh:
            for segment, spec in hhp_ragdoll.active_segments(arm).items():
                for name in spec['bones']:
                    pb = arm.pose.bones.get(name)
                    if pb:
                        hhp_ragdoll.mute_animation_constraints(pb, arm, hhp_ragdoll.bone_part_segment(segment,name))
            hhp_ragdoll.prepare_transfer_constraints(arm, hhp_ragdoll.transfer_bones(arm))
        hhp_ragdoll.sync_transform_driver_overrides(arm)


def sync_proportions(arm, evaluate=True):
    from .animation_transfer_support import sync_proportion_followers, sync_proportion_controls
    sync_proportion_followers(arm)
    if is_built(arm):
        sync_proportion_controls(arm, manifest(arm))
    if evaluate:
        update(arm)


@contextmanager
def _pose_context(arm):
    active = bpy.context.view_layer.objects.active
    mode = active.mode if active else 'OBJECT'
    selection = list(bpy.context.selected_objects)
    auto = bpy.context.scene.tool_settings.use_keyframe_insert_auto
    hidden = arm.hide_get()
    if active == arm and mode == 'POSE':
        # Staying in Pose mode keeps one operator in Blender's undo history.
        try:
            bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
            yield
        finally:
            bpy.context.scene.tool_settings.use_keyframe_insert_auto = auto
        return
    try:
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
        if active and active.mode != 'OBJECT':
            bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
        bpy.ops.object.select_all('EXEC_DEFAULT', False, action='DESELECT')
        arm.hide_set(False)
        arm.select_set(True)
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='POSE')
        yield
    finally:
        if bpy.context.object and bpy.context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode='OBJECT')
        arm.select_set(False)
        for obj in selection:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = active
        if active and mode != 'OBJECT':
            bpy.ops.object.mode_set('EXEC_DEFAULT', False, mode=mode)
        arm.hide_set(hidden)
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = auto


def _operator(arm, kind, **kwargs):
    ensure_ui()
    operator = getattr(bpy.ops.pose, 'rigify_' + kind + '_' + arm.data['rig_id'])
    result = operator('EXEC_DEFAULT', False, **kwargs)
    if 'FINISHED' not in result:
        raise RuntimeError('Rigify could not complete the requested snap')


def _generated_snap(arm, spec):
    ensure_ui()
    args=dict(spec)
    name=args.pop('operator').split('.',1)[1]
    result=getattr(bpy.ops.pose,name)('EXEC_DEFAULT',False,**args)
    if 'FINISHED' not in result:
        raise RuntimeError('Rigify could not complete the requested snap')


def ensure_ui():
    from . import rigify_compat_loader
    ui = rigify_compat_loader.require_ui()
    if not ui.is_registered():ui.register()


def _state(arm):
    return {'basis':{p.name:p.matrix_basis.copy() for p in arm.pose.bones},
            'bones':{p.name:{k:p[k] for k in p.keys() if isinstance(p[k],(bool,int,float))} for p in arm.pose.bones},
            'props':{k:arm.get(k,0.) for k in ('hhp_rigify_active','hhp_native_limit_override')}}


def _restore(arm,state):
    for name,matrix in state['basis'].items():arm.pose.bones[name].matrix_basis=matrix
    for name,props in state['bones'].items():
        for key,value in props.items():arm.pose.bones[name][key]=value
    for key,value in state['props'].items():arm[key]=value
    update(arm)


def _digits(data):
    return [i for i in data['instances'] if i['type'].endswith('.super_finger')]


def is_ik(arm):
    if not is_built(arm):
        return True
    data=manifest(arm)
    return all(arm.pose.bones[item['master']].get('IK_FK',0) < .5 for item in data['limbs'])


def _key_controls(arm, names):
    with _keying_action_slot(arm):
        for name in dict.fromkeys(names):
            pb=arm.pose.bones[name]
            for path in ('location', 'scale', 'rotation_quaternion' if pb.rotation_mode=='QUATERNION' else
                         'rotation_axis_angle' if pb.rotation_mode=='AXIS_ANGLE' else 'rotation_euler'):
                pb.keyframe_insert(path, group=name)
            for prop in pb.keys():
                if isinstance(pb[prop],(bool,int,float)):
                    pb.keyframe_insert('["'+prop+'"]',group=name)


def switch_kinematics(arm, ik, keyframe=False):
    if not is_built(arm):
        return
    ensure_ui()
    state=_state(arm)
    native=native_action_owns_pose(arm)
    paused=_pause_preview_action(arm)
    try:
        _switch_kinematics(arm,ik,keyframe and not native)
    except Exception:
        _restore(arm,state)
        if paused:_resume_preview_action(arm)
        raise


def _switch_kinematics(arm, ik, keyframe=False):
    data=manifest(arm)
    desired=matrices(arm,data['driven']) if control_rig_active(arm) else None
    with _pose_context(arm):
        for item in data['limbs']:
            pb=arm.pose.bones[item['master']]
            if (pb['IK_FK'] < .5) == bool(ik):
                continue
            _generated_snap(arm,item['to_ik' if ik else 'to_fk'])
            pb['IK_FK']=0.0 if ik else 1.0
            update(arm)
        for item in data['fingers']:
            tip=arm.pose.bones[item['ik_control']]
            if (tip['FK_IK'] >= .5) == bool(ik):
                continue
            if ik and item.get('orientation_spec'):
                from .hhp_rigify_fingers_tongue import snap_ik_from_fk
                snap_ik_from_fk(arm,item)
            else:
                if ik and item.get('base_control'):
                    from .hhp_rigify_tongue_base import prepare_ik_snap
                    prepare_ik_snap(arm,item)
                _generated_snap(arm,item['to_ik' if ik else 'to_fk'])
            tip['FK_IK']=1.0 if ik else 0.0
            update(arm)
    if desired is not None:
        _fit_bindings(arm,desired)
    if keyframe:
        _key_controls(arm,data['controls']+list(data['bindings'].values()))
        _resume_preview_action(arm)
    refresh_visibility(arm)


def _basis(arm, name, pose, desired):
    pb=arm.pose.bones[name]; bone=pb.bone
    kw={}
    if bone.parent:
        kw=dict(parent_matrix=desired.get(bone.parent.name,pb.parent.matrix),parent_matrix_local=bone.parent.matrix_local)
    return bone.convert_local_to_pose(pose,bone.matrix_local,invert=True,**kw)


def _fit_daz_channels(arm, desired):
    # A switch is an explicit operation. No fitting runs while moving a bone.
    for _ in range(8):
        actual=matrices(arm,desired)
        if max(matrix_error(actual[n],m) for n,m in desired.items()) < 2e-5:
            return
        changes={n:_basis(arm,n,wanted,desired) @ _basis(arm,n,actual[n],actual).inverted_safe()
                 @ arm.pose.bones[n].matrix_basis for n,wanted in desired.items()}
        for n,b in changes.items():
            # Convert through a quaternion before Blender writes Euler channels.
            # Constraint-space matrices can contain tiny shear; direct Euler
            # extraction interprets that shear as a turn and stalls the fit.
            arm.pose.bones[n].matrix_basis=Matrix.LocRotScale(*b.decompose())
    actual=matrices(arm,desired)
    if max(matrix_error(actual[n],m) for n,m in desired.items())>1e-4:
        worst=sorted(((n,matrix_error(actual[n],m)) for n,m in desired.items()),key=lambda v:-v[1])[:5]
        raise RuntimeError('The Daz skeleton could not reproduce this pose: '+str(worst))


@contextmanager
def _suspend_location_limits(arm, names):
    """Fit raw channels before restoring the native Daz movement bounds."""
    saved=[]
    drivers=arm.animation_data.drivers if arm.animation_data else None
    try:
        for name in names:
            for constraint in arm.pose.bones[name].constraints:
                if constraint.type != 'LIMIT_LOCATION':continue
                driver=drivers.find(constraint.path_from_id('mute')) if drivers is not None else None
                saved.append((constraint,constraint.mute,driver,driver.mute if driver else False))
                if driver:driver.mute=True
                constraint.mute=True
        yield
    finally:
        for constraint,muted,driver,driver_muted in saved:
            constraint.mute=muted
            if driver:driver.mute=driver_muted


def _small_shear_pose_match(arm, actual, desired):
    """Accept only small affine residue with matching channels and bone endpoints.

    Constraint-space transforms can contain shear that pose channels cannot
    store. Keep the ordinary channel tolerance, bound the entire residual, and
    require both ends of every bone to stay within 0.02 mm in template units.
    """
    for name, wanted in desired.items():
        result = actual[name]
        if matrix_error(result, wanted) > 2e-4:
            return False
        if matrix_error(Matrix.LocRotScale(*result.decompose()),
                        Matrix.LocRotScale(*wanted.decompose())) > 1e-4:
            return False
        tip = Vector((0., arm.data.bones[name].length, 0.))
        if ((result.translation - wanted.translation).length > 2e-5
                or (result @ tip - wanted @ tip).length > 2e-5):
            return False
    return True


def _fit_bindings(arm, desired):
    # Residual offsets retain Daz-only twist/morph poses that have no exact
    # one-to-one Rigify channel. They are ordinary bone transforms, evaluated
    # by Blender, and stay fixed until the next explicit Daz/control snap.
    data=manifest(arm)
    for _ in range(6):
        actual=matrices(arm,desired)
        if max(matrix_error(actual[n],m) for n,m in desired.items()) < 2e-5:
            return
        changes={}
        for n,wanted in desired.items():
            bind=arm.pose.bones[data['bindings'][n]]
            output=arm.pose.bones[data['outputs'][n]].matrix
            wanted_bind=bind.matrix @ output.inverted_safe() @ wanted @ actual[n].inverted_safe() @ output
            changes[bind.name]=_basis(arm,bind.name,wanted_bind,{})
        for n,b in changes.items():
            arm.pose.bones[n].matrix_basis=b
    actual=matrices(arm,desired)
    if (max(matrix_error(actual[n],m) for n,m in desired.items())>1e-4
            and not _small_shear_pose_match(arm,actual,desired)):
        raise RuntimeError('The Rigify bindings could not preserve this Daz pose')



def _fk_seed(arm, desired):
    data=manifest(arm)
    # This receiving FK pose is replaced immediately. Snapping the dormant
    # old pose first would run every solver without contributing to the result.
    for item in data['limbs']:arm.pose.bones[item['master']]['IK_FK']=1.0
    for item in data['fingers']:arm.pose.bones[item['ik_control']]['FK_IK']=0.0
    update(arm)
    mapping=data.get('fk_map',{})
    levels={}
    for native,control in mapping.items():
        levels.setdefault(len(arm.data.bones[control].parent_recursive),[]).append(native)
    from .rigify_compat_loader import set_transform_from_matrix
    for level in sorted(levels):
        for native in levels[level]:
            control=mapping[native]
            wanted=desired[native] @ arm.data.bones[native].matrix_local.inverted_safe() @ arm.data.bones[control].matrix_local
            set_transform_from_matrix(arm,control,wanted,ignore_locks=True,undo_copy_scale=True)
            pb=arm.pose.bones[control]
            for con in pb.constraints:
                if con.name.startswith('(HHP) Rigify Proportion - ') and con.type=='TRANSFORM' and con.map_to=='SCALE':
                    factor=con.to_min_x_scale
                    pb.scale=tuple(v/factor for v in pb.scale)
        update(arm)


def set_daz_rotation_limits(arm, use_limits, keyframe=False):
    """Edit limits in Daz mode without an active Action undoing the choice."""
    value=float(not use_limits)
    old=arm.get('hhp_native_limit_override',0.)
    if old==value and not keyframe:return
    native=native_action_owns_pose(arm)
    paused=_pause_preview_action(arm)
    try:
        arm['hhp_native_limit_override']=value
        update(arm)
        if keyframe and not native:
            with _keying_action_slot(arm):
                arm.keyframe_insert('["hhp_native_limit_override"]')
            _resume_preview_action(arm)
    except Exception:
        arm['hhp_native_limit_override']=old
        if paused:_resume_preview_action(arm)
        update(arm)
        raise


def switch_rig(arm, enabled, keyframe=False, *, use_daz_limits=False):
    if not is_built(arm):
        return
    if bool(enabled)==control_rig_active(arm):
        if not enabled:
            set_daz_rotation_limits(arm,use_daz_limits,keyframe)
        return
    if enabled:ensure_ui()
    if getattr(arm.data,'hhp_ragdoll_enabled',False) and not native_action_owns_pose(arm):
        raise RuntimeError('Stop the ragdoll before switching rig controls')
    data=manifest(arm)
    desired=matrices(arm,data['driven'])
    saved=_state(arm)
    was_ik=is_ik(arm)
    native=native_action_owns_pose(arm)
    paused=_pause_preview_action(arm)
    data_flags={}
    data_paused=False
    if native:keyframe=False
    try:
        if native:
            from ..EXPERIMENTAL import hhp_ragdoll
            data_paused=_pause_preview_action(arm.data)
            for name in ('hhp_ragdoll_enabled','hhp_ragdoll_bake_enabled','hhp_ragdoll_keys_enabled','hhp_ragdoll_pose_override'):
                if hasattr(arm.data,name):
                    data_flags[name]=getattr(arm.data,name)
                    setattr(arm.data,name,False)
            hhp_ragdoll._mirror_state_properties(arm.data)
            hhp_ragdoll.sync_portable_action_playback(arm)
        if enabled:
            _fk_seed(arm,desired)
            arm['hhp_rigify_active']=1.0
            sync_proportions(arm)
            _sync_ragdoll(arm)
            if was_ik:
                switch_kinematics(arm,True)
            _fit_bindings(arm,desired)
        else:
            arm['hhp_rigify_active']=0.0
            arm['hhp_native_limit_override']=1.0
            sync_proportions(arm)
            _sync_ragdoll(arm)
            with _suspend_location_limits(arm,desired):
                _fit_daz_channels(arm,desired)
            arm['hhp_native_limit_override']=float(not use_daz_limits)
            update(arm)
        if keyframe:
            _key_controls(arm,data['controls']+list(data['bindings'].values()) if enabled else data['driven'])
            with _keying_action_slot(arm):
                arm.keyframe_insert('["hhp_rigify_active"]')
                arm.keyframe_insert('["hhp_native_limit_override"]')
            _resume_preview_action(arm)
        refresh_visibility(arm)
    except Exception:
        _restore(arm,saved)
        for name,value in data_flags.items():setattr(arm.data,name,value)
        if data_paused:_resume_preview_action(arm.data)
        if paused:
            _resume_preview_action(arm)
        from ..EXPERIMENTAL import hhp_ragdoll
        if data_flags:hhp_ragdoll._mirror_state_properties(arm.data)
        hhp_ragdoll.sync_portable_action_playback(arm)
        sync_proportions(arm)
        _sync_ragdoll(arm)
        update(arm)
        raise


def clear_pose(arm, context):
    state=_state(arm)
    flags={name:getattr(arm.data,name) for name in ('hhp_ragdoll_enabled','hhp_ragdoll_bake_enabled',
           'hhp_ragdoll_keys_enabled','hhp_ragdoll_pose_override') if hasattr(arm.data,name)}
    already_paused={owner:_PAUSE_STATE in owner for owner in (arm,arm.data)}
    try:
        _clear_pose(arm,context)
    except Exception:
        for name,value in flags.items():setattr(arm.data,name,value)
        from ..EXPERIMENTAL import hhp_ragdoll
        if flags:hhp_ragdoll._mirror_state_properties(arm.data)
        _restore(arm,state)
        for owner,paused in already_paused.items():
            if not paused:_resume_preview_action(owner)
        hhp_ragdoll.sync_portable_action_playback(arm)
        _sync_ragdoll(arm)
        update(arm)
        refresh_visibility(arm)
        raise


def _clear_pose(arm, context):
    from ..EXPERIMENTAL import hhp_ragdoll
    native=native_action_owns_pose(arm)
    effective_mode=control_rig_active(arm)
    if getattr(arm.data,'hhp_ragdoll_enabled',False) and not native:
        raise RuntimeError('Stop the ragdoll before clearing the character pose')
    _pause_preview_action(arm)
    if native:
        _pause_preview_action(arm.data)
        for name in ('hhp_ragdoll_enabled','hhp_ragdoll_bake_enabled','hhp_ragdoll_keys_enabled','hhp_ragdoll_pose_override'):
            if hasattr(arm.data,name):setattr(arm.data,name,False)
        hhp_ragdoll._mirror_state_properties(arm.data)
    if is_built(arm):arm['hhp_rigify_active']=float(effective_mode)
    data=manifest(arm) if is_built(arm) else {}
    names=data.get('native_bones',list(arm.pose.bones.keys()))+data.get('controls',[])+list(data.get('bindings',{}).values())
    for name in dict.fromkeys(names):
        pb=arm.pose.bones[name]
        neutral=data.get('neutral_basis',{}).get(name)
        pb.matrix_basis=Matrix(neutral) if neutral else Matrix.Identity(4)
    root=arm.pose.bones.get('root')
    if root and 'Uniform Scale' in root:root['Uniform Scale']=1.0
    arm['hhp_native_limit_override']=0.0
    hhp_ragdoll.sync_portable_action_playback(arm)
    sync_proportions(arm)
    _sync_ragdoll(arm)
    update(arm)
    refresh_visibility(arm)


def refresh_visibility(arm):
    if not is_built(arm):return
    data=manifest(arm)
    active=control_rig_active(arm)
    show_daz=bool(getattr(getattr(arm,'hhp_anim_preview_props',None),'show_daz_bones',False))
    if data.get('visibility_collections_revision',0) >= 1:
        from .hhp_rigify_collections import refresh
        refresh(arm,data,active,show_daz)
        return
    generated=set(data['generated_bones'])
    controls=set(data['controls'])
    hidden=dict(data.get('native_hidden',{}))
    desired={n: hidden.get(n,False) or (active and not show_daz) for n in data['driven']}
    desired.update({n: not active or n not in controls for n in generated})
    for item in data['limbs']:
        ik=arm.pose.bones[item['master']].get('IK_FK',0)<.5
        desired.update({n:not active or ik for n in item['fk_bones']})
        desired.update({n:not active or not ik for n in item['ik_ctrl_bones']+item['ik_extra_ctrls']+item['tail_bones']})
        pole=bool(arm.pose.bones[item['master']].get('pole_vector'))
        desired[item['ik_ctrl_bones'][1]]=not active or not ik or not pole
    for item in _digits(data):
        ctrl=item['bones']['ctrl'];ik=arm.pose.bones[ctrl['ik']].get('FK_IK',0)>=.5
        desired[ctrl['ik']]=not active or not ik
        desired.update({n:not active or ik for n in ctrl['fk']})
    for name,hide in desired.items():
        pb=arm.pose.bones.get(name)
        if pb:
            owner=pb if hasattr(pb,'hide') else pb.bone
            if owner.hide != hide:owner.hide=hide
    from .hhp_rigify_visibility import refresh
    refresh(arm,data,active,show_daz)


def _mode_signature(arm):
    key=arm.as_pointer()
    if key not in _VISIBILITY_MAPS:
        data=manifest(arm)
        _VISIBILITY_MAPS[key]=([(item['master'],'IK_FK') for item in data['limbs']]
            +[(item['master'],'pole_vector') for item in data['limbs']]
            +[(item['ik_control'],'FK_IK') for item in data['fingers']])
    props=getattr(arm,'hhp_anim_preview_props',None)
    return (control_rig_active(arm),bool(getattr(props,'show_daz_bones',False)),
            *(arm.pose.bones[name].get(prop) for name,prop in _VISIBILITY_MAPS[key]))


def _flush_visibility():
    names=tuple(_VISIBILITY_PENDING);_VISIBILITY_PENDING.clear()
    for name in names:
        arm=bpy.data.objects.get(name)
        if arm and is_built(arm):refresh_visibility(arm)
    return None


@persistent
def _watch_rig_modes(scene,depsgraph=None):
    # Observe a small set of selector values; no chain solving, pose fitting,
    # mesh evaluation or unconditional bone writes occur during a bone drag.
    if bpy.app.background:return
    if depsgraph is None:
        candidates=[obj for obj in scene.objects if obj.type=='ARMATURE']
    else:
        candidates=[]
        for change in depsgraph.updates:
            owner=change.id.original
            if isinstance(owner,bpy.types.Object) and owner.type=='ARMATURE':candidates.append(owner)
            elif isinstance(owner,bpy.types.Armature):
                candidates.extend(obj for obj in scene.objects if obj.type=='ARMATURE' and obj.data==owner)
    for arm in candidates:
        if not is_built(arm):continue
        signature=_mode_signature(arm);key=arm.as_pointer()
        if _VISIBILITY_SIGNATURES.get(key)!=signature:
            _VISIBILITY_SIGNATURES[key]=signature;_VISIBILITY_PENDING.add(arm.name)
    if _VISIBILITY_PENDING and not bpy.app.timers.is_registered(_flush_visibility):
        bpy.app.timers.register(_flush_visibility,first_interval=0.0)


@persistent
def _frame_rig_modes(scene,depsgraph=None):
    _watch_rig_modes(scene,None)


@persistent
def _visibility_file_change(_dummy=None):
    _VISIBILITY_MAPS.clear();_VISIBILITY_SIGNATURES.clear();_VISIBILITY_PENDING.clear()


_MODE_HANDLERS=(('depsgraph_update_post',_watch_rig_modes),('frame_change_post',_frame_rig_modes),
                ('load_post',_visibility_file_change),('undo_post',_visibility_file_change),('redo_post',_visibility_file_change))


class HHP_OT_RigifySnap(bpy.types.Operator):
    bl_idname='hhp.rigify_snap'
    bl_label='Snap Rig Controls'
    bl_description='Transfer the current pose using the Rigify controls and the original Daz bones'
    bl_options={'REGISTER','UNDO'}
    direction:bpy.props.EnumProperty(items=[('DAZ_TO_CONTROL','Daz to Rigify','Match Rigify to the Daz pose'),
        ('CONTROL_TO_DAZ','Rigify to Daz','Transfer the Rigify pose to Daz'),
        ('IK_TO_FK','IK to FK','Match FK controls to the IK pose'),('FK_TO_IK','FK to IK','Match IK controls to the FK pose')])
    @classmethod
    def poll(cls,context):return is_built(get_armature(context))
    def execute(self,context):
        arm=get_armature(context)
        key=bool(getattr(getattr(arm,'hhp_anim_preview_props',None),'keyframe_ik_fk_switch',False))
        try:
            if self.direction in {'DAZ_TO_CONTROL','CONTROL_TO_DAZ'}:
                switch_rig(arm,self.direction=='DAZ_TO_CONTROL',key)
            else:switch_kinematics(arm,self.direction=='FK_TO_IK',key)
        except (ValueError,RuntimeError,KeyError) as exc:
            self.report({'ERROR'},str(exc));return {'CANCELLED'}
        return {'FINISHED'}


def draw_options(layout,arm):
    if not is_built(arm):return
    row=layout.row(align=True)
    from .hhp_rigify_controls import available
    row.operator_context='INVOKE_DEFAULT'
    receive=row.row(align=True);receive.enabled=available()
    receive.operator('hhp.set_rig_type',text='Daz to Rigify',icon='SNAP_ON').rig_type='RIGIFY'
    row.operator('hhp.set_rig_type',text='Rigify to Daz',icon='BONE_DATA').rig_type='DAZ'
    row=layout.row(align=True);row.enabled=control_rig_active(arm) and available()
    row.operator('hhp.rigify_snap',text='IK to FK',icon='CON_ROTLIKE').direction='IK_TO_FK'
    row.operator('hhp.rigify_snap',text='FK to IK',icon='CON_KINEMATIC').direction='FK_TO_IK'
    layout.prop(arm.hhp_anim_preview_props,'show_daz_bones',icon='BONE_DATA')
    if not control_rig_active(arm):layout.prop(arm.hhp_anim_preview_props,'use_daz_rotation_limits')
    elif arm.mode=='POSE' and available():
        panel=bpy.types.Panel.bl_rna_get_subclass_py('VIEW3D_PT_rig_ui_'+arm.data['rig_id'])
        if panel:
            # Use Rigify's generated selection-aware panel for all limb/parent,
            # foot-roll, stretch, finger, pole and snapping controls.
            proxy=type('RigifyPanelLayout',(),{'layout':layout.column(align=True)})()
            panel.draw(proxy,bpy.context)


def register():
    from . import rigify_compat_loader, hhp_rigify_controls
    rigify_compat_loader.register()
    hhp_rigify_controls.register()
    from . import hhp_rigify_fingers_tongue
    hhp_rigify_fingers_tongue.register()
    bpy.utils.register_class(HHP_OT_RigifySnap)
    from . import hhp5_root
    hhp5_root.register()
    for name,handler in _PREVIEW_HANDLERS:
        if handler not in getattr(bpy.app.handlers,name):getattr(bpy.app.handlers,name).insert(0,handler)
    for name,handler in _MODE_HANDLERS:
        if handler not in getattr(bpy.app.handlers,name):getattr(bpy.app.handlers,name).append(handler)


def unregister():
    for name,handler in _MODE_HANDLERS:
        if handler in getattr(bpy.app.handlers,name):getattr(bpy.app.handlers,name).remove(handler)
    if bpy.app.timers.is_registered(_flush_visibility):bpy.app.timers.unregister(_flush_visibility)
    _visibility_file_change()
    for name,handler in _PREVIEW_HANDLERS:
        if handler in getattr(bpy.app.handlers,name):getattr(bpy.app.handlers,name).remove(handler)
    _resume_all_previews()
    from . import hhp5_root
    hhp5_root.unregister()
    bpy.utils.unregister_class(HHP_OT_RigifySnap)
    from . import rigify_compat_loader, hhp_rigify_controls
    from . import hhp_rigify_fingers_tongue
    hhp_rigify_fingers_tongue.unregister()
    hhp_rigify_controls.unregister()
    rigify_compat_loader.unregister()
