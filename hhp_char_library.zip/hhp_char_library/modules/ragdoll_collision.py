"""Bounded-memory SAT projections with mathutils' float32 product semantics."""
import numpy as np


def projected_cut(vertices_a, vertices_b, axes, center_direction,
                  epsilon=1.0e-7, batch_size=2048):
    """Return the same first minimum-overlap plane as ordered Vector.dot loops.

    Vertices and axes are mathutils Vectors. Keep the caller's axis construction,
    deduplication, center calculation, and AABB rejection unchanged. Blender's
    Vector.dot sums float32 products in float64; NumPy matmul does not reproduce
    that rounding. Explicit products retain exact scalar projection results.
    """
    if not vertices_a or not vertices_b or not axes:
        return None
    vertices = (np.asarray(vertices_a, dtype=np.float32),
                np.asarray(vertices_b, dtype=np.float32))
    center = np.asarray(center_direction, dtype=np.float32)
    best = None
    for start in range(0, len(axes), batch_size):
        original = axes[start:start + batch_size]
        batch = np.asarray(original, dtype=np.float32)
        direction = np.sum(batch * center, axis=1, dtype=np.float64)
        negative = direction < 0.0
        batch[negative] *= -1.0
        extrema = []
        for points in vertices:
            projection = (points[:, 0, None] * batch[None, :, 0]).astype(np.float64)
            projection += points[:, 1, None] * batch[None, :, 1]
            projection += points[:, 2, None] * batch[None, :, 2]
            extrema.append((projection.min(axis=0), projection.max(axis=0)))
        lower = np.maximum(extrema[0][0], extrema[1][0])
        upper = np.minimum(extrema[0][1], extrema[1][1])
        overlaps = upper - lower
        if np.any(overlaps <= epsilon):
            return None
        index = int(np.argmin(overlaps))
        overlap = float(overlaps[index])
        if best is None or overlap < best[0]:
            axis = -original[index] if negative[index] else original[index]
            plane_point = axis * float((lower[index] + upper[index]) * 0.5)
            best = (overlap, plane_point, axis)
    return best
