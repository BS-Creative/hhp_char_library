"""Adapt copied identity shaders to the retained character's HHP rig version."""
import ast

from .animation_transfer_support import TransferError


_EYES = {'head eyeball left': 'lEye', 'head eyeball right': 'rEye'}
_TWIST_BONES = ('neckLower', 'head')
_FEET = {'Metatarsals.l': 'lMetatarsals', 'Metatarsals.r': 'rMetatarsals',
         'Toe.l': 'lToe', 'Toe.r': 'rToe'}


def version(body):
    return 5 if body.get('HHP Version') == 5 else 4


def material_owners(objects):
    """Visit every Material and tree once, including embedded and shared trees."""
    seen = set()
    pending = [mat for obj in objects for mat in getattr(getattr(obj, 'data', None), 'materials', ()) if mat]
    while pending:
        owner = pending.pop()
        pointer = owner.as_pointer()
        if pointer in seen:
            continue
        seen.add(pointer)
        yield owner
        tree = getattr(owner, 'node_tree', None)
        if tree:
            pending.append(tree)
        for node in getattr(owner, 'nodes', ()):
            if node.type == 'GROUP' and node.node_tree:
                pending.append(node.node_tree)


def _recipe(variable, target, donor_version):
    eyes = _EYES if donor_version == 4 else {v: k for k, v in _EYES.items()}
    if (variable.type == 'TRANSFORMS' and target.bone_target in eyes
            and target.transform_type == 'ROT_X' and target.transform_space == 'LOCAL_SPACE'
            and target.rotation_mode == 'QUATERNION'):
        return {'bone_target': eyes[target.bone_target]}, True
    if donor_version == 4 and variable.type == 'SINGLE_PROP':
        for old_bone, new_bone in _FEET.items():
            if target.data_path in (f'pose.bones["{old_bone}"].rotation_quaternion[1]',
                                    f"pose.bones['{old_bone}'].rotation_quaternion[1]"):
                return {'type': 'TRANSFORMS', 'bone_target': new_bone,
                        'data_path': f'pose.bones["{new_bone}"].rotation_quaternion[1]',
                        'transform_type': 'ROT_X', 'transform_space': 'LOCAL_SPACE',
                        'rotation_mode': 'QUATERNION'}, True
        for bone in _TWIST_BONES:
            if target.data_path in (f'pose.bones["{bone}"].rotation_quaternion[2]',
                                    f"pose.bones['{bone}'].rotation_quaternion[2]"):
                return {'type': 'TRANSFORMS', 'bone_target': bone,
                        'transform_type': 'ROT_Y', 'transform_space': 'LOCAL_SPACE',
                        'rotation_mode': 'QUATERNION'}, False
    if (donor_version == 5 and variable.type == 'TRANSFORMS'
            and target.bone_target in _FEET.values() and target.transform_type == 'ROT_X'
            and target.transform_space == 'LOCAL_SPACE' and target.rotation_mode == 'QUATERNION'):
        bone = next(old for old, new in _FEET.items() if new == target.bone_target)
        return {'type': 'SINGLE_PROP', 'data_path': f'pose.bones["{bone}"].rotation_quaternion[1]',
                'bone_target': '', 'transform_type': 'LOC_X',
                'transform_space': 'WORLD_SPACE', 'rotation_mode': 'AUTO'}, True
    if (donor_version == 5 and variable.type == 'TRANSFORMS'
            and target.bone_target in _TWIST_BONES and target.transform_type == 'ROT_Y'
            and target.transform_space == 'LOCAL_SPACE' and target.rotation_mode == 'QUATERNION'):
        bone = target.bone_target
        return {'type': 'SINGLE_PROP', 'data_path': f'pose.bones["{bone}"].rotation_quaternion[2]',
                'bone_target': '', 'transform_type': 'LOC_X',
                'transform_space': 'WORLD_SPACE' if bone == 'neckLower' else 'LOCAL_SPACE',
                'rotation_mode': 'AUTO'}, False
    return None, False


class _FlipVariables(ast.NodeTransformer):
    def __init__(self, names):
        self.names = names

    def visit_UnaryOp(self, node):
        if isinstance(node.op, ast.USub) and isinstance(node.operand, ast.Name) and node.operand.id in self.names:
            return node.operand
        return self.generic_visit(node)

    def visit_Name(self, node):
        if node.id in self.names:
            return ast.copy_location(ast.UnaryOp(op=ast.USub(), operand=node), node)
        return node


def _flip_expression(driver, names):
    if driver.type == 'SCRIPTED':
        expression = driver.expression
    else:
        variables = [variable.name for variable in driver.variables]
        if driver.type in {'SUM', 'AVERAGE'}:
            expression = '(' + '+'.join(variables) + ')'
            if driver.type == 'AVERAGE':
                expression += '/' + str(len(variables))
        elif driver.type in {'MIN', 'MAX'}:
            expression = (driver.type.lower() + '(' + ','.join(variables) + ')'
                          if len(variables) > 1 else variables[0])
        else:
            raise TransferError('Unsupported shader rotation driver type: ' + driver.type)
    try:
        tree = _FlipVariables(names).visit(ast.parse(expression, mode='eval'))
        return ast.unparse(ast.fix_missing_locations(tree))
    except (SyntaxError, ValueError) as error:
        raise TransferError('Cannot adapt an invalid shader rotation driver expression') from error


def remap(objects, source_arm, target_arm, source_version, target_version, check_only=False):
    """Convert donor channel semantics before the normal character ID remapping.

    Eye/foot local quaternion X has opposite polarity across rigs. Neck/head
    twist reads raw pose quaternion Y in HHP4, but the evaluated local quaternion
    in HHP5 (whose constrained bones use Euler channels). Other inputs are shared.
    Build the full plan first so a missing destination control never half-applies.
    """
    if source_version == target_version or not target_arm:
        return 0
    plans = []
    for owner in material_owners(objects):
        for curve in getattr(getattr(owner, 'animation_data', None), 'drivers', ()):
            updates, flips = [], set()
            for variable in curve.driver.variables:
                for target in variable.targets:
                    if target.id != target_arm:
                        continue
                    recipe, flip = _recipe(variable, target, target_version)
                    if recipe is None:
                        continue
                    bone = recipe.get('bone_target')
                    if not bone:
                        # All SINGLE_PROP recipes name an explicit destination bone.
                        bone = recipe['data_path'].split('["', 1)[1].split('"]', 1)[0]
                    if not source_arm or bone not in source_arm.pose.bones:
                        raise TransferError(f'The source rig is missing shader control "{bone}"')
                    updates.append((variable, recipe))
                    if flip:
                        flips.add(variable.name)
            expression = _flip_expression(curve.driver, flips) if flips else None
            if updates:
                plans.append((owner, curve.driver, updates, expression))
    if not check_only:
        for owner, driver, updates, expression in plans:
            for variable, recipe in updates:
                # Changing variable type may rebuild its targets; retain the ID.
                old_id = variable.targets[0].id
                if 'type' in recipe:
                    variable.type = recipe['type']
                target = variable.targets[0]
                target.id = old_id
                for field, value in recipe.items():
                    if field != 'type':
                        setattr(target, field, value)
            if expression is not None:
                driver.type = 'SCRIPTED'
                driver.expression = expression
            owner.update_tag()
    return len(plans)
