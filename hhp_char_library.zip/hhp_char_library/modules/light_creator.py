import bpy
from bpy.types import Operator
from math import radians
import mathutils
import random

def get_or_create_quick_lights_collection(context):
    """Get or create the main (BS) Quick Lights collection"""
    main_collection_name = "(BS) Quick Lights"
    main_collection = bpy.data.collections.get(main_collection_name)
    if not main_collection:
        main_collection = bpy.data.collections.new(main_collection_name)
        context.scene.collection.children.link(main_collection)
        main_collection.color_tag = 'COLOR_07'
    return main_collection

def get_or_create_sub_collection(context, main_collection, sub_collection_name):
    """Get or create a sub-collection within the main collection"""
    sub_collection = bpy.data.collections.get(sub_collection_name)
    if not sub_collection:
        sub_collection = bpy.data.collections.new(sub_collection_name)
        main_collection.children.link(sub_collection)
    return sub_collection

class HHP_OT_CreateReflectionLight(Operator):
    bl_idname = "hhp.create_reflection_light"
    bl_label = "Create Reflection Light"
    bl_description = "Create a reflection light at the 3D cursor position"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # Check if an object is selected and in a mode other than 'OBJECT'
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Deselect all objects
        bpy.ops.object.select_all(action='DESELECT')

        # Create a new point light data
        light_data = bpy.data.lights.new(name="(BS)_Reflection light", type='POINT')

        # Create a new light object
        light_object = bpy.data.objects.new(name="(BS)_Reflection light", object_data=light_data)

        # Get or create the collections
        main_collection = get_or_create_quick_lights_collection(context)
        reflection_collection = get_or_create_sub_collection(context, main_collection, "Reflection Lights")
        
        # Link the light object to the reflection collection
        reflection_collection.objects.link(light_object)

        # Set the light object at the cursor position
        light_object.location = context.scene.cursor.location

        # Set the properties of the light
        light_object.data.energy = 1
        light_object.data.diffuse_factor = 0
        light_object.data.volume_factor = 0
        light_object.data.shadow_soft_size = 0.02
        light_object.data.use_shadow = False

        # Make the new light the active and only selected object
        context.view_layer.objects.active = light_object
        light_object.select_set(True)

        # Update the scene
        context.view_layer.update()
        
        self.report({'INFO'}, "Reflection light created at cursor position")
        return {'FINISHED'}

class HHP_OT_CreateSunsetLight(Operator):
    bl_idname = "hhp.create_sunset_light"
    bl_label = "Create Sunset Light"
    bl_description = "Create a sunset light at the 3D cursor position"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # Check if an object is selected and in a mode other than 'OBJECT'
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Define the light color (RGB)
        light_color = (1.000, 0.45668, 0.118074)

        # Get the current 3D cursor location
        cursor_location = context.scene.cursor.location

        # Create a new SUN light at the 3D cursor location
        bpy.ops.object.light_add(type='SUN', location=cursor_location)
        sunlight = context.object
        
        # Get or create the collections and move the light
        main_collection = get_or_create_quick_lights_collection(context)
        sunset_collection = get_or_create_sub_collection(context, main_collection, "Sunset Lights")
        
        # Remove from current collection and add to sunset collection
        for collection in sunlight.users_collection:
            collection.objects.unlink(sunlight)
        sunset_collection.objects.link(sunlight)

        # Set the sunlight color and strength
        sunlight.data.color = light_color
        sunlight.data.energy = 5.0

        # Set the light angle (converted from degrees to radians)
        sunlight.data.angle = radians(0.526)

        # Enable shadows
        sunlight.data.use_shadow = True

        # Set contact shadow properties only if they exist
        if hasattr(sunlight.data, "use_contact_shadow"):
            sunlight.data.use_contact_shadow = True
            sunlight.data.contact_shadow_distance = 0.02
            sunlight.data.contact_shadow_bias = 0.030
            sunlight.data.contact_shadow_thickness = 1.0

        # Set the rotation of the sunlight
        sunlight.rotation_euler = (radians(81.4834), radians(-35.4985), radians(-34.7197))

        # Update the scene
        context.view_layer.update()
        
        self.report({'INFO'}, "Sunset light created at cursor position")
        return {'FINISHED'}

# --- New operator: Create Targeted Reflection Light ---
class HHP_OT_CreateTargetedReflectionLight(bpy.types.Operator):
    bl_idname = "hhp.create_targeted_reflection_light"
    bl_label = "Create Targeted Reflection Light"
    bl_description = "Creates a reflection light targeting specific meshes. Select target meshes in the popup or use currently selected meshes."
    bl_options = {"REGISTER", "UNDO"}

    use_selection_as_targets: bpy.props.BoolProperty(
        name="Use selection as targets",
        description="Use currently selected mesh objects as targets instead of picking a single object",
        default=False
    )

    def invoke(self, context, event):
        # Check if there are any selected mesh objects
        selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        # Default to using selection if meshes are selected
        self.use_selection_as_targets = len(selected_meshes) > 0
        
        return context.window_manager.invoke_props_dialog(self, width=350)

    def draw(self, context):
        layout = self.layout
        
        # Show checkbox for using selection
        layout.prop(self, "use_selection_as_targets")
        
        # Show object picker only when not using selection
        if not self.use_selection_as_targets:
            layout.prop(context.scene, "hhp_targeted_light_mesh", text="Target Mesh", icon="EYEDROPPER")
        else:
            # Show disabled object picker to indicate it's not being used
            row = layout.row()
            row.enabled = False
            row.prop(context.scene, "hhp_targeted_light_mesh", text="Target Mesh", icon="EYEDROPPER")
            
            # Show error if no mesh objects are selected
            selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
            if not selected_meshes:
                layout.label(text="No mesh objects selected!", icon='ERROR')

    def execute(self, context):
        target_objects = []
        
        if self.use_selection_as_targets:
            # Use selected mesh objects as targets
            selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
            if not selected_meshes:
                self.report({'ERROR'}, "No mesh objects selected. Please select at least one mesh object.")
                return {'CANCELLED'}
            target_objects = selected_meshes
        else:
            # Use single picked object as target
            target_obj = context.scene.hhp_targeted_light_mesh
            if not target_obj or target_obj.type != 'MESH':
                self.report({'ERROR'}, "Please select a valid mesh object as target")
                return {'CANCELLED'}
            target_objects = [target_obj]
        
        # Check if an object is selected and in a mode other than 'OBJECT'
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Deselect all objects
        bpy.ops.object.select_all(action='DESELECT')
        
        # Create the light data (same settings as regular reflection light)
        light_data = bpy.data.lights.new(name="Targeted Reflection Light", type='POINT')
        light_data.energy = 1
        light_data.diffuse_factor = 0
        light_data.volume_factor = 0
        light_data.shadow_soft_size = 0.02
        light_data.use_shadow = False
        
        # Create the light object
        light_obj = bpy.data.objects.new(name="Targeted Reflection Light", object_data=light_data)
        
        # Position at 3D cursor
        light_obj.location = context.scene.cursor.location
        
        # Get or create the collections
        main_collection = get_or_create_quick_lights_collection(context)
        targeted_collection = get_or_create_sub_collection(context, main_collection, "Targeted Reflection Lights")
        
        # Link to targeted collection
        targeted_collection.objects.link(light_obj)
        
        # Create a dedicated collection for light linking
        target_names = [obj.name for obj in target_objects]
        if len(target_names) > 2:
            linking_collection_name = f"LightLink_{len(target_names)}objects_{light_obj.name}"
        else:
            linking_collection_name = f"LightLink_{'_'.join(target_names)}_{light_obj.name}"
        
        linking_collection = bpy.data.collections.new(linking_collection_name)
        
        # Add all target objects to the linking collection
        for target_obj in target_objects:
            linking_collection.objects.link(target_obj)
        
        # Set up light linking (this is the key part)
        # Note: The exact API may vary, but this follows the general pattern
        try:
            # Try to access light linking properties (Blender 4.3+ specific)
            if hasattr(light_obj, 'light_linking'):
                light_obj.light_linking.receiver_collection = linking_collection
            elif hasattr(light_data, 'light_linking'):
                light_data.light_linking.receiver_collection = linking_collection
            elif hasattr(light_obj, 'data') and hasattr(light_obj.data, 'cycles'):
                # Alternative approach through Cycles settings
                if hasattr(light_obj.data.cycles, 'light_linking'):
                    light_obj.data.cycles.light_linking.receiver_collection = linking_collection
            else:
                # Fallback: Store the target information in custom properties for manual setup
                light_obj["target_objects"] = [obj.name for obj in target_objects]
                light_obj["light_link_collection"] = linking_collection_name
                self.report({'WARNING'}, f"Light linking API not found. Target objects stored in custom properties. Please set up light linking manually in the light properties.")
                
        except Exception as e:
            # If light linking fails, store info for manual setup
            light_obj["target_objects"] = [obj.name for obj in target_objects]
            light_obj["light_link_collection"] = linking_collection_name
            self.report({'WARNING'}, f"Could not set up automatic light linking: {str(e)}. Please configure light linking manually in the light properties.")
        
        # Select the new light
        bpy.context.view_layer.objects.active = light_obj
        light_obj.select_set(True)
        
        # Update the scene
        context.view_layer.update()
        
        if len(target_objects) == 1:
            self.report({'INFO'}, f"Created targeted reflection light for '{target_objects[0].name}'")
        else:
            self.report({'INFO'}, f"Created targeted reflection light for {len(target_objects)} objects")
        return {'FINISHED'}

# --- End new operator ---

# --- New operator: Setup Light System ---
class HHP_OT_SetupLightSystem(bpy.types.Operator):
    bl_idname = "hhp.setup_light_system"
    bl_label = "Setup Light System"
    bl_description = "Creates a professional lighting setup with 1-10 lights positioned around and targeting the 3D cursor"
    bl_options = {"REGISTER", "UNDO"}

    seed: bpy.props.IntProperty(
        name="Seed",
        description="Random seed for reproducible lighting variations",
        default=0,
        min=0,
        max=10000
    )

    distance_multiplier: bpy.props.FloatProperty(
        name="Distance",
        description="Distance multiplier for light positioning around the cursor",
        default=1.0,
        min=0.0,
        step=1.0
    )

    saturation: bpy.props.FloatProperty(
        name="Color Saturation",
        description="Color saturation of the lights (0=grayscale, 1=full color)",
        default=1.0,
        min=0.0,
        max=10.0,
        step=1.0
    )

    power_multiplier: bpy.props.FloatProperty(
        name="Power",
        description="Power multiplier for all lights",
        default=1.0,
        min=0.0,
        step=1.0
    )

    num_lights: bpy.props.IntProperty(
        name="Number of Lights",
        description="Number of lights to create in the system",
        default=3,
        min=1,
        max=10
    )

    radius_multiplier: bpy.props.FloatProperty(
        name="Radius Multiplier",
        description="Radius multiplier for light softness/size",
        default=5.0,
        min=0.0,
        step=1.0
    )

    color_mode: bpy.props.EnumProperty(
        name="Color Mode",
        description="Choose the color palette for the lights",
        items=[
            ('MIXED', "Mixed Colors", "Traditional lighting setup with key, fill, and rim light colors"),
            ('WARM', "Warm Colors", "Saturated oranges to desaturated yellows"),
            ('COOL', "Cool Colors", "Sky blues to blueish whites"),
            ('RANDOM', "Random Colors", "Full spectrum random colors"),
            ('SPECIFIC', "Specific Color Range", "Variations of a specific color you choose")
        ],
        default='MIXED'
    )

    specific_color: bpy.props.FloatVectorProperty(
        name="Base Color",
        description="Base color for generating variations",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0),
        min=0.0,
        max=1.0,
        size=3
    )

    def draw(self, context):
        layout = self.layout
        
        # Use column layout for vertical alignment
        col = layout.column(align=True)
        
        # Show properties in original order
        col.prop(self, "seed")
        col.prop(self, "distance_multiplier")
        col.prop(self, "saturation")
        col.prop(self, "power_multiplier")
        col.prop(self, "num_lights")
        col.prop(self, "radius_multiplier")
        col.prop(self, "color_mode", text="")
        
        # Only show color picker when Specific Color Range mode is selected
        if self.color_mode == 'SPECIFIC':
            col.prop(self, "specific_color")

    def execute(self, context):
        # Initialize random seed (treat 0 as 521)
        actual_seed = 521 if self.seed == 0 else self.seed
        random.seed(actual_seed)
        
        # Check if an object is selected and in a mode other than 'OBJECT'
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Get or create the collections
        main_collection = get_or_create_quick_lights_collection(context)
        lights_collection = get_or_create_sub_collection(context, main_collection, "Light System")
        
        # Get 3D cursor position as target
        cursor_pos = context.scene.cursor.location.copy()
        
        # Helper function to generate unique light names
        def get_unique_name(base_name):
            if base_name not in [obj.name for obj in bpy.data.objects]:
                return base_name
            
            counter = 1
            while f"{base_name}.{counter:03d}" in [obj.name for obj in bpy.data.objects]:
                counter += 1
            return f"{base_name}.{counter:03d}"
        
        # Calculate appropriate distance based on user setting
        base_distance = 1.2  # New default base distance
        light_distance = base_distance * self.distance_multiplier
        
        # When distance is 0, lights should be exactly at cursor - no minimum override
        
        # Helper function to adjust color saturation
        def adjust_saturation(color, saturation):
            # Convert to HSV, adjust saturation, convert back
            r, g, b = color
            # Simple saturation adjustment - scale by 1.5 so that slider value 1.0 = actual saturation 1.5
            actual_saturation = saturation * 1.5
            gray = (r + g + b) / 3
            return (
                gray + (r - gray) * actual_saturation,
                gray + (g - gray) * actual_saturation,
                gray + (b - gray) * actual_saturation
            )
        
        # Create the lighting setup
        lights_created = []
        
        import math
        
        for i in range(self.num_lights):
            # Determine light name and characteristics
            if i == 0 and self.num_lights >= 3:
                light_name = "Key Light"
                energy_range = (60, 90)
            elif i == 1 and self.num_lights >= 3:
                light_name = "Fill Light"
                energy_range = (25, 50)
            elif i == 2 and self.num_lights >= 3:
                light_name = "Rim Light"
                energy_range = (40, 60)
            else:
                light_name = f"Light {i + 1}"
                energy_range = (30, 70)
            
            # Create light data
            unique_name = get_unique_name(light_name)
            light_data = bpy.data.lights.new(name=unique_name, type='POINT')
            light_data.energy = random.uniform(*energy_range) * self.power_multiplier
            
            if self.color_mode == 'MIXED':
                # Traditional mixed lighting with different colors for different light types
                if i == 0 and self.num_lights >= 3:
                    # Key Light: Warm white variation
                    light_data.color = (
                        random.uniform(0.8, 1.0),
                        random.uniform(0.7, 1.0),
                        random.uniform(0.4, 0.9)
                    )
                elif i == 1 and self.num_lights >= 3:
                    # Fill Light: Cool white/blue variation
                    light_data.color = (
                        random.uniform(0.4, 0.9),
                        random.uniform(0.6, 1.0),
                        random.uniform(0.8, 1.0)
                    )
                elif i == 2 and self.num_lights >= 3:
                    # Rim Light: Purple/cool variation
                    light_data.color = (
                        random.uniform(0.6, 1.0),
                        random.uniform(0.4, 0.9),
                        random.uniform(0.7, 1.0)
                    )
                else:
                    # Additional lights: Full color variation
                    light_data.color = (
                        random.uniform(0.4, 1.0),
                        random.uniform(0.4, 1.0),
                        random.uniform(0.4, 1.0)
                    )
            elif self.color_mode == 'WARM':
                light_data.color = (
                    random.uniform(0.8, 1.0),
                    random.uniform(0.6, 0.9),
                    random.uniform(0.4, 0.7)
                )
            elif self.color_mode == 'COOL':
                light_data.color = (
                    random.uniform(0.6, 1.0),
                    random.uniform(0.8, 1.0),
                    random.uniform(0.9, 1.0)
                )
            elif self.color_mode == 'RANDOM':
                light_data.color = (
                    random.uniform(0.0, 1.0),
                    random.uniform(0.0, 1.0),
                    random.uniform(0.0, 1.0)
                )
            elif self.color_mode == 'SPECIFIC':
                # Generate variations of the specific color
                base_r, base_g, base_b = self.specific_color
                variation_amount = 0.25  # How much variation to allow
                
                # Add random variation to each channel
                varied_r = base_r + random.uniform(-variation_amount, variation_amount)
                varied_g = base_g + random.uniform(-variation_amount, variation_amount)
                varied_b = base_b + random.uniform(-variation_amount, variation_amount)
                
                # Clamp values to 0.0-1.0 range
                light_data.color = (
                    max(0.0, min(1.0, varied_r)),
                    max(0.0, min(1.0, varied_g)),
                    max(0.0, min(1.0, varied_b))
                )
            
            light_data.color = adjust_saturation(light_data.color, self.saturation)
            light_data.shadow_soft_size = random.uniform(0.015, 0.05) * self.radius_multiplier
            light_data.use_shadow = True
            
            # Create light object
            light_obj = bpy.data.objects.new(name=unique_name, object_data=light_data)
            
            # Position lights in a circle around cursor if distance > 0
            if light_distance > 0:
                if self.num_lights == 1:
                    # Single light: place randomly around cursor
                    light_pos = cursor_pos + mathutils.Vector([
                        light_distance * random.uniform(-1.0, 1.0),
                        light_distance * random.uniform(-1.0, 1.0),
                        light_distance * random.uniform(-0.5, 1.5)
                    ])
                elif i == 0:  # First light always uses key position
                    light_pos = cursor_pos + mathutils.Vector([
                        light_distance * random.uniform(0.6, 0.9),
                        light_distance * random.uniform(-0.8, -0.4),
                        light_distance * random.uniform(0.5, 1.0)
                    ])
                elif i == 1:  # Second light always uses fill position
                    light_pos = cursor_pos + mathutils.Vector([
                        light_distance * random.uniform(-0.9, -0.6),
                        light_distance * random.uniform(-0.6, -0.2),
                        light_distance * random.uniform(-0.2, 0.4)
                    ])
                elif i == 2:  # Third light always uses rim position
                    light_pos = cursor_pos + mathutils.Vector([
                        light_distance * random.uniform(-0.3, 0.3),
                        light_distance * random.uniform(0.7, 1.2),
                        light_distance * random.uniform(0.6, 1.3)
                    ])
                else:
                    # Additional lights (4+) use circular distribution
                    # Start from light 4, so subtract 3 from index for circle calculation
                    circle_index = i - 3
                    total_circle_lights = self.num_lights - 3
                    angle = (circle_index / total_circle_lights) * 2 * math.pi
                    radius_variation = random.uniform(0.8, 1.2)
                    height_variation = random.uniform(-0.5, 1.5)
                    
                    light_pos = cursor_pos + mathutils.Vector([
                        light_distance * math.cos(angle) * radius_variation,
                        light_distance * math.sin(angle) * radius_variation,
                        light_distance * height_variation
                    ])
            else:
                # All lights at cursor position when distance is 0
                light_pos = cursor_pos
            
            light_obj.location = light_pos
            lights_collection.objects.link(light_obj)
            lights_created.append(light_obj)
        
        # Select only the created lights
        bpy.ops.object.select_all(action='DESELECT')
        for light_obj in lights_created:
            light_obj.select_set(True)
        
        # Set the first light as active object
        if lights_created:
            context.view_layer.objects.active = lights_created[0]
        
        self.report({'INFO'}, f"Created {self.num_lights} light system at cursor position")
        return {'FINISHED'}

# --- End new operator ---

def register():
    bpy.utils.register_class(HHP_OT_CreateReflectionLight)
    bpy.utils.register_class(HHP_OT_CreateSunsetLight)
    bpy.utils.register_class(HHP_OT_CreateTargetedReflectionLight)
    bpy.utils.register_class(HHP_OT_SetupLightSystem)
    
    # Register scene property for targeted light
    bpy.types.Scene.hhp_targeted_light_mesh = bpy.props.PointerProperty(
        name="Target Mesh",
        description="Select the mesh to affect with the reflection light",
        type=bpy.types.Object
    )

def unregister():
    bpy.utils.unregister_class(HHP_OT_CreateSunsetLight)
    bpy.utils.unregister_class(HHP_OT_CreateReflectionLight)
    bpy.utils.unregister_class(HHP_OT_CreateTargetedReflectionLight)
    bpy.utils.unregister_class(HHP_OT_SetupLightSystem)
    
    # Unregister scene property
    del bpy.types.Scene.hhp_targeted_light_mesh

if __name__ == "__main__":
    register() 