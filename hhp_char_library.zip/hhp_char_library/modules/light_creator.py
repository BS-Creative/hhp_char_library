import bpy
from bpy.types import Operator
from math import radians
import mathutils
import random

def get_or_create_quick_lights_collection(context):
    """Get or create the main (BS) Quick Lights collection"""
    main_collection_name = "(BS) Quick Lights"
    main_collection = bpy.data.collections.get(main_collection_name)
    if not main_collection:
        main_collection = bpy.data.collections.new(main_collection_name)
        context.scene.collection.children.link(main_collection)
        main_collection.color_tag = 'COLOR_07'
    return main_collection

def get_or_create_sub_collection(context, main_collection, sub_collection_name):
    """Get or create a sub-collection within the main collection"""
    sub_collection = bpy.data.collections.get(sub_collection_name)
    if not sub_collection:
        sub_collection = bpy.data.collections.new(sub_collection_name)
        main_collection.children.link(sub_collection)
    return sub_collection

def apply_reflection_only_settings(light_obj: bpy.types.Object) -> None:
    """Apply 'reflection-only' visibility + Cycles light factors to a light object.

    This matches the requested behavior:
    - Hide from camera/diffuse/transmission/volume, allow glossy only
    - Light affects specular only (Cycles light factors)
    """
    if not light_obj:
        return

    # Object ray visibility (Blender 4.x)
    visibility_settings = {
        "visible_camera": False,
        "visible_diffuse": False,
        "visible_transmission": False,
        "visible_volume_scatter": False,
        "visible_glossy": True,
    }
    for prop_name, value in visibility_settings.items():
        if hasattr(light_obj, prop_name):
            setattr(light_obj, prop_name, value)

    # Cycles light contribution factors live on the light data
    light_data = getattr(light_obj, "data", None)
    if not light_data:
        return

    factor_settings = {
        "diffuse_factor": 0.0,
        "specular_factor": 1.0,
        "transmission_factor": 0.0,
        "volume_factor": 0.0,
    }
    for prop_name, value in factor_settings.items():
        if hasattr(light_data, prop_name):
            setattr(light_data, prop_name, value)

class HHP_OT_CreateReflectionLight(Operator):
    bl_idname = "hhp.create_reflection_light"
    bl_label = "Create Light (Reflection)"
    bl_description = "Create a reflection light at the 3D cursor position"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # Check if an object is selected and in a mode other than 'OBJECT'
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Deselect all objects
        bpy.ops.object.select_all(action='DESELECT')

        # Create a new point light data
        light_data = bpy.data.lights.new(name="(BS)_Reflection light", type='POINT')

        # Create a new light object
        light_object = bpy.data.objects.new(name="(BS)_Reflection light", object_data=light_data)

        # Get or create the collections
        main_collection = get_or_create_quick_lights_collection(context)
        reflection_collection = get_or_create_sub_collection(context, main_collection, "Reflection Lights")
        
        # Link the light object to the reflection collection
        reflection_collection.objects.link(light_object)

        # Set the light object at the cursor position
        light_object.location = context.scene.cursor.location

        # Set the properties of the light
        light_object.data.energy = 1
        light_object.data.diffuse_factor = 0
        light_object.data.volume_factor = 0
        light_object.data.shadow_soft_size = 0.02
        light_object.data.use_shadow = False

        # Make this a reflection-only light (glossy only)
        apply_reflection_only_settings(light_object)

        # Make the new light the active and only selected object
        context.view_layer.objects.active = light_object
        light_object.select_set(True)

        # Update the scene
        context.view_layer.update()
        
        self.report({'INFO'}, "Reflection light created at cursor position")
        return {'FINISHED'}

class HHP_OT_CreateSunsetLight(Operator):
    bl_idname = "hhp.create_sunset_light"
    bl_label = "Create Sunset Light"
    bl_description = "Create a sunset light at the 3D cursor position"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # Check if an object is selected and in a mode other than 'OBJECT'
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Define the light color (RGB)
        light_color = (1.000, 0.45668, 0.118074)

        # Get the current 3D cursor location
        cursor_location = context.scene.cursor.location

        # Create a new SUN light at the 3D cursor location
        bpy.ops.object.light_add(type='SUN', location=cursor_location)
        sunlight = context.object
        
        # Get or create the collections and move the light
        main_collection = get_or_create_quick_lights_collection(context)
        sunset_collection = get_or_create_sub_collection(context, main_collection, "Sunset Lights")
        
        # Remove from current collection and add to sunset collection
        for collection in sunlight.users_collection:
            collection.objects.unlink(sunlight)
        sunset_collection.objects.link(sunlight)

        # Set the sunlight color and strength
        sunlight.data.color = light_color
        sunlight.data.energy = 5.0

        # Set the light angle (converted from degrees to radians)
        sunlight.data.angle = radians(0.526)

        # Enable shadows
        sunlight.data.use_shadow = True

        # Set contact shadow properties only if they exist
        if hasattr(sunlight.data, "use_contact_shadow"):
            sunlight.data.use_contact_shadow = True
            sunlight.data.contact_shadow_distance = 0.02
            sunlight.data.contact_shadow_bias = 0.030
            sunlight.data.contact_shadow_thickness = 1.0

        # Set the rotation of the sunlight
        sunlight.rotation_euler = (radians(81.4834), radians(-35.4985), radians(-34.7197))

        # Update the scene
        context.view_layer.update()
        
        self.report({'INFO'}, "Sunset light created at cursor position")
        return {'FINISHED'}

# --- New operator: Create Targeted Reflection Light ---
class HHP_OT_CreateTargetedReflectionLight(bpy.types.Operator):
    bl_idname = "hhp.create_targeted_reflection_light"
    bl_label = "Create Targeted Light (Reflection)"
    bl_description = "Creates a reflection light targeting specific objects. Select target objects in the popup or use currently selected objects."
    bl_options = {"REGISTER", "UNDO"}

    use_selection_as_targets: bpy.props.BoolProperty(
        name="Use selection as targets",
        description="Use currently selected mesh objects as targets instead of picking a single object",
        default=False
    )

    def invoke(self, context, event):
        # Default to using selection if anything is selected
        self.use_selection_as_targets = len(context.selected_objects) > 0
        
        return context.window_manager.invoke_props_dialog(self, width=350)

    def draw(self, context):
        layout = self.layout
        
        # Show checkbox for using selection
        layout.prop(self, "use_selection_as_targets")
        
        # Show object picker only when not using selection
        if not self.use_selection_as_targets:
            layout.prop(context.scene, "hhp_targeted_light_mesh", text="Target Object", icon="EYEDROPPER")
        else:
            # Show disabled object picker to indicate it's not being used
            row = layout.row()
            row.enabled = False
            row.prop(context.scene, "hhp_targeted_light_mesh", text="Target Object", icon="EYEDROPPER")
            
            # Show error if nothing is selected
            if not context.selected_objects:
                layout.label(text="No objects selected. This light will affect everything.", icon='INFO')

    def execute(self, context):
        target_objects = []
        
        if self.use_selection_as_targets:
            # Use selected objects as targets
            selected_objects = list(context.selected_objects)
            target_objects = selected_objects
        else:
            # Use single picked object as target
            target_obj = context.scene.hhp_targeted_light_mesh
            target_objects = [target_obj] if target_obj else []
        
        # Check if an object is selected and in a mode other than 'OBJECT'
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Deselect all objects
        bpy.ops.object.select_all(action='DESELECT')
        
        # Create the light data (same settings as regular reflection light)
        light_data = bpy.data.lights.new(name="Targeted Reflection Light", type='POINT')
        light_data.energy = 1
        light_data.diffuse_factor = 0
        light_data.volume_factor = 0
        light_data.shadow_soft_size = 0.02
        light_data.use_shadow = False
        
        # Create the light object
        light_obj = bpy.data.objects.new(name="Targeted Reflection Light", object_data=light_data)

        # Make this a reflection-only light (glossy only)
        apply_reflection_only_settings(light_obj)
        
        # Position at 3D cursor
        light_obj.location = context.scene.cursor.location
        
        # Get or create the collections
        main_collection = get_or_create_quick_lights_collection(context)
        targeted_collection = get_or_create_sub_collection(context, main_collection, "Targeted Reflection Lights")
        
        # Link to targeted collection
        targeted_collection.objects.link(light_obj)

        # Optional: Light link to targets. If none specified, affect everything (normal light behavior).
        if target_objects:
            # Create a dedicated collection for light linking
            target_names = [obj.name for obj in target_objects]
            if len(target_names) > 2:
                linking_collection_name = f"LightLink_{len(target_names)}objects_{light_obj.name}"
            else:
                linking_collection_name = f"LightLink_{'_'.join(target_names)}_{light_obj.name}"

            linking_collection = bpy.data.collections.new(linking_collection_name)

            # Add all target objects to the linking collection
            for target_obj in target_objects:
                linking_collection.objects.link(target_obj)

            # Set up light linking (this is the key part)
            # Note: The exact API may vary, but this follows the general pattern
            try:
                # Try to access light linking properties (Blender 4.3+ specific)
                if hasattr(light_obj, 'light_linking'):
                    light_obj.light_linking.receiver_collection = linking_collection
                elif hasattr(light_data, 'light_linking'):
                    light_data.light_linking.receiver_collection = linking_collection
                elif hasattr(light_obj, 'data') and hasattr(light_obj.data, 'cycles'):
                    # Alternative approach through Cycles settings
                    if hasattr(light_obj.data.cycles, 'light_linking'):
                        light_obj.data.cycles.light_linking.receiver_collection = linking_collection
                else:
                    # Fallback: Store the target information in custom properties for manual setup
                    light_obj["target_objects"] = [obj.name for obj in target_objects]
                    light_obj["light_link_collection"] = linking_collection_name
                    self.report({'WARNING'}, "Light linking API not found. Target objects stored in custom properties. Please set up light linking manually in the light properties.")

            except Exception as e:
                # If light linking fails, store info for manual setup
                light_obj["target_objects"] = [obj.name for obj in target_objects]
                light_obj["light_link_collection"] = linking_collection_name
                self.report({'WARNING'}, f"Could not set up automatic light linking: {str(e)}. Please configure light linking manually.")
        
        # Select the new light
        bpy.context.view_layer.objects.active = light_obj
        light_obj.select_set(True)
        
        # Update the scene
        context.view_layer.update()
        
        if not target_objects:
            self.report({'INFO'}, "Created targeted reflection light (no targets selected; affects everything)")
        elif len(target_objects) == 1:
            self.report({'INFO'}, f"Created targeted reflection light for '{target_objects[0].name}'")
        else:
            self.report({'INFO'}, f"Created targeted reflection light for {len(target_objects)} objects")
        return {'FINISHED'}

# --- End new operator ---

# --- New operator: Create Targeted Light ---
class HHP_OT_CreateTargetedLight(bpy.types.Operator):
    bl_idname = "hhp.create_targeted_light"
    bl_label = "Create Targeted Light"
    bl_description = "Creates a light at the 3D cursor and light-links it to chosen object(s). Pick a single target or use the current selection, then control the light factors with the sliders."
    bl_options = {"REGISTER", "UNDO"}

    use_selection_as_targets: bpy.props.BoolProperty(
        name="Use selection as targets",
        description="Use currently selected objects as targets instead of picking a single object",
        default=False
    )

    diffuse_factor: bpy.props.FloatProperty(
        name="Diffuse",
        description="How much this light affects diffuse lighting",
        default=1.0,
        min=0.0,
        max=10000.0,
        soft_min=0.0,
        soft_max=1.0,
        step=0.1
    )

    specular_factor: bpy.props.FloatProperty(
        name="Glossy",
        description="How much this light affects glossy/specular highlights",
        default=1.0,
        min=0.0,
        max=10000.0,
        soft_min=0.0,
        soft_max=1.0,
        step=0.1
    )

    transmission_factor: bpy.props.FloatProperty(
        name="Transmission",
        description="How much this light affects transmission (glass/refraction)",
        default=1.0,
        min=0.0,
        max=10000.0,
        soft_min=0.0,
        soft_max=1.0,
        step=0.1
    )

    volume_factor: bpy.props.FloatProperty(
        name="Volume Scatter",
        description="How much this light affects volume scattering (smoke/fog)",
        default=1.0,
        min=0.0,
        max=10000.0,
        soft_min=0.0,
        soft_max=1.0,
        step=0.1
    )

    visible_diffuse: bpy.props.BoolProperty(
        name="Diffuse",
        description="Allow this light to contribute to diffuse lighting (ray visibility)",
        default=True,
    )

    visible_glossy: bpy.props.BoolProperty(
        name="Glossy",
        description="Allow this light to contribute to glossy/specular lighting (ray visibility)",
        default=True,
    )

    visible_transmission: bpy.props.BoolProperty(
        name="Transmission",
        description="Allow this light to contribute to transmission/refraction lighting (ray visibility)",
        default=True,
    )

    visible_volume_scatter: bpy.props.BoolProperty(
        name="Volume Scatter",
        description="Allow this light to contribute to volume scattering (ray visibility)",
        default=True,
    )

    def invoke(self, context, event):
        # Default to using selection if objects are selected
        selected_objects = list(context.selected_objects)
        self.use_selection_as_targets = len(selected_objects) > 0
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        layout = self.layout

        # Show checkbox for using selection (same pattern as targeted reflection light)
        layout.prop(self, "use_selection_as_targets")

        # Show object picker only when not using selection
        if not self.use_selection_as_targets:
            layout.prop(context.scene, "hhp_targeted_light_object", text="Target Object", icon="EYEDROPPER")
        else:
            # Show disabled object picker to indicate it's not being used
            row = layout.row()
            row.enabled = False
            row.prop(context.scene, "hhp_targeted_light_object", text="Target Object", icon="EYEDROPPER")

            # Show error if nothing is selected
            if not context.selected_objects:
                layout.label(text="No objects selected. This light will affect everything.", icon='INFO')

        # Sliders under the picker slot
        col = layout.column(align=True)

        r = col.row(align=True)
        r.enabled = bool(self.visible_diffuse)
        r.prop(self, "diffuse_factor")

        r = col.row(align=True)
        r.enabled = bool(self.visible_glossy)
        r.prop(self, "specular_factor")

        r = col.row(align=True)
        r.enabled = bool(self.visible_transmission)
        r.prop(self, "transmission_factor")

        r = col.row(align=True)
        r.enabled = bool(self.visible_volume_scatter)
        r.prop(self, "volume_factor")

        # Light ray visibility toggles (button-style, under sliders)
        vis_row = layout.row(align=True)
        vis_row.prop(self, "visible_diffuse", toggle=True)
        vis_row.prop(self, "visible_glossy", toggle=True)
        vis_row.prop(self, "visible_transmission", toggle=True)
        vis_row.prop(self, "visible_volume_scatter", toggle=True)

    def execute(self, context):
        target_objects = []

        if self.use_selection_as_targets:
            selected_objects = list(context.selected_objects)
            target_objects = selected_objects
        else:
            target_obj = context.scene.hhp_targeted_light_object
            target_objects = [target_obj] if target_obj else []

        # Check if an object is selected and in a mode other than 'OBJECT'
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Deselect all objects
        bpy.ops.object.select_all(action='DESELECT')

        # Helper for unique naming
        def get_unique_name(base_name: str) -> str:
            if base_name not in bpy.data.objects:
                return base_name
            counter = 1
            while f"{base_name}.{counter:03d}" in bpy.data.objects:
                counter += 1
            return f"{base_name}.{counter:03d}"

        # Create light data
        unique_name = get_unique_name("Targeted Light")
        light_data = bpy.data.lights.new(name=unique_name, type='POINT')
        light_data.energy = 1.0
        light_data.shadow_soft_size = 0.02
        light_data.use_shadow = True

        # Set requested factors (guarded for API differences)
        # Also clamp factors to 0 when their corresponding toggle is off.
        if hasattr(light_data, "diffuse_factor"):
            light_data.diffuse_factor = self.diffuse_factor if self.visible_diffuse else 0.0
        if hasattr(light_data, "specular_factor"):
            light_data.specular_factor = self.specular_factor if self.visible_glossy else 0.0
        if hasattr(light_data, "transmission_factor"):
            light_data.transmission_factor = self.transmission_factor if self.visible_transmission else 0.0
        if hasattr(light_data, "volume_factor"):
            light_data.volume_factor = self.volume_factor if self.visible_volume_scatter else 0.0

        # Create light object at 3D cursor
        light_obj = bpy.data.objects.new(name=unique_name, object_data=light_data)
        light_obj.location = context.scene.cursor.location

        # Apply ray visibility on the light object (guarded for API differences)
        if hasattr(light_obj, "visible_diffuse"):
            light_obj.visible_diffuse = self.visible_diffuse
        if hasattr(light_obj, "visible_glossy"):
            light_obj.visible_glossy = self.visible_glossy
        if hasattr(light_obj, "visible_transmission"):
            light_obj.visible_transmission = self.visible_transmission
        if hasattr(light_obj, "visible_volume_scatter"):
            light_obj.visible_volume_scatter = self.visible_volume_scatter

        # Get or create the collections
        main_collection = get_or_create_quick_lights_collection(context)
        targeted_collection = get_or_create_sub_collection(context, main_collection, "Targeted Lights")
        targeted_collection.objects.link(light_obj)

        # Optional: Light link to targets. If none specified, affect everything (normal light behavior).
        if target_objects:
            # Create a dedicated collection for light linking
            target_names = [obj.name for obj in target_objects]
            if len(target_names) > 2:
                linking_collection_name = f"LightLink_{len(target_names)}objects_{light_obj.name}"
            else:
                linking_collection_name = f"LightLink_{'_'.join(target_names)}_{light_obj.name}"
            linking_collection = bpy.data.collections.new(linking_collection_name)

            # Add all target objects to the linking collection
            for obj in target_objects:
                linking_collection.objects.link(obj)

            # Set up light linking (same approach as targeted reflection light)
            try:
                if hasattr(light_obj, 'light_linking'):
                    light_obj.light_linking.receiver_collection = linking_collection
                elif hasattr(light_data, 'light_linking'):
                    light_data.light_linking.receiver_collection = linking_collection
                elif hasattr(light_obj, 'data') and hasattr(light_obj.data, 'cycles'):
                    if hasattr(light_obj.data.cycles, 'light_linking'):
                        light_obj.data.cycles.light_linking.receiver_collection = linking_collection
                else:
                    light_obj["target_objects"] = [obj.name for obj in target_objects]
                    light_obj["light_link_collection"] = linking_collection_name
                    self.report({'WARNING'}, "Light linking API not found. Target stored in custom properties; please set up light linking manually.")
            except Exception as e:
                light_obj["target_objects"] = [obj.name for obj in target_objects]
                light_obj["light_link_collection"] = linking_collection_name
                self.report({'WARNING'}, f"Could not set up automatic light linking: {str(e)}. Please configure light linking manually.")

        # Select the new light
        context.view_layer.objects.active = light_obj
        light_obj.select_set(True)

        context.view_layer.update()
        if not target_objects:
            self.report({'INFO'}, "Created targeted light (no targets selected; affects everything)")
        elif len(target_objects) == 1:
            self.report({'INFO'}, f"Created targeted light for '{target_objects[0].name}'")
        else:
            self.report({'INFO'}, f"Created targeted light for {len(target_objects)} objects")
        return {'FINISHED'}

# --- End new operator ---

# --- New operator: Setup Light System ---
class HHP_OT_SetupLightSystem(bpy.types.Operator):
    bl_idname = "hhp.setup_light_system"
    bl_label = "Setup Light System"
    bl_description = "Creates a professional lighting setup with 1-10 lights positioned around the 3D Cursor or the median point of selected objects"
    bl_options = {"REGISTER", "UNDO"}

    placement_mode: bpy.props.EnumProperty(
        name="Mode",
        description="Choose what the light system is positioned around",
        items=[
            ('CURSOR', "3D Cursor", "Create the light system around the 3D Cursor position"),
            ('SELECTED', "Selected object(s)", "Create the light system around the median point of all selected objects"),
        ],
        default='CURSOR'
    )

    # Cached selection median pivot for redo usability. The operator selects the created lights,
    # so relying on context.selected_objects during redo would be incorrect.
    has_selection_pivot: bpy.props.BoolProperty(
        name="Has Selection Pivot",
        default=False,
        options={'HIDDEN'}
    )

    selection_pivot: bpy.props.FloatVectorProperty(
        name="Selection Pivot",
        description="Cached median point of the initially selected objects (world space)",
        subtype='XYZ',
        default=(0.0, 0.0, 0.0),
        size=3,
        options={'HIDDEN'}
    )

    seed: bpy.props.IntProperty(
        name="Seed",
        description="Random seed for reproducible lighting variations",
        default=0,
        min=0,
        max=10000
    )

    distance_multiplier: bpy.props.FloatProperty(
        name="Distance",
        description="Distance multiplier for light positioning around the cursor",
        default=1.0,
        min=0.0,
        step=1.0
    )

    saturation: bpy.props.FloatProperty(
        name="Color Saturation",
        description="Color saturation of the lights (0=grayscale, 1=full color)",
        default=1.0,
        min=0.0,
        max=10.0,
        step=1.0
    )

    power_multiplier: bpy.props.FloatProperty(
        name="Power",
        description="Power multiplier for all lights",
        default=1.0,
        min=0.0,
        step=1.0
    )

    num_lights: bpy.props.IntProperty(
        name="Number of Lights",
        description="Number of lights to create in the system",
        default=3,
        min=1,
        max=10
    )

    radius_multiplier: bpy.props.FloatProperty(
        name="Radius Multiplier",
        description="Radius multiplier for light softness/size",
        default=5.0,
        min=0.0,
        step=1.0
    )

    color_mode: bpy.props.EnumProperty(
        name="Color Mode",
        description="Choose the color palette for the lights",
        items=[
            ('MIXED', "Mixed Colors", "Traditional lighting setup with key, fill, and rim light colors"),
            ('WARM', "Warm Colors", "Saturated oranges to desaturated yellows"),
            ('COOL', "Cool Colors", "Sky blues to blueish whites"),
            ('RANDOM', "Random Colors", "Full spectrum random colors"),
            ('SPECIFIC', "Specific Color Range", "Variations of a specific color you choose")
        ],
        default='MIXED'
    )

    specific_color: bpy.props.FloatVectorProperty(
        name="Base Color",
        description="Base color for generating variations",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0),
        min=0.0,
        max=1.0,
        size=3
    )

    def draw(self, context):
        layout = self.layout
        
        # Use column layout for vertical alignment
        col = layout.column(align=True)

        # Mode selector at the top (side-by-side)
        row = col.row(align=True)
        row.prop_enum(self, "placement_mode", 'CURSOR')
        selected_btn = row.row(align=True)
        selected_btn.enabled = bool(self.has_selection_pivot)
        selected_btn.prop_enum(self, "placement_mode", 'SELECTED')
        
        # Show properties in original order
        col.prop(self, "seed")
        col.prop(self, "distance_multiplier")
        col.prop(self, "saturation")
        col.prop(self, "power_multiplier")
        col.prop(self, "num_lights")
        col.prop(self, "radius_multiplier")
        col.prop(self, "color_mode", text="")
        
        # Only show color picker when Specific Color Range mode is selected
        if self.color_mode == 'SPECIFIC':
            col.prop(self, "specific_color")

    def invoke(self, context, event):
        # Cache selection median pivot for redo panel usability.
        # We intentionally use object origins (world translation), per request.
        selected_objects = list(context.selected_objects)
        if selected_objects:
            median = mathutils.Vector((0.0, 0.0, 0.0))
            for obj in selected_objects:
                median += obj.matrix_world.translation
            median /= float(len(selected_objects))
            self.selection_pivot = median
            self.has_selection_pivot = True
        else:
            self.has_selection_pivot = False

        # If user tries Selected mode with nothing selected, force Cursor mode.
        if self.placement_mode == 'SELECTED' and not self.has_selection_pivot:
            self.placement_mode = 'CURSOR'

        return self.execute(context)

    def execute(self, context):
        # Initialize random seed (treat 0 as 521)
        actual_seed = 521 if self.seed == 0 else self.seed
        random.seed(actual_seed)
        
        # Check if an object is selected and in a mode other than 'OBJECT'
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Get or create the collections
        main_collection = get_or_create_quick_lights_collection(context)
        lights_collection = get_or_create_sub_collection(context, main_collection, "Light System")
        
        # Determine target position (cursor or median of selected mesh objects)
        target_pos = context.scene.cursor.location.copy()
        placement_label = "3D cursor"

        if self.placement_mode == 'SELECTED':
            if not self.has_selection_pivot:
                self.report({'WARNING'}, "Mode is set to 'Selected object(s)' but no objects were selected when you ran the operator. Falling back to 3D Cursor.")
                self.placement_mode = 'CURSOR'
            else:
                target_pos = mathutils.Vector(self.selection_pivot)
                placement_label = "selection median"
        
        # Helper function to generate unique light names
        def get_unique_name(base_name):
            if base_name not in [obj.name for obj in bpy.data.objects]:
                return base_name
            
            counter = 1
            while f"{base_name}.{counter:03d}" in [obj.name for obj in bpy.data.objects]:
                counter += 1
            return f"{base_name}.{counter:03d}"
        
        # Calculate appropriate distance based on user setting
        base_distance = 1.2  # New default base distance
        light_distance = base_distance * self.distance_multiplier
        
        # When distance is 0, lights should be exactly at cursor - no minimum override
        
        # Helper function to adjust color saturation
        def adjust_saturation(color, saturation):
            # Convert to HSV, adjust saturation, convert back
            r, g, b = color
            # Simple saturation adjustment - scale by 1.5 so that slider value 1.0 = actual saturation 1.5
            actual_saturation = saturation * 1.5
            gray = (r + g + b) / 3
            return (
                gray + (r - gray) * actual_saturation,
                gray + (g - gray) * actual_saturation,
                gray + (b - gray) * actual_saturation
            )
        
        # Create the lighting setup
        lights_created = []
        
        import math
        
        for i in range(self.num_lights):
            # Determine light name and characteristics
            if i == 0 and self.num_lights >= 3:
                light_name = "Key Light"
                energy_range = (60, 90)
            elif i == 1 and self.num_lights >= 3:
                light_name = "Fill Light"
                energy_range = (25, 50)
            elif i == 2 and self.num_lights >= 3:
                light_name = "Rim Light"
                energy_range = (40, 60)
            else:
                light_name = f"Light {i + 1}"
                energy_range = (30, 70)
            
            # Create light data
            unique_name = get_unique_name(light_name)
            light_data = bpy.data.lights.new(name=unique_name, type='POINT')
            light_data.energy = random.uniform(*energy_range) * self.power_multiplier
            
            if self.color_mode == 'MIXED':
                # Traditional mixed lighting with different colors for different light types
                if i == 0 and self.num_lights >= 3:
                    # Key Light: Warm white variation
                    light_data.color = (
                        random.uniform(0.8, 1.0),
                        random.uniform(0.7, 1.0),
                        random.uniform(0.4, 0.9)
                    )
                elif i == 1 and self.num_lights >= 3:
                    # Fill Light: Cool white/blue variation
                    light_data.color = (
                        random.uniform(0.4, 0.9),
                        random.uniform(0.6, 1.0),
                        random.uniform(0.8, 1.0)
                    )
                elif i == 2 and self.num_lights >= 3:
                    # Rim Light: Purple/cool variation
                    light_data.color = (
                        random.uniform(0.6, 1.0),
                        random.uniform(0.4, 0.9),
                        random.uniform(0.7, 1.0)
                    )
                else:
                    # Additional lights: Full color variation
                    light_data.color = (
                        random.uniform(0.4, 1.0),
                        random.uniform(0.4, 1.0),
                        random.uniform(0.4, 1.0)
                    )
            elif self.color_mode == 'WARM':
                light_data.color = (
                    random.uniform(0.8, 1.0),
                    random.uniform(0.6, 0.9),
                    random.uniform(0.4, 0.7)
                )
            elif self.color_mode == 'COOL':
                light_data.color = (
                    random.uniform(0.6, 1.0),
                    random.uniform(0.8, 1.0),
                    random.uniform(0.9, 1.0)
                )
            elif self.color_mode == 'RANDOM':
                light_data.color = (
                    random.uniform(0.0, 1.0),
                    random.uniform(0.0, 1.0),
                    random.uniform(0.0, 1.0)
                )
            elif self.color_mode == 'SPECIFIC':
                # Generate variations of the specific color
                base_r, base_g, base_b = self.specific_color
                variation_amount = 0.25  # How much variation to allow
                
                # Add random variation to each channel
                varied_r = base_r + random.uniform(-variation_amount, variation_amount)
                varied_g = base_g + random.uniform(-variation_amount, variation_amount)
                varied_b = base_b + random.uniform(-variation_amount, variation_amount)
                
                # Clamp values to 0.0-1.0 range
                light_data.color = (
                    max(0.0, min(1.0, varied_r)),
                    max(0.0, min(1.0, varied_g)),
                    max(0.0, min(1.0, varied_b))
                )
            
            light_data.color = adjust_saturation(light_data.color, self.saturation)
            light_data.shadow_soft_size = random.uniform(0.015, 0.05) * self.radius_multiplier
            light_data.use_shadow = True
            
            # Create light object
            light_obj = bpy.data.objects.new(name=unique_name, object_data=light_data)
            
            # Position lights in a circle around cursor if distance > 0
            if light_distance > 0:
                if self.num_lights == 1:
                    # Single light: place randomly around cursor
                    light_pos = target_pos + mathutils.Vector([
                        light_distance * random.uniform(-1.0, 1.0),
                        light_distance * random.uniform(-1.0, 1.0),
                        light_distance * random.uniform(-0.5, 1.5)
                    ])
                elif i == 0:  # First light always uses key position
                    light_pos = target_pos + mathutils.Vector([
                        light_distance * random.uniform(0.6, 0.9),
                        light_distance * random.uniform(-0.8, -0.4),
                        light_distance * random.uniform(0.5, 1.0)
                    ])
                elif i == 1:  # Second light always uses fill position
                    light_pos = target_pos + mathutils.Vector([
                        light_distance * random.uniform(-0.9, -0.6),
                        light_distance * random.uniform(-0.6, -0.2),
                        light_distance * random.uniform(-0.2, 0.4)
                    ])
                elif i == 2:  # Third light always uses rim position
                    light_pos = target_pos + mathutils.Vector([
                        light_distance * random.uniform(-0.3, 0.3),
                        light_distance * random.uniform(0.7, 1.2),
                        light_distance * random.uniform(0.6, 1.3)
                    ])
                else:
                    # Additional lights (4+) use circular distribution
                    # Start from light 4, so subtract 3 from index for circle calculation
                    circle_index = i - 3
                    total_circle_lights = self.num_lights - 3
                    angle = (circle_index / total_circle_lights) * 2 * math.pi
                    radius_variation = random.uniform(0.8, 1.2)
                    height_variation = random.uniform(-0.5, 1.5)
                    
                    light_pos = target_pos + mathutils.Vector([
                        light_distance * math.cos(angle) * radius_variation,
                        light_distance * math.sin(angle) * radius_variation,
                        light_distance * height_variation
                    ])
            else:
                # All lights at cursor position when distance is 0
                light_pos = target_pos
            
            light_obj.location = light_pos
            lights_collection.objects.link(light_obj)
            lights_created.append(light_obj)
        
        # Select only the created lights
        bpy.ops.object.select_all(action='DESELECT')
        for light_obj in lights_created:
            light_obj.select_set(True)
        
        # Set the first light as active object
        if lights_created:
            context.view_layer.objects.active = lights_created[0]
        
        self.report({'INFO'}, f"Created {self.num_lights} light system at {placement_label}")
        return {'FINISHED'}

# --- End new operator ---

def register():
    bpy.utils.register_class(HHP_OT_CreateReflectionLight)
    bpy.utils.register_class(HHP_OT_CreateSunsetLight)
    bpy.utils.register_class(HHP_OT_CreateTargetedReflectionLight)
    bpy.utils.register_class(HHP_OT_CreateTargetedLight)
    bpy.utils.register_class(HHP_OT_SetupLightSystem)
    
    # Register scene property for targeted light
    bpy.types.Scene.hhp_targeted_light_mesh = bpy.props.PointerProperty(
        name="Target Object",
        description="Select the object to affect with the targeted reflection light",
        type=bpy.types.Object
    )

    bpy.types.Scene.hhp_targeted_light_object = bpy.props.PointerProperty(
        name="Target Object",
        description="Select the object to be affected by the targeted light",
        type=bpy.types.Object
    )

def unregister():
    bpy.utils.unregister_class(HHP_OT_CreateSunsetLight)
    bpy.utils.unregister_class(HHP_OT_CreateReflectionLight)
    bpy.utils.unregister_class(HHP_OT_CreateTargetedReflectionLight)
    bpy.utils.unregister_class(HHP_OT_CreateTargetedLight)
    bpy.utils.unregister_class(HHP_OT_SetupLightSystem)
    
    # Unregister scene property
    del bpy.types.Scene.hhp_targeted_light_mesh
    del bpy.types.Scene.hhp_targeted_light_object

if __name__ == "__main__":
    register() 