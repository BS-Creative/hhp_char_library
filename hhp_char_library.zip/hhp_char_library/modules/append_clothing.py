import bpy
import json
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Operator, PropertyGroup, UIList
import os
import re
from ..Customize_HHP import capture_outfit_preset, apply_outfit_preset
from . import hhp_naming

PROTECTED_ASSET_COLLECTION_BASES = {
    "Clothes",
    "Char Specific Proxies",
    "Char Appendage",
    "Hair",
    "Collision",
}
EXCLUDED_COLLISION_OBJECT_NAME = "collision - linked (do not edit mesh)"
_SOURCE_CLOTHING_COLLECTION_CACHE = {}


def _iter_blend_ids():
    """Yield every loaded Blender ID without assuming a fixed bpy.data schema."""
    seen = set()
    for prop in bpy.data.bl_rna.properties:
        identifier = prop.identifier
        if identifier == "rna_type":
            continue
        values = getattr(bpy.data, identifier, None)
        if values is None or not hasattr(values, "__iter__"):
            continue
        try:
            iterator = iter(values)
        except TypeError:
            continue
        for item in iterator:
            if not isinstance(item, bpy.types.ID):
                continue
            pointer = item.as_pointer()
            if pointer in seen:
                continue
            seen.add(pointer)
            yield item


def _remove_temporary_linked_ids(existing_id_pointers, existing_library_pointers, abs_filepath):
    """Remove only IDs introduced by a temporary linked-library inspection."""
    new_linked_ids = [
        item for item in _iter_blend_ids()
        if item.as_pointer() not in existing_id_pointers
        and item.library is not None
        and bpy.path.abspath(item.library.filepath) == abs_filepath
    ]
    if new_linked_ids:
        bpy.data.batch_remove(ids=new_linked_ids)

    for library in list(bpy.data.libraries):
        if (
            library.as_pointer() not in existing_library_pointers
            and bpy.path.abspath(library.filepath) == abs_filepath
        ):
            bpy.data.libraries.remove(library)


def get_source_clothing_collections(filepath):
    """List the immediate child collections of the source file's Clothes root."""
    abs_filepath = bpy.path.abspath(filepath) if filepath else ""
    if not abs_filepath or not os.path.exists(abs_filepath):
        return []
    try:
        stamp = os.path.getmtime(abs_filepath)
    except OSError:
        return []
    cached = _SOURCE_CLOTHING_COLLECTION_CACHE.get(abs_filepath)
    if cached and cached[0] == stamp:
        return list(cached[1])
    existing_id_pointers = {item.as_pointer() for item in _iter_blend_ids()}
    existing_library_pointers = {library.as_pointer() for library in bpy.data.libraries}
    names = []
    try:
        with bpy.data.libraries.load(abs_filepath, link=True) as (data_from, data_to):
            clothes_roots = [
                name for name in data_from.collections
                if get_base_object_name(name).casefold() == "clothes"
            ]
            if not clothes_roots:
                _SOURCE_CLOTHING_COLLECTION_CACHE[abs_filepath] = (stamp, tuple())
                return []
            root_name = min(
                clothes_roots,
                key=lambda name: (get_enumeration_number(name), name.casefold()),
            )
            data_to.collections = [root_name]
        root_collection = data_to.collections[0] if data_to.collections else None
        if root_collection:
            names = [child.name for child in root_collection.children]
    except Exception:
        return []
    finally:
        _remove_temporary_linked_ids(
            existing_id_pointers,
            existing_library_pointers,
            abs_filepath,
        )

    names.sort(key=lambda name: (get_enumeration_number(name), name.casefold()))
    _SOURCE_CLOTHING_COLLECTION_CACHE[abs_filepath] = (stamp, tuple(names))
    return names


def encode_source_clothing_collections(names):
    return json.dumps(list(names), ensure_ascii=False)


def decode_source_clothing_collections(payload):
    try:
        names = json.loads(payload or "[]")
    except (TypeError, ValueError, json.JSONDecodeError):
        return []
    if not isinstance(names, list):
        return []
    return [name for name in names if isinstance(name, str) and name]

def mesh_poll(self, obj):
    return obj.type == 'MESH'

def get_top_parent_collection(obj):
    """Get the highest parent collection of an object (just before the scene collection)"""
    if not obj.users_collection:
        return None
    
    # Start with the first collection the object is in
    current_collection = obj.users_collection[0]
    
    # Keep going up until we find a collection that's a direct child of the scene collection
    while current_collection:
        # Check if this collection is a direct child of the scene collection
        if current_collection.name in bpy.context.scene.collection.children:
            return current_collection
        
        # Find the parent collection
        parent_collections = [coll for coll in bpy.data.collections if current_collection.name in coll.children]
        if not parent_collections:
            break
        
        current_collection = parent_collections[0]
    
    return current_collection

def find_primary_fullbody_proxy(source_mesh):
    """Find 'Deform Proxy - Primary (Fullbody)' meshes in the same parent collection as the source mesh"""
    if not source_mesh:
        return []
    
    # Get the top parent collection of the source mesh
    parent_collection = get_top_parent_collection(source_mesh)
    if not parent_collection:
        return []
    
    # Find all objects in this collection and its children that match the criteria
    primary_fullbody_candidates = []
    
    def search_collection(collection):
        for obj in collection.objects:
            if (obj.type == 'MESH' and 
                "Deform Proxy" in obj.name and 
                "Primary" in obj.name and 
                "Fullbody" in obj.name):
                primary_fullbody_candidates.append(obj)
        
        # Search in child collections
        for child in collection.children:
            search_collection(child)
    
    # Start the search from the parent collection
    search_collection(parent_collection)
    
    return primary_fullbody_candidates

def find_asset_category_collections_in_parent(source_mesh, category_name):
    """Find character category roots without descending into asset packs."""
    if not source_mesh:
        return []
    parent_collection = get_top_parent_collection(source_mesh)
    if not parent_collection:
        return []

    # Eyes is also a category boundary even though this operator does not append it.
    boundaries = {name.casefold() for name in PROTECTED_ASSET_COLLECTION_BASES} | {"eyes"}
    wanted = category_name.casefold()
    found = []
    visited = set()

    def search_collection(collection):
        if collection in visited:
            return
        visited.add(collection)
        for child in collection.children:
            name = get_base_object_name(child.name).casefold()
            if name == wanted and child not in found:
                found.append(child)
            # A pack's own Hair/Clothes/etc. folders belong to that pack. Only
            # ordinary containers (including Appendages) may hold category roots.
            if name not in boundaries:
                search_collection(child)

    search_collection(parent_collection)
    return found


def find_clothes_collections_in_parent(source_mesh):
    """Find canonical Clothes roots belonging to the character."""
    return find_asset_category_collections_in_parent(source_mesh, "Clothes")


def find_char_specific_proxies_collections_in_parent(source_mesh):
    """Find canonical Char Specific Proxies roots belonging to the character."""
    return find_asset_category_collections_in_parent(source_mesh, "Char Specific Proxies")


def find_char_appendage_collections_in_parent(source_mesh):
    """Find canonical Char Appendage roots belonging to the character."""
    return find_asset_category_collections_in_parent(source_mesh, "Char Appendage")


def find_hair_collections_in_parent(source_mesh):
    """Find canonical Hair roots belonging to the character."""
    return find_asset_category_collections_in_parent(source_mesh, "Hair")


def find_collision_collections_in_parent(source_mesh):
    """Find canonical Collision roots, lowest enumeration first."""
    collision_collections = find_asset_category_collections_in_parent(source_mesh, "Collision")
    collision_collections.sort(
        key=lambda collection: (
            get_enumeration_number(collection.name),
            collection.name.lower(),
        )
    )
    return collision_collections


def remove_excluded_collision_meshes(collection):
    """Remove linked collision helper meshes from an appended Collision tree."""
    removed = 0
    for obj in list(collection.objects):
        if (
            getattr(obj, "type", None) == 'MESH'
            and EXCLUDED_COLLISION_OBJECT_NAME in obj.name.lower()
        ):
            bpy.data.objects.remove(obj, do_unlink=True)
            removed += 1
    for child in collection.children:
        removed += remove_excluded_collision_meshes(child)
    return removed

def get_all_children_and_objects_recursively(collection, item_list):
    """Recursively collect all objects and child collections from a given collection."""
    item_list.extend(collection.objects)
    item_list.extend(collection.children)
    for child in collection.children:
        get_all_children_and_objects_recursively(child, item_list)

def update_presets_after_append(source_mesh, new_items):
    """
    Updates all presets on the source_mesh to include new_items as hidden.
    1. Stores original visibility of new items.
    2. Hides new items.
    3. For each preset, applies it, then recaptures the state. This adds the new items as hidden.
    4. Restores original visibility of new items in the viewport.
    """
    if not source_mesh or "presets" not in source_mesh or not new_items:
        return

    # 1. Store original visibility of new items
    original_states = {item: (item.hide_viewport, item.hide_render) for item in new_items}

    # 2. Set new items to be hidden
    for item in new_items:
        item.hide_viewport = True
        item.hide_render = True

    context = bpy.context
    original_active_object = context.view_layer.objects.active
    if source_mesh != original_active_object:
        context.view_layer.objects.active = source_mesh
    
    presets = source_mesh["presets"]
    for preset_name in list(presets.keys()):
        preset_data = presets[preset_name]
        
        # 3a. Apply the collections part of the preset to restore old item visibility
        if "collections" in preset_data:
            apply_outfit_preset(preset_data["collections"])

        # 3b. Capture the new state, now including new items as hidden
        updated_collections_state = capture_outfit_preset(context)
        
        # 3c. Update the preset data in-place
        presets[preset_name]["collections"] = updated_collections_state

    # Restore original active object
    if source_mesh != original_active_object:
        context.view_layer.objects.active = original_active_object

    # 4. Restore original visibility of new items
    for item, (hide_v, hide_r) in original_states.items():
        item.hide_viewport = hide_v
        item.hide_render = hide_r

def get_base_object_name(name):
    """Strips numerical suffixes like .001 from an object name."""
    return re.sub(r'\.\d+$', '', name)


def get_enumeration_number(name):
    match = re.search(r'\.(\d+)$', name or "")
    return int(match.group(1)) if match else 0


def is_char_specific_proxies_collection(collection):
    return (
        collection is not None
        and get_base_object_name(collection.name).lower() == "char specific proxies"
    )


def find_highest_visible_hhp_character_mesh(context):
    """Find the highest-enumerated visible HHP character body mesh."""
    candidates = []
    for obj in context.scene.objects:
        if getattr(obj, "type", None) != 'MESH':
            continue
        if not hhp_naming.base_name_matches_any(obj.name, hhp_naming.CHAR_MESH_OBJECT_NAMES):
            continue
        mesh_data = getattr(obj, "data", None)
        if mesh_data and not hhp_naming.base_name_matches_any(mesh_data.name, hhp_naming.CHAR_MESH_DATA_NAMES):
            continue
        if obj.hide_viewport or obj.hide_get(view_layer=context.view_layer):
            continue
        if not obj.visible_get(view_layer=context.view_layer):
            continue
        candidates.append(obj)

    if not candidates:
        return None

    candidates.sort(
        key=lambda obj: (get_enumeration_number(obj.name), obj.name.lower()),
        reverse=True,
    )
    return candidates[0]


def remove_object(obj):
    """Remove an object without depending on any other addon."""
    if not obj or obj.name not in bpy.data.objects:
        return []
    user_collections = list(obj.users_collection)
    bpy.data.objects.remove(obj, do_unlink=True)
    return user_collections


def get_parent_collections(collection):
    if not collection:
        return []
    return [
        parent for parent in bpy.data.collections
        if collection.name in parent.children
    ]


def collection_has_parent_base(collection, base_name):
    pending = [collection]
    seen = set()
    target_base = base_name.lower()

    while pending:
        current = pending.pop()
        if not current:
            continue
        pointer = current.as_pointer()
        if pointer in seen:
            continue
        seen.add(pointer)

        if get_base_object_name(current.name).lower() == target_base:
            return True
        pending.extend(get_parent_collections(current))

    return False


def object_is_in_collection_base(obj, base_name):
    if not obj:
        return False
    return any(
        collection_has_parent_base(collection, base_name)
        for collection in obj.users_collection
    )


def remove_empty_collection(collection):
    if not collection or collection.name not in bpy.data.collections:
        return

    for parent in get_parent_collections(collection):
        if collection.name in parent.children:
            parent.children.unlink(collection)

    if collection.name in bpy.context.scene.collection.children:
        bpy.context.scene.collection.children.unlink(collection)

    bpy.data.collections.remove(collection)


def cleanup_empty_asset_collections(collections):
    """Remove now-empty asset collections while keeping category roots in place."""
    pending = list(collections or [])
    seen = set()

    while pending:
        collection = pending.pop()
        if not collection or collection.name not in bpy.data.collections:
            continue

        pointer = collection.as_pointer()
        if pointer in seen:
            continue
        seen.add(pointer)

        if get_base_object_name(collection.name) in PROTECTED_ASSET_COLLECTION_BASES:
            continue
        if len(collection.objects) > 0 or len(collection.children) > 0:
            continue

        parents = get_parent_collections(collection)
        remove_empty_collection(collection)
        pending.extend(parents)


def collect_collection_meshes(collection, meshes=None):
    if meshes is None:
        meshes = []
    if not collection:
        return meshes

    for obj in collection.objects:
        if getattr(obj, "type", None) == 'MESH':
            meshes.append(obj)
    for child in collection.children:
        collect_collection_meshes(child, meshes)
    return meshes


def object_uses_surface_deform_target(obj, target):
    if not is_valid_object(obj) or not is_valid_object(target) or getattr(obj, "type", None) != 'MESH':
        return False
    for mod in obj.modifiers:
        if getattr(mod, "type", None) == 'SURFACE_DEFORM' and getattr(mod, "target", None) == target:
            return True
    return False


def replace_surface_deform_target(old_target, new_target):
    """Retarget every Surface Deform modifier using an object being removed."""
    if not is_valid_object(old_target) or not is_valid_object(new_target):
        return 0

    updated = 0
    for obj in bpy.data.objects:
        if getattr(obj, "type", None) != 'MESH':
            continue
        for mod in obj.modifiers:
            if (
                getattr(mod, "type", None) == 'SURFACE_DEFORM'
                and getattr(mod, "target", None) == old_target
            ):
                mod.target = new_target
                updated += 1
    return updated


def is_valid_object(obj):
    try:
        return obj is not None and obj.name in bpy.data.objects
    except ReferenceError:
        return False


def cleanup_unused_char_specific_proxy_meshes(char_root_collection_name, proxy_collection_name):
    char_root = bpy.data.collections.get(char_root_collection_name) if char_root_collection_name else None
    proxy_collection = bpy.data.collections.get(proxy_collection_name) if proxy_collection_name else None
    if not char_root or not proxy_collection:
        return 0

    character_meshes = collect_collection_meshes(char_root)
    proxy_meshes = collect_collection_meshes(proxy_collection)
    removed = 0

    for proxy_obj in list(proxy_meshes):
        if not is_valid_object(proxy_obj):
            continue
        is_used = any(
            obj is not proxy_obj and object_uses_surface_deform_target(obj, proxy_obj)
            for obj in character_meshes
            if is_valid_object(obj)
        )
        if is_used:
            continue
        cleanup_empty_asset_collections(remove_object(proxy_obj))
        removed += 1

    return removed


class HHP_CHARLIB_UL_asset_clash_list(UIList):
    """UI list that lets the user pick which duplicate appended asset to keep."""

    bl_idname = "HHP_CHARLIB_UL_asset_clash_list"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type not in {'DEFAULT', 'COMPACT'}:
            return

        layout.use_property_split = False
        layout.use_property_decorate = False

        row = layout.row(align=True)
        row.alert = item.is_surface_deform_target
        split = row.split(factor=0.2, align=True)

        col = split.column(align=True)
        col.prop_enum(item, "choice", 'APPENDED', text="", icon='TRIA_LEFT')

        split = split.split(factor=0.75, align=True)
        info_col = split.column(align=True)
        if item.is_surface_deform_target:
            info_col.label(
                text=f"{item.base_name or '(Unnamed Asset)'} (Deformer. Keep it)",
                icon='MOD_MESHDEFORM',
            )
        else:
            info_col.label(text=item.base_name or "(Unnamed Asset)", icon='OUTLINER_OB_MESH')

        choice_split = split.split(factor=0.35, align=True)
        choice_split.prop_enum(item, "choice", 'BOTH', text="", icon='DUPLICATE')
        choice_split.prop_enum(item, "choice", 'EXISTING', text="", icon='TRIA_RIGHT')


class HHP_CHARLIB_AssetClashItem(PropertyGroup):
    """Stores one duplicate asset clash found during clothing append."""

    base_name: StringProperty(name="Base Name")
    appended_name: StringProperty(name="Appended Asset Name")
    existing_name: StringProperty(name="Existing Asset Name")
    is_surface_deform_target: BoolProperty(
        name="Surface Deform Target",
        description="This clash was included because the appended mesh is used as a Surface Deform target",
        default=False,
    )
    choice: EnumProperty(
        name="Keep",
        description="Decide whether to keep the appended asset or the existing character asset",
        items=[
            ('APPENDED', 'Appended', 'Keep the newly appended asset', 'TRIA_LEFT', 0),
            ('EXISTING', 'Existing', 'Keep the asset already on the character', 'TRIA_RIGHT', 1),
            ('BOTH', 'Both', 'Keep both the appended and existing assets', 'DUPLICATE', 2),
        ],
        default='EXISTING',
    )
    appended_obj: PointerProperty(
        name="Appended Object",
        type=bpy.types.Object,
    )
    existing_obj: PointerProperty(
        name="Existing Object",
        type=bpy.types.Object,
    )


class HHP_CHARLIB_OT_asset_clash_set_all(Operator):
    """Batch-assign the same choice to every appended asset clash."""

    bl_idname = "hhp_char_library.asset_clash_set_all"
    bl_label = "Set All Appended Asset Clashes"
    bl_description = "Set the same choice for every appended asset clash"
    bl_options = {'REGISTER'}

    choice: EnumProperty(
        name="Choice",
        items=[
            ('APPENDED', 'Appended', 'Keep all newly appended assets'),
            ('BOTH', 'Both', 'Keep all appended and existing assets'),
            ('EXISTING', 'Existing', 'Keep all assets already on the character'),
        ],
        default='EXISTING',
    )

    def execute(self, context):
        clashes = getattr(context.window_manager, "hhp_char_library_asset_clashes", None)
        if not clashes:
            return {'CANCELLED'}

        for item in clashes:
            item.choice = self.choice
        return {'FINISHED'}


class HHP_CHARLIB_OT_asset_clash_resolver(Operator):
    """Dialog that lets the user resolve duplicate assets after appending."""

    bl_idname = "hhp_char_library.asset_clash_resolver"
    bl_label = "Resolve Appended Asset Clashes"
    bl_description = "Choose whether to keep appended or existing assets when names clash"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        wm = context.window_manager
        return hasattr(wm, "hhp_char_library_asset_clashes") and len(wm.hhp_char_library_asset_clashes) > 0

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=460)

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        num_clashes = len(wm.hhp_char_library_asset_clashes)

        col = layout.column()
        col.label(text=f"Found {num_clashes} asset name clash(es). Choose which version to keep.", icon='ERROR')

        layout.separator()
        header_split = layout.split(factor=0.5, align=True)
        header_left = header_split.column(align=True)
        header_left.alignment = 'LEFT'
        header_left.label(text="Appended")
        header_right = header_split.column(align=True)
        header_right.alignment = 'RIGHT'
        header_right.label(text="Existing")

        layout.template_list(
            "HHP_CHARLIB_UL_asset_clash_list",
            "",
            wm,
            "hhp_char_library_asset_clashes",
            wm,
            "hhp_char_library_asset_clash_active_index",
            rows=6,
            maxrows=10,
        )

        layout.separator()
        layout.label(text="Batch Operations:")
        row = layout.row(align=True)
        op_appended = row.operator("hhp_char_library.asset_clash_set_all", text="Set All to Appended", icon='TRIA_LEFT')
        op_appended.choice = 'APPENDED'
        op_both = row.operator("hhp_char_library.asset_clash_set_all", text="All to Both", icon='DUPLICATE')
        op_both.choice = 'BOTH'
        op_existing = row.operator("hhp_char_library.asset_clash_set_all", text="Set All to Existing", icon='TRIA_RIGHT')
        op_existing.choice = 'EXISTING'

    def execute(self, context):
        wm = context.window_manager
        clashes = getattr(wm, "hhp_char_library_asset_clashes", None)
        if not clashes:
            self.report({'WARNING'}, "No appended asset clashes to resolve.")
            return {'CANCELLED'}

        # Capture pointers before deleting anything: Blender clears later RNA
        # rows that reference an object removed by an earlier batch decision.
        objects = {}
        decisions = []
        for clash in clashes:
            pointers = []
            for obj in (clash.appended_obj, clash.existing_obj):
                pointer = obj.as_pointer() if is_valid_object(obj) else None
                pointers.append(pointer)
                if pointer is not None:
                    objects[pointer] = obj
            desired_name = clash.existing_name or (
                clash.existing_obj.name if is_valid_object(clash.existing_obj)
                else clash.appended_name
            )
            decisions.append((clash.choice, *pointers, desired_name))

        replacements = {}

        def survivor(pointer):
            while pointer in replacements:
                pointer = replacements[pointer]
            obj = objects.get(pointer)
            return obj if is_valid_object(obj) else None

        resolved = 0
        skipped = 0
        for choice, appended_pointer, existing_pointer, desired_name in decisions:
            if choice == 'BOTH':
                resolved += 1
                continue
            appended_obj = survivor(appended_pointer)
            existing_obj = survivor(existing_pointer)
            keeper, discarded = (
                (appended_obj, existing_obj) if choice == 'APPENDED'
                else (existing_obj, appended_obj)
            )
            # A user may delete an asset while the dialog is open. Never delete
            # the other side when the requested keeper no longer exists.
            if keeper is None:
                skipped += 1
                continue
            if discarded is not None and discarded != keeper:
                replacements[discarded.as_pointer()] = keeper.as_pointer()
                replace_surface_deform_target(discarded, keeper)
                cleanup_empty_asset_collections(remove_object(discarded))
            if desired_name:
                keeper.name = desired_name
            resolved += 1

        clashes.clear()
        removed_proxies = cleanup_unused_char_specific_proxy_meshes(
            getattr(wm, "hhp_char_library_asset_clash_char_root", ""),
            getattr(wm, "hhp_char_library_asset_clash_proxy_collection", ""),
        )
        wm.hhp_char_library_asset_clash_char_root = ""
        wm.hhp_char_library_asset_clash_proxy_collection = ""

        message = f"Resolved {resolved} appended asset clash(es)."
        if removed_proxies:
            message += f" Removed {removed_proxies} unused char specific proxy mesh(es)."
        self.report({'INFO'}, message)
        if skipped:
            self.report({'WARNING'}, f"Skipped {skipped} clash(es) because the requested asset no longer exists.")
        return {'FINISHED'}

    def cancel(self, context):
        clashes = getattr(context.window_manager, "hhp_char_library_asset_clashes", None)
        if clashes is not None:
            clashes.clear()
        context.window_manager.hhp_char_library_asset_clash_char_root = ""
        context.window_manager.hhp_char_library_asset_clash_proxy_collection = ""
        return {'CANCELLED'}


HHP_CHARLIB_ASSET_CLASH_CLASSES = (
    HHP_CHARLIB_UL_asset_clash_list,
    HHP_CHARLIB_AssetClashItem,
    HHP_CHARLIB_OT_asset_clash_set_all,
    HHP_CHARLIB_OT_asset_clash_resolver,
)


def collect_mesh_assets_by_base(collections, include_char_specific=False):
    assets_by_base = {}
    seen_collections = set()
    seen_objects = set()

    def walk(collection):
        if collection.as_pointer() in seen_collections:
            return
        seen_collections.add(collection.as_pointer())
        if is_char_specific_proxies_collection(collection) and not include_char_specific:
            return
        for obj in collection.objects:
            if getattr(obj, "type", None) != 'MESH' or obj.as_pointer() in seen_objects:
                continue
            seen_objects.add(obj.as_pointer())
            base = get_base_object_name(obj.name)
            if base:
                assets_by_base.setdefault(base, []).append(obj)
        for child in collection.children:
            walk(child)

    for collection in collections:
        if collection:
            walk(collection)

    for objects in assets_by_base.values():
        objects.sort(key=lambda obj: (get_enumeration_number(obj.name), obj.name.lower()))

    return assets_by_base


def collect_descendant_collection_bases(collections):
    collection_bases = set()

    for collection in collections:
        if not collection or is_char_specific_proxies_collection(collection):
            continue
        for child in collection.children:
            base = get_base_object_name(child.name)
            if base:
                collection_bases.add(base)

    return collection_bases


def get_top_asset_collection_base(collection):
    current = collection
    fallback_base = None

    while current:
        current_base = get_base_object_name(current.name)
        parents = get_parent_collections(current)
        if not parents:
            return fallback_base

        parent = parents[0]
        parent_base = get_base_object_name(parent.name)
        if parent_base in PROTECTED_ASSET_COLLECTION_BASES:
            return current_base

        fallback_base = current_base
        current = parent

    return fallback_base


def object_belongs_to_clashing_collection(obj, clashing_collection_bases):
    for collection in getattr(obj, "users_collection", []) or []:
        # Hair and collision assets can be stored directly in their category
        # roots instead of inside per-asset child collections.
        if get_base_object_name(collection.name) in {"Hair", "Collision"}:
            return True
        base = get_top_asset_collection_base(collection)
        if base and base in clashing_collection_bases:
            return True

    return False


def collect_surface_deform_target_pointers(collections):
    """Find deformer dependencies across all imported asset categories."""
    targets = set()
    assets = collect_mesh_assets_by_base(collections, include_char_specific=True)
    for objects in assets.values():
        for obj in objects:
            for mod in obj.modifiers:
                target = getattr(mod, "target", None)
                if getattr(mod, "type", None) == 'SURFACE_DEFORM' and is_valid_object(target):
                    targets.add(target.as_pointer())
    return targets


def build_asset_clash_records(
    appended_collections, existing_assets_by_base, clashing_collection_bases=None,
    surface_deform_target_pointers=None,
):
    """Match meshes in the caller's asset scope, independent of folder layout.

    The legacy collection-name argument is accepted for compatibility, but does
    not filter direct meshes or detached, specifically selected outfit folders.
    """
    clash_records = []
    used_existing = set()
    seen_objects = set()
    seen_collections = set()
    if surface_deform_target_pointers is None:
        surface_deform_target_pointers = collect_surface_deform_target_pointers(appended_collections)

    def walk(collection):
        if collection.as_pointer() in seen_collections:
            return
        seen_collections.add(collection.as_pointer())
        for obj in list(collection.objects):
            if getattr(obj, "type", None) != 'MESH' or obj.as_pointer() in seen_objects:
                continue
            seen_objects.add(obj.as_pointer())
            is_surface_deform_target = obj.as_pointer() in surface_deform_target_pointers
            base = get_base_object_name(obj.name)
            candidates = existing_assets_by_base.get(base)
            if not candidates:
                continue

            existing_obj = None
            for candidate in candidates:
                if not is_valid_object(candidate):
                    continue
                pointer = candidate.as_pointer()
                if pointer in used_existing or candidate == obj:
                    continue
                existing_obj = candidate
                break

            if not existing_obj:
                # More incoming copies than existing copies still need a row.
                # The resolver follows whichever object survives prior choices.
                existing_obj = next((candidate for candidate in candidates
                                     if is_valid_object(candidate) and candidate != obj), None)
                if existing_obj is None:
                    continue

            used_existing.add(existing_obj.as_pointer())
            clash_records.append({
                "base_name": base,
                "appended_obj": obj,
                "existing_obj": existing_obj,
                "is_surface_deform_target": is_surface_deform_target,
            })

        for child in collection.children:
            walk(child)

    for collection in appended_collections:
        walk(collection)

    return clash_records


def launch_asset_clash_resolver(
    context,
    clash_records,
    char_root_collection=None,
    char_specific_proxy_collection=None,
):
    if not clash_records:
        return False

    wm = context.window_manager
    clashes = getattr(wm, "hhp_char_library_asset_clashes", None)
    if clashes is None:
        print("Appended asset clashes detected but library clash properties are not registered.")
        return False

    clashes.clear()
    added = 0
    for record in clash_records:
        appended_obj = record.get("appended_obj")
        existing_obj = record.get("existing_obj")
        if not appended_obj or not existing_obj:
            continue
        item = clashes.add()
        item.base_name = record["base_name"]
        item.appended_name = appended_obj.name
        item.existing_name = existing_obj.name
        item.appended_obj = appended_obj
        item.existing_obj = existing_obj
        item.is_surface_deform_target = record.get("is_surface_deform_target", False)
        item.choice = 'BOTH' if item.is_surface_deform_target else 'EXISTING'
        added += 1

    if not added:
        clashes.clear()
        return False

    wm.hhp_char_library_asset_clash_active_index = 0
    wm.hhp_char_library_asset_clash_char_root = char_root_collection.name if char_root_collection else ""
    wm.hhp_char_library_asset_clash_proxy_collection = (
        char_specific_proxy_collection.name if char_specific_proxy_collection else ""
    )
    try:
        bpy.ops.hhp_char_library.asset_clash_resolver('INVOKE_DEFAULT')
    except Exception as exc:
        print(f"Failed to launch appended asset clash resolver: {exc}")
        return False
    return True


def retarget_shapekey_driver_targets(obj, new_mesh, new_armature):
    """
    Update shapekey driver variables on obj so they point to the provided
    character mesh and armature instead of the original appended targets.
    Returns the number of driver targets that were updated.
    """
    if not obj or obj.type != 'MESH':
        return 0

    data = getattr(obj, "data", None)
    if not data:
        return 0

    shape_keys = getattr(data, "shape_keys", None)
    if not shape_keys:
        return 0

    anim = getattr(shape_keys, "animation_data", None)
    if not anim or not getattr(anim, "drivers", None):
        return 0

    updated = 0
    for fcurve in anim.drivers:
        driver = getattr(fcurve, "driver", None)
        if not driver or not getattr(driver, "variables", None):
            continue
        for var in driver.variables:
            targets = getattr(var, "targets", None)
            if not targets:
                continue
            for target in targets:
                if not target:
                    continue
                id_obj = getattr(target, "id", None)
                # We only care about object ID targets
                if not isinstance(id_obj, bpy.types.Object):
                    continue

                # If driver references any armature, retarget to the chosen armature
                if id_obj.type == 'ARMATURE' and new_armature and id_obj is not new_armature:
                    target.id = new_armature
                    updated += 1
                # If driver references a mesh that is not this mesh, retarget to the chosen body mesh
                elif id_obj.type == 'MESH' and new_mesh and id_obj is not new_mesh and id_obj is not obj:
                    target.id = new_mesh
                    updated += 1

    if updated:
        print(f"Retargeted {updated} shapekey driver target(s) on '{obj.name}'")
    return updated

def find_object_in_hierarchy(start_collection, base_name):
    """Recursively search for an object with a given base name in a collection hierarchy."""
    # Check objects in the current collection
    for obj in start_collection.objects:
        if get_base_object_name(obj.name) == base_name:
            return obj
            
    # Recurse into child collections
    for child_collection in start_collection.children:
        found_obj = find_object_in_hierarchy(child_collection, base_name)
        if found_obj:
            return found_obj
            
    return None

class OT_ApplyRemap(Operator):
    """Apply Armature and Surface Deform targets to selected meshes"""
    bl_idname = "object.apply_remap"
    bl_label = "Apply Remap Targets"
    bl_options = {'UNDO'}

    sd_target_name: StringProperty()
    filepath: StringProperty(subtype="FILE_PATH")
    source_clothing_collection_names_json: StringProperty(options={'HIDDEN'})
    append_hair: BoolProperty(default=False)
    append_collisions: BoolProperty(default=False)
    append_toggled_off: BoolProperty(default=False)

    def execute(self, context):
        scene = context.scene
        src = scene.armature_source
        if not src:
            self.report({'ERROR'}, "No source mesh selected")
            return {'CANCELLED'}

        # Armature target lookup
        arm_mod = next((m for m in src.modifiers if m.type == 'ARMATURE' and m.object), None)
        if not arm_mod:
            self.report({'ERROR'}, f"'{src.name}' has no Armature modifier with a valid target")
            return {'CANCELLED'}
        arm_obj = arm_mod.object

        # Surface Deform target lookup from popup choice
        sd_target = bpy.data.objects.get(self.sd_target_name)
        if not sd_target:
            self.report({'ERROR'}, f"Surface Deform target '{self.sd_target_name}' not found")
            return {'CANCELLED'}

        # Now execute the append clothing operation with the selected targets
        result = bpy.ops.wm.append_clothing_execute(
            filepath=self.filepath,
            source_clothing_collection_names_json=self.source_clothing_collection_names_json,
            source_mesh_name=src.name,
            sd_target_name=sd_target.name,
            append_hair=self.append_hair,
            append_collisions=self.append_collisions,
            append_toggled_off=self.append_toggled_off
        )
        
        return result

class OT_SelectClothesCollection(Operator):
    """Select which Clothes collection to use"""
    bl_idname = "object.select_clothes_collection"
    bl_label = "Select Clothes Collection"
    bl_options = {'UNDO'}
    
    collection_name: StringProperty()
    filepath: StringProperty(subtype="FILE_PATH")
    source_clothing_collection_names_json: StringProperty(options={'HIDDEN'})
    source_mesh_name: StringProperty()
    sd_target_name: StringProperty()
    append_hair: BoolProperty(default=False)
    append_collisions: BoolProperty(default=False)
    append_toggled_off: BoolProperty(default=False)

    def execute(self, context):
        # Execute the append clothing operation with the selected collection
        result = bpy.ops.wm.append_clothing_execute(
            filepath=self.filepath,
            source_clothing_collection_names_json=self.source_clothing_collection_names_json,
            source_mesh_name=self.source_mesh_name,
            sd_target_name=self.sd_target_name,
            target_collection_name=self.collection_name,
            append_hair=self.append_hair,
            append_collisions=self.append_collisions,
            append_toggled_off=self.append_toggled_off,
        )
        return result

def draw_sd_menu(self, context):
    layout = self.layout
    scene = context.scene
    src = scene.armature_source
    filepath = scene.append_clothing_filepath

    # Get all candidates
    all_candidates = []
    
    # First, check for "Deform Proxy - Primary (Fullbody)" objects in the same parent collection
    primary_fullbody_candidates = find_primary_fullbody_proxy(src)
    
    # Add primary fullbody candidates to the list
    for o in primary_fullbody_candidates:
        all_candidates.append(o)
    
    # Add other meshes sharing the same mesh data
    data_candidates = [
        o for o in context.scene.objects
        if o.type == 'MESH' and o.data == src.data and o != src and o not in primary_fullbody_candidates
    ]
    
    # Add data candidates to the list
    for o in data_candidates:
        all_candidates.append(o)
    
    # Sort candidates: primary fullbody proxies first (in numerical order), then others
    def get_sort_key(obj):
        if obj in primary_fullbody_candidates:
            # Extract number from name if it exists, otherwise use 0
            import re
            match = re.search(r'(\d+)', obj.name)
            num = int(match.group(1)) if match else 0
            return (0, num)  # Primary fullbody proxies first, sorted by number
        return (1, 0)  # Other meshes after
    
    all_candidates.sort(key=get_sort_key)
    
    # Get the append_hair setting from the scene
    append_hair = getattr(scene, 'append_hair_setting', False)
    append_collisions = getattr(scene, 'append_collisions_setting', False)
    append_toggled_off = getattr(scene, 'append_toggled_off_setting', False)
    source_clothing_collection_names_json = getattr(
        scene,
        'append_source_clothing_collections_json',
        '[]',
    )
    
    # Display primary fullbody candidates first
    for o in all_candidates:
        if o in primary_fullbody_candidates:
            op = layout.operator(OT_ApplyRemap.bl_idname, text=o.name)
            op.sd_target_name = o.name
            op.filepath = filepath
            op.source_clothing_collection_names_json = source_clothing_collection_names_json
            op.append_hair = append_hair
            op.append_collisions = append_collisions
            op.append_toggled_off = append_toggled_off
    
    # Add a separator after primary fullbody candidates
    if primary_fullbody_candidates and (data_candidates or src):
        layout.separator()
    
    # Display other candidates
    for o in all_candidates:
        if o not in primary_fullbody_candidates:
            op = layout.operator(OT_ApplyRemap.bl_idname, text=o.name)
            op.sd_target_name = o.name
            op.filepath = filepath
            op.source_clothing_collection_names_json = source_clothing_collection_names_json
            op.append_hair = append_hair
            op.append_collisions = append_collisions
            op.append_toggled_off = append_toggled_off
    
    # Option to use the source mesh itself (at the bottom)
    op = layout.operator(OT_ApplyRemap.bl_idname, text="Source Mesh (not recommended)")
    op.sd_target_name = src.name
    op.filepath = filepath
    op.source_clothing_collection_names_json = source_clothing_collection_names_json
    op.append_hair = append_hair
    op.append_collisions = append_collisions
    op.append_toggled_off = append_toggled_off

class HHP_AppendClothingSourceItem(PropertyGroup):
    """One selectable immediate child of the source Clothes collection."""

    selected: BoolProperty(
        name="Selected",
        description="Include this clothing collection in the append operation",
        default=False,
    )


class HHP_UL_AppendClothingSourceCollections(UIList):
    """Boolean-style multi-select list for source clothing collections."""

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.prop(
                item,
                "selected",
                text=item.name,
                icon='CHECKBOX_HLT' if item.selected else 'CHECKBOX_DEHLT',
                toggle=True,
            )
        else:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='CHECKBOX_HLT' if item.selected else 'CHECKBOX_DEHLT')


def update_clothing_selection_mode(self, context):
    """Inspect the source hierarchy only when specific selection is requested."""
    if self.clothing_mode != 'SPECIFIC' or self.source_clothing_collections_loaded:
        return
    self.source_clothing_collections.clear()
    for collection_name in get_source_clothing_collections(self.filepath):
        item = self.source_clothing_collections.add()
        item.name = collection_name
        item.selected = False
    self.source_clothing_collection_index = 0
    self.source_clothing_collections_loaded = True


class WM_OT_AppendClothingDialog(Operator):
    """Dialog to select source mesh before appending clothing, char specific proxies, char appendages, and hair"""
    bl_idname = "wm.append_clothing_dialog"
    bl_label = "Auto remapper (fitting options)"
    bl_description = "Choose remapping options before appending clothing, char specific proxies, char appendages, and hair"
    bl_options = set()

    filepath: StringProperty(subtype="FILE_PATH")
    clothing_mode: EnumProperty(
        name="Clothing Selection",
        description="Choose whether to append every clothing collection or selected collections only",
        items=(
            ('ALL', "All Clothing", "Append every immediate child collection under Clothes"),
            ('SPECIFIC', "Specific Collection", "Choose one or more immediate child collections under Clothes"),
        ),
        default='ALL',
        update=update_clothing_selection_mode,
    )
    source_clothing_collections_loaded: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})
    source_clothing_collections: CollectionProperty(type=HHP_AppendClothingSourceItem)
    source_clothing_collection_index: IntProperty(default=0, options={'HIDDEN'})
    append_toggled_off: BoolProperty(
        name="Append toggled off",
        description="Disable the appended assets after updating presets",
        default=False
    )
    append_hair: BoolProperty(
        name="Append Hair with assets",
        description="Include hair collections when appending",
        default=False
    )
    append_collisions: BoolProperty(
        name="Append Collisions",
        description="Append and remap collision meshes, excluding linked collision helper meshes",
        default=False
    )

    def invoke(self, context, event):
        # Store the filepath in the scene for later use
        context.scene.append_clothing_filepath = self.filepath
        self.clothing_mode = 'ALL'
        self.source_clothing_collections.clear()
        self.source_clothing_collections_loaded = False
        self.source_clothing_collection_index = 0
        context.scene.append_source_clothing_collections_json = '[]'
        default_source_mesh = find_highest_visible_hhp_character_mesh(context)
        if default_source_mesh:
            context.scene.armature_source = default_source_mesh
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.prop(context.scene, "armature_source", text="Source Mesh")
        layout.label(text="Select the HHP character mesh you want to remap appended assets to")
        layout.label(text="If no source mesh is selected, assets will be appended without remapping")
        layout.separator()
        mode_row = layout.row(align=True)
        mode_row.prop(self, "clothing_mode", expand=True)
        if self.clothing_mode == 'SPECIFIC':
            if self.source_clothing_collections:
                source_box = layout.box()
                source_box.template_list(
                    "HHP_UL_AppendClothingSourceCollections",
                    "",
                    self,
                    "source_clothing_collections",
                    self,
                    "source_clothing_collection_index",
                    rows=min(10, max(3, len(self.source_clothing_collections))),
                )
                source_box.label(
                    text="Toggle any number of clothing collections",
                    icon='INFO',
                )
            else:
                layout.label(text="No collections found directly under Clothes", icon='ERROR')
        layout.separator()
        layout.prop(self, "append_toggled_off")
        layout.prop(self, "append_hair")
        layout.prop(self, "append_collisions")

    def execute(self, context):
        # Store the source mesh selection
        source_mesh = context.scene.armature_source
        selected_source_collections = []
        if self.clothing_mode == 'SPECIFIC':
            selected_source_collections = [
                item.name for item in self.source_clothing_collections if item.selected
            ]
            if not selected_source_collections:
                self.report({'ERROR'}, "Select at least one clothing collection")
                return {'CANCELLED'}
        selected_source_collections_json = encode_source_clothing_collections(
            selected_source_collections
        )
        context.scene.append_source_clothing_collections_json = selected_source_collections_json
        
        if not source_mesh:
            # If no source mesh selected, just append without remapping
            result = bpy.ops.wm.append_clothing_execute(
                filepath=self.filepath,
                source_clothing_collection_names_json=selected_source_collections_json,
                append_hair=self.append_hair,
                append_collisions=self.append_collisions,
                append_toggled_off=self.append_toggled_off,
            )
            return result
        
        # Check for armature modifier
        arm_mod = next((m for m in source_mesh.modifiers if m.type == 'ARMATURE' and m.object), None)
        if not arm_mod:
            self.report({'ERROR'}, f"'{source_mesh.name}' has no Armature modifier with a valid target")
            return {'CANCELLED'}
        
        # First, check for "Deform Proxy - Primary (Fullbody)" objects in the same parent collection
        primary_fullbody_candidates = find_primary_fullbody_proxy(source_mesh)
        
        # If exactly one primary fullbody proxy found, use it
        if len(primary_fullbody_candidates) == 1:
            sd_target = primary_fullbody_candidates[0]
            result = bpy.ops.wm.append_clothing_execute(
                filepath=self.filepath,
                source_clothing_collection_names_json=selected_source_collections_json,
                source_mesh_name=source_mesh.name,
                sd_target_name=sd_target.name,
                append_hair=self.append_hair,
                append_collisions=self.append_collisions,
                append_toggled_off=self.append_toggled_off
            )
            return result
        
        # If multiple primary fullbody proxies found, show popup
        if primary_fullbody_candidates:
            # Store append_hair setting for the popup
            context.scene.append_hair_setting = self.append_hair
            context.scene.append_collisions_setting = self.append_collisions
            context.scene.append_toggled_off_setting = self.append_toggled_off
            context.window_manager.popup_menu(
                draw_sd_menu,
                title="Choose Deformation Cage",
                icon='MESH_DATA'
            )
            return {'FINISHED'}
        
        # If no primary fullbody proxies found, fall back to meshes sharing the same mesh data
        data_candidates = [
            o for o in context.scene.objects
            if o.type == 'MESH' and o.data == source_mesh.data and o != source_mesh
        ]

        # If exactly one candidate, auto-apply
        if len(data_candidates) == 1:
            sd_target = data_candidates[0]
            result = bpy.ops.wm.append_clothing_execute(
                filepath=self.filepath,
                source_clothing_collection_names_json=selected_source_collections_json,
                source_mesh_name=source_mesh.name,
                sd_target_name=sd_target.name,
                append_hair=self.append_hair,
                append_collisions=self.append_collisions,
                append_toggled_off=self.append_toggled_off
            )
            return result
        else:
            # Multiple or none: show popup with all candidates
            # Store append_hair setting for the popup
            context.scene.append_hair_setting = self.append_hair
            context.scene.append_collisions_setting = self.append_collisions
            context.scene.append_toggled_off_setting = self.append_toggled_off
            context.window_manager.popup_menu(
                draw_sd_menu,
                title="Choose Deformation Cage",
                icon='MESH_DATA'
            )
            return {'FINISHED'}

class WM_OT_AppendClothing(Operator):
    bl_idname = "wm.append_clothing"
    bl_label = "Append Clothing & Accessories"
    bl_description = "Append and remap clothing, accessories, hair, and optional collision meshes from the selected file"
    bl_options = set()

    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        # Show the dialog first
        bpy.ops.wm.append_clothing_dialog('INVOKE_DEFAULT', filepath=self.filepath)
        return {'FINISHED'}

class WM_OT_AppendClothingExecute(Operator):
    bl_idname = "wm.append_clothing_execute"
    bl_label = "Execute Append Clothing"
    bl_description = "Execute the clothing, proxy, appendage, hair, and collision append operation"
    bl_options = set()

    filepath: StringProperty(subtype="FILE_PATH")
    source_clothing_collection_names_json: StringProperty(options={'HIDDEN'})
    source_mesh_name: StringProperty()
    sd_target_name: StringProperty()
    target_collection_name: StringProperty()
    append_hair: BoolProperty(default=False)
    append_collisions: BoolProperty(default=False)
    append_toggled_off: BoolProperty(default=False)

    def apply_remapping_to_appended_meshes(
        self,
        context,
        appended_collections,
        source_mesh_name,
        sd_target_name,
        preserved_surface_deform_targets=None,
    ):
        """Apply armature and surface deform remapping to appended meshes"""
        source_mesh = bpy.data.objects.get(source_mesh_name)
        sd_target = bpy.data.objects.get(sd_target_name)
        preserved_surface_deform_targets = preserved_surface_deform_targets or set()
        
        if not source_mesh or not sd_target:
            return
        
        # Get the armature from the source mesh
        arm_mod = next((m for m in source_mesh.modifiers if m.type == 'ARMATURE' and m.object), None)
        if not arm_mod:
            return
        
        arm_obj = arm_mod.object
        arm_count = 0
        sd_smart_count = 0
        constraint_count = 0
        lattice_childof_count = 0
        shapekey_driver_retarget_count = 0
        character_collection = get_top_parent_collection(source_mesh)
        
        def process_collection(collection, is_hair_collection=False, is_char_specific_collection=False):
            nonlocal arm_count, sd_smart_count, constraint_count, lattice_childof_count, shapekey_driver_retarget_count
            for obj in collection.objects:
                if obj.type == 'MESH':
                    # Apply armature modifier
                    existing_arm_mod = next((m for m in obj.modifiers if m.type == 'ARMATURE'), None)
                    if existing_arm_mod:
                        existing_arm_mod.object = arm_obj
                        arm_count += 1

                    # Retarget shapekey drivers that reference the original body/armature
                    shapekey_driver_retarget_count += retarget_shapekey_driver_targets(
                        obj,
                        source_mesh,
                        arm_obj
                    )
                    
                    # Retarget only when the destination character contains an
                    # equivalent mesh. Otherwise preserve the appended target.
                    for mod in obj.modifiers:
                        if mod.type == 'SURFACE_DEFORM':
                            original_target = mod.target
                            if not original_target or not character_collection:
                                continue
                            if original_target.as_pointer() in preserved_surface_deform_targets:
                                continue

                            base_name = get_base_object_name(original_target.name)
                            equivalent_target = find_object_in_hierarchy(character_collection, base_name)
                            if (
                                equivalent_target
                                and equivalent_target.type == 'MESH'
                                and equivalent_target != original_target
                            ):
                                mod.target = equivalent_target
                                sd_smart_count += 1
                    
                    # Apply object constraint remapping
                    for constraint in obj.constraints:
                        if hasattr(constraint, 'target') and constraint.target:
                            constraint.target = source_mesh
                            constraint_count += 1
                elif obj.type == 'LATTICE' and is_char_specific_collection:
                    # Retarget Child Of constraints on lattices in Char Specific Proxies to the armature
                    for constraint in obj.constraints:
                        if getattr(constraint, 'type', None) == 'CHILD_OF':
                            constraint.target = arm_obj
                            lattice_childof_count += 1
            
            # Process child collections recursively
            for child in collection.children:
                # Check if child collection is a hair collection
                child_is_hair = child.name.lower().startswith("hair")
                child_is_char_specific = child.name.lower().startswith("char specific proxies") or is_char_specific_collection
                process_collection(child, is_hair_collection or child_is_hair, child_is_char_specific)

        for collection in appended_collections:
            # Check if this collection is a hair collection
            is_hair = collection.name.lower().startswith("hair")
            is_char_specific = collection.name.lower().startswith("char specific proxies")
            process_collection(collection, is_hair, is_char_specific)

        # Build report message
        report_parts = []
        if arm_count > 0:
            report_parts.append(f"{arm_count} Armature modifiers")
        if sd_smart_count > 0:
            report_parts.append(f"{sd_smart_count} Surface Deform modifiers to equivalent targets")
        if constraint_count > 0:
            report_parts.append(f"{constraint_count} Object constraints to '{source_mesh.name}'")
        if lattice_childof_count > 0:
            report_parts.append(f"{lattice_childof_count} Lattice 'Child Of' constraints to armature '{arm_obj.name}'")
        if shapekey_driver_retarget_count > 0:
            report_parts.append(f"{shapekey_driver_retarget_count} shapekey driver target(s) retargeted")
        
        if report_parts:
            self.report({'INFO'}, f"Remapped {', '.join(report_parts)}")

    def execute(self, context):
        if not self.filepath or not os.path.exists(self.filepath):
            self.report({'ERROR'}, "Filepath not set or file does not exist.")
            return {'CANCELLED'}

        abs_filepath = bpy.path.abspath(self.filepath)
        context.scene.append_hair_setting = self.append_hair
        context.scene.append_collisions_setting = self.append_collisions
        context.scene.append_toggled_off_setting = self.append_toggled_off
        context.scene.append_source_clothing_collections_json = self.source_clothing_collection_names_json
        selected_source_clothing_names = decode_source_clothing_collections(
            self.source_clothing_collection_names_json
        )
        
        # Find the target collections
        target_clothes_collection = None
        target_char_specific_proxies_collection = None
        target_char_appendage_collection = None
        target_hair_collection = None
        target_collision_collection = None
        
        if self.target_collection_name:
            target_clothes_collection = bpy.data.collections.get(self.target_collection_name)
        
        if not target_clothes_collection:
            # If no target collection specified, find or create one in the source mesh's parent collection
            source_mesh = bpy.data.objects.get(self.source_mesh_name)
            if source_mesh:
                clothes_collections = find_clothes_collections_in_parent(source_mesh)
                if len(clothes_collections) == 1:
                    target_clothes_collection = clothes_collections[0]
                elif len(clothes_collections) > 1:
                    # Store necessary info for the popup
                    context.scene.sd_target_name = self.sd_target_name
                    context.window_manager.popup_menu(
                        draw_clothes_collection_menu,
                        title="Choose Clothes Collection",
                        icon='OUTLINER_COLLECTION'
                    )
                    return {'FINISHED'}
        
        # Find or create target char specific proxies collection
        source_mesh = bpy.data.objects.get(self.source_mesh_name)
        if source_mesh:
            char_specific_proxies_collections = find_char_specific_proxies_collections_in_parent(source_mesh)
            if len(char_specific_proxies_collections) == 1:
                target_char_specific_proxies_collection = char_specific_proxies_collections[0]
            elif len(char_specific_proxies_collections) > 1:
                # Use the first one found for now
                target_char_specific_proxies_collection = char_specific_proxies_collections[0]
        
        # Find or create target char appendage collection
        source_mesh = bpy.data.objects.get(self.source_mesh_name)
        if source_mesh:
            char_appendage_collections = find_char_appendage_collections_in_parent(source_mesh)
            if len(char_appendage_collections) == 1:
                target_char_appendage_collection = char_appendage_collections[0]
            elif len(char_appendage_collections) > 1:
                # Use the first one found for now
                target_char_appendage_collection = char_appendage_collections[0]
        
        # Find or create target hair collection
        source_mesh = bpy.data.objects.get(self.source_mesh_name)
        if source_mesh:
            hair_collections = find_hair_collections_in_parent(source_mesh)
            if len(hair_collections) == 1:
                target_hair_collection = hair_collections[0]
            elif len(hair_collections) > 1:
                # Use the first one found for now
                target_hair_collection = hair_collections[0]

        # Find the lowest-enumerated exact Collision root on the target character.
        if source_mesh and self.append_collisions:
            collision_collections = find_collision_collections_in_parent(source_mesh)
            if collision_collections:
                target_collision_collection = collision_collections[0]
        
        if not target_clothes_collection:
            # If still no target collection, create one in the source mesh's parent collection
            source_mesh = bpy.data.objects.get(self.source_mesh_name)
            if source_mesh:
                parent_collection = get_top_parent_collection(source_mesh)
                if parent_collection:
                    target_clothes_collection = bpy.data.collections.new("Clothes")
                    parent_collection.children.link(target_clothes_collection)
                else:
                    target_clothes_collection = bpy.data.collections.new("Clothes")
                    context.scene.collection.children.link(target_clothes_collection)
            else:
                target_clothes_collection = bpy.data.collections.new("Clothes")
                context.scene.collection.children.link(target_clothes_collection)
        
        if not target_char_specific_proxies_collection:
            # Create char specific proxies collection in the source mesh's parent collection
            source_mesh = bpy.data.objects.get(self.source_mesh_name)
            if source_mesh:
                parent_collection = get_top_parent_collection(source_mesh)
                if parent_collection:
                    target_char_specific_proxies_collection = bpy.data.collections.new("Char Specific Proxies")
                    parent_collection.children.link(target_char_specific_proxies_collection)
                else:
                    target_char_specific_proxies_collection = bpy.data.collections.new("Char Specific Proxies")
                    context.scene.collection.children.link(target_char_specific_proxies_collection)
            else:
                target_char_specific_proxies_collection = bpy.data.collections.new("Char Specific Proxies")
                context.scene.collection.children.link(target_char_specific_proxies_collection)
        
        if not target_char_appendage_collection:
            # Create char appendage collection in the source mesh's parent collection
            source_mesh = bpy.data.objects.get(self.source_mesh_name)
            if source_mesh:
                parent_collection = get_top_parent_collection(source_mesh)
                if parent_collection:
                    target_char_appendage_collection = bpy.data.collections.new("Char Appendage")
                    parent_collection.children.link(target_char_appendage_collection)
                else:
                    target_char_appendage_collection = bpy.data.collections.new("Char Appendage")
                    context.scene.collection.children.link(target_char_appendage_collection)
            else:
                target_char_appendage_collection = bpy.data.collections.new("Char Appendage")
                context.scene.collection.children.link(target_char_appendage_collection)
        
        if not target_hair_collection:
            # Create hair collection in the source mesh's parent collection
            source_mesh = bpy.data.objects.get(self.source_mesh_name)
            if source_mesh:
                parent_collection = get_top_parent_collection(source_mesh)
                if parent_collection:
                    target_hair_collection = bpy.data.collections.new("Hair")
                    parent_collection.children.link(target_hair_collection)
                else:
                    target_hair_collection = bpy.data.collections.new("Hair")
                    context.scene.collection.children.link(target_hair_collection)
            else:
                target_hair_collection = bpy.data.collections.new("Hair")
                context.scene.collection.children.link(target_hair_collection)

        if self.append_collisions and not target_collision_collection:
            source_mesh = bpy.data.objects.get(self.source_mesh_name)
            parent_collection = get_top_parent_collection(source_mesh) if source_mesh else None
            target_collision_collection = bpy.data.collections.new("Collision")
            if parent_collection:
                parent_collection.children.link(target_collision_collection)
            else:
                context.scene.collection.children.link(target_collision_collection)
            target_collision_collection.color_tag = 'COLOR_08'

        target_asset_collections = {
            "Clothes": target_clothes_collection,
            "Char Specific Proxies": target_char_specific_proxies_collection,
            "Char Appendage": target_char_appendage_collection,
            "Hair": target_hair_collection if self.append_hair else None,
            "Collision": target_collision_collection if self.append_collisions else None,
        }
        existing_assets_by_category = {
            category: collect_mesh_assets_by_base([collection], include_char_specific=True)
            for category, collection in target_asset_collections.items()
        }
        
        # Find collections to append from the file
        clothes_collections_in_file = []
        char_specific_proxies_collections_in_file = []
        char_appendage_collections_in_file = []
        hair_collections_in_file = []
        collision_collections_in_file = []
        
        try:
            with bpy.data.libraries.load(abs_filepath, link=False) as (data_from, data_to):
                available_collection_names = set(data_from.collections)
                if selected_source_clothing_names:
                    missing_names = [
                        name for name in selected_source_clothing_names
                        if name not in available_collection_names
                    ]
                    if missing_names:
                        self.report(
                            {'ERROR'},
                            f"Selected clothing collection not found: {', '.join(missing_names)}",
                        )
                        return {'CANCELLED'}
                    clothes_collections_in_file = list(selected_source_clothing_names)
                else:
                    clothes_roots = [
                        name for name in data_from.collections
                        if get_base_object_name(name).casefold() == "clothes"
                    ]
                    if clothes_roots:
                        clothes_collections_in_file = [
                            min(
                                clothes_roots,
                                key=lambda name: (
                                    get_enumeration_number(name),
                                    name.casefold(),
                                ),
                            )
                        ]

                for name in data_from.collections:
                    if name.lower().startswith("char specific proxies"):
                        char_specific_proxies_collections_in_file.append(name)
                    elif name.lower().startswith("char appendage"):
                        char_appendage_collections_in_file.append(name)
                    elif get_base_object_name(name).lower() == "hair" and self.append_hair:
                        hair_collections_in_file.append(name)
                    elif get_base_object_name(name).lower() == "collision" and self.append_collisions:
                        collision_collections_in_file.append(name)

                if hair_collections_in_file:
                    hair_collections_in_file = [
                        min(
                            hair_collections_in_file,
                            key=lambda name: (get_enumeration_number(name), name.lower()),
                        )
                    ]

                if collision_collections_in_file:
                    collision_collections_in_file = [
                        min(
                            collision_collections_in_file,
                            key=lambda name: (get_enumeration_number(name), name.lower()),
                        )
                    ]
                
                collections_to_append = (
                    clothes_collections_in_file
                    + char_specific_proxies_collections_in_file
                    + char_appendage_collections_in_file
                    + hair_collections_in_file
                    + collision_collections_in_file
                )
                
                if not collections_to_append:
                    hair_text = ", or 'Hair'" if self.append_hair else ""
                    collision_text = ", or 'Collision'" if self.append_collisions else ""
                    self.report({'INFO'}, f"No collections starting with 'Clothes', 'Char Specific Proxies', 'Char Appendage'{hair_text}{collision_text} found in the file.")
                    return {'FINISHED'}
                
                data_to.collections = collections_to_append
            loaded_top_level_collections = list(data_to.collections)
        except Exception as e:
            self.report({'ERROR'}, f"Error loading collections from {abs_filepath}: {e}")
            return {'CANCELLED'}
        
        # The library API returns requested top-level collections in request order.
        # Use those handles directly so specifically selected outfit collections do
        # not need to be named "Clothes" to be recognized as clothing.
        offset = 0

        def take_loaded(count):
            nonlocal offset
            result = [
                collection for collection in loaded_top_level_collections[offset:offset + count]
                if collection is not None
            ]
            offset += count
            return result

        appended_clothes_collections = take_loaded(len(clothes_collections_in_file))
        appended_char_specific_proxies_collections = take_loaded(
            len(char_specific_proxies_collections_in_file)
        )
        appended_char_appendage_collections = take_loaded(
            len(char_appendage_collections_in_file)
        )
        appended_hair_collections = take_loaded(len(hair_collections_in_file))
        appended_collision_collections = take_loaded(len(collision_collections_in_file))

        excluded_collision_meshes = sum(
            remove_excluded_collision_meshes(collection)
            for collection in appended_collision_collections
        )
        if excluded_collision_meshes:
            self.report(
                {'INFO'},
                f"Skipped {excluded_collision_meshes} linked collision helper mesh(es)"
            )
        
        all_appended_collections = (
            appended_clothes_collections
            + appended_char_specific_proxies_collections
            + appended_char_appendage_collections
            + appended_hair_collections
            + appended_collision_collections
        )
        
        # Collect all appended items that will be part of presets before they are merged.
        new_preset_items = []
        preset_collections = appended_clothes_collections + appended_char_appendage_collections + appended_hair_collections
        for coll in preset_collections:
            if coll in appended_clothes_collections and selected_source_clothing_names:
                new_preset_items.append(coll)
            get_all_children_and_objects_recursively(coll, new_preset_items)

        if not all_appended_collections:
            self.report({'INFO'}, "No new collections were actually appended.")
            return {'FINISHED'}

        # Resolve names within each category; a Hair object must not replace an
        # unrelated Clothes object just because both have the same base name.
        appended_by_category = {
            "Clothes": appended_clothes_collections,
            "Char Specific Proxies": appended_char_specific_proxies_collections,
            "Char Appendage": appended_char_appendage_collections,
            "Hair": appended_hair_collections,
            "Collision": appended_collision_collections,
        }
        surface_targets = collect_surface_deform_target_pointers(all_appended_collections)
        asset_clash_records = []
        for category, collections in appended_by_category.items():
            asset_clash_records.extend(build_asset_clash_records(
                collections, existing_assets_by_category[category],
                surface_deform_target_pointers=surface_targets,
            ))
        
        # Apply remapping to appended meshes if source mesh and sd target were specified
        if self.source_mesh_name and self.sd_target_name:
            preserved_surface_deform_targets = {
                record["appended_obj"].as_pointer()
                for record in asset_clash_records
                if record.get("is_surface_deform_target") and record.get("appended_obj")
            }
            self.apply_remapping_to_appended_meshes(
                context, 
                all_appended_collections, 
                self.source_mesh_name,
                self.sd_target_name,
                preserved_surface_deform_targets,
            )
        
        # Merge clothes collections
        num_clothes_merged = 0
        potential_new_color_tag_from_appended = 'COLOR_00'

        for collection_to_merge in appended_clothes_collections:
            if collection_to_merge == target_clothes_collection:
                continue
            
            if collection_to_merge.color_tag != 'COLOR_00' and potential_new_color_tag_from_appended == 'COLOR_00':
                potential_new_color_tag_from_appended = collection_to_merge.color_tag
            
            if selected_source_clothing_names:
                # A specifically selected outfit is itself a child of Clothes;
                # preserve that collection instead of flattening its contents.
                if collection_to_merge.name not in target_clothes_collection.children:
                    target_clothes_collection.children.link(collection_to_merge)
                for parent_coll in bpy.data.collections:
                    if (
                        parent_coll != target_clothes_collection
                        and collection_to_merge.name in parent_coll.children
                    ):
                        parent_coll.children.unlink(collection_to_merge)
                if collection_to_merge.name in context.scene.collection.children:
                    context.scene.collection.children.unlink(collection_to_merge)
            else:
                # All Clothing loads the source Clothes root. Merge its immediate
                # contents into the destination Clothes root without nesting roots.
                for obj in list(collection_to_merge.objects):
                    if obj.name not in target_clothes_collection.objects:
                        target_clothes_collection.objects.link(obj)

                for child in list(collection_to_merge.children):
                    if child.name not in target_clothes_collection.children:
                        target_clothes_collection.children.link(child)

                for parent_coll in bpy.data.collections:
                    if collection_to_merge.name in parent_coll.children:
                        parent_coll.children.unlink(collection_to_merge)
                if collection_to_merge.name in context.scene.collection.children:
                    context.scene.collection.children.unlink(collection_to_merge)

                bpy.data.collections.remove(collection_to_merge)
            num_clothes_merged += 1
        
        # Merge char specific proxies collections
        num_char_specific_proxies_merged = 0
        potential_new_color_tag_from_char_specific_proxies = 'COLOR_00'

        for collection_to_merge in appended_char_specific_proxies_collections:
            if collection_to_merge == target_char_specific_proxies_collection:
                continue
            
            if collection_to_merge.color_tag != 'COLOR_00' and potential_new_color_tag_from_char_specific_proxies == 'COLOR_00':
                potential_new_color_tag_from_char_specific_proxies = collection_to_merge.color_tag
            
            for obj in list(collection_to_merge.objects):
                if obj.name not in target_char_specific_proxies_collection.objects:
                    target_char_specific_proxies_collection.objects.link(obj)
            
            for child in list(collection_to_merge.children):
                if child.name not in target_char_specific_proxies_collection.children:
                    target_char_specific_proxies_collection.children.link(child)
            
            for parent_coll in bpy.data.collections:
                if collection_to_merge.name in parent_coll.children:
                    parent_coll.children.unlink(collection_to_merge)
            if collection_to_merge.name in context.scene.collection.children:
                 context.scene.collection.children.unlink(collection_to_merge)
            
            bpy.data.collections.remove(collection_to_merge)
            num_char_specific_proxies_merged += 1
        
        # Merge char appendage collections
        num_char_appendage_merged = 0
        potential_new_color_tag_from_char_appendage = 'COLOR_00'

        for collection_to_merge in appended_char_appendage_collections:
            if collection_to_merge == target_char_appendage_collection:
                continue
            
            if collection_to_merge.color_tag != 'COLOR_00' and potential_new_color_tag_from_char_appendage == 'COLOR_00':
                potential_new_color_tag_from_char_appendage = collection_to_merge.color_tag
            
            for obj in list(collection_to_merge.objects):
                if obj.name not in target_char_appendage_collection.objects:
                    target_char_appendage_collection.objects.link(obj)
            
            for child in list(collection_to_merge.children):
                if child.name not in target_char_appendage_collection.children:
                    target_char_appendage_collection.children.link(child)
            
            for parent_coll in bpy.data.collections:
                if collection_to_merge.name in parent_coll.children:
                    parent_coll.children.unlink(collection_to_merge)
            if collection_to_merge.name in context.scene.collection.children:
                 context.scene.collection.children.unlink(collection_to_merge)
            
            bpy.data.collections.remove(collection_to_merge)
            num_char_appendage_merged += 1
        
        # Merge hair collections
        num_hair_merged = 0
        potential_new_color_tag_from_hair = 'COLOR_00'

        for collection_to_merge in appended_hair_collections:
            if collection_to_merge == target_hair_collection:
                continue
            
            if collection_to_merge.color_tag != 'COLOR_00' and potential_new_color_tag_from_hair == 'COLOR_00':
                potential_new_color_tag_from_hair = collection_to_merge.color_tag
            
            for obj in list(collection_to_merge.objects):
                if obj.name not in target_hair_collection.objects:
                    target_hair_collection.objects.link(obj)
            
            for child in list(collection_to_merge.children):
                if child.name not in target_hair_collection.children:
                    target_hair_collection.children.link(child)
            
            for parent_coll in bpy.data.collections:
                if collection_to_merge.name in parent_coll.children:
                    parent_coll.children.unlink(collection_to_merge)
            if collection_to_merge.name in context.scene.collection.children:
                 context.scene.collection.children.unlink(collection_to_merge)
            
            bpy.data.collections.remove(collection_to_merge)
            num_hair_merged += 1

        # Merge collision collections.
        num_collision_merged = 0
        potential_new_color_tag_from_collision = 'COLOR_00'

        for collection_to_merge in appended_collision_collections:
            if collection_to_merge == target_collision_collection:
                continue

            if (
                collection_to_merge.color_tag != 'COLOR_00'
                and potential_new_color_tag_from_collision == 'COLOR_00'
            ):
                potential_new_color_tag_from_collision = collection_to_merge.color_tag

            for obj in list(collection_to_merge.objects):
                if obj.name not in target_collision_collection.objects:
                    target_collision_collection.objects.link(obj)

            for child in list(collection_to_merge.children):
                if child.name not in target_collision_collection.children:
                    target_collision_collection.children.link(child)

            for parent_coll in bpy.data.collections:
                if collection_to_merge.name in parent_coll.children:
                    parent_coll.children.unlink(collection_to_merge)
            if collection_to_merge.name in context.scene.collection.children:
                context.scene.collection.children.unlink(collection_to_merge)

            bpy.data.collections.remove(collection_to_merge)
            num_collision_merged += 1
        
        # Build final report message
        final_report_parts = []
        
        if num_clothes_merged > 0:
            final_report_parts.append(f"Merged {num_clothes_merged} clothing collections into '{target_clothes_collection.name}' collection")
        
        if num_char_specific_proxies_merged > 0:
            final_report_parts.append(f"Merged {num_char_specific_proxies_merged} char specific proxies collections into '{target_char_specific_proxies_collection.name}' collection")
        
        if num_char_appendage_merged > 0:
            final_report_parts.append(f"Merged {num_char_appendage_merged} char appendage collections into '{target_char_appendage_collection.name}' collection")
        
        if num_hair_merged > 0:
            final_report_parts.append(f"Merged {num_hair_merged} hair collections into '{target_hair_collection.name}' collection")

        if num_collision_merged > 0:
            final_report_parts.append(f"Merged {num_collision_merged} collision collections into '{target_collision_collection.name}' collection")
        
        final_report_message = ". ".join(final_report_parts) + "."

        # Apply color tag logic for clothes collection
        if self.source_mesh_name and num_clothes_merged > 0:
            if target_clothes_collection.color_tag != 'COLOR_00':
                final_report_message += f" Clothes collection's original color tag ('{target_clothes_collection.color_tag}') was preserved."
            else:
                if potential_new_color_tag_from_appended != 'COLOR_00':
                    target_clothes_collection.color_tag = potential_new_color_tag_from_appended
                    final_report_message += f" Clothes collection color tag set to '{potential_new_color_tag_from_appended}' from an appended item."
                else:
                    target_clothes_collection.color_tag = 'COLOR_03'
                    final_report_message += f" Clothes collection color tag set to default ('COLOR_03')."
        
        # Apply color tag logic for char specific proxies collection
        if self.source_mesh_name and num_char_specific_proxies_merged > 0:
            if target_char_specific_proxies_collection.color_tag != 'COLOR_00':
                final_report_message += f" Char Specific Proxies collection's original color tag ('{target_char_specific_proxies_collection.color_tag}') was preserved."
            else:
                if potential_new_color_tag_from_char_specific_proxies != 'COLOR_00':
                    target_char_specific_proxies_collection.color_tag = potential_new_color_tag_from_char_specific_proxies
                    final_report_message += f" Char Specific Proxies collection color tag set to '{potential_new_color_tag_from_char_specific_proxies}' from an appended item."
                else:
                    target_char_specific_proxies_collection.color_tag = 'COLOR_04'
                    final_report_message += f" Char Specific Proxies collection color tag set to default ('COLOR_04')."
        
        # Apply color tag logic for char appendage collection
        if self.source_mesh_name and num_char_appendage_merged > 0:
            if target_char_appendage_collection.color_tag != 'COLOR_00':
                final_report_message += f" Char Appendage collection's original color tag ('{target_char_appendage_collection.color_tag}') was preserved."
            else:
                if potential_new_color_tag_from_char_appendage != 'COLOR_00':
                    target_char_appendage_collection.color_tag = potential_new_color_tag_from_char_appendage
                    final_report_message += f" Char Appendage collection color tag set to '{potential_new_color_tag_from_char_appendage}' from an appended item."
                else:
                    target_char_appendage_collection.color_tag = 'COLOR_05'
                    final_report_message += f" Char Appendage collection color tag set to default ('COLOR_05')."
        
        # Apply color tag logic for hair collection
        if self.source_mesh_name and num_hair_merged > 0:
            if target_hair_collection.color_tag != 'COLOR_00':
                final_report_message += f" Hair collection's original color tag ('{target_hair_collection.color_tag}') was preserved."
            else:
                if potential_new_color_tag_from_hair != 'COLOR_00':
                    target_hair_collection.color_tag = potential_new_color_tag_from_hair
                    final_report_message += f" Hair collection color tag set to '{potential_new_color_tag_from_hair}' from an appended item."
                else:
                    target_hair_collection.color_tag = 'COLOR_06'
                    final_report_message += f" Hair collection color tag set to default ('COLOR_06')."

        # Apply color tag logic for collision collection.
        if self.source_mesh_name and num_collision_merged > 0:
            if target_collision_collection.color_tag != 'COLOR_00':
                final_report_message += f" Collision collection's original color tag ('{target_collision_collection.color_tag}') was preserved."
            elif potential_new_color_tag_from_collision != 'COLOR_00':
                target_collision_collection.color_tag = potential_new_color_tag_from_collision
                final_report_message += f" Collision collection color tag set to '{potential_new_color_tag_from_collision}' from the appended collection."
            else:
                target_collision_collection.color_tag = 'COLOR_08'
                final_report_message += " Collision collection color tag set to default ('COLOR_08')."
        
        # Update presets after appending is complete
        if self.source_mesh_name:
            source_mesh = bpy.data.objects.get(self.source_mesh_name)
            if source_mesh and "presets" in source_mesh and source_mesh["presets"]:
                # Preserve viewport state through the preset update process.
                # 1. Ensure the source mesh is active and capture the current visibility state.
                original_active = context.view_layer.objects.active
                context.view_layer.objects.active = source_mesh
                pre_update_outfit_state = capture_outfit_preset(context)

                # 2. Update the presets. This function handles its own active object management.
                update_presets_after_append(source_mesh, new_preset_items)

                # 3. Restore the original visibility state by re-applying the captured state.
                apply_outfit_preset(pre_update_outfit_state)

                # 4. Restore the original active object.
                context.view_layer.objects.active = original_active

        if self.append_toggled_off:
            for item in new_preset_items:
                if hasattr(item, 'hide_viewport'):
                    item.hide_viewport = True
                    item.hide_render = True

        source_mesh = bpy.data.objects.get(self.source_mesh_name)
        char_root_collection = get_top_parent_collection(source_mesh) if source_mesh else None
        if launch_asset_clash_resolver(
            context,
            asset_clash_records,
            char_root_collection,
            target_char_specific_proxies_collection,
        ):
            final_report_message += " Resolve appended asset clashes in the popup."

        self.report({'INFO'}, final_report_message)
        return {'FINISHED'}

def draw_clothes_collection_menu(self, context):
    layout = self.layout
    scene = context.scene
    filepath = scene.append_clothing_filepath
    source_mesh = scene.armature_source
    
    # Get all clothes collections in the parent collection
    clothes_collections = find_clothes_collections_in_parent(source_mesh)
    
    # Display all clothes collections
    for coll in clothes_collections:
        op = layout.operator(OT_SelectClothesCollection.bl_idname, text=coll.name)
        op.collection_name = coll.name
        op.filepath = filepath
        op.source_clothing_collection_names_json = getattr(
            scene,
            'append_source_clothing_collections_json',
            '[]',
        )
        op.source_mesh_name = source_mesh.name
        op.sd_target_name = scene.sd_target_name if hasattr(scene, 'sd_target_name') else ""
        op.append_hair = getattr(scene, 'append_hair_setting', False)
        op.append_collisions = getattr(scene, 'append_collisions_setting', False)
        op.append_toggled_off = getattr(scene, 'append_toggled_off_setting', False)

def register():
    for cls in HHP_CHARLIB_ASSET_CLASH_CLASSES:
        bpy.utils.register_class(cls)

    bpy.utils.register_class(OT_ApplyRemap)
    bpy.utils.register_class(OT_SelectClothesCollection)
    bpy.utils.register_class(HHP_AppendClothingSourceItem)
    bpy.utils.register_class(HHP_UL_AppendClothingSourceCollections)
    bpy.utils.register_class(WM_OT_AppendClothingDialog)
    bpy.utils.register_class(WM_OT_AppendClothing)
    bpy.utils.register_class(WM_OT_AppendClothingExecute)
    
    bpy.types.Scene.armature_source = PointerProperty(
        name="Source Mesh",
        type=bpy.types.Object,
        poll=mesh_poll,
        description="Select the HHP character mesh you want to remap appended assets to"
    )
    
    # Add property to store filepath for the popup menu
    bpy.types.Scene.append_clothing_filepath = StringProperty(
        name="Append Clothing Filepath",
        default="",
        options={'HIDDEN'}
    )
    bpy.types.Scene.append_source_clothing_collections_json = StringProperty(
        name="Source Clothing Collections",
        description="Specific clothing collections selected from the append source file",
        default="[]",
        options={'HIDDEN'},
    )
    
    # Add property to store sd target name for the clothes collection popup
    bpy.types.Scene.sd_target_name = StringProperty(
        name="Surface Deform Target Name",
        default="",
        options={'HIDDEN'}
    )
    
    # Add property to store append hair setting for the popup menu
    bpy.types.Scene.append_hair_setting = BoolProperty(
        name="Append Hair Setting",
        default=False,
        options={'HIDDEN'}
    )

    bpy.types.Scene.append_collisions_setting = BoolProperty(
        name="Append Collisions Setting",
        default=False,
        options={'HIDDEN'}
    )
    
    # Add property to store append toggled off setting for the popup menu
    bpy.types.Scene.append_toggled_off_setting = BoolProperty(
        name="Append Toggled Off Setting",
        default=False,
        options={'HIDDEN'}
    )

    bpy.types.WindowManager.hhp_char_library_asset_clashes = CollectionProperty(
        type=HHP_CHARLIB_AssetClashItem
    )
    bpy.types.WindowManager.hhp_char_library_asset_clash_active_index = IntProperty(
        name="Active Appended Asset Clash Index",
        default=0,
    )
    bpy.types.WindowManager.hhp_char_library_asset_clash_char_root = StringProperty(
        name="Appended Asset Clash Character Root",
        default="",
        options={'HIDDEN'},
    )
    bpy.types.WindowManager.hhp_char_library_asset_clash_proxy_collection = StringProperty(
        name="Appended Asset Clash Proxy Collection",
        default="",
        options={'HIDDEN'},
    )

def unregister():
    _SOURCE_CLOTHING_COLLECTION_CACHE.clear()
    if hasattr(bpy.types.WindowManager, 'hhp_char_library_asset_clash_proxy_collection'):
        del bpy.types.WindowManager.hhp_char_library_asset_clash_proxy_collection

    if hasattr(bpy.types.WindowManager, 'hhp_char_library_asset_clash_char_root'):
        del bpy.types.WindowManager.hhp_char_library_asset_clash_char_root

    if hasattr(bpy.types.WindowManager, 'hhp_char_library_asset_clashes'):
        del bpy.types.WindowManager.hhp_char_library_asset_clashes

    if hasattr(bpy.types.WindowManager, 'hhp_char_library_asset_clash_active_index'):
        del bpy.types.WindowManager.hhp_char_library_asset_clash_active_index

    bpy.utils.unregister_class(WM_OT_AppendClothingExecute)
    bpy.utils.unregister_class(WM_OT_AppendClothing)
    bpy.utils.unregister_class(WM_OT_AppendClothingDialog)
    bpy.utils.unregister_class(HHP_UL_AppendClothingSourceCollections)
    bpy.utils.unregister_class(HHP_AppendClothingSourceItem)
    bpy.utils.unregister_class(OT_SelectClothesCollection)
    bpy.utils.unregister_class(OT_ApplyRemap)
    for cls in reversed(HHP_CHARLIB_ASSET_CLASH_CLASSES):
        bpy.utils.unregister_class(cls)
    
    if hasattr(bpy.types.Scene, 'armature_source'):
        del bpy.types.Scene.armature_source
    
    if hasattr(bpy.types.Scene, 'append_clothing_filepath'):
        del bpy.types.Scene.append_clothing_filepath

    if hasattr(bpy.types.Scene, 'append_source_clothing_collections_json'):
        del bpy.types.Scene.append_source_clothing_collections_json
        
    if hasattr(bpy.types.Scene, 'sd_target_name'):
        del bpy.types.Scene.sd_target_name
        
    if hasattr(bpy.types.Scene, 'append_hair_setting'):
        del bpy.types.Scene.append_hair_setting

    if hasattr(bpy.types.Scene, 'append_collisions_setting'):
        del bpy.types.Scene.append_collisions_setting
        
    if hasattr(bpy.types.Scene, 'append_toggled_off_setting'):
        del bpy.types.Scene.append_toggled_off_setting
