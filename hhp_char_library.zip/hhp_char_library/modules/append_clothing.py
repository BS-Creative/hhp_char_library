import bpy
from bpy.props import StringProperty, PointerProperty, BoolProperty
from bpy.types import Operator
import os
from ..Customize_HHP import capture_outfit_preset, apply_outfit_preset

def mesh_poll(self, obj):
    return obj.type == 'MESH'

def get_top_parent_collection(obj):
    """Get the highest parent collection of an object (just before the scene collection)"""
    if not obj.users_collection:
        return None
    
    # Start with the first collection the object is in
    current_collection = obj.users_collection[0]
    
    # Keep going up until we find a collection that's a direct child of the scene collection
    while current_collection:
        # Check if this collection is a direct child of the scene collection
        if current_collection.name in bpy.context.scene.collection.children:
            return current_collection
        
        # Find the parent collection
        parent_collections = [coll for coll in bpy.data.collections if current_collection.name in coll.children]
        if not parent_collections:
            break
        
        current_collection = parent_collections[0]
    
    return current_collection

def find_primary_fullbody_proxy(source_mesh):
    """Find 'Deform Proxy - Primary (Fullbody)' meshes in the same parent collection as the source mesh"""
    if not source_mesh:
        return []
    
    # Get the top parent collection of the source mesh
    parent_collection = get_top_parent_collection(source_mesh)
    if not parent_collection:
        return []
    
    # Find all objects in this collection and its children that match the criteria
    primary_fullbody_candidates = []
    
    def search_collection(collection):
        for obj in collection.objects:
            if (obj.type == 'MESH' and 
                "Deform Proxy" in obj.name and 
                "Primary" in obj.name and 
                "Fullbody" in obj.name):
                primary_fullbody_candidates.append(obj)
        
        # Search in child collections
        for child in collection.children:
            search_collection(child)
    
    # Start the search from the parent collection
    search_collection(parent_collection)
    
    return primary_fullbody_candidates

def find_clothes_collections_in_parent(source_mesh):
    """Find all collections starting with 'Clothes' in the same parent collection as the source mesh"""
    if not source_mesh:
        return []
    
    # Get the top parent collection of the source mesh
    parent_collection = get_top_parent_collection(source_mesh)
    if not parent_collection:
        return []
    
    # Find all collections starting with 'Clothes' in this collection and its children
    clothes_collections = []
    
    def search_collection(collection):
        for child in collection.children:
            if child.name.lower().startswith("clothes"):
                clothes_collections.append(child)
            search_collection(child)
    
    # Start the search from the parent collection
    search_collection(parent_collection)
    
    return clothes_collections

def find_char_specific_proxies_collections_in_parent(source_mesh):
    """Find all collections starting with 'Char Specific Proxies' in the same parent collection as the source mesh"""
    if not source_mesh:
        return []
    
    # Get the top parent collection of the source mesh
    parent_collection = get_top_parent_collection(source_mesh)
    if not parent_collection:
        return []
    
    # Find all collections starting with 'Char Specific Proxies' in this collection and its children
    char_specific_proxies_collections = []
    
    def search_collection(collection):
        for child in collection.children:
            if child.name.lower().startswith("char specific proxies"):
                char_specific_proxies_collections.append(child)
            search_collection(child)
    
    # Start the search from the parent collection
    search_collection(parent_collection)
    
    return char_specific_proxies_collections

def find_char_appendage_collections_in_parent(source_mesh):
    """Find all collections starting with 'Char Appendage' in the same parent collection as the source mesh"""
    if not source_mesh:
        return []
    
    # Get the top parent collection of the source mesh
    parent_collection = get_top_parent_collection(source_mesh)
    if not parent_collection:
        return []
    
    # Find all collections starting with 'Char Appendage' in this collection and its children
    char_appendage_collections = []
    
    def search_collection(collection):
        for child in collection.children:
            if child.name.lower().startswith("char appendage"):
                char_appendage_collections.append(child)
            search_collection(child)
    
    # Start the search from the parent collection
    search_collection(parent_collection)
    
    return char_appendage_collections

def find_hair_collections_in_parent(source_mesh):
    """Find all collections starting with 'Hair' in the same parent collection as the source mesh"""
    if not source_mesh:
        return []
    
    # Get the top parent collection of the source mesh
    parent_collection = get_top_parent_collection(source_mesh)
    if not parent_collection:
        return []
    
    # Find all collections starting with 'Hair' in this collection and its children
    hair_collections = []
    
    def search_collection(collection):
        for child in collection.children:
            if child.name.lower().startswith("hair"):
                hair_collections.append(child)
            search_collection(child)
    
    # Start the search from the parent collection
    search_collection(parent_collection)
    
    return hair_collections

def get_all_children_and_objects_recursively(collection, item_list):
    """Recursively collect all objects and child collections from a given collection."""
    item_list.extend(collection.objects)
    item_list.extend(collection.children)
    for child in collection.children:
        get_all_children_and_objects_recursively(child, item_list)

def update_presets_after_append(source_mesh, new_items):
    """
    Updates all presets on the source_mesh to include new_items as hidden.
    1. Stores original visibility of new items.
    2. Hides new items.
    3. For each preset, applies it, then recaptures the state. This adds the new items as hidden.
    4. Restores original visibility of new items in the viewport.
    """
    if not source_mesh or "presets" not in source_mesh or not new_items:
        return

    # 1. Store original visibility of new items
    original_states = {item: (item.hide_viewport, item.hide_render) for item in new_items}

    # 2. Set new items to be hidden
    for item in new_items:
        item.hide_viewport = True
        item.hide_render = True

    context = bpy.context
    original_active_object = context.view_layer.objects.active
    if source_mesh != original_active_object:
        context.view_layer.objects.active = source_mesh
    
    presets = source_mesh["presets"]
    for preset_name in list(presets.keys()):
        preset_data = presets[preset_name]
        
        # 3a. Apply the collections part of the preset to restore old item visibility
        if "collections" in preset_data:
            apply_outfit_preset(preset_data["collections"])

        # 3b. Capture the new state, now including new items as hidden
        updated_collections_state = capture_outfit_preset(context)
        
        # 3c. Update the preset data in-place
        presets[preset_name]["collections"] = updated_collections_state

    # Restore original active object
    if source_mesh != original_active_object:
        context.view_layer.objects.active = original_active_object

    # 4. Restore original visibility of new items
    for item, (hide_v, hide_r) in original_states.items():
        item.hide_viewport = hide_v
        item.hide_render = hide_r

def get_base_object_name(name):
    """Strips numerical suffixes like .001 from an object name."""
    import re
    return re.sub(r'\.\d+$', '', name)


def retarget_shapekey_driver_targets(obj, new_mesh, new_armature):
    """
    Update shapekey driver variables on obj so they point to the provided
    character mesh and armature instead of the original appended targets.
    Returns the number of driver targets that were updated.
    """
    if not obj or obj.type != 'MESH':
        return 0

    data = getattr(obj, "data", None)
    if not data:
        return 0

    shape_keys = getattr(data, "shape_keys", None)
    if not shape_keys:
        return 0

    anim = getattr(shape_keys, "animation_data", None)
    if not anim or not getattr(anim, "drivers", None):
        return 0

    updated = 0
    for fcurve in anim.drivers:
        driver = getattr(fcurve, "driver", None)
        if not driver or not getattr(driver, "variables", None):
            continue
        for var in driver.variables:
            targets = getattr(var, "targets", None)
            if not targets:
                continue
            for target in targets:
                if not target:
                    continue
                id_obj = getattr(target, "id", None)
                # We only care about object ID targets
                if not isinstance(id_obj, bpy.types.Object):
                    continue

                # If driver references any armature, retarget to the chosen armature
                if id_obj.type == 'ARMATURE' and new_armature and id_obj is not new_armature:
                    target.id = new_armature
                    updated += 1
                # If driver references a mesh that is not this mesh, retarget to the chosen body mesh
                elif id_obj.type == 'MESH' and new_mesh and id_obj is not new_mesh and id_obj is not obj:
                    target.id = new_mesh
                    updated += 1

    if updated:
        print(f"Retargeted {updated} shapekey driver target(s) on '{obj.name}'")
    return updated

def find_object_in_hierarchy(start_collection, base_name):
    """Recursively search for an object with a given base name in a collection hierarchy."""
    # Check objects in the current collection
    for obj in start_collection.objects:
        if get_base_object_name(obj.name) == base_name:
            return obj
            
    # Recurse into child collections
    for child_collection in start_collection.children:
        found_obj = find_object_in_hierarchy(child_collection, base_name)
        if found_obj:
            return found_obj
            
    return None

class OT_ApplyRemap(Operator):
    """Apply Armature and Surface Deform targets to selected meshes"""
    bl_idname = "object.apply_remap"
    bl_label = "Apply Remap Targets"
    bl_options = {'UNDO'}

    sd_target_name: StringProperty()
    filepath: StringProperty(subtype="FILE_PATH")
    append_hair: BoolProperty(default=False)
    append_toggled_off: BoolProperty(default=False)

    def execute(self, context):
        scene = context.scene
        src = scene.armature_source
        if not src:
            self.report({'ERROR'}, "No source mesh selected")
            return {'CANCELLED'}

        # Armature target lookup
        arm_mod = next((m for m in src.modifiers if m.type == 'ARMATURE' and m.object), None)
        if not arm_mod:
            self.report({'ERROR'}, f"'{src.name}' has no Armature modifier with a valid target")
            return {'CANCELLED'}
        arm_obj = arm_mod.object

        # Surface Deform target lookup from popup choice
        sd_target = bpy.data.objects.get(self.sd_target_name)
        if not sd_target:
            self.report({'ERROR'}, f"Surface Deform target '{self.sd_target_name}' not found")
            return {'CANCELLED'}

        # Now execute the append clothing operation with the selected targets
        result = bpy.ops.wm.append_clothing_execute(
            filepath=self.filepath,
            source_mesh_name=src.name,
            sd_target_name=sd_target.name,
            append_hair=self.append_hair,
            append_toggled_off=self.append_toggled_off
        )
        
        return result

class OT_SelectClothesCollection(Operator):
    """Select which Clothes collection to use"""
    bl_idname = "object.select_clothes_collection"
    bl_label = "Select Clothes Collection"
    bl_options = {'UNDO'}
    
    collection_name: StringProperty()
    filepath: StringProperty(subtype="FILE_PATH")
    source_mesh_name: StringProperty()
    sd_target_name: StringProperty()

    def execute(self, context):
        # Execute the append clothing operation with the selected collection
        result = bpy.ops.wm.append_clothing_execute(
            filepath=self.filepath,
            source_mesh_name=self.source_mesh_name,
            sd_target_name=self.sd_target_name,
            target_collection_name=self.collection_name
        )
        return result

def draw_sd_menu(self, context):
    layout = self.layout
    scene = context.scene
    src = scene.armature_source
    filepath = scene.append_clothing_filepath

    # Get all candidates
    all_candidates = []
    
    # First, check for "Deform Proxy - Primary (Fullbody)" objects in the same parent collection
    primary_fullbody_candidates = find_primary_fullbody_proxy(src)
    
    # Add primary fullbody candidates to the list
    for o in primary_fullbody_candidates:
        all_candidates.append(o)
    
    # Add other meshes sharing the same mesh data
    data_candidates = [
        o for o in context.scene.objects
        if o.type == 'MESH' and o.data == src.data and o != src and o not in primary_fullbody_candidates
    ]
    
    # Add data candidates to the list
    for o in data_candidates:
        all_candidates.append(o)
    
    # Sort candidates: primary fullbody proxies first (in numerical order), then others
    def get_sort_key(obj):
        if obj in primary_fullbody_candidates:
            # Extract number from name if it exists, otherwise use 0
            import re
            match = re.search(r'(\d+)', obj.name)
            num = int(match.group(1)) if match else 0
            return (0, num)  # Primary fullbody proxies first, sorted by number
        return (1, 0)  # Other meshes after
    
    all_candidates.sort(key=get_sort_key)
    
    # Get the append_hair setting from the scene
    append_hair = getattr(scene, 'append_hair_setting', False)
    append_toggled_off = getattr(scene, 'append_toggled_off_setting', False)
    
    # Display primary fullbody candidates first
    for o in all_candidates:
        if o in primary_fullbody_candidates:
            op = layout.operator(OT_ApplyRemap.bl_idname, text=o.name)
            op.sd_target_name = o.name
            op.filepath = filepath
            op.append_hair = append_hair
            op.append_toggled_off = append_toggled_off
    
    # Add a separator after primary fullbody candidates
    if primary_fullbody_candidates and (data_candidates or src):
        layout.separator()
    
    # Display other candidates
    for o in all_candidates:
        if o not in primary_fullbody_candidates:
            op = layout.operator(OT_ApplyRemap.bl_idname, text=o.name)
            op.sd_target_name = o.name
            op.filepath = filepath
            op.append_hair = append_hair
            op.append_toggled_off = append_toggled_off
    
    # Option to use the source mesh itself (at the bottom)
    op = layout.operator(OT_ApplyRemap.bl_idname, text="Source Mesh (not recommended)")
    op.sd_target_name = src.name
    op.filepath = filepath
    op.append_hair = append_hair
    op.append_toggled_off = append_toggled_off

class WM_OT_AppendClothingDialog(Operator):
    """Dialog to select source mesh before appending clothing, char specific proxies, char appendages, and hair"""
    bl_idname = "wm.append_clothing_dialog"
    bl_label = "Auto remapper (fitting options)"
    bl_description = "Choose remapping options before appending clothing, char specific proxies, char appendages, and hair"
    bl_options = set()

    filepath: StringProperty(subtype="FILE_PATH")
    append_toggled_off: BoolProperty(
        name="Append toggled off",
        description="Disable the appended assets after updating presets",
        default=False
    )
    append_hair: BoolProperty(
        name="Append Hair with assets",
        description="Include hair collections when appending",
        default=False
    )

    def invoke(self, context, event):
        # Store the filepath in the scene for later use
        context.scene.append_clothing_filepath = self.filepath
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.prop(context.scene, "armature_source", text="Source Mesh")
        layout.label(text="Select the HHP character mesh you want to remap appended assets to")
        layout.label(text="If no source mesh is selected, assets will be appended without remapping")
        layout.separator()
        layout.prop(self, "append_toggled_off")
        layout.prop(self, "append_hair")

    def execute(self, context):
        # Store the source mesh selection
        source_mesh = context.scene.armature_source
        
        if not source_mesh:
            # If no source mesh selected, just append without remapping
            result = bpy.ops.wm.append_clothing_execute(filepath=self.filepath, append_hair=self.append_hair, append_toggled_off=self.append_toggled_off)
            return result
        
        # Check for armature modifier
        arm_mod = next((m for m in source_mesh.modifiers if m.type == 'ARMATURE' and m.object), None)
        if not arm_mod:
            self.report({'ERROR'}, f"'{source_mesh.name}' has no Armature modifier with a valid target")
            return {'CANCELLED'}
        
        # First, check for "Deform Proxy - Primary (Fullbody)" objects in the same parent collection
        primary_fullbody_candidates = find_primary_fullbody_proxy(source_mesh)
        
        # If exactly one primary fullbody proxy found, use it
        if len(primary_fullbody_candidates) == 1:
            sd_target = primary_fullbody_candidates[0]
            result = bpy.ops.wm.append_clothing_execute(
                filepath=self.filepath,
                source_mesh_name=source_mesh.name,
                sd_target_name=sd_target.name,
                append_hair=self.append_hair,
                append_toggled_off=self.append_toggled_off
            )
            return result
        
        # If multiple primary fullbody proxies found, show popup
        if primary_fullbody_candidates:
            # Store append_hair setting for the popup
            context.scene.append_hair_setting = self.append_hair
            context.scene.append_toggled_off_setting = self.append_toggled_off
            context.window_manager.popup_menu(
                draw_sd_menu,
                title="Choose Deformation Cage",
                icon='MESH_DATA'
            )
            return {'FINISHED'}
        
        # If no primary fullbody proxies found, fall back to meshes sharing the same mesh data
        data_candidates = [
            o for o in context.scene.objects
            if o.type == 'MESH' and o.data == source_mesh.data and o != source_mesh
        ]

        # If exactly one candidate, auto-apply
        if len(data_candidates) == 1:
            sd_target = data_candidates[0]
            result = bpy.ops.wm.append_clothing_execute(
                filepath=self.filepath,
                source_mesh_name=source_mesh.name,
                sd_target_name=sd_target.name,
                append_hair=self.append_hair,
                append_toggled_off=self.append_toggled_off
            )
            return result
        else:
            # Multiple or none: show popup with all candidates
            # Store append_hair setting for the popup
            context.scene.append_hair_setting = self.append_hair
            context.scene.append_toggled_off_setting = self.append_toggled_off
            context.window_manager.popup_menu(
                draw_sd_menu,
                title="Choose Deformation Cage",
                icon='MESH_DATA'
            )
            return {'FINISHED'}

class WM_OT_AppendClothing(Operator):
    bl_idname = "wm.append_clothing"
    bl_label = "Append Clothing & Accessories"
    bl_description = "Append and remap clothing, accessories, and hair from the selected file"
    bl_options = set()

    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        # Show the dialog first
        bpy.ops.wm.append_clothing_dialog('INVOKE_DEFAULT', filepath=self.filepath)
        return {'FINISHED'}

class WM_OT_AppendClothingExecute(Operator):
    bl_idname = "wm.append_clothing_execute"
    bl_label = "Execute Append Clothing"
    bl_description = "Execute the actual clothing, char specific proxies, char appendage, and hair append operation"
    bl_options = set()

    filepath: StringProperty(subtype="FILE_PATH")
    source_mesh_name: StringProperty()
    sd_target_name: StringProperty()
    target_collection_name: StringProperty()
    append_hair: BoolProperty(default=False)
    append_toggled_off: BoolProperty(default=False)

    def apply_remapping_to_appended_meshes(self, context, appended_collections, source_mesh_name, sd_target_name):
        """Apply armature and surface deform remapping to appended meshes"""
        source_mesh = bpy.data.objects.get(source_mesh_name)
        sd_target = bpy.data.objects.get(sd_target_name)
        
        if not source_mesh or not sd_target:
            return
        
        # Get the armature from the source mesh
        arm_mod = next((m for m in source_mesh.modifiers if m.type == 'ARMATURE' and m.object), None)
        if not arm_mod:
            return
        
        arm_obj = arm_mod.object
        arm_count = 0
        sd_count = 0
        sd_smart_count = 0
        constraint_count = 0
        lattice_childof_count = 0
        shapekey_driver_retarget_count = 0
        
        def process_collection(collection, is_hair_collection=False, is_char_specific_collection=False):
            nonlocal arm_count, sd_count, sd_smart_count, constraint_count, lattice_childof_count, shapekey_driver_retarget_count
            for obj in collection.objects:
                if obj.type == 'MESH':
                    # Apply armature modifier
                    existing_arm_mod = next((m for m in obj.modifiers if m.type == 'ARMATURE'), None)
                    if existing_arm_mod:
                        existing_arm_mod.object = arm_obj
                        arm_count += 1

                    # Retarget shapekey drivers that reference the original body/armature
                    shapekey_driver_retarget_count += retarget_shapekey_driver_targets(
                        obj,
                        source_mesh,
                        arm_obj
                    )
                    
                    # Apply surface deform modifier with HHP check and smart target matching for all collections
                    for mod in obj.modifiers:
                        if mod.type == 'SURFACE_DEFORM':
                            # Check if the modifier name starts with "(HHPs)" or "(HHP)"
                            if mod.name.startswith("(HHPs)") or mod.name.startswith("(HHP)"):
                                # Skip remapping for HHP-specific modifiers
                                continue
                            
                            # Apply smart name matching to ALL collections, not just hair
                            original_target_name = mod.target.name if mod.target else None
                            if original_target_name:
                                # Strip numerical suffixes like .001, .002, etc. from the target name
                                base_name = get_base_object_name(original_target_name)
                                
                                # Look for an object with the base name in the current scene
                                character_collection = get_top_parent_collection(source_mesh)
                                same_named_target = None
                                if character_collection:
                                    same_named_target = find_object_in_hierarchy(character_collection, base_name)

                                if same_named_target and same_named_target.type == 'MESH':
                                    mod.target = same_named_target
                                    sd_smart_count += 1  # Smart matching applied to all collections
                                else:
                                    # Fallback to the selected target if same named target not found
                                    mod.target = sd_target
                                    sd_count += 1
                            else:
                                # No original target, use the selected target
                                mod.target = sd_target
                                sd_count += 1
                    
                    # Apply object constraint remapping
                    for constraint in obj.constraints:
                        if hasattr(constraint, 'target') and constraint.target:
                            constraint.target = source_mesh
                            constraint_count += 1
                elif obj.type == 'LATTICE' and is_char_specific_collection:
                    # Retarget Child Of constraints on lattices in Char Specific Proxies to the armature
                    for constraint in obj.constraints:
                        if getattr(constraint, 'type', None) == 'CHILD_OF':
                            constraint.target = arm_obj
                            lattice_childof_count += 1
            
            # Process child collections recursively
            for child in collection.children:
                # Check if child collection is a hair collection
                child_is_hair = child.name.lower().startswith("hair")
                child_is_char_specific = child.name.lower().startswith("char specific proxies") or is_char_specific_collection
                process_collection(child, is_hair_collection or child_is_hair, child_is_char_specific)

        for collection in appended_collections:
            # Check if this collection is a hair collection
            is_hair = collection.name.lower().startswith("hair")
            is_char_specific = collection.name.lower().startswith("char specific proxies")
            process_collection(collection, is_hair, is_char_specific)

        # Build report message
        report_parts = []
        if arm_count > 0:
            report_parts.append(f"{arm_count} Armature modifiers")
        if sd_count > 0:
            report_parts.append(f"{sd_count} Surface Deform modifiers to '{sd_target.name}' (fallback)")
        if sd_smart_count > 0:
            report_parts.append(f"{sd_smart_count} Surface Deform modifiers to smart-matched targets")
        if constraint_count > 0:
            report_parts.append(f"{constraint_count} Object constraints to '{source_mesh.name}'")
        if lattice_childof_count > 0:
            report_parts.append(f"{lattice_childof_count} Lattice 'Child Of' constraints to armature '{arm_obj.name}'")
        if shapekey_driver_retarget_count > 0:
            report_parts.append(f"{shapekey_driver_retarget_count} shapekey driver target(s) retargeted")
        
        if report_parts:
            self.report({'INFO'}, f"Remapped {', '.join(report_parts)}")

    def execute(self, context):
        if not self.filepath or not os.path.exists(self.filepath):
            self.report({'ERROR'}, "Filepath not set or file does not exist.")
            return {'CANCELLED'}

        abs_filepath = bpy.path.abspath(self.filepath)
        
        original_collection_names_in_scene = set(c.name for c in bpy.data.collections)
        
        # Find the target collections
        target_clothes_collection = None
        target_char_specific_proxies_collection = None
        target_char_appendage_collection = None
        target_hair_collection = None
        
        if self.target_collection_name:
            target_clothes_collection = bpy.data.collections.get(self.target_collection_name)
        
        if not target_clothes_collection:
            # If no target collection specified, find or create one in the source mesh's parent collection
            source_mesh = bpy.data.objects.get(self.source_mesh_name)
            if source_mesh:
                clothes_collections = find_clothes_collections_in_parent(source_mesh)
                if len(clothes_collections) == 1:
                    target_clothes_collection = clothes_collections[0]
                elif len(clothes_collections) > 1:
                    # Store necessary info for the popup
                    context.scene.sd_target_name = self.sd_target_name
                    context.window_manager.popup_menu(
                        draw_clothes_collection_menu,
                        title="Choose Clothes Collection",
                        icon='OUTLINER_COLLECTION'
                    )
                    return {'FINISHED'}
        
        # Find or create target char specific proxies collection
        source_mesh = bpy.data.objects.get(self.source_mesh_name)
        if source_mesh:
            char_specific_proxies_collections = find_char_specific_proxies_collections_in_parent(source_mesh)
            if len(char_specific_proxies_collections) == 1:
                target_char_specific_proxies_collection = char_specific_proxies_collections[0]
            elif len(char_specific_proxies_collections) > 1:
                # Use the first one found for now
                target_char_specific_proxies_collection = char_specific_proxies_collections[0]
        
        # Find or create target char appendage collection
        source_mesh = bpy.data.objects.get(self.source_mesh_name)
        if source_mesh:
            char_appendage_collections = find_char_appendage_collections_in_parent(source_mesh)
            if len(char_appendage_collections) == 1:
                target_char_appendage_collection = char_appendage_collections[0]
            elif len(char_appendage_collections) > 1:
                # Use the first one found for now
                target_char_appendage_collection = char_appendage_collections[0]
        
        # Find or create target hair collection
        source_mesh = bpy.data.objects.get(self.source_mesh_name)
        if source_mesh:
            hair_collections = find_hair_collections_in_parent(source_mesh)
            if len(hair_collections) == 1:
                target_hair_collection = hair_collections[0]
            elif len(hair_collections) > 1:
                # Use the first one found for now
                target_hair_collection = hair_collections[0]
        
        if not target_clothes_collection:
            # If still no target collection, create one in the source mesh's parent collection
            source_mesh = bpy.data.objects.get(self.source_mesh_name)
            if source_mesh:
                parent_collection = get_top_parent_collection(source_mesh)
                if parent_collection:
                    target_clothes_collection = bpy.data.collections.new("Clothes")
                    parent_collection.children.link(target_clothes_collection)
                else:
                    target_clothes_collection = bpy.data.collections.new("Clothes")
                    context.scene.collection.children.link(target_clothes_collection)
            else:
                target_clothes_collection = bpy.data.collections.new("Clothes")
                context.scene.collection.children.link(target_clothes_collection)
        
        if not target_char_specific_proxies_collection:
            # Create char specific proxies collection in the source mesh's parent collection
            source_mesh = bpy.data.objects.get(self.source_mesh_name)
            if source_mesh:
                parent_collection = get_top_parent_collection(source_mesh)
                if parent_collection:
                    target_char_specific_proxies_collection = bpy.data.collections.new("Char Specific Proxies")
                    parent_collection.children.link(target_char_specific_proxies_collection)
                else:
                    target_char_specific_proxies_collection = bpy.data.collections.new("Char Specific Proxies")
                    context.scene.collection.children.link(target_char_specific_proxies_collection)
            else:
                target_char_specific_proxies_collection = bpy.data.collections.new("Char Specific Proxies")
                context.scene.collection.children.link(target_char_specific_proxies_collection)
        
        if not target_char_appendage_collection:
            # Create char appendage collection in the source mesh's parent collection
            source_mesh = bpy.data.objects.get(self.source_mesh_name)
            if source_mesh:
                parent_collection = get_top_parent_collection(source_mesh)
                if parent_collection:
                    target_char_appendage_collection = bpy.data.collections.new("Char Appendage")
                    parent_collection.children.link(target_char_appendage_collection)
                else:
                    target_char_appendage_collection = bpy.data.collections.new("Char Appendage")
                    context.scene.collection.children.link(target_char_appendage_collection)
            else:
                target_char_appendage_collection = bpy.data.collections.new("Char Appendage")
                context.scene.collection.children.link(target_char_appendage_collection)
        
        if not target_hair_collection:
            # Create hair collection in the source mesh's parent collection
            source_mesh = bpy.data.objects.get(self.source_mesh_name)
            if source_mesh:
                parent_collection = get_top_parent_collection(source_mesh)
                if parent_collection:
                    target_hair_collection = bpy.data.collections.new("Hair")
                    parent_collection.children.link(target_hair_collection)
                else:
                    target_hair_collection = bpy.data.collections.new("Hair")
                    context.scene.collection.children.link(target_hair_collection)
            else:
                target_hair_collection = bpy.data.collections.new("Hair")
                context.scene.collection.children.link(target_hair_collection)
        
        # Find collections to append from the file
        clothes_collections_in_file = []
        char_specific_proxies_collections_in_file = []
        char_appendage_collections_in_file = []
        hair_collections_in_file = []
        
        try:
            with bpy.data.libraries.load(abs_filepath, link=False) as (data_from, data_to):
                for name in data_from.collections:
                    if name.lower().startswith("clothes"):
                        clothes_collections_in_file.append(name)
                    elif name.lower().startswith("char specific proxies"):
                        char_specific_proxies_collections_in_file.append(name)
                    elif name.lower().startswith("char appendage"):
                        char_appendage_collections_in_file.append(name)
                    elif name.lower().startswith("hair") and self.append_hair:
                        hair_collections_in_file.append(name)
                
                collections_to_append = clothes_collections_in_file + char_specific_proxies_collections_in_file + char_appendage_collections_in_file + hair_collections_in_file
                
                if not collections_to_append:
                    hair_text = ", or 'Hair'" if self.append_hair else ""
                    self.report({'INFO'}, f"No collections starting with 'Clothes', 'Char Specific Proxies', 'Char Appendage'{hair_text} found in the file.")
                    return {'FINISHED'}
                
                data_to.collections = collections_to_append
        except Exception as e:
            self.report({'ERROR'}, f"Error loading collections from {abs_filepath}: {e}")
            return {'CANCELLED'}
        
        # Separate appended collections by type
        appended_clothes_collections = []
        appended_char_specific_proxies_collections = []
        appended_char_appendage_collections = []
        appended_hair_collections = []
        
        for collection in bpy.data.collections:
            if collection.name not in original_collection_names_in_scene and collection.library is None:
                if collection.name.lower().startswith("clothes"):
                    appended_clothes_collections.append(collection)
                elif collection.name.lower().startswith("char specific proxies"):
                    appended_char_specific_proxies_collections.append(collection)
                elif collection.name.lower().startswith("char appendage"):
                    appended_char_appendage_collections.append(collection)
                elif collection.name.lower().startswith("hair") and self.append_hair:
                    appended_hair_collections.append(collection)
        
        all_appended_collections = appended_clothes_collections + appended_char_specific_proxies_collections + appended_char_appendage_collections + appended_hair_collections
        
        # Collect all appended items that will be part of presets before they are merged.
        new_preset_items = []
        preset_collections = appended_clothes_collections + appended_char_appendage_collections + appended_hair_collections
        for coll in preset_collections:
            get_all_children_and_objects_recursively(coll, new_preset_items)

        if not all_appended_collections:
            self.report({'INFO'}, "No new collections were actually appended.")
            return {'FINISHED'}
        
        # Apply remapping to appended meshes if source mesh and sd target were specified
        if self.source_mesh_name and self.sd_target_name:
            self.apply_remapping_to_appended_meshes(
                context, 
                all_appended_collections, 
                self.source_mesh_name,
                self.sd_target_name
            )
        
        # Merge clothes collections
        num_clothes_merged = 0
        potential_new_color_tag_from_appended = 'COLOR_00'

        for collection_to_merge in appended_clothes_collections:
            if collection_to_merge == target_clothes_collection:
                continue
            
            if collection_to_merge.color_tag != 'COLOR_00' and potential_new_color_tag_from_appended == 'COLOR_00':
                potential_new_color_tag_from_appended = collection_to_merge.color_tag
            
            for obj in list(collection_to_merge.objects):
                if obj.name not in target_clothes_collection.objects:
                    target_clothes_collection.objects.link(obj)
            
            for child in list(collection_to_merge.children):
                if child.name not in target_clothes_collection.children:
                    target_clothes_collection.children.link(child)
            
            for parent_coll in bpy.data.collections:
                if collection_to_merge.name in parent_coll.children:
                    parent_coll.children.unlink(collection_to_merge)
            if collection_to_merge.name in context.scene.collection.children:
                 context.scene.collection.children.unlink(collection_to_merge)
            
            bpy.data.collections.remove(collection_to_merge)
            num_clothes_merged += 1
        
        # Merge char specific proxies collections
        num_char_specific_proxies_merged = 0
        potential_new_color_tag_from_char_specific_proxies = 'COLOR_00'

        for collection_to_merge in appended_char_specific_proxies_collections:
            if collection_to_merge == target_char_specific_proxies_collection:
                continue
            
            if collection_to_merge.color_tag != 'COLOR_00' and potential_new_color_tag_from_char_specific_proxies == 'COLOR_00':
                potential_new_color_tag_from_char_specific_proxies = collection_to_merge.color_tag
            
            for obj in list(collection_to_merge.objects):
                if obj.name not in target_char_specific_proxies_collection.objects:
                    target_char_specific_proxies_collection.objects.link(obj)
            
            for child in list(collection_to_merge.children):
                if child.name not in target_char_specific_proxies_collection.children:
                    target_char_specific_proxies_collection.children.link(child)
            
            for parent_coll in bpy.data.collections:
                if collection_to_merge.name in parent_coll.children:
                    parent_coll.children.unlink(collection_to_merge)
            if collection_to_merge.name in context.scene.collection.children:
                 context.scene.collection.children.unlink(collection_to_merge)
            
            bpy.data.collections.remove(collection_to_merge)
            num_char_specific_proxies_merged += 1
        
        # Merge char appendage collections
        num_char_appendage_merged = 0
        potential_new_color_tag_from_char_appendage = 'COLOR_00'

        for collection_to_merge in appended_char_appendage_collections:
            if collection_to_merge == target_char_appendage_collection:
                continue
            
            if collection_to_merge.color_tag != 'COLOR_00' and potential_new_color_tag_from_char_appendage == 'COLOR_00':
                potential_new_color_tag_from_char_appendage = collection_to_merge.color_tag
            
            for obj in list(collection_to_merge.objects):
                if obj.name not in target_char_appendage_collection.objects:
                    target_char_appendage_collection.objects.link(obj)
            
            for child in list(collection_to_merge.children):
                if child.name not in target_char_appendage_collection.children:
                    target_char_appendage_collection.children.link(child)
            
            for parent_coll in bpy.data.collections:
                if collection_to_merge.name in parent_coll.children:
                    parent_coll.children.unlink(collection_to_merge)
            if collection_to_merge.name in context.scene.collection.children:
                 context.scene.collection.children.unlink(collection_to_merge)
            
            bpy.data.collections.remove(collection_to_merge)
            num_char_appendage_merged += 1
        
        # Merge hair collections
        num_hair_merged = 0
        potential_new_color_tag_from_hair = 'COLOR_00'

        for collection_to_merge in appended_hair_collections:
            if collection_to_merge == target_hair_collection:
                continue
            
            if collection_to_merge.color_tag != 'COLOR_00' and potential_new_color_tag_from_hair == 'COLOR_00':
                potential_new_color_tag_from_hair = collection_to_merge.color_tag
            
            for obj in list(collection_to_merge.objects):
                if obj.name not in target_hair_collection.objects:
                    target_hair_collection.objects.link(obj)
            
            for child in list(collection_to_merge.children):
                if child.name not in target_hair_collection.children:
                    target_hair_collection.children.link(child)
            
            for parent_coll in bpy.data.collections:
                if collection_to_merge.name in parent_coll.children:
                    parent_coll.children.unlink(collection_to_merge)
            if collection_to_merge.name in context.scene.collection.children:
                 context.scene.collection.children.unlink(collection_to_merge)
            
            bpy.data.collections.remove(collection_to_merge)
            num_hair_merged += 1
        
        # Build final report message
        final_report_parts = []
        
        if num_clothes_merged > 0:
            final_report_parts.append(f"Merged {num_clothes_merged} clothing collections into '{target_clothes_collection.name}' collection")
        
        if num_char_specific_proxies_merged > 0:
            final_report_parts.append(f"Merged {num_char_specific_proxies_merged} char specific proxies collections into '{target_char_specific_proxies_collection.name}' collection")
        
        if num_char_appendage_merged > 0:
            final_report_parts.append(f"Merged {num_char_appendage_merged} char appendage collections into '{target_char_appendage_collection.name}' collection")
        
        if num_hair_merged > 0:
            final_report_parts.append(f"Merged {num_hair_merged} hair collections into '{target_hair_collection.name}' collection")
        
        final_report_message = ". ".join(final_report_parts) + "."

        # Apply color tag logic for clothes collection
        if self.source_mesh_name and num_clothes_merged > 0:
            if target_clothes_collection.color_tag != 'COLOR_00':
                final_report_message += f" Clothes collection's original color tag ('{target_clothes_collection.color_tag}') was preserved."
            else:
                if potential_new_color_tag_from_appended != 'COLOR_00':
                    target_clothes_collection.color_tag = potential_new_color_tag_from_appended
                    final_report_message += f" Clothes collection color tag set to '{potential_new_color_tag_from_appended}' from an appended item."
                else:
                    target_clothes_collection.color_tag = 'COLOR_03'
                    final_report_message += f" Clothes collection color tag set to default ('COLOR_03')."
        
        # Apply color tag logic for char specific proxies collection
        if self.source_mesh_name and num_char_specific_proxies_merged > 0:
            if target_char_specific_proxies_collection.color_tag != 'COLOR_00':
                final_report_message += f" Char Specific Proxies collection's original color tag ('{target_char_specific_proxies_collection.color_tag}') was preserved."
            else:
                if potential_new_color_tag_from_char_specific_proxies != 'COLOR_00':
                    target_char_specific_proxies_collection.color_tag = potential_new_color_tag_from_char_specific_proxies
                    final_report_message += f" Char Specific Proxies collection color tag set to '{potential_new_color_tag_from_char_specific_proxies}' from an appended item."
                else:
                    target_char_specific_proxies_collection.color_tag = 'COLOR_04'
                    final_report_message += f" Char Specific Proxies collection color tag set to default ('COLOR_04')."
        
        # Apply color tag logic for char appendage collection
        if self.source_mesh_name and num_char_appendage_merged > 0:
            if target_char_appendage_collection.color_tag != 'COLOR_00':
                final_report_message += f" Char Appendage collection's original color tag ('{target_char_appendage_collection.color_tag}') was preserved."
            else:
                if potential_new_color_tag_from_char_appendage != 'COLOR_00':
                    target_char_appendage_collection.color_tag = potential_new_color_tag_from_char_appendage
                    final_report_message += f" Char Appendage collection color tag set to '{potential_new_color_tag_from_char_appendage}' from an appended item."
                else:
                    target_char_appendage_collection.color_tag = 'COLOR_05'
                    final_report_message += f" Char Appendage collection color tag set to default ('COLOR_05')."
        
        # Apply color tag logic for hair collection
        if self.source_mesh_name and num_hair_merged > 0:
            if target_hair_collection.color_tag != 'COLOR_00':
                final_report_message += f" Hair collection's original color tag ('{target_hair_collection.color_tag}') was preserved."
            else:
                if potential_new_color_tag_from_hair != 'COLOR_00':
                    target_hair_collection.color_tag = potential_new_color_tag_from_hair
                    final_report_message += f" Hair collection color tag set to '{potential_new_color_tag_from_hair}' from an appended item."
                else:
                    target_hair_collection.color_tag = 'COLOR_06'
                    final_report_message += f" Hair collection color tag set to default ('COLOR_06')."
        
        # Update presets after appending is complete
        if self.source_mesh_name:
            source_mesh = bpy.data.objects.get(self.source_mesh_name)
            if source_mesh and "presets" in source_mesh and source_mesh["presets"]:
                # Preserve viewport state through the preset update process.
                # 1. Ensure the source mesh is active and capture the current visibility state.
                original_active = context.view_layer.objects.active
                context.view_layer.objects.active = source_mesh
                pre_update_outfit_state = capture_outfit_preset(context)

                # 2. Update the presets. This function handles its own active object management.
                update_presets_after_append(source_mesh, new_preset_items)

                # 3. Restore the original visibility state by re-applying the captured state.
                apply_outfit_preset(pre_update_outfit_state)

                # 4. Restore the original active object.
                context.view_layer.objects.active = original_active

        if self.append_toggled_off:
            for item in new_preset_items:
                if hasattr(item, 'hide_viewport'):
                    item.hide_viewport = True
                    item.hide_render = True

        self.report({'INFO'}, final_report_message)
        return {'FINISHED'}

def draw_clothes_collection_menu(self, context):
    layout = self.layout
    scene = context.scene
    filepath = scene.append_clothing_filepath
    source_mesh = scene.armature_source
    
    # Get all clothes collections in the parent collection
    clothes_collections = find_clothes_collections_in_parent(source_mesh)
    
    # Display all clothes collections
    for coll in clothes_collections:
        op = layout.operator(OT_SelectClothesCollection.bl_idname, text=coll.name)
        op.collection_name = coll.name
        op.filepath = filepath
        op.source_mesh_name = source_mesh.name
        op.sd_target_name = scene.sd_target_name if hasattr(scene, 'sd_target_name') else ""

def register():
    bpy.utils.register_class(OT_ApplyRemap)
    bpy.utils.register_class(OT_SelectClothesCollection)
    bpy.utils.register_class(WM_OT_AppendClothingDialog)
    bpy.utils.register_class(WM_OT_AppendClothing)
    bpy.utils.register_class(WM_OT_AppendClothingExecute)
    
    bpy.types.Scene.armature_source = PointerProperty(
        name="Source Mesh",
        type=bpy.types.Object,
        poll=mesh_poll,
        description="Select the HHP character mesh you want to remap appended assets to"
    )
    
    # Add property to store filepath for the popup menu
    bpy.types.Scene.append_clothing_filepath = StringProperty(
        name="Append Clothing Filepath",
        default="",
        options={'HIDDEN'}
    )
    
    # Add property to store sd target name for the clothes collection popup
    bpy.types.Scene.sd_target_name = StringProperty(
        name="Surface Deform Target Name",
        default="",
        options={'HIDDEN'}
    )
    
    # Add property to store append hair setting for the popup menu
    bpy.types.Scene.append_hair_setting = BoolProperty(
        name="Append Hair Setting",
        default=False,
        options={'HIDDEN'}
    )
    
    # Add property to store append toggled off setting for the popup menu
    bpy.types.Scene.append_toggled_off_setting = BoolProperty(
        name="Append Toggled Off Setting",
        default=False,
        options={'HIDDEN'}
    )

def unregister():
    bpy.utils.unregister_class(WM_OT_AppendClothingExecute)
    bpy.utils.unregister_class(WM_OT_AppendClothing)
    bpy.utils.unregister_class(WM_OT_AppendClothingDialog)
    bpy.utils.unregister_class(OT_SelectClothesCollection)
    bpy.utils.unregister_class(OT_ApplyRemap)
    
    if hasattr(bpy.types.Scene, 'armature_source'):
        del bpy.types.Scene.armature_source
    
    if hasattr(bpy.types.Scene, 'append_clothing_filepath'):
        del bpy.types.Scene.append_clothing_filepath
        
    if hasattr(bpy.types.Scene, 'sd_target_name'):
        del bpy.types.Scene.sd_target_name
        
    if hasattr(bpy.types.Scene, 'append_hair_setting'):
        del bpy.types.Scene.append_hair_setting 
        
    if hasattr(bpy.types.Scene, 'append_toggled_off_setting'):
        del bpy.types.Scene.append_toggled_off_setting 