"""Optional, namespaced access to the bundled Rigify runtime.

This module is always installed. Removing ``Rigify Compat`` or its contents
disables its operators without preventing registration of the native tools.
"""
from contextlib import contextmanager
from importlib import util
from pathlib import Path
import sys

_ADDON_PACKAGE = __package__.rsplit('.modules', 1)[0]
_PACKAGE = _ADDON_PACKAGE + '._rigify_compat'
_DIRECTORY = Path(__file__).resolve().parents[1] / 'Rigify Compat'
_module = None
_reason = ''


class RigifyCompatUnavailable(RuntimeError):
    """An optional Rigify operation is unavailable; native tools still work."""


def _files_present():
    return all((_DIRECTORY / name).is_file()
               for name in ('__init__.py', 'generated_ui.py', 'bake_transaction.py'))


def _discard_modules():
    for name in list(sys.modules):
        if name == _PACKAGE or name.startswith(_PACKAGE + '.'):
            del sys.modules[name]


def _load():
    global _module, _reason
    if not _files_present():
        _reason = 'Rigify Compat is missing or incomplete. Restore that folder to use Rigify snapping and generation.'
        return None
    if _module is not None:
        return _module
    try:
        spec = util.spec_from_file_location(_PACKAGE, _DIRECTORY / '__init__.py',
                                          submodule_search_locations=[str(_DIRECTORY)])
        module = util.module_from_spec(spec)
        sys.modules[_PACKAGE] = module
        spec.loader.exec_module(module)
        _module = module
        _reason = ''
        return module
    except Exception as exc:
        _discard_modules()
        _reason = 'Rigify Compat could not load: ' + str(exc)
        return None


def is_available():
    return _load() is not None


def unavailable_reason():
    _load()
    return _reason


def require_ui():
    module = _load()
    if module is None:
        raise RigifyCompatUnavailable(_reason)
    return module.generated_ui


def set_transform_from_matrix(*args, **kwargs):
    return require_ui().set_transform_from_matrix(*args, **kwargs)


def register():
    """Non-raising registration for the main add-on startup path."""
    global _reason
    module = _load()
    if module is None:
        return False
    try:
        module.generated_ui.register()
        return True
    except Exception as exc:
        _reason = 'Rigify Compat operators could not register: ' + str(exc)
        return False


def unregister():
    global _module, _reason
    # A loaded runtime still owns RNA even if its files were removed meanwhile.
    try:
        if _module is not None:
            _module.generated_ui.unregister()
    finally:
        _module = None
        _reason = ''
        _discard_modules()


def has_generator():
    return is_available() and (_DIRECTORY / 'generation.py').is_file() and (
        _DIRECTORY / 'vendor/rigify/__init__.py').is_file()


@contextmanager
def generation_context():
    """Provide the bundled generation engine only for a build operation."""
    module = _load()
    if module is None or not has_generator():
        raise RigifyCompatUnavailable(unavailable_reason() or
            'Rigify Compat generation sources are missing. Restore the complete folder to build a rig.')
    try:
        from importlib import import_module
        generation = import_module(_PACKAGE + '.generation')
    except Exception as exc:
        raise RigifyCompatUnavailable('Rigify Compat generation could not load: ' + str(exc)) from exc
    try:
        with generation.generation_context() as engine:
            yield engine
    except ImportError as exc:
        raise RigifyCompatUnavailable(
            'Rigify Compat generation sources are incomplete. Restore the complete folder. ' + str(exc)
        ) from exc
