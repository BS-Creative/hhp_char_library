"""Central naming standards for the HHP character body datablocks.

Two naming standards are accepted for the character body. Every tool asks the
helpers below instead of testing a literal name, so supporting a further
standard only ever means extending the tuples in this file.

    standard   object name             mesh data name       armature object name
    --------   --------------------    ------------------   --------------------
    Genesis    Genesis8Female.Shape    Genesis8Female       Genesis8Female
    HHP        Char Mesh (HHP)         Char Data (HHP)      Armature (HHP)

Blender's ".001" enumeration suffixes are tolerated by every helper here, and
the three fields are matched independently, so a character that mixes the two
standards (for example an HHP object name over Genesis mesh data) still passes.

This module deliberately does not import bpy: it only ever looks at names, so
the optional heavy tools can fall back to their own copy when they are loaded
outside the addon package.
"""

import re

# Object names of the character body mesh.
CHAR_MESH_OBJECT_NAMES = ("Genesis8Female.Shape", "Char Mesh (HHP)")

# Mesh data (datablock) names of the character body mesh.
CHAR_MESH_DATA_NAMES = ("Genesis8Female", "Char Data (HHP)")

# Object names of the character armature.
CHAR_ARMATURE_NAMES = ("Genesis8Female", "Armature (HHP)")

# Object-name marker for the deform proxies that share the character's data.
DEFORM_PROXY_TOKEN = "Deform Proxy"

_ENUMERATION_SUFFIX = re.compile(r"\.\d+$")


def base_name(name):
    """Strip Blender's enumeration suffix ('Char Mesh (HHP).001' -> 'Char Mesh (HHP)')."""
    return _ENUMERATION_SUFFIX.sub("", name or "")


def name_contains_any(name, tokens):
    """True when any standard's token appears anywhere in the name."""
    return bool(name) and any(token in name for token in tokens)


def name_startswith_any(name, tokens):
    """True when the name begins with any standard's token."""
    return bool(name) and any(name.startswith(token) for token in tokens)


def base_name_matches_any(name, tokens):
    """True when the name, minus its enumeration suffix, is exactly one of the tokens."""
    return bool(name) and base_name(name) in tokens


def is_char_mesh_object_name(name):
    """True for an object name that follows either character-mesh standard."""
    return name_contains_any(name, CHAR_MESH_OBJECT_NAMES)


def is_char_mesh_data_name(name):
    """True for a mesh data name that follows either character-data standard."""
    return name_contains_any(name, CHAR_MESH_DATA_NAMES)


def is_char_armature_name(name):
    """True for an object name that follows either character-armature standard."""
    return name_contains_any(name, CHAR_ARMATURE_NAMES)


def is_deform_proxy_name(name):
    """True for the deform proxies, which reuse the character's mesh data name."""
    return bool(name) and DEFORM_PROXY_TOKEN in name


def is_char_mesh(obj, require_object_name=True, require_data_name=True, exclude_deform_proxy=True):
    """True when the object is the character body mesh under either standard.

    The three checks are individually optional so each tool keeps the exact
    strictness it had before the second standard was introduced.
    """
    if obj is None or getattr(obj, "type", None) != 'MESH':
        return False
    if require_object_name and not is_char_mesh_object_name(obj.name):
        return False
    if require_data_name:
        data_name = getattr(getattr(obj, "data", None), "name", None)
        if not is_char_mesh_data_name(data_name):
            return False
    if exclude_deform_proxy and is_deform_proxy_name(obj.name):
        return False
    return True


def is_char_armature(obj):
    """True when the object is the character armature under either standard."""
    return (
        obj is not None
        and getattr(obj, "type", None) == 'ARMATURE'
        and is_char_armature_name(obj.name)
    )
