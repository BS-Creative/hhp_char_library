"""Explicit tongue-base control and unconstrained four-segment IK chain."""
import json
import bpy
from mathutils import Matrix
from .hhp_rigify_fingers_tongue import _drive


def upgrade(arm):
    data=json.loads(arm['hhp_rigify_manifest'])
    if data.get('tongue_base_revision'):
        return data['tongue_base_control']
    item=next(item for item in data['fingers'] if 'tongue' in item['base'])
    chain=json.loads(item['to_fk']['ik_chain'])
    name='tongue_base'
    if name in arm.data.bones:
        raise RuntimeError('Tongue base bone name is already in use')
    bpy.context.view_layer.objects.active=arm
    if arm.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.mode_set(mode='EDIT')
    first=arm.data.edit_bones[chain[0]]
    base=arm.data.edit_bones.new(name)
    base.head,base.tail,base.roll=first.head,first.tail,first.roll
    base.parent=first.parent;base.use_deform=False
    arm.data.collections_all['Tongue / IK'].assign(base)
    bpy.ops.object.mode_set(mode='OBJECT')
    base=arm.pose.bones[name]
    base.rotation_mode='QUATERNION'
    base.lock_location=(False,False,False)
    base.lock_rotation=(False,False,False)
    base.lock_scale=(False,True,True)
    reference=bpy.data.objects.get('Genesis8Female')
    reference=reference.pose.bones.get('tongue01') if reference else None
    if reference and reference.custom_shape:
        widget=reference.custom_shape.copy()
        if widget.data:widget.data=widget.data.copy()
        widget.name='HHP Tongue Base Widget';widget.hide_render=True
        bpy.data.collections['HHP Bone Widgets'].objects.link(widget)
        base.custom_shape=widget
        for prop in ('custom_shape_translation','custom_shape_rotation_euler',
                     'custom_shape_scale_xyz','use_custom_shape_bone_size'):
            setattr(base,prop,getattr(reference,prop))
    base.color.palette=arm.pose.bones[item['ik_control']].color.palette
    ik_path=arm.pose.bones[item['ik_control']].path_from_id()+'["FK_IK"]'
    for bone_name in chain:
        pb=arm.pose.bones[bone_name]
        # FK's stretch scaffolding must not dictate the initial matrices of
        # the IK solver. The solver inherits its own connected rest chain.
        con=pb.constraints['Copy Transforms']
        _drive(con,'influence',arm,'1-ik',{'ik':ik_path})
    first=arm.pose.bones[chain[0]]
    con=first.constraints.new('COPY_TRANSFORMS')
    con.name='(HHP) Tongue Base';con.target=arm;con.subtarget=name
    con.owner_space=con.target_space='WORLD'
    _drive(con,'influence',arm,'ik',{'ik':ik_path})
    # The original master is still needed by the generated FK snap, but it
    # does not control this independent IK chain and belongs with FK bones.
    master=arm.data.bones[item['master']]
    for coll in list(master.collections):coll.unassign(master)
    arm.data.collections_all['Tongue / FK'].assign(master)
    item['base_control']=name
    data['tongue_base_revision']=1;data['tongue_base_control']=name
    data['controls'].append(name);data['generated_bones'].append(name)
    data['neutral_basis'][name]=[list(row) for row in Matrix.Identity(4)]
    arm['hhp_rigify_manifest']=json.dumps(data,separators=(',',':'))
    arm.update_tag(refresh={'OBJECT'});bpy.context.view_layer.update()
    return name


def prepare_ik_snap(arm,item):
    """Place the root control before the normal generated tip snap."""
    name=item.get('base_control')
    if name:
        first=json.loads(item['to_fk']['ik_chain'])[0]
        arm.pose.bones[name].matrix=arm.pose.bones[first].matrix.copy()
        arm.update_tag(refresh={'OBJECT'});bpy.context.view_layer.update()
