import bpy
import bmesh
from mathutils import Vector
from mathutils.bvhtree import BVHTree

def compute_barycentric(P, A, B, C):
    """Compute barycentric coordinates for point P in triangle ABC"""
    v0 = B - A
    v1 = C - A
    v2 = P - A
    d00 = v0.dot(v0)
    d01 = v0.dot(v1)
    d11 = v1.dot(v1)
    d20 = v2.dot(v0)
    d21 = v2.dot(v1)
    denom = d00 * d11 - d01 * d01
    if denom == 0:
        return (1, 0, 0)
    v = (d11 * d20 - d01 * d21) / denom
    w = (d00 * d21 - d01 * d20) / denom
    u = 1 - v - w
    return (u, v, w)

def build_source_bvhtree(source_obj):
    """Build BVH tree from source object with face mapping"""
    # Get the evaluated version of the object that includes all modifiers and shapekeys
    depsgraph = bpy.context.evaluated_depsgraph_get()
    eval_obj = source_obj.evaluated_get(depsgraph)
    
    bm = bmesh.new()
    bm.from_mesh(eval_obj.data)  # Use evaluated mesh data
    
    # Transform to world space
    bm.transform(source_obj.matrix_world)
    bmesh.ops.triangulate(bm, faces=bm.faces[:])
    bm.verts.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    bm.normal_update()
    bm.faces.ensure_lookup_table()
    
    bvh = BVHTree.FromBMesh(bm)
    
    # Create face mapping with coordinates and normals
    face_mapping = []
    for face in bm.faces:
        inds = [v.index for v in face.verts]
        coords = [v.co.copy() for v in face.verts]
        normals = [v.normal.copy() for v in face.verts]
        face_mapping.append((inds, coords, normals))
    
    return bvh, face_mapping, bm

def get_source_basis_world(source_obj):
    """Get basis coordinates in world space"""
    coords = []
    for v in source_obj.data.vertices:
        coords.append(source_obj.matrix_world @ v.co)
    return coords

def get_next_inflate_name(target_obj):
    """Get the next available inflate shapekey name"""
    base_name = "(BS) Inflate"
    
    if not target_obj.data.shape_keys:
        return base_name
    
    # Check if base name exists
    if base_name not in target_obj.data.shape_keys.key_blocks:
        return base_name
    
    # Find next available enumerated name
    counter = 1
    while True:
        new_name = f"{base_name}.{counter:03d}"
        if new_name not in target_obj.data.shape_keys.key_blocks:
            return new_name
        counter += 1

def store_armature_poses():
    """Store current pose states of all armatures in the scene"""
    pose_states = {}
    for obj in bpy.context.scene.objects:
        if obj.type == 'ARMATURE':
            pose_states[obj.name] = obj.data.pose_position
    return pose_states

def set_armatures_to_rest():
    """Set all armatures in the scene to rest position"""
    for obj in bpy.context.scene.objects:
        if obj.type == 'ARMATURE':
            obj.data.pose_position = 'REST'
    bpy.context.view_layer.update()

def restore_armature_poses(pose_states):
    """Restore armature poses from stored states"""
    for obj in bpy.context.scene.objects:
        if obj.type == 'ARMATURE' and obj.name in pose_states:
            obj.data.pose_position = pose_states[obj.name]
    bpy.context.view_layer.update()

def has_armature_modifier(obj):
    """Check if object has an armature modifier"""
    return any(mod.type == 'ARMATURE' for mod in obj.modifiers)

class HHP_OT_InflateSkByActive(bpy.types.Operator):
    bl_idname = "hhp.inflate_sk_by_active"
    bl_label = "Inflate SK by active"
    bl_description = "Create a '(BS) Inflate' shapekey on selected meshes that inflates them based on the normals of the active mesh"
    bl_options = {'REGISTER', 'UNDO'}
    
    project_at_rest: bpy.props.BoolProperty(
        name="Project inflation at rest pose",
        description="Set armatures to rest position during inflation projection if active mesh has armature modifier",
        default=True
    )
    
    inflation_amount: bpy.props.FloatProperty(
        name="Inflation Amount",
        description="Amount to inflate in Blender units",
        default=0.01,
        min=0.0001,
        max=1.0,
        step=0.1,
        precision=3
    )
    
    shapekey_value: bpy.props.FloatProperty(
        name="Shapekey Value",
        description="Value of the created shapekey",
        default=1.0,
        min=0.0,
        max=1.0,
        step=0.1,
        precision=3
    )

    def execute(self, context):
        active_obj = context.active_object
        selected_objects = context.selected_objects
        
        # Check if we have an active object
        if not active_obj:
            self.report({'ERROR'}, "No active object selected")
            return {'CANCELLED'}
        
        # Check if active object is a mesh
        if active_obj.type != 'MESH':
            self.report({'ERROR'}, "Active object must be a mesh")
            return {'CANCELLED'}
        
        # Get selected meshes excluding the active one
        target_meshes = [obj for obj in selected_objects if obj != active_obj and obj.type == 'MESH']
        
        if not target_meshes:
            self.report({'ERROR'}, "No other mesh objects selected")
            return {'CANCELLED'}
        
        # Store original mode
        original_mode = context.mode
        
        # Switch to object mode
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # Handle armature poses if needed
        pose_states = None
        if self.project_at_rest and has_armature_modifier(active_obj):
            pose_states = store_armature_poses()
            set_armatures_to_rest()
        
        try:
            # Build BVH tree from active mesh
            bvh, face_mapping, bm = build_source_bvhtree(active_obj)
            src_basis = get_source_basis_world(active_obj)
            
            # Create inflate shapekey for each target mesh
            for target_obj in target_meshes:
                self.create_inflate_shapekey(target_obj, bvh, face_mapping, src_basis)
            
            # Clean up
            bm.free()
            
            self.report({'INFO'}, f"Created inflate shapekey on {len(target_meshes)} object(s)")
            
        except Exception as e:
            self.report({'ERROR'}, f"Error creating inflate shapekey: {str(e)}")
            return {'CANCELLED'}
        
        finally:
            # Restore armature poses if they were modified
            if pose_states is not None:
                restore_armature_poses(pose_states)
            
            # Restore original mode
            if original_mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=original_mode)
        
        return {'FINISHED'}
    
    def create_inflate_shapekey(self, target_obj, bvh, face_mapping, src_basis):
        """Create an inflate shapekey on the target object based on active object normals"""
        
        # Ensure the target object has a basis shapekey
        if not target_obj.data.shape_keys:
            target_obj.shape_key_add(name="Basis", from_mix=False)
        
        # Get next available inflate name
        sk_name = get_next_inflate_name(target_obj)
        
        # Create the new inflate shapekey
        inflate_sk = target_obj.shape_key_add(name=sk_name, from_mix=False)
        
        # Get target basis coordinates in world space
        tgt_basis = []
        for v in target_obj.data.vertices:
            tgt_basis.append(target_obj.matrix_world @ v.co)
        
        n = len(tgt_basis)
        
        # Project each target vertex to find corresponding normal on active mesh
        hit_face_idx = [None] * n
        hit_point = [None] * n
        
        for i, pt in enumerate(tgt_basis):
            hit = bvh.find_nearest(pt)
            if hit is not None:
                loc, normal, face_idx, dist = hit
                hit_point[i] = loc
                hit_face_idx[i] = face_idx
            else:
                hit_point[i] = None
                hit_face_idx[i] = None
        
        # Calculate inflated positions
        inflated_positions = [None] * n
        
        for i in range(n):
            if hit_face_idx[i] is not None:
                # Get the hit point and face information
                loc = hit_point[i]
                face_idx = hit_face_idx[i]
                inds, tri_coords, tri_normals = face_mapping[face_idx]
                
                # Get triangle vertices and normals
                A, B, C = tri_coords[0], tri_coords[1], tri_coords[2]
                nA, nB, nC = tri_normals[0], tri_normals[1], tri_normals[2]
                
                # Compute barycentric coordinates
                u, v, w = compute_barycentric(loc, A, B, C)
                
                # Interpolate normal using barycentric coordinates
                interpolated_normal = u * nA + v * nB + w * nC
                interpolated_normal.normalize()
                
                # Apply inflation
                inflated_pos = tgt_basis[i] + (interpolated_normal * self.inflation_amount)
                inflated_positions[i] = inflated_pos
            else:
                # If no hit found, don't inflate (use original position)
                inflated_positions[i] = tgt_basis[i]
        
        # Update shapekey vertex positions
        for i, inflated_pos in enumerate(inflated_positions):
            # Convert back to local space
            local_co = target_obj.matrix_world.inverted() @ inflated_pos
            inflate_sk.data[i].co = local_co
        
        # Set the shapekey value
        inflate_sk.value = self.shapekey_value
        
        # Make the created shapekey the active shapekey
        for idx, kb in enumerate(target_obj.data.shape_keys.key_blocks):
            if kb == inflate_sk:
                target_obj.active_shape_key_index = idx
                break
        
        # Update the mesh
        target_obj.data.update()

    def draw(self, context):
        layout = self.layout
        
        # Checkbox at top
        layout.prop(self, "project_at_rest")
        
        # Vertically aligned sliders
        col = layout.column(align=True)
        col.prop(self, "inflation_amount")
        col.prop(self, "shapekey_value", slider=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

# Registration
classes = (
    HHP_OT_InflateSkByActive,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register() 