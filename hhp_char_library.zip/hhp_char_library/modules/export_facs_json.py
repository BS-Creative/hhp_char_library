import bpy
import json
import os

from bpy_extras.io_utils import ExportHelper
from bpy.props import StringProperty, EnumProperty

# Mouth-only shapekeys list
MOUTH_SHAPEKEYS = [
    "jawForward",
    "jawLeft",
    "jawRight",
    "jawOpen",
    "mouthClose",
    "mouthFunnel",
    "mouthPucker",
    "mouthLeft",
    "mouthRight",
    "mouthSmileLeft",
    "mouthSmileRight",
    "mouthFrownLeft",
    "mouthFrownRight",
    "mouthDimpleLeft",
    "mouthDimpleRight",
    "mouthStretchLeft",
    "mouthStretchRight",
    "mouthRollLower",
    "mouthRollUpper",
    "mouthShrugLower",
    "mouthShrugUpper",
    "mouthPressLeft",
    "mouthPressRight",
    "mouthLowerDownLeft",
    "mouthLowerDownRight",
    "mouthUpperUpLeft",
    "mouthUpperUpRight",
    "cheekPuff",
    "tongueOut"
]

class HHP_OT_Export_FACS_JSON(bpy.types.Operator, ExportHelper):
    """Export the active shapekey action to a JSON file"""
    bl_idname = "hhp.export_facs_json"
    bl_label = "Export FACS to JSON"
    bl_options = {'PRESET'}

    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})

    export_mode: EnumProperty(
        name="Export Mode",
        description="Select which shapekeys to export",
        items=[
            ('FULL', "Full Face", "Export full shapekey animation"),
            ('MOUTH_ONLY', "Lip Sync Only", "Export only mouth-related shapekey animation")
        ],
        default='FULL'
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.data.shape_keys or not obj.data.shape_keys.animation_data or not obj.data.shape_keys.animation_data.action:
            self.report({'ERROR'}, "No active shapekey action on the active mesh.")
            return {'CANCELLED'}

        action = obj.data.shape_keys.animation_data.action
        
        frame_start = int(action.frame_range[0])
        frame_end = int(action.frame_range[1])
        
        facs_names = []
        for fcurve in action.fcurves:
            if 'key_blocks' in fcurve.data_path and '.value' in fcurve.data_path:
                shapekey_name = fcurve.data_path.split('"')[1]
                if self.export_mode == 'MOUTH_ONLY' and shapekey_name not in MOUTH_SHAPEKEYS:
                    continue
                if shapekey_name not in facs_names:
                    facs_names.append(shapekey_name)

        if not facs_names:
            self.report({'ERROR'}, "No shapekeys to export for the selected mode.")
            return {'CANCELLED'}
        
        weight_mat = []
        for frame in range(frame_start, frame_end + 1):
            frame_weights = []
            for shapekey_name in facs_names:
                value = 0.0
                for fcurve in action.fcurves:
                     if fcurve.data_path == f'key_blocks["{shapekey_name}"].value':
                        value = fcurve.evaluate(frame)
                        break
                frame_weights.append(value)
            weight_mat.append(frame_weights)

        export_data = {
            "exportFps": context.scene.render.fps,
            "numFrames": len(weight_mat),
            "facsNames": facs_names,
            "weightMat": weight_mat,
        }

        with open(self.filepath, 'w') as jsonfile:
            json.dump(export_data, jsonfile, indent=4)

        self.report({'INFO'}, f"Exported to {self.filepath}")
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.prop(self, "export_mode", expand=True)

def register():
    bpy.utils.register_class(HHP_OT_Export_FACS_JSON)

def unregister():
    bpy.utils.unregister_class(HHP_OT_Export_FACS_JSON)
