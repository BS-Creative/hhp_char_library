import bpy

HHP_MIX_SSS_MASK_NODETREE_NAME = "(HHP) Mix SSS Mask"
HHP_MIX_SSS_MASK_WEIGHT_SOCKET_NAME = "SSS Mask (Weight)"
HHP_MIX_SSS_MASK_ORIG_PROP_KEY = "orig_hhp_mix_sss_mask_weight"
HHP_MIX_SSS_MASK_MAX_WEIGHT = 0.999

def _render_engine_identifiers(scene) -> set[str]:
    """Return the set of valid render engine enum identifiers for this Blender build."""
    try:
        enum_items = scene.render.bl_rna.properties["engine"].enum_items
        # enum_items is iterable over EnumPropertyItem
        return {item.identifier for item in enum_items}
    except Exception:
        # Fallback: if RNA access fails for any reason, return empty set.
        return set()

def _set_render_engine_first_available(scene, engine_ids: tuple[str, ...]) -> str | None:
    """
    Set scene.render.engine to the first identifier that exists in this Blender build.
    Returns the identifier that was set, or None if none were available.
    """
    available = _render_engine_identifiers(scene)
    for engine_id in engine_ids:
        if engine_id in available:
            scene.render.engine = engine_id
            return engine_id
    return None

# Any object living anywhere under (i.e. inside) a collection whose name contains
# one of these tokens will be ignored by conversion + revert operations.
# This applies even if the object is inside a nested sub-collection of such a collection.
IGNORED_COLLECTION_NAME_TOKENS = (
    "Proxies (HHP)",
    "Collision",
    "Controllers (HHP)",
    "Block Proxy",
)

def _collection_name_is_ignored(name: str) -> bool:
    name_l = (name or "").lower()
    return any(tok.lower() in name_l for tok in IGNORED_COLLECTION_NAME_TOKENS)

def _get_ignored_object_names_in_scene(context) -> set[str]:
    """
    Return a set of object names that are inside any ignored collection in the scene collection tree.
    If an ignored collection is found, all objects in that collection and its descendants are ignored.
    """
    ignored_names: set[str] = set()

    def _walk_collection(col, parent_ignored: bool = False):
        this_ignored = parent_ignored or _collection_name_is_ignored(col.name)
        if this_ignored:
            for obj in col.all_objects:
                ignored_names.add(obj.name)
            # No need to descend further; all_objects already covers descendants.
            return
        for child in col.children:
            _walk_collection(child, this_ignored)

    _walk_collection(context.scene.collection, False)
    return ignored_names

def _filter_ignored_objects(context, objs):
    """Filter out any objects that are inside ignored collections."""
    ignored = _get_ignored_object_names_in_scene(context)
    return [obj for obj in objs if obj and obj.name not in ignored]

def _iter_collections_recursive(root_col):
    yield root_col
    for child in root_col.children:
        yield from _iter_collections_recursive(child)

def get_hhp_char_collections(context):
    """Return all collections in the scene collection tree whose name starts with 'Char (HHP)'."""
    return [
        col for col in _iter_collections_recursive(context.scene.collection)
        if col.name.startswith("Char (HHP)")
    ]

def get_hhp_char_objects(context):
    """Return a deduped list of all objects in all 'Char (HHP)*' collections in the scene."""
    char_collections = get_hhp_char_collections(context)
    if not char_collections:
        return []

    ignored_names = _get_ignored_object_names_in_scene(context)
    seen = set()
    objs = []
    for col in char_collections:
        for obj in col.all_objects:
            # Object names are unique in the scene; safe dedupe key.
            if obj.name in ignored_names:
                continue
            if obj.name not in seen:
                seen.add(obj.name)
                objs.append(obj)
    return objs

def is_mesh_on_optimized_materials(obj):
    """
    Optimized materials in this addon are linked by OBJECT (not DATA).
    We treat a mesh as 'optimized' when all its material slots are OBJECT-linked.
    """
    return (
        obj is not None
        and obj.type == 'MESH'
        and bool(getattr(obj, "material_slots", None))
        and all(slot.link == 'OBJECT' for slot in obj.material_slots)
    )

def get_target_objects(context, target_mode):
    """
    Return the list of target objects based on the selected target mode.
    If 'COLLECTION' is selected, find ALL collections in the scene collection tree
    whose name starts with "Char (HHP)" and return the union of their objects.
    Otherwise, return the currently selected objects.
    """
    if target_mode == 'COLLECTION':
        return get_hhp_char_objects(context)
    else:
        # Still only operate on objects that belong to a 'Char (HHP)*' collection.
        hhp_objs = {obj.name for obj in get_hhp_char_objects(context)}
        return [obj for obj in context.selected_objects if obj.name in hhp_objs]

def get_target_objects_from_selected_collection(context, target_mode):
    """
    Return the list of target objects based on the selected target mode.
    If 'COLLECTION' is selected, find the collection that contains the selected object
    and return all objects from that collection and its subcollections.
    Otherwise, return the currently selected objects.
    """
    if target_mode == 'COLLECTION':
        if not context.selected_objects:
            return []
        
        selected_obj = context.selected_objects[0]
        
        # Find which collection contains the selected object
        def find_object_collection(obj, collection):
            if obj.name in collection.objects:
                return collection
            for child_col in collection.children:
                result = find_object_collection(obj, child_col)
                if result:
                    return result
            return None
        
        # Start searching from scene collection
        target_collection = find_object_collection(selected_obj, context.scene.collection)
        
        if target_collection:
            return _filter_ignored_objects(context, list(target_collection.all_objects))
        else:
            return _filter_ignored_objects(context, list(context.selected_objects))
    else:
        return _filter_ignored_objects(context, list(context.selected_objects))

def update_principled_nodes(node_tree):
    """
    Recursively update every Principled BSDF node in the provided node tree by
    setting its subsurface_method to 'BURLEY'. If the node is a group, process its node tree.
    """
    for node in node_tree.nodes:
        if node.type == 'BSDF_PRINCIPLED':
            node.subsurface_method = 'BURLEY'
            print(f"Updated {node.name} in node tree {node_tree.name}")
        if node.type == 'GROUP' and node.node_tree is not None:
            update_principled_nodes(node.node_tree)

def set_principled_sss_mode(node_tree, mode):
    """
    Recursively set the subsurface_method of all Principled BSDF nodes in the node_tree to the given mode.
    """
    for node in node_tree.nodes:
        if node.type == 'BSDF_PRINCIPLED':
            node.subsurface_method = mode
            print(f"Set {node.name} subsurface method to {mode} in node tree {node_tree.name}")
        if node.type == 'GROUP' and node.node_tree is not None:
            set_principled_sss_mode(node.node_tree, mode)

def set_sss_properties_in_node_tree(node_tree, mode, weight, radius):
    """
    Recursively set SSS properties for both Principled BSDF and Subsurface Scattering nodes.
    """
    # Map node types to their input socket names
    NODE_SSS_INPUTS = {
        'BSDF_PRINCIPLED': {
            'weight': 'Subsurface Weight',
            'radius': 'Subsurface Radius'
        },
        'SUBSURFACE_SCATTERING': {
            'weight': 'Scale',
            'radius': 'Radius'
        }
    }
    
    for node in node_tree.nodes:
        if node.type in NODE_SSS_INPUTS:
            inputs = NODE_SSS_INPUTS[node.type]
            
            # Set subsurface method for Principled BSDF
            if node.type == 'BSDF_PRINCIPLED':
                node.subsurface_method = mode
                print(f"Set {node.name} subsurface method to {mode} in node tree {node_tree.name}")
            
            # Set weight/scale
            if inputs['weight'] in node.inputs:
                weight_input = node.inputs[inputs['weight']]
                if hasattr(weight_input, 'default_value'):
                    weight_input.default_value = weight
                    print(f"Set {node.name} {inputs['weight']} to {weight} in node tree {node_tree.name}")
            
            # Set radius
            if inputs['radius'] in node.inputs:
                radius_input = node.inputs[inputs['radius']]
                if hasattr(radius_input, 'default_value'):
                    radius_input.default_value = radius
                    print(f"Set {node.name} {inputs['radius']} to {radius} in node tree {node_tree.name}")
        
        # Recurse into group nodes
        if node.type == 'GROUP' and node.node_tree is not None:
            set_sss_properties_in_node_tree(node.node_tree, mode, weight, radius)

def process_entire_blend_file_sss(mode, weight, radius):
    """
    Process every material, world, and node group in the blend file for SSS properties.
    """
    # Process all materials
    for mat in bpy.data.materials:
        if mat.use_nodes and mat.node_tree:
            set_sss_properties_in_node_tree(mat.node_tree, mode, weight, radius)
    
    # Process all worlds
    for world in bpy.data.worlds:
        if world.use_nodes and world.node_tree:
            set_sss_properties_in_node_tree(world.node_tree, mode, weight, radius)
    
    # Process all node groups
    for ng in bpy.data.node_groups:
        set_sss_properties_in_node_tree(ng, mode, weight, radius)

def process_sss_radius_in_node_tree(node_tree):
    """
    Process SSS radius values in a node tree for Principled BSDF and Subsurface Scattering nodes.
    If the X,Y,Z values of the radius are not within 0.03 of each other, change them all to 0.44.
    Store original values for restoration.
    """
    THRESHOLD = 0.03
    NEW_RADIUS = (0.44, 0.44, 0.44)
    
    # Map node types to the name of their SSS radius input socket
    NODE_SSS = {
        'BSDF_PRINCIPLED': 'Subsurface Radius',
        'SUBSURFACE_SCATTERING': 'Radius',
    }
    
    for node in node_tree.nodes:
        # Only care about Principled BSDF and SSS nodes
        input_name = NODE_SSS.get(node.type)
        if not input_name:
            # Recurse into group nodes
            if node.type == 'GROUP' and node.node_tree is not None:
                process_sss_radius_in_node_tree(node.node_tree)
            continue
            
        sock = node.inputs.get(input_name)
        if not sock or not hasattr(sock, "default_value"):
            continue
            
        # Ensure it's a 3-component vector
        try:
            vals = sock.default_value
            comps = [vals[i] for i in range(3)]
        except Exception:
            continue
            
        # Check if spread > threshold
        if max(comps) - min(comps) > THRESHOLD:
            # Store original value if not already stored
            original_key = f"orig_sss_radius_{input_name.replace(' ', '_').lower()}"
            if original_key not in node:
                node[original_key] = tuple(vals[:3])
                
            sock.default_value = NEW_RADIUS
            print(f"→ {node_tree.name}: set '{node.name}' {input_name} to {NEW_RADIUS}")

def revert_sss_radius_in_node_tree(node_tree):
    """
    Revert SSS radius values in a node tree back to their original values.
    """
    NODE_SSS = {
        'BSDF_PRINCIPLED': 'Subsurface Radius',
        'SUBSURFACE_SCATTERING': 'Radius',
    }
    
    for node in node_tree.nodes:
        # Only care about Principled BSDF and SSS nodes
        input_name = NODE_SSS.get(node.type)
        if not input_name:
            # Recurse into group nodes
            if node.type == 'GROUP' and node.node_tree is not None:
                revert_sss_radius_in_node_tree(node.node_tree)
            continue
            
        sock = node.inputs.get(input_name)
        if not sock or not hasattr(sock, "default_value"):
            continue
            
        # Check if we have stored original value
        original_key = f"orig_sss_radius_{input_name.replace(' ', '_').lower()}"
        if original_key in node:
            original_value = node[original_key]
            sock.default_value = original_value
            del node[original_key]
            print(f"→ {node_tree.name}: reverted '{node.name}' {input_name} to {original_value}")

def clamp_hhp_mix_sss_mask_weight_in_node_tree(node_tree, _visited=None):
    """
    Recursively find any Group nodes that use a node tree containing '(HHP) Mix SSS Mask' in its name.
    If the group node has an input named 'SSS Mask (Weight)' and it's > 0.999, clamp it to 0.999.
    Stores the original value on the node (once) so it can be restored later.
    Returns True if any values were clamped.
    """
    if _visited is None:
        _visited = set()
    if node_tree is None or node_tree in _visited:
        return False
    _visited.add(node_tree)

    changed = False
    for node in node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree is not None:
            # Clamp on the group node input socket (not inside the group tree).
            group_tree_name = node.node_tree.name or ""
            node_name = node.name or ""
            if (HHP_MIX_SSS_MASK_NODETREE_NAME in group_tree_name) or (HHP_MIX_SSS_MASK_NODETREE_NAME in node_name):
                sock = node.inputs.get(HHP_MIX_SSS_MASK_WEIGHT_SOCKET_NAME)
                if sock is not None and hasattr(sock, "default_value"):
                    try:
                        val = float(sock.default_value)
                    except Exception:
                        val = None
                    if val is not None and val > HHP_MIX_SSS_MASK_MAX_WEIGHT:
                        if HHP_MIX_SSS_MASK_ORIG_PROP_KEY not in node:
                            node[HHP_MIX_SSS_MASK_ORIG_PROP_KEY] = val
                        sock.default_value = HHP_MIX_SSS_MASK_MAX_WEIGHT
                        changed = True
                        print(
                            f"→ {node_tree.name}: clamped '{node.name}' "
                            f"{HHP_MIX_SSS_MASK_WEIGHT_SOCKET_NAME} from {val} to {HHP_MIX_SSS_MASK_MAX_WEIGHT}"
                        )

            # Recurse into nested groups
            changed |= clamp_hhp_mix_sss_mask_weight_in_node_tree(node.node_tree, _visited)

    return changed

def restore_hhp_mix_sss_mask_weight_in_node_tree(node_tree, _visited=None):
    """
    Recursively restore previously stored '(HHP) Mix SSS Mask' group node input values.
    Looks for nodes with the custom property 'orig_hhp_mix_sss_mask_weight' and restores
    the 'SSS Mask (Weight)' input, then removes the stored value.
    Returns True if any values were restored.
    """
    if _visited is None:
        _visited = set()
    if node_tree is None or node_tree in _visited:
        return False
    _visited.add(node_tree)

    restored = False
    for node in node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree is not None:
            if HHP_MIX_SSS_MASK_ORIG_PROP_KEY in node:
                sock = node.inputs.get(HHP_MIX_SSS_MASK_WEIGHT_SOCKET_NAME)
                if sock is not None and hasattr(sock, "default_value"):
                    original = node[HHP_MIX_SSS_MASK_ORIG_PROP_KEY]
                    sock.default_value = float(original)
                    del node[HHP_MIX_SSS_MASK_ORIG_PROP_KEY]
                    restored = True
                    print(
                        f"→ {node_tree.name}: restored '{node.name}' "
                        f"{HHP_MIX_SSS_MASK_WEIGHT_SOCKET_NAME} to {original}"
                    )

            restored |= restore_hhp_mix_sss_mask_weight_in_node_tree(node.node_tree, _visited)

    return restored

def _iter_group_nodes_recursive(node_tree, _visited=None):
    """
    Yield all GROUP nodes in a node tree, recursively descending into nested node groups.
    Uses a visited-set to avoid infinite loops from cyclic group references.
    """
    if _visited is None:
        _visited = set()
    if node_tree is None or node_tree in _visited:
        return
    _visited.add(node_tree)

    for node in node_tree.nodes:
        if node.type == 'GROUP':
            yield node
            if node.node_tree is not None:
                yield from _iter_group_nodes_recursive(node.node_tree, _visited)

def _is_hhp_hair_group_node(node):
    if node is None or node.type != 'GROUP':
        return False
    node_name = getattr(node, "name", "") or ""
    tree_name = getattr(getattr(node, "node_tree", None), "name", "") or ""
    return "(BS) Hair" in node_name or "(BS) Hair" in tree_name

def _is_hhp_nails_group_node(node):
    if node is None or node.type != 'GROUP':
        return False
    node_name = getattr(node, "name", "") or ""
    tree_name = getattr(getattr(node, "node_tree", None), "name", "") or ""
    needles = ("Unpolished nails", "Toenails (HHP)", "Fingernails (HHP)")
    return any(n in node_name for n in needles) or any(n in tree_name for n in needles)

def _set_group_input_default_recursive(
    node_tree,
    *,
    match_fn,
    socket_name,
    new_value,
    store_prop_key,
    debug_label=None,
):
    """
    Recursively find matching group nodes and set a given input socket default_value.
    Stores the original value on the node instance (only once) using store_prop_key.
    Returns how many node instances were changed.
    """
    changed = 0
    for node in _iter_group_nodes_recursive(node_tree):
        if not match_fn(node):
            continue
        sock = node.inputs.get(socket_name) if hasattr(node, "inputs") else None
        if sock is None or not hasattr(sock, "default_value"):
            continue
        if store_prop_key not in node:
            node[store_prop_key] = sock.default_value
        sock.default_value = new_value
        changed += 1
        if debug_label:
            print(f"{debug_label}: set '{node.name}' {socket_name} to {new_value}")
    return changed

def _restore_group_input_default_recursive(
    node_tree,
    *,
    match_fn,
    socket_name,
    store_prop_key,
    debug_label=None,
):
    """
    Recursively find matching group nodes and restore a given input socket default_value
    from store_prop_key, then remove the stored property.
    Returns how many node instances were restored.
    """
    restored = 0
    for node in _iter_group_nodes_recursive(node_tree):
        if not match_fn(node):
            continue
        if store_prop_key not in node:
            continue
        sock = node.inputs.get(socket_name) if hasattr(node, "inputs") else None
        if sock is None or not hasattr(sock, "default_value"):
            continue
        original = node[store_prop_key]
        sock.default_value = float(original)
        del node[store_prop_key]
        restored += 1
        if debug_label:
            print(f"{debug_label}: restored '{node.name}' {socket_name} to {original}")
    return restored

class SHADER_SSS_OT_use_cycles_v3(bpy.types.Operator):
    """Store original subsurface values (if not stored) and convert shaders for Cycles V4.0"""
    bl_idname = "shader_sss.use_cycles_v3"
    bl_label = "Use with Cycles V4.0"
    bl_description = (
        "This has the intended subsurface values for softer more realistic skin.\n"
        "Store original subsurface values (if not stored) and convert subsurface shaders for Cycles V4.0:\n"
        "• Sets custom object 'Subsurface' property to 0.035\n"
        "• Sets '(BS) Hair' node Subsurface input to 0\n"
        "• Switches SSS mode to RANDOM_WALK on all Principled BSDF nodes\n"
        "• Sets SSS radius to 0.44 for uniform light diffusion"
    )
    bl_options = {'REGISTER'}
    
    material_option: bpy.props.EnumProperty(
        name="Material Handling",
        items=[
            ('SWITCH', "Switch to original materials and convert", "Switch to original materials first, then apply shader conversion"),
            ('CONVERT_ANYWAY', "Convert them anyway", "Apply shader conversion to optimized materials")
        ],
        default='SWITCH'
    )

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection or selected objects",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes")
         ],
         default='COLLECTION'
    )

    def execute(self, context):
        objs = get_target_objects(context, self.target_mode)
        if not objs:
            self.report({'WARNING'}, "No 'Char (HHP)' collections found (or no selected objects belong to them).")
            return {'CANCELLED'}

        # Switch to Cycles and configure settings
        context.scene.render.engine = 'CYCLES'
        # Only increase transparent_max_bounces if it's currently less than 100
        if context.scene.cycles.transparent_max_bounces < 100:
            context.scene.cycles.transparent_max_bounces = 100
        # Set viewport to rendered mode
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].shading.type = 'RENDERED'
                break

        # Handle material switching if needed
        if self.material_option == 'SWITCH':
            # If any target mesh is on optimized materials, switch ALL target meshes back to DATA linking.
            if any(is_mesh_on_optimized_materials(obj) for obj in objs):
                for obj in objs:
                    if obj.type == 'MESH' and obj.material_slots:
                        for slot in obj.material_slots:
                            slot.link = 'DATA'

        for obj in objs:
            if obj.type == 'MESH':
                if "Subsurface" in obj:
                    # Store original value if not already stored
                    if "orig_subsurface" not in obj:
                        obj["orig_subsurface"] = obj["Subsurface"]
                    obj["Subsurface"] = 0.035
                    print(f"Converted object '{obj.name}' Subsurface property to 0.035")
                for slot in obj.material_slots:
                    mat = slot.material
                    if mat and mat.use_nodes and mat.node_tree:
                        set_principled_sss_mode(mat.node_tree, 'RANDOM_WALK')
                        # Process SSS radius values for character collection materials
                        process_sss_radius_in_node_tree(mat.node_tree)
                        clamp_hhp_mix_sss_mask_weight_in_node_tree(mat.node_tree)
                        _set_group_input_default_recursive(
                            mat.node_tree,
                            match_fn=_is_hhp_hair_group_node,
                            socket_name="Subsurface",
                            new_value=0,
                            store_prop_key="orig_subsurface",
                            debug_label=f"Converted '(BS) Hair' (recursive) [{mat.name}]",
                        )
                        _set_group_input_default_recursive(
                            mat.node_tree,
                            match_fn=_is_hhp_nails_group_node,
                            socket_name="Subsurface",
                            new_value=0,
                            store_prop_key="orig_subsurface_nails",
                            debug_label=f"Converted nails (recursive) [{mat.name}]",
                        )
        # Toggle edit mode to force a refresh (only for mesh objects).
        if context.active_object and context.active_object.type == 'MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, "Subsurface conversion for Cycles V4.0 applied.")
        return {'FINISHED'}

    def invoke(self, context, event):
        objs = get_target_objects(context, self.target_mode)
        if any(is_mesh_on_optimized_materials(obj) for obj in objs):
            return context.window_manager.invoke_props_dialog(self, width=450)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="One or more character meshes are on optimized materials not meant for conversion.")
        layout.separator()
        layout.prop(self, "material_option", expand=True)

class SHADER_SSS_OT_use_cycles_v3_sharper(bpy.types.Operator):
    """Store original subsurface values (if not stored) and convert shaders for Cycles V4.0 with sharper skin"""
    bl_idname = "shader_sss.use_cycles_v3_sharper"
    bl_label = "Use with Cycles V4.0 | Sharper Skin"
    bl_description = (
        "This has lower subsurface values for skin (skin details are more defined due to lower light diffusion).\n"
        "Store original subsurface values (if not stored) and convert subsurface shaders for Cycles V4.0:\n"
        "• Sets custom object 'Subsurface' property to 0.015\n"
        "• Sets '(BS) Hair' node Subsurface input to 0\n"
        "• Switches SSS mode to RANDOM_WALK on all Principled BSDF nodes\n"
        "• Sets SSS radius to 0.44 for uniform light diffusion"
    )
    bl_options = {'REGISTER'}
    
    material_option: bpy.props.EnumProperty(
        name="Material Handling",
        items=[
            ('SWITCH', "Switch to original materials and convert", "Switch to original materials first, then apply shader conversion"),
            ('CONVERT_ANYWAY', "Convert them anyway", "Apply shader conversion to optimized materials")
        ],
        default='SWITCH'
    )

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection or selected objects",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes")
         ],
         default='COLLECTION'
    )

    def execute(self, context):
        objs = get_target_objects(context, self.target_mode)
        if not objs:
            self.report({'WARNING'}, "No 'Char (HHP)' collections found (or no selected objects belong to them).")
            return {'CANCELLED'}

        # Switch to Cycles and configure settings
        context.scene.render.engine = 'CYCLES'
        # Only increase transparent_max_bounces if it's currently less than 100
        if context.scene.cycles.transparent_max_bounces < 100:
            context.scene.cycles.transparent_max_bounces = 100
        # Set viewport to rendered mode
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].shading.type = 'RENDERED'
                break

        # Handle material switching if needed
        if self.material_option == 'SWITCH':
            # If any target mesh is on optimized materials, switch ALL target meshes back to DATA linking.
            if any(is_mesh_on_optimized_materials(obj) for obj in objs):
                for obj in objs:
                    if obj.type == 'MESH' and obj.material_slots:
                        for slot in obj.material_slots:
                            slot.link = 'DATA'

        for obj in objs:
            if obj.type == 'MESH':
                if "Subsurface" in obj:
                    # Store original value if not already stored
                    if "orig_subsurface" not in obj:
                        obj["orig_subsurface"] = obj["Subsurface"]
                    obj["Subsurface"] = 0.015
                    print(f"Converted object '{obj.name}' Subsurface property to 0.015")
                for slot in obj.material_slots:
                    mat = slot.material
                    if mat and mat.use_nodes and mat.node_tree:
                        set_principled_sss_mode(mat.node_tree, 'RANDOM_WALK')
                        # Process SSS radius values for character collection materials
                        process_sss_radius_in_node_tree(mat.node_tree)
                        clamp_hhp_mix_sss_mask_weight_in_node_tree(mat.node_tree)
                        _set_group_input_default_recursive(
                            mat.node_tree,
                            match_fn=_is_hhp_hair_group_node,
                            socket_name="Subsurface",
                            new_value=0,
                            store_prop_key="orig_subsurface",
                            debug_label=f"Converted '(BS) Hair' (recursive) [{mat.name}]",
                        )
                        _set_group_input_default_recursive(
                            mat.node_tree,
                            match_fn=_is_hhp_nails_group_node,
                            socket_name="Subsurface",
                            new_value=0,
                            store_prop_key="orig_subsurface_nails",
                            debug_label=f"Converted nails (recursive) [{mat.name}]",
                        )
        # Toggle edit mode to force a refresh (only for mesh objects).
        if context.active_object and context.active_object.type == 'MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, "Subsurface conversion for Cycles V4.0 | Sharper Skin applied.")
        return {'FINISHED'}

    def invoke(self, context, event):
        objs = get_target_objects(context, self.target_mode)
        if any(is_mesh_on_optimized_materials(obj) for obj in objs):
            return context.window_manager.invoke_props_dialog(self, width=450)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="One or more character meshes are on optimized materials not meant for conversion.")
        layout.separator()
        layout.prop(self, "material_option", expand=True)

class SHADER_SSS_OT_switch_sss(bpy.types.Operator):
    """Switch the SSS mode for all Principled BSDF and Subsurface Scattering nodes to the selected mode and modify SSS properties."""
    bl_idname = "shader_sss.switch_sss"
    bl_label = "Just switch SSS mode"
    bl_options = {'REGISTER', 'UNDO'}

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection, selected objects, or entire blend file",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes"),
             ('ENTIRE_BLEND', "Entire Blend File", "Process every principled and subsurface node in the entire blend file")
         ],
         default='COLLECTION'
    )

    sss_mode: bpy.props.EnumProperty(
         name="SSS Mode",
         description="Select subsurface scattering mode",
         items=[
             ('BURLEY', "BURLEY", "Use BURLEY mode"),
             ('RANDOM_WALK', "RANDOM_WALK", "Use RANDOM_WALK mode"),
             ('RANDOM_WALK_SKIN', "RANDOM_WALK_SKIN", "Use RANDOM_WALK_SKIN mode")
         ],
         default='RANDOM_WALK'
    )

    sss_weight: bpy.props.FloatProperty(
        name="SSS Weight",
        description="Subsurface scattering weight/amount",
        default=1.00,
        min=0.0,
        max=1.0,
        step=10,
        precision=2
    )

    radius_x: bpy.props.FloatProperty(
        name="Radius X",
        description="Subsurface radius X component",
        default=0.44,
        min=0.0,
        max=10.0,
        step=1,
        precision=3
    )

    radius_y: bpy.props.FloatProperty(
        name="Radius Y", 
        description="Subsurface radius Y component",
        default=0.44,
        min=0.0,
        max=10.0,
        step=1,
        precision=3
    )

    radius_z: bpy.props.FloatProperty(
        name="Radius Z",
        description="Subsurface radius Z component", 
        default=0.44,
        min=0.0,
        max=10.0,
        step=1,
        precision=3
    )

    def execute(self, context):
        radius = (self.radius_x, self.radius_y, self.radius_z)
        
        if self.target_mode == 'ENTIRE_BLEND':
            # Process entire blend file
            process_entire_blend_file_sss(self.sss_mode, self.sss_weight, radius)
            self.report({'INFO'}, f"SSS properties applied to entire blend file: Mode={self.sss_mode}, Weight={self.sss_weight}, Radius={radius}")
        else:
            # Process selected objects or character collection
            objs = get_target_objects_from_selected_collection(context, self.target_mode)
            for obj in objs:
                if obj.type == 'MESH':
                    for slot in obj.material_slots:
                        mat = slot.material
                        if mat and mat.use_nodes and mat.node_tree:
                            set_sss_properties_in_node_tree(mat.node_tree, self.sss_mode, self.sss_weight, radius)
            
            # Toggle edit mode to force a refresh (only for mesh objects).
            if context.active_object and context.active_object.type == 'MESH':
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.object.mode_set(mode='OBJECT')
            
            target_desc = "character collection" if self.target_mode == 'COLLECTION' else "selected objects"
            self.report({'INFO'}, f"SSS properties applied to {target_desc}: Mode={self.sss_mode}, Weight={self.sss_weight}, Radius={radius}")
        
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=450)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Configure SSS properties:")
        
        # Target mode selection
        layout.prop(self, "target_mode")
        
        # SSS mode selection
        layout.prop(self, "sss_mode")
        
        # SSS weight slider
        layout.prop(self, "sss_weight")
        
        # Radius controls (vertically stacked)
        layout.label(text="SSS Radius:")
        col = layout.column(align=True)
        col.prop(self, "radius_x")
        col.prop(self, "radius_y") 
        col.prop(self, "radius_z")

class SHADER_SSS_OT_revert(bpy.types.Operator):
    """Revert subsurface conversion and restore original subsurface values"""
    bl_idname = "shader_sss.revert"
    bl_label = "Use with EEVEE (Restore Original)"
    bl_description = "Revert the subsurface conversion and restore original subsurface values when stored"
    bl_options = {'REGISTER'}

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection or selected objects",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes")
         ],
         default='COLLECTION'
    )

    material_option: bpy.props.EnumProperty(
        name="Material Handling",
        items=[
            ('SWITCH', "Switch to original materials and revert", "Switch to original materials first, then restore original shader values"),
            ('CONVERT_ANYWAY', "Revert anyway", "Restore original shader values without switching back from optimized materials")
        ],
        default='SWITCH'
    )

    def execute(self, context):
        objs = get_target_objects(context, self.target_mode)
        if not objs:
            self.report({'WARNING'}, "No 'Char (HHP)' collections found (or no selected objects belong to them).")
            return {'CANCELLED'}

        # Switch to EEVEE and configure settings (Blender 5 removed BLENDER_EEVEE_NEXT enum)
        eevee_engine = _set_render_engine_first_available(
            context.scene,
            ("BLENDER_EEVEE_NEXT", "BLENDER_EEVEE"),
        )
        if eevee_engine is None:
            self.report({'ERROR'}, "EEVEE render engine not available in this Blender build.")
            return {'CANCELLED'}
        # Set viewport to rendered mode
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].shading.type = 'RENDERED'
                break

        # If any target mesh is on optimized materials, optionally switch ALL target meshes back to DATA linking.
        if self.material_option == 'SWITCH':
            if any(is_mesh_on_optimized_materials(obj) for obj in objs):
                for obj in objs:
                    if obj.type == 'MESH' and obj.material_slots:
                        for slot in obj.material_slots:
                            slot.link = 'DATA'

        # Check if there are any stored values to revert
        has_stored_values = False
        for obj in objs:
            if obj.type == 'MESH' and "Subsurface" in obj:
                if "orig_subsurface" in obj:
                    has_stored_values = True
                    original = obj["orig_subsurface"]
                    obj["Subsurface"] = original
                    del obj["orig_subsurface"]
                    print(f"Reverted object '{obj.name}' Subsurface property to {original}")
            if obj.type == 'MESH' and getattr(obj, "material_slots", None):
                for slot in obj.material_slots:
                    mat = slot.material
                    if mat and mat.use_nodes and mat.node_tree:
                        # Revert SSS radius values
                        revert_sss_radius_in_node_tree(mat.node_tree)
                        if restore_hhp_mix_sss_mask_weight_in_node_tree(mat.node_tree):
                            has_stored_values = True
                        if _restore_group_input_default_recursive(
                            mat.node_tree,
                            match_fn=_is_hhp_hair_group_node,
                            socket_name="Subsurface",
                            store_prop_key="orig_subsurface",
                            debug_label=f"Reverted '(BS) Hair' (recursive) [{mat.name}]",
                        ):
                            has_stored_values = True
                        if _restore_group_input_default_recursive(
                            mat.node_tree,
                            match_fn=_is_hhp_nails_group_node,
                            socket_name="Subsurface",
                            store_prop_key="orig_subsurface_nails",
                            debug_label=f"Reverted nails (recursive) [{mat.name}]",
                        ):
                            has_stored_values = True
        # Toggle edit mode to force a refresh (only for mesh objects).
        if context.active_object and context.active_object.type == 'MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')
        if has_stored_values:
            self.report({'INFO'}, "Subsurface values reverted.")
        else:
            self.report({'INFO'}, "Already using EEVEE shaders.")
        return {'FINISHED'}

    def invoke(self, context, event):
        objs = get_target_objects(context, self.target_mode)
        if any(is_mesh_on_optimized_materials(obj) for obj in objs):
            return context.window_manager.invoke_props_dialog(self, width=450)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="One or more character meshes are on optimized materials.")
        layout.separator()
        layout.prop(self, "material_option", expand=True)

class SHADER_SSS_OT_use_eevee_v3(bpy.types.Operator):
    """Store original subsurface values (if not stored) and convert shaders for EEVEE (Alternate)"""
    bl_idname = "shader_sss.use_eevee_v3"
    bl_label = "Use with EEVEE (Alternate)"
    bl_description = (
        "This is an alternate look for EEVEE with less colored light scattering in the skin.\n"
        "Store original subsurface values (if not stored) and convert subsurface shaders for EEVEE:\n"
        "• Sets custom object 'Subsurface' property to 0.035\n"
        "• Restores '(BS) Hair' node Subsurface values to original\n"
        "• Switches to EEVEE render engine\n"
        "• Sets SSS radius to 0.44 for uniform light diffusion"
    )
    bl_options = {'REGISTER'}
    
    material_option: bpy.props.EnumProperty(
        name="Material Handling",
        items=[
            ('SWITCH', "Switch to original materials and convert", "Switch to original materials first, then apply shader conversion"),
            ('CONVERT_ANYWAY', "Convert them anyway", "Apply shader conversion to optimized materials")
        ],
        default='SWITCH'
    )

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection or selected objects",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes")
         ],
         default='COLLECTION'
    )

    def execute(self, context):
        objs = get_target_objects(context, self.target_mode)
        if not objs:
            self.report({'WARNING'}, "No 'Char (HHP)' collections found (or no selected objects belong to them).")
            return {'CANCELLED'}

        # Switch to EEVEE and configure settings
        eevee_engine = _set_render_engine_first_available(
            context.scene,
            ("BLENDER_EEVEE_NEXT", "BLENDER_EEVEE"),
        )
        if eevee_engine is None:
            self.report({'ERROR'}, "EEVEE render engine not available in this Blender build.")
            return {'CANCELLED'}
        # Set viewport to rendered mode
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].shading.type = 'RENDERED'
                break

        # Handle material switching if needed
        if self.material_option == 'SWITCH':
            # If any target mesh is on optimized materials, switch ALL target meshes back to DATA linking.
            if any(is_mesh_on_optimized_materials(obj) for obj in objs):
                for obj in objs:
                    if obj.type == 'MESH' and obj.material_slots:
                        for slot in obj.material_slots:
                            slot.link = 'DATA'

        for obj in objs:
            if obj.type == 'MESH':
                if "Subsurface" in obj:
                    # Store original value if not already stored
                    if "orig_subsurface" not in obj:
                        obj["orig_subsurface"] = obj["Subsurface"]
                    obj["Subsurface"] = 0.035
                    print(f"Converted object '{obj.name}' Subsurface property to 0.035")
                for slot in obj.material_slots:
                    mat = slot.material
                    if mat and mat.use_nodes and mat.node_tree:
                        # Process SSS radius values for character collection materials
                        process_sss_radius_in_node_tree(mat.node_tree)
                        restore_hhp_mix_sss_mask_weight_in_node_tree(mat.node_tree)
                        # Restore hair/nails subsurface values like EEVEE original does (recursive)
                        _restore_group_input_default_recursive(
                            mat.node_tree,
                            match_fn=_is_hhp_hair_group_node,
                            socket_name="Subsurface",
                            store_prop_key="orig_subsurface",
                            debug_label=f"Restored '(BS) Hair' (recursive) [{mat.name}]",
                        )
                        _restore_group_input_default_recursive(
                            mat.node_tree,
                            match_fn=_is_hhp_nails_group_node,
                            socket_name="Subsurface",
                            store_prop_key="orig_subsurface_nails",
                            debug_label=f"Restored nails (recursive) [{mat.name}]",
                        )
        # Toggle edit mode to force a refresh (only for mesh objects).
        if context.active_object and context.active_object.type == 'MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, "Subsurface conversion for EEVEE (Alternate) applied.")
        return {'FINISHED'}

    def invoke(self, context, event):
        objs = get_target_objects(context, self.target_mode)
        if any(is_mesh_on_optimized_materials(obj) for obj in objs):
            return context.window_manager.invoke_props_dialog(self, width=450)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="One or more character meshes are on optimized materials not meant for conversion.")
        layout.separator()
        layout.prop(self, "material_option", expand=True)

class SHADER_SSS_MT_convert_menu(bpy.types.Menu):
    """A submenu that groups the subsurface shader conversion operators."""
    bl_label = "Convert shaders"
    bl_idname = "SHADER_SSS_MT_convert_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("shader_sss.revert", text="EEVEE (Default)")
        layout.operator("shader_sss.use_eevee_v3", text="EEVEE (Alternate)")
        layout.operator("shader_sss.use_cycles_v3", text="Cycles V4")
        layout.operator("shader_sss.use_cycles_v3_sharper", text="Cycles V4 (Sharper Skin)")
        layout.separator()
        
        # Only show debug/developer options if debug mode is enabled
        prefs = context.preferences.addons[__name__.split('.')[0]].preferences
        if prefs.debug_mode:
            layout.operator("shader_sss.switch_sss", text="Just switch SSS mode")

class SHADER_SSS_MT_menu(bpy.types.Menu):
    """A menu that groups shader setup tools."""
    bl_label = "Shader setup"
    bl_idname = "SHADER_SSS_MT_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("hhp.setup_render_basics", text="Setup Render Basics", icon='SHADING_RENDERED')
        layout.menu("SHADER_SSS_MT_convert_menu", text="Convert shaders", icon='BLENDER')

# Registration
classes = (
    SHADER_SSS_OT_use_cycles_v3,
    SHADER_SSS_OT_use_cycles_v3_sharper,
    SHADER_SSS_OT_use_eevee_v3,
    SHADER_SSS_OT_switch_sss,
    SHADER_SSS_OT_revert,
    SHADER_SSS_MT_convert_menu,
    SHADER_SSS_MT_menu,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register() 