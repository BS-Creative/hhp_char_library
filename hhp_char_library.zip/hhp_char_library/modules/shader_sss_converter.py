import bpy

def get_target_objects(context, target_mode):
    """
    Return the list of target objects based on the selected target mode.
    If 'COLLECTION' is selected, look for the first collection
    whose name starts with "Char (HHP)" and return all its objects.
    Otherwise, return the currently selected objects.
    """
    if target_mode == 'COLLECTION':
        char_collection = None
        for col in context.scene.collection.children:
            if col.name.startswith("Char (HHP)"):
                char_collection = col
                break
        if char_collection:
            return char_collection.all_objects
        else:
            return context.selected_objects
    else:
        return context.selected_objects

def update_principled_nodes(node_tree):
    """
    Recursively update every Principled BSDF node in the provided node tree by
    setting its subsurface_method to 'BURLEY'. If the node is a group, process its node tree.
    """
    for node in node_tree.nodes:
        if node.type == 'BSDF_PRINCIPLED':
            node.subsurface_method = 'BURLEY'
            print(f"Updated {node.name} in node tree {node_tree.name}")
        if node.type == 'GROUP' and node.node_tree is not None:
            update_principled_nodes(node.node_tree)

def set_principled_sss_mode(node_tree, mode):
    """
    Recursively set the subsurface_method of all Principled BSDF nodes in the node_tree to the given mode.
    """
    for node in node_tree.nodes:
        if node.type == 'BSDF_PRINCIPLED':
            node.subsurface_method = mode
            print(f"Set {node.name} subsurface method to {mode} in node tree {node_tree.name}")
        if node.type == 'GROUP' and node.node_tree is not None:
            set_principled_sss_mode(node.node_tree, mode)

class SHADER_SSS_OT_use_cycles(bpy.types.Operator):
    """Store original subsurface values (if not stored) and convert shaders for Cycles"""
    bl_idname = "shader_sss.use_cycles"
    bl_label = "Use with Cycles"
    bl_description = (
        "Store original subsurface values (if not stored) and convert subsurface shaders for Cycles:\n"
        "• Sets custom object 'Subsurface' property to 0.035\n"
        "• Sets '(BS) Hair' node Subsurface input to 0\n"
        "• Switches SSS mode to BURLEY on all Principled BSDF nodes"
    )
    bl_options = {'REGISTER', 'UNDO'}

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection or selected objects",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes")
         ],
         default='COLLECTION'
    )

    def execute(self, context):
        # Switch to Cycles and configure settings
        context.scene.render.engine = 'CYCLES'
        # Only increase transparent_max_bounces if it's currently less than 25
        if context.scene.cycles.transparent_max_bounces < 25:
            context.scene.cycles.transparent_max_bounces = 25
        # Set viewport to rendered mode
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].shading.type = 'RENDERED'
                break

        objs = get_target_objects(context, self.target_mode)
        for obj in objs:
            if obj.type == 'MESH':
                if "Subsurface" in obj:
                    # Store original value if not already stored
                    if "orig_subsurface" not in obj:
                        obj["orig_subsurface"] = obj["Subsurface"]
                    obj["Subsurface"] = 0.035
                    print(f"Converted object '{obj.name}' Subsurface property to 0.035")
                for slot in obj.material_slots:
                    mat = slot.material
                    if mat and mat.use_nodes and mat.node_tree:
                        update_principled_nodes(mat.node_tree)
                        for node in mat.node_tree.nodes:
                            if node.type == 'GROUP' and (
                                "(BS) Hair" in node.name or 
                                (node.node_tree is not None and "(BS) Hair" in node.node_tree.name)
                            ):
                                if "Subsurface" in node.inputs:
                                    # Store the original node input value if not already stored
                                    if "orig_subsurface" not in node:
                                        node["orig_subsurface"] = node.inputs["Subsurface"].default_value
                                    node.inputs["Subsurface"].default_value = 0
                                    print(f"Converted '(BS) Hair' node '{node.name}' Subsurface value for material: {mat.name}")
        # Toggle edit mode to force a refresh (only for mesh objects).
        if context.active_object and context.active_object.type == 'MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, "Subsurface conversion for Cycles applied.")
        return {'FINISHED'}

    def invoke(self, context, event):
        active_obj = context.active_object
        if active_obj and active_obj.type == 'MESH' and active_obj.material_slots:
            if all(slot.link == 'OBJECT' for slot in active_obj.material_slots):
                return context.window_manager.invoke_props_dialog(self, width=400)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Model is using optimized materials meant for Eevee. Convert them anyway?")

class SHADER_SSS_OT_switch_sss(bpy.types.Operator):
    """Switch the SSS mode for all Principled BSDF nodes to the selected mode without modifying subsurface values."""
    bl_idname = "shader_sss.switch_sss"
    bl_label = "Just switch SSS mode"
    bl_options = {'REGISTER', 'UNDO'}

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection or selected objects",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes")
         ],
         default='COLLECTION'
    )

    sss_mode: bpy.props.EnumProperty(
         name="SSS Mode",
         description="Select subsurface scattering mode",
         items=[
             ('BURLEY', "BURLEY", "Use BURLEY mode"),
             ('RANDOM_WALK', "RANDOM_WALK", "Use RANDOM_WALK mode"),
             ('RANDOM_WALK_SKIN', "RANDOM_WALK_SKIN", "Use RANDOM_WALK_SKIN mode")
         ],
         default='BURLEY'
    )

    def execute(self, context):
        objs = get_target_objects(context, self.target_mode)
        for obj in objs:
            if obj.type == 'MESH':
                for slot in obj.material_slots:
                    mat = slot.material
                    if mat and mat.use_nodes and mat.node_tree:
                        set_principled_sss_mode(mat.node_tree, self.sss_mode)
        # Toggle edit mode to force a refresh (only for mesh objects).
        if context.active_object and context.active_object.type == 'MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, f"Subsurface SSS mode switched to {self.sss_mode}.")
        return {'FINISHED'}

class SHADER_SSS_OT_revert(bpy.types.Operator):
    """Revert subsurface conversion and restore original subsurface values"""
    bl_idname = "shader_sss.revert"
    bl_label = "Revert Subsurface Values"
    bl_description = "Revert the subsurface conversion and restore original subsurface values when stored"
    bl_options = {'REGISTER', 'UNDO'}

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection or selected objects",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes")
         ],
         default='COLLECTION'
    )

    def execute(self, context):
        # Switch to EEVEE Next and configure settings
        context.scene.render.engine = 'BLENDER_EEVEE_NEXT'
        # Set viewport to rendered mode
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].shading.type = 'RENDERED'
                break

        # Check if there are any stored values to revert
        has_stored_values = False
        objs = get_target_objects(context, self.target_mode)
        for obj in objs:
            if obj.type == 'MESH' and "Subsurface" in obj:
                if "orig_subsurface" in obj:
                    has_stored_values = True
                    original = obj["orig_subsurface"]
                    obj["Subsurface"] = original
                    del obj["orig_subsurface"]
                    print(f"Reverted object '{obj.name}' Subsurface property to {original}")
            for slot in obj.material_slots:
                mat = slot.material
                if mat and mat.use_nodes and mat.node_tree:
                    for node in mat.node_tree.nodes:
                        if node.type == 'GROUP' and (
                            "(BS) Hair" in node.name or 
                            (node.node_tree is not None and "(BS) Hair" in node.node_tree.name)
                        ):
                            if "Subsurface" in node.inputs and "orig_subsurface" in node:
                                has_stored_values = True
                                original = node["orig_subsurface"]
                                node.inputs["Subsurface"].default_value = original
                                del node["orig_subsurface"]
                                print(f"Reverted '(BS) Hair' node '{node.name}' Subsurface value for material: {mat.name}")
        # Toggle edit mode to force a refresh (only for mesh objects).
        if context.active_object and context.active_object.type == 'MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')
        if has_stored_values:
            self.report({'INFO'}, "Subsurface values reverted.")
        else:
            self.report({'INFO'}, "Already using EEVEE shaders.")
        return {'FINISHED'}

class SHADER_SSS_MT_menu(bpy.types.Menu):
    """A submenu that groups the subsurface shader conversion operators."""
    bl_label = "Convert subsurface shaders for"
    bl_idname = "SHADER_SSS_MT_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("shader_sss.revert", text="Use with EEVEE (Enabled by default)")
        layout.operator("shader_sss.use_cycles", text="Use with Cycles")
        layout.separator()
        layout.operator("shader_sss.switch_sss", text="Just switch SSS mode")

# Registration
classes = (
    SHADER_SSS_OT_use_cycles,
    SHADER_SSS_OT_switch_sss,
    SHADER_SSS_OT_revert,
    SHADER_SSS_MT_menu,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register() 