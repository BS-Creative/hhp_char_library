import bpy

def get_target_objects(context, target_mode):
    """
    Return the list of target objects based on the selected target mode.
    If 'COLLECTION' is selected, look for the first collection
    whose name starts with "Char (HHP)" and return all its objects.
    Otherwise, return the currently selected objects.
    """
    if target_mode == 'COLLECTION':
        char_collection = None
        for col in context.scene.collection.children:
            if col.name.startswith("Char (HHP)"):
                char_collection = col
                break
        if char_collection:
            return char_collection.all_objects
        else:
            return context.selected_objects
    else:
        return context.selected_objects

def get_target_objects_from_selected_collection(context, target_mode):
    """
    Return the list of target objects based on the selected target mode.
    If 'COLLECTION' is selected, find the collection that contains the selected object
    and return all objects from that collection and its subcollections.
    Otherwise, return the currently selected objects.
    """
    if target_mode == 'COLLECTION':
        if not context.selected_objects:
            return []
        
        selected_obj = context.selected_objects[0]
        
        # Find which collection contains the selected object
        def find_object_collection(obj, collection):
            if obj.name in collection.objects:
                return collection
            for child_col in collection.children:
                result = find_object_collection(obj, child_col)
                if result:
                    return result
            return None
        
        # Start searching from scene collection
        target_collection = find_object_collection(selected_obj, context.scene.collection)
        
        if target_collection:
            return target_collection.all_objects
        else:
            return context.selected_objects
    else:
        return context.selected_objects

def update_principled_nodes(node_tree):
    """
    Recursively update every Principled BSDF node in the provided node tree by
    setting its subsurface_method to 'BURLEY'. If the node is a group, process its node tree.
    """
    for node in node_tree.nodes:
        if node.type == 'BSDF_PRINCIPLED':
            node.subsurface_method = 'BURLEY'
            print(f"Updated {node.name} in node tree {node_tree.name}")
        if node.type == 'GROUP' and node.node_tree is not None:
            update_principled_nodes(node.node_tree)

def set_principled_sss_mode(node_tree, mode):
    """
    Recursively set the subsurface_method of all Principled BSDF nodes in the node_tree to the given mode.
    """
    for node in node_tree.nodes:
        if node.type == 'BSDF_PRINCIPLED':
            node.subsurface_method = mode
            print(f"Set {node.name} subsurface method to {mode} in node tree {node_tree.name}")
        if node.type == 'GROUP' and node.node_tree is not None:
            set_principled_sss_mode(node.node_tree, mode)

def set_sss_properties_in_node_tree(node_tree, mode, weight, radius):
    """
    Recursively set SSS properties for both Principled BSDF and Subsurface Scattering nodes.
    """
    # Map node types to their input socket names
    NODE_SSS_INPUTS = {
        'BSDF_PRINCIPLED': {
            'weight': 'Subsurface Weight',
            'radius': 'Subsurface Radius'
        },
        'SUBSURFACE_SCATTERING': {
            'weight': 'Scale',
            'radius': 'Radius'
        }
    }
    
    for node in node_tree.nodes:
        if node.type in NODE_SSS_INPUTS:
            inputs = NODE_SSS_INPUTS[node.type]
            
            # Set subsurface method for Principled BSDF
            if node.type == 'BSDF_PRINCIPLED':
                node.subsurface_method = mode
                print(f"Set {node.name} subsurface method to {mode} in node tree {node_tree.name}")
            
            # Set weight/scale
            if inputs['weight'] in node.inputs:
                weight_input = node.inputs[inputs['weight']]
                if hasattr(weight_input, 'default_value'):
                    weight_input.default_value = weight
                    print(f"Set {node.name} {inputs['weight']} to {weight} in node tree {node_tree.name}")
            
            # Set radius
            if inputs['radius'] in node.inputs:
                radius_input = node.inputs[inputs['radius']]
                if hasattr(radius_input, 'default_value'):
                    radius_input.default_value = radius
                    print(f"Set {node.name} {inputs['radius']} to {radius} in node tree {node_tree.name}")
        
        # Recurse into group nodes
        if node.type == 'GROUP' and node.node_tree is not None:
            set_sss_properties_in_node_tree(node.node_tree, mode, weight, radius)

def process_entire_blend_file_sss(mode, weight, radius):
    """
    Process every material, world, and node group in the blend file for SSS properties.
    """
    # Process all materials
    for mat in bpy.data.materials:
        if mat.use_nodes and mat.node_tree:
            set_sss_properties_in_node_tree(mat.node_tree, mode, weight, radius)
    
    # Process all worlds
    for world in bpy.data.worlds:
        if world.use_nodes and world.node_tree:
            set_sss_properties_in_node_tree(world.node_tree, mode, weight, radius)
    
    # Process all node groups
    for ng in bpy.data.node_groups:
        set_sss_properties_in_node_tree(ng, mode, weight, radius)

def process_sss_radius_in_node_tree(node_tree):
    """
    Process SSS radius values in a node tree for Principled BSDF and Subsurface Scattering nodes.
    If the X,Y,Z values of the radius are not within 0.03 of each other, change them all to 0.44.
    Store original values for restoration.
    """
    THRESHOLD = 0.03
    NEW_RADIUS = (0.44, 0.44, 0.44)
    
    # Map node types to the name of their SSS radius input socket
    NODE_SSS = {
        'BSDF_PRINCIPLED': 'Subsurface Radius',
        'SUBSURFACE_SCATTERING': 'Radius',
    }
    
    for node in node_tree.nodes:
        # Only care about Principled BSDF and SSS nodes
        input_name = NODE_SSS.get(node.type)
        if not input_name:
            # Recurse into group nodes
            if node.type == 'GROUP' and node.node_tree is not None:
                process_sss_radius_in_node_tree(node.node_tree)
            continue
            
        sock = node.inputs.get(input_name)
        if not sock or not hasattr(sock, "default_value"):
            continue
            
        # Ensure it's a 3-component vector
        try:
            vals = sock.default_value
            comps = [vals[i] for i in range(3)]
        except Exception:
            continue
            
        # Check if spread > threshold
        if max(comps) - min(comps) > THRESHOLD:
            # Store original value if not already stored
            original_key = f"orig_sss_radius_{input_name.replace(' ', '_').lower()}"
            if original_key not in node:
                node[original_key] = tuple(vals[:3])
                
            sock.default_value = NEW_RADIUS
            print(f"→ {node_tree.name}: set '{node.name}' {input_name} to {NEW_RADIUS}")

def revert_sss_radius_in_node_tree(node_tree):
    """
    Revert SSS radius values in a node tree back to their original values.
    """
    NODE_SSS = {
        'BSDF_PRINCIPLED': 'Subsurface Radius',
        'SUBSURFACE_SCATTERING': 'Radius',
    }
    
    for node in node_tree.nodes:
        # Only care about Principled BSDF and SSS nodes
        input_name = NODE_SSS.get(node.type)
        if not input_name:
            # Recurse into group nodes
            if node.type == 'GROUP' and node.node_tree is not None:
                revert_sss_radius_in_node_tree(node.node_tree)
            continue
            
        sock = node.inputs.get(input_name)
        if not sock or not hasattr(sock, "default_value"):
            continue
            
        # Check if we have stored original value
        original_key = f"orig_sss_radius_{input_name.replace(' ', '_').lower()}"
        if original_key in node:
            original_value = node[original_key]
            sock.default_value = original_value
            del node[original_key]
            print(f"→ {node_tree.name}: reverted '{node.name}' {input_name} to {original_value}")

class SHADER_SSS_OT_use_cycles(bpy.types.Operator):
    """Store original subsurface values (if not stored) and convert shaders for Cycles"""
    bl_idname = "shader_sss.use_cycles"
    bl_label = "Use with Cycles (Old / Deprecated)"
    bl_description = (
        "Store original subsurface values (if not stored) and convert subsurface shaders for Cycles:\n"
        "• Sets custom object 'Subsurface' property to 0.035\n"
        "• Sets '(BS) Hair' node Subsurface input to 0\n"
        "• Switches SSS mode to BURLEY on all Principled BSDF nodes"
    )
    bl_options = {'REGISTER'}
    
    material_option: bpy.props.EnumProperty(
        name="Material Handling",
        items=[
            ('SWITCH', "Switch to original materials and convert", "Switch to original materials first, then apply shader conversion"),
            ('CONVERT_ANYWAY', "Convert them anyway", "Apply shader conversion to optimized materials")
        ],
        default='SWITCH'
    )

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection or selected objects",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes")
         ],
         default='COLLECTION'
    )

    def execute(self, context):
        # Switch to Cycles and configure settings
        context.scene.render.engine = 'CYCLES'
        # Only increase transparent_max_bounces if it's currently less than 50
        if context.scene.cycles.transparent_max_bounces < 50:
            context.scene.cycles.transparent_max_bounces = 50
        # Set viewport to rendered mode
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].shading.type = 'RENDERED'
                break

        # Handle material switching if needed
        if self.material_option == 'SWITCH':
            selected_objects = context.selected_objects
            if selected_objects and any(obj.type == 'MESH' for obj in selected_objects):
                # Check if materials are linked by OBJECT (optimized)
                materials_linked_by_object = any(
                    obj.type == 'MESH' and obj.material_slots and
                    all(slot.link == 'OBJECT' for slot in obj.material_slots)
                    for obj in selected_objects
                )
                if materials_linked_by_object:
                    # Switch to DATA linking (original materials)
                    for obj in selected_objects:
                        if obj.material_slots:
                            for slot in obj.material_slots:
                                slot.link = 'DATA'

        objs = get_target_objects(context, self.target_mode)
        for obj in objs:
            if obj.type == 'MESH':
                if "Subsurface" in obj:
                    # Store original value if not already stored
                    if "orig_subsurface" not in obj:
                        obj["orig_subsurface"] = obj["Subsurface"]
                    obj["Subsurface"] = 0.035
                    print(f"Converted object '{obj.name}' Subsurface property to 0.035")
                for slot in obj.material_slots:
                    mat = slot.material
                    if mat and mat.use_nodes and mat.node_tree:
                        update_principled_nodes(mat.node_tree)
                        for node in mat.node_tree.nodes:
                            if node.type == 'GROUP' and (
                                "(BS) Hair" in node.name or 
                                (node.node_tree is not None and "(BS) Hair" in node.node_tree.name)
                            ):
                                if "Subsurface" in node.inputs:
                                    # Store the original node input value if not already stored
                                    if "orig_subsurface" not in node:
                                        node["orig_subsurface"] = node.inputs["Subsurface"].default_value
                                    node.inputs["Subsurface"].default_value = 0
                                    print(f"Converted '(BS) Hair' node '{node.name}' Subsurface value for material: {mat.name}")
        # Toggle edit mode to force a refresh (only for mesh objects).
        if context.active_object and context.active_object.type == 'MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, "Subsurface conversion for Cycles applied.")
        return {'FINISHED'}

    def invoke(self, context, event):
        active_obj = context.active_object
        if active_obj and active_obj.type == 'MESH' and active_obj.material_slots:
            if all(slot.link == 'OBJECT' for slot in active_obj.material_slots):
                return context.window_manager.invoke_props_dialog(self, width=450)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Model is on optimized materials not meant for conversion.")
        layout.separator()
        layout.prop(self, "material_option", expand=True)

class SHADER_SSS_OT_use_cycles_v3(bpy.types.Operator):
    """Store original subsurface values (if not stored) and convert shaders for Cycles V3.0"""
    bl_idname = "shader_sss.use_cycles_v3"
    bl_label = "Use with Cycles V3.0"
    bl_description = (
        "This has the intended subsurface values for softer more realistic skin.\n"
        "Store original subsurface values (if not stored) and convert subsurface shaders for Cycles V3.0:\n"
        "• Sets custom object 'Subsurface' property to 0.035\n"
        "• Sets '(BS) Hair' node Subsurface input to 0\n"
        "• Switches SSS mode to RANDOM_WALK on all Principled BSDF nodes\n"
        "• Sets SSS radius to 0.44 for uniform light diffusion"
    )
    bl_options = {'REGISTER'}
    
    material_option: bpy.props.EnumProperty(
        name="Material Handling",
        items=[
            ('SWITCH', "Switch to original materials and convert", "Switch to original materials first, then apply shader conversion"),
            ('CONVERT_ANYWAY', "Convert them anyway", "Apply shader conversion to optimized materials")
        ],
        default='SWITCH'
    )

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection or selected objects",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes")
         ],
         default='COLLECTION'
    )

    def execute(self, context):
        # Switch to Cycles and configure settings
        context.scene.render.engine = 'CYCLES'
        # Only increase transparent_max_bounces if it's currently less than 100
        if context.scene.cycles.transparent_max_bounces < 100:
            context.scene.cycles.transparent_max_bounces = 100
        # Set viewport to rendered mode
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].shading.type = 'RENDERED'
                break

        # Handle material switching if needed
        if self.material_option == 'SWITCH':
            selected_objects = context.selected_objects
            if selected_objects and any(obj.type == 'MESH' for obj in selected_objects):
                # Check if materials are linked by OBJECT (optimized)
                materials_linked_by_object = any(
                    obj.type == 'MESH' and obj.material_slots and
                    all(slot.link == 'OBJECT' for slot in obj.material_slots)
                    for obj in selected_objects
                )
                if materials_linked_by_object:
                    # Switch to DATA linking (original materials)
                    for obj in selected_objects:
                        if obj.material_slots:
                            for slot in obj.material_slots:
                                slot.link = 'DATA'

        objs = get_target_objects(context, self.target_mode)
        for obj in objs:
            if obj.type == 'MESH':
                if "Subsurface" in obj:
                    # Store original value if not already stored
                    if "orig_subsurface" not in obj:
                        obj["orig_subsurface"] = obj["Subsurface"]
                    obj["Subsurface"] = 0.035
                    print(f"Converted object '{obj.name}' Subsurface property to 0.035")
                for slot in obj.material_slots:
                    mat = slot.material
                    if mat and mat.use_nodes and mat.node_tree:
                        set_principled_sss_mode(mat.node_tree, 'RANDOM_WALK')
                        # Process SSS radius values for character collection materials
                        process_sss_radius_in_node_tree(mat.node_tree)
                        for node in mat.node_tree.nodes:
                            if node.type == 'GROUP' and (
                                "(BS) Hair" in node.name or 
                                (node.node_tree is not None and "(BS) Hair" in node.node_tree.name)
                            ):
                                if "Subsurface" in node.inputs:
                                    # Store the original node input value if not already stored
                                    if "orig_subsurface" not in node:
                                        node["orig_subsurface"] = node.inputs["Subsurface"].default_value
                                    node.inputs["Subsurface"].default_value = 0
                                    print(f"Converted '(BS) Hair' node '{node.name}' Subsurface value for material: {mat.name}")
                            # Process nail nodes
                            elif node.type == 'GROUP' and (
                                "Unpolished nails" in node.name or
                                "Toenails (HHP)" in node.name or
                                "Fingernails (HHP)" in node.name or
                                (node.node_tree is not None and (
                                    "Unpolished nails" in node.node_tree.name or
                                    "Toenails (HHP)" in node.node_tree.name or
                                    "Fingernails (HHP)" in node.node_tree.name
                                ))
                            ):
                                if "Subsurface" in node.inputs:
                                    # Store the original node input value if not already stored
                                    if "orig_subsurface_nails" not in node:
                                        node["orig_subsurface_nails"] = node.inputs["Subsurface"].default_value
                                    node.inputs["Subsurface"].default_value = 0
                                    print(f"Converted nail node '{node.name}' Subsurface value for material: {mat.name}")
        # Toggle edit mode to force a refresh (only for mesh objects).
        if context.active_object and context.active_object.type == 'MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, "Subsurface conversion for Cycles V3.0 applied.")
        return {'FINISHED'}

    def invoke(self, context, event):
        active_obj = context.active_object
        if active_obj and active_obj.type == 'MESH' and active_obj.material_slots:
            if all(slot.link == 'OBJECT' for slot in active_obj.material_slots):
                return context.window_manager.invoke_props_dialog(self, width=450)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Model is on optimized materials not meant for conversion.")
        layout.separator()
        layout.prop(self, "material_option", expand=True)

class SHADER_SSS_OT_use_cycles_v3_sharper(bpy.types.Operator):
    """Store original subsurface values (if not stored) and convert shaders for Cycles V3.0 with sharper skin"""
    bl_idname = "shader_sss.use_cycles_v3_sharper"
    bl_label = "Use with Cycles V3.0 | Sharper Skin"
    bl_description = (
        "This has lower subsurface values for skin (skin details are more defined due to lower light diffusion).\n"
        "Store original subsurface values (if not stored) and convert subsurface shaders for Cycles V3.0:\n"
        "• Sets custom object 'Subsurface' property to 0.015\n"
        "• Sets '(BS) Hair' node Subsurface input to 0\n"
        "• Switches SSS mode to RANDOM_WALK on all Principled BSDF nodes\n"
        "• Sets SSS radius to 0.44 for uniform light diffusion"
    )
    bl_options = {'REGISTER'}
    
    material_option: bpy.props.EnumProperty(
        name="Material Handling",
        items=[
            ('SWITCH', "Switch to original materials and convert", "Switch to original materials first, then apply shader conversion"),
            ('CONVERT_ANYWAY', "Convert them anyway", "Apply shader conversion to optimized materials")
        ],
        default='SWITCH'
    )

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection or selected objects",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes")
         ],
         default='COLLECTION'
    )

    def execute(self, context):
        # Switch to Cycles and configure settings
        context.scene.render.engine = 'CYCLES'
        # Only increase transparent_max_bounces if it's currently less than 100
        if context.scene.cycles.transparent_max_bounces < 100:
            context.scene.cycles.transparent_max_bounces = 100
        # Set viewport to rendered mode
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].shading.type = 'RENDERED'
                break

        # Handle material switching if needed
        if self.material_option == 'SWITCH':
            selected_objects = context.selected_objects
            if selected_objects and any(obj.type == 'MESH' for obj in selected_objects):
                # Check if materials are linked by OBJECT (optimized)
                materials_linked_by_object = any(
                    obj.type == 'MESH' and obj.material_slots and
                    all(slot.link == 'OBJECT' for slot in obj.material_slots)
                    for obj in selected_objects
                )
                if materials_linked_by_object:
                    # Switch to DATA linking (original materials)
                    for obj in selected_objects:
                        if obj.material_slots:
                            for slot in obj.material_slots:
                                slot.link = 'DATA'

        objs = get_target_objects(context, self.target_mode)
        for obj in objs:
            if obj.type == 'MESH':
                if "Subsurface" in obj:
                    # Store original value if not already stored
                    if "orig_subsurface" not in obj:
                        obj["orig_subsurface"] = obj["Subsurface"]
                    obj["Subsurface"] = 0.015
                    print(f"Converted object '{obj.name}' Subsurface property to 0.015")
                for slot in obj.material_slots:
                    mat = slot.material
                    if mat and mat.use_nodes and mat.node_tree:
                        set_principled_sss_mode(mat.node_tree, 'RANDOM_WALK')
                        # Process SSS radius values for character collection materials
                        process_sss_radius_in_node_tree(mat.node_tree)
                        for node in mat.node_tree.nodes:
                            if node.type == 'GROUP' and (
                                "(BS) Hair" in node.name or 
                                (node.node_tree is not None and "(BS) Hair" in node.node_tree.name)
                            ):
                                if "Subsurface" in node.inputs:
                                    # Store the original node input value if not already stored
                                    if "orig_subsurface" not in node:
                                        node["orig_subsurface"] = node.inputs["Subsurface"].default_value
                                    node.inputs["Subsurface"].default_value = 0
                                    print(f"Converted '(BS) Hair' node '{node.name}' Subsurface value for material: {mat.name}")
                            # Process nail nodes
                            elif node.type == 'GROUP' and (
                                "Unpolished nails" in node.name or
                                "Toenails (HHP)" in node.name or
                                "Fingernails (HHP)" in node.name or
                                (node.node_tree is not None and (
                                    "Unpolished nails" in node.node_tree.name or
                                    "Toenails (HHP)" in node.node_tree.name or
                                    "Fingernails (HHP)" in node.node_tree.name
                                ))
                            ):
                                if "Subsurface" in node.inputs:
                                    # Store the original node input value if not already stored
                                    if "orig_subsurface_nails" not in node:
                                        node["orig_subsurface_nails"] = node.inputs["Subsurface"].default_value
                                    node.inputs["Subsurface"].default_value = 0
                                    print(f"Converted nail node '{node.name}' Subsurface value for material: {mat.name}")
        # Toggle edit mode to force a refresh (only for mesh objects).
        if context.active_object and context.active_object.type == 'MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, "Subsurface conversion for Cycles V3.0 | Sharper Skin applied.")
        return {'FINISHED'}

    def invoke(self, context, event):
        active_obj = context.active_object
        if active_obj and active_obj.type == 'MESH' and active_obj.material_slots:
            if all(slot.link == 'OBJECT' for slot in active_obj.material_slots):
                return context.window_manager.invoke_props_dialog(self, width=450)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Model is on optimized materials not meant for conversion.")
        layout.separator()
        layout.prop(self, "material_option", expand=True)

class SHADER_SSS_OT_switch_sss(bpy.types.Operator):
    """Switch the SSS mode for all Principled BSDF and Subsurface Scattering nodes to the selected mode and modify SSS properties."""
    bl_idname = "shader_sss.switch_sss"
    bl_label = "Just switch SSS mode"
    bl_options = {'REGISTER', 'UNDO'}

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection, selected objects, or entire blend file",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes"),
             ('ENTIRE_BLEND', "Entire Blend File", "Process every principled and subsurface node in the entire blend file")
         ],
         default='COLLECTION'
    )

    sss_mode: bpy.props.EnumProperty(
         name="SSS Mode",
         description="Select subsurface scattering mode",
         items=[
             ('BURLEY', "BURLEY", "Use BURLEY mode"),
             ('RANDOM_WALK', "RANDOM_WALK", "Use RANDOM_WALK mode"),
             ('RANDOM_WALK_SKIN', "RANDOM_WALK_SKIN", "Use RANDOM_WALK_SKIN mode")
         ],
         default='RANDOM_WALK'
    )

    sss_weight: bpy.props.FloatProperty(
        name="SSS Weight",
        description="Subsurface scattering weight/amount",
        default=1.00,
        min=0.0,
        max=1.0,
        step=10,
        precision=2
    )

    radius_x: bpy.props.FloatProperty(
        name="Radius X",
        description="Subsurface radius X component",
        default=0.44,
        min=0.0,
        max=10.0,
        step=1,
        precision=3
    )

    radius_y: bpy.props.FloatProperty(
        name="Radius Y", 
        description="Subsurface radius Y component",
        default=0.44,
        min=0.0,
        max=10.0,
        step=1,
        precision=3
    )

    radius_z: bpy.props.FloatProperty(
        name="Radius Z",
        description="Subsurface radius Z component", 
        default=0.44,
        min=0.0,
        max=10.0,
        step=1,
        precision=3
    )

    def execute(self, context):
        radius = (self.radius_x, self.radius_y, self.radius_z)
        
        if self.target_mode == 'ENTIRE_BLEND':
            # Process entire blend file
            process_entire_blend_file_sss(self.sss_mode, self.sss_weight, radius)
            self.report({'INFO'}, f"SSS properties applied to entire blend file: Mode={self.sss_mode}, Weight={self.sss_weight}, Radius={radius}")
        else:
            # Process selected objects or character collection
            objs = get_target_objects_from_selected_collection(context, self.target_mode)
            for obj in objs:
                if obj.type == 'MESH':
                    for slot in obj.material_slots:
                        mat = slot.material
                        if mat and mat.use_nodes and mat.node_tree:
                            set_sss_properties_in_node_tree(mat.node_tree, self.sss_mode, self.sss_weight, radius)
            
            # Toggle edit mode to force a refresh (only for mesh objects).
            if context.active_object and context.active_object.type == 'MESH':
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.object.mode_set(mode='OBJECT')
            
            target_desc = "character collection" if self.target_mode == 'COLLECTION' else "selected objects"
            self.report({'INFO'}, f"SSS properties applied to {target_desc}: Mode={self.sss_mode}, Weight={self.sss_weight}, Radius={radius}")
        
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=450)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Configure SSS properties:")
        
        # Target mode selection
        layout.prop(self, "target_mode")
        
        # SSS mode selection
        layout.prop(self, "sss_mode")
        
        # SSS weight slider
        layout.prop(self, "sss_weight")
        
        # Radius controls (vertically stacked)
        layout.label(text="SSS Radius:")
        col = layout.column(align=True)
        col.prop(self, "radius_x")
        col.prop(self, "radius_y") 
        col.prop(self, "radius_z")

class SHADER_SSS_OT_revert(bpy.types.Operator):
    """Revert subsurface conversion and restore original subsurface values"""
    bl_idname = "shader_sss.revert"
    bl_label = "Use with EEVEE (Restore Original)"
    bl_description = "Revert the subsurface conversion and restore original subsurface values when stored"
    bl_options = {'REGISTER'}

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection or selected objects",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes")
         ],
         default='COLLECTION'
    )

    def execute(self, context):
        # Switch to EEVEE Next and configure settings
        context.scene.render.engine = 'BLENDER_EEVEE_NEXT'
        # Set viewport to rendered mode
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].shading.type = 'RENDERED'
                break

        # Check if there are any stored values to revert
        has_stored_values = False
        objs = get_target_objects(context, self.target_mode)
        for obj in objs:
            if obj.type == 'MESH' and "Subsurface" in obj:
                if "orig_subsurface" in obj:
                    has_stored_values = True
                    original = obj["orig_subsurface"]
                    obj["Subsurface"] = original
                    del obj["orig_subsurface"]
                    print(f"Reverted object '{obj.name}' Subsurface property to {original}")
            for slot in obj.material_slots:
                mat = slot.material
                if mat and mat.use_nodes and mat.node_tree:
                    # Revert SSS radius values
                    revert_sss_radius_in_node_tree(mat.node_tree)
                    for node in mat.node_tree.nodes:
                        if node.type == 'GROUP' and (
                            "(BS) Hair" in node.name or 
                            (node.node_tree is not None and "(BS) Hair" in node.node_tree.name)
                        ):
                            if "Subsurface" in node.inputs and "orig_subsurface" in node:
                                has_stored_values = True
                                original = node["orig_subsurface"]
                                node.inputs["Subsurface"].default_value = original
                                del node["orig_subsurface"]
                                print(f"Reverted '(BS) Hair' node '{node.name}' Subsurface value for material: {mat.name}")
                        # Revert nail nodes
                        elif node.type == 'GROUP' and (
                            "Unpolished nails" in node.name or
                            "Toenails (HHP)" in node.name or
                            "Fingernails (HHP)" in node.name or
                            (node.node_tree is not None and (
                                "Unpolished nails" in node.node_tree.name or
                                "Toenails (HHP)" in node.node_tree.name or
                                "Fingernails (HHP)" in node.node_tree.name
                            ))
                        ):
                            if "Subsurface" in node.inputs and "orig_subsurface_nails" in node:
                                has_stored_values = True
                                original = node["orig_subsurface_nails"]
                                node.inputs["Subsurface"].default_value = original
                                del node["orig_subsurface_nails"]
                                print(f"Reverted nail node '{node.name}' Subsurface value for material: {mat.name}")
        # Toggle edit mode to force a refresh (only for mesh objects).
        if context.active_object and context.active_object.type == 'MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')
        if has_stored_values:
            self.report({'INFO'}, "Subsurface values reverted.")
        else:
            self.report({'INFO'}, "Already using EEVEE shaders.")
        return {'FINISHED'}

class SHADER_SSS_OT_use_eevee_v3(bpy.types.Operator):
    """Store original subsurface values (if not stored) and convert shaders for EEVEE (Alternate)"""
    bl_idname = "shader_sss.use_eevee_v3"
    bl_label = "Use with EEVEE (Alternate)"
    bl_description = (
        "This is an alternate look for EEVEE with less colored light scattering in the skin.\n"
        "Store original subsurface values (if not stored) and convert subsurface shaders for EEVEE:\n"
        "• Sets custom object 'Subsurface' property to 0.035\n"
        "• Restores '(BS) Hair' node Subsurface values to original\n"
        "• Switches to EEVEE render engine\n"
        "• Sets SSS radius to 0.44 for uniform light diffusion"
    )
    bl_options = {'REGISTER'}
    
    material_option: bpy.props.EnumProperty(
        name="Material Handling",
        items=[
            ('SWITCH', "Switch to original materials and convert", "Switch to original materials first, then apply shader conversion"),
            ('CONVERT_ANYWAY', "Convert them anyway", "Apply shader conversion to optimized materials")
        ],
        default='SWITCH'
    )

    target_mode: bpy.props.EnumProperty(
         name="Target Objects",
         description="Process character collection or selected objects",
         items=[
             ('COLLECTION', "Character Collection", "Process every mesh in the character collection"),
             ('SELECTED', "Selected Objects", "Process only the selected meshes")
         ],
         default='COLLECTION'
    )

    def execute(self, context):
        # Switch to EEVEE and configure settings
        context.scene.render.engine = 'BLENDER_EEVEE_NEXT'
        # Set viewport to rendered mode
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].shading.type = 'RENDERED'
                break

        # Handle material switching if needed
        if self.material_option == 'SWITCH':
            selected_objects = context.selected_objects
            if selected_objects and any(obj.type == 'MESH' for obj in selected_objects):
                # Check if materials are linked by OBJECT (optimized)
                materials_linked_by_object = any(
                    obj.type == 'MESH' and obj.material_slots and
                    all(slot.link == 'OBJECT' for slot in obj.material_slots)
                    for obj in selected_objects
                )
                if materials_linked_by_object:
                    # Switch to DATA linking (original materials)
                    for obj in selected_objects:
                        if obj.material_slots:
                            for slot in obj.material_slots:
                                slot.link = 'DATA'

        objs = get_target_objects(context, self.target_mode)
        for obj in objs:
            if obj.type == 'MESH':
                if "Subsurface" in obj:
                    # Store original value if not already stored
                    if "orig_subsurface" not in obj:
                        obj["orig_subsurface"] = obj["Subsurface"]
                    obj["Subsurface"] = 0.035
                    print(f"Converted object '{obj.name}' Subsurface property to 0.035")
                for slot in obj.material_slots:
                    mat = slot.material
                    if mat and mat.use_nodes and mat.node_tree:
                        # Process SSS radius values for character collection materials
                        process_sss_radius_in_node_tree(mat.node_tree)
                        # Restore hair subsurface values like EEVEE original does
                        for node in mat.node_tree.nodes:
                            if node.type == 'GROUP' and (
                                "(BS) Hair" in node.name or 
                                (node.node_tree is not None and "(BS) Hair" in node.node_tree.name)
                            ):
                                if "Subsurface" in node.inputs and "orig_subsurface" in node:
                                    original = node["orig_subsurface"]
                                    node.inputs["Subsurface"].default_value = original
                                    del node["orig_subsurface"]
                                    print(f"Restored '(BS) Hair' node '{node.name}' Subsurface value for material: {mat.name}")
                            # Restore nail subsurface values like EEVEE original does
                            elif node.type == 'GROUP' and (
                                "Unpolished nails" in node.name or
                                "Toenails (HHP)" in node.name or
                                "Fingernails (HHP)" in node.name or
                                (node.node_tree is not None and (
                                    "Unpolished nails" in node.node_tree.name or
                                    "Toenails (HHP)" in node.node_tree.name or
                                    "Fingernails (HHP)" in node.node_tree.name
                                ))
                            ):
                                if "Subsurface" in node.inputs and "orig_subsurface_nails" in node:
                                    original = node["orig_subsurface_nails"]
                                    node.inputs["Subsurface"].default_value = original
                                    del node["orig_subsurface_nails"]
                                    print(f"Restored nail node '{node.name}' Subsurface value for material: {mat.name}")
        # Toggle edit mode to force a refresh (only for mesh objects).
        if context.active_object and context.active_object.type == 'MESH':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, "Subsurface conversion for EEVEE (Alternate) applied.")
        return {'FINISHED'}

    def invoke(self, context, event):
        active_obj = context.active_object
        if active_obj and active_obj.type == 'MESH' and active_obj.material_slots:
            if all(slot.link == 'OBJECT' for slot in active_obj.material_slots):
                return context.window_manager.invoke_props_dialog(self, width=450)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Model is on optimized materials not meant for conversion.")
        layout.separator()
        layout.prop(self, "material_option", expand=True)

class SHADER_SSS_MT_convert_menu(bpy.types.Menu):
    """A submenu that groups the subsurface shader conversion operators."""
    bl_label = "Convert shaders"
    bl_idname = "SHADER_SSS_MT_convert_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("shader_sss.revert", text="EEVEE (Default)")
        layout.operator("shader_sss.use_eevee_v3", text="EEVEE (Alternate)")
        layout.operator("shader_sss.use_cycles_v3", text="Cycles V3")
        layout.operator("shader_sss.use_cycles_v3_sharper", text="Cycles V3 (Sharper Skin)")
        layout.separator()
        
        # Only show debug/developer options if debug mode is enabled
        prefs = context.preferences.addons[__name__.split('.')[0]].preferences
        if prefs.debug_mode:
            layout.operator("shader_sss.switch_sss", text="Just switch SSS mode")
        
        layout.operator("shader_sss.use_cycles", text="Cycles V1 (Old / Deprecated)")

class SHADER_SSS_MT_menu(bpy.types.Menu):
    """A menu that groups shader setup tools."""
    bl_label = "Shader setup"
    bl_idname = "SHADER_SSS_MT_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("hhp.setup_render_basics", text="Setup Render Basics", icon='SHADING_RENDERED')
        layout.menu("SHADER_SSS_MT_convert_menu", text="Convert shaders", icon='BLENDER')

# Registration
classes = (
    SHADER_SSS_OT_use_cycles,
    SHADER_SSS_OT_use_cycles_v3,
    SHADER_SSS_OT_use_cycles_v3_sharper,
    SHADER_SSS_OT_use_eevee_v3,
    SHADER_SSS_OT_switch_sss,
    SHADER_SSS_OT_revert,
    SHADER_SSS_MT_convert_menu,
    SHADER_SSS_MT_menu,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register() 