import bpy


def apply_corrective_modifier(context, repeat, rest_source, replace_existing=True):
    obj = context.object
    if obj is None:
        raise ValueError("No active object found. Please select an HHP character mesh.")
    if obj.type != 'MESH':
        raise ValueError("The active object must be a mesh to apply the corrective smooth modifier.")

    scene = context.scene
    view_layer = context.view_layer

    def _is_mask_modifier(mod) -> bool:
        return (
            (mod.type == 'MASK') or
            # Keep compatibility with our naming convention, even if type changes later.
            mod.name.startswith("(HHP) Mask - ")
        )

    original_active = view_layer.objects.active
    if original_active != obj:
        view_layer.objects.active = obj
    if not obj.select_get():
        obj.select_set(True)

    previous_mode = obj.mode
    if previous_mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    warning_message = None

    # If any Subdivision Surface modifier is above any Mask modifier, move ALL Subdivision Surface
    # modifiers to the bottom of the stack (preserving their order). This prevents vertex-count
    # changes before mask evaluation.
    mods_snapshot = list(obj.modifiers)
    mask_indices = [i for i, m in enumerate(mods_snapshot) if _is_mask_modifier(m)]
    if mask_indices:
        first_mask_index = min(mask_indices)
        has_subsurf_before_mask = any(
            (m.type == 'SUBSURF') and (i < first_mask_index)
            for i, m in enumerate(mods_snapshot)
        )
        if has_subsurf_before_mask:
            subsurf_mods = [m for m in obj.modifiers if m.type == 'SUBSURF']
            for m in subsurf_mods:
                current_idx = obj.modifiers.find(m.name)
                if current_idx != -1:
                    obj.modifiers.move(current_idx, len(obj.modifiers) - 1)

            warning_message = (
                "Subdivision Surface modifier(s) found above Mask modifier(s). "
                "They were moved to the bottom of the modifier stack to avoid vertex-count changes."
            )

    if replace_existing:
        # Remove ALL existing mouth correctives:
        # Any Corrective Smooth modifier that contains "HHP Mouth Corrective" in its name,
        # including enumerated ones like "HHP Mouth Corrective.001".
        to_remove = [
            mod for mod in obj.modifiers
            if mod.type == 'CORRECTIVE_SMOOTH' and "HHP Mouth Corrective" in mod.name
        ]
        for mod in to_remove:
            obj.modifiers.remove(mod)

    modifier = obj.modifiers.new(name="HHP Mouth Corrective", type='CORRECTIVE_SMOOTH')

    modifier.factor = 0.5
    modifier.iterations = repeat
    modifier.scale = 1.0
    modifier.smooth_type = 'SIMPLE'
    modifier.use_only_smooth = False
    modifier.use_pin_boundary = False
    modifier.rest_source = rest_source

    vertex_group = None
    for candidate in ("Auto HHP - Mouth", "SK_Protect mouth (INV)"):
        if obj.vertex_groups.get(candidate):
            vertex_group = candidate
            break
    modifier.vertex_group = vertex_group or ""

    # --- Modifier stack ordering ---
    # IMPORTANT:
    # Mask modifiers can change the evaluated vertex count.
    # This mouth corrective must be placed *before* any Mask modifiers to avoid index/count mismatches.
    #
    # Ordering rules:
    # - If any Mask modifiers exist: move mouth corrective above the *first* one (lowest index)
    #   so it is before *all* masks.
    # - Else fallback to previous behavior: place it right before the last Subdivision modifier.
    mask_indices = [i for i, m in enumerate(obj.modifiers) if _is_mask_modifier(m)]
    subsurf_indices = [i for i, m in enumerate(obj.modifiers) if m.type == 'SUBSURF']

    target_index = None
    if mask_indices:
        target_index = min(mask_indices)
    elif subsurf_indices:
        target_index = subsurf_indices[-1]

    if target_index is not None:
        current_index = obj.modifiers.find(modifier.name)
        if current_index != -1 and current_index > target_index:
            obj.modifiers.move(current_index, target_index)

    if rest_source == 'BIND':
        current_frame = scene.frame_current
        start_frame = scene.frame_start
        scene.frame_set(start_frame)
        try:
            with context.temp_override(
                object=obj,
                active_object=obj,
                selected_objects=[obj],
                selected_editable_objects=[obj],
                view_layer=view_layer,
            ):
                result = bpy.ops.object.correctivesmooth_bind(modifier=modifier.name)
                if result != {'FINISHED'}:
                    raise RuntimeError("Failed to bind the corrective smooth modifier.")
        finally:
            scene.frame_set(current_frame)

    if previous_mode != 'OBJECT':
        try:
            bpy.ops.object.mode_set(mode=previous_mode)
        except RuntimeError:
            pass

    if original_active and original_active != obj:
        view_layer.objects.active = original_active

    return warning_message