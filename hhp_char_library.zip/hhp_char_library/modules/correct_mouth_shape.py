import bpy


def apply_corrective_modifier(context, repeat, rest_source):
    obj = context.object
    if obj is None:
        raise ValueError("No active object found. Please select an HHP character mesh.")
    if obj.type != 'MESH':
        raise ValueError("The active object must be a mesh to apply the corrective smooth modifier.")

    scene = context.scene
    view_layer = context.view_layer

    original_active = view_layer.objects.active
    if original_active != obj:
        view_layer.objects.active = obj
    if not obj.select_get():
        obj.select_set(True)

    previous_mode = obj.mode
    if previous_mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    modifier = obj.modifiers.new(name="HHP Mouth Corrective", type='CORRECTIVE_SMOOTH')

    modifier.factor = 0.5
    modifier.iterations = repeat
    modifier.scale = 1.0
    modifier.smooth_type = 'SIMPLE'
    modifier.use_only_smooth = False
    modifier.use_pin_boundary = False
    modifier.rest_source = rest_source

    vertex_group = None
    for candidate in ("Auto HHP - Mouth", "SK_Protect mouth (INV)"):
        if obj.vertex_groups.get(candidate):
            vertex_group = candidate
            break
    modifier.vertex_group = vertex_group or ""

    subsurf_indices = [index for index, mod in enumerate(obj.modifiers) if mod.type == 'SUBSURF']
    if subsurf_indices:
        target_index = subsurf_indices[-1]
        current_index = obj.modifiers.find(modifier.name)
        if current_index != -1 and current_index > target_index:
            obj.modifiers.move(current_index, target_index)

    if rest_source == 'BIND':
        current_frame = scene.frame_current
        start_frame = scene.frame_start
        scene.frame_set(start_frame)
        try:
            with context.temp_override(
                object=obj,
                active_object=obj,
                selected_objects=[obj],
                selected_editable_objects=[obj],
                view_layer=view_layer,
            ):
                result = bpy.ops.object.correctivesmooth_bind(modifier=modifier.name)
                if result != {'FINISHED'}:
                    raise RuntimeError("Failed to bind the corrective smooth modifier.")
        finally:
            scene.frame_set(current_frame)

    if previous_mode != 'OBJECT':
        try:
            bpy.ops.object.mode_set(mode=previous_mode)
        except RuntimeError:
            pass

    if original_active and original_active != obj:
        view_layer.objects.active = original_active

