import bpy


MOUTH_CORRECTIVE_KEY = "HHP Mouth Corrective"
MISC_DATA_PROP = "HHP_misc_data"
CORRECTIVE_BIND_FRAMES_PROP = "shape_corrective_binding_frames"


def get_linked_meshes(active_obj, scene):
    if active_obj is None or active_obj.type != 'MESH':
        return []

    linked_meshes = [
        linked_obj for linked_obj in scene.objects
        if linked_obj.type == 'MESH' and linked_obj.data == active_obj.data and linked_obj != active_obj
    ]
    return [active_obj] + linked_meshes


def get_mouth_corrective_names(obj):
    if obj is None or obj.type != 'MESH':
        return []

    names = [
        mod.name for mod in obj.modifiers
        if mod.type == 'CORRECTIVE_SMOOTH' and MOUTH_CORRECTIVE_KEY in mod.name
    ]
    return names


def get_mouth_corrective_slider_names(obj):
    if obj is None or obj.type != 'MESH':
        return []

    modifier_names = set(get_mouth_corrective_names(obj))
    slider_names = [
        name for name in modifier_names
        if name in obj.keys() and isinstance(obj[name], (int, float))
    ]
    slider_names.sort()
    return slider_names


def delete_corrective_modifier(context, modifier_name):
    obj = context.object
    if obj is None or obj.type != 'MESH':
        raise ValueError("The active object must be a mesh to delete a mouth corrective.")
    if not modifier_name:
        raise ValueError("No mouth corrective was selected for deletion.")

    target_meshes = get_linked_meshes(obj, context.scene)
    removed_any = False
    for target_obj in target_meshes:
        modifier = target_obj.modifiers.get(modifier_name)
        if modifier and modifier.type == 'CORRECTIVE_SMOOTH' and MOUTH_CORRECTIVE_KEY in modifier.name:
            target_obj.modifiers.remove(modifier)
            removed_any = True

    if modifier_name in obj.keys():
        del obj[modifier_name]
    _remove_binding_frame(obj, modifier_name)

    if not removed_any:
        raise ValueError(f"Mouth corrective '{modifier_name}' was not found on the active mesh.")


def _store_binding_frame(obj, modifier_name, frame):
    if MISC_DATA_PROP not in obj:
        obj[MISC_DATA_PROP] = {}
    misc_data = obj[MISC_DATA_PROP]
    if not hasattr(misc_data, "keys"):
        raise ValueError(f"'{MISC_DATA_PROP}' must be a property group to store mouth corrective bind data.")
    if CORRECTIVE_BIND_FRAMES_PROP not in misc_data:
        misc_data[CORRECTIVE_BIND_FRAMES_PROP] = {}
    bind_frames = misc_data[CORRECTIVE_BIND_FRAMES_PROP]
    bind_frames[modifier_name] = int(frame)


def _remove_binding_frame(obj, modifier_name):
    misc_data = obj.get(MISC_DATA_PROP)
    if not hasattr(misc_data, "get"):
        return

    bind_frames = misc_data.get(CORRECTIVE_BIND_FRAMES_PROP)
    if hasattr(bind_frames, "__delitem__") and modifier_name in bind_frames:
        del bind_frames[modifier_name]


def apply_corrective_modifier(context, repeat, rest_source, replace_existing=True):
    obj = context.object
    if obj is None:
        raise ValueError("No active object found. Please select an HHP character mesh.")
    if obj.type != 'MESH':
        raise ValueError("The active object must be a mesh to apply the corrective smooth modifier.")

    scene = context.scene
    view_layer = context.view_layer
    modifier_rest_source = 'BIND' if rest_source == 'BIND_CURRENT' else rest_source

    def _is_mask_modifier(mod) -> bool:
        return (
            (mod.type == 'MASK') or
            # Keep compatibility with our naming convention, even if type changes later.
            mod.name.startswith("(HHP) Mask - ")
        )

    original_active = view_layer.objects.active
    if original_active != obj:
        view_layer.objects.active = obj
    if not obj.select_get():
        obj.select_set(True)

    previous_mode = obj.mode
    if previous_mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    warning_message = None

    linked_meshes = [
        linked_obj for linked_obj in scene.objects
        if linked_obj.type == 'MESH' and linked_obj.data == obj.data and linked_obj != obj
    ]
    target_meshes = [obj] + linked_meshes

    def _move_subsurf_below_masks(target_obj) -> bool:
        # If any Subdivision Surface modifier is above any Mask modifier, move ALL Subdivision Surface
        # modifiers to the bottom of the stack (preserving their order). This prevents vertex-count
        # changes before mask evaluation.
        mods_snapshot = list(target_obj.modifiers)
        mask_indices = [i for i, m in enumerate(mods_snapshot) if _is_mask_modifier(m)]
        if not mask_indices:
            return False

        first_mask_index = min(mask_indices)
        has_subsurf_before_mask = any(
            (m.type == 'SUBSURF') and (i < first_mask_index)
            for i, m in enumerate(mods_snapshot)
        )
        if not has_subsurf_before_mask:
            return False

        subsurf_mods = [m for m in target_obj.modifiers if m.type == 'SUBSURF']
        for m in subsurf_mods:
            current_idx = target_obj.modifiers.find(m.name)
            if current_idx != -1:
                target_obj.modifiers.move(current_idx, len(target_obj.modifiers) - 1)
        return True

    def _remove_existing_mouth_correctives(target_obj):
        # Remove ALL existing mouth correctives:
        # Any Corrective Smooth modifier that contains "HHP Mouth Corrective" in its name,
        # including enumerated ones like "HHP Mouth Corrective.001".
        to_remove = [
            mod for mod in target_obj.modifiers
            if mod.type == 'CORRECTIVE_SMOOTH' and MOUTH_CORRECTIVE_KEY in mod.name
        ]
        for mod in to_remove:
            target_obj.modifiers.remove(mod)

    def _set_modifier_stack_order(target_obj, modifier):
        # --- Modifier stack ordering ---
        # IMPORTANT:
        # Mask modifiers can change the evaluated vertex count.
        # This mouth corrective must be placed *before* any Mask modifiers to avoid index/count mismatches.
        #
        # Ordering rules:
        # - If any Mask modifiers exist: move mouth corrective above the *first* one (lowest index)
        #   so it is before *all* masks.
        # - Else fallback to previous behavior: place it right before the last Subdivision modifier.
        mask_indices = [i for i, m in enumerate(target_obj.modifiers) if _is_mask_modifier(m)]
        subsurf_indices = [i for i, m in enumerate(target_obj.modifiers) if m.type == 'SUBSURF']

        target_index = None
        if mask_indices:
            target_index = min(mask_indices)
        elif subsurf_indices:
            target_index = subsurf_indices[-1]

        if target_index is not None:
            current_index = target_obj.modifiers.find(modifier.name)
            if current_index != -1 and current_index > target_index:
                target_obj.modifiers.move(current_index, target_index)

    def _drive_modifier_factor(modifier, driver_obj, driver_prop_name):
        try:
            modifier.driver_remove("factor")
        except TypeError:
            pass

        factor_driver = modifier.driver_add("factor").driver
        factor_driver.type = 'SCRIPTED'
        while factor_driver.variables:
            factor_driver.variables.remove(factor_driver.variables[0])
        factor_var = factor_driver.variables.new()
        factor_var.name = "factor_value"
        factor_target = factor_var.targets[0]
        factor_target.id = driver_obj
        factor_target.data_path = f'["{driver_prop_name}"]'
        factor_driver.expression = factor_var.name

    def _add_corrective_modifier(target_obj):
        modifier = target_obj.modifiers.new(name=MOUTH_CORRECTIVE_KEY, type='CORRECTIVE_SMOOTH')

        modifier.factor = 0.5
        modifier.iterations = repeat
        modifier.scale = 1.0
        modifier.smooth_type = 'SIMPLE'
        modifier.use_only_smooth = False
        modifier.use_pin_boundary = False
        modifier.rest_source = modifier_rest_source

        vertex_group = None
        for candidate in ("Auto HHP - Mouth", "SK_Protect mouth (INV)"):
            if target_obj.vertex_groups.get(candidate):
                vertex_group = candidate
                break
        modifier.vertex_group = vertex_group or ""

        _set_modifier_stack_order(target_obj, modifier)
        return modifier

    def _bind_modifier_if_needed(target_obj, modifier):
        if modifier_rest_source != 'BIND':
            return

        current_frame = scene.frame_current
        bind_frame = current_frame if rest_source == 'BIND_CURRENT' else scene.frame_start
        scene.frame_set(bind_frame)
        try:
            with context.temp_override(
                object=target_obj,
                active_object=target_obj,
                selected_objects=[target_obj],
                selected_editable_objects=[target_obj],
                view_layer=view_layer,
            ):
                result = bpy.ops.object.correctivesmooth_bind(modifier=modifier.name)
                if result != {'FINISHED'}:
                    raise RuntimeError("Failed to bind the corrective smooth modifier.")
        finally:
            scene.frame_set(current_frame)

    def _prepare_bind_visibility(target_objects):
        collection_states = {}
        layer_collection_states = {}
        object_visibility_states = {}

        def _get_all_child_collections(collection):
            child_cols = []
            for child in collection.children:
                child_cols.append(child)
                child_cols.extend(_get_all_child_collections(child))
            return child_cols

        def _get_all_parent_collections(collection):
            parent_cols = []
            for parent in bpy.data.collections:
                if collection.name in parent.children.keys():
                    parent_cols.append(parent)
                    parent_cols.extend(_get_all_parent_collections(parent))
            return parent_cols

        def _find_layer_collections_for_collection(layer_collection, collection):
            matches = []
            if layer_collection.collection == collection:
                matches.append(layer_collection)
            for child in layer_collection.children:
                matches.extend(_find_layer_collections_for_collection(child, collection))
            return matches

        def _enable_layer_collection_tree(collection):
            layer_collections = _find_layer_collections_for_collection(
                view_layer.layer_collection,
                collection,
            )

            def _enable_recursive(layer_coll):
                lc_id = id(layer_coll)
                if lc_id not in layer_collection_states:
                    layer_collection_states[lc_id] = (layer_coll, layer_coll.exclude)
                layer_coll.exclude = False
                for child_lc in layer_coll.children:
                    _enable_recursive(child_lc)

            for layer_coll in layer_collections:
                _enable_recursive(layer_coll)

        for target_obj in target_objects:
            if target_obj.name not in object_visibility_states:
                was_hidden = target_obj.hide_get() if hasattr(target_obj, "hide_get") else False
                object_visibility_states[target_obj.name] = (target_obj.hide_viewport, was_hidden)
                if hasattr(target_obj, "hide_set"):
                    target_obj.hide_set(False)
                target_obj.hide_viewport = False

            for col in target_obj.users_collection:
                related_collections = [col]
                related_collections.extend(_get_all_parent_collections(col))
                related_collections.extend(_get_all_child_collections(col))

                for related_col in related_collections:
                    if related_col.name not in collection_states:
                        collection_states[related_col.name] = related_col.hide_viewport
                        related_col.hide_viewport = False
                        _enable_layer_collection_tree(related_col)

        return object_visibility_states, collection_states, layer_collection_states

    def _restore_bind_visibility(object_visibility_states, collection_states, layer_collection_states):
        for obj_name, (hide_viewport, was_hidden) in object_visibility_states.items():
            bind_obj = bpy.data.objects.get(obj_name)
            if bind_obj:
                bind_obj.hide_viewport = hide_viewport
                if hasattr(bind_obj, "hide_set"):
                    bind_obj.hide_set(was_hidden)

        for col_name, hide_viewport in collection_states.items():
            col = bpy.data.collections.get(col_name)
            if col:
                col.hide_viewport = hide_viewport

        for _, (layer_coll, exclude_state) in layer_collection_states.items():
            layer_coll.exclude = exclude_state

    moved_subsurf_any = False
    for target_obj in target_meshes:
        if _move_subsurf_below_masks(target_obj):
            moved_subsurf_any = True

    if moved_subsurf_any:
        warning_message = (
            "Subdivision Surface modifier(s) found above Mask modifier(s). "
            "They were moved to the bottom of the modifier stack to avoid vertex-count changes."
        )

    if replace_existing:
        for target_obj in target_meshes:
            _remove_existing_mouth_correctives(target_obj)

    active_modifier = _add_corrective_modifier(obj)
    prop_name = active_modifier.name
    obj[prop_name] = 0.5
    obj.id_properties_ui(prop_name).update(
        default=0.5,
        min=0.0,
        max=1.0,
        soft_min=0.0,
        soft_max=1.0,
        description="Controls the strength of the mouth corrective modifier.",
    )
    _drive_modifier_factor(active_modifier, obj, prop_name)

    linked_modifiers = []
    for linked_obj in linked_meshes:
        linked_modifier = _add_corrective_modifier(linked_obj)
        _drive_modifier_factor(linked_modifier, obj, prop_name)
        linked_modifiers.append((linked_obj, linked_modifier))

    if modifier_rest_source == 'BIND':
        bind_frame = scene.frame_current if rest_source == 'BIND_CURRENT' else scene.frame_start
        bind_targets = [obj] + [linked_obj for linked_obj, _ in linked_modifiers]
        object_visibility_states, collection_states, layer_collection_states = _prepare_bind_visibility(bind_targets)
        try:
            _bind_modifier_if_needed(obj, active_modifier)
            for linked_obj, linked_modifier in linked_modifiers:
                _bind_modifier_if_needed(linked_obj, linked_modifier)
            _store_binding_frame(obj, prop_name, bind_frame)
        finally:
            _restore_bind_visibility(object_visibility_states, collection_states, layer_collection_states)
    else:
        _remove_binding_frame(obj, prop_name)

    if previous_mode != 'OBJECT':
        try:
            bpy.ops.object.mode_set(mode=previous_mode)
        except RuntimeError:
            pass

    if original_active and original_active != obj:
        view_layer.objects.active = original_active

    return warning_message