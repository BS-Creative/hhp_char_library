"""Source-only shape-name conversion shared by character transfer tools."""
from pathlib import Path
from .animation_transfer_support import TransferError

_HEADERS = {'Phonemes', 'Expressions', 'Morphs (Body)', 'Morphs (Facial)',
            'Shapers (Main)', 'Shapers (Build a Bod)', 'Feet', 'Custom Correctives',
            'Morphs (Facial RIG)', 'Morphs (iPhone Mocap)', 'Left Eye', 'Right Eye',
            'Mouth and Jaw', 'Eyebrows, Cheeks, and Nose', 'Morphs (Genitals)',
            'Multi_Expression_Mesh', 'Correctives (HHP)', 'Tongue'}
_PREFIXES = ('Expression - ', 'Preset - ', 'Head - ', 'Torso - ', 'Arm - ',
             'Hand - ', 'Leg - ', 'Feet - ', 'Genitals - ', 'Proportion - ',
             'Utility - ', 'Fix - ', 'Char - ', 'Head preset -', 'Mouth preset -')


def _is_categorized(name):
    return (name.startswith(_PREFIXES) or name.casefold().startswith(('head preset -', 'mouth preset -'))
            or name == 'Torso | Chest - Nipples Pinch Base')


def _isolate_actions(keys):
    animation = keys.animation_data
    if animation is None:
        return
    owners = [animation]
    owners.extend(strip for track in animation.nla_tracks for strip in track.strips)
    copies = {}
    for owner in owners:
        action = getattr(owner, 'action', None)
        if action is None or (action.users <= 1 and action not in copies):
            continue
        slot = getattr(owner, 'action_slot', None)
        identifier = slot.identifier if slot else None
        if action not in copies:
            copies[action] = action.copy()
        owner.action = copies[action]
        if identifier:
            for copied_slot in owner.action.slots:
                if copied_slot.identifier == identifier:
                    owner.action_slot = copied_slot
                    break


def load_mapping():
    directory = Path(__file__).resolve().parents[1] / 'remapping'
    try:
        old = (directory / 'HHP4 old SK names.txt').read_text(encoding='utf8').splitlines()
        new = (directory / 'HHP4 New SK names.txt').read_text(encoding='utf8').splitlines()
    except OSError as error:
        raise TransferError(f'Cannot read the shape-key naming reference: {error}') from error
    if len(old) != len(new):
        raise TransferError('The shape-key naming reference has mismatched line counts')
    pairs = [(a.strip(), b.strip()) for a, b in zip(old, new)
             if a.strip() and b.strip() and a.strip() not in _HEADERS
             and not a.strip().startswith(('Shapekeys:', 'Object:'))]
    return {a: b for a, b in pairs if a != b}, {b for _, b in pairs}


def prepare_source_shape_keys(meshes):
    """Convert source names and saved presets without selecting other objects."""
    mapping, valid = load_mapping()
    meshes = list(dict.fromkeys(obj for obj in meshes if obj is not None and obj.type == 'MESH'))
    if any(not obj.is_editable or not obj.data.is_editable for obj in meshes):
        raise TransferError('The source mesh must be editable to update its shape keys')
    total = 0
    for obj in meshes:
        keys = obj.data.shape_keys
        if keys is None:
            continue
        # Keep independent characters with linked geometry out of this conversion.
        # Conversion of proxies in the same character is intentional.
        import bpy
        def character_root(mesh):
            pending, seen = list(mesh.users_collection), set()
            while pending:
                coll = pending.pop()
                if coll in seen:
                    continue
                seen.add(coll)
                if coll.name.startswith(('Char (HHP)', 'Char HHP', 'Char (F)')):
                    return coll
                pending.extend(c for c in bpy.data.collections if coll.name in c.children)
            return None
        root = character_root(obj)
        owners = [other for other in bpy.data.objects if getattr(other, 'data', None) == obj.data]
        local = [other for other in owners if other == obj or (root and character_root(other) == root)]
        if any(other not in local for other in owners):
            copied = obj.data.copy()
            for other in local:
                other.data = copied
            keys = copied.shape_keys
        reserved = set(keys.key_blocks.keys())
        planned = []
        for key in keys.key_blocks:
            old = key.name
            new = ('Char -' + old[7:] if old.startswith('Torso -') and old not in valid
                   else mapping.get(old, old))
            if new == old or new in reserved:
                continue
            planned.append((key, old, new))
            reserved.add(new)
        if planned:
            _isolate_actions(keys)
        renames = {}
        for key, old, new in planned:
            key.name = new
            renames[old] = key.name
            reserved.add(key.name)
            total += 1
        if not renames:
            continue
        for owner in local:
            for preset in owner.get('presets', {}).values():
                if 'shapekeys' not in preset:
                    continue
                values = {renames.get(name, name): value for name, value in preset['shapekeys'].items()}
                for key in keys.key_blocks:
                    if _is_categorized(key.name) and len(key.name.encode('utf8')) <= 63:
                        values.setdefault(key.name, key.value)
                preset['shapekeys'] = values
    return total
