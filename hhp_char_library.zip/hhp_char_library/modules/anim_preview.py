import bpy

def create_base_layer_action():
    """
    1) Store current bone selection
    2) Switch to Pose Mode
    3) Create "Preview_BaseLayer" Action, assign it, select all bones
    4) Clear transforms
    5) Keyframe at start & end frames
    6) Push action to NLA with REPLACE blend
    7) Restore bone selection
    """
    armature = bpy.context.object
    if not armature or armature.type != 'ARMATURE':
        print("No valid armature selected.")
        return

    selected_bones = [bone.name for bone in armature.data.bones if bone.select]

    # Switch to Pose mode if needed
    if armature.mode != 'POSE':
        bpy.ops.object.mode_set(mode='POSE')

    # Create a new action and assign it
    new_action = bpy.data.actions.new("Preview_Base layer")
    armature.animation_data_create()
    armature.animation_data.action = new_action

    # Select all bones, clear transforms, and set keyframes at start & end
    bpy.ops.pose.select_all(action='SELECT')
    bpy.ops.pose.transforms_clear()

    start_frame = bpy.context.scene.frame_start
    end_frame = bpy.context.scene.frame_end

    bpy.context.scene.frame_set(start_frame)
    bpy.ops.anim.keyframe_insert(type='LocRotScale')
    bpy.context.scene.frame_set(end_frame)
    bpy.ops.anim.keyframe_insert(type='LocRotScale')

    # Push Action to NLA
    armature.animation_data.action = None
    nla_track = armature.animation_data.nla_tracks.new()
    nla_track.name = "Preview_BaseLayer"
    nla_strip = nla_track.strips.new("Preview_BaseLayer", start_frame, new_action)
    nla_strip.blend_type = 'REPLACE'
    nla_strip.frame_start = start_frame
    nla_strip.frame_end = end_frame

    # Restore selection
    bpy.ops.pose.select_all(action='DESELECT')
    for bone in armature.data.bones:
        bone.select = (bone.name in selected_bones)


class HHP_OT_CreateBaseLayer(bpy.types.Operator):
    """Creates a new preview base layer and pushes it to the NLA. Useful for previewing add blend mode actions if armature has no NLA strips assigned"""
    bl_idname = "hhp.create_base_layer"
    bl_label = "Create Base layer"
    bl_description = "Creates a new preview base layer and pushes it to the NLA. Useful for previewing add blend mode actions if armature has no NLA strips assigned"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        """
        This operator is only valid if:
          1. An Armature is active, AND
          2. No NLA strip name contains 'Preview_BaseLayer' on the active Armature.
        """
        ob = context.active_object
        if not ob or ob.type != 'ARMATURE':
            return False

        # Check if there's already a strip whose name contains "Preview_BaseLayer"
        if ob.animation_data:
            for track in ob.animation_data.nla_tracks:
                for strip in track.strips:
                    if "Preview_BaseLayer" in strip.name:
                        return False
        return True

    def invoke(self, context, event):
        """Show a confirmation dialog to avoid accidental clicks."""
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        # Create the base layer action
        create_base_layer_action()

        # After creating the base layer, set the blending mode to REPLACE
        ob = context.active_object
        if ob and ob.type == 'ARMATURE' and ob.animation_data:
            ob.animation_data.action_blend_type = 'REPLACE'

        # Also clear the selected action in the anim preview properties on the active armature (not on the scene)
        ob.hhp_anim_preview_props.action = None

        self.report({'INFO'}, "Preview_BaseLayer created and pushed to NLA.")
        return {'FINISHED'}


def update_action(self, context):
    """
    When a new Action is selected or cleared in the dropdown:
      - If an Action is selected, force Pose Position on the Armature
        and assign that Action as active.
      - If cleared (None), clear the pose and do not force Pose Position.
    """
    ob = context.active_object
    if not ob or ob.type != 'ARMATURE':
        return

    # If the user selected a valid Action, force Pose Position
    if self.action:
        ob.data.pose_position = 'POSE'
        ob.animation_data_create()
        ob.animation_data.action = self.action
    else:
        # Clear pose when action is cleared
        for bone in ob.pose.bones:
            bone.location = (0, 0, 0)
            bone.rotation_quaternion = (1, 0, 0, 0)
            bone.rotation_euler = (0, 0, 0)
            bone.rotation_axis_angle = (0, 0, 1, 0)
            bone.scale = (1, 1, 1)
        
        ob.animation_data_create()
        ob.animation_data.action = None
        
        # Update the view
        bpy.context.view_layer.update()


# New update function to update FK/IK constraint influence based on the slider value
def update_fkik_switch(self, context):
    # Determine desired influence from mode: "IK" -> 1.0, "FK" -> 0.0.
    desired_influence = 1.0 if self.fkik_mode == "IK" else 0.0
    mapping = {
        "lShin": ["IK"],
        "lFoot": ["Copy Rotation"],
        "lForearmBend": ["IK"],
        "lHand": ["Copy Rotation"],
        "rShin": ["IK"],
        "rFoot": ["Copy Rotation"],
        "rForearmBend": ["IK"],
        "rHand": ["Copy Rotation"],
        "lForearmTwist": ["Copy Rotation", "Damped Track"],
        "rForearmTwist": ["Copy Rotation", "Damped Track"]
    }
    for obj in context.selected_objects:
        if obj.type == 'ARMATURE':
            for bone_name, constraint_names in mapping.items():
                if bone_name in obj.pose.bones:
                    pbone = obj.pose.bones[bone_name]
                    for constr in pbone.constraints:
                        if constr.name in constraint_names:
                            constr.influence = desired_influence
                            # If keyframe toggle is enabled, insert a keyframe for influence.
                            if self.keyframe_ik_fk_switch:
                                constr.keyframe_insert(data_path="influence")
            # Set visibility of "Layer 31" in armature's data collections_all based on fkik_mode
            if "Layer 31" in obj.data.collections_all:
                obj.data.collections_all["Layer 31"].is_visible = True if self.fkik_mode == "FK" else False


class HHP_OT_ClearPose(bpy.types.Operator):
    """Reset pose to rest position"""
    bl_idname = "hhp.clear_pose"
    bl_label = "Clear Pose"
    bl_description = "Reset all bones to their rest position"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'ARMATURE'

    def execute(self, context):
        armature = context.active_object
        
        # Store current selection
        selected_bones = [bone.name for bone in armature.data.bones if bone.select]
        
        # Clear all transforms to default values
        for bone in armature.pose.bones:
            # Clear location
            bone.location = (0, 0, 0)
            # Clear rotation (in all rotation modes)
            bone.rotation_quaternion = (1, 0, 0, 0)
            bone.rotation_euler = (0, 0, 0)
            bone.rotation_axis_angle = (0, 0, 1, 0)
            # Clear scale
            bone.scale = (1, 1, 1)
            
        # Update the view
        context.view_layer.update()
            
        return {'FINISHED'}


class HHP_AnimPreviewProperties(bpy.types.PropertyGroup):
    # Pointer to a Blender Action. Updating it triggers update_action().
    action: bpy.props.PointerProperty(
        type=bpy.types.Action,
        description="Select an Action to apply to the active Armature",
        update=update_action
    )

    # Boolean property for showing advanced options (toggleable via an icon)
    advanced_options: bpy.props.BoolProperty(
        name="",
        description="Advanced Options:\nShow or hide advanced features like the Base Layer button.",
        default=False
    )

    # New FK/IK mode selector property
    fkik_mode: bpy.props.EnumProperty(
        name="FK/IK Mode",
        description="Select IK or FK mode for designated bones",
        items=[
            ("IK", "IK", "Inverse Kinematics mode"),
            ("FK", "FK", "Forward Kinematics mode")
        ],
        default="IK",
        update=update_fkik_switch
    )

    # Keyframe toggle for the IK/FK switch (clean icon only)
    keyframe_ik_fk_switch: bpy.props.BoolProperty(
        name="",
        description="Keyframe IK/FK switch",
        default=False
    )


class HHP_OT_RedistributeProportions(bpy.types.Operator):
    """Redistributes proportions of selected HHP armatures to a younger size by pose mode then selects affected bones & keyframes their scale"""
    bl_idname = "hhp.redistribute_proportions"
    bl_label = "Re-distribute proportions by pose"
    bl_description = "Redistributes proportions of selected HHP armatures to a younger size by pose mode then selects affected bones & keyframes their scale"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # Check if any armatures are selected
        if not context.selected_objects or not any(obj.type == 'ARMATURE' for obj in context.selected_objects):
            return False
        
        # Check if any selected armature has the required bones
        required_bones = {"Metatarsals.r", "Metatarsals.l", "neckLower", "hip"}
        for obj in context.selected_objects:
            if obj.type == 'ARMATURE':
                if all(bone in obj.pose.bones for bone in required_bones):
                    return True
        return False

    def execute(self, context):
        selected_armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
        
        if not selected_armatures:
            self.report({'WARNING'}, "An HHP armature needs to be selected")
            return {'CANCELLED'}
        
        # Check if any armature has the required bones
        required_bones = {"Metatarsals.r", "Metatarsals.l", "neckLower", "hip"}
        valid_armatures = []
        for armature in selected_armatures:
            if all(bone in armature.pose.bones for bone in required_bones):
                valid_armatures.append(armature)
        
        if not valid_armatures:
            self.report({'WARNING'}, "An HHP armature needs to be selected")
            return {'CANCELLED'}
        
        for armature in valid_armatures:
            # Make this armature the active object
            context.view_layer.objects.active = armature
            
            # Switch to Pose Mode
            bpy.ops.object.mode_set(mode='POSE')
            
            # Deselect all bones first
            bpy.ops.pose.select_all(action='DESELECT')
            
            # Define the bones and their scale factors
            bones_to_scale = {
                "Metatarsals.r": 1.1,
                "Metatarsals.l": 1.1,
                "neckLower": 1.1,
                "hip": 0.9
            }
            
            # Scale each bone if it exists and keyframe immediately
            for bone_name, scale_factor in bones_to_scale.items():
                if bone_name in armature.pose.bones:
                    # Select the relevant bone
                    armature.data.bones[bone_name].select = True
                    pose_bone = armature.pose.bones[bone_name]
                    pose_bone.scale = (scale_factor, scale_factor, scale_factor)
                    # Keyframe the scale for this specific bone
                    pose_bone.keyframe_insert(data_path="scale")
            
        self.report({'INFO'}, f"Redistributed proportions on {len(valid_armatures)} armature(s)")
        return {'FINISHED'}


def draw_anim_preview_box(layout, context):
    """
    Draws the anim preview box and its widgets.
    Should be called from a panel's draw() method.
    Only draws if the active object is an armature.
    """
    ob = context.active_object

    # Only show the preview box if an armature is active
    if not ob or ob.type != 'ARMATURE':
        return

    box = layout.box()
    box.label(text="Preview Animation")

    # Use active object's custom property instead of the scene's
    scene_props = ob.hhp_anim_preview_props

    col = box.column(align=True)
    row = col.row(align=True)

    # Toggle using a wrench icon
    row.prop(
        scene_props,
        "advanced_options",
        icon='MODIFIER',
        text="",
        emboss=True,
        toggle=True
    )
    # Action selector
    row.prop(scene_props, "action", text="")

    # Blend mode: ensure animation_data exists
    if not ob.animation_data:
        ob.animation_data_create()
    row.prop(ob.animation_data, "action_blend_type", text="")

    # FK/IK mode selector and keyframe checkbox row
    row_fkik = col.row(align=True)
    row_fkik.prop(scene_props, "keyframe_ik_fk_switch", text="", icon='KEYFRAME')
    row_fkik.prop(scene_props, "fkik_mode", expand=True)

    # If advanced options are enabled, show additional buttons
    if scene_props.advanced_options:
        row = col.row(align=True)
        row.operator("hhp.clear_pose", text="Clear Pose")  # Clear Pose first
        row.operator("hhp.create_base_layer", text="Create Base layer")  # Base layer second

        # New row for redistribute proportions button
        row = col.row(align=True)
        row.operator("hhp.redistribute_proportions", text="Re-distribute proportions by pose")


# Registration
classes = (
    HHP_OT_CreateBaseLayer,
    HHP_OT_ClearPose,
    HHP_AnimPreviewProperties,
    HHP_OT_RedistributeProportions,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    # Attach the anim preview properties to every Blender Object (for armatures)
    bpy.types.Object.hhp_anim_preview_props = bpy.props.PointerProperty(type=HHP_AnimPreviewProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    # Remove the property from Blender Object
    del bpy.types.Object.hhp_anim_preview_props 