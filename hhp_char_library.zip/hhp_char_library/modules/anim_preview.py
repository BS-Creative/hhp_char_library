import bpy
from bpy.app.handlers import persistent
from mathutils import Vector

from . import hhp_naming, hhp_rigify
from .animation_transfer_support import (
    PROPORTION_PROPERTIES, proportion_anchor_bone, proportion_bone_map,
    supports_proportions, sync_proportion_distribution_ui, proportion_rig_version,
    sync_proportion_followers, remove_proportion_constraint,
    is_proportion_constraint, is_proportion_follower, set_proportion_influence,
    proportion_constraint_influence, proportion_constraint_muted,
)


_PORTABLE_SYNCING = False
_PORTABLE_ERRORS = {}


def _sync_portable_objects(objects, frame=None, restore=False):
    """Keep imported native bone clips independent of the physics UI switch."""
    global _PORTABLE_SYNCING
    if _PORTABLE_SYNCING:
        return False
    from ..EXPERIMENTAL import hhp_ragdoll
    changed = False
    _PORTABLE_SYNCING = True
    try:
        for armature in tuple(objects):
            if armature.type != 'ARMATURE' or armature.is_evaluated:
                continue
            pointer = armature.as_pointer()
            try:
                if restore:
                    changed = hhp_ragdoll.restore_portable_action_playback(armature) or changed
                else:
                    changed = hhp_ragdoll.sync_portable_action_playback(armature, frame=frame) or changed
                _PORTABLE_ERRORS.pop(pointer, None)
            except (AttributeError, KeyError, ReferenceError, RuntimeError, TypeError, ValueError) as exc:
                message = str(exc)
                if _PORTABLE_ERRORS.get(pointer) != message:
                    print('HHP native action playback: ' + message)
                    _PORTABLE_ERRORS[pointer] = message
    finally:
        _PORTABLE_SYNCING = False
    return changed


@persistent
def _portable_frame_change(scene, depsgraph=None):
    _sync_portable_objects(scene.objects, scene.frame_current_final)


@persistent
def _portable_depsgraph_update(scene, depsgraph=None):
    # Direct Action Editor assignments do not call the preview dropdown update.
    # The helper only tags the rig when its ownership state actually changes.
    _sync_portable_objects(scene.objects)


@persistent
def _portable_file_change(_dummy=None):
    _PORTABLE_ERRORS.clear()
    for scene in getattr(bpy.data, 'scenes', ()):
        for armature in scene.objects:
            if armature.type == 'ARMATURE' and armature.get('hhp_proportion_ui_pending'):
                sync_proportion_distribution_ui(armature)
        _sync_portable_objects(scene.objects, scene.frame_current_final)


_PORTABLE_HANDLERS = (
    ('frame_change_pre', _portable_frame_change),
    ('depsgraph_update_post', _portable_depsgraph_update),
    ('load_post', _portable_file_change),
    ('undo_post', _portable_file_change),
    ('redo_post', _portable_file_change),
)


def _find_character_mesh_for_armature(context, armature):
    """Return the HHP character body mesh driven by *armature*."""
    if armature is None or getattr(armature, "type", None) != 'ARMATURE':
        return None

    character_meshes = [
        obj for obj in getattr(context.scene, "objects", [])
        if hhp_naming.is_char_mesh(obj)
    ]
    if not character_meshes:
        return None

    # The Armature modifier is the strongest link between the selected rig and body.
    modifier_matches = [
        obj for obj in character_meshes
        if any(
            modifier.type == 'ARMATURE' and getattr(modifier, "object", None) == armature
            for modifier in getattr(obj, "modifiers", [])
        )
    ]
    if modifier_matches:
        return sorted(modifier_matches, key=lambda obj: obj.name.lower())[0]

    # HHP Struct keeps the armature and character mesh in the same Char (HHP)
    # collection. Use that relationship as a fallback for rigs without a modifier.
    armature_char_collections = {
        collection for collection in getattr(armature, "users_collection", [])
        if "Char (HHP)" in getattr(collection, "name", "")
    }
    collection_matches = [
        obj for obj in character_meshes
        if any(
            collection in armature_char_collections
            for collection in getattr(obj, "users_collection", [])
        )
    ]
    if collection_matches:
        return sorted(collection_matches, key=lambda obj: obj.name.lower())[0]

    return None


def _get_evaluated_bounding_box_height(context, obj):
    """Return the evaluated object's world-space bounding-box height in Blender units."""
    if obj is None:
        return None

    try:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_obj = obj.evaluated_get(depsgraph)
        corners = tuple(evaluated_obj.bound_box)
        if not corners:
            return None
        world_z = [
            (evaluated_obj.matrix_world @ Vector(corner)).z
            for corner in corners
        ]
        height = max(world_z) - min(world_z)
        return height if height > 0.0 else None
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _format_character_height(scene, height):
    """Format a Blender-unit height using the scene's current unit settings."""
    if height is None:
        return None

    unit_settings = getattr(scene, "unit_settings", None)
    system = getattr(unit_settings, "system", 'NONE') if unit_settings else 'NONE'
    if system in {'METRIC', 'IMPERIAL'}:
        scale_length = float(getattr(unit_settings, "scale_length", 1.0) or 1.0)
        return bpy.utils.units.to_string(
            system,
            'LENGTH',
            height * scale_length,
            precision=3,
            split_unit=bool(getattr(unit_settings, "use_separate", False)),
        )

    return f"{height:.3f} BU"


def _refresh_proportion_preview(context, armatures):
    """Evaluate proportion edits immediately and redraw the live height label."""
    for armature in armatures:
        if hhp_rigify.is_built(armature):
            hhp_rigify.sync_proportions(armature, evaluate=False)
        else:
            sync_proportion_followers(armature)
        if getattr(armature.data, 'hhp_ragdoll_built', False):
            from ..EXPERIMENTAL import hhp_ragdoll
            physical = {name: hhp_ragdoll.bone_part_segment(segment, name)
                        for segment, spec in hhp_ragdoll.active_segments(armature).items()
                        for name in spec['bones']}
            for bone in armature.pose.bones:
                if ('hhp_rd_base_influences' in bone
                        and any(is_proportion_constraint(c) or is_proportion_follower(c)
                                for c in bone.constraints)):
                    hhp_ragdoll.mute_animation_constraints(
                        bone, armature, physical.get(bone.name), physics=bone.name in physical)
        try:
            armature.update_tag()
        except (AttributeError, ReferenceError, RuntimeError):
            pass

    try:
        context.view_layer.update()
    except (AttributeError, RuntimeError):
        pass

    screen = getattr(context, "screen", None)
    for area in getattr(screen, "areas", []) if screen else []:
        try:
            area.tag_redraw()
        except (AttributeError, ReferenceError, RuntimeError):
            pass

def _get_posebone_custom_prop_default(pbone, key, current_val):
    """
    Best-effort default resolver for pose-bone ID properties.
    - Prefers explicit default from pbone["_RNA_UI"][key]["default"] when available.
    - Falls back to type-based defaults when not present.
    """
    try:
        rna_ui = pbone.get("_RNA_UI", None)
        ui_k = None
        if rna_ui is not None:
            # _RNA_UI is typically an IDPropertyGroup/dict-like
            if hasattr(rna_ui, "get"):
                ui_k = rna_ui.get(key)
            else:
                ui_k = rna_ui[key]
        if ui_k and hasattr(ui_k, "get") and ("default" in ui_k):
            return ui_k.get("default")
    except Exception:
        pass

    # Fallbacks when no explicit default exists
    if isinstance(current_val, bool):
        return False
    if isinstance(current_val, int):
        return 0
    if isinstance(current_val, float):
        return 0.0
    return current_val


def _set_posebone_custom_props_to_defaults(pbone):
    """Set scalar custom properties (excluding _RNA_UI) to their default value."""
    try:
        keys = [k for k in pbone.keys() if k != "_RNA_UI"]
    except Exception:
        return

    for k in keys:
        try:
            v = pbone.get(k)
            if not isinstance(v, (int, float, bool)):
                continue
            default_v = _get_posebone_custom_prop_default(pbone, k, v)
            # Keep type stable where possible
            if isinstance(v, bool):
                pbone[k] = bool(default_v)
            elif isinstance(v, int):
                pbone[k] = int(default_v)
            else:
                pbone[k] = float(default_v)
        except Exception:
            continue


def _keyframe_posebone_custom_props(pbone):
    """Insert keyframes for scalar custom properties (excluding _RNA_UI)."""
    try:
        keys = [k for k in pbone.keys() if k != "_RNA_UI"]
    except Exception:
        return
    for k in keys:
        try:
            v = pbone.get(k)
            if isinstance(v, (int, float, bool)):
                pbone.keyframe_insert(data_path=f'["{k}"]')
        except Exception:
            continue


def create_base_layer_action():
    """
    Creates a unified "Preview_BaseLayer" (Action + NLA Track + NLA Strip) that represents the
    armature in its default state, and inserts it as the base (evaluated first) in the NLA.

    Behavior:
    - Remember active action/slot, pose position, pose bone transforms, and pose bone custom properties.
    - Temporarily reset pose transforms and reset pose bone custom properties to their defaults (does NOT delete them).
    - Create the base layer action with keys at scene start/end.
    - Push to NLA as a REPLACE strip with HOLD extrapolation, placed as the bottom-most track.
    - Restore the previously remembered action/pose/custom properties.
    """
    armature = bpy.context.object
    if not armature or armature.type != 'ARMATURE':
        print("No valid armature selected.")
        return

    if hhp_rigify.is_built(armature):
        from .hhp_rigify_preview import create_base_layer
        return create_base_layer(armature)

    scene = bpy.context.scene
    start_frame = scene.frame_start
    end_frame = scene.frame_end
    stored_frame = scene.frame_current

    # Snapshot current state (best-effort, but should be robust in Blender 5).
    stored_pose_position = getattr(armature.data, "pose_position", None)
    armature.animation_data_create()
    stored_action = armature.animation_data.action
    stored_action_slot = getattr(armature.animation_data, "action_slot", None)
    stored_action_blend_type = None
    try:
        if hasattr(armature.animation_data, "action_blend_type"):
            stored_action_blend_type = armature.animation_data.action_blend_type
    except Exception:
        stored_action_blend_type = None

    stored_props_action = None
    try:
        if hasattr(armature, "hhp_anim_preview_props"):
            stored_props_action = armature.hhp_anim_preview_props.action
    except Exception:
        stored_props_action = None

    stored_bone_state = {}
    if getattr(armature, "pose", None):
        for pbone in armature.pose.bones:
            # Store transforms (matrix_basis is the delta from rest).
            try:
                mb = pbone.matrix_basis.copy()
            except Exception:
                mb = None

            # Store custom properties (excluding UI metadata which we should never touch).
            custom_props = {}
            try:
                for k in pbone.keys():
                    if k == "_RNA_UI":
                        continue
                    custom_props[k] = pbone.get(k)
            except Exception:
                custom_props = {}

            stored_bone_state[pbone.name] = {
                "matrix_basis": mb,
                "custom_props": custom_props,
            }

    # Temporarily reset to defaults: clear pose + reset custom props to defaults (do NOT delete them)
    if getattr(armature, "pose", None):
        for pbone in armature.pose.bones:
            try:
                pbone.matrix_basis.identity()
            except Exception:
                pbone.location = (0.0, 0.0, 0.0)
                pbone.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
                pbone.rotation_euler = (0.0, 0.0, 0.0)
                pbone.scale = (1.0, 1.0, 1.0)

            # Reset all pose-bone custom properties to their defaults.
            # IMPORTANT: do NOT delete properties; deleting can break driver paths and UI sliders.
            _set_posebone_custom_props_to_defaults(pbone)

    # Create a new unified action and assign it
    base_name = "Preview_BaseLayer"
    new_action = bpy.data.actions.new(base_name)
    armature.animation_data.action = new_action

    # Insert keys for all pose bones at start/end (data API, no operators)
    if getattr(armature, "pose", None):
        scene.frame_set(start_frame)
        for pbone in armature.pose.bones:
            # Ensure custom properties are at default values at the exact moment we keyframe them.
            _set_posebone_custom_props_to_defaults(pbone)
            pbone.keyframe_insert(data_path="location")
            # Insert all common rotation representations; Blender will ignore non-applicable paths.
            pbone.keyframe_insert(data_path="rotation_quaternion")
            pbone.keyframe_insert(data_path="rotation_euler")
            pbone.keyframe_insert(data_path="scale")
            # Keyframe custom properties (sliders) so the base layer includes them.
            _keyframe_posebone_custom_props(pbone)

        scene.frame_set(end_frame)
        for pbone in armature.pose.bones:
            _set_posebone_custom_props_to_defaults(pbone)
            pbone.keyframe_insert(data_path="location")
            pbone.keyframe_insert(data_path="rotation_quaternion")
            pbone.keyframe_insert(data_path="rotation_euler")
            pbone.keyframe_insert(data_path="scale")
            _keyframe_posebone_custom_props(pbone)

    # Push Action to NLA
    armature.animation_data.action = None
    nla_track = armature.animation_data.nla_tracks.new()
    nla_track.name = base_name
    nla_strip = nla_track.strips.new(base_name, start_frame, new_action)
    nla_strip.blend_type = 'REPLACE'
    nla_strip.frame_start = start_frame
    nla_strip.frame_end = end_frame
    # Extrapolation: HOLD (best-effort; different Blender versions use different enum names)
    try:
        nla_strip.extrapolation = 'HOLD'
    except Exception:
        try:
            nla_strip.extrapolation = 'HOLD_FORWARD'
        except Exception:
            pass

    # Ensure this base track is evaluated first: put it at the bottom of the NLA stack.
    try:
        tracks = armature.animation_data.nla_tracks
        tracks.move(len(tracks) - 1, len(tracks) - 1)  # no-op if already last (keeps API warm)
        # The newly created track is last by default; enforce explicitly in case Blender changes behavior.
        tracks.move(tracks.find(nla_track.name), len(tracks) - 1)
    except Exception:
        pass

    # Restore previous state (pose transforms + custom props + active action/slot)
    if getattr(armature, "pose", None):
        for pbone in armature.pose.bones:
            st = stored_bone_state.get(pbone.name)
            if not st:
                continue
            if st.get("matrix_basis") is not None:
                try:
                    pbone.matrix_basis = st["matrix_basis"]
                except Exception:
                    pass
            # Restore pose-bone custom property values (do NOT delete properties).
            try:
                for k, v in st.get("custom_props", {}).items():
                    pbone[k] = v
            except Exception:
                pass

    try:
        if stored_pose_position is not None:
            armature.data.pose_position = stored_pose_position
    except Exception:
        pass

    try:
        armature.animation_data.action = stored_action
        if hasattr(armature.animation_data, "action_slot"):
            armature.animation_data.action_slot = stored_action_slot
        if stored_action_blend_type is not None and hasattr(armature.animation_data, "action_blend_type"):
            armature.animation_data.action_blend_type = stored_action_blend_type
    except Exception:
        pass

    # Restore the anim preview dropdown selection (last, since it has an update callback)
    try:
        if hasattr(armature, "hhp_anim_preview_props"):
            armature.hhp_anim_preview_props.action = stored_props_action
    except Exception:
        pass

    # Restore the user's current frame
    try:
        scene.frame_set(stored_frame)
    except Exception:
        pass

    try:
        armature.update_tag()
        bpy.context.view_layer.update()
    except Exception:
        pass


class HHP_OT_CreateBaseLayer(bpy.types.Operator):
    """Creates a new preview base layer and pushes it to the NLA. Useful for previewing add blend mode actions if armature has no NLA strips assigned"""
    bl_idname = "hhp.create_base_layer"
    bl_label = "Create Base layer"
    bl_description = "Creates a new preview base layer and pushes it to the NLA. Useful for previewing add blend mode actions if armature has no NLA strips assigned"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        """
        This operator is only valid if:
          1. An Armature is active, AND
          2. The Armature has NO existing NLA tracks (button is disabled if any tracks already exist).
        """
        ob = context.active_object
        if not ob or ob.type != 'ARMATURE':
            return False

        # Disable if any NLA tracks already exist (requested behavior)
        if ob.animation_data and getattr(ob.animation_data, "nla_tracks", None):
            if len(ob.animation_data.nla_tracks) > 0:
                return False
        return True

    def invoke(self, context, event):
        """Show a confirmation dialog to avoid accidental clicks."""
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        # Create the base layer action
        try:
            create_base_layer_action()
        except (RuntimeError, ValueError, KeyError, TypeError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        # Also clear the selected action in the anim preview properties on the active armature (not on the scene)
        ob = context.active_object
        ob.hhp_anim_preview_props.action = None

        self.report({'INFO'}, "Preview_BaseLayer created and pushed to NLA.")
        return {'FINISHED'}


def _clear_preview_pose_and_action(ob, context):
    """Clear the preview action/slot and reset the armature to its rest pose."""
    ob.animation_data_create()
    # Blender 5.1 requires the slot to be released while its Action is still assigned.
    if ob.animation_data.action is not None:
        ob.animation_data.action_slot = None
    ob.animation_data.action = None
    _sync_portable_objects((ob,), context.scene.frame_current_final)
    hhp_rigify.clear_pose(ob, context)

    if context.view_layer:
        context.view_layer.update()


def update_action(self, context):
    """
    When a new Action is selected or cleared in the dropdown:
      - If an Action is selected, force Pose Position on the Armature
        and assign that Action as active, using the Action Slot system.
      - If cleared (None), clear the pose and the active action/slot.
    """
    ob = self.id_data
    if not ob or ob.type != 'ARMATURE' or ob.is_evaluated:
        return

    # If the user selected a valid Action
    if self.action:
        action_to_assign = self.action
        previous_action = ob.animation_data.action if ob.animation_data else None

        # A direct A -> B selection must use the same cleanup as A -> None -> B.
        # Otherwise transforms not keyed by B can remain behind from A.
        if previous_action and previous_action != action_to_assign:
            _clear_preview_pose_and_action(ob, context)

        ob.data.pose_position = 'POSE'
        ob.animation_data_create()

        ob.animation_data.action = action_to_assign # Assign the action itself

        target_slot = None
        if action_to_assign and action_to_assign.slots:
            target_slot = action_to_assign.slots.active
            # If no active slot, fall back to the first slot if available
            if not target_slot and len(action_to_assign.slots) > 0:
                target_slot = action_to_assign.slots[0]

        # Assign the determined slot (or None if no slots exist on the action)
        ob.animation_data.action_slot = target_slot
        if _sync_portable_objects((ob,), context.scene.frame_current_final) and context.view_layer:
            context.view_layer.update()

    else: # Action is cleared
        _clear_preview_pose_and_action(ob, context)


def _rig_type_get(self):
    return int(hhp_rigify.control_rig_active(self.id_data))


def _rig_type_set(self, value):
    arm = self.id_data
    if arm.is_evaluated:
        return
    hhp_rigify.switch_rig(arm, bool(value), self.keyframe_ik_fk_switch)


def _fkik_get(self):
    return 0 if hhp_rigify.is_ik(self.id_data) else 1


def _fkik_set(self, value):
    arm = self.id_data
    if arm.is_evaluated:
        return
    hhp_rigify.switch_kinematics(arm, value == 0, self.keyframe_ik_fk_switch)


def _clear_character_pose(armature, context):
    """Clear the native or generated rig while preserving animation ownership."""
    hhp_rigify.clear_pose(armature, context)


class HHP_OT_ClearPose(bpy.types.Operator):
    """Clear the pose while keeping the character's current rig and proportions"""
    bl_idname = "hhp.clear_pose"
    bl_label = "Clear Pose"
    bl_description = ("Clear bone poses and global root scale, match the controls to neutral "
                      "proportions, and keep the selected rig mode and animation")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'ARMATURE'

    def execute(self, context):
        armature = context.active_object
        try:
            _clear_character_pose(armature, context)
        except (RuntimeError, ValueError, KeyError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class HHP_AnimPreviewProperties(bpy.types.PropertyGroup):
    use_daz_rotation_limits: bpy.props.BoolProperty(
        name="Use Daz Rotation Limits",
        description="Apply the original Daz rotation limits; enabling this can clamp a transferred pose outside those limits",
        get=lambda self: not bool(self.id_data.get('hhp_native_limit_override', 0)),
        set=lambda self, value: hhp_rigify.set_daz_rotation_limits(self.id_data, value),
    )
    show_daz_bones: bpy.props.BoolProperty(
        name="Show Daz Bones",
        description="Keep the original Daz bones visible alongside the Rigify controls",
        default=False,
        update=lambda self, context: hhp_rigify.refresh_visibility(self.id_data),
    )
    # Pointer to a Blender Action. Updating it triggers update_action().
    action: bpy.props.PointerProperty(
        type=bpy.types.Action,
        description="Select an Action to apply to the active Armature",
        update=update_action
    )

    # Boolean property for showing advanced options (toggleable via an icon)
    advanced_options: bpy.props.BoolProperty(
        name="",
        description="Advanced Options:\nShow or hide advanced features like the Base Layer button.",
        default=False
    )

    rig_type: bpy.props.EnumProperty(
        name="Rig Type",
        description="Use the original Daz bones or the Rigify control rig; switching transfers the current pose",
        items=[('DAZ', 'Daz', 'Use the original Daz bone channels', 0),
               ('RIGIFY', 'Rigify', 'Use the generated Rigify controllers', 1)],
        get=_rig_type_get, set=_rig_type_set,
    )

    fkik_mode: bpy.props.EnumProperty(
        name="Mode",
        description="Switch the Rigify limbs between IK targets and FK controls using their generated pose-matching operators",
        items=[('IK', 'IK', 'Pose with hand, foot, finger and tongue targets', 0),
               ('FK', 'FK', 'Pose the generated FK controls', 1)],
        get=_fkik_get, set=_fkik_set,
    )

    # Keyframe toggle for the IK/FK switch (clean icon only)
    keyframe_ik_fk_switch: bpy.props.BoolProperty(
        name="",
        description="Keyframe IK/FK switch",
        default=False
    )

    # New property for proportion constraints influence
    proportion_influence: bpy.props.FloatProperty(
        name="Proportion Influence",
        description="Control the influence of all proportion constraints",
        default=1.0,
        min=0.0,
        max=1.0,
        subtype='FACTOR',  # This creates the blue fill effect
        update=lambda self, context: update_proportion_influence(self, context)
    )

    # Proportion Distribution: which bone acts as the downscale anchor (only one is kept at a time)
    propdist_anchor_bone: bpy.props.EnumProperty(
        name="Anchor Bone",
        description=(
            "Choose which bone acts as the Proportion Distribution anchor.\n"
            "Switching this will remove the Proportion Distribution constraint from the other anchor bone "
            "and apply it to the selected one (root/hip) for the selected armatures. "
            "HHP5 preserves existing hip proportions; IK targets keep their posed positions."
        ),
        items=[
            ("ROOT", "Root", "Use the root bone as the Proportion Distribution anchor (downscale bone)"),
            ("HIP", "Hip", "Use the hip bone as the Proportion Distribution anchor (downscale bone)"),
        ],
        default="ROOT",
        update=lambda self, context: update_propdist_anchor_bone(self, context),
    )

    # Proportion Distribution: per-bone constraint toggles (these drive constraint mute/influence)
    propdist_enable_metatarsals_r: bpy.props.BoolProperty(
        name="",
        description="Enable proportion scaling on the right forefoot",
        default=True,
        update=lambda self, context: update_proportion_enabled(self, context),
    )
    propdist_scale_metatarsals_r: bpy.props.FloatProperty(
        name="",
        description="Set proportion scale on the right forefoot (all axes)",
        default=1.1,
        min=0.01,
        max=2.0,
        step=0.1,
        update=lambda self, context: update_proportion_scale_values(self, context),
    )
    propdist_enable_metatarsals_l: bpy.props.BoolProperty(
        name="",
        description="Enable proportion scaling on the left forefoot",
        default=True,
        update=lambda self, context: update_proportion_enabled(self, context),
    )
    propdist_scale_metatarsals_l: bpy.props.FloatProperty(
        name="",
        description="Set proportion scale on the left forefoot (all axes)",
        default=1.1,
        min=0.01,
        max=2.0,
        step=0.1,
        update=lambda self, context: update_proportion_scale_values(self, context),
    )
    propdist_enable_neckLower: bpy.props.BoolProperty(
        name="",
        description="Enable the Proportion Distribution constraint on neckLower",
        default=True,
        update=lambda self, context: update_proportion_enabled(self, context),
    )
    propdist_scale_neckLower: bpy.props.FloatProperty(
        name="",
        description="Set the Proportion Distribution min/max scale value for neckLower (applies to all axes)",
        default=1.1,
        min=0.01,
        max=2.0,
        step=0.1,
        update=lambda self, context: update_proportion_scale_values(self, context),
    )
    propdist_enable_root: bpy.props.BoolProperty(
        name="",
        description="Enable the Proportion Distribution constraint on root (if present)",
        default=True,
        update=lambda self, context: update_proportion_enabled(self, context),
    )
    propdist_scale_root: bpy.props.FloatProperty(
        name="",
        description="Set the Proportion Distribution min/max scale value for root (applies to all axes)",
        default=0.9,
        min=0.01,
        max=2.0,
        step=0.1,
        update=lambda self, context: update_proportion_scale_values(self, context),
    )
    propdist_enable_hip: bpy.props.BoolProperty(
        name="",
        description="Enable the Proportion Distribution constraint on hip (if present)",
        default=True,
        update=lambda self, context: update_proportion_enabled(self, context),
    )
    propdist_scale_hip: bpy.props.FloatProperty(
        name="",
        description="Set the Proportion Distribution min/max scale value for hip (applies to all axes)",
        default=0.9,
        min=0.01,
        max=2.0,
        step=0.1,
        update=lambda self, context: update_proportion_scale_values(self, context),
    )


def update_proportion_influence(self, context):
    """Update the influence of all proportion constraints on selected armatures.

    Note: This does NOT change constraint enabled state; that is handled by update_proportion_enabled().
    """
    if self.get("_syncing_from_constraints", False):
        return

    selected_armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
    for obj in selected_armatures:
        if obj.type != 'ARMATURE' or not getattr(obj, "pose", None):
            continue
        for pose_bone in obj.pose.bones:
            for constraint in pose_bone.constraints:
                if "(HHP) Limit Scale - Proportions" in constraint.name and hasattr(constraint, "influence"):
                    set_proportion_influence(obj, pose_bone, constraint, float(self.proportion_influence))

    _refresh_proportion_preview(context, selected_armatures)


def update_proportion_enabled(self, context):
    """Enable/disable (mute/unmute) proportion constraints per bone, based on the UI toggles.

    Note: This does NOT change constraint influence; that is handled by update_proportion_influence().
    """
    if self.get("_syncing_from_constraints", False):
        return

    selected_armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
    for obj in selected_armatures:
        if obj.type != 'ARMATURE' or not getattr(obj, "pose", None):
            continue
        bone_toggle_map = {
            bone: "propdist_enable_" + PROPORTION_PROPERTIES[name][0]
            for name, bone in proportion_bone_map(obj).items()
        }
        for pose_bone in obj.pose.bones:
            prop_name = bone_toggle_map.get(pose_bone.name)
            enabled = True if not prop_name else bool(getattr(self, prop_name, True))

            for constraint in pose_bone.constraints:
                if "(HHP) Limit Scale - Proportions" in constraint.name and hasattr(constraint, "mute"):
                    if proportion_rig_version(obj) >= 5:
                        saved = dict(pose_bone.get('hhp_proportion_mutes', {}))
                        if saved.get(constraint.name) != (not enabled):
                            saved[constraint.name] = not enabled
                            pose_bone['hhp_proportion_mutes'] = saved
                    if constraint.mute != (not enabled):
                        constraint.mute = (not enabled)

    _refresh_proportion_preview(context, selected_armatures)


def update_proportion_scale_values(self, context):
    """Update the min/max scale values for proportion constraints on selected armatures.

    Each bone uses a single scale value, written to all min/max axes of its LIMIT_SCALE constraint.
    """
    if self.get("_syncing_from_constraints", False):
        return

    axis_attrs = ("min_x", "min_y", "min_z", "max_x", "max_y", "max_z")

    selected_armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
    for obj in selected_armatures:
        if obj.type != 'ARMATURE' or not getattr(obj, "pose", None):
            continue
        bone_scale_map = {
            bone: "propdist_scale_" + PROPORTION_PROPERTIES[name][0]
            for name, bone in proportion_bone_map(obj).items()
        }
        for bone_name, prop_name in bone_scale_map.items():
            pose_bone = obj.pose.bones.get(bone_name)
            if not pose_bone:
                continue

            scale_value = float(getattr(self, prop_name, 1.0))
            for constraint in pose_bone.constraints:
                if "(HHP) Limit Scale - Proportions" not in constraint.name:
                    continue
                for attr in axis_attrs:
                    if hasattr(constraint, attr) and getattr(constraint, attr) != scale_value:
                        setattr(constraint, attr, scale_value)

    _refresh_proportion_preview(context, selected_armatures)


def update_propdist_anchor_bone(self, context):
    """Move the Proportion Distribution anchor constraint between root and hip.

    Behavior:
    - Ensures ONLY the selected anchor bone keeps the '(HHP) Limit Scale - Proportions' constraint.
    - Removes the constraint from the other anchor bone if present.
    - Creates the constraint on the selected anchor bone if missing.
    - Carries each armature's current anchor scale, influence and enabled state.
    """
    if self.get("_syncing_from_constraints", False):
        return

    requested_anchor = self.propdist_anchor_bone
    for obj in context.selected_objects:
        if not supports_proportions(obj):
            continue
        desired_bone = proportion_anchor_bone(obj, requested_anchor)
        other_bone = "hip" if desired_bone == "root" else "root"

        # If the desired anchor bone doesn't exist on this armature, don't modify anything.
        desired_pb = obj.pose.bones.get(desired_bone)
        if not desired_pb:
            continue

        # Read the current anchor before removing it. The destination's UI scale
        # is reset to its default while it has no constraint; it is not the
        # user's current body scale. Read each rig separately for multi-selection.
        other_pb = obj.pose.bones.get(other_bone)
        source = next((c for c in other_pb.constraints if is_proportion_constraint(c)), None) if other_pb else None
        source_pb = other_pb
        if source is None:
            source = next((c for c in desired_pb.constraints if is_proportion_constraint(c)), None)
            source_pb = desired_pb
        props = getattr(obj, "hhp_anim_preview_props", self)
        scale_value = float(getattr(props, "propdist_scale_" + desired_bone))
        axis_attrs = ("min_x", "min_y", "min_z", "max_x", "max_y", "max_z")
        scales = {attr: getattr(source, attr) if source else scale_value for attr in axis_attrs}
        influence = (proportion_constraint_influence(obj, source_pb.name, source)
                     if source else float(props.proportion_influence))
        muted = (proportion_constraint_muted(obj, source_pb.name, source)
                 if source else not bool(getattr(props, "propdist_enable_" + desired_bone)))

        # Remove constraint from the other anchor bone (if it exists).
        if other_pb:
            for c in list(other_pb.constraints):
                if "(HHP) Limit Scale - Proportions" in c.name:
                    remove_proportion_constraint(obj, other_pb, c)

        # Ensure selected anchor bone has the constraint.
        existing = None
        for c in desired_pb.constraints:
            if "(HHP) Limit Scale - Proportions" in c.name:
                existing = c
                break

        if not existing:
            existing = desired_pb.constraints.new('LIMIT_SCALE')
            existing.name = "(HHP) Limit Scale - Proportions"

        # Ensure constraint settings match our expected setup.
        for attr in ("use_min_x", "use_min_y", "use_min_z", "use_max_x", "use_max_y", "use_max_z"):
            if hasattr(existing, attr):
                setattr(existing, attr, True)

        for attr, scale_value in scales.items():
            if hasattr(existing, attr):
                setattr(existing, attr, scale_value)

        if hasattr(existing, "owner_space"):
            existing.owner_space = 'LOCAL'
        if hasattr(existing, "use_transform_limit"):
            existing.use_transform_limit = True
        if hasattr(existing, "influence"):
            set_proportion_influence(obj, desired_pb, existing, influence)

        existing.mute = muted
        if proportion_rig_version(obj) >= 5:
            saved = dict(desired_pb.get('hhp_proportion_mutes', {}))
            saved[existing.name] = muted
            desired_pb['hhp_proportion_mutes'] = saved
        sync_proportion_distribution_ui(obj)

        try:
            obj.update_tag()
        except Exception:
            pass
    _refresh_proportion_preview(
        context,
        [obj for obj in context.selected_objects if obj.type == 'ARMATURE'],
    )


class HHP_OT_RedistributeProportions(bpy.types.Operator):
    """Redistribute HHP4 and HHP5 proportions using reversible pose constraints."""
    bl_idname = "hhp.redistribute_proportions"
    bl_label = "Redistribute Proportions"
    bl_description = "Redistribute HHP4 or HHP5 proportions with reversible forefoot, neck and body scale constraints around the selected root or hip"
    bl_options = {'REGISTER', 'UNDO'}

    # Anchor bone selector (root vs hip)
    anchor_bone: bpy.props.EnumProperty(
        name="Anchor Bone",
        description="Choose whether the character scales around its root or its hip",
        items=[
            ("ROOT", "Root", "Use the root bone as the anchor (downscale bone)"),
            ("HIP", "Hip", "Use the hip bone as the anchor (downscale bone)"),
        ],
        default="ROOT"
    )

    @classmethod
    def poll(cls, context):
        return any(supports_proportions(obj) for obj in context.selected_objects)

    def invoke(self, context, event):
        # Default to the persistent UI selection (if available), so the button always honors the dropdown.
        ob = context.active_object
        props = getattr(ob, "hhp_anim_preview_props", None) if ob else None
        if props and hasattr(props, "propdist_anchor_bone"):
            try:
                self.anchor_bone = props.propdist_anchor_bone
            except Exception:
                pass
        return self.execute(context)

    def execute(self, context):
        selected_armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
        
        if not selected_armatures:
            self.report({'WARNING'}, "An HHP armature needs to be selected")
            return {'CANCELLED'}
        
        valid_armatures = []
        for armature in selected_armatures:
            if supports_proportions(armature):
                anchor_bone_name = proportion_anchor_bone(armature, self.anchor_bone)
                if anchor_bone_name in armature.pose.bones:
                    valid_armatures.append(armature)
        
        if not valid_armatures:
            self.report({'WARNING'}, f"No valid HHP armatures with required bones including '{self.anchor_bone.lower()}' found")
            return {'CANCELLED'}
        
        for armature in valid_armatures:
            # NOTE: Avoid bpy.ops (mode switching / selection) — Blender 5 is stricter about operator context.
            anchor_bone_name = proportion_anchor_bone(armature, self.anchor_bone)
            other_anchor_name = "hip" if anchor_bone_name == "root" else "root"

            props = getattr(armature, "hhp_anim_preview_props", None)
            # Reset values locally without firing selected-object callbacks partway
            # through the operation (selected rigs can use different bone names).
            if props:
                previous_guard = props.get("_syncing_from_constraints")
                props["_syncing_from_constraints"] = True
                try:
                    for suffix, scale in PROPORTION_PROPERTIES.values():
                        setattr(props, "propdist_scale_" + suffix, scale)
                finally:
                    if previous_guard is None:
                        del props["_syncing_from_constraints"]
                    else:
                        props["_syncing_from_constraints"] = previous_guard

            # Ensure ONLY one anchor constraint exists (remove from both anchors first).
            for bn in (anchor_bone_name, other_anchor_name):
                pb = armature.pose.bones.get(bn)
                if not pb:
                    continue
                for c in list(pb.constraints):
                    if "(HHP) Limit Scale - Proportions" in c.name:
                        remove_proportion_constraint(armature, pb, c)

            mapping = proportion_bone_map(armature)
            bones_to_scale = {mapping[name]: PROPORTION_PROPERTIES[name][1]
                              for name in ("Metatarsals.r", "Metatarsals.l", "neckLower")}
            bones_to_scale[anchor_bone_name] = 0.9

            for bone_name, scale_factor in bones_to_scale.items():
                pose_bone = armature.pose.bones.get(bone_name)
                if not pose_bone:
                    continue

                # Remove any existing "(HHP) Limit Scale - Proportions" constraint(s) (safety)
                for c in list(pose_bone.constraints):
                    if "(HHP) Limit Scale - Proportions" in c.name:
                        remove_proportion_constraint(armature, pose_bone, c)

                const = pose_bone.constraints.new('LIMIT_SCALE')
                const.name = "(HHP) Limit Scale - Proportions"

                # Enable both min and max for all axes (guarded for Blender RNA differences)
                for attr in ("use_min_x", "use_min_y", "use_min_z", "use_max_x", "use_max_y", "use_max_z"):
                    if hasattr(const, attr):
                        setattr(const, attr, True)

                # Set both min and max to the scale factor
                for attr in ("min_x", "min_y", "min_z", "max_x", "max_y", "max_z"):
                    if hasattr(const, attr):
                        setattr(const, attr, float(scale_factor))

                if hasattr(const, "owner_space"):
                    const.owner_space = 'LOCAL'
                if hasattr(const, "use_transform_limit"):
                    const.use_transform_limit = True
                if hasattr(const, "influence"):
                    const.influence = 1.0

            # Ensure Blender evaluates the new constraints.
            try:
                armature.update_tag()
            except Exception:
                pass

            sync_proportion_distribution_ui(armature)
            hhp_rigify.sync_proportions(armature)

        try:
            context.view_layer.update()
        except Exception:
            pass
            
        anchors = sorted({proportion_anchor_bone(armature, self.anchor_bone).title()
                          for armature in valid_armatures})
        self.report({'INFO'}, f"Added proportion constraints to {len(valid_armatures)} armature(s) using {' / '.join(anchors)} anchor")
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        # Anchor selection in the redo panel (side-by-side selector like before)
        row = layout.row(align=True)
        row.label(text="Anchor Bone:")
        row.prop(self, "anchor_bone", expand=True)


class HHP_OT_RemoveProportionDistribution(bpy.types.Operator):
    """Remove the proportion distribution constraints from selected HHP armatures"""
    bl_idname = "hhp.remove_proportion_distribution"
    bl_label = "Clear Proportions"
    bl_description = (
        "Remove all '(HHP) Limit Scale - Proportions' constraints from selected armatures "
        "and reset the Proportion Influence slider to 0"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not context.selected_objects:
            return False
        for obj in context.selected_objects:
            if obj.type != 'ARMATURE' or not getattr(obj, "pose", None):
                continue
            for pose_bone in obj.pose.bones:
                if any("(HHP) Limit Scale - Proportions" in c.name for c in pose_bone.constraints):
                    return True
        return False

    def execute(self, context):
        armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
        if not armatures:
            self.report({'WARNING'}, "Select at least one armature")
            return {'CANCELLED'}

        removed_total = 0
        affected_armatures = 0

        for armature in armatures:
            if not getattr(armature, "pose", None):
                continue

            removed_this_armature = 0
            for pose_bone in armature.pose.bones:
                for c in list(pose_bone.constraints):
                    if "(HHP) Limit Scale - Proportions" in c.name:
                        remove_proportion_constraint(armature, pose_bone, c)
                        removed_total += 1
                        removed_this_armature += 1

            if removed_this_armature:
                affected_armatures += 1
                # Reset slider (requested behavior)
                try:
                    if hasattr(armature, "hhp_anim_preview_props"):
                        armature.hhp_anim_preview_props.proportion_influence = 0.0
                except Exception:
                    pass
                try:
                    armature.update_tag()
                except Exception:
                    pass

        try:
            context.view_layer.update()
        except Exception:
            pass

        if removed_total == 0:
            self.report({'INFO'}, "No proportion distribution constraints found")
        else:
            self.report({'INFO'}, f"Removed {removed_total} constraint(s) from {affected_armatures} armature(s)")
        return {'FINISHED'}


def draw_anim_preview_box(layout, context):
    """
    Draws the anim preview box and its widgets.
    Should be called from a panel's draw() method.
    Only draws if the active object is an armature.
    """
    ob = context.active_object

    # Only show the preview box if an armature is active
    if not ob or ob.type != 'ARMATURE':
        return

    box = layout.box()
    box.label(text="Preview Animation")

    # Use active object's custom property instead of the scene's
    scene_props = ob.hhp_anim_preview_props

    col = box.column(align=True)
    row = col.row(align=True)

    # Action selector
    row.prop(scene_props, "action", text="")

    # Blend mode: ensure animation_data exists
    if not ob.animation_data:
        ob.animation_data_create()
    row.prop(ob.animation_data, "action_blend_type", text="")

    # FK/IK mode selector and keyframe checkbox row
    row_fkik = col.row(align=True)
    row_fkik.enabled = hhp_rigify.is_built(ob) and hhp_rigify.control_rig_active(ob)
    row_fkik.prop(scene_props, "keyframe_ik_fk_switch", text="", icon='KEYFRAME')
    from .hhp_rigify_controls import available
    modes=row_fkik.row(align=True);modes.enabled=available()
    for mode in ("IK", "FK"):
        modes.operator("hhp.set_rig_mode", text=mode, icon="CON_KINEMATIC" if mode == "IK" else "CON_ROTLIKE", depress=scene_props.fkik_mode == mode).mode=mode
    pose_row = col.row(align=True)
    pose_row.operator("hhp.clear_pose", text="Clear Pose", icon='LOOP_BACK')
    pose_row.operator("hhp.create_base_layer", text="Create Base Layer", icon='NLA')
    rig_col = box.column(align=True)
    rig_row = rig_col.row(align=True)
    rig_row.enabled = hhp_rigify.is_built(ob)
    rig_row.use_property_split = False
    rig_label = 'Rigify' if scene_props.rig_type == 'RIGIFY' else 'Daz'
    rig_row.menu("HHP_MT_rig_type", text=f"Rig Type: {rig_label}", icon='ARMATURE_DATA')
    hhp_rigify.draw_options(rig_col, ob)

    # Proportion Distribution (own box)
    prop_box = box.box()
    character_mesh = _find_character_mesh_for_armature(context, ob)
    character_height = _get_evaluated_bounding_box_height(context, character_mesh)
    formatted_height = _format_character_height(context.scene, character_height)
    proportion_label = "Proportion Distribution"
    if formatted_height:
        proportion_label += f" ({formatted_height})"
    prop_box.label(text=proportion_label)

    # Gather which bones currently have the proportion constraint, so we only show relevant toggles.
    constrained_bones = set()
    for obj in context.selected_objects:
        if obj.type != 'ARMATURE' or not getattr(obj, "pose", None):
            continue
        for pose_bone in obj.pose.bones:
            if any("(HHP) Limit Scale - Proportions" in c.name for c in pose_bone.constraints):
                constrained_bones.add(pose_bone.name)

    has_proportion_constraints = bool(constrained_bones)

    prop_col = prop_box.column(align=True)
    proportion_actions = prop_col.row(align=True)
    proportion_actions.operator("hhp.redistribute_proportions", text="Redistribute Proportions", icon='CONSTRAINT_BONE')
    proportion_actions.operator("hhp.remove_proportion_distribution", text="Clear Proportions", icon='TRASH')

    if has_proportion_constraints:
        # row2: Influence slider
        row2 = prop_col.row(align=True)
        row2.prop(scene_props, "proportion_influence", text="Influence")

        # row3+: Per-bone toggles (3 per row, full-width grid for consistent alignment)
        toggle_defs = []
        active_mapping = proportion_bone_map(ob)
        selected_mappings = [proportion_bone_map(obj) for obj in context.selected_objects
                             if obj.type == 'ARMATURE']
        for name, (suffix, _scale) in PROPORTION_PROPERTIES.items():
            if any(mapping.get(name) in constrained_bones for mapping in selected_mappings):
                toggle_defs.append(("propdist_enable_" + suffix,
                                    "propdist_scale_" + suffix,
                                    active_mapping.get(name, name)))

        # Row 3+: EXACTLY 3 per row: each cell = toggle + per-bone scale slider under it
        for i in range(0, len(toggle_defs), 3):
            row_tog = prop_col.row(align=True)
            row_tog.alignment = 'EXPAND'

            chunk = toggle_defs[i:i + 3]
            for toggle_prop, scale_prop, label in chunk:
                cell = row_tog.column(align=True)
                cell.prop(
                    scene_props,
                    toggle_prop,
                    text=label,
                    icon='BONE_DATA',
                    toggle=True,
                )
                cell.prop(
                    scene_props,
                    scale_prop,
                    text="",
                )

        # Bottom row: Anchor selector dropdown (persistent; updates constraints immediately)
        row_anchor = prop_col.row(align=True)
        # Single labeled menu button (no separate label beside the control)
        try:
            enum_item = scene_props.bl_rna.properties["propdist_anchor_bone"].enum_items[scene_props.propdist_anchor_bone]
            anchor_label = enum_item.name
        except Exception:
            anchor_label = str(getattr(scene_props, "propdist_anchor_bone", ""))
        row_anchor.prop_menu_enum(scene_props, "propdist_anchor_bone", text=f"Anchor Bone: {anchor_label}")


# Registration
classes = (
    HHP_OT_CreateBaseLayer,
    HHP_OT_ClearPose,
    HHP_AnimPreviewProperties,
    HHP_OT_RedistributeProportions,
    HHP_OT_RemoveProportionDistribution,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    # Attach the anim preview properties to every Blender Object (for armatures)
    bpy.types.Object.hhp_anim_preview_props = bpy.props.PointerProperty(type=HHP_AnimPreviewProperties)
    for name, handler in _PORTABLE_HANDLERS:
        collection = getattr(bpy.app.handlers, name)
        if handler not in collection:
            collection.append(handler)
    if hasattr(bpy.data, 'scenes'):
        _portable_file_change()
    elif not bpy.app.timers.is_registered(_portable_file_change):
        bpy.app.timers.register(_portable_file_change, first_interval=0.0)

def unregister():
    if bpy.app.timers.is_registered(_portable_file_change):
        bpy.app.timers.unregister(_portable_file_change)
    for name, handler in reversed(_PORTABLE_HANDLERS):
        collection = getattr(bpy.app.handlers, name)
        if handler in collection:
            collection.remove(handler)
    _sync_portable_objects(bpy.data.objects, restore=True)
    _PORTABLE_ERRORS.clear()
    del bpy.types.Object.hhp_anim_preview_props
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
