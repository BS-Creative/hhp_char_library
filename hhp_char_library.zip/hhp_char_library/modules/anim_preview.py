import bpy

def _get_posebone_custom_prop_default(pbone, key, current_val):
    """
    Best-effort default resolver for pose-bone ID properties.
    - Prefers explicit default from pbone["_RNA_UI"][key]["default"] when available.
    - Falls back to type-based defaults when not present.
    """
    try:
        rna_ui = pbone.get("_RNA_UI", None)
        ui_k = None
        if rna_ui is not None:
            # _RNA_UI is typically an IDPropertyGroup/dict-like
            if hasattr(rna_ui, "get"):
                ui_k = rna_ui.get(key)
            else:
                ui_k = rna_ui[key]
        if ui_k and hasattr(ui_k, "get") and ("default" in ui_k):
            return ui_k.get("default")
    except Exception:
        pass

    # Fallbacks when no explicit default exists
    if isinstance(current_val, bool):
        return False
    if isinstance(current_val, int):
        return 0
    if isinstance(current_val, float):
        return 0.0
    return current_val


def _set_posebone_custom_props_to_defaults(pbone):
    """Set scalar custom properties (excluding _RNA_UI) to their default value."""
    try:
        keys = [k for k in pbone.keys() if k != "_RNA_UI"]
    except Exception:
        return

    for k in keys:
        try:
            v = pbone.get(k)
            if not isinstance(v, (int, float, bool)):
                continue
            default_v = _get_posebone_custom_prop_default(pbone, k, v)
            # Keep type stable where possible
            if isinstance(v, bool):
                pbone[k] = bool(default_v)
            elif isinstance(v, int):
                pbone[k] = int(default_v)
            else:
                pbone[k] = float(default_v)
        except Exception:
            continue


def _keyframe_posebone_custom_props(pbone):
    """Insert keyframes for scalar custom properties (excluding _RNA_UI)."""
    try:
        keys = [k for k in pbone.keys() if k != "_RNA_UI"]
    except Exception:
        return
    for k in keys:
        try:
            v = pbone.get(k)
            if isinstance(v, (int, float, bool)):
                pbone.keyframe_insert(data_path=f'["{k}"]')
        except Exception:
            continue


def create_base_layer_action():
    """
    Creates a unified "Preview_BaseLayer" (Action + NLA Track + NLA Strip) that represents the
    armature in its default state, and inserts it as the base (evaluated first) in the NLA.

    Behavior:
    - Remember active action/slot, pose position, pose bone transforms, and pose bone custom properties.
    - Temporarily reset pose transforms and reset pose bone custom properties to their defaults (does NOT delete them).
    - Create the base layer action with keys at scene start/end.
    - Push to NLA as a REPLACE strip with HOLD extrapolation, placed as the bottom-most track.
    - Restore the previously remembered action/pose/custom properties.
    """
    armature = bpy.context.object
    if not armature or armature.type != 'ARMATURE':
        print("No valid armature selected.")
        return

    scene = bpy.context.scene
    start_frame = scene.frame_start
    end_frame = scene.frame_end
    stored_frame = scene.frame_current

    # Snapshot current state (best-effort, but should be robust in Blender 5).
    stored_pose_position = getattr(armature.data, "pose_position", None)
    armature.animation_data_create()
    stored_action = armature.animation_data.action
    stored_action_slot = getattr(armature.animation_data, "action_slot", None)
    stored_action_blend_type = None
    try:
        if hasattr(armature.animation_data, "action_blend_type"):
            stored_action_blend_type = armature.animation_data.action_blend_type
    except Exception:
        stored_action_blend_type = None

    stored_props_action = None
    try:
        if hasattr(armature, "hhp_anim_preview_props"):
            stored_props_action = armature.hhp_anim_preview_props.action
    except Exception:
        stored_props_action = None

    stored_bone_state = {}
    if getattr(armature, "pose", None):
        for pbone in armature.pose.bones:
            # Store transforms (matrix_basis is the delta from rest).
            try:
                mb = pbone.matrix_basis.copy()
            except Exception:
                mb = None

            # Store custom properties (excluding UI metadata which we should never touch).
            custom_props = {}
            try:
                for k in pbone.keys():
                    if k == "_RNA_UI":
                        continue
                    custom_props[k] = pbone.get(k)
            except Exception:
                custom_props = {}

            stored_bone_state[pbone.name] = {
                "matrix_basis": mb,
                "custom_props": custom_props,
            }

    # Temporarily reset to defaults: clear pose + reset custom props to defaults (do NOT delete them)
    if getattr(armature, "pose", None):
        for pbone in armature.pose.bones:
            try:
                pbone.matrix_basis.identity()
            except Exception:
                pbone.location = (0.0, 0.0, 0.0)
                pbone.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
                pbone.rotation_euler = (0.0, 0.0, 0.0)
                pbone.scale = (1.0, 1.0, 1.0)

            # Reset all pose-bone custom properties to their defaults.
            # IMPORTANT: do NOT delete properties; deleting can break driver paths and UI sliders.
            _set_posebone_custom_props_to_defaults(pbone)

    # Create a new unified action and assign it
    base_name = "Preview_BaseLayer"
    new_action = bpy.data.actions.new(base_name)
    armature.animation_data.action = new_action

    # Insert keys for all pose bones at start/end (data API, no operators)
    if getattr(armature, "pose", None):
        scene.frame_set(start_frame)
        for pbone in armature.pose.bones:
            # Ensure custom properties are at default values at the exact moment we keyframe them.
            _set_posebone_custom_props_to_defaults(pbone)
            pbone.keyframe_insert(data_path="location")
            # Insert all common rotation representations; Blender will ignore non-applicable paths.
            pbone.keyframe_insert(data_path="rotation_quaternion")
            pbone.keyframe_insert(data_path="rotation_euler")
            pbone.keyframe_insert(data_path="scale")
            # Keyframe custom properties (sliders) so the base layer includes them.
            _keyframe_posebone_custom_props(pbone)

        scene.frame_set(end_frame)
        for pbone in armature.pose.bones:
            _set_posebone_custom_props_to_defaults(pbone)
            pbone.keyframe_insert(data_path="location")
            pbone.keyframe_insert(data_path="rotation_quaternion")
            pbone.keyframe_insert(data_path="rotation_euler")
            pbone.keyframe_insert(data_path="scale")
            _keyframe_posebone_custom_props(pbone)

    # Push Action to NLA
    armature.animation_data.action = None
    nla_track = armature.animation_data.nla_tracks.new()
    nla_track.name = base_name
    nla_strip = nla_track.strips.new(base_name, start_frame, new_action)
    nla_strip.blend_type = 'REPLACE'
    nla_strip.frame_start = start_frame
    nla_strip.frame_end = end_frame
    # Extrapolation: HOLD (best-effort; different Blender versions use different enum names)
    try:
        nla_strip.extrapolation = 'HOLD'
    except Exception:
        try:
            nla_strip.extrapolation = 'HOLD_FORWARD'
        except Exception:
            pass

    # Ensure this base track is evaluated first: put it at the bottom of the NLA stack.
    try:
        tracks = armature.animation_data.nla_tracks
        tracks.move(len(tracks) - 1, len(tracks) - 1)  # no-op if already last (keeps API warm)
        # The newly created track is last by default; enforce explicitly in case Blender changes behavior.
        tracks.move(tracks.find(nla_track.name), len(tracks) - 1)
    except Exception:
        pass

    # Restore previous state (pose transforms + custom props + active action/slot)
    if getattr(armature, "pose", None):
        for pbone in armature.pose.bones:
            st = stored_bone_state.get(pbone.name)
            if not st:
                continue
            if st.get("matrix_basis") is not None:
                try:
                    pbone.matrix_basis = st["matrix_basis"]
                except Exception:
                    pass
            # Restore pose-bone custom property values (do NOT delete properties).
            try:
                for k, v in st.get("custom_props", {}).items():
                    pbone[k] = v
            except Exception:
                pass

    try:
        if stored_pose_position is not None:
            armature.data.pose_position = stored_pose_position
    except Exception:
        pass

    try:
        armature.animation_data.action = stored_action
        if hasattr(armature.animation_data, "action_slot"):
            armature.animation_data.action_slot = stored_action_slot
        if stored_action_blend_type is not None and hasattr(armature.animation_data, "action_blend_type"):
            armature.animation_data.action_blend_type = stored_action_blend_type
    except Exception:
        pass

    # Restore the anim preview dropdown selection (last, since it has an update callback)
    try:
        if hasattr(armature, "hhp_anim_preview_props"):
            armature.hhp_anim_preview_props.action = stored_props_action
    except Exception:
        pass

    # Restore the user's current frame
    try:
        scene.frame_set(stored_frame)
    except Exception:
        pass

    try:
        armature.update_tag()
        bpy.context.view_layer.update()
    except Exception:
        pass


class HHP_OT_CreateBaseLayer(bpy.types.Operator):
    """Creates a new preview base layer and pushes it to the NLA. Useful for previewing add blend mode actions if armature has no NLA strips assigned"""
    bl_idname = "hhp.create_base_layer"
    bl_label = "Create Base layer"
    bl_description = "Creates a new preview base layer and pushes it to the NLA. Useful for previewing add blend mode actions if armature has no NLA strips assigned"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        """
        This operator is only valid if:
          1. An Armature is active, AND
          2. The Armature has NO existing NLA tracks (button is disabled if any tracks already exist).
        """
        ob = context.active_object
        if not ob or ob.type != 'ARMATURE':
            return False

        # Disable if any NLA tracks already exist (requested behavior)
        if ob.animation_data and getattr(ob.animation_data, "nla_tracks", None):
            if len(ob.animation_data.nla_tracks) > 0:
                return False
        return True

    def invoke(self, context, event):
        """Show a confirmation dialog to avoid accidental clicks."""
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        # Create the base layer action
        create_base_layer_action()

        # Also clear the selected action in the anim preview properties on the active armature (not on the scene)
        ob = context.active_object
        ob.hhp_anim_preview_props.action = None

        self.report({'INFO'}, "Preview_BaseLayer created and pushed to NLA.")
        return {'FINISHED'}


def update_action(self, context):
    """
    When a new Action is selected or cleared in the dropdown:
      - If an Action is selected, force Pose Position on the Armature
        and assign that Action as active, using the Action Slot system.
      - If cleared (None), clear the pose and the active action/slot.
    """
    ob = context.active_object
    if not ob or ob.type != 'ARMATURE':
        return

    # If the user selected a valid Action
    if self.action:
        ob.data.pose_position = 'POSE'
        ob.animation_data_create()

        action_to_assign = self.action
        ob.animation_data.action = action_to_assign # Assign the action itself

        target_slot = None
        if action_to_assign and action_to_assign.slots:
            target_slot = action_to_assign.slots.active
            # If no active slot, fall back to the first slot if available
            if not target_slot and len(action_to_assign.slots) > 0:
                target_slot = action_to_assign.slots[0]

        # Assign the determined slot (or None if no slots exist on the action)
        ob.animation_data.action_slot = target_slot

    else: # Action is cleared
        # Clear pose when action is cleared
        if ob.pose: # Check if pose bones exist
            for bone in ob.pose.bones:
                bone.location = (0, 0, 0)
                bone.rotation_quaternion = (1, 0, 0, 0)
                bone.rotation_euler = (0, 0, 0)
                bone.rotation_axis_angle = (0, 0, 1, 0)
                bone.scale = (1, 1, 1)

        ob.animation_data_create()
        ob.animation_data.action = None
        ob.animation_data.action_slot = None # Explicitly clear the slot reference

        # Update the view
        if context.view_layer:
            context.view_layer.update()


# New update function to update FK/IK constraint influence based on the slider value
def update_fkik_switch(self, context):
    # Determine desired influence from mode: "IK" -> 1.0, "FK" -> 0.0.
    desired_influence = 1.0 if self.fkik_mode == "IK" else 0.0
    mapping = {
        "lShin": ["IK"],
        "lFoot": ["Copy Rotation"],
        "lForearmBend": ["IK"],
        "lHand": ["Copy Rotation"],
        "rShin": ["IK"],
        "rFoot": ["Copy Rotation"],
        "rForearmBend": ["IK"],
        "rHand": ["Copy Rotation"],
        "lForearmTwist": ["Copy Rotation", "Damped Track"],
        "rForearmTwist": ["Copy Rotation", "Damped Track"]
    }
    for obj in context.selected_objects:
        if obj.type == 'ARMATURE':
            for bone_name, constraint_names in mapping.items():
                if bone_name in obj.pose.bones:
                    pbone = obj.pose.bones[bone_name]
                    for constr in pbone.constraints:
                        if constr.name in constraint_names:
                            constr.influence = desired_influence
                            # If keyframe toggle is enabled, insert a keyframe for influence.
                            if self.keyframe_ik_fk_switch:
                                constr.keyframe_insert(data_path="influence")
            # Set visibility of "Layer 31" in armature's data collections_all based on fkik_mode
            if "Layer 31" in obj.data.collections_all:
                obj.data.collections_all["Layer 31"].is_visible = True if self.fkik_mode == "FK" else False


class HHP_OT_ClearPose(bpy.types.Operator):
    """Reset pose to rest position"""
    bl_idname = "hhp.clear_pose"
    bl_label = "Clear Pose"
    bl_description = "Reset all bones to their rest position"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'ARMATURE'

    def execute(self, context):
        armature = context.active_object
        
        # Store current bone selection / active bone (best-effort).
        selected_bone_names = set()
        active_bone_name = None
        try:
            # Blender 5 no longer exposes Bone.select in all contexts; try pose selection first.
            if getattr(armature, "pose", None):
                for pbone in armature.pose.bones:
                    b = getattr(pbone, "bone", None)
                    if b and getattr(b, "select", False):
                        selected_bone_names.add(b.name)

            # Fallback for older versions / contexts where Bone.select exists.
            if not selected_bone_names:
                for b in armature.data.bones:
                    if getattr(b, "select", False):
                        selected_bone_names.add(b.name)

            active = getattr(armature.data.bones, "active", None)
            if active:
                active_bone_name = active.name
        except Exception:
            selected_bone_names = set()
            active_bone_name = None

        # Blender 5 is stricter about context for pose operators; using direct data API is the most robust.
        # matrix_basis represents the delta from rest pose; identity = rest pose transforms.
        for pbone in armature.pose.bones:
            try:
                pbone.matrix_basis.identity()
            except Exception:
                # Fallback for any edge cases (should be rare)
                pbone.location = (0.0, 0.0, 0.0)
                pbone.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
                pbone.rotation_euler = (0.0, 0.0, 0.0)
                pbone.scale = (1.0, 1.0, 1.0)

        # Restore selection / active bone (so the operator feels non-destructive).
        try:
            # Best-effort restore: only if selection RNA is available in this Blender version/context.
            if selected_bone_names and getattr(armature, "pose", None):
                for pbone in armature.pose.bones:
                    b = getattr(pbone, "bone", None)
                    if b and hasattr(b, "select"):
                        b.select = (b.name in selected_bone_names)

            if active_bone_name and active_bone_name in armature.data.bones and hasattr(armature.data.bones, "active"):
                armature.data.bones.active = armature.data.bones[active_bone_name]
        except Exception:
            pass

        # Update depsgraph/view.
        try:
            armature.update_tag()
        except Exception:
            pass
        try:
            context.view_layer.update()
        except Exception:
            pass
            
        return {'FINISHED'}


class HHP_AnimPreviewProperties(bpy.types.PropertyGroup):
    # Pointer to a Blender Action. Updating it triggers update_action().
    action: bpy.props.PointerProperty(
        type=bpy.types.Action,
        description="Select an Action to apply to the active Armature",
        update=update_action
    )

    # Boolean property for showing advanced options (toggleable via an icon)
    advanced_options: bpy.props.BoolProperty(
        name="",
        description="Advanced Options:\nShow or hide advanced features like the Base Layer button.",
        default=False
    )

    # New FK/IK mode selector property
    fkik_mode: bpy.props.EnumProperty(
        name="FK/IK Mode",
        description="Select IK or FK mode for designated bones",
        items=[
            ("IK", "IK", "Inverse Kinematics mode"),
            ("FK", "FK", "Forward Kinematics mode")
        ],
        default="IK",
        update=update_fkik_switch
    )

    # Keyframe toggle for the IK/FK switch (clean icon only)
    keyframe_ik_fk_switch: bpy.props.BoolProperty(
        name="",
        description="Keyframe IK/FK switch",
        default=False
    )

    # New property for proportion constraints influence
    proportion_influence: bpy.props.FloatProperty(
        name="Proportion Influence",
        description="Control the influence of all proportion constraints",
        default=1.0,
        min=0.0,
        max=1.0,
        subtype='FACTOR',  # This creates the blue fill effect
        update=lambda self, context: update_proportion_influence(self, context)
    )

    # Proportion Distribution: per-bone constraint toggles (these drive constraint mute/influence)
    propdist_enable_metatarsals_r: bpy.props.BoolProperty(
        name="",
        description="Enable the Proportion Distribution constraint on Metatarsals.r",
        default=True,
        update=lambda self, context: update_proportion_enabled(self, context),
    )
    propdist_scale_metatarsals_r: bpy.props.FloatProperty(
        name="",
        description="Set the Proportion Distribution min/max scale value for Metatarsals.r (applies to all axes)",
        default=1.1,
        min=0.01,
        max=2.0,
        step=0.1,
        update=lambda self, context: update_proportion_scale_values(self, context),
    )
    propdist_enable_metatarsals_l: bpy.props.BoolProperty(
        name="",
        description="Enable the Proportion Distribution constraint on Metatarsals.l",
        default=True,
        update=lambda self, context: update_proportion_enabled(self, context),
    )
    propdist_scale_metatarsals_l: bpy.props.FloatProperty(
        name="",
        description="Set the Proportion Distribution min/max scale value for Metatarsals.l (applies to all axes)",
        default=1.1,
        min=0.01,
        max=2.0,
        step=0.1,
        update=lambda self, context: update_proportion_scale_values(self, context),
    )
    propdist_enable_neckLower: bpy.props.BoolProperty(
        name="",
        description="Enable the Proportion Distribution constraint on neckLower",
        default=True,
        update=lambda self, context: update_proportion_enabled(self, context),
    )
    propdist_scale_neckLower: bpy.props.FloatProperty(
        name="",
        description="Set the Proportion Distribution min/max scale value for neckLower (applies to all axes)",
        default=1.1,
        min=0.01,
        max=2.0,
        step=0.1,
        update=lambda self, context: update_proportion_scale_values(self, context),
    )
    propdist_enable_root: bpy.props.BoolProperty(
        name="",
        description="Enable the Proportion Distribution constraint on root (if present)",
        default=True,
        update=lambda self, context: update_proportion_enabled(self, context),
    )
    propdist_scale_root: bpy.props.FloatProperty(
        name="",
        description="Set the Proportion Distribution min/max scale value for root (applies to all axes)",
        default=0.9,
        min=0.01,
        max=2.0,
        step=0.1,
        update=lambda self, context: update_proportion_scale_values(self, context),
    )
    propdist_enable_hip: bpy.props.BoolProperty(
        name="",
        description="Enable the Proportion Distribution constraint on hip (if present)",
        default=True,
        update=lambda self, context: update_proportion_enabled(self, context),
    )
    propdist_scale_hip: bpy.props.FloatProperty(
        name="",
        description="Set the Proportion Distribution min/max scale value for hip (applies to all axes)",
        default=0.9,
        min=0.01,
        max=2.0,
        step=0.1,
        update=lambda self, context: update_proportion_scale_values(self, context),
    )


def update_proportion_influence(self, context):
    """Update the influence of all proportion constraints on selected armatures.

    Note: This does NOT change constraint enabled state; that is handled by update_proportion_enabled().
    """
    for obj in context.selected_objects:
        if obj.type != 'ARMATURE' or not getattr(obj, "pose", None):
            continue
        for pose_bone in obj.pose.bones:
            for constraint in pose_bone.constraints:
                if "(HHP) Limit Scale - Proportions" in constraint.name and hasattr(constraint, "influence"):
                    constraint.influence = float(self.proportion_influence)


def update_proportion_enabled(self, context):
    """Enable/disable (mute/unmute) proportion constraints per bone, based on the UI toggles.

    Note: This does NOT change constraint influence; that is handled by update_proportion_influence().
    """
    bone_toggle_map = {
        "Metatarsals.r": "propdist_enable_metatarsals_r",
        "Metatarsals.l": "propdist_enable_metatarsals_l",
        "neckLower": "propdist_enable_neckLower",
        "root": "propdist_enable_root",
        "hip": "propdist_enable_hip",
    }

    for obj in context.selected_objects:
        if obj.type != 'ARMATURE' or not getattr(obj, "pose", None):
            continue
        for pose_bone in obj.pose.bones:
            prop_name = bone_toggle_map.get(pose_bone.name)
            enabled = True if not prop_name else bool(getattr(self, prop_name, True))

            for constraint in pose_bone.constraints:
                if "(HHP) Limit Scale - Proportions" in constraint.name and hasattr(constraint, "mute"):
                    constraint.mute = (not enabled)


def update_proportion_scale_values(self, context):
    """Update the min/max scale values for proportion constraints on selected armatures.

    Each bone uses a single scale value, written to all min/max axes of its LIMIT_SCALE constraint.
    """
    bone_scale_map = {
        "Metatarsals.r": "propdist_scale_metatarsals_r",
        "Metatarsals.l": "propdist_scale_metatarsals_l",
        "neckLower": "propdist_scale_neckLower",
        "root": "propdist_scale_root",
        "hip": "propdist_scale_hip",
    }

    axis_attrs = ("min_x", "min_y", "min_z", "max_x", "max_y", "max_z")

    for obj in context.selected_objects:
        if obj.type != 'ARMATURE' or not getattr(obj, "pose", None):
            continue

        for bone_name, prop_name in bone_scale_map.items():
            pose_bone = obj.pose.bones.get(bone_name)
            if not pose_bone:
                continue

            scale_value = float(getattr(self, prop_name, 1.0))
            for constraint in pose_bone.constraints:
                if "(HHP) Limit Scale - Proportions" not in constraint.name:
                    continue
                for attr in axis_attrs:
                    if hasattr(constraint, attr):
                        setattr(constraint, attr, scale_value)


class HHP_OT_RedistributeProportions(bpy.types.Operator):
    """Redistributes proportions of selected HHP armatures to a younger size by adding limit scale constraints to the relevant bones"""
    bl_idname = "hhp.redistribute_proportions"
    bl_label = "Redistribute Proportions"
    bl_description = "Redistributes proportions of selected HHP armatures to a younger size by adding limit scale constraints to the relevant bones"
    bl_options = {'REGISTER', 'UNDO'}

    # Mode selector for choosing between root and hip
    bone_mode: bpy.props.EnumProperty(
        name="Bone Mode",
        description="Choose which bone to use for downscale constraint",
        items=[
            ("ROOT", "Root", "Apply downscale to the root bone"),
            ("HIP", "Hip", "Apply downscale to the hip bone")
        ],
        default="ROOT"
    )

    @classmethod
    def poll(cls, context):
        # Check if any armatures are selected
        if not context.selected_objects or not any(obj.type == 'ARMATURE' for obj in context.selected_objects):
            return False
        
        # Check if any selected armature has the required bones
        required_bones = {"Metatarsals.r", "Metatarsals.l", "neckLower"}
        # Add the required bones based on mode
        root_bones = {"root"}
        hip_bones = {"hip"}
        
        for obj in context.selected_objects:
            if obj.type == 'ARMATURE':
                # Check basic required bones
                if all(bone in obj.pose.bones for bone in required_bones):
                    # Check if either root or hip is present
                    if any(bone in obj.pose.bones for bone in root_bones) or any(bone in obj.pose.bones for bone in hip_bones):
                        return True
        return False

    def execute(self, context):
        selected_armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
        
        if not selected_armatures:
            self.report({'WARNING'}, "An HHP armature needs to be selected")
            return {'CANCELLED'}
        
        # Check if any armature has the required bones
        required_bones = {"Metatarsals.r", "Metatarsals.l", "neckLower"}
        valid_armatures = []
        for armature in selected_armatures:
            if all(bone in armature.pose.bones for bone in required_bones):
                # Check if the selected mode's bone exists
                downscale_bone = "root" if self.bone_mode == "ROOT" else "hip"
                if downscale_bone in armature.pose.bones:
                    valid_armatures.append(armature)
        
        if not valid_armatures:
            self.report({'WARNING'}, f"No valid HHP armatures with required bones including '{self.bone_mode.lower()}' found")
            return {'CANCELLED'}
        
        for armature in valid_armatures:
            # NOTE: Avoid bpy.ops (mode switching / selection) — Blender 5 is stricter about operator context.
            downscale_bone = "root" if self.bone_mode == "ROOT" else "hip"

            props = getattr(armature, "hhp_anim_preview_props", None)
            # Reset per-bone dial values to defaults when redistributing (requested behavior).
            if props:
                props.propdist_scale_metatarsals_r = 1.1
                props.propdist_scale_metatarsals_l = 1.1
                props.propdist_scale_neckLower = 1.1
                # Keep both defaults in sync; only the active downscale bone is used for this run.
                props.propdist_scale_root = 0.9
                props.propdist_scale_hip = 0.9

            bones_to_scale = {
                "Metatarsals.r": getattr(props, "propdist_scale_metatarsals_r", 1.1) if props else 1.1,
                "Metatarsals.l": getattr(props, "propdist_scale_metatarsals_l", 1.1) if props else 1.1,
                "neckLower": getattr(props, "propdist_scale_neckLower", 1.1) if props else 1.1,
                downscale_bone: getattr(props, "propdist_scale_root", 0.9) if (props and downscale_bone == "root") else (
                    getattr(props, "propdist_scale_hip", 0.9) if props else 0.9
                ),
            }

            for bone_name, scale_factor in bones_to_scale.items():
                pose_bone = armature.pose.bones.get(bone_name)
                if not pose_bone:
                    continue

                # Remove any existing "(HHP) Limit Scale - Proportions" constraint(s)
                for c in list(pose_bone.constraints):
                    if c.name == "(HHP) Limit Scale - Proportions":
                        pose_bone.constraints.remove(c)

                const = pose_bone.constraints.new('LIMIT_SCALE')
                const.name = "(HHP) Limit Scale - Proportions"

                # Enable both min and max for all axes (guarded for Blender RNA differences)
                for attr in ("use_min_x", "use_min_y", "use_min_z", "use_max_x", "use_max_y", "use_max_z"):
                    if hasattr(const, attr):
                        setattr(const, attr, True)

                # Set both min and max to the scale factor
                for attr in ("min_x", "min_y", "min_z", "max_x", "max_y", "max_z"):
                    if hasattr(const, attr):
                        setattr(const, attr, float(scale_factor))

                if hasattr(const, "owner_space"):
                    const.owner_space = 'LOCAL'
                if hasattr(const, "use_transform_limit"):
                    const.use_transform_limit = True
                if hasattr(const, "influence"):
                    const.influence = 1.0

            # Ensure Blender evaluates the new constraints.
            try:
                armature.update_tag()
            except Exception:
                pass

            # Ensure the UI slider snaps to full influence when this operator is run (requested behavior).
            # This also re-applies influences through the property's update callback when applicable.
            try:
                if hasattr(armature, "hhp_anim_preview_props"):
                    armature.hhp_anim_preview_props.proportion_influence = 1.0
            except Exception:
                pass

        try:
            context.view_layer.update()
        except Exception:
            pass
            
        mode_name = "Root" if self.bone_mode == "ROOT" else "Hip"
        self.report({'INFO'}, f"Added proportion constraints to {len(valid_armatures)} armature(s) using {mode_name} mode")
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        # Create a horizontal row for the mode selector
        row = layout.row(align=True)
        row.label(text="Downscale Bone:")
        row.prop(self, "bone_mode", expand=True)


class HHP_OT_RemoveProportionDistribution(bpy.types.Operator):
    """Remove the proportion distribution constraints from selected HHP armatures"""
    bl_idname = "hhp.remove_proportion_distribution"
    bl_label = "Clear Proportions"
    bl_description = (
        "Remove all '(HHP) Limit Scale - Proportions' constraints from selected armatures "
        "and reset the Proportion Influence slider to 0"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not context.selected_objects:
            return False
        for obj in context.selected_objects:
            if obj.type != 'ARMATURE' or not getattr(obj, "pose", None):
                continue
            for pose_bone in obj.pose.bones:
                if any("(HHP) Limit Scale - Proportions" in c.name for c in pose_bone.constraints):
                    return True
        return False

    def execute(self, context):
        armatures = [obj for obj in context.selected_objects if obj.type == 'ARMATURE']
        if not armatures:
            self.report({'WARNING'}, "Select at least one armature")
            return {'CANCELLED'}

        removed_total = 0
        affected_armatures = 0

        for armature in armatures:
            if not getattr(armature, "pose", None):
                continue

            removed_this_armature = 0
            for pose_bone in armature.pose.bones:
                for c in list(pose_bone.constraints):
                    if "(HHP) Limit Scale - Proportions" in c.name:
                        pose_bone.constraints.remove(c)
                        removed_total += 1
                        removed_this_armature += 1

            if removed_this_armature:
                affected_armatures += 1
                # Reset slider (requested behavior)
                try:
                    if hasattr(armature, "hhp_anim_preview_props"):
                        armature.hhp_anim_preview_props.proportion_influence = 0.0
                except Exception:
                    pass
                try:
                    armature.update_tag()
                except Exception:
                    pass

        try:
            context.view_layer.update()
        except Exception:
            pass

        if removed_total == 0:
            self.report({'INFO'}, "No proportion distribution constraints found")
        else:
            self.report({'INFO'}, f"Removed {removed_total} constraint(s) from {affected_armatures} armature(s)")
        return {'FINISHED'}


def draw_anim_preview_box(layout, context):
    """
    Draws the anim preview box and its widgets.
    Should be called from a panel's draw() method.
    Only draws if the active object is an armature.
    """
    ob = context.active_object

    # Only show the preview box if an armature is active
    if not ob or ob.type != 'ARMATURE':
        return

    box = layout.box()
    box.label(text="Preview Animation")

    # Use active object's custom property instead of the scene's
    scene_props = ob.hhp_anim_preview_props

    col = box.column(align=True)
    row = col.row(align=True)

    # Toggle using a wrench icon
    row.prop(
        scene_props,
        "advanced_options",
        icon='MODIFIER',
        text="",
        emboss=True,
        toggle=True
    )
    # Action selector
    row.prop(scene_props, "action", text="")

    # Blend mode: ensure animation_data exists
    if not ob.animation_data:
        ob.animation_data_create()
    row.prop(ob.animation_data, "action_blend_type", text="")

    # FK/IK mode selector and keyframe checkbox row
    row_fkik = col.row(align=True)
    row_fkik.prop(scene_props, "keyframe_ik_fk_switch", text="", icon='KEYFRAME')
    row_fkik.prop(scene_props, "fkik_mode", expand=True)

    # If advanced options are enabled, show additional buttons
    if scene_props.advanced_options:
        row = col.row(align=True)
        row.operator("hhp.clear_pose", text="Clear Pose")  # Clear Pose first
        row.operator("hhp.create_base_layer", text="Create Base layer")  # Base layer second

        # Proportion Distribution (own box)
        prop_box = col.box()
        prop_box.label(text="Proportion Distribution")

        # Gather which bones currently have the proportion constraint, so we only show relevant toggles.
        constrained_bones = set()
        for obj in context.selected_objects:
            if obj.type != 'ARMATURE' or not getattr(obj, "pose", None):
                continue
            for pose_bone in obj.pose.bones:
                if any("(HHP) Limit Scale - Proportions" in c.name for c in pose_bone.constraints):
                    constrained_bones.add(pose_bone.name)

        has_proportion_constraints = bool(constrained_bones)

        # COLUMN layout with rows:
        # row1 = buttons, row2 = slider, row3+ = toggles grid (full-width)
        prop_col = prop_box.column(align=True)

        # row1: Distribution buttons
        row1 = prop_col.row(align=True)
        row1.operator(
            "hhp.redistribute_proportions",
            text="Redistribute Proportions",
            icon='CONSTRAINT_BONE',
        )
        row1.operator(
            "hhp.remove_proportion_distribution",
            text="Clear Proportions",
            icon='TRASH',
        )

        if has_proportion_constraints:
            # row2: Influence slider
            row2 = prop_col.row(align=True)
            row2.prop(scene_props, "proportion_influence", text="Influence")

            # row3+: Per-bone toggles (3 per row, full-width grid for consistent alignment)
            toggle_defs = []
            if "Metatarsals.r" in constrained_bones:
                toggle_defs.append(("propdist_enable_metatarsals_r", "propdist_scale_metatarsals_r", "Metatarsals.r"))
            if "Metatarsals.l" in constrained_bones:
                toggle_defs.append(("propdist_enable_metatarsals_l", "propdist_scale_metatarsals_l", "Metatarsals.l"))
            if "neckLower" in constrained_bones:
                toggle_defs.append(("propdist_enable_neckLower", "propdist_scale_neckLower", "neckLower"))
            if "root" in constrained_bones:
                toggle_defs.append(("propdist_enable_root", "propdist_scale_root", "root"))
            if "hip" in constrained_bones:
                toggle_defs.append(("propdist_enable_hip", "propdist_scale_hip", "hip"))

            # Row 3+: EXACTLY 3 per row: each cell = toggle + per-bone scale slider under it
            for i in range(0, len(toggle_defs), 3):
                row_tog = prop_col.row(align=True)
                row_tog.alignment = 'EXPAND'

                chunk = toggle_defs[i:i + 3]
                for toggle_prop, scale_prop, label in chunk:
                    cell = row_tog.column(align=True)
                    cell.prop(
                        scene_props,
                        toggle_prop,
                        text=label,
                        icon='BONE_DATA',
                        toggle=True,
                    )
                    cell.prop(
                        scene_props,
                        scale_prop,
                        text="",
                    )


# Registration
classes = (
    HHP_OT_CreateBaseLayer,
    HHP_OT_ClearPose,
    HHP_AnimPreviewProperties,
    HHP_OT_RedistributeProportions,
    HHP_OT_RemoveProportionDistribution,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    # Attach the anim preview properties to every Blender Object (for armatures)
    bpy.types.Object.hhp_anim_preview_props = bpy.props.PointerProperty(type=HHP_AnimPreviewProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    # Remove the property from Blender Object
    del bpy.types.Object.hhp_anim_preview_props 