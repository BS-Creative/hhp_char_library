import bpy
from mathutils import Vector, Euler
from bpy.types import Operator, PropertyGroup, UIList, Panel
from bpy.props import PointerProperty, BoolProperty, CollectionProperty, EnumProperty, IntProperty
import random

class FLUID_EffectorItem(PropertyGroup):
    object: PointerProperty(
        name="Fluid Collision Object",
        description="Mesh to use as fluid effector",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'MESH'
    )

class FLUID_UL_effector_list(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "object", text="")

class FLUID_OT_add_effector(Operator):
    bl_idname = "fluid.add_effector"
    bl_label = "Add Effector"
    bl_description = "Add a new effector slot"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        context.scene.fluid_effectors.effector_list.add()
        return {'FINISHED'}

class FLUID_OT_remove_effector(Operator):
    bl_idname = "fluid.remove_effector"
    bl_label = "Remove Effector"
    bl_description = "Remove selected effector"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        effectors = context.scene.fluid_effectors
        if effectors.active_index >= 0 and effectors.active_index < len(effectors.effector_list):
            effectors.effector_list.remove(effectors.active_index)
            if effectors.active_index > 0:
                effectors.active_index -= 1
        return {'FINISHED'}

class OBJECT_OT_setup_cmn_simulation(Operator):
    bl_idname = "object.setup_cmn_simulation"
    bl_label = "Setup Simulation (White fluid - CMN)"
    bl_description = "Creates a white fluid simulation setup with domain, emitter and collision surface"
    bl_options = {'REGISTER', 'UNDO'}
    
    # Internal cache for selected objects at invoke time
    _selected_objects_at_invoke: list = []
    
    # USER SETTINGS
    DOMAIN_SIDE = 0.40
    DOMAIN_RES = 20
    FLOW_RADIUS = 0.02
    FLOW_SPEED = Vector((0.0, 5.0, 0.0))  # Updated to match human ejaculation velocity (approx. 5 m/s)
    SKIN_NAME = "Skin"
    PLANE_SIZE = 0.35
    PLANE_TILT_DEG = 10
    STICK_SHELL = 0.003
    SURFACE_TENSION = 0.073  # Surface tension of human semen (N/m)
    REFERENCE_FPS = 24.0
    
    # Scientific data for ejaculation
    # Average male ejaculation consists of 10-15 contractions
    # Initial contractions occur approximately every 0.6 seconds
    # The interval increases by about 0.1 seconds per contraction
    # Second contraction is typically the largest (40% of total volume)
    # Total ejaculation process lasts several seconds
    EJAC_NUM_PULSES = 12      # Average number of contractions
    EJAC_INITIAL_INTERVAL = 0.6  # Initial interval between contractions (seconds)
    EJAC_INTERVAL_INCREASE = 0.1  # Increase in interval per contraction (seconds)
    EJAC_FADEOUT_TIME = 2.0   # Time to fade out after last pulse (seconds)
    
    use_selection: BoolProperty(
        name="Use Selection as Fluid Collision",
        description="Use currently selected mesh objects as fluid effectors (otherwise use the object picker below)",
        default=True # Default is True, but adjusted in invoke if nothing is selected
    )
    
    quality_level: EnumProperty(
        name="Quality Level",
        description="Quality presets for simulation resolution",
        items=[
            ('INSTANT', "Instant", "16 divisions, fixed timesteps (2). Best for quick testing and rapid iteration"),
            ('FAST', "Fast", "20 divisions, adaptive timesteps (4-8). Good for general work and previews"),
            ('PREVIEW', "Preview", "40 divisions, adaptive timesteps (4-8). Balanced quality/speed for pre-final work"),
            ('HIGH', "High", "64 divisions, adaptive timesteps (4-8). For high quality final simulations"),
            ('ULTRA', "Ultra", "128 divisions, adaptive timesteps (4-8). For maximum quality renders")
        ],
        default='FAST'
    )
    
    # Properties for UI
    cmn_method: EnumProperty(
        name="CMN Method",
        description="Method for CMN fluid simulation",
        items=[
            ('CONTINUOUS', "Continuous", "Continuous flow of fluid"),
            ('PULSE', "Pulse", "Pulsating flow simulating ejaculation")
        ],
        default='PULSE'
    )
    
    frame_start: IntProperty(
        name="Start Frame",
        description="Frame to start the fluid simulation",
        default=1,
        min=1
    )
    
    frame_end: IntProperty(
        name="End Frame",
        description="Frame to end the fluid simulation",
        default=250,
        min=1
    )
    
    flow_end_frame: IntProperty(
        name="Flow End Frame",
        description="Frame to stop fluid inflow (simulation will continue until End Frame)",
        default=200,  # Will be randomized in invoke
        min=1
    )
    
    smooth_iterations: IntProperty(
        name="Smooth",
        description="This is how many times the fluid will be smoothed via the modifier",
        default=10,
        min=0,
        max=100
    )

    flow_velocity_multiplier: bpy.props.FloatProperty(
        name="Flow Velocity Multiplier",
        description="Multiplies the inflow velocity used by the simulation (applies to both Blender Default and Flip Fluids modes)",
        default=1.00,
        min=0.00,
        max=100.00,
        soft_max=2.00,
        step=0.1,
        precision=2
    )
    
    flow_pulse_duration: bpy.props.FloatProperty(
        name="Flow Pulse Duration",
        description="Multiplies how long each pulse stays enabled (applies to both Blender Default and Flip Fluids modes)",
        default=1.00,
        min=0.00,
        max=100.00,
        soft_max=2.00,
        step=0.1,
        precision=2
    )

    def _get_scene_fps(self, scene=None):
        scene = scene or bpy.context.scene
        fps = float(scene.render.fps)
        fps_base = float(scene.render.fps_base) if scene.render.fps_base else 1.0
        return fps / fps_base

    def _fps_scale_from_60(self, scene=None):
        """
        Convert values authored for a 60fps baseline to the current scene FPS.
        """
        return self._get_scene_fps(scene) / 60.0

    def _scaled_flow_velocity_y(self, base_velocity_y):
        """
        Scale velocity to be FPS independent based on a 60fps-authored baseline,
        then apply the user velocity multiplier.
        """
        return float(base_velocity_y) * float(self.flow_velocity_multiplier) * self._fps_scale_from_60()

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        # Quality Level dropdown above all other controls
        row = layout.row(align=True)
        row.prop(self, "quality_level", text="Quality Level")
        
        # Create a column with align=True to stack elements vertically
        col = layout.column(align=True)
        
        # Method selector in a row to make options side by side
        row = col.row(align=True)
        row.prop(self, "cmn_method", expand=True)
        
        # Frame range controls in same column
        row = col.row(align=True)
        row.prop(self, "frame_start")
        row.prop(self, "frame_end")
        
        # Flow end frame and smooth iterations controls in same row
        row = col.row(align=True)
        row.prop(self, "flow_end_frame")
        row.prop(self, "smooth_iterations")

        # Flow velocity + pulse duration multipliers (requested)
        row = col.row(align=True)
        row.prop(self, "flow_velocity_multiplier", text="Flow Velocity Multiplier")
        row.prop(self, "flow_pulse_duration", text="Flow Pulse Duration")
        
        # Original settings (with separator to separate from the tightly grouped controls above)
        layout.separator()
        row = layout.row()
        row.prop(self, "use_selection")
        
        # Ensure there is always one effector item available for the UI
        if len(scene.fluid_effectors.effector_list) == 0:
             scene.fluid_effectors.effector_list.add()
             
        row = layout.row()
        # Grey out the slot if use_selection is True
        row.enabled = not self.use_selection 
        # Display the single effector slot
        if scene.fluid_effectors.effector_list:
             # Use "Fluid Collision" as the label
             row.prop(scene.fluid_effectors.effector_list[0], "object", text="") 
        else:
             row.label(text="Error: No effector slot found!") # Should not happen
    
    def invoke(self, context, event):
        # Store the current selection when the operator is invoked
        self._selected_objects_at_invoke = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        # Set default frames from scene
        self.frame_start = context.scene.frame_current
        self.frame_end = context.scene.frame_end
        
        # Set random flow end between 6-10 seconds (framerate independent)
        fps = context.scene.render.fps
        random_seconds = 6.0 + random.random() * 4.0  # Between 6-10 seconds
        flow_end_frames = int(random_seconds * fps)
        self.flow_end_frame = min(self.frame_start + flow_end_frames, self.frame_end - int(0.5 * fps))
        
        # Set default for use_selection based on whether anything is selected
        if not self._selected_objects_at_invoke:
            self.use_selection = False
        else:
            self.use_selection = True # Explicitly set True if selection exists
            
        # Ensure there's an effector item for the UI
        if len(context.scene.fluid_effectors.effector_list) == 0:
            context.scene.fluid_effectors.effector_list.add()
            
        return context.window_manager.invoke_props_dialog(self, width=400)
    
    def deselect_all(self):
        for o in bpy.data.objects:
            o.select_set(False)

    # ----------------------------
    # FLIP Fluids setup helpers
    # ----------------------------
    def _flip_fluids_available(self):
        # Check for Flip Fluids property groups registered on Scene/Object.
        return hasattr(bpy.types.Scene, "flip_fluid") and hasattr(bpy.types.Object, "flip_fluid")

    def _get_flip_resolution_for_quality(self):
        """
        Map our quality preset to FLIP Fluids 'resolution' (voxels on longest side).
        User requirement: ULTRA must be 320.
        """
        # Keep a simple, predictable ramp that matches the existing Blender-fluid presets,
        # scaled so that 128 -> 320 (x2.5).
        if self.quality_level == 'INSTANT':
            return 40
        if self.quality_level == 'FAST':
            return 50
        if self.quality_level == 'PREVIEW':
            return 100
        if self.quality_level == 'HIGH':
            return 160
        # ULTRA
        return 320

    def _flip_select_active(self, obj):
        """Select + set active object safely."""
        self.deselect_all()
        try:
            obj.select_set(True)
        except RuntimeError:
            # Object may exist but not be linked into the current scene/view layer
            self._ensure_object_in_current_scene(obj, bpy.context)
            obj.select_set(True)
        bpy.context.view_layer.objects.active = obj

    def _ensure_object_in_current_scene(self, obj, context):
        """
        Ensure object is linked to the current scene collections so it can be selected
        in the current ViewLayer.
        """
        scene = context.scene

        # Link into scene collection if not already linked to this scene.
        try:
            if obj.name not in scene.objects:
                scene.collection.objects.link(obj)
        except Exception:
            pass

        # Also link into the active layer collection (helps keep it visible in many setups).
        try:
            active_coll = context.view_layer.active_layer_collection.collection
            if obj.name not in active_coll.objects:
                active_coll.objects.link(obj)
        except Exception:
            pass

        # If any of the collections containing this object are excluded in the view layer,
        # un-exclude them so selection is allowed.
        try:
            target_colls = {c for c in getattr(obj, "users_collection", [])}
            if target_colls:
                def walk(layer_coll):
                    if layer_coll.collection in target_colls:
                        layer_coll.exclude = False
                    for child in layer_coll.children:
                        walk(child)
                walk(context.view_layer.layer_collection)
        except Exception:
            pass

        try:
            context.view_layer.update()
        except Exception:
            pass

    def _flip_fluid_add_and_set_type(self, obj, object_type_identifier):
        """
        Ensure the object is registered with FLIP Fluids and set its object type.
        Flip Fluids requires running flip_fluid_add() to mark the object as active.
        """
        self._flip_select_active(obj)

        # Register object with the addon (sets flip_fluid.is_active, etc.)
        try:
            bpy.ops.flip_fluid_operators.flip_fluid_add()
        except Exception:
            # If the operator isn't available for some reason, fall back to direct flag.
            pass

        # Ensure the object is marked active for FLIP Fluids UI/polling logic.
        try:
            obj.flip_fluid.is_active = True
        except Exception:
            pass

        # Set type (Domain/Inflow/Obstacle/etc.)
        obj.flip_fluid.object_type = object_type_identifier

        try:
            bpy.context.view_layer.update()
        except Exception:
            pass

    def _apply_flip_domain_settings(self, domain_obj):
        dprops = domain_obj.flip_fluid.domain

        # Only change resolution based on quality preset (requested).
        dprops.simulation.resolution = self._get_flip_resolution_for_quality()

        # Set simulation frame range to match operator Start/End (requested follow-up).
        # Flip Fluids defaults to timeline; this just switches it to Custom and sets the range.
        try:
            dprops.simulation.frame_range_mode = 'FRAME_RANGE_CUSTOM'
            dprops.simulation.frame_range_custom.value_min = int(self.frame_start)
            dprops.simulation.frame_range_custom.value_max = int(self.frame_end)
        except Exception:
            pass

        # Visualize grid (requested).
        try:
            dprops.debug.grid_display_mode = 'GRID_DISPLAY_SIMULATION'
            dprops.debug.display_simulation_grid = True
        except Exception:
            pass

    def _apply_flip_inflow_settings(self, inflow_obj):
        iprops = inflow_obj.flip_fluid.inflow

        # Enable inflow (requested).
        iprops.is_enabled = True

        # Set speed/velocity (requested) to match Blender default branch:
        # Blender Mantaflow uses f.velocity_coord = Vector((0.0, 5.0, 0.0))
        iprops.inflow_velocity_mode = 'INFLOW_VELOCITY_MANUAL'
        iprops.inflow_velocity = Vector((0.0, self._scaled_flow_velocity_y(5.0), 0.0))

        # Add object velocity to inflow (requested).
        iprops.append_object_velocity = True

        # Animated enabled (requested): export inflow mesh as animated.
        iprops.export_animated_mesh = True

    def _setup_flip_obstacle(self, obj):
        # Set selected meshes as FLIP Fluids obstacles
        if not hasattr(obj, "flip_fluid"):
            return
        self._flip_fluid_add_and_set_type(obj, 'TYPE_OBSTACLE')

    def _make_flip_domain(self):
        scene = bpy.context.scene

        # Reuse an existing FLIP domain if one is already set (Flip Fluids supports only 1).
        try:
            if scene.flip_fluid.is_domain_object_set():
                dom = scene.flip_fluid.get_domain_object()
                if dom:
                    dom.name = "CMN_Fluid_Domain"
                    # Ensure it is linked into the current scene/view layer for selection ops
                    self._ensure_object_in_current_scene(dom, bpy.context)
                    self._apply_flip_domain_settings(dom)
                    return dom
        except Exception:
            pass

        # Create cube at 3D cursor location (same sizing as Blender-fluid branch)
        bpy.ops.mesh.primitive_cube_add(size=self.DOMAIN_SIDE)
        dom = bpy.context.active_object
        dom.name = "CMN_Fluid_Domain"
        # Ensure linked into current scene/view layer
        self._ensure_object_in_current_scene(dom, bpy.context)

        # Set as Flip Fluids domain (initializes properties)
        self._flip_fluid_add_and_set_type(dom, 'TYPE_DOMAIN')

        # Apply requested domain settings
        self._apply_flip_domain_settings(dom)

        return dom

    def _make_flip_inflow(self, domain_obj):
        # Create a manifold sphere inflow in the center of the domain (requested).
        flow_position = domain_obj.location.copy()

        bpy.ops.mesh.primitive_uv_sphere_add(
            radius=self.FLOW_RADIUS,
            location=flow_position
        )
        inflow = bpy.context.active_object
        inflow.name = "CMN_Flow"
        # Ensure linked into current scene/view layer
        self._ensure_object_in_current_scene(inflow, bpy.context)

        self._flip_fluid_add_and_set_type(inflow, 'TYPE_INFLOW')
        self._apply_flip_inflow_settings(inflow)

        # Configure inflow object display (similar intent as Blender branch)
        inflow.hide_render = True
        inflow.display_type = 'WIRE'
        inflow.show_name = True

        return inflow

    def _setup_flip_continuous_flow(self, inflow_obj, frame_start, frame_end, flow_end_frame):
        """Continuous emission: toggle is_enabled on/off, keep velocity constant."""
        iprops = inflow_obj.flip_fluid.inflow

        # Ensure manual velocity matches Blender default
        iprops.inflow_velocity_mode = 'INFLOW_VELOCITY_MANUAL'
        iprops.inflow_velocity = Vector((0.0, self._scaled_flow_velocity_y(5.0), 0.0))
        inflow_obj.keyframe_insert(data_path='flip_fluid.inflow.inflow_velocity', frame=frame_start)

        # Off before start
        iprops.is_enabled = False
        inflow_obj.keyframe_insert(data_path='flip_fluid.inflow.is_enabled', frame=frame_start - 1)

        # On at start
        iprops.is_enabled = True
        inflow_obj.keyframe_insert(data_path='flip_fluid.inflow.is_enabled', frame=frame_start)

        # Off at end
        iprops.is_enabled = False
        inflow_obj.keyframe_insert(data_path='flip_fluid.inflow.is_enabled', frame=flow_end_frame)

    def _setup_flip_pulse_flow(self, inflow_obj, frame_start, frame_end, flow_end_frame):
        """Pulsating emission: toggle is_enabled and keyframe inflow velocity (matches Blender default branch)."""
        iprops = inflow_obj.flip_fluid.inflow
        fps = bpy.context.scene.render.fps

        # Calculate pulse timing (same timing logic as Blender-fluid branch)
        pulse_frames = []
        current_time = 0.0
        interval = self.EJAC_INITIAL_INTERVAL

        for i in range(self.EJAC_NUM_PULSES):
            pulse_frame = frame_start + int(current_time * fps)
            if pulse_frame >= flow_end_frame:
                break
            pulse_frames.append(pulse_frame)
            variation = 0.9 + 0.2 * random.random()
            current_time += interval * variation
            interval += self.EJAC_INTERVAL_INCREASE

        # Ensure manual velocity mode
        iprops.inflow_velocity_mode = 'INFLOW_VELOCITY_MANUAL'

        # Start off
        iprops.is_enabled = False
        inflow_obj.keyframe_insert(data_path='flip_fluid.inflow.is_enabled', frame=frame_start - 1)

        base_velocity = Vector((0.0, self._scaled_flow_velocity_y(5.0), 0.0))

        for i, pulse_frame in enumerate(pulse_frames):
            # Turn on
            iprops.is_enabled = True
            inflow_obj.keyframe_insert(data_path='flip_fluid.inflow.is_enabled', frame=pulse_frame)

            # Pulse speed curve (mirrors Blender branch intent)
            pulse_strength = 1.0
            if i in (0, 1):
                pulse_strength = 1.0
            elif i < 4:
                pulse_strength = 0.9
            elif i < 7:
                pulse_strength = 0.7
            else:
                pulse_strength = max(0.2, 0.6 - (i - 7) * 0.1)

            variation = 0.95 + 0.1 * random.random()
            pulse_strength *= variation

            iprops.inflow_velocity = base_velocity * pulse_strength
            inflow_obj.keyframe_insert(data_path='flip_fluid.inflow.inflow_velocity', frame=pulse_frame)

            # Turn off after short duration
            # pulse duration was authored in frames for a 60fps baseline; convert to seconds then back to frames
            base_pulse_duration_60fps_frames = max(3, 6 - (i * 0.3))
            base_pulse_duration_seconds = base_pulse_duration_60fps_frames / 60.0
            pulse_duration = int(base_pulse_duration_seconds * self._get_scene_fps() * float(self.flow_pulse_duration))
            iprops.is_enabled = False
            inflow_obj.keyframe_insert(data_path='flip_fluid.inflow.is_enabled', frame=pulse_frame + int(pulse_duration))

        # Ensure off at flow end
        iprops.is_enabled = False
        inflow_obj.keyframe_insert(data_path='flip_fluid.inflow.is_enabled', frame=flow_end_frame)
    
    def make_domain(self):
        scene = bpy.context.scene
        actual_fps = scene.render.fps / scene.render.fps_base
        time_scale = actual_fps / self.REFERENCE_FPS
    
        # Create cube at 3D cursor location
        bpy.ops.mesh.primitive_cube_add(
            size=self.DOMAIN_SIDE
            # removed location argument to use 3D cursor
        )
        dom = bpy.context.active_object
        # Rename Domain
        dom.name = "CMN_Fluid_Domain"
    
        md = dom.modifiers.new("FluidDomain", "FLUID")
        md.fluid_type = "DOMAIN"
        d = md.domain_settings
    
        d.domain_type = "LIQUID"
        d.simulation_method = "APIC"
        # Set resolution divisions based on quality level
        if self.quality_level == 'INSTANT':
            d.resolution_max = 16
            d.timesteps_min = 2
            d.timesteps_max = 2
        elif self.quality_level == 'FAST':
            d.resolution_max = self.DOMAIN_RES
        elif self.quality_level == 'PREVIEW':
            d.resolution_max = 40
        elif self.quality_level == 'HIGH':
            d.resolution_max = 64
        else:  # 'ULTRA'
            d.resolution_max = 128
        d.flip_ratio = 1.0
        
        # Improve simulation quality with better time steps
        d.use_adaptive_timesteps = True
        d.cfl_condition = 4.0  # Default is 7.0, lower is more accurate but slower
        
        # Only set these if not in INSTANT mode (which has its own specific settings)
        if self.quality_level != 'INSTANT':
            d.timesteps_min = 4  # Increased from 2 to 4 for smoother simulation
            d.timesteps_max = 8  # Default is 4, increase for higher quality
        
        d.time_scale = time_scale
    
        # Enable border collisions for all sides
        for side in ("front", "back", "left", "right", "top", "bottom"):
            setattr(d, "use_collision_border_" + side, True)
    
        # Settings to match real-human semen properties
        d.use_diffusion = True
        d.viscosity_base = 5.0  # Human semen viscosity is typically 3-7 cP
        d.viscosity_exponent = 4  # Lower than default to match medium viscosity
        d.surface_tension = 0.02  # Updated from self.SURFACE_TENSION
        d.use_viscosity = True
        d.viscosity_value = 0.02  # Updated from 0.01
    
        d.particle_number = 3
        d.particle_band_width = 12.0  # Updated from 3.0
        d.particle_randomness = 5.0  # Added parameter
        d.use_mesh = True
        d.mesh_scale = 2
        d.mesh_generator = "IMPROVED"
        d.use_speed_vectors = True
    
        d.cache_type = "REPLAY"
        # Match fluid simulation frames to scene frames
        d.cache_frame_start = self.frame_start
        d.cache_frame_end = self.frame_end
    
        for m in dom.modifiers:
            if m.type == "PARTICLE_SYSTEM":
                m.show_viewport = False
                m.show_render = False
    
        return dom
    
    def make_flow(self, domain):
        # Get domain position and dimensions
        domain_half_size = self.DOMAIN_SIDE / 2
        
        # Create the flow object at the back of the domain (negative Y)
        # positioned slightly forward from the domain boundary for better fluid spawning
        flow_position = domain.location.copy()
        flow_position.y -= (domain_half_size - 0.04)  # Move to near the back of the domain, but 0.04 units forward
        
        # Create circular plane
        bpy.ops.mesh.primitive_circle_add(
            radius=self.FLOW_RADIUS,
            fill_type='NGON',
            location=flow_position
        )
        flow = bpy.context.active_object
        
        # Set exact dimensions to ensure consistent size
        flow.dimensions = (0.02, 0.02, 0.02)
        
        # Rotate to face positive Y
        flow.rotation_euler = (-1.5707963267948966, 0, 0)  # -90 degrees in X to face positive Y
        
        # Rename Flow
        flow.name = "CMN_Flow"
    
        mf = flow.modifiers.new("FluidFlow", "FLUID")
        mf.fluid_type = "FLOW"
        f = mf.flow_settings
        f.flow_type = "LIQUID"
        f.flow_behavior = "INFLOW"
        f.flow_source = "MESH"
        f.use_inflow = True
        f.use_initial_velocity = True
        f.use_plane_init = True
        
        # Set velocity to positive Y - Updated to match human ejaculation velocity
        velocity_vector = Vector((0.0, self._scaled_flow_velocity_y(5.0), 0.0))
        f.velocity_coord = velocity_vector
    
        return flow
        
    def setup_effector(self, obj):
        # Check if object already has a fluid modifier
        for mod in obj.modifiers:
            if mod.type == 'FLUID' and hasattr(mod, 'fluid_type'):
                # Already has a fluid modifier, ensure it's set as effector
                mod.fluid_type = "EFFECTOR"
                if hasattr(mod, 'effector_settings'):
                    e = mod.effector_settings
                    e.effector_type = "COLLISION"
                    e.surface_distance = self.STICK_SHELL
                    e.velocity_factor = 0.0
                    e.use_plane_init = False
                return obj
        
        # Add fluid effector modifier if not present
        try:
            # Try to add a new fluid modifier
            me = obj.modifiers.new("FluidEffector", "FLUID")
            if me and hasattr(me, 'fluid_type'):
                me.fluid_type = "EFFECTOR"
                e = me.effector_settings
                e.effector_type = "COLLISION"
                e.surface_distance = self.STICK_SHELL
                e.velocity_factor = 0.0
                e.use_plane_init = False
            else:
                self.report({'WARNING'}, f"Could not set fluid modifier on {obj.name}")
        except Exception as ex:
            self.report({'WARNING'}, f"Error setting up effector on {obj.name}: {str(ex)}")
        
        return obj
    
    def setup_continuous_flow(self, flow, frame_start, frame_end, flow_end_frame):
        """Set up keyframes for continuous flow with realistic fadeout"""
        # Get the flow settings
        mf = flow.modifiers.get("FluidFlow")
        if not mf:
            return
            
        f = mf.flow_settings
        fps = bpy.context.scene.render.fps
        
        # Calculate fadeout start frame - shorter fadeout period
        fadeout_time = 1.5  # seconds (reduced from 3.5)
        fadeout_frames = int(fadeout_time * fps)
        fadeout_start = flow_end_frame - fadeout_frames
        
        # End flow slightly before the designated flow end frame
        actual_end_frame = flow_end_frame
        
        # Set initial keyframes for use_inflow
        f.use_inflow = False
        flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.use_inflow', frame=frame_start-1)
        
        # Initial velocity - full strength
        initial_velocity = Vector((0.0, self._scaled_flow_velocity_y(5.0), 0.0))
        f.velocity_coord = initial_velocity
        flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.velocity_coord', frame=frame_start)
        
        f.use_inflow = True
        flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.use_inflow', frame=frame_start)
        
        # For realistic fadeout, simulate slight pulsing during fadeout phase
        if fadeout_start > frame_start + 10:  # Only do pulsing if we have enough frames
            # Strong flow until fadeout starts
            flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.use_inflow', frame=fadeout_start-1)
            
            # Start decreasing velocity at fadeout start
            reduced_velocity = Vector((0.0, self._scaled_flow_velocity_y(3.5), 0.0))
            f.velocity_coord = reduced_velocity
            flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.velocity_coord', frame=fadeout_start)
            
            # Reduced number of pulses (3 instead of 7)
            num_fadeout_pulses = 3
            
            # Initialize with randomized timing
            import random
            
            # Just a couple quick pulses at the end
            current_frame = fadeout_start
            
            for i in range(num_fadeout_pulses):
                # Shorter pulse durations
                pulse_duration = max(2, int(4 - (i * 0.8) + random.randint(-1, 1)))
                
                # Turn off briefly (pulse off)
                f.use_inflow = False
                flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.use_inflow', frame=current_frame)
                
                # Turn back on (pulse on) - if we're not at the last pulse
                if i < num_fadeout_pulses - 1:
                    f.use_inflow = True
                    flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.use_inflow', 
                                       frame=current_frame + pulse_duration)
                    
                    # Gradually decrease velocity with each pulse
                    pulse_velocity = Vector((0.0, self._scaled_flow_velocity_y(max(1.0, 3.0 - i * 0.8)), 0.0))
                    f.velocity_coord = pulse_velocity
                    flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.velocity_coord', 
                                       frame=current_frame + pulse_duration)
                
                # Update current frame - shorter intervals
                interval = max(3, int(fadeout_frames / (num_fadeout_pulses * 2) * (0.8 + 0.4 * random.random())))
                current_frame += pulse_duration + interval
                
                # Stop if we've gone past our end frame
                if current_frame >= actual_end_frame:
                    break
        
        # Final keyframe - ensure it's off at the end
        f.use_inflow = False
        flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.use_inflow', frame=actual_end_frame)
        
        # Final velocity is significantly reduced
        final_velocity = Vector((0.0, self._scaled_flow_velocity_y(0.5), 0.0))
        f.velocity_coord = final_velocity
        flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.velocity_coord', frame=actual_end_frame)
    
    def setup_pulse_flow(self, flow, frame_start, frame_end, flow_end_frame):
        """Set up keyframes for pulsating flow simulating ejaculation"""
        # Get the flow settings
        mf = flow.modifiers.get("FluidFlow")
        if not mf:
            return
            
        f = mf.flow_settings
        fps = bpy.context.scene.render.fps
        
        # Calculate pulse timing
        pulse_frames = []
        current_time = 0
        interval = self.EJAC_INITIAL_INTERVAL
        
        # Calculate frame for each pulse - ensure pulses stop at flow_end_frame
        for i in range(self.EJAC_NUM_PULSES):
            pulse_frame = frame_start + int(current_time * fps)
            
            # Stop adding pulses if we've reached the flow end frame
            if pulse_frame >= flow_end_frame:
                break
                
            pulse_frames.append(pulse_frame)
            
            # Add some natural variation (±10% to interval)
            variation = 0.9 + 0.2 * random.random()  
            current_time += interval * variation
            interval += self.EJAC_INTERVAL_INCREASE
        
        # Initial keyframe - off
        f.use_inflow = False
        flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.use_inflow', frame=frame_start-1)
        
        # Set keyframes for each pulse
        for i, pulse_frame in enumerate(pulse_frames):
            # Turn on flow at pulse frame
            f.use_inflow = True
            
            # Set velocity - stronger at start, gradually decreasing
            # Research shows first few contractions are strongest
            pulse_strength = 1.0
            if i == 0:
                pulse_strength = 1.0  # First pulse: 100%
            elif i == 1:
                pulse_strength = 1.0  # Second pulse: 100% (typically strongest)
            elif i < 4:
                pulse_strength = 0.9  # Pulses 3-4: 90%
            elif i < 7:
                pulse_strength = 0.7  # Pulses 5-7: 70%
            else:
                # Gradually decrease for later pulses
                pulse_strength = max(0.2, 0.6 - (i - 7) * 0.1)
                
            # Add some natural variation
            variation = 0.95 + 0.1 * random.random()
            pulse_strength *= variation
            
            pulse_velocity = Vector((0.0, self._scaled_flow_velocity_y(5.0) * pulse_strength, 0.0))
            f.velocity_coord = pulse_velocity
            
            # Insert keyframes
            flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.use_inflow', frame=pulse_frame)
            flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.velocity_coord', frame=pulse_frame)
            
            # Turn off flow shortly after
            # Longer pulses at beginning, shorter at end
            # pulse duration was authored in frames for a 60fps baseline; convert to seconds then back to frames
            base_pulse_duration_60fps_frames = max(3, 6 - (i * 0.3))  # Frames at 60fps baseline
            base_pulse_duration_seconds = base_pulse_duration_60fps_frames / 60.0
            pulse_duration = int(base_pulse_duration_seconds * self._get_scene_fps() * float(self.flow_pulse_duration))
            f.use_inflow = False
            flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.use_inflow', frame=pulse_frame + int(pulse_duration))
        
        # Ensure it's off at the flow end frame
        f.use_inflow = False
        flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.use_inflow', frame=flow_end_frame)
        
        # Final velocity is minimal
        final_velocity = Vector((0.0, self._scaled_flow_velocity_y(0.5), 0.0))
        f.velocity_coord = final_velocity
        flow.keyframe_insert(data_path='modifiers["FluidFlow"].flow_settings.velocity_coord', frame=flow_end_frame)
    
    def execute(self, context):
        # Get the fluid mode setting
        fluid_mode = context.scene.hhp_dynamics_props.fluid_mode
        
        if fluid_mode == 'BLENDER':
            # Use the existing Blender fluid simulation setup
            self.deselect_all()
            dom = self.make_domain()
            flow = self.make_flow(dom)
            
            # Set up keyframes based on selected method
            if self.cmn_method == 'CONTINUOUS':
                self.setup_continuous_flow(flow, self.frame_start, self.frame_end, self.flow_end_frame)
            else:  # PULSE
                self.setup_pulse_flow(flow, self.frame_start, self.frame_end, self.flow_end_frame)
            
            # Configure flow object display
            flow.hide_render = True
            flow.display_type = 'WIRE'
            flow.show_name = True
            
            # Update domain settings to match frame range
            md = dom.modifiers.get("FluidDomain")
            if md and hasattr(md, "domain_settings"):
                d = md.domain_settings
                d.cache_frame_start = self.frame_start
                d.cache_frame_end = self.frame_end  # Simulation runs until the end frame
            
            effector_objects = []
            
            # Process the selection to make them effectors
            if self.use_selection:
                # Use selected objects stored from invoke time
                if not self._selected_objects_at_invoke:
                     self.report({'WARNING'}, "'Use Selection' was checked, but no mesh objects were selected initially.")
                else:
                    for obj in self._selected_objects_at_invoke:
                        if obj and obj.name in bpy.data.objects: # Check if object still exists
                            self.setup_effector(obj)
                            effector_objects.append(obj)
                        else:
                             self.report({'WARNING'}, f"Selected object no longer exists.")
            else:
                # Use object from the picker slot
                # Ensure effector slot exists (can be empty in some execute() paths)
                if len(context.scene.fluid_effectors.effector_list) == 0:
                    context.scene.fluid_effectors.effector_list.add()
                effector_item = context.scene.fluid_effectors.effector_list[0] # Get the single item
                if effector_item.object:
                    self.setup_effector(effector_item.object)
                    effector_objects.append(effector_item.object)
                else:
                     self.report({'WARNING'}, "No effector object selected in the picker slot.")

            # Clear the cached selection
            self._selected_objects_at_invoke.clear()
            
            # Apply smooth shading & add smooth modifier to domain
            self.deselect_all()
            dom.select_set(True)
            context.view_layer.objects.active = dom
            bpy.ops.object.shade_smooth()
            sm = dom.modifiers.new("Smooth", "SMOOTH")
            sm.iterations = self.smooth_iterations  # Use the value from the slider
            sm.factor = 1.5
            
            # Finalize selection (select flow)
            self.deselect_all()
            flow.select_set(True) # Select flow
            context.view_layer.objects.active = flow # Make flow active
            
            self.report({'INFO'}, f"CMN sim set up with {self.cmn_method.lower()} method from frame {self.frame_start} to {self.frame_end}")
            
        elif fluid_mode == 'FLIP':
            if not self._flip_fluids_available():
                self.report({'ERROR'}, "Flip Fluids addon not available/enabled. Please enable FLIP Fluids and try again.")
                return {'CANCELLED'}

            self.deselect_all()
            dom = self._make_flip_domain()
            inflow = self._make_flip_inflow(dom)

            # Disable auto-load baked frames (requested)
            try:
                context.scene.flip_fluid_helper.enable_auto_frame_load = False
            except Exception:
                pass

            # Ensure grid draw operator is running (requested visualization)
            try:
                bpy.ops.flip_fluid_operators.draw_debug_grid('INVOKE_DEFAULT')
            except Exception:
                pass

            # Set up keyframes based on selected method
            if self.cmn_method == 'CONTINUOUS':
                self._setup_flip_continuous_flow(inflow, self.frame_start, self.frame_end, self.flow_end_frame)
            else:
                self._setup_flip_pulse_flow(inflow, self.frame_start, self.frame_end, self.flow_end_frame)

            # Do not smooth the domain in FLIP Fluids mode (requested)
            # (Keep selection/activation for the user's convenience.)
            self._flip_select_active(dom)

            # Set obstacles from selection or picker (reuse operator UI)
            effector_objects = []
            if self.use_selection:
                if not self._selected_objects_at_invoke:
                    self.report({'WARNING'}, "'Use Selection' was checked, but no mesh objects were selected initially.")
                else:
                    for obj in self._selected_objects_at_invoke:
                        if obj and obj.name in bpy.data.objects:
                            self._setup_flip_obstacle(obj)
                            effector_objects.append(obj)
                        else:
                            self.report({'WARNING'}, "Selected object no longer exists.")
            else:
                # Ensure effector slot exists (can be empty in some execute() paths)
                if len(context.scene.fluid_effectors.effector_list) == 0:
                    context.scene.fluid_effectors.effector_list.add()
                effector_item = context.scene.fluid_effectors.effector_list[0]
                if effector_item.object:
                    self._setup_flip_obstacle(effector_item.object)
                    effector_objects.append(effector_item.object)
                else:
                    self.report({'WARNING'}, "No obstacle object selected in the picker slot.")

            self._selected_objects_at_invoke.clear()

            # Finalize selection (select inflow)
            self.deselect_all()
            inflow.select_set(True)
            context.view_layer.objects.active = inflow

            self.report({'INFO'}, f"Flip Fluids CMN sim set up with {self.cmn_method.lower()} method from frame {self.frame_start} to {self.frame_end} (Ultra=320)")
            
        return {'FINISHED'}

class FLUID_EffectorList(PropertyGroup):
    effector_list: CollectionProperty(type=FLUID_EffectorItem)
    # active_index is no longer needed

# Registration
classes = (
    FLUID_EffectorItem,
    FLUID_UL_effector_list,
    FLUID_EffectorList,
    FLUID_OT_add_effector,
    FLUID_OT_remove_effector,
    OBJECT_OT_setup_cmn_simulation,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.fluid_effectors = PointerProperty(type=FLUID_EffectorList)

def unregister():
    del bpy.types.Scene.fluid_effectors
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register() 