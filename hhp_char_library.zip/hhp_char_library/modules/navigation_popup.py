"""Standard icon-button selectors for character panels and sections."""
import bpy

MAIN_ITEMS = (
    ('PROXIES', 'Physics / Proxies', 'PHYSICS'),
    ('OPTIMIZE', 'Optimized Tools', 'MODIFIER_DATA'),
    ('CUSTOMIZE', 'Customize', 'MOD_HUE_SATURATION'),
    ('RENDER', 'Render / Lighting', 'LIGHT'),
    ('ANIMATION', 'Animation', 'ACTION'),
    ('DYNAMICS', 'Dynamics / Fluids', 'MOD_FLUIDSIM'),
)
SECTION_ITEMS = (
    ('INITIAL_SETUP', 'Initial Setup', 'QUIT'),
    ('SHAPEKEY_MORPHS', 'Shape Key Morphs', 'SHAPEKEY_DATA'),
    ('EFFECTS_SHADERS', 'Effects & Shaders', 'MATERIAL'),
    ('CLOTHING', 'Clothing & Accessories', 'MOD_CLOTH'),
    ('MISC', 'Misc', 'MOD_MASK'),
)

def active_value(context, kind):
    return (context.scene.hhp_panel_mode.selected_panel if kind == 'MAIN'
            else context.window_manager.custom_panel_section)

def draw_selector(layout, context, kind):
    items = MAIN_ITEMS if kind == 'MAIN' else SECTION_ITEMS
    active = active_value(context, kind)
    row = layout.row(align=True)
    for key, label, icon in items:
        op = row.operator('hhp.select_navigation_panel', text='', icon=icon,
                          depress=key == active)
        op.kind = kind
        op.panel = key

class HHP_OT_SelectNavigationPanel(bpy.types.Operator):
    bl_idname = 'hhp.select_navigation_panel'
    bl_label = 'Select Panel'
    bl_description = 'Show the selected panel'
    bl_options = {'INTERNAL'}

    kind: bpy.props.EnumProperty(
        name='Panel Group', description='Select main panels or customization sections',
        items=(('MAIN', 'Panels', 'Main character panels'),
               ('SECTION', 'Customize', 'Customization sections')), default='MAIN')
    panel: bpy.props.StringProperty(name='Panel', description='Panel to display')

    @classmethod
    def description(cls, context, properties):
        items = MAIN_ITEMS if properties.kind == 'MAIN' else SECTION_ITEMS
        label = next((label for key, label, _ in items if key == properties.panel), 'selected panel')
        return f'Show {label}'

    def execute(self, context):
        items = MAIN_ITEMS if self.kind == 'MAIN' else SECTION_ITEMS
        if self.panel not in {key for key, _, _ in items}:
            return {'CANCELLED'}
        if self.kind == 'MAIN':
            context.scene.hhp_panel_mode.selected_panel = self.panel
        else:
            context.window_manager.custom_panel_section = self.panel
        for area in context.screen.areas if context.screen else ():
            area.tag_redraw()
        return {'FINISHED'}

def draw_choices(layout, context, kind):
    items = MAIN_ITEMS if kind == 'MAIN' else SECTION_ITEMS
    active = active_value(context, kind)
    for key, label, icon in items:
        op = layout.operator('hhp.select_navigation_panel', text=label,
                             icon=icon, depress=key == active)
        op.kind = kind
        op.panel = key

class HHP_MT_MainPanelSelector(bpy.types.Menu):
    bl_label = 'Panels'
    bl_idname = 'HHP_MT_MainPanelSelector'

    def draw(self, context):
        draw_choices(self.layout, context, 'MAIN')

class HHP_MT_CustomizeSectionSelector(bpy.types.Menu):
    bl_label = 'Customize'
    bl_idname = 'HHP_MT_CustomizeSectionSelector'

    def draw(self, context):
        draw_choices(self.layout, context, 'SECTION')

_CLASSES = (HHP_OT_SelectNavigationPanel, HHP_MT_MainPanelSelector,
            HHP_MT_CustomizeSectionSelector)

def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
