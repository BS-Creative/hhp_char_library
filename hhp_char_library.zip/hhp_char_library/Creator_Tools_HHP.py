# File: Creator Tools_HHP.py

import bpy

# -------------------------------------------------------------------
# 1) Transfer Delta as Shape Key (named "DeltaCorrective")
# -------------------------------------------------------------------

def transfer_delta_as_shapekey():
    """
    Transfers the vertex delta between the selected mesh (source)
    and the active mesh (target) as a new shape key on the active mesh.
    
    Requirements:
      - Exactly two mesh objects are selected
      - Active object receives the new shape key
      - The other selected object is the source
      - Shape key is named "DeltaCorrective"
    """
    ctx = bpy.context
    depsgraph = ctx.evaluated_depsgraph_get()

    if len(ctx.selected_objects) != 2:
        self_report("ERROR: Select exactly two mesh objects (active + source).")
        return

    active_obj = ctx.active_object
    sel_objs = ctx.selected_objects

    # Identify which is source vs. active
    if sel_objs[0] == active_obj:
        source_obj = sel_objs[1]
    else:
        source_obj = sel_objs[0]

    if active_obj.type != 'MESH' or source_obj.type != 'MESH':
        self_report("ERROR: Both selected objects must be meshes.")
        return

    # Get final/evaluated meshes
    active_eval = active_obj.evaluated_get(depsgraph)
    source_eval = source_obj.evaluated_get(depsgraph)
    
    active_mesh = active_eval.to_mesh()
    source_mesh = source_eval.to_mesh()

    if len(active_mesh.vertices) != len(source_mesh.vertices):
        self_report("ERROR: Topology mismatch (different vertex counts).")
        active_eval.to_mesh_clear()
        source_eval.to_mesh_clear()
        return

    # Ensure a Basis shape key
    if not active_obj.data.shape_keys:
        active_obj.shape_key_add(name="Basis")
    basis_key = active_obj.data.shape_keys.key_blocks[0]

    # Create "DeltaCorrective" shape key
    new_key = active_obj.shape_key_add(name="DeltaCorrective", from_mix=False)

    # For each vertex, compute: (source - active) + basis
    for i, sk_vert in enumerate(new_key.data):
        delta = source_mesh.vertices[i].co - active_mesh.vertices[i].co
        sk_vert.co = basis_key.data[i].co + delta

    # Set shape key value to 1.0
    new_key.value = 1.0

    # Make "DeltaCorrective" the active shape key
    for idx, kb in enumerate(active_obj.data.shape_keys.key_blocks):
        if kb == new_key:
            active_obj.active_shape_key_index = idx
            break

    # Cleanup
    active_eval.to_mesh_clear()
    source_eval.to_mesh_clear()


# -------------------------------------------------------------------
# 2) Main Delta Transfer with Corrective Smooth
# -------------------------------------------------------------------

def delta_transfer_with_corrective_smooth(context):
    """
    Performs the entire operation in one go:
      1) Duplicate active mesh
      2) Mute shape keys that match 'Mute Word'
      3) Add a Corrective Smooth modifier with 'Vertex Group Mask' and 'Repeat' count
      4) Convert the duplicate to a mesh
      5) Transfer the delta to the active (transfer_delta_as_shapekey)
      6) Delete the duplicate
      7) Restore original selection
    """

    scene = context.scene
    view_layer = context.view_layer
    active_obj = view_layer.objects.active

    if not active_obj or active_obj.type != 'MESH':
        self_report("ERROR: No active mesh object.")
        return {'CANCELLED'}

    # If advanced options is disabled, use defaults
    # If enabled, use user-specified properties
    if scene.advanced_options:
        shape_key_word = scene.mute_key_word
        vertex_group_name = scene.vertex_group_name
    else:
        shape_key_word = "head"
        vertex_group_name = "Eyelids_Corrective smooth"

    correct_amount = scene.correct_amount

    # ----------------------------------------------------------------
    # Store the original selection & active object to restore later
    # ----------------------------------------------------------------
    original_selection = list(context.selected_objects)
    original_active = view_layer.objects.active

    # Deselect all, select only the active
    bpy.ops.object.select_all(action='DESELECT')
    active_obj.select_set(True)
    view_layer.objects.active = active_obj

    # Duplicate
    bpy.ops.object.duplicate()
    duplicate = view_layer.objects.active
    if not duplicate or duplicate.type != 'MESH':
        self_report("ERROR: Duplicate failed or not a mesh.")
        restore_selection(original_selection, original_active)
        return {'CANCELLED'}

    # Store + Mute shape keys
    shapekeys = duplicate.data.shape_keys
    shapekey_mute_states = {}
    if shapekeys:
        for kb in shapekeys.key_blocks:
            shapekey_mute_states[kb.name] = kb.mute
            if shape_key_word.lower() in kb.name.lower():
                kb.mute = True

    # Add Corrective Smooth
    smooth_mod = duplicate.modifiers.new(name="CorrectiveSmooth", type='CORRECTIVE_SMOOTH')
    smooth_mod.vertex_group = vertex_group_name
    smooth_mod.rest_source = 'BIND'
    smooth_mod.iterations = correct_amount

    # Must be in object mode to bind
    if context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.correctivesmooth_bind(modifier=smooth_mod.name)

    # Restore shape key mute states
    if shapekeys:
        for kb in shapekeys.key_blocks:
            kb.mute = shapekey_mute_states.get(kb.name, False)

    # Convert duplicate to mesh
    bpy.ops.object.convert(target='MESH')

    # Reselect original + duplicate, set original active
    bpy.ops.object.select_all(action='DESELECT')
    active_obj.select_set(True)
    duplicate.select_set(True)
    view_layer.objects.active = active_obj

    # Transfer delta
    transfer_delta_as_shapekey()

    # Delete duplicate
    bpy.ops.object.select_all(action='DESELECT')
    duplicate.select_set(True)
    bpy.ops.object.delete()

    # ----------------------------------------------------------------
    # Restore the user's original selection and active object
    # ----------------------------------------------------------------
    restore_selection(original_selection, original_active)

    return {'FINISHED'}


# -------------------------------------------------------------------
# 3) Operator: runs the entire process
# -------------------------------------------------------------------

class HHP_OT_create_delta_corrective(bpy.types.Operator):
    """Create a Delta Corrective Shape Key via duplication + corrective smooth"""
    bl_idname = "hhp.create_delta_corrective"
    bl_label = "Create Delta Corrective"
    bl_options = {'UNDO'}

    def execute(self, context):
        return delta_transfer_with_corrective_smooth(context)


# -------------------------------------------------------------------
# 4) "Reset to Default" Operator
# -------------------------------------------------------------------

class HHP_OT_reset_advanced_settings(bpy.types.Operator):
    """Reset advanced settings to default"""
    bl_idname = "hhp.reset_advanced_settings"
    bl_label = "Reset to Default"

    def execute(self, context):
        scene = context.scene

        # Reset all advanced fields
        scene.mute_key_word = "head"
        scene.vertex_group_name = "Eyelids_Corrective smooth"

        # Also reset the repeat value
        scene.correct_amount = 140

        return {'FINISHED'}


# -------------------------------------------------------------------
# 5) UI Panel in the N-panel (Category = "Char (HHP)")
# -------------------------------------------------------------------

class HHP_PT_experimental_creator_tools(bpy.types.Panel):
    """EXPERIMENTAL - Creator Tools Panel"""
    bl_label = "EXPERIMENTAL - Creator Tools"
    bl_idname = "HHP_PT_experimental_creator_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Char (HHP)"
    bl_order = 50
    bl_options = {'DEFAULT_CLOSED'}  # Panel is collapsed by default

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        obj = context.object

        # Main box with "Correction" label
        box = layout.box()
        box.label(text="Correction", icon='TOOL_SETTINGS')

        # Row for advanced checkbox, repeat slider, and main button
        row = box.row(align=True)
        # A column for the advanced checkbox
        left_col = row.column(align=True)
        left_col.prop(scene, "advanced_options",
                      text="",
                      icon='MODIFIER',  # Wrench icon
                      emboss=True,
                      toggle=True)

        # The Repeat slider
        row.prop(scene, "correct_amount", text="Repeat")

        # The "Create Delta Corrective" button
        row.operator("hhp.create_delta_corrective", text="Create Delta Corrective")

        # If advanced options are enabled, show extra controls
        if scene.advanced_options:
            col = box.column(align=True)
            col.prop(scene, "mute_key_word", text="Mute Word")

            # "Vertex Group Mask" as a prop_search
            # If no group is selected, entire mesh will be smoothed
            if obj and obj.type == 'MESH':
                col.prop_search(
                    data=scene,                      # data containing the string property
                    property="vertex_group_name",    # the actual string property
                    search_data=obj,                 # the object with vertex groups
                    search_property="vertex_groups", # the name of the collection
                    text="Vertex Group Mask"
                )
            else:
                # fallback if no valid active mesh
                col.prop(scene, "vertex_group_name", text="Vertex Group Mask")

            col.operator("hhp.reset_advanced_settings", text="Reset to Default", icon='FILE_REFRESH')


# -------------------------------------------------------------------
# 6) Helpers, Registration, etc.
# -------------------------------------------------------------------

def self_report(message):
    """Show error messages (no success pop-ups)."""
    print(message)
    bpy.context.window_manager.popup_menu(
        lambda self, ctx: self.layout.label(text=message),
        title="Error", icon='ERROR'
    )

def restore_selection(original_selection, original_active):
    """Restores the user’s previous selection + active object."""
    bpy.ops.object.select_all(action='DESELECT')
    for obj in original_selection:
        if obj and obj.name in bpy.data.objects:
            obj.select_set(True)
    if original_active and original_active.name in bpy.data.objects:
        bpy.context.view_layer.objects.active = original_active


# -------------------------------------------------------------------
# 7) Registration
# -------------------------------------------------------------------

def register():
    from bpy.utils import register_class

    # Our properties
    bpy.types.Scene.correct_amount = bpy.props.IntProperty(
        name="Correct Amount",
        description="Number of smoothing iterations for Corrective Smooth",
        default=140,
        min=1,
        max=200
    )
    bpy.types.Scene.advanced_options = bpy.props.BoolProperty(
        name="Advanced Options",
        description="Toggle advanced shape-key muting & vertex group masking",
        default=False
    )
    bpy.types.Scene.mute_key_word = bpy.props.StringProperty(
        name="Mute Key Word",
        description="Shape keys containing this word (case-insensitive) will be muted (Excluded from smoothing)",
        default="head"
    )
    bpy.types.Scene.vertex_group_name = bpy.props.StringProperty(
        name="Vertex Group Mask",
        description="Limits the correction to the selected vertex group. If no group is selected, the entire mesh will be smoothed",
        default="Eyelids_Corrective smooth"
    )

    register_class(HHP_OT_create_delta_corrective)
    register_class(HHP_OT_reset_advanced_settings)
    register_class(HHP_PT_experimental_creator_tools)


def unregister():
    from bpy.utils import unregister_class

    del bpy.types.Scene.correct_amount
    del bpy.types.Scene.advanced_options
    del bpy.types.Scene.mute_key_word
    del bpy.types.Scene.vertex_group_name

    unregister_class(HHP_PT_experimental_creator_tools)
    unregister_class(HHP_OT_reset_advanced_settings)
    unregister_class(HHP_OT_create_delta_corrective)
