# File: Creator Tools_HHP.py

import bpy

# -------------------------------------------------------------------
# 1) Transfer Delta as Shape Key (named "DeltaCorrective")
# -------------------------------------------------------------------

def transfer_delta_as_shapekey():
    """
    Transfers the vertex delta between the selected mesh (source)
    and the active mesh (target) as a new shape key on the active mesh.
    
    Requirements:
      - Exactly two mesh objects are selected
      - Active object receives the new shape key
      - The other selected object is the source
      - Shape key is named "DeltaCorrective"
    """
    ctx = bpy.context
    depsgraph = ctx.evaluated_depsgraph_get()

    if len(ctx.selected_objects) != 2:
        self_report("ERROR: Select exactly two mesh objects (active + source).")
        return

    active_obj = ctx.active_object
    sel_objs = ctx.selected_objects

    # Identify which is source vs. active
    if sel_objs[0] == active_obj:
        source_obj = sel_objs[1]
    else:
        source_obj = sel_objs[0]

    if active_obj.type != 'MESH' or source_obj.type != 'MESH':
        self_report("ERROR: Both selected objects must be meshes.")
        return

    # Get final/evaluated meshes
    active_eval = active_obj.evaluated_get(depsgraph)
    source_eval = source_obj.evaluated_get(depsgraph)
    
    active_mesh = active_eval.to_mesh()
    source_mesh = source_eval.to_mesh()

    if len(active_mesh.vertices) != len(source_mesh.vertices):
        self_report("ERROR: Topology mismatch (different vertex counts).")
        active_eval.to_mesh_clear()
        source_eval.to_mesh_clear()
        return

    # Ensure a Basis shape key
    if not active_obj.data.shape_keys:
        active_obj.shape_key_add(name="Basis")
    basis_key = active_obj.data.shape_keys.key_blocks[0]

    # Create "DeltaCorrective" shape key
    new_key = active_obj.shape_key_add(name="DeltaCorrective", from_mix=False)

    # For each vertex, compute: (source - active) + basis
    for i, sk_vert in enumerate(new_key.data):
        delta = source_mesh.vertices[i].co - active_mesh.vertices[i].co
        sk_vert.co = basis_key.data[i].co + delta

    # Set shape key value to 1.0
    new_key.value = 1.0

    # Make "DeltaCorrective" the active shape key
    for idx, kb in enumerate(active_obj.data.shape_keys.key_blocks):
        if kb == new_key:
            active_obj.active_shape_key_index = idx
            break

    # Cleanup
    active_eval.to_mesh_clear()
    source_eval.to_mesh_clear()


# -------------------------------------------------------------------
# 2) Main Delta Transfer with Corrective Smooth
# -------------------------------------------------------------------

def delta_transfer_with_corrective_smooth(context):
    """
    Performs the entire operation in one go:
      1) Duplicate active mesh
      2) Mute shape keys that match 'Mute Word'
      3) Add a Corrective Smooth modifier with 'Vertex Group Mask' and 'Repeat' count
      4) Convert the duplicate to a mesh
      5) Transfer the delta to the active (transfer_delta_as_shapekey)
      6) Delete the duplicate
      7) Restore original selection
    """

    scene = context.scene
    view_layer = context.view_layer
    active_obj = view_layer.objects.active

    if not active_obj or active_obj.type != 'MESH':
        self_report("ERROR: No active mesh object.")
        return {'CANCELLED'}

    # If advanced options is disabled, use defaults
    # If enabled, use user-specified properties
    if scene.advanced_options:
        shape_key_word = scene.mute_key_word
        vertex_group_name = scene.vertex_group_name
    else:
        shape_key_word = "head"
        vertex_group_name = "Eyelids_Corrective smooth"

    correct_amount = scene.correct_amount

    # ----------------------------------------------------------------
    # Store the original selection & active object to restore later
    # ----------------------------------------------------------------
    original_selection = list(context.selected_objects)
    original_active = view_layer.objects.active

    # Deselect all, select only the active
    bpy.ops.object.select_all(action='DESELECT')
    active_obj.select_set(True)
    view_layer.objects.active = active_obj

    # Duplicate
    bpy.ops.object.duplicate()
    duplicate = view_layer.objects.active
    if not duplicate or duplicate.type != 'MESH':
        self_report("ERROR: Duplicate failed or not a mesh.")
        restore_selection(original_selection, original_active)
        return {'CANCELLED'}

    # Store + Mute shape keys
    shapekeys = duplicate.data.shape_keys
    shapekey_mute_states = {}
    if shapekeys:
        for kb in shapekeys.key_blocks:
            shapekey_mute_states[kb.name] = kb.mute
            if shape_key_word.lower() in kb.name.lower():
                kb.mute = True

    # Add Corrective Smooth
    smooth_mod = duplicate.modifiers.new(name="CorrectiveSmooth", type='CORRECTIVE_SMOOTH')
    smooth_mod.vertex_group = vertex_group_name
    smooth_mod.rest_source = 'BIND'
    smooth_mod.iterations = correct_amount

    # Must be in object mode to bind
    if context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.correctivesmooth_bind(modifier=smooth_mod.name)

    # Restore shape key mute states
    if shapekeys:
        for kb in shapekeys.key_blocks:
            kb.mute = shapekey_mute_states.get(kb.name, False)

    # Convert duplicate to mesh
    bpy.ops.object.convert(target='MESH')

    # Reselect original + duplicate, set original active
    bpy.ops.object.select_all(action='DESELECT')
    active_obj.select_set(True)
    duplicate.select_set(True)
    view_layer.objects.active = active_obj

    # Transfer delta
    transfer_delta_as_shapekey()

    # Delete duplicate
    bpy.ops.object.select_all(action='DESELECT')
    duplicate.select_set(True)
    bpy.ops.object.delete()

    # ----------------------------------------------------------------
    # Restore the user's original selection and active object
    # ----------------------------------------------------------------
    restore_selection(original_selection, original_active)

    return {'FINISHED'}


# -------------------------------------------------------------------
# 3) Operator: runs the entire process
# -------------------------------------------------------------------

class HHP_OT_create_delta_corrective(bpy.types.Operator):
    """Create a Delta Corrective Shape Key via duplication + corrective smooth"""
    bl_idname = "hhp.create_delta_corrective"
    bl_label = "Create Delta Corrective"
    bl_options = {'UNDO'}

    def execute(self, context):
        # Run the main corrective process
        ret = delta_transfer_with_corrective_smooth(context)

        # If it completed successfully AND auto-split is true, split the new shape key
        if ret == {'FINISHED'} and context.scene.auto_split_lr:
            obj = context.view_layer.objects.active
            if obj and obj.type == 'MESH':
                split_and_delete_active_shape_key(obj, threshold=0.0)

        return ret


# -------------------------------------------------------------------
# 4) "Reset to Default" Operator
# -------------------------------------------------------------------

class HHP_OT_reset_advanced_settings(bpy.types.Operator):
    """Reset advanced settings to default"""
    bl_idname = "hhp.reset_advanced_settings"
    bl_label = "Reset to Default"

    def execute(self, context):
        scene = context.scene

        # Reset all advanced fields
        scene.mute_key_word = "head"
        scene.vertex_group_name = "Eyelids_Corrective smooth"

        # Also reset the repeat value
        scene.correct_amount = 20

        # Reset auto split checkbox
        scene.auto_split_lr = False

        return {'FINISHED'}


# -------------------------------------------------------------------
# 5) UI Panel in the N-panel (Category = "Char (HHP)")
# -------------------------------------------------------------------

class HHP_PT_experimental_creator_tools(bpy.types.Panel):
    """EXPERIMENTAL - Creator Tools Panel"""
    bl_label = "EXPERIMENTAL - Creator Tools"
    bl_idname = "HHP_PT_experimental_creator_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Char (HHP)"
    bl_order = 50
    bl_options = {'DEFAULT_CLOSED'}  # Panel is collapsed by default

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        obj = context.object

        # Main box with "Correction" label
        box = layout.box()
        box.label(text="Correction", icon='TOOL_SETTINGS')

        # Row for advanced checkbox, repeat slider, main button, and auto-split
        row = box.row(align=True)

        # A column for the advanced checkbox
        left_col = row.column(align=True)
        left_col.prop(scene, "advanced_options",
                      text="",
                      icon='MODIFIER',  # Wrench icon
                      emboss=True,
                      toggle=True)

        # The Repeat slider
        row.prop(scene, "correct_amount", text="Repeat")

        # The "Create Delta Corrective" button
        row.operator("hhp.create_delta_corrective", text="Create Delta Corrective")

        # The unlabeled checkbox (with mirror icon)
        row.prop(scene, "auto_split_lr",
                 text="",
                 icon='MOD_MIRROR',
                 emboss=True)

        # If advanced options are enabled, show extra controls
        if scene.advanced_options:
            col = box.column(align=True)
            col.prop(scene, "mute_key_word", text="Mute Word")

            # "Vertex Group Mask" as a prop_search
            # If no group is selected, entire mesh will be smoothed
            if obj and obj.type == 'MESH':
                col.prop_search(
                    data=scene,                      # data containing the string property
                    property="vertex_group_name",    # the actual string property
                    search_data=obj,                 # the object with vertex groups
                    search_property="vertex_groups", # the name of the collection
                    text="Vertex Group Mask"
                )
            else:
                # fallback if no valid active mesh
                col.prop(scene, "vertex_group_name", text="Vertex Group Mask")

            # The "Split sides of active SK" button (requires confirmation)
            col.operator("hhp.split_sides_of_active_sk",
                         text="Split sides of active SK",
                         icon='MOD_MIRROR')

            col.operator("hhp.reset_advanced_settings", text="Reset to Default", icon='FILE_REFRESH')

        # Add a new box for the mask tools
        box = layout.box()
        box.label(text="Masking", icon='MOD_MASK')
        
        # Create HHP Mask button
        row = box.row()
        row.operator("hhp.create_mask", text="Create HHP Mask", icon='ADD')
        if context.mode != 'EDIT_MESH':
            row.enabled = False

        # Add a new box for HHP Update tools
        box = layout.box()
        box.label(text="HHP Update", icon='TOOL_SETTINGS')
        
        # Add the Copy Bone Shapes button
        row = box.row()
        row.operator("hhp.copy_bone_shapes", icon='BONE_DATA')


# -------------------------------------------------------------------
# 6) Helpers, Registration, etc.
# -------------------------------------------------------------------

def self_report(message):
    """Show error messages (no success pop-ups)."""
    print(message)
    bpy.context.window_manager.popup_menu(
        lambda self, ctx: self.layout.label(text=message),
        title="Error", icon='ERROR'
    )

def restore_selection(original_selection, original_active):
    """Restores the user's previous selection + active object."""
    bpy.ops.object.select_all(action='DESELECT')
    for obj in original_selection:
        if obj and obj.name in bpy.data.objects:
            obj.select_set(True)
    if original_active and original_active.name in bpy.data.objects:
        bpy.context.view_layer.objects.active = original_active


# -------------------------------------------------------------------
# 7) Split & Delete Active Shape Key (Provided Script)
# -------------------------------------------------------------------

def split_and_delete_active_shape_key(obj, threshold=0.0):
    """
    Splits the active shape key of the given object into two (".l" & ".r")
    and then deletes the original shape key.
    
    The new shape keys inherit the original shape key's value.
    The ".l" shape key is made active by default.
    """
    # Ensure the object has an active shape key
    if obj.active_shape_key is None:
        print("No active shape key to split.")
        return

    # Ensure the object has shape keys at all
    if not obj.data.shape_keys:
        print("No shape keys found on the object.")
        return
    
    shape_keys = obj.data.shape_keys
    active_sk = obj.active_shape_key
    basis_sk = shape_keys.key_blocks[0]  # The basis key is index 0
    mesh = obj.data

    # If the active shape key is the basis, splitting doesn't make sense
    if active_sk == basis_sk:
        print("Active shape key is the Basis. Aborting.")
        return

    # Store the original shape key value (e.g. 1.0)
    original_value = active_sk.value

    # Create the ".l" and ".r" shape keys
    sk_left = obj.shape_key_add(name=active_sk.name + ".l", from_mix=False)
    sk_right = obj.shape_key_add(name=active_sk.name + ".r", from_mix=False)

    # Set their values to match the original
    sk_left.value = original_value
    sk_right.value = original_value

    # Copy deformations into the left or right key depending on x-position
    for i, vert in enumerate(mesh.vertices):
        base_co = basis_sk.data[i].co
        active_co = active_sk.data[i].co
        
        if base_co.x > threshold:
            sk_left.data[i].co = active_co
            sk_right.data[i].co = base_co
        else:
            sk_left.data[i].co = base_co
            sk_right.data[i].co = active_co

    # Delete the original shape key using the operator approach
    idx = shape_keys.key_blocks.find(active_sk.name)
    if idx != -1:
        obj.active_shape_key_index = idx
        bpy.ops.object.shape_key_remove(all=False)

    # Finally, make the ".l" shape key active
    new_idx_left = shape_keys.key_blocks.find(sk_left.name)
    if new_idx_left != -1:
        obj.active_shape_key_index = new_idx_left


# -------------------------------------------------------------------
# 8) Operator for Splitting Sides with Confirmation
# -------------------------------------------------------------------

class HHP_OT_split_sides_of_active_sk(bpy.types.Operator):
    """Split sides of active shape key (requires confirmation)"""
    bl_idname = "hhp.split_sides_of_active_sk"
    bl_label = "Split sides of active SK"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        # Show a confirmation popup
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        obj = context.view_layer.objects.active
        if not obj or obj.type != 'MESH':
            self_report("No active mesh or no active object.")
            return {'CANCELLED'}

        split_and_delete_active_shape_key(obj, threshold=0.0)
        return {'FINISHED'}


# -------------------------------------------------------------------
# 9) Operator for Creating a Mask
# -------------------------------------------------------------------

class HHP_OT_create_mask(bpy.types.Operator):
    """Mask selected vertices by modifier & assign as HHP Misc property"""
    bl_idname = "hhp.create_mask"
    bl_label = "Create HHP Mask"
    bl_options = {'REGISTER', 'UNDO'}

    mask_name: bpy.props.StringProperty(
        name="Mask Name",
        description="Name for the mask setup",
        default="New"
    )
    
    # Store the original name to handle updates
    _original_name: str = ""

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH' and 
                context.active_object and 
                context.active_object.type == 'MESH')

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = context.active_object
        
        # If this is the first execution (not an update)
        if not self._original_name:
            prop_name = f"Mask - {self.mask_name}"
            vgroup_name = f"(HHP) Mask - {self.mask_name}"
            mod_name = f"(HHP) Mask - {self.mask_name}"
            
            # Check if any of the data already exists
            if (prop_name in obj or 
                vgroup_name in obj.vertex_groups or 
                mod_name in obj.modifiers):
                self_report("Data already exists. Select a different name.")
                return {'CANCELLED'}

            # Create custom property
            obj[prop_name] = True
            ui_data = obj.id_properties_ui(prop_name)
            ui_data.update(description=f"Toggle for {self.mask_name} mask")
            rna_ui = obj.get('_RNA_UI', {})
            rna_ui[prop_name] = {
                "min": 0.0,
                "max": 1.0,
                "soft_min": 0.0,
                "soft_max": 1.0,
                "description": f"Toggle for {self.mask_name} mask"
            }
            obj['_RNA_UI'] = rna_ui

            # Create vertex group from selection and assign selected vertices
            mask_group = obj.vertex_groups.new(name=vgroup_name)
            obj.vertex_groups.active = mask_group  # Set this vertex group as active
            bpy.ops.object.vertex_group_assign()

            # Add mask modifier
            mask_mod = obj.modifiers.new(name=mod_name, type='MASK')
            mask_mod.vertex_group = vgroup_name
            mask_mod.invert_vertex_group = True
            # Turn on "on cage" and "edit mode" display for the mask modifier
            mask_mod.show_on_cage = True
            mask_mod.show_in_editmode = True

            # Move modifier below last subdivision
            last_subsurf_idx = -1
            for i, mod in enumerate(obj.modifiers):
                if mod.type == 'SUBSURF':
                    last_subsurf_idx = i

            if last_subsurf_idx >= 0:
                current_idx = len(obj.modifiers) - 1
                positions_to_move = current_idx - (last_subsurf_idx + 1)
                for _ in range(positions_to_move):
                    bpy.ops.object.modifier_move_up(modifier=mask_mod.name)

            # Add drivers
            for state in ['show_viewport', 'show_render']:
                # Always try to remove any existing driver first
                try:
                    mask_mod.driver_remove(state)
                except:
                    pass
                
                # Create new driver
                driver = mask_mod.driver_add(state).driver
                driver.type = 'SCRIPTED'
                
                # Clear any existing variables
                for var in driver.variables:
                    driver.variables.remove(var)
                
                # Create new variable
                var = driver.variables.new()
                var.name = 'mask_toggle'
                var.type = 'SINGLE_PROP'
                
                target = var.targets[0]
                target.id_type = 'OBJECT'
                target.id = obj
                target.data_path = f'["{prop_name}"]'
                
                # Set expression to use the variable directly
                driver.expression = 'mask_toggle'

            # Store the original name for future updates
            self._original_name = self.mask_name

            # Reassign selected vertices to the updated vertex group
            vgroup = obj.vertex_groups.get(vgroup_name)
            if vgroup:
                obj.vertex_groups.active = vgroup
                bpy.ops.object.vertex_group_assign()

        else:
            # This is an update - rename existing items
            old_prop_name = f"Mask - {self._original_name}"
            old_vgroup_name = f"(HHP) Mask - {self._original_name}"
            old_mod_name = f"(HHP) Mask - {self._original_name}"

            new_prop_name = f"Mask - {self.mask_name}"
            new_vgroup_name = f"(HHP) Mask - {self.mask_name}"
            new_mod_name = f"(HHP) Mask - {self.mask_name}"

            # Check if new names would conflict with existing items
            if ((new_prop_name in obj and new_prop_name != old_prop_name) or 
                (new_vgroup_name in obj.vertex_groups and new_vgroup_name != old_vgroup_name) or 
                (new_mod_name in obj.modifiers and new_mod_name != old_mod_name)):
                self_report("Cannot rename: target names already exist.")
                return {'CANCELLED'}

            # Rename the custom property
            if old_prop_name in obj:
                value = obj[old_prop_name]
                rna_ui = obj.get('_RNA_UI', {})
                prop_ui = rna_ui.get(old_prop_name, {})
                
                del obj[old_prop_name]
                obj[new_prop_name] = value
                
                if prop_ui:
                    rna_ui[new_prop_name] = prop_ui
                    del rna_ui[old_prop_name]
                    obj['_RNA_UI'] = rna_ui

            # Rename the vertex group
            vgroup = obj.vertex_groups.get(old_vgroup_name)
            if vgroup:
                vgroup.name = new_vgroup_name

            # Rename the modifier and update its vertex group reference
            mod = obj.modifiers.get(old_mod_name)
            if mod:
                mod.name = new_mod_name
                mod.vertex_group = new_vgroup_name

                # Turn on "on cage" and "edit mode" display for the mask modifier
                mod.show_on_cage = True
                mod.show_in_editmode = True

                # Update drivers to point to new property
                for state in ['show_viewport', 'show_render']:
                    try:
                        mod.driver_remove(state)
                    except:
                        pass
                    
                    driver = mod.driver_add(state).driver
                    driver.type = 'SCRIPTED'
                    
                    # Clear any existing variables
                    for var in driver.variables:
                        driver.variables.remove(var)
                    
                    # Create new variable
                    var = driver.variables.new()
                    var.name = 'mask_toggle'
                    var.type = 'SINGLE_PROP'
                    
                    target = var.targets[0]
                    target.id_type = 'OBJECT'
                    target.id = obj
                    target.data_path = f'["{new_prop_name}"]'
                    
                    # Set expression to use the variable directly
                    driver.expression = 'mask_toggle'

            # Update the stored original name
            self._original_name = self.mask_name

            # Reassign selected vertices to the updated vertex group
            vgroup = obj.vertex_groups.get(new_vgroup_name)
            if vgroup:
                obj.vertex_groups.active = vgroup
                bpy.ops.object.vertex_group_assign()

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "mask_name")


# -------------------------------------------------------------------
# 10) Operator for Copying Bone Shapes
# -------------------------------------------------------------------

class HHP_OT_copy_bone_shapes(bpy.types.Operator):
    """Copy bone shapes from active armature to selected armatures"""
    bl_idname = "hhp.copy_bone_shapes"
    bl_label = "Copy bone shapes from active armature"
    bl_options = {'REGISTER', 'UNDO'}

    ignore_existing: bpy.props.BoolProperty(
        name="Ignore Existing Shapes",
        description="Skip bones that already have a shape with the same base name (ignoring .001, .002 etc)",
        default=True
    )

    @classmethod
    def poll(cls, context):
        # Check if active object is an armature
        return context.active_object and context.active_object.type == 'ARMATURE'

    def get_base_name(self, name):
        """Remove .001, .002 etc from the end of the name"""
        import re
        return re.sub(r'\.\d+$', '', name)

    def execute(self, context):
        source_armature = context.active_object
        
        # Iterate over all selected objects
        for obj in context.selected_objects:
            # Skip the source armature and any non-armature objects
            if obj == source_armature or obj.type != 'ARMATURE':
                continue
            
            print(f"Copying custom bone shapes to armature: {obj.name}")
            
            # Copy each bone's custom shape data from the source to the target armature
            for source_bone in source_armature.pose.bones:
                if source_bone.name in obj.pose.bones:
                    target_bone = obj.pose.bones[source_bone.name]
                    
                    # Check if we should skip this bone based on existing shape names
                    if self.ignore_existing and source_bone.custom_shape and target_bone.custom_shape:
                        source_shape_name = self.get_base_name(source_bone.custom_shape.name)
                        target_shape_name = self.get_base_name(target_bone.custom_shape.name)
                        
                        if source_shape_name == target_shape_name:
                            print(f"Skipping bone '{source_bone.name}' - already has matching shape")
                            continue
                    
                    target_bone.custom_shape = source_bone.custom_shape
                    target_bone.custom_shape_scale_xyz = source_bone.custom_shape_scale_xyz
                    target_bone.custom_shape_translation = source_bone.custom_shape_translation
                else:
                    print(f"Warning: Bone '{source_bone.name}' not found in armature '{obj.name}'")
        
        print("Bone shape copy complete!")
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "ignore_existing")


# -------------------------------------------------------------------
# 11) Registration
# -------------------------------------------------------------------

def register():
    from bpy.utils import register_class

    # Our properties
    bpy.types.Scene.correct_amount = bpy.props.IntProperty(
        name="Correct Amount",
        description="Number of smoothing iterations for Corrective Smooth",
        default=20,
        min=1,
        max=200
    )
    bpy.types.Scene.advanced_options = bpy.props.BoolProperty(
        name="Advanced Options",
        description="Toggle advanced shape-key muting & vertex group masking",
        default=False
    )
    bpy.types.Scene.mute_key_word = bpy.props.StringProperty(
        name="Mute Key Word",
        description="Shape keys containing this word (case-insensitive) will be muted (Excluded from smoothing)",
        default="head"
    )
    bpy.types.Scene.vertex_group_name = bpy.props.StringProperty(
        name="Vertex Group Mask",
        description="Limits the correction to the selected vertex group. If no group is selected, the entire mesh will be smoothed",
        default="Eyelids_Corrective smooth"
    )

    # New property for auto-splitting sides
    bpy.types.Scene.auto_split_lr = bpy.props.BoolProperty(
        name="Auto-Split LR",
        description="Automatically split left and right sides of created corrective",
        default=False
    )

    register_class(HHP_OT_create_delta_corrective)
    register_class(HHP_OT_split_sides_of_active_sk)
    register_class(HHP_OT_reset_advanced_settings)
    register_class(HHP_PT_experimental_creator_tools)
    register_class(HHP_OT_create_mask)
    register_class(HHP_OT_copy_bone_shapes)


def unregister():
    from bpy.utils import unregister_class

    del bpy.types.Scene.correct_amount
    del bpy.types.Scene.advanced_options
    del bpy.types.Scene.mute_key_word
    del bpy.types.Scene.vertex_group_name
    del bpy.types.Scene.auto_split_lr

    unregister_class(HHP_PT_experimental_creator_tools)
    unregister_class(HHP_OT_reset_advanced_settings)
    unregister_class(HHP_OT_split_sides_of_active_sk)
    unregister_class(HHP_OT_create_delta_corrective)
    unregister_class(HHP_OT_create_mask)
    unregister_class(HHP_OT_copy_bone_shapes)
