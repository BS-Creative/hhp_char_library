import bpy

# Function to check if all selected objects' materials are linked via 'OBJECT'
def is_material_linked_by_object(selected_objects):
    has_material = False
    for obj in selected_objects:
        if obj.type != 'MESH':
            continue
        if obj.material_slots:
            has_material = True
            for slot in obj.material_slots:
                if slot.link != 'OBJECT':
                    return False
    return has_material

# Function to toggle material link type
def toggle_material_link(selected_objects):
    current_link = None
    for obj in selected_objects:
        if obj.material_slots:
            current_link = obj.material_slots[0].link
            break

    if current_link is None:
        print("No materials found on selected objects.")
        return

    new_link = 'OBJECT' if current_link == 'DATA' else 'DATA'
    
    for obj in selected_objects:
        if obj.material_slots:
            for slot in obj.material_slots:
                slot.link = new_link

    print(f"Material link set to '{new_link}' for all selected objects.")
    bpy.context.view_layer.update()

# Function to check if heavy collections are hidden
def is_heavy_collections_hidden():
    # Find all collections that start with "Char (HHP)"
    char_collections = [col for col in bpy.data.collections if col.name.startswith("Char (HHP)")]

    # For each of these collections, find nested collections that start with "Clothes", "Hair", or "Char Appendage"
    collections_to_check = []
    for char_col in char_collections:
        collections_to_check.extend(find_collections_recursive(char_col, ["Clothes", "Hair", "Char Appendage"]))

    if not collections_to_check:
        return False  # No heavy collections found

    # If all collections_to_check have hide_viewport == True, return True
    all_hidden = all(col.hide_viewport for col in collections_to_check)
    return all_hidden

# Function to toggle heavy collections
def toggle_heavy_collections(context):
    scene = context.scene

    # Find all collections that start with "Char (HHP)"
    char_collections = [col for col in bpy.data.collections if col.name.startswith("Char (HHP)")]

    # For each of these collections, find nested collections that start with "Clothes", "Hair", or "Char Appendage"
    collections_to_toggle = []
    for char_col in char_collections:
        collections_to_toggle.extend(find_collections_recursive(char_col, ["Clothes", "Hair", "Char Appendage"]))

    if not collections_to_toggle:
        print("No 'Clothes', 'Hair', or 'Char Appendage' collections found inside 'Char (HHP)' collections.")
        return

    # Find all custom properties with "Mask -" in their name
    mask_properties = []
    
    # Check scene custom properties
    for prop_name in scene.keys():
        if "Mask -" in prop_name and isinstance(scene[prop_name], bool):
            mask_properties.append(('scene', prop_name, scene))
    
    # Check all objects' custom properties
    for obj in bpy.data.objects:
        for prop_name in obj.keys():
            if "Mask -" in prop_name and isinstance(obj[prop_name], bool):
                mask_properties.append(('object', prop_name, obj))

    all_hidden = all(col.hide_viewport for col in collections_to_toggle)

    if not all_hidden:
        # Collections are currently visible, hide them and store visibility states
        visibility_states = {}
        for col in collections_to_toggle:
            visibility_states[col.name] = col.hide_viewport
            col.hide_viewport = True  # Hide the collection

        # Store mask property states and set them to False
        mask_property_states = {}
        for prop_type, prop_name, obj in mask_properties:
            if prop_type == 'scene':
                mask_property_states[f"scene_{prop_name}"] = obj[prop_name]
                obj[prop_name] = False
            elif prop_type == 'object':
                mask_property_states[f"object_{obj.name}_{prop_name}"] = obj[prop_name]
                obj[prop_name] = False

        # Store the states in the scene
        scene['heavy_collections_visibility'] = visibility_states
        scene['mask_properties_states'] = mask_property_states
        
        # Refresh viewport by entering and exiting edit mode
        if context.active_object and context.active_object.type == 'MESH':
            current_mode = context.active_object.mode
            if current_mode == 'OBJECT':
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.object.mode_set(mode='OBJECT')
        
        print("Heavy collections hidden and mask properties disabled.")
    else:
        # Collections are currently hidden
        if 'heavy_collections_visibility' in scene:
            # Restore visibility states
            visibility_states = scene['heavy_collections_visibility']
            for col in collections_to_toggle:
                if col.name in visibility_states:
                    col.hide_viewport = visibility_states[col.name]
                else:
                    col.hide_viewport = False
            # Remove the stored visibility states
            del scene['heavy_collections_visibility']
            
            # Restore mask property states
            if 'mask_properties_states' in scene:
                mask_property_states = scene['mask_properties_states']
                for key, value in mask_property_states.items():
                    if key.startswith('scene_'):
                        prop_name = key[6:]  # Remove 'scene_' prefix
                        if prop_name in scene:
                            scene[prop_name] = value
                    elif key.startswith('object_'):
                        parts = key.split('_', 2)  # Split into ['object', obj_name, prop_name]
                        if len(parts) >= 3:
                            obj_name = parts[1]
                            prop_name = parts[2]
                            obj = bpy.data.objects.get(obj_name)
                            if obj and prop_name in obj:
                                obj[prop_name] = value
                del scene['mask_properties_states']
            
            # Refresh viewport by entering and exiting edit mode
            if context.active_object and context.active_object.type == 'MESH':
                current_mode = context.active_object.mode
                if current_mode == 'OBJECT':
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.object.mode_set(mode='OBJECT')
            
            print("Heavy collections visibility and mask properties restored.")
        else:
            # No stored visibility, show all heavy collections
            for col in collections_to_toggle:
                col.hide_viewport = False
            
            # Refresh viewport by entering and exiting edit mode
            if context.active_object and context.active_object.type == 'MESH':
                current_mode = context.active_object.mode
                if current_mode == 'OBJECT':
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.object.mode_set(mode='OBJECT')
            
            print("Heavy collections shown.")

def find_collections_recursive(collection, prefixes):
    matched_collections = []
    for child in collection.children:
        for prefix in prefixes:
            if child.name.startswith(prefix):
                matched_collections.append(child)
        # Recurse into children
        matched_collections.extend(find_collections_recursive(child, prefixes))
    return matched_collections

# Function for "Bind to Active" button
def add_surface_deform_to_selected(source_obj):
    if not source_obj or source_obj.type != 'MESH':
        print("Active object is not a mesh or is not selected.")
        return

    initial_selection = bpy.context.selected_objects.copy()
    initial_active = bpy.context.view_layer.objects.active

    bpy.ops.object.mode_set(mode='OBJECT')

    for obj in initial_selection:
        if obj == source_obj:
            continue

        surf_deform_mod = obj.modifiers.new(name="SurfaceDeform", type='SURFACE_DEFORM')
        surf_deform_mod.target = source_obj
        surf_deform_mod.show_in_editmode = True
        surf_deform_mod.show_on_cage = True

        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.surfacedeform_bind(modifier=surf_deform_mod.name)

    bpy.ops.object.select_all(action='DESELECT')
    for obj in initial_selection:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = initial_active

    print("Surface Deform modifiers added and bound to the active object.")

# Function for "Bind to Proxy" - excludes the original active mesh
def add_surface_deform_to_selected_excluding_active(source_obj, exclude_obj):
    if not source_obj or source_obj.type != 'MESH':
        print("Active object is not a mesh or is not selected.")
        return

    initial_selection = bpy.context.selected_objects.copy()
    initial_active = bpy.context.view_layer.objects.active

    bpy.ops.object.mode_set(mode='OBJECT')

    for obj in initial_selection:
        if obj == source_obj or obj == exclude_obj:
            continue

        surf_deform_mod = obj.modifiers.new(name="SurfaceDeform", type='SURFACE_DEFORM')
        surf_deform_mod.target = source_obj
        surf_deform_mod.show_in_editmode = True
        surf_deform_mod.show_on_cage = True

        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.surfacedeform_bind(modifier=surf_deform_mod.name)

    bpy.ops.object.select_all(action='DESELECT')
    for obj in initial_selection:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = initial_active

    print("Surface Deform modifiers added and bound to the proxy object.")

# Function for "Toggle Armatures (Smart)" button
def set_armature_state():
    pose_count = sum(1 for obj in bpy.data.objects if obj.type == 'ARMATURE' and obj.data.pose_position == 'POSE')
    rest_count = sum(1 for obj in bpy.data.objects if obj.type == 'ARMATURE' and obj.data.pose_position == 'REST')

    desired_state = 'REST' if pose_count > rest_count else 'POSE'

    for obj in bpy.data.objects:
        if obj.type == 'ARMATURE':
            obj.data.pose_position = desired_state
            obj.update_tag()
    bpy.context.view_layer.update()

    print(f"All armatures set to {desired_state} position.")

# Function for "Setup Render Basics" button
def setup_render_basics():
    # General render settings
    bpy.context.scene.unit_settings.system = 'METRIC'
    bpy.context.scene.render.use_simplify = True
    bpy.context.scene.render.simplify_subdivision = 0
    bpy.context.scene.render.simplify_subdivision_render = 3
    bpy.context.scene.render.use_motion_blur = False
    bpy.context.scene.sync_mode = 'AUDIO_SYNC'
    bpy.context.scene.render.use_persistent_data = True
    
    # Cycles settings
    if bpy.context.scene.cycles.transparent_max_bounces < 100:
        bpy.context.scene.cycles.transparent_max_bounces = 100
    
    # Eevee settings
    bpy.context.scene.eevee.use_taa_reprojection = False
    bpy.context.scene.eevee.use_shadow_jitter_viewport = False
    bpy.context.scene.eevee.taa_samples = 64
    bpy.context.scene.eevee.taa_render_samples = 64
    bpy.context.scene.eevee.use_overscan = True
    bpy.context.scene.eevee.overscan_size = 3
    bpy.context.scene.eevee.use_shadows = True
    bpy.context.scene.eevee.shadow_resolution_scale = 0.5
    bpy.context.scene.eevee.shadow_ray_count = 1
    bpy.context.scene.eevee.shadow_step_count = 6
    bpy.context.scene.eevee.use_raytracing = True
    bpy.context.scene.eevee.ray_tracing_method = 'SCREEN'
    bpy.context.scene.eevee.ray_tracing_options.resolution_scale = '1'
    bpy.context.scene.eevee.ray_tracing_options.trace_max_roughness = 0.5
    bpy.context.scene.eevee.ray_tracing_options.screen_trace_quality = 0.25
    bpy.context.scene.eevee.ray_tracing_options.screen_trace_thickness = 0.2
    bpy.context.scene.eevee.ray_tracing_options.use_denoise = True
    bpy.context.scene.eevee.ray_tracing_options.denoise_spatial = True
    bpy.context.scene.eevee.ray_tracing_options.denoise_temporal = True
    bpy.context.scene.eevee.ray_tracing_options.denoise_bilateral = True
    bpy.context.scene.eevee.fast_gi_method = 'GLOBAL_ILLUMINATION'
    bpy.context.scene.eevee.fast_gi_resolution = '2'
    bpy.context.scene.eevee.fast_gi_ray_count = 2
    bpy.context.scene.eevee.fast_gi_step_count = 8
    bpy.context.scene.eevee.fast_gi_quality = 0.25
    bpy.context.scene.eevee.fast_gi_distance = 0
    bpy.context.scene.eevee.fast_gi_thickness_near = 0.25
    bpy.context.scene.eevee.fast_gi_thickness_far = 0.785398
    bpy.context.scene.eevee.fast_gi_bias = 0.05
    print("Render setup basics applied.")

# Panel class
class HHP_PT_OptimizePanel(bpy.types.Panel):
    bl_label = "Optimize / Tools (HHP)"
    bl_idname = "HHP_PT_optimize_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Char (HHP)"
    bl_parent_id = "CHAR_HHP_PT_Panel"  # Set parent panel
    bl_options = {'HIDE_HEADER'}  # Hide the header
    bl_order = 15
    
    @classmethod
    def poll(cls, context):
        # Only show this panel if OPTIMIZE is selected in the mode selector
        return context.scene.hhp_panel_mode.selected_panel == 'OPTIMIZE'

    def draw(self, context):
        layout = self.layout

        # Create a box layout
        box = layout.box()
        box.label(text="Limit Texture Size (VRAM Optimizer)")
        col = box.column(align=True)
        col.operator("file.find_missing_files", text="Re-Link Textures")
        col.prop(bpy.context.preferences.system, "gl_texture_limit", text="")

        # Get the selected objects
        selected_objects = context.selected_objects

        # Check if materials are linked by OBJECT
        materials_linked_by_object = is_material_linked_by_object(selected_objects)

        # Prepare the label for the playback method
        scene = context.scene
        sync_mode = scene.sync_mode

        if sync_mode == 'NONE':
            playback_label = "Play Every Frame"
        elif sync_mode == 'AUDIO_SYNC':
            playback_label = "Sync to Audio"
        elif sync_mode == 'FRAME_DROP':
            playback_label = "Frame Dropping"
        else:
            playback_label = "Unknown"

        # Create aligned column for two-column button layout
        col = layout.column(align=True)
        
        # Row 1: Toggle optimized materials | Toggle optimized view
        row = col.row(align=True)
        row.operator("hhp.flip_material_link", text="Toggle optimized materials", icon='MATERIAL', depress=materials_linked_by_object)
        row.operator("hhp.toggle_heavy_collections", text="Toggle optimized view", icon='HIDE_OFF', depress=is_heavy_collections_hidden())
        
        # Row 2: Inflate SK by active | Bind to active
        row = col.row(align=True)
        row.operator("hhp.inflate_sk_by_active", text="Inflate SK by active", icon='SHAPEKEY_DATA')
        row.operator("hhp.bind_surface_deform", text="Bind to active", icon='MOD_LATTICE')
        
        # Row 3: Toggle armatures | Toggle playback method
        row = col.row(align=True)
        row.operator("hhp.toggle_armature_smart", text="Toggle armatures", icon='ARMATURE_DATA')
        row.operator("hhp.toggle_playback_method", text=playback_label, icon='PLAY')
        
        # Row 4: Create HHP Mask (full width since it's alone)
        row = col.row(align=True)
        row.operator("hhp.create_mask", text="Create HHP Mask", icon='MOD_MASK')

        # Add the Subsurface conversion button in its own full-width row
        row = layout.row(align=True)
        row.menu("SHADER_SSS_MT_menu", text="Shader setup", icon='BLENDER')

# Operator for "Flip Material Link"
class HHP_OT_FlipMaterialLink(bpy.types.Operator):
    bl_idname = "hhp.flip_material_link"
    bl_label = "Flip Material Link"
    bl_description = "Switches to optimized HHP materials for fast realtime animation playback. Handy to have on while animating"

    def execute(self, context):
        selected_objects = bpy.context.selected_objects
        if not any(obj.type == 'MESH' for obj in selected_objects):
            self.report({'ERROR'}, "Character mesh must be selected to toggle optimized materials")
            return {'CANCELLED'}
        toggle_material_link(selected_objects)
        return {'FINISHED'}

# Operator for "Toggle Heavy Collections"
class HHP_OT_ToggleHeavyCollections(bpy.types.Operator):
    bl_idname = "hhp.toggle_heavy_collections"
    bl_label = "Toggle Optimized View"
    bl_description = "Toggle optimized view mode: hide heavy collections (Clothes, Hair, Appendages) and disable mask properties for better performance."

    def execute(self, context):
        toggle_heavy_collections(context)
        return {'FINISHED'}

# Modified Operator for "Bind to Active"
class HHP_OT_BindSurfaceDeform(bpy.types.Operator):
    bl_idname = "hhp.bind_surface_deform"
    bl_label = "Bind Surface Deform"
    bl_description = "Bind surface deform modifiers from selected objects using the active object as target."

    def execute(self, context):
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.popup_menu(self.draw_menu, title="Bind Options")
        return {'FINISHED'}

    def draw_menu(self, menu, context):
        layout = menu.layout
        layout.operator("hhp.bind_surface_deform_normal", text="Bind to Active")
        layout.operator("hhp.bind_surface_deform_forced", text="Bind to Active (Forced)")
        layout.separator()
        layout.operator("hhp.bind_to_proxy_of_active", text="Bind to Proxy of Active")
        layout.operator("hhp.bind_to_proxy_of_active_forced", text="Bind to Proxy of Active (Forced)")

# Function to find proxy meshes with the same mesh data as the active object
def find_proxy_meshes(source_mesh):
    """Find all meshes that share the same mesh data as the source mesh"""
    if not source_mesh or source_mesh.type != 'MESH':
        return []
    
    # Find all objects with the same mesh data
    proxy_candidates = [
        obj for obj in bpy.data.objects
        if obj.type == 'MESH' and obj.data == source_mesh.data and obj != source_mesh
    ]
    
    return proxy_candidates

# New Operator for normal binding
class HHP_OT_BindSurfaceDeformNormal(bpy.types.Operator):
    bl_idname = "hhp.bind_surface_deform_normal"
    bl_label = "Bind Surface Deform Normal"
    bl_description = "Bind with surface deform modifiers from selected objects using the active object as target"

    def execute(self, context):
        source_obj = bpy.context.active_object
        add_surface_deform_to_selected(source_obj)
        return {'FINISHED'}

# New Operator for forced binding
class HHP_OT_BindSurfaceDeformForced(bpy.types.Operator):
    bl_idname = "hhp.bind_surface_deform_forced"
    bl_label = "Bind Surface Deform Forced"
    bl_description = "Bind with surface deform modifiers using triangulation method for difficult geometry"

    def execute(self, context):
        # Script 1: Add triangulate modifier
        if bpy.context.active_object and bpy.context.active_object.type == 'MESH':
            obj = bpy.context.active_object
            triangulate_mod = obj.modifiers.new(name="Triangulate", type='TRIANGULATE')
            triangulate_mod.quad_method = 'FIXED'
            triangulate_mod.ngon_method = 'BEAUTY'
            triangulate_mod.min_vertices = 4
            print("Triangulate modifier added with specified settings.")
        else:
            print("No suitable active object found or the active object cannot have modifiers.")

        # Script 2: Add surface deform
        source_obj = bpy.context.active_object
        add_surface_deform_to_selected(source_obj)

        # Script 3: Remove triangulate modifier
        if bpy.context.active_object and bpy.context.active_object.type == 'MESH':
            obj = bpy.context.active_object
            last_triangulate_modifier = None
            
            for modifier in obj.modifiers:
                if modifier.type == 'TRIANGULATE':
                    last_triangulate_modifier = modifier
            
            if last_triangulate_modifier:
                obj.modifiers.remove(last_triangulate_modifier)
                print("Last Triangulate modifier removed.")
            else:
                print("No Triangulate modifier found.")
        else:
            print("No suitable active mesh object found.")

        return {'FINISHED'}

# Operator for binding to deform proxy
class HHP_OT_BindToProxyOfActive(bpy.types.Operator):
    bl_idname = "hhp.bind_to_proxy_of_active"
    bl_label = "Bind to Proxy of Active"
    bl_description = "Bind with surface deform modifiers to a proxy mesh that shares the same mesh data as the active object"

    def execute(self, context):
        active_obj = bpy.context.active_object
        if not active_obj or active_obj.type != 'MESH':
            self.report({'ERROR'}, "Active object must be a mesh")
            return {'CANCELLED'}

        proxy_meshes = find_proxy_meshes(active_obj)
        if not proxy_meshes:
            self.report({'ERROR'}, "No proxy meshes found that share the same mesh data as the active object")
            return {'CANCELLED'}

        # Store the proxy meshes for the popup menu
        bpy.context.scene['proxy_meshes'] = [obj.name for obj in proxy_meshes]
        context.window_manager.popup_menu(self.draw_proxy_menu, title="Select Proxy Mesh")
        return {'FINISHED'}

    def draw_proxy_menu(self, menu, context):
        layout = menu.layout
        if 'proxy_meshes' in context.scene:
            proxy_names = context.scene['proxy_meshes']
            for proxy_name in proxy_names:
                proxy_obj = bpy.data.objects.get(proxy_name)
                if proxy_obj:
                    op = layout.operator("hhp.bind_to_proxy_execute", text=proxy_name)
                    op.proxy_name = proxy_name
                    op.is_forced = False

# Operator for binding to deform proxy (forced)
class HHP_OT_BindToProxyOfActiveForced(bpy.types.Operator):
    bl_idname = "hhp.bind_to_proxy_of_active_forced"
    bl_label = "Bind to Proxy of Active (Forced)"
    bl_description = "Bind with surface deform modifiers to a proxy mesh using triangulation method for difficult geometry"

    def execute(self, context):
        active_obj = bpy.context.active_object
        if not active_obj or active_obj.type != 'MESH':
            self.report({'ERROR'}, "Active object must be a mesh")
            return {'CANCELLED'}

        proxy_meshes = find_proxy_meshes(active_obj)
        if not proxy_meshes:
            self.report({'ERROR'}, "No proxy meshes found that share the same mesh data as the active object")
            return {'CANCELLED'}

        # Store the proxy meshes for the popup menu
        bpy.context.scene['proxy_meshes'] = [obj.name for obj in proxy_meshes]
        context.window_manager.popup_menu(self.draw_proxy_menu, title="Select Proxy Mesh")
        return {'FINISHED'}

    def draw_proxy_menu(self, menu, context):
        layout = menu.layout
        if 'proxy_meshes' in context.scene:
            proxy_names = context.scene['proxy_meshes']
            for proxy_name in proxy_names:
                proxy_obj = bpy.data.objects.get(proxy_name)
                if proxy_obj:
                    op = layout.operator("hhp.bind_to_proxy_execute", text=proxy_name)
                    op.proxy_name = proxy_name
                    op.is_forced = True

# Operator to execute the actual binding to proxy
class HHP_OT_BindToProxyExecute(bpy.types.Operator):
    bl_idname = "hhp.bind_to_proxy_execute"
    bl_label = "Execute Bind to Proxy"
    bl_description = "Execute the binding to the selected proxy mesh"

    proxy_name: bpy.props.StringProperty()
    is_forced: bpy.props.BoolProperty(default=False)

    def execute(self, context):
        proxy_obj = bpy.data.objects.get(self.proxy_name)
        if not proxy_obj:
            self.report({'ERROR'}, f"Proxy object '{self.proxy_name}' not found")
            return {'CANCELLED'}

        # Store the original active object to exclude it from binding
        original_active = bpy.context.view_layer.objects.active

        if self.is_forced:
            # Add triangulate modifier to proxy
            triangulate_mod = proxy_obj.modifiers.new(name="Triangulate", type='TRIANGULATE')
            triangulate_mod.quad_method = 'FIXED'
            triangulate_mod.ngon_method = 'BEAUTY'
            triangulate_mod.min_vertices = 4
            print(f"Triangulate modifier added to {proxy_obj.name}")

        # Add surface deform using the proxy as target, but exclude the original active mesh
        add_surface_deform_to_selected_excluding_active(proxy_obj, original_active)

        if self.is_forced:
            # Remove triangulate modifier from proxy
            last_triangulate_modifier = None
            for modifier in proxy_obj.modifiers:
                if modifier.type == 'TRIANGULATE':
                    last_triangulate_modifier = modifier
            
            if last_triangulate_modifier:
                proxy_obj.modifiers.remove(last_triangulate_modifier)
                print(f"Triangulate modifier removed from {proxy_obj.name}")

        # Clean up the stored proxy meshes
        if 'proxy_meshes' in context.scene:
            del context.scene['proxy_meshes']

        return {'FINISHED'}

# Operator for "Toggle Armatures (Smart)"
class HHP_OT_ToggleArmatureSmart(bpy.types.Operator):
    bl_idname = "hhp.toggle_armature_smart"
    bl_label = "Toggle Armatures (Smart)"
    bl_description = "Toggle between REST and POSE modes for armatures based on current state."

    def execute(self, context):
        set_armature_state()
        return {'FINISHED'}

# Operator for "Setup Render Basics"
class HHP_OT_SetupRenderBasics(bpy.types.Operator):
    bl_idname = "hhp.setup_render_basics"
    bl_label = "Setup Render Basics"
    bl_description = "Apply basic render settings for both Eevee and Cycles engines for optimal character rendering and performance"

    def execute(self, context):
        setup_render_basics()
        self.report({'INFO'}, "Render setup basics applied")
        return {'FINISHED'}

# Operator for "Toggle Playback Method"
class HHP_OT_TogglePlaybackMethod(bpy.types.Operator):
    bl_idname = "hhp.toggle_playback_method"
    bl_label = "Toggle Playback Method"
    bl_description = "Toggle playback method between 'Sync to Audio' and 'Play Every Frame'."

    def execute(self, context):
        scene = context.scene
        current_mode = scene.sync_mode

        if current_mode == 'AUDIO_SYNC':
            scene.sync_mode = 'NONE'
            self.report({'INFO'}, "Playback method set to 'Play Every Frame'")
        else:
            scene.sync_mode = 'AUDIO_SYNC'
            self.report({'INFO'}, "Playback method set to 'Sync to Audio'")

        return {'FINISHED'}

# Register the panel and operators
def register():
    bpy.utils.register_class(HHP_PT_OptimizePanel)
    bpy.utils.register_class(HHP_OT_FlipMaterialLink)
    bpy.utils.register_class(HHP_OT_ToggleHeavyCollections)
    bpy.utils.register_class(HHP_OT_BindSurfaceDeform)
    bpy.utils.register_class(HHP_OT_BindSurfaceDeformNormal)
    bpy.utils.register_class(HHP_OT_BindSurfaceDeformForced)
    bpy.utils.register_class(HHP_OT_BindToProxyOfActive)
    bpy.utils.register_class(HHP_OT_BindToProxyOfActiveForced)
    bpy.utils.register_class(HHP_OT_BindToProxyExecute)
    bpy.utils.register_class(HHP_OT_ToggleArmatureSmart)
    bpy.utils.register_class(HHP_OT_SetupRenderBasics)
    bpy.utils.register_class(HHP_OT_TogglePlaybackMethod)

def unregister():
    bpy.utils.unregister_class(HHP_PT_OptimizePanel)
    bpy.utils.unregister_class(HHP_OT_FlipMaterialLink)
    bpy.utils.unregister_class(HHP_OT_ToggleHeavyCollections)
    bpy.utils.unregister_class(HHP_OT_BindSurfaceDeform)
    bpy.utils.unregister_class(HHP_OT_BindSurfaceDeformNormal)
    bpy.utils.unregister_class(HHP_OT_BindSurfaceDeformForced)
    bpy.utils.unregister_class(HHP_OT_BindToProxyOfActive)
    bpy.utils.unregister_class(HHP_OT_BindToProxyOfActiveForced)
    bpy.utils.unregister_class(HHP_OT_BindToProxyExecute)
    bpy.utils.unregister_class(HHP_OT_ToggleArmatureSmart)
    bpy.utils.unregister_class(HHP_OT_SetupRenderBasics)
    bpy.utils.unregister_class(HHP_OT_TogglePlaybackMethod)

if __name__ == "__main__":
    register()
