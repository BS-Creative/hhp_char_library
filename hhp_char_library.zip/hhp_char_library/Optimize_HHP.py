import bpy
from bpy.props import BoolProperty, EnumProperty, StringProperty
from .modules import use_optimized_normals_node
from .modules import hhp_naming
import re
import hashlib
import json

_ENUM_SUFFIX_RE = re.compile(r"\.(\d{3})$")
HHP_PROXY_PREFIX = "(BS)_Proxy_"
PRIMARY_FULLBODY_PROXY_NAME = "Deform Proxy - Primary (Fullbody)"
HHP_BIND_PROXY_MESHES_KEY = "hhp_bind_proxy_meshes"
hhp_node_group_cache = {}


def _get_enumeration_number(name: str) -> int:
    """Return Blender-style .001 enumeration as int, or 0 if not enumerated."""
    if not name:
        return 0
    m = _ENUM_SUFFIX_RE.search(name)
    if not m:
        return 0
    try:
        return int(m.group(1))
    except Exception:
        return 0


def _get_base_name(name: str) -> str:
    """Strip Blender-style .001 suffix if present."""
    if not name:
        return ""
    m = _ENUM_SUFFIX_RE.search(name)
    return name[: m.start()] if m else name


def _char_state_token(char_col) -> str:
    """Stable short token for per-character scene state keys (keeps IDProperty names <= 63 chars)."""
    name = getattr(char_col, "name", "") or ""
    return hashlib.sha1(name.encode("utf-8")).hexdigest()[:12]


def _scene_state_key(prefix: str, char_col) -> str:
    return f"{prefix}__{_char_state_token(char_col)}"


def _legacy_scene_state_key(prefix: str, char_col) -> str:
    return f"{prefix}__{char_col.name}"


def _existing_scene_state_key(scene, prefix: str, char_col) -> str:
    """Return active key if present (new hashed key first), otherwise return new hashed key."""
    key = _scene_state_key(prefix, char_col)
    if key in scene:
        return key
    legacy_key = _legacy_scene_state_key(prefix, char_col)
    if legacy_key in scene:
        return legacy_key
    return key


def _is_hhp_character_mesh(obj) -> bool:
    """Mirror the 'Select HHP Character' dropdown detection logic from __init__.py."""
    return hhp_naming.is_char_mesh(obj)


def _iter_layer_collections(root_lc, inherited_excluded=False, inherited_hidden=False):
    eff_excluded = inherited_excluded or bool(getattr(root_lc, "exclude", False))
    eff_hidden = inherited_hidden or bool(getattr(root_lc, "hide_viewport", False))
    yield root_lc, eff_excluded, eff_hidden
    for child in getattr(root_lc, "children", []):
        yield from _iter_layer_collections(child, eff_excluded, eff_hidden)


def _get_view_layer_collection_flags(context):
    """Map bpy.data.collections -> (effective_excluded, effective_hidden) in current view layer."""
    flags = {}
    try:
        for lc, eff_excluded, eff_hidden in _iter_layer_collections(context.view_layer.layer_collection):
            flags[lc.collection] = (eff_excluded, eff_hidden)
    except Exception:
        pass
    return flags


def _find_visible_char_hhp_collections(context):
    """Return visible, non-excluded collections in the scene tree whose name contains 'Char (HHP)'."""
    col_flags = _get_view_layer_collection_flags(context)

    char_cols = []
    try:
        stack = [context.scene.collection]
        seen = set()
        while stack:
            col = stack.pop()
            if col is None or col.name in seen:
                continue
            seen.add(col.name)

            if "Char (HHP)" in col.name:
                if not bool(getattr(col, "hide_viewport", False)):
                    eff = col_flags.get(col)
                    if eff is not None:
                        eff_excluded, eff_hidden = eff
                        if not eff_excluded and not eff_hidden:
                            char_cols.append(col)

            stack.extend(list(getattr(col, "children", [])))
    except Exception:
        return []

    char_cols.sort(key=lambda c: (_get_base_name(c.name).lower(), _get_enumeration_number(c.name), c.name.lower()))
    return char_cols


def _get_all_hhp_character_targets(context):
    """Return every (character mesh, Char (HHP) collection) pair in the scene."""
    targets = []
    stack = [getattr(context.scene, "collection", None)]
    seen_collections = set()

    while stack:
        col = stack.pop()
        if col is None:
            continue

        col_pointer = col.as_pointer()
        if col_pointer in seen_collections:
            continue
        seen_collections.add(col_pointer)
        stack.extend(list(getattr(col, "children", [])))

        if "Char (HHP)" not in getattr(col, "name", ""):
            continue

        character_meshes = [
            obj for obj in list(getattr(col, "objects", []))
            if _is_hhp_character_mesh(obj)
        ]
        if not character_meshes:
            continue

        character_meshes.sort(
            key=lambda obj: (
                _get_base_name(obj.name).lower(),
                _get_enumeration_number(obj.name),
                obj.name.lower(),
            )
        )
        targets.append((character_meshes[0], col))

    targets.sort(
        key=lambda target: (
            _get_base_name(target[1].name).lower(),
            _get_enumeration_number(target[1].name),
            target[1].name.lower(),
        )
    )
    return targets


def _build_collection_parent_map(root_collection):
    """Build a mapping {child_collection: parent_collection} for the scene collection tree."""
    parent_map = {}
    if root_collection is None:
        return parent_map

    stack = [root_collection]
    seen = set()
    while stack:
        col = stack.pop()
        if col is None or col in seen:
            continue
        seen.add(col)
        for child in getattr(col, "children", []):
            if child is None:
                continue
            # First parent encountered is fine for our use (Blender collections can be linked multiple places,
            # but Char (HHP) characters are expected to live in one hierarchy).
            parent_map.setdefault(child, col)
            stack.append(child)
    return parent_map


def _find_char_hhp_collection_for_object(context, obj):
    """
    Given ANY object (even deep inside sub-collections), find the topmost parent collection
    in its hierarchy that contains 'Char (HHP)' in the name.

    This lets us scope actions to the correct character even when the active object is a clothing mesh
    in a sub-sub-sub collection.
    """
    if obj is None:
        return None

    parent_map = _build_collection_parent_map(getattr(context.scene, "collection", None))
    candidates = []

    for start_col in getattr(obj, "users_collection", []) or []:
        col = start_col
        topmost_char = None
        while col is not None:
            if "Char (HHP)" in getattr(col, "name", ""):
                # Keep updating so we end up with the HIGHEST parent Char (HHP) in this chain.
                topmost_char = col
            col = parent_map.get(col)
        if topmost_char is not None:
            candidates.append(topmost_char)

    if not candidates:
        return None

    # Prefer lowest enumeration collection (Char (HHP) vs Char (HHP).001)
    candidates.sort(key=lambda c: (_get_base_name(c.name).lower(), _get_enumeration_number(c.name), c.name.lower()))
    return candidates[0]


def _hhp_select_make_active(context, obj):
    """Switch to Object Mode, deselect all, then select the object and make it active."""
    try:
        if getattr(context, "mode", None) != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        pass

    try:
        bpy.ops.object.select_all(action='DESELECT')
    except Exception:
        try:
            for o in context.view_layer.objects:
                o.select_set(False)
        except Exception:
            pass

    try:
        obj.select_set(True)
    except Exception:
        pass
    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass


def _auto_select_hhp_character_for_current_context(context):
    """
    Auto-select an HHP character mesh to operate on:
    - If the current active object is inside a Char (HHP) collection, select the lowest-enumeration HHP mesh in that collection.
    - Otherwise select the lowest-enumeration HHP mesh in the lowest-enumeration visible Char (HHP) collection.
    """
    active = getattr(context, "active_object", None)

    def _lowest_hhp_mesh_in_collection(col):
        meshes = [o for o in list(getattr(col, "objects", [])) if _is_hhp_character_mesh(o)]
        if not meshes:
            return None
        meshes.sort(key=lambda o: (_get_base_name(o.name).lower(), _get_enumeration_number(o.name), o.name.lower()))
        return meshes[0]

    # Prefer "current character context": walk up the active object's collection tree to the top Char (HHP).
    if active is not None:
        char_col = _find_char_hhp_collection_for_object(context, active)
        if char_col is not None:
            target = _lowest_hhp_mesh_in_collection(char_col)
            if target:
                _hhp_select_make_active(context, target)
                return target

    # Only if we can't infer a containing Char (HHP) collection, fall back to searching visible Char (HHP) collections.
    # (This prevents selecting a different character elsewhere in the scene when you're already inside Char (HHP).001.)
    for col in _find_visible_char_hhp_collections(context):
        target = _lowest_hhp_mesh_in_collection(col)
        if target:
            _hhp_select_make_active(context, target)
            return target

    return None


def _get_target_hhp_character_for_current_collection(context, auto_select=False):
    """
    Return (character_mesh_obj, char_collection, error_message).

    We scope actions to the active HHP character mesh's direct "Char (HHP)" collection,
    and require BOTH the collection and mesh to be the lowest enumeration (to avoid duplicates).
    """
    obj = getattr(context, "active_object", None)
    if auto_select and not _is_hhp_character_mesh(obj):
        obj = _auto_select_hhp_character_for_current_context(context)

    if not _is_hhp_character_mesh(obj):
        return None, None, "No HHP character mesh found to operate on."

    # Find the direct Char (HHP) collection(s) this mesh is inside.
    char_cols = [c for c in getattr(obj, "users_collection", []) if c and "Char (HHP)" in c.name]
    if not char_cols:
        return None, None, "HHP character mesh must be directly inside a 'Char (HHP)' collection."

    # Prefer the lowest-enumeration Char (HHP) collection (avoid '.001' duplicates).
    def _col_sort_key(c):
        return (_get_base_name(c.name).lower(), _get_enumeration_number(c.name), c.name.lower())

    char_cols.sort(key=_col_sort_key)
    char_col = char_cols[0]

    # Enforce mesh is the lowest enumeration inside this collection (avoid '.001' duplicates).
    mesh_base = _get_base_name(obj.name)
    mesh_candidates = [o for o in list(char_col.objects) if _is_hhp_character_mesh(o) and _get_base_name(o.name) == mesh_base]
    if mesh_candidates:
        mesh_candidates.sort(key=lambda o: (_get_enumeration_number(o.name), o.name.lower()))
        lowest_mesh = mesh_candidates[0]
        if obj != lowest_mesh:
            if auto_select:
                obj = lowest_mesh
                _hhp_select_make_active(context, obj)
            else:
                return None, None, f"Active HHP character mesh must be the lowest enumeration in '{char_col.name}' (use '{lowest_mesh.name}', not '{obj.name}')."

    return obj, char_col, None

# Function to check if all selected objects' materials are linked via 'OBJECT'
def is_material_linked_by_object(selected_objects):
    has_material = False
    for obj in selected_objects:
        if obj.type != 'MESH':
            continue
        if obj.material_slots:
            has_material = True
            for slot in obj.material_slots:
                if slot.link != 'OBJECT':
                    return False
    return has_material


def is_optimized_materials_active(context=None):
    """Return True when any HHP character in the scene uses optimized materials."""
    context = context or bpy.context
    return any(
        is_material_linked_by_object([char_obj])
        for char_obj, _char_col in _get_all_hhp_character_targets(context)
    )


def set_material_link(objects, link):
    """Set every material slot on the supplied meshes to one link mode."""
    changed_slots = 0
    seen_objects = set()
    for obj in objects:
        if obj is None or obj.type != 'MESH':
            continue
        obj_pointer = obj.as_pointer()
        if obj_pointer in seen_objects:
            continue
        seen_objects.add(obj_pointer)
        for slot in obj.material_slots:
            if slot.link != link:
                slot.link = link
                changed_slots += 1
    bpy.context.view_layer.update()
    return changed_slots


# Function to toggle material link type
def toggle_material_link(selected_objects):
    current_link = None
    for obj in selected_objects:
        if obj.material_slots:
            current_link = obj.material_slots[0].link
            break

    if current_link is None:
        print("No materials found on selected objects.")
        return

    new_link = 'OBJECT' if current_link == 'DATA' else 'DATA'
    
    for obj in selected_objects:
        if obj.material_slots:
            for slot in obj.material_slots:
                slot.link = new_link

    print(f"Material link set to '{new_link}' for all selected objects.")
    bpy.context.view_layer.update()


def hhp_proxy_base_name(name: str) -> str:
    already_proxy = name.startswith(HHP_PROXY_PREFIX)
    proxied = name if already_proxy else (HHP_PROXY_PREFIX + name)
    m = re.match(r"^(.*)\.\d{3}$", proxied)
    if m:
        proxied = m.group(1)
    if already_proxy:
        m = re.match(r"^(.*)_\d+$", proxied)
        if m:
            proxied = m.group(1)
    return proxied


def hhp_unique_name(base_name, existing_names):
    if base_name not in existing_names:
        legacy_pattern = re.compile(rf"^{re.escape(base_name)}_(\d+)$")
        dot_pattern = re.compile(rf"^{re.escape(base_name)}\.(\d{{3}})$")
        if not any(legacy_pattern.match(n) or dot_pattern.match(n) for n in existing_names):
            return base_name

    max_index = 0 if base_name in existing_names else -1
    legacy_pattern = re.compile(rf"^{re.escape(base_name)}_(\d+)$")
    dot_pattern = re.compile(rf"^{re.escape(base_name)}\.(\d{{3}})$")
    for name in existing_names:
        m = legacy_pattern.match(name)
        if m:
            max_index = max(max_index, int(m.group(1)))
            continue
        m = dot_pattern.match(name)
        if m:
            max_index = max(max_index, int(m.group(1)))

    index = max_index + 1
    unique_name_val = f"{base_name}.{index:03d}"
    while unique_name_val in existing_names:
        index += 1
        unique_name_val = f"{base_name}.{index:03d}"
    return unique_name_val


def hhp_duplicate_node_group(node_group, all_node_group_names):
    if node_group is None:
        return None
    try:
        source_name = node_group.name
    except ReferenceError:
        return None
    if source_name in hhp_node_group_cache:
        return hhp_node_group_cache.get(source_name, None)

    proxy_name = hhp_unique_name(hhp_proxy_base_name(source_name), all_node_group_names)
    node_group_copy = node_group.copy()
    node_group_copy.name = proxy_name
    hhp_node_group_cache[source_name] = node_group_copy
    all_node_group_names.add(proxy_name)

    for node in list(node_group_copy.nodes):
        if node.type == 'GROUP':
            duplicated = hhp_duplicate_node_group(node.node_tree, all_node_group_names)
            if duplicated is not None:
                node.node_tree = duplicated
    return node_group_copy


def hhp_is_proxy_material(material):
    return material is not None and material.name.startswith(HHP_PROXY_PREFIX)


def hhp_clear_proxified_materials_from_objects(objects, purge_unrelated_groups=True):
    objects = tuple(objects)
    owned_proxy_groups = set()
    if not purge_unrelated_groups:
        # Transfer refreshes only retire the proxy trees belonging to their meshes.
        pending = []
        for obj in objects:
            if obj.type != 'MESH':
                continue
            for slot in obj.material_slots:
                link = slot.link
                slot.link = 'OBJECT'
                material = slot.material
                if hhp_is_proxy_material(material) and material.node_tree:
                    pending.append(material.node_tree)
                slot.link = link
        visited = set()
        while pending:
            tree = pending.pop()
            pointer = tree.as_pointer()
            if pointer in visited:
                continue
            visited.add(pointer)
            for node in tree.nodes:
                if node.type == 'GROUP' and node.node_tree:
                    owned_proxy_groups.add(node.node_tree.as_pointer())
                    pending.append(node.node_tree)
    cleared_materials = {}
    affected_mesh_count = 0
    unlinked_slot_count = 0

    for obj in objects:
        if obj.type != 'MESH':
            continue

        material_slots = list(obj.material_slots)
        affected_mesh = False
        for slot in material_slots:
            if slot.link == 'OBJECT':
                material = slot.material
                affected_mesh = True
                if hhp_is_proxy_material(material):
                    material.use_fake_user = False
                    cleared_materials.setdefault(material.as_pointer(), material)
                if material:
                    slot.material = None
                    unlinked_slot_count += 1
                slot.link = 'DATA'
                continue

            # A Data-linked slot can still retain an old Object-linked proxy
            # override. Temporarily expose that hidden override so it can be
            # removed before rebuilding the proxy materials.
            slot.link = 'OBJECT'
            hidden_object_material = slot.material
            if hhp_is_proxy_material(hidden_object_material):
                hidden_object_material.use_fake_user = False
                cleared_materials.setdefault(
                    hidden_object_material.as_pointer(),
                    hidden_object_material,
                )
                slot.material = None
                unlinked_slot_count += 1
                affected_mesh = True
            slot.link = 'DATA'

        if affected_mesh:
            affected_mesh_count += 1

    # Remove replaced proxy materials immediately instead of leaving them as
    # orphaned datablocks until the blend file is reopened or manually purged.
    for material in list(cleared_materials.values()):
        if material.users == 0:
            bpy.data.materials.remove(material, do_unlink=True)

    # Proxy node groups can reference other proxy node groups. Repeated passes
    # remove parents first, then children once their user counts reach zero.
    while True:
        orphaned_proxy_groups = [
            node_group for node_group in bpy.data.node_groups
            if node_group.name.startswith(HHP_PROXY_PREFIX) and node_group.users == 0
            and (purge_unrelated_groups or node_group.as_pointer() in owned_proxy_groups)
        ]
        if not orphaned_proxy_groups:
            break
        for node_group in orphaned_proxy_groups:
            bpy.data.node_groups.remove(node_group, do_unlink=True)

    return len(cleared_materials), affected_mesh_count, unlinked_slot_count


def hhp_adjust_material_slots(objects):
    for obj in objects:
        if obj.type != 'MESH':
            continue

        data_linked_materials = [slot.material for slot in obj.material_slots]
        for slot, material in zip(obj.material_slots, data_linked_materials):
            slot.link = 'OBJECT'
            slot.material = material


def hhp_process_materials(objects):
    all_material_names = {mat.name for mat in bpy.data.materials}
    all_node_group_names = {ng.name for ng in bpy.data.node_groups}
    proxified_material_count = 0
    proxified_mesh_names = set()

    hhp_node_group_cache.clear()
    for obj in objects:
        if obj.type != 'MESH':
            continue

        for slot in obj.material_slots:
            material = slot.material
            if not material or not material.use_nodes:
                continue

            proxy_name = hhp_unique_name(hhp_proxy_base_name(material.name), all_material_names)
            if proxy_name == hhp_proxy_base_name(material.name) and proxy_name in all_material_names:
                continue

            material_copy = material.copy()
            material_copy.name = proxy_name
            slot.material = material_copy
            all_material_names.add(proxy_name)
            proxified_material_count += 1
            proxified_mesh_names.add(obj.name)

            for node in list(material_copy.node_tree.nodes):
                if node.type == 'GROUP':
                    duplicated = hhp_duplicate_node_group(node.node_tree, all_node_group_names)
                    if duplicated is not None:
                        node.node_tree = duplicated

    return proxified_material_count, len(proxified_mesh_names)


def hhp_delete_drivers_from_nodetree(nodetree):
    if nodetree and nodetree.animation_data:
        for driver in reversed(nodetree.animation_data.drivers):
            nodetree.driver_remove(driver.data_path)


def hhp_handle_node_groups(nodetree):
    if nodetree is None:
        return

    hhp_delete_drivers_from_nodetree(nodetree)
    for node in nodetree.nodes:
        if node.type == 'GROUP':
            hhp_handle_node_groups(node.node_tree)


def hhp_unlink_actions_from_nla_tracks(nla_tracks):
    for track in nla_tracks:
        for strip in track.strips:
            strip.action = None


def hhp_unlink_actions_from_node_tree(node_tree):
    if node_tree is None:
        return

    if node_tree.animation_data:
        if node_tree.animation_data.action:
            node_tree.animation_data.action = None
        if node_tree.animation_data.nla_tracks:
            hhp_unlink_actions_from_nla_tracks(node_tree.animation_data.nla_tracks)

    for node in node_tree.nodes:
        if node.type == 'GROUP':
            hhp_unlink_actions_from_node_tree(node.node_tree)


def hhp_unlink_actions_from_material(material):
    if material is None:
        return

    if material.animation_data:
        if material.animation_data.action:
            material.animation_data.action = None
        if material.animation_data.nla_tracks:
            hhp_unlink_actions_from_nla_tracks(material.animation_data.nla_tracks)

    if material.node_tree:
        hhp_unlink_actions_from_node_tree(material.node_tree)


def hhp_proxify_materials(objects):
    for obj in objects:
        if obj.type == 'MESH':
            for slot in obj.material_slots:
                if slot.material:
                    slot.material.use_fake_user = True

    hhp_adjust_material_slots(objects)
    proxified_material_count, proxified_mesh_count = hhp_process_materials(objects)

    proxified_materials = []
    proxified_material_pointers = set()
    for obj in objects:
        if obj.type != 'MESH':
            continue
        for slot in obj.material_slots:
            material = slot.material
            if not hhp_is_proxy_material(material):
                continue
            material_pointer = material.as_pointer()
            if material_pointer not in proxified_material_pointers:
                proxified_material_pointers.add(material_pointer)
                proxified_materials.append(material)
    use_optimized_normals_node.apply_optimized_normals_to_materials(proxified_materials)

    for obj in objects:
        if obj.type == 'MESH':
            for slot in obj.material_slots:
                if slot.material and slot.material.node_tree:
                    hhp_handle_node_groups(slot.material.node_tree)
                if slot.material:
                    hhp_unlink_actions_from_material(slot.material)
                    slot.material.use_fake_user = True

    bpy.context.view_layer.update()
    return proxified_material_count, proxified_mesh_count

# Function to check if optimized view is active on any HHP character
def is_heavy_collections_hidden(context=None):
    context = context or bpy.context
    return any(
        is_optimized_view_active_for_char_collection(context, char_col)
        for _char_obj, char_col in _get_all_hhp_character_targets(context)
    )


def is_optimized_view_active_for_char_collection(context, char_col):
    """Return whether optimized view is active for a specific Char (HHP) collection."""
    if not char_col:
        return False

    session_active, _session_mode = _get_optimized_view_session_state(context.scene, char_col)
    if session_active:
        # Keep the toggle visually "on" while any optimized-view session is active,
        # until explicit restore via the toggle.
        return True

    collections_to_check = find_collections_recursive(char_col, ["Clothes", "Hair", "Char Appendage"])
    if not collections_to_check:
        return False
    return all(col.hide_viewport for col in collections_to_check)


def _get_optimized_view_session_state(scene, char_col):
    """Return (is_active, mode) for optimized view session state for this character."""
    vis_key = _existing_scene_state_key(scene, "heavy_collections_visibility", char_col)
    mask_key = _existing_scene_state_key(scene, "mask_properties_states", char_col)
    mode_key = _existing_scene_state_key(scene, "optimized_view_mode", char_col)
    mod_key = _existing_scene_state_key(scene, "modifier_viewport_states", char_col)
    simplify_key = _existing_scene_state_key(scene, "viewport_simplify_states", char_col)

    is_active = any(k in scene for k in (vis_key, mask_key, mode_key, mod_key, simplify_key))
    mode = str(scene.get(mode_key, "")) if mode_key in scene else ""
    return is_active, mode


def get_optimized_view_button_text(context=None):
    """Return the global optimized-view state label for all HHP characters."""
    context = context or bpy.context
    active_modes = []
    has_active_view = False
    for _char_obj, char_col in _get_all_hhp_character_targets(context):
        if not is_optimized_view_active_for_char_collection(context, char_col):
            continue
        has_active_view = True
        session_active, session_mode = _get_optimized_view_session_state(context.scene, char_col)
        if session_active:
            active_modes.append(session_mode)

    if 'FULL' in active_modes:
        return "Optimized View: Full"
    if has_active_view:
        return "Optimized View: Partial"
    return "Optimized View"


def _get_active_and_linked_meshes(active_obj):
    """Return the active mesh and all meshes linked to the same mesh data block."""
    if not active_obj or active_obj.type != 'MESH':
        return []

    linked_meshes = [
        obj for obj in bpy.data.objects
        if obj.type == 'MESH' and obj.data == active_obj.data
    ]
    if active_obj not in linked_meshes:
        linked_meshes.append(active_obj)

    linked_meshes.sort(key=lambda o: o.name.lower())
    return linked_meshes


def _store_and_disable_modifier_viewport_states(scene, char_col, source_mesh_obj):
    """Store modifier viewport states and disable non-armature modifiers for active+linked meshes."""
    mod_key = _scene_state_key("modifier_viewport_states", char_col)
    modifier_states = []

    for obj in _get_active_and_linked_meshes(source_mesh_obj):
        for mod in obj.modifiers:
            if mod.type == 'ARMATURE':
                continue
            if obj != source_mesh_obj and mod.type == 'MASK':
                # Linked meshes: keep mask modifiers untouched in Full mode.
                continue
            modifier_states.append([obj.name, mod.name, bool(mod.show_viewport)])
            mod.show_viewport = False

    # Store as JSON to avoid Blender IDProperty nested-key length limits.
    scene[mod_key] = json.dumps(modifier_states, separators=(",", ":"))


def _restore_modifier_viewport_states(scene, char_col):
    """Restore modifier viewport states previously stored for full optimized view."""
    mod_key = _existing_scene_state_key(scene, "modifier_viewport_states", char_col)
    if mod_key not in scene:
        return

    stored_payload = scene[mod_key]

    # New format: JSON list [[obj_name, mod_name, stored_value], ...]
    if isinstance(stored_payload, str):
        try:
            modifier_states = json.loads(stored_payload)
        except Exception:
            modifier_states = []

        if isinstance(modifier_states, list):
            for entry in modifier_states:
                if not isinstance(entry, (list, tuple)) or len(entry) < 3:
                    continue
                obj_name, mod_name, stored_value = entry[0], entry[1], entry[2]

                obj = bpy.data.objects.get(obj_name)
                if not obj or obj.type != 'MESH':
                    continue

                mod = obj.modifiers.get(mod_name)
                if mod and mod.type != 'ARMATURE':
                    mod.show_viewport = bool(stored_value)

    # Legacy format: dict {"obj|||mod": bool}
    elif isinstance(stored_payload, dict):
        for state_key, stored_value in stored_payload.items():
            obj_name, sep, mod_name = str(state_key).partition("|||")
            if not sep:
                continue

            obj = bpy.data.objects.get(obj_name)
            if not obj or obj.type != 'MESH':
                continue

            mod = obj.modifiers.get(mod_name)
            if mod and mod.type != 'ARMATURE':
                mod.show_viewport = bool(stored_value)

    del scene[mod_key]


def _store_and_apply_viewport_simplify_state(scene, char_col):
    """Store scene simplify settings, then force full optimized view simplify values."""
    simplify_key = _scene_state_key("viewport_simplify_states", char_col)
    render = scene.render
    simplify_state = {
        "use_simplify": bool(render.use_simplify),
        "simplify_subdivision": int(render.simplify_subdivision),
    }

    scene[simplify_key] = json.dumps(simplify_state, separators=(",", ":"))
    render.use_simplify = True
    render.simplify_subdivision = 0


def _restore_viewport_simplify_state(scene, char_col):
    """Restore scene simplify settings previously stored for full optimized view."""
    simplify_key = _existing_scene_state_key(scene, "viewport_simplify_states", char_col)
    if simplify_key not in scene:
        return

    render = scene.render
    stored_payload = scene[simplify_key]

    if isinstance(stored_payload, str):
        try:
            simplify_state = json.loads(stored_payload)
        except Exception:
            simplify_state = {}
    elif isinstance(stored_payload, dict):
        simplify_state = stored_payload
    else:
        simplify_state = {}

    if isinstance(simplify_state, dict):
        if "use_simplify" in simplify_state:
            render.use_simplify = bool(simplify_state["use_simplify"])
        if "simplify_subdivision" in simplify_state:
            render.simplify_subdivision = int(simplify_state["simplify_subdivision"])

    del scene[simplify_key]


def _store_and_disable_hhp_deform_modifiers_in_collection(collection):
    """Use the customize preset visibility path for HHP deform modifiers."""
    try:
        from . import Customize_HHP
        Customize_HHP.hhp_store_and_disable_deform_modifiers_in_collection(collection)
    except Exception:
        pass


def _restore_hhp_deform_modifiers_in_collection(collection):
    """Restore HHP deform modifiers only for objects visible after optimized view restore."""
    try:
        from . import Customize_HHP
        Customize_HHP.hhp_restore_deform_modifiers_in_collection(collection)
    except Exception:
        pass


# Function to toggle heavy collections for one explicit HHP character
def toggle_heavy_collections(context, mode='PARTIAL', char_obj=None, char_col=None):
    scene = context.scene
    if char_obj is None or char_col is None:
        char_obj, char_col, err = _get_target_hhp_character_for_current_collection(context, auto_select=False)
    else:
        err = None
    if not char_col:
        print(err or "No active HHP character collection found.")
        return

    collections_to_toggle = find_collections_recursive(char_col, ["Clothes", "Hair", "Char Appendage"])
    if not collections_to_toggle:
        print(f"No 'Clothes', 'Hair', or 'Char Appendage' collections found inside '{char_col.name}'.")
        return

    # Find mask properties only on objects within THIS character collection tree (avoid affecting other characters).
    mask_properties = []
    try:
        objs_in_char = list(char_col.all_objects)
    except Exception:
        # Fallback: traverse recursively.
        objs_in_char = []
        stack = [char_col]
        seen = set()
        while stack:
            c = stack.pop()
            if c is None or c.name in seen:
                continue
            seen.add(c.name)
            objs_in_char.extend(list(getattr(c, "objects", [])))
            stack.extend(list(getattr(c, "children", [])))

    # Scene custom mask props (kept for backward compatibility).
    for prop_name in scene.keys():
        if "Mask -" in prop_name and isinstance(scene[prop_name], bool):
            mask_properties.append(('scene', prop_name, scene))

    # Object mask props (scoped to this character only).
    for o in objs_in_char:
        for prop_name in o.keys():
            if "Mask -" in prop_name and isinstance(o[prop_name], bool):
                mask_properties.append(('object', prop_name, o))

    all_hidden = all(col.hide_viewport for col in collections_to_toggle)

    vis_key = _scene_state_key("heavy_collections_visibility", char_col)
    mask_key = _scene_state_key("mask_properties_states", char_col)
    mode_key = _scene_state_key("optimized_view_mode", char_col)

    session_active, entered_mode = _get_optimized_view_session_state(scene, char_col)

    if not all_hidden and not session_active:
        visibility_states = {}
        for col in collections_to_toggle:
            visibility_states[col.name] = bool(col.hide_viewport)
            _store_and_disable_hhp_deform_modifiers_in_collection(col)
            col.hide_viewport = True

        mask_property_states = {}
        for prop_type, prop_name, owner in mask_properties:
            if prop_type == 'scene':
                mask_property_states[f"scene_{prop_name}"] = bool(owner[prop_name])
                owner[prop_name] = False
            elif prop_type == 'object':
                mask_property_states[f"object_{owner.name}_{prop_name}"] = bool(owner[prop_name])
                owner[prop_name] = False

        scene[vis_key] = visibility_states
        scene[mask_key] = mask_property_states
        scene[mode_key] = str(mode)

        if str(mode) == 'FULL':
            _store_and_disable_modifier_viewport_states(scene, char_col, char_obj)
            _store_and_apply_viewport_simplify_state(scene, char_col)

        # Refresh viewport
        if context.active_object and context.active_object.type == 'MESH':
            try:
                if context.active_object.mode == 'OBJECT':
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

        print(f"Heavy collections hidden and mask properties disabled for '{char_col.name}'.")
        return

    # Restore
    vis_key = _existing_scene_state_key(scene, "heavy_collections_visibility", char_col)
    mask_key = _existing_scene_state_key(scene, "mask_properties_states", char_col)
    mode_key = _existing_scene_state_key(scene, "optimized_view_mode", char_col)
    mod_key = _existing_scene_state_key(scene, "modifier_viewport_states", char_col)
    simplify_key = _existing_scene_state_key(scene, "viewport_simplify_states", char_col)

    entered_mode = str(scene.get(mode_key, 'PARTIAL'))

    if vis_key in scene:
        visibility_states = scene[vis_key]
        for col in collections_to_toggle:
            col.hide_viewport = bool(visibility_states.get(col.name, False))
            _restore_hhp_deform_modifiers_in_collection(col)
        del scene[vis_key]
    else:
        for col in collections_to_toggle:
            col.hide_viewport = False
            _restore_hhp_deform_modifiers_in_collection(col)

    if mask_key in scene:
        mask_property_states = scene[mask_key]
        for key, value in mask_property_states.items():
            if key.startswith('scene_'):
                prop_name = key[6:]
                if prop_name in scene:
                    scene[prop_name] = bool(value)
            elif key.startswith('object_'):
                parts = key.split('_', 2)
                if len(parts) >= 3:
                    obj_name = parts[1]
                    prop_name = parts[2]
                    o = bpy.data.objects.get(obj_name)
                    if o and prop_name in o:
                        o[prop_name] = bool(value)
        del scene[mask_key]

    if entered_mode == 'FULL':
        _restore_modifier_viewport_states(scene, char_col)
        _restore_viewport_simplify_state(scene, char_col)
    else:
        if mod_key in scene:
            # Safety cleanup for legacy or mixed states.
            del scene[mod_key]
        if simplify_key in scene:
            # Safety cleanup for legacy or mixed states.
            del scene[simplify_key]

    if mode_key in scene:
        del scene[mode_key]

    # Refresh viewport
    if context.active_object and context.active_object.type == 'MESH':
        try:
            if context.active_object.mode == 'OBJECT':
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass

    print(f"Heavy collections visibility and mask properties restored for '{char_col.name}'.")


def set_global_optimized_view(context, enabled, mode='PARTIAL'):
    """Apply one optimized-view state to every HHP character without changing selection."""
    targets = _get_all_hhp_character_targets(context)
    ordered_targets = targets if enabled else reversed(targets)

    for char_obj, char_col in ordered_targets:
        is_active = is_optimized_view_active_for_char_collection(context, char_col)
        if is_active == enabled:
            continue
        toggle_heavy_collections(
            context,
            mode=mode,
            char_obj=char_obj,
            char_col=char_col,
        )

    return len(targets)


def _ensure_lowest_hhp_character_selected_for_action(context):
    """
    Ensure the active object is the lowest-enumeration HHP character mesh in the lowest-enumeration
    Char (HHP) collection context. If not, auto-select it and return (obj, col, True).

    Returns:
      (obj, char_col, did_auto_select, error_message)
    """
    # If current active is already valid (and lowest), do nothing.
    obj, char_col, err = _get_target_hhp_character_for_current_collection(context, auto_select=False)
    if obj and char_col and not err:
        return obj, char_col, False, None

    active = getattr(context, "active_object", None)

    def _pick_lowest_mesh_in_char_collection(col):
        meshes = [o for o in list(getattr(col, "objects", [])) if _is_hhp_character_mesh(o)]
        if not meshes:
            return None
        meshes.sort(key=lambda o: (_get_base_name(o.name).lower(), _get_enumeration_number(o.name), o.name.lower()))
        return meshes[0]

    # Try to infer the "current" Char (HHP) collection from whatever is active.
    if active is not None:
        chosen_col = _find_char_hhp_collection_for_object(context, active)
        target = _pick_lowest_mesh_in_char_collection(chosen_col) if chosen_col else None
        if target:
            _hhp_select_make_active(context, target)
            # Re-resolve to also normalize collection/mesh lowest-enum constraints.
            obj2, col2, _err2 = _get_target_hhp_character_for_current_collection(context, auto_select=True)
            return obj2 or target, col2 or chosen_col, True, None

    # Fallback: select the lowest-enumeration HHP character mesh we can find in visible Char (HHP) collections.
    target = _auto_select_hhp_character_for_current_context(context)
    if target:
        obj2, col2, _err2 = _get_target_hhp_character_for_current_collection(context, auto_select=True)
        return obj2 or target, col2, True, None

    return None, None, False, "No HHP character mesh found in the current view to operate on."

def find_collections_recursive(collection, prefixes):
    matched_collections = []
    for child in collection.children:
        for prefix in prefixes:
            if child.name.startswith(prefix):
                matched_collections.append(child)
        # Recurse into children
        matched_collections.extend(find_collections_recursive(child, prefixes))
    return matched_collections

def _can_bind_source(source_obj):
    return source_obj is not None and source_obj.type == 'MESH'


def _begin_temporary_triangulation(
        context, source_obj, quad_method='BEAUTY'):
    """Evaluate triangulation for binding without editing the source mesh."""
    modifier = source_obj.modifiers.new(
        name="Temporary Surface Bind Triangulate",
        type='TRIANGULATE',
    )
    try:
        modifier.quad_method = quad_method
        modifier.ngon_method = 'BEAUTY'
        modifier.min_vertices = 4
        context.view_layer.update()
    except Exception:
        if source_obj.modifiers.get(modifier.name) is not None:
            source_obj.modifiers.remove(modifier)
        context.view_layer.update()
        raise

    return modifier


def _end_temporary_triangulation(
        context, source_obj, modifier):
    """Remove only the temporary evaluated Triangulate modifier."""
    if modifier is None:
        return
    if source_obj.modifiers.get(modifier.name) is not None:
        source_obj.modifiers.remove(modifier)
        context.view_layer.update()


def _restore_selection(context, initial_selection, initial_active):
    bpy.ops.object.select_all(action='DESELECT')
    for obj in initial_selection:
        if bpy.data.objects.get(obj.name):
            obj.select_set(True)
    if initial_active and bpy.data.objects.get(initial_active.name):
        context.view_layer.objects.active = initial_active


def _remove_modifiers(modifiers):
    for obj, modifier in reversed(modifiers):
        if bpy.data.objects.get(obj.name) and obj.modifiers.get(modifier.name):
            obj.modifiers.remove(modifier)


def _new_surface_deform_modifier(obj, source_obj):
    surf_deform_mod = obj.modifiers.new(name="SurfaceDeform", type='SURFACE_DEFORM')
    surf_deform_mod.target = source_obj
    surf_deform_mod.show_in_editmode = True
    surf_deform_mod.show_on_cage = True
    return surf_deform_mod


def _bind_surface_deform(context, obj, modifier):
    context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='OBJECT')

    try:
        result = bpy.ops.object.surfacedeform_bind(modifier=modifier.name)
    except Exception as exc:
        return False, str(exc)

    if 'FINISHED' not in result:
        return False, "Surface Deform bind did not finish."
    if hasattr(modifier, "is_bound") and not modifier.is_bound:
        return False, "Surface Deform was not bound, target has invalid geometry."
    return True, ""


def _bind_selected_to_source(
        context, source_obj, exclude_objects=None, forced=False,
        quad_method='BEAUTY'):
    if not _can_bind_source(source_obj):
        return False, "Active object must be a mesh.", 0, False

    exclude_objects = set(exclude_objects or [])
    initial_selection = context.selected_objects.copy()
    initial_active = context.view_layer.objects.active
    bind_targets = [
        obj for obj in initial_selection
        if obj.type == 'MESH' and obj != source_obj and obj not in exclude_objects
    ]

    if not bind_targets:
        return False, "Select at least one mesh to bind.", 0, False

    created_modifiers = []
    triangulate_modifier = None
    failed_message = ""
    did_bind_all = False

    try:
        bpy.ops.object.mode_set(mode='OBJECT')

        if forced:
            triangulate_modifier = _begin_temporary_triangulation(
                context,
                source_obj,
                quad_method=quad_method,
            )

        for obj in bind_targets:
            surf_deform_mod = _new_surface_deform_modifier(obj, source_obj)
            created_modifiers.append((obj, surf_deform_mod))

            did_bind, failed_message = _bind_surface_deform(context, obj, surf_deform_mod)
            if not did_bind:
                break

        did_bind_all = not failed_message
    except Exception as exc:
        failed_message = str(exc)
    finally:
        try:
            _end_temporary_triangulation(
                context,
                source_obj,
                triangulate_modifier,
            )
        finally:
            _restore_selection(context, initial_selection, initial_active)

    if did_bind_all:
        still_bound = all(
            not hasattr(modifier, "is_bound") or modifier.is_bound
            for _obj, modifier in created_modifiers
        )
        if still_bound:
            return True, "", len(bind_targets), False
        failed_message = "Surface Deform lost its bind after restoring the target topology."

    _remove_modifiers(created_modifiers)
    return False, failed_message or "Surface Deform bind failed.", len(bind_targets), not forced


def _bind_selected_to_source_with_fallback(context, source_obj, exclude_objects=None):
    did_bind, message, count, can_retry = _bind_selected_to_source(
        context,
        source_obj,
        exclude_objects=exclude_objects,
        forced=False,
    )
    if did_bind or not can_retry:
        return did_bind, message, count, False

    forced_message = message
    forced_count = count
    for quad_method in (
            'BEAUTY', 'FIXED_ALTERNATE', 'FIXED',
            'SHORTEST_DIAGONAL', 'LONGEST_DIAGONAL'):
        did_bind, forced_message, forced_count, _can_retry = (
            _bind_selected_to_source(
                context,
                source_obj,
                exclude_objects=exclude_objects,
                forced=True,
                quad_method=quad_method,
            ))
        if did_bind:
            return True, "", forced_count, True
    return False, forced_message, forced_count, True


def _primary_proxy_sort_key(name):
    if name == PRIMARY_FULLBODY_PROXY_NAME:
        return (0, 0, "")

    enumerated_prefix = f"{PRIMARY_FULLBODY_PROXY_NAME}."
    suffix = name[len(enumerated_prefix):] if name.startswith(enumerated_prefix) else ""
    if suffix.isdigit():
        return (1, int(suffix), name.lower())

    return (2, 0, name.lower())


def _split_ordered_proxy_names(proxy_names):
    primary_names = [
        name for name in proxy_names
        if PRIMARY_FULLBODY_PROXY_NAME in name
    ]
    other_names = [
        name for name in proxy_names
        if PRIMARY_FULLBODY_PROXY_NAME not in name
    ]

    primary_names.sort(key=_primary_proxy_sort_key)
    other_names.sort(key=str.lower)
    return primary_names, other_names


def _preferred_proxy_mesh(context, active_obj):
    proxy_meshes = find_proxy_meshes(active_obj)
    selected_proxy = next((obj for obj in context.selected_objects if obj in proxy_meshes), None)
    if selected_proxy:
        return selected_proxy
    return proxy_meshes[0] if proxy_meshes else None


def _execute_bind_choice(operator, context, bind_target, proxy_name=""):
    active_obj = context.active_object
    if not _can_bind_source(active_obj):
        operator.report({'ERROR'}, "Active object must be a mesh.")
        return {'CANCELLED'}

    exclude_objects = set()
    source_obj = active_obj

    if bind_target == 'PROXY':
        proxy_obj = bpy.data.objects.get(proxy_name) if proxy_name else _preferred_proxy_mesh(context, active_obj)
        if not proxy_obj:
            operator.report({'ERROR'}, "No linked proxy mesh found for the active object.")
            return {'CANCELLED'}
        source_obj = proxy_obj
        exclude_objects.add(active_obj)

    did_bind, message, count, used_forced = _bind_selected_to_source_with_fallback(
        context,
        source_obj,
        exclude_objects=exclude_objects,
    )
    if not did_bind:
        operator.report({'ERROR'}, message)
        return {'CANCELLED'}

    if used_forced:
        operator.report(
            {'WARNING'},
            f"Bound {count} mesh(es) to \"{source_obj.name}\" using forced bind.",
        )
    else:
        operator.report({'INFO'}, f"Bound {count} mesh(es) to \"{source_obj.name}\".")
    return {'FINISHED'}

# Function for "Toggle Armatures (Smart)" button
def set_armature_state():
    pose_count = sum(1 for obj in bpy.data.objects if obj.type == 'ARMATURE' and obj.data.pose_position == 'POSE')
    rest_count = sum(1 for obj in bpy.data.objects if obj.type == 'ARMATURE' and obj.data.pose_position == 'REST')

    desired_state = 'REST' if pose_count > rest_count else 'POSE'

    for obj in bpy.data.objects:
        if obj.type == 'ARMATURE':
            obj.data.pose_position = desired_state
            obj.update_tag()
    bpy.context.view_layer.update()

    print(f"All armatures set to {desired_state} position.")

# Function for "Setup Render Basics" button
def setup_render_basics():
    # General render settings
    bpy.context.scene.unit_settings.system = 'METRIC'
    bpy.context.scene.render.use_simplify = True
    bpy.context.scene.render.simplify_subdivision = 0
    bpy.context.scene.render.simplify_subdivision_render = 3
    bpy.context.scene.render.use_motion_blur = False
    bpy.context.scene.sync_mode = 'AUDIO_SYNC'
    bpy.context.scene.render.use_persistent_data = True
    
    # Cycles settings
    if bpy.context.scene.cycles.transparent_max_bounces < 100:
        bpy.context.scene.cycles.transparent_max_bounces = 100
    
    # Eevee settings
    bpy.context.scene.eevee.use_taa_reprojection = False
    bpy.context.scene.eevee.use_shadow_jitter_viewport = False
    bpy.context.scene.eevee.taa_samples = 64
    bpy.context.scene.eevee.taa_render_samples = 64
    bpy.context.scene.eevee.use_overscan = True
    bpy.context.scene.eevee.overscan_size = 3
    bpy.context.scene.eevee.use_shadows = True
    bpy.context.scene.eevee.shadow_resolution_scale = 0.5
    bpy.context.scene.eevee.shadow_ray_count = 1
    bpy.context.scene.eevee.shadow_step_count = 6
    bpy.context.scene.eevee.use_raytracing = True
    bpy.context.scene.eevee.ray_tracing_method = 'SCREEN'
    bpy.context.scene.eevee.ray_tracing_options.resolution_scale = '1'
    bpy.context.scene.eevee.ray_tracing_options.trace_max_roughness = 0.5
    bpy.context.scene.eevee.ray_tracing_options.screen_trace_quality = 0.25
    bpy.context.scene.eevee.ray_tracing_options.screen_trace_thickness = 0.2
    bpy.context.scene.eevee.ray_tracing_options.use_denoise = True
    bpy.context.scene.eevee.ray_tracing_options.denoise_spatial = True
    bpy.context.scene.eevee.ray_tracing_options.denoise_temporal = True
    bpy.context.scene.eevee.ray_tracing_options.denoise_bilateral = True
    bpy.context.scene.eevee.fast_gi_method = 'GLOBAL_ILLUMINATION'
    bpy.context.scene.eevee.fast_gi_resolution = '2'
    bpy.context.scene.eevee.fast_gi_ray_count = 2
    bpy.context.scene.eevee.fast_gi_step_count = 8
    bpy.context.scene.eevee.fast_gi_quality = 0.25
    bpy.context.scene.eevee.fast_gi_distance = 0
    bpy.context.scene.eevee.fast_gi_thickness_near = 0.25
    bpy.context.scene.eevee.fast_gi_thickness_far = 0.785398
    bpy.context.scene.eevee.fast_gi_bias = 0.05
    print("Render setup basics applied.")

# Panel class
class HHP_PT_OptimizePanel(bpy.types.Panel):
    bl_label = "Optimize / Tools (HHP)"
    bl_idname = "HHP_PT_optimize_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Char (HHP)"
    bl_parent_id = "CHAR_HHP_PT_Panel"  # Set parent panel
    bl_options = {'HIDE_HEADER'}  # Hide the header
    bl_order = 15
    
    @classmethod
    def poll(cls, context):
        # Only show this panel if OPTIMIZE is selected in the mode selector
        return context.scene.hhp_panel_mode.selected_panel == 'OPTIMIZE'

    def draw(self, context):
        layout = self.layout

        # Create a box layout
        box = layout.box()
        box.label(text="Limit Texture Size (VRAM Optimizer)")
        col = box.column(align=True)
        col.operator("file.find_missing_files", text="Re-Link Textures")
        col.prop(bpy.context.preferences.system, "gl_texture_limit", text="")

        # Display the shared state used by every HHP character in the scene.
        materials_linked_by_object = is_optimized_materials_active(context)

        # Prepare the label for the playback method
        scene = context.scene
        sync_mode = scene.sync_mode

        if sync_mode == 'NONE':
            playback_label = "Play Every Frame"
        elif sync_mode == 'AUDIO_SYNC':
            playback_label = "Sync to Audio"
        elif sync_mode == 'FRAME_DROP':
            playback_label = "Frame Dropping"
        else:
            playback_label = "Unknown"

        # Create aligned column for two-column button layout
        col = layout.column(align=True)
        
        # Row 1: Toggle optimized materials | Toggle optimized view
        row = col.row(align=True)
        row.operator("hhp.update_optimized_materials", text="", icon='FILE_REFRESH')
        row.operator("hhp.flip_material_link", text="Optimized Materials", icon='MATERIAL', depress=materials_linked_by_object)
        row.operator("hhp.toggle_heavy_collections", text=get_optimized_view_button_text(context), icon='HIDE_OFF', depress=is_heavy_collections_hidden(context))

        # Row 1.5: Update and toggle optimized normals
        row = col.row(align=True)
        row.operator("hhp.update_optimized_normals", text="", icon='FILE_REFRESH')
        row.prop(
            context.scene,
            "hhp_use_optimized_normals",
            text="Use Optimized Normals (Recommended)",
            icon='NORMALS_VERTEX',
            toggle=True,
        )
        col.separator()
        
        # Row 2: Inflate SK by active | Bind to active
        row = col.row(align=True)
        row.operator("hhp.inflate_sk_by_active", text="Inflate SK by active", icon='SHAPEKEY_DATA')
        row.operator("hhp.bind_surface_deform", text="Bind to Active", icon='LATTICE_DATA')
        
        # Row 3: Toggle armatures | Toggle playback method
        row = col.row(align=True)
        row.operator("hhp.toggle_armature_smart", text="Toggle armatures", icon='ARMATURE_DATA')
        row.operator("hhp.toggle_playback_method", text=playback_label, icon='PLAY')
        
        # Row 4: Create HHP Mask (full width since it's alone)
        row = col.row(align=True)
        row.operator("hhp.create_mask", text="Create HHP Mask", icon='MOD_MASK')

        # Add the Subsurface conversion button in its own full-width row
        row = layout.row(align=True)
        row.menu("SHADER_SSS_MT_menu", text="Shader setup", icon='BLENDER')

# Operator for "Update Optimized Materials"
class HHP_OT_UpdateOptimizedMaterials(bpy.types.Operator):
    bl_idname = "hhp.update_optimized_materials"
    bl_label = "Update Optimized Materials"
    bl_description = "Clear and rebuild fresh optimized proxy materials for every HHP character in the scene"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        if _get_all_hhp_character_targets(context):
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context):
        char_objects = []
        seen_objects = set()
        for char_obj, _char_col in _get_all_hhp_character_targets(context):
            obj_pointer = char_obj.as_pointer()
            if obj_pointer in seen_objects:
                continue
            seen_objects.add(obj_pointer)
            char_objects.append(char_obj)

        if not char_objects:
            self.report({'ERROR'}, "No HHP characters found in the scene.")
            return {'CANCELLED'}

        cleared_count, _mesh_count, unlinked_slot_count = hhp_clear_proxified_materials_from_objects(char_objects)
        proxified_count, proxified_mesh_count = hhp_proxify_materials(char_objects)
        self.report(
            {'INFO'},
            f"Updated {len(char_objects)} HHP character(s): cleared {cleared_count}, "
            f"unlinked {unlinked_slot_count} slot(s), "
            f"created {proxified_count} material(s) for {proxified_mesh_count} mesh(es)."
        )
        return {'FINISHED'}


# Operator for "Update Optimized Normals"
class HHP_OT_UpdateOptimizedNormals(bpy.types.Operator):
    bl_idname = "hhp.update_optimized_normals"
    bl_label = "Update Optimized Normals"
    bl_description = "Turn on optimized normals and update all newly added materials and node groups to use them"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.scene.hhp_use_optimized_normals:
            use_optimized_normals_node.apply_use_optimized_normals(True)
        else:
            context.scene.hhp_use_optimized_normals = True
        self.report({'INFO'}, "Optimized normals updated for all materials and node groups.")
        return {'FINISHED'}


# Operator for "Flip Material Link"
class HHP_OT_FlipMaterialLink(bpy.types.Operator):
    bl_idname = "hhp.flip_material_link"
    bl_label = "Flip Material Link"
    bl_description = "Toggle optimized materials for every HHP character in the scene without changing the current selection"

    def execute(self, context):
        targets = _get_all_hhp_character_targets(context)
        if not targets:
            self.report({'ERROR'}, "No HHP characters found in the scene.")
            return {'CANCELLED'}

        enable_optimized = not is_optimized_materials_active(context)
        set_material_link(
            [char_obj for char_obj, _char_col in targets],
            'OBJECT' if enable_optimized else 'DATA',
        )
        state_label = "enabled" if enable_optimized else "disabled"
        self.report({'INFO'}, f"Optimized materials {state_label} for {len(targets)} HHP character(s).")
        return {'FINISHED'}

# Operator for "Toggle Heavy Collections"
class HHP_OT_ToggleHeavyCollections(bpy.types.Operator):
    bl_idname = "hhp.toggle_heavy_collections"
    bl_label = "Toggle Optimized View"
    bl_description = "Toggle optimized view for every HHP character without changing the current selection"

    def draw_mode_menu(self, menu, context):
        layout = menu.layout
        layout.operator("hhp.toggle_heavy_collections_partial", text="Partial (With modifiers)", icon='HIDE_OFF')
        layout.operator("hhp.toggle_heavy_collections_full", text="Full (No modifiers)", icon='MODIFIER')

    def execute(self, context):
        targets = _get_all_hhp_character_targets(context)
        if not targets:
            self.report({'ERROR'}, "No HHP characters found in the scene.")
            return {'CANCELLED'}

        if is_heavy_collections_hidden(context):
            set_global_optimized_view(context, False)
            self.report({'INFO'}, f"Optimized view disabled for {len(targets)} HHP character(s).")
            return {'FINISHED'}

        context.window_manager.popup_menu(self.draw_mode_menu, title="Optimized View Mode")
        return {'FINISHED'}


class HHP_OT_ToggleHeavyCollectionsPartial(bpy.types.Operator):
    bl_idname = "hhp.toggle_heavy_collections_partial"
    bl_label = "Toggle Optimized View (Partial)"
    bl_description = "Enable partial optimized view for every HHP character"

    def execute(self, context):
        target_count = set_global_optimized_view(context, True, mode='PARTIAL')
        if not target_count:
            self.report({'ERROR'}, "No HHP characters found in the scene.")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Partial optimized view enabled for {target_count} HHP character(s).")
        return {'FINISHED'}


class HHP_OT_ToggleHeavyCollectionsFull(bpy.types.Operator):
    bl_idname = "hhp.toggle_heavy_collections_full"
    bl_label = "Toggle Optimized View (Full)"
    bl_description = "Enable full optimized view for every HHP character"

    def execute(self, context):
        target_count = set_global_optimized_view(context, True, mode='FULL')
        if not target_count:
            self.report({'ERROR'}, "No HHP characters found in the scene.")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Full optimized view enabled for {target_count} HHP character(s).")
        return {'FINISHED'}

class HHP_OT_BindSurfaceDeform(bpy.types.Operator):
    bl_idname = "hhp.bind_surface_deform"
    bl_label = "Bind to Active"
    bl_description = "Bind selected meshes to the active mesh; if linked proxy meshes exist, choose Active Mesh or Proxy Mesh (Linked)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        active_obj = context.active_object
        return active_obj is not None and active_obj.type == 'MESH'

    def execute(self, context):
        active_obj = context.active_object
        if not _can_bind_source(active_obj):
            self.report({'ERROR'}, "Active object must be a mesh.")
            return {'CANCELLED'}

        if find_proxy_meshes(active_obj):
            context.window_manager.popup_menu(self.draw_bind_menu, title="Bind to Active")
            return {'FINISHED'}

        return _execute_bind_choice(self, context, 'ACTIVE')

    def draw_bind_menu(self, menu, context):
        layout = menu.layout
        layout.operator(
            "hhp.bind_to_active_execute",
            text="Active Mesh",
            icon='OUTLINER_OB_MESH',
        ).bind_target = 'ACTIVE'
        layout.operator(
            "hhp.bind_to_active_proxy_menu",
            text="Proxy Mesh (Linked)",
            icon='LINKED',
        )

# Function to find proxy meshes with the same mesh data as the active object
def find_proxy_meshes(source_mesh):
    """Find all meshes that share the same mesh data as the source mesh"""
    if not source_mesh or source_mesh.type != 'MESH':
        return []
    
    # Find all objects with the same mesh data
    proxy_candidates = [
        obj for obj in bpy.data.objects
        if obj.type == 'MESH' and obj.data == source_mesh.data and obj != source_mesh
    ]
    
    return proxy_candidates

class HHP_OT_BindToActiveProxyMenu(bpy.types.Operator):
    bl_idname = "hhp.bind_to_active_proxy_menu"
    bl_label = "Proxy Mesh (Linked)"
    bl_description = "Choose which linked proxy mesh to use as the Surface Deform bind target"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        active_obj = context.active_object
        if not _can_bind_source(active_obj):
            self.report({'ERROR'}, "Active object must be a mesh.")
            return {'CANCELLED'}

        proxy_meshes = find_proxy_meshes(active_obj)
        if not proxy_meshes:
            self.report({'ERROR'}, "No linked proxy meshes found for the active object.")
            return {'CANCELLED'}

        context.scene[HHP_BIND_PROXY_MESHES_KEY] = [obj.name for obj in proxy_meshes]
        context.window_manager.popup_menu(self.draw_proxy_menu, title="Select Linked Proxy Mesh")
        return {'FINISHED'}

    def draw_proxy_menu(self, menu, context):
        layout = menu.layout
        proxy_names = context.scene.get(HHP_BIND_PROXY_MESHES_KEY, [])
        primary_names, other_names = _split_ordered_proxy_names(proxy_names)

        for proxy_name in primary_names:
            if not bpy.data.objects.get(proxy_name):
                continue
            op = layout.operator(
                "hhp.bind_to_active_execute",
                text=proxy_name,
                icon='LINKED',
            )
            op.bind_target = 'PROXY'
            op.proxy_name = proxy_name
        if primary_names and other_names:
            layout.separator()
        for proxy_name in other_names:
            if not bpy.data.objects.get(proxy_name):
                continue
            op = layout.operator(
                "hhp.bind_to_active_execute",
                text=proxy_name,
                icon='LINKED',
            )
            op.bind_target = 'PROXY'
            op.proxy_name = proxy_name


class HHP_OT_BindToActiveExecute(bpy.types.Operator):
    bl_idname = "hhp.bind_to_active_execute"
    bl_label = "Bind to Active Choice"
    bl_description = "Bind selected meshes to the chosen active or linked proxy mesh, retrying with forced binding if the normal bind fails"
    bl_options = {'REGISTER', 'UNDO'}

    bind_target: EnumProperty(
        name="Bind Target",
        description="Choose whether to bind to the active mesh or its linked proxy mesh",
        items=[
            ('ACTIVE', "Active Mesh", "Bind selected meshes to the active mesh"),
            ('PROXY', "Proxy Mesh (Linked)", "Bind selected meshes to a linked proxy mesh"),
        ],
        default='ACTIVE',
        options={'HIDDEN'},
    )

    proxy_name: StringProperty(
        name="Proxy Mesh",
        description="Linked proxy mesh to use as the bind target",
        default="",
        options={'HIDDEN'},
    )

    def execute(self, context):
        result = _execute_bind_choice(self, context, self.bind_target, self.proxy_name)
        if result == {'FINISHED'} and HHP_BIND_PROXY_MESHES_KEY in context.scene:
            del context.scene[HHP_BIND_PROXY_MESHES_KEY]
        return result


# Operator for normal binding
class HHP_OT_BindSurfaceDeformNormal(bpy.types.Operator):
    bl_idname = "hhp.bind_surface_deform_normal"
    bl_label = "Bind Surface Deform Normal"
    bl_description = "Bind with surface deform modifiers from selected objects using the active object as target"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return _execute_bind_choice(self, context, 'ACTIVE')

# Operator for forced binding
class HHP_OT_BindSurfaceDeformForced(bpy.types.Operator):
    bl_idname = "hhp.bind_surface_deform_forced"
    bl_label = "Bind Surface Deform Forced"
    bl_description = "Force-bind selected meshes to the active mesh without changing its topology"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        source_obj = context.active_object
        did_bind, message, count, _can_retry = _bind_selected_to_source(context, source_obj, forced=True)
        if not did_bind:
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        self.report(
            {'WARNING'},
            f"Bound {count} mesh(es) to \"{source_obj.name}\" using forced bind.",
        )
        return {'FINISHED'}

# Operator for binding to deform proxy
class HHP_OT_BindToProxyOfActive(bpy.types.Operator):
    bl_idname = "hhp.bind_to_proxy_of_active"
    bl_label = "Bind to Proxy of Active"
    bl_description = "Bind with surface deform modifiers to a proxy mesh that shares the same mesh data as the active object"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        active_obj = context.active_object
        if not active_obj or active_obj.type != 'MESH':
            self.report({'ERROR'}, "Active object must be a mesh")
            return {'CANCELLED'}

        proxy_meshes = find_proxy_meshes(active_obj)
        if not proxy_meshes:
            self.report({'ERROR'}, "No proxy meshes found that share the same mesh data as the active object")
            return {'CANCELLED'}

        context.scene[HHP_BIND_PROXY_MESHES_KEY] = [obj.name for obj in proxy_meshes]
        context.window_manager.popup_menu(self.draw_proxy_menu, title="Select Proxy Mesh")
        return {'FINISHED'}

    def draw_proxy_menu(self, menu, context):
        layout = menu.layout
        if HHP_BIND_PROXY_MESHES_KEY in context.scene:
            proxy_names = context.scene[HHP_BIND_PROXY_MESHES_KEY]
            primary_names, other_names = _split_ordered_proxy_names(proxy_names)
            for proxy_name in primary_names:
                proxy_obj = bpy.data.objects.get(proxy_name)
                if proxy_obj:
                    op = layout.operator("hhp.bind_to_proxy_execute", text=proxy_name, icon='LINKED')
                    op.proxy_name = proxy_name
                    op.is_forced = False
            if primary_names and other_names:
                layout.separator()
            for proxy_name in other_names:
                proxy_obj = bpy.data.objects.get(proxy_name)
                if proxy_obj:
                    op = layout.operator("hhp.bind_to_proxy_execute", text=proxy_name, icon='LINKED')
                    op.proxy_name = proxy_name
                    op.is_forced = False

# Operator for binding to deform proxy (forced)
class HHP_OT_BindToProxyOfActiveForced(bpy.types.Operator):
    bl_idname = "hhp.bind_to_proxy_of_active_forced"
    bl_label = "Bind to Proxy of Active (Forced)"
    bl_description = "Bind with surface deform modifiers to a proxy mesh using triangulation method for difficult geometry"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        active_obj = context.active_object
        if not active_obj or active_obj.type != 'MESH':
            self.report({'ERROR'}, "Active object must be a mesh")
            return {'CANCELLED'}

        proxy_meshes = find_proxy_meshes(active_obj)
        if not proxy_meshes:
            self.report({'ERROR'}, "No proxy meshes found that share the same mesh data as the active object")
            return {'CANCELLED'}

        context.scene[HHP_BIND_PROXY_MESHES_KEY] = [obj.name for obj in proxy_meshes]
        context.window_manager.popup_menu(self.draw_proxy_menu, title="Select Proxy Mesh")
        return {'FINISHED'}

    def draw_proxy_menu(self, menu, context):
        layout = menu.layout
        if HHP_BIND_PROXY_MESHES_KEY in context.scene:
            proxy_names = context.scene[HHP_BIND_PROXY_MESHES_KEY]
            primary_names, other_names = _split_ordered_proxy_names(proxy_names)
            for proxy_name in primary_names:
                proxy_obj = bpy.data.objects.get(proxy_name)
                if proxy_obj:
                    op = layout.operator("hhp.bind_to_proxy_execute", text=proxy_name, icon='LINKED')
                    op.proxy_name = proxy_name
                    op.is_forced = True
            if primary_names and other_names:
                layout.separator()
            for proxy_name in other_names:
                proxy_obj = bpy.data.objects.get(proxy_name)
                if proxy_obj:
                    op = layout.operator("hhp.bind_to_proxy_execute", text=proxy_name, icon='LINKED')
                    op.proxy_name = proxy_name
                    op.is_forced = True

# Operator to execute the actual binding to proxy
class HHP_OT_BindToProxyExecute(bpy.types.Operator):
    bl_idname = "hhp.bind_to_proxy_execute"
    bl_label = "Execute Bind to Proxy"
    bl_description = "Execute the binding to the selected proxy mesh"
    bl_options = {'REGISTER', 'UNDO'}

    proxy_name: StringProperty(
        name="Proxy Mesh",
        description="Linked proxy mesh to use as the bind target",
        options={'HIDDEN'},
    )
    is_forced: BoolProperty(
        name="Forced",
        description="Use forced triangulate binding",
        default=False,
        options={'HIDDEN'},
    )

    def execute(self, context):
        proxy_obj = bpy.data.objects.get(self.proxy_name)
        if not proxy_obj:
            self.report({'ERROR'}, f"Proxy object '{self.proxy_name}' not found")
            return {'CANCELLED'}

        original_active = context.view_layer.objects.active

        if self.is_forced:
            did_bind, message, count, _can_retry = _bind_selected_to_source(
                context,
                proxy_obj,
                exclude_objects={original_active},
                forced=True,
            )
            used_forced = True
        else:
            did_bind, message, count, used_forced = _bind_selected_to_source_with_fallback(
                context,
                proxy_obj,
                exclude_objects={original_active},
            )

        if not did_bind:
            self.report({'ERROR'}, message)
            return {'CANCELLED'}

        if HHP_BIND_PROXY_MESHES_KEY in context.scene:
            del context.scene[HHP_BIND_PROXY_MESHES_KEY]

        if used_forced:
            self.report(
                {'WARNING'},
                f"Bound {count} mesh(es) to \"{proxy_obj.name}\" using forced bind.",
            )
        else:
            self.report({'INFO'}, f"Bound {count} mesh(es) to \"{proxy_obj.name}\".")
        return {'FINISHED'}

# Operator for "Toggle Armatures (Smart)"
class HHP_OT_ToggleArmatureSmart(bpy.types.Operator):
    bl_idname = "hhp.toggle_armature_smart"
    bl_label = "Toggle Armatures (Smart)"
    bl_description = "Toggle between REST and POSE modes for armatures based on current state."

    def execute(self, context):
        set_armature_state()
        return {'FINISHED'}

# Operator for "Setup Render Basics"
class HHP_OT_SetupRenderBasics(bpy.types.Operator):
    bl_idname = "hhp.setup_render_basics"
    bl_label = "Setup Render Basics"
    bl_description = "Apply basic render settings for both Eevee and Cycles engines for optimal character rendering and performance"

    def execute(self, context):
        setup_render_basics()
        self.report({'INFO'}, "Render setup basics applied")
        return {'FINISHED'}

# Operator for "Toggle Playback Method"
class HHP_OT_TogglePlaybackMethod(bpy.types.Operator):
    bl_idname = "hhp.toggle_playback_method"
    bl_label = "Toggle Playback Method"
    bl_description = "Toggle playback method between 'Sync to Audio' and 'Play Every Frame'."

    def execute(self, context):
        scene = context.scene
        current_mode = scene.sync_mode

        if current_mode == 'AUDIO_SYNC':
            scene.sync_mode = 'NONE'
            self.report({'INFO'}, "Playback method set to 'Play Every Frame'")
        else:
            scene.sync_mode = 'AUDIO_SYNC'
            self.report({'INFO'}, "Playback method set to 'Sync to Audio'")

        return {'FINISHED'}

# Register the panel and operators
def register():
    use_optimized_normals_node.register_properties()
    bpy.utils.register_class(HHP_PT_OptimizePanel)
    bpy.utils.register_class(HHP_OT_UpdateOptimizedMaterials)
    bpy.utils.register_class(HHP_OT_UpdateOptimizedNormals)
    bpy.utils.register_class(HHP_OT_FlipMaterialLink)
    bpy.utils.register_class(HHP_OT_ToggleHeavyCollections)
    bpy.utils.register_class(HHP_OT_ToggleHeavyCollectionsPartial)
    bpy.utils.register_class(HHP_OT_ToggleHeavyCollectionsFull)
    bpy.utils.register_class(HHP_OT_BindSurfaceDeform)
    bpy.utils.register_class(HHP_OT_BindToActiveProxyMenu)
    bpy.utils.register_class(HHP_OT_BindToActiveExecute)
    bpy.utils.register_class(HHP_OT_BindSurfaceDeformNormal)
    bpy.utils.register_class(HHP_OT_BindSurfaceDeformForced)
    bpy.utils.register_class(HHP_OT_BindToProxyOfActive)
    bpy.utils.register_class(HHP_OT_BindToProxyOfActiveForced)
    bpy.utils.register_class(HHP_OT_BindToProxyExecute)
    bpy.utils.register_class(HHP_OT_ToggleArmatureSmart)
    bpy.utils.register_class(HHP_OT_SetupRenderBasics)
    bpy.utils.register_class(HHP_OT_TogglePlaybackMethod)

def unregister():
    bpy.utils.unregister_class(HHP_PT_OptimizePanel)
    bpy.utils.unregister_class(HHP_OT_UpdateOptimizedMaterials)
    bpy.utils.unregister_class(HHP_OT_UpdateOptimizedNormals)
    bpy.utils.unregister_class(HHP_OT_FlipMaterialLink)
    bpy.utils.unregister_class(HHP_OT_ToggleHeavyCollectionsFull)
    bpy.utils.unregister_class(HHP_OT_ToggleHeavyCollectionsPartial)
    bpy.utils.unregister_class(HHP_OT_ToggleHeavyCollections)
    bpy.utils.unregister_class(HHP_OT_BindToProxyExecute)
    bpy.utils.unregister_class(HHP_OT_BindToProxyOfActiveForced)
    bpy.utils.unregister_class(HHP_OT_BindToProxyOfActive)
    bpy.utils.unregister_class(HHP_OT_BindSurfaceDeformForced)
    bpy.utils.unregister_class(HHP_OT_BindSurfaceDeformNormal)
    bpy.utils.unregister_class(HHP_OT_BindToActiveExecute)
    bpy.utils.unregister_class(HHP_OT_BindToActiveProxyMenu)
    bpy.utils.unregister_class(HHP_OT_BindSurfaceDeform)
    bpy.utils.unregister_class(HHP_OT_ToggleArmatureSmart)
    bpy.utils.unregister_class(HHP_OT_SetupRenderBasics)
    bpy.utils.unregister_class(HHP_OT_TogglePlaybackMethod)
    use_optimized_normals_node.unregister_properties()

if __name__ == "__main__":
    register()
