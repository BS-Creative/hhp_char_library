import bpy

# Function to toggle material link type
def toggle_material_link(selected_objects):
    current_link = None
    for obj in selected_objects:
        if obj.material_slots:
            current_link = obj.material_slots[0].link
            break

    if current_link is None:
        print("No materials found on selected objects.")
        return

    new_link = 'OBJECT' if current_link == 'DATA' else 'DATA'
    
    for obj in selected_objects:
        if obj.material_slots:
            for slot in obj.material_slots:
                slot.link = new_link

    print(f"Material link set to '{new_link}' for all selected objects.")
    bpy.context.view_layer.update()

# Function for "Bind to Active" button
def add_surface_deform_to_selected(source_obj):
    if not source_obj or source_obj.type != 'MESH':
        print("Active object is not a mesh or is not selected.")
        return

    initial_selection = bpy.context.selected_objects.copy()
    initial_active = bpy.context.view_layer.objects.active

    bpy.ops.object.mode_set(mode='OBJECT')

    for obj in initial_selection:
        if obj == source_obj:
            continue

        surf_deform_mod = obj.modifiers.new(name="SurfaceDeform", type='SURFACE_DEFORM')
        surf_deform_mod.target = source_obj
        surf_deform_mod.show_in_editmode = True
        surf_deform_mod.show_on_cage = True

        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.surfacedeform_bind(modifier=surf_deform_mod.name)

    bpy.ops.object.select_all(action='DESELECT')
    for obj in initial_selection:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = initial_active

    print("Surface Deform modifiers added and bound to the active object.")

# Function for "Toggle Armatures (Smart)" button
def set_armature_state():
    pose_count = sum(1 for obj in bpy.data.objects if obj.type == 'ARMATURE' and obj.data.pose_position == 'POSE')
    rest_count = sum(1 for obj in bpy.data.objects if obj.type == 'ARMATURE' and obj.data.pose_position == 'REST')

    desired_state = 'REST' if pose_count > rest_count else 'POSE'

    for obj in bpy.data.objects:
        if obj.type == 'ARMATURE':
            obj.data.pose_position = desired_state
            obj.update_tag()
    bpy.context.view_layer.update()

    print(f"All armatures set to {desired_state} position.")

# Function for "Eevee Setup Basics" button
def setup_eevee_basics():
    bpy.context.scene.render.engine = 'BLENDER_EEVEE_NEXT'
    bpy.context.scene.unit_settings.system = 'METRIC'
    bpy.context.scene.render.use_simplify = True
    bpy.context.scene.render.simplify_subdivision = 0
    bpy.context.scene.render.simplify_subdivision_render = 3
    bpy.context.scene.eevee.use_taa_reprojection = False
    bpy.context.scene.eevee.use_shadow_jitter_viewport = False
    bpy.context.scene.eevee.taa_samples = 64
    bpy.context.scene.eevee.taa_render_samples = 64
    bpy.context.scene.render.use_motion_blur = False
    bpy.context.scene.eevee.use_overscan = True
    bpy.context.scene.eevee.overscan_size = 3
    bpy.context.scene.sync_mode = 'AUDIO_SYNC'
    bpy.context.scene.eevee.use_shadows = True
    bpy.context.scene.eevee.shadow_resolution_scale = 0.5
    bpy.context.scene.eevee.shadow_ray_count = 1
    bpy.context.scene.eevee.shadow_step_count = 6
    bpy.context.scene.eevee.use_raytracing = True
    bpy.context.scene.eevee.ray_tracing_method = 'SCREEN'
    bpy.context.scene.eevee.ray_tracing_options.resolution_scale = '1'
    bpy.context.scene.eevee.ray_tracing_options.trace_max_roughness = 0.5
    bpy.context.scene.eevee.ray_tracing_options.screen_trace_quality = 0.25
    bpy.context.scene.eevee.ray_tracing_options.screen_trace_thickness = 0.2
    bpy.context.scene.eevee.ray_tracing_options.use_denoise = True
    bpy.context.scene.eevee.ray_tracing_options.denoise_spatial = True
    bpy.context.scene.eevee.ray_tracing_options.denoise_temporal = True
    bpy.context.scene.eevee.ray_tracing_options.denoise_bilateral = True
    bpy.context.scene.eevee.fast_gi_method = 'GLOBAL_ILLUMINATION'
    bpy.context.scene.eevee.fast_gi_resolution = '2'
    bpy.context.scene.eevee.fast_gi_ray_count = 2
    bpy.context.scene.eevee.fast_gi_step_count = 8
    bpy.context.scene.eevee.fast_gi_quality = 0.25
    bpy.context.scene.eevee.fast_gi_distance = 0
    bpy.context.scene.eevee.fast_gi_thickness_near = 0.25
    bpy.context.scene.eevee.fast_gi_thickness_far = 0.785398
    bpy.context.scene.eevee.fast_gi_bias = 0.05
    print("Eevee setup basics applied.")

# Panel class
class HHP_PT_OptimizePanel(bpy.types.Panel):
    bl_label = "Optimize (HHP)"
    bl_idname = "HHP_PT_optimize_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Char (HHP)"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 5

    def draw(self, context):
        layout = self.layout
        
        # First row: Flip Material Link and Eevee Setup Basics
        row = layout.row(align=True)
        row.operator("hhp.flip_material_link", text="Toggle optimized materials", icon='MATERIAL')
        row.operator("hhp.eevee_setup_basics", text="Eevee setup basics", icon='SCENE')

        # Second row: Bind to Active and Toggle Armatures (Smart)
        row = layout.row(align=True)
        row.operator("hhp.bind_surface_deform", text="Bind to active", icon='MOD_LATTICE')
        row.operator("hhp.toggle_armature_smart", text="Toggle armatures", icon='ARMATURE_DATA')

# Operator for "Flip Material Link"
class HHP_OT_FlipMaterialLink(bpy.types.Operator):
    bl_idname = "hhp.flip_material_link"
    bl_label = "Flip Material Link"
    
    def execute(self, context):
        toggle_material_link(bpy.context.selected_objects)
        return {'FINISHED'}

# Operator for "Bind to Active"
class HHP_OT_BindSurfaceDeform(bpy.types.Operator):
    bl_idname = "hhp.bind_surface_deform"
    bl_label = "Bind Surface Deform"
    
    def execute(self, context):
        source_obj = bpy.context.active_object
        add_surface_deform_to_selected(source_obj)
        return {'FINISHED'}

# Operator for "Toggle Armatures (Smart)"
class HHP_OT_ToggleArmatureSmart(bpy.types.Operator):
    bl_idname = "hhp.toggle_armature_smart"
    bl_label = "Toggle Armatures (Smart)"
    
    def execute(self, context):
        set_armature_state()
        return {'FINISHED'}

# Operator for "Eevee Setup Basics"
class HHP_OT_EeveeSetupBasics(bpy.types.Operator):
    bl_idname = "hhp.eevee_setup_basics"
    bl_label = "Eevee Setup Basics"
    
    def execute(self, context):
        setup_eevee_basics()
        return {'FINISHED'}

# Register the panel and operators
def register():
    bpy.utils.register_class(HHP_PT_OptimizePanel)
    bpy.utils.register_class(HHP_OT_FlipMaterialLink)
    bpy.utils.register_class(HHP_OT_BindSurfaceDeform)
    bpy.utils.register_class(HHP_OT_ToggleArmatureSmart)
    bpy.utils.register_class(HHP_OT_EeveeSetupBasics)

def unregister():
    bpy.utils.unregister_class(HHP_PT_OptimizePanel)
    bpy.utils.unregister_class(HHP_OT_FlipMaterialLink)
    bpy.utils.unregister_class(HHP_OT_BindSurfaceDeform)
    bpy.utils.unregister_class(HHP_OT_ToggleArmatureSmart)
    bpy.utils.unregister_class(HHP_OT_EeveeSetupBasics)

if __name__ == "__main__":
    register()
