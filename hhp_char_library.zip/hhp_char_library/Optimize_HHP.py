import bpy

# Function to toggle material link type
def toggle_material_link(selected_objects):
    current_link = None
    for obj in selected_objects:
        if obj.material_slots:
            current_link = obj.material_slots[0].link
            break

    if current_link is None:
        print("No materials found on selected objects.")
        return

    new_link = 'OBJECT' if current_link == 'DATA' else 'DATA'
    
    for obj in selected_objects:
        if obj.material_slots:
            for slot in obj.material_slots:
                slot.link = new_link

    print(f"Material link set to '{new_link}' for all selected objects.")
    bpy.context.view_layer.update()

# Function for "Bind to Active" button
def add_surface_deform_to_selected(source_obj):
    if not source_obj or source_obj.type != 'MESH':
        print("Active object is not a mesh or is not selected.")
        return

    initial_selection = bpy.context.selected_objects.copy()
    initial_active = bpy.context.view_layer.objects.active

    bpy.ops.object.mode_set(mode='OBJECT')

    for obj in initial_selection:
        if obj == source_obj:
            continue

        surf_deform_mod = obj.modifiers.new(name="SurfaceDeform", type='SURFACE_DEFORM')
        surf_deform_mod.target = source_obj
        surf_deform_mod.show_in_editmode = True
        surf_deform_mod.show_on_cage = True

        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.surfacedeform_bind(modifier=surf_deform_mod.name)

    bpy.ops.object.select_all(action='DESELECT')
    for obj in initial_selection:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = initial_active

    print("Surface Deform modifiers added and bound to the active object.")

# Function for "Toggle Armatures (Smart)" button
def set_armature_state():
    pose_count = sum(1 for obj in bpy.data.objects if obj.type == 'ARMATURE' and obj.data.pose_position == 'POSE')
    rest_count = sum(1 for obj in bpy.data.objects if obj.type == 'ARMATURE' and obj.data.pose_position == 'REST')

    desired_state = 'REST' if pose_count > rest_count else 'POSE'

    for obj in bpy.data.objects:
        if obj.type == 'ARMATURE':
            obj.data.pose_position = desired_state
            obj.update_tag()
    bpy.context.view_layer.update()

    print(f"All armatures set to {desired_state} position.")

# Panel class
class HHP_PT_OptimizePanel(bpy.types.Panel):
    bl_label = "Optimize (HHP)"
    bl_idname = "HHP_PT_optimize_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Char (HHP)"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 5

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)  # Align to save space
        
        # Buttons in one row
        row.operator("hhp.flip_material_link", text="Toggle Optimized material", icon='MATERIAL')
        row.operator("hhp.bind_surface_deform", text="Bind to active", icon='MOD_LATTICE')
        row.operator("hhp.toggle_armature_smart", text="Toggle Armatures", icon='ARMATURE_DATA')

# Operator for "Flip Material Link"
class HHP_OT_FlipMaterialLink(bpy.types.Operator):
    bl_idname = "hhp.flip_material_link"
    bl_label = "Flip Material Link"
    
    def execute(self, context):
        toggle_material_link(bpy.context.selected_objects)
        return {'FINISHED'}

# Operator for "Bind to Active"
class HHP_OT_BindSurfaceDeform(bpy.types.Operator):
    bl_idname = "hhp.bind_surface_deform"
    bl_label = "Bind Surface Deform"
    
    def execute(self, context):
        source_obj = bpy.context.active_object
        add_surface_deform_to_selected(source_obj)
        return {'FINISHED'}

# Operator for "Toggle Armatures (Smart)"
class HHP_OT_ToggleArmatureSmart(bpy.types.Operator):
    bl_idname = "hhp.toggle_armature_smart"
    bl_label = "Toggle Armatures (Smart)"
    
    def execute(self, context):
        set_armature_state()
        return {'FINISHED'}

# Register the panel and operators
def register():
    bpy.utils.register_class(HHP_PT_OptimizePanel)
    bpy.utils.register_class(HHP_OT_FlipMaterialLink)
    bpy.utils.register_class(HHP_OT_BindSurfaceDeform)
    bpy.utils.register_class(HHP_OT_ToggleArmatureSmart)

def unregister():
    bpy.utils.unregister_class(HHP_PT_OptimizePanel)
    bpy.utils.unregister_class(HHP_OT_FlipMaterialLink)
    bpy.utils.unregister_class(HHP_OT_BindSurfaceDeform)
    bpy.utils.unregister_class(HHP_OT_ToggleArmatureSmart)

if __name__ == "__main__":
    register()
