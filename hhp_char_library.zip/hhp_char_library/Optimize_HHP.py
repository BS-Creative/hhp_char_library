import bpy
from .modules import use_optimized_normals_node
import re

_ENUM_SUFFIX_RE = re.compile(r"\.(\d{3})$")


def _get_enumeration_number(name: str) -> int:
    """Return Blender-style .001 enumeration as int, or 0 if not enumerated."""
    if not name:
        return 0
    m = _ENUM_SUFFIX_RE.search(name)
    if not m:
        return 0
    try:
        return int(m.group(1))
    except Exception:
        return 0


def _get_base_name(name: str) -> str:
    """Strip Blender-style .001 suffix if present."""
    if not name:
        return ""
    m = _ENUM_SUFFIX_RE.search(name)
    return name[: m.start()] if m else name


def _is_hhp_character_mesh(obj) -> bool:
    """Mirror the 'Select HHP Character' dropdown detection logic from __init__.py."""
    return (
        obj is not None
        and obj.type == 'MESH'
        and "Genesis8Female.Shape" in obj.name
        and getattr(obj.data, "name", None) is not None
        and "Genesis8Female" in obj.data.name
        and "Deform Proxy" not in obj.name
    )


def _iter_layer_collections(root_lc, inherited_excluded=False, inherited_hidden=False):
    eff_excluded = inherited_excluded or bool(getattr(root_lc, "exclude", False))
    eff_hidden = inherited_hidden or bool(getattr(root_lc, "hide_viewport", False))
    yield root_lc, eff_excluded, eff_hidden
    for child in getattr(root_lc, "children", []):
        yield from _iter_layer_collections(child, eff_excluded, eff_hidden)


def _get_view_layer_collection_flags(context):
    """Map bpy.data.collections -> (effective_excluded, effective_hidden) in current view layer."""
    flags = {}
    try:
        for lc, eff_excluded, eff_hidden in _iter_layer_collections(context.view_layer.layer_collection):
            flags[lc.collection] = (eff_excluded, eff_hidden)
    except Exception:
        pass
    return flags


def _find_visible_char_hhp_collections(context):
    """Return visible, non-excluded collections in the scene tree whose name contains 'Char (HHP)'."""
    col_flags = _get_view_layer_collection_flags(context)

    char_cols = []
    try:
        stack = [context.scene.collection]
        seen = set()
        while stack:
            col = stack.pop()
            if col is None or col.name in seen:
                continue
            seen.add(col.name)

            if "Char (HHP)" in col.name:
                if not bool(getattr(col, "hide_viewport", False)):
                    eff = col_flags.get(col)
                    if eff is not None:
                        eff_excluded, eff_hidden = eff
                        if not eff_excluded and not eff_hidden:
                            char_cols.append(col)

            stack.extend(list(getattr(col, "children", [])))
    except Exception:
        return []

    char_cols.sort(key=lambda c: (_get_base_name(c.name).lower(), _get_enumeration_number(c.name), c.name.lower()))
    return char_cols


def _build_collection_parent_map(root_collection):
    """Build a mapping {child_collection: parent_collection} for the scene collection tree."""
    parent_map = {}
    if root_collection is None:
        return parent_map

    stack = [root_collection]
    seen = set()
    while stack:
        col = stack.pop()
        if col is None or col in seen:
            continue
        seen.add(col)
        for child in getattr(col, "children", []):
            if child is None:
                continue
            # First parent encountered is fine for our use (Blender collections can be linked multiple places,
            # but Char (HHP) characters are expected to live in one hierarchy).
            parent_map.setdefault(child, col)
            stack.append(child)
    return parent_map


def _find_char_hhp_collection_for_object(context, obj):
    """
    Given ANY object (even deep inside sub-collections), find the topmost parent collection
    in its hierarchy that contains 'Char (HHP)' in the name.

    This lets us scope actions to the correct character even when the active object is a clothing mesh
    in a sub-sub-sub collection.
    """
    if obj is None:
        return None

    parent_map = _build_collection_parent_map(getattr(context.scene, "collection", None))
    candidates = []

    for start_col in getattr(obj, "users_collection", []) or []:
        col = start_col
        topmost_char = None
        while col is not None:
            if "Char (HHP)" in getattr(col, "name", ""):
                # Keep updating so we end up with the HIGHEST parent Char (HHP) in this chain.
                topmost_char = col
            col = parent_map.get(col)
        if topmost_char is not None:
            candidates.append(topmost_char)

    if not candidates:
        return None

    # Prefer lowest enumeration collection (Char (HHP) vs Char (HHP).001)
    candidates.sort(key=lambda c: (_get_base_name(c.name).lower(), _get_enumeration_number(c.name), c.name.lower()))
    return candidates[0]


def _hhp_select_make_active(context, obj):
    """Switch to Object Mode, deselect all, then select the object and make it active."""
    try:
        if getattr(context, "mode", None) != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        pass

    try:
        bpy.ops.object.select_all(action='DESELECT')
    except Exception:
        try:
            for o in context.view_layer.objects:
                o.select_set(False)
        except Exception:
            pass

    try:
        obj.select_set(True)
    except Exception:
        pass
    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass


def _auto_select_hhp_character_for_current_context(context):
    """
    Auto-select an HHP character mesh to operate on:
    - If the current active object is inside a Char (HHP) collection, select the lowest-enumeration HHP mesh in that collection.
    - Otherwise select the lowest-enumeration HHP mesh in the lowest-enumeration visible Char (HHP) collection.
    """
    active = getattr(context, "active_object", None)

    def _lowest_hhp_mesh_in_collection(col):
        meshes = [o for o in list(getattr(col, "objects", [])) if _is_hhp_character_mesh(o)]
        if not meshes:
            return None
        meshes.sort(key=lambda o: (_get_base_name(o.name).lower(), _get_enumeration_number(o.name), o.name.lower()))
        return meshes[0]

    # Prefer "current character context": walk up the active object's collection tree to the top Char (HHP).
    if active is not None:
        char_col = _find_char_hhp_collection_for_object(context, active)
        if char_col is not None:
            target = _lowest_hhp_mesh_in_collection(char_col)
            if target:
                _hhp_select_make_active(context, target)
                return target

    # Only if we can't infer a containing Char (HHP) collection, fall back to searching visible Char (HHP) collections.
    # (This prevents selecting a different character elsewhere in the scene when you're already inside Char (HHP).001.)
    for col in _find_visible_char_hhp_collections(context):
        target = _lowest_hhp_mesh_in_collection(col)
        if target:
            _hhp_select_make_active(context, target)
            return target

    return None


def _get_target_hhp_character_for_current_collection(context, auto_select=False):
    """
    Return (character_mesh_obj, char_collection, error_message).

    We scope actions to the active HHP character mesh's direct "Char (HHP)" collection,
    and require BOTH the collection and mesh to be the lowest enumeration (to avoid duplicates).
    """
    obj = getattr(context, "active_object", None)
    if auto_select and not _is_hhp_character_mesh(obj):
        obj = _auto_select_hhp_character_for_current_context(context)

    if not _is_hhp_character_mesh(obj):
        return None, None, "No HHP character mesh found to operate on."

    # Find the direct Char (HHP) collection(s) this mesh is inside.
    char_cols = [c for c in getattr(obj, "users_collection", []) if c and "Char (HHP)" in c.name]
    if not char_cols:
        return None, None, "HHP character mesh must be directly inside a 'Char (HHP)' collection."

    # Prefer the lowest-enumeration Char (HHP) collection (avoid '.001' duplicates).
    def _col_sort_key(c):
        return (_get_base_name(c.name).lower(), _get_enumeration_number(c.name), c.name.lower())

    char_cols.sort(key=_col_sort_key)
    char_col = char_cols[0]

    # Enforce mesh is the lowest enumeration inside this collection (avoid '.001' duplicates).
    mesh_base = _get_base_name(obj.name)
    mesh_candidates = [o for o in list(char_col.objects) if _is_hhp_character_mesh(o) and _get_base_name(o.name) == mesh_base]
    if mesh_candidates:
        mesh_candidates.sort(key=lambda o: (_get_enumeration_number(o.name), o.name.lower()))
        lowest_mesh = mesh_candidates[0]
        if obj != lowest_mesh:
            if auto_select:
                obj = lowest_mesh
                _hhp_select_make_active(context, obj)
            else:
                return None, None, f"Active HHP character mesh must be the lowest enumeration in '{char_col.name}' (use '{lowest_mesh.name}', not '{obj.name}')."

    return obj, char_col, None

# Function to check if all selected objects' materials are linked via 'OBJECT'
def is_material_linked_by_object(selected_objects):
    has_material = False
    for obj in selected_objects:
        if obj.type != 'MESH':
            continue
        if obj.material_slots:
            has_material = True
            for slot in obj.material_slots:
                if slot.link != 'OBJECT':
                    return False
    return has_material

# Function to toggle material link type
def toggle_material_link(selected_objects):
    current_link = None
    for obj in selected_objects:
        if obj.material_slots:
            current_link = obj.material_slots[0].link
            break

    if current_link is None:
        print("No materials found on selected objects.")
        return

    new_link = 'OBJECT' if current_link == 'DATA' else 'DATA'
    
    for obj in selected_objects:
        if obj.material_slots:
            for slot in obj.material_slots:
                slot.link = new_link

    print(f"Material link set to '{new_link}' for all selected objects.")
    bpy.context.view_layer.update()

# Function to check if heavy collections are hidden (scoped to active HHP character collection)
def is_heavy_collections_hidden(context=None):
    context = context or bpy.context
    obj, char_col, _err = _get_target_hhp_character_for_current_collection(context, auto_select=False)
    if not char_col:
        return False

    collections_to_check = find_collections_recursive(char_col, ["Clothes", "Hair", "Char Appendage"])
    if not collections_to_check:
        return False
    return all(col.hide_viewport for col in collections_to_check)

# Function to toggle heavy collections (scoped to active HHP character collection)
def toggle_heavy_collections(context):
    scene = context.scene
    _obj, char_col, err = _get_target_hhp_character_for_current_collection(context, auto_select=False)
    if not char_col:
        print(err or "No active HHP character collection found.")
        return

    collections_to_toggle = find_collections_recursive(char_col, ["Clothes", "Hair", "Char Appendage"])
    if not collections_to_toggle:
        print(f"No 'Clothes', 'Hair', or 'Char Appendage' collections found inside '{char_col.name}'.")
        return

    # Find mask properties only on objects within THIS character collection tree (avoid affecting other characters).
    mask_properties = []
    try:
        objs_in_char = list(char_col.all_objects)
    except Exception:
        # Fallback: traverse recursively.
        objs_in_char = []
        stack = [char_col]
        seen = set()
        while stack:
            c = stack.pop()
            if c is None or c.name in seen:
                continue
            seen.add(c.name)
            objs_in_char.extend(list(getattr(c, "objects", [])))
            stack.extend(list(getattr(c, "children", [])))

    # Scene custom mask props (kept for backward compatibility).
    for prop_name in scene.keys():
        if "Mask -" in prop_name and isinstance(scene[prop_name], bool):
            mask_properties.append(('scene', prop_name, scene))

    # Object mask props (scoped to this character only).
    for o in objs_in_char:
        for prop_name in o.keys():
            if "Mask -" in prop_name and isinstance(o[prop_name], bool):
                mask_properties.append(('object', prop_name, o))

    all_hidden = all(col.hide_viewport for col in collections_to_toggle)

    vis_key = f"heavy_collections_visibility__{char_col.name}"
    mask_key = f"mask_properties_states__{char_col.name}"

    if not all_hidden:
        visibility_states = {}
        for col in collections_to_toggle:
            visibility_states[col.name] = bool(col.hide_viewport)
            col.hide_viewport = True

        mask_property_states = {}
        for prop_type, prop_name, owner in mask_properties:
            if prop_type == 'scene':
                mask_property_states[f"scene_{prop_name}"] = bool(owner[prop_name])
                owner[prop_name] = False
            elif prop_type == 'object':
                mask_property_states[f"object_{owner.name}_{prop_name}"] = bool(owner[prop_name])
                owner[prop_name] = False

        scene[vis_key] = visibility_states
        scene[mask_key] = mask_property_states

        # Refresh viewport
        if context.active_object and context.active_object.type == 'MESH':
            try:
                if context.active_object.mode == 'OBJECT':
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

        print(f"Heavy collections hidden and mask properties disabled for '{char_col.name}'.")
        return

    # Restore
    if vis_key in scene:
        visibility_states = scene[vis_key]
        for col in collections_to_toggle:
            col.hide_viewport = bool(visibility_states.get(col.name, False))
        del scene[vis_key]
    else:
        for col in collections_to_toggle:
            col.hide_viewport = False

    if mask_key in scene:
        mask_property_states = scene[mask_key]
        for key, value in mask_property_states.items():
            if key.startswith('scene_'):
                prop_name = key[6:]
                if prop_name in scene:
                    scene[prop_name] = bool(value)
            elif key.startswith('object_'):
                parts = key.split('_', 2)
                if len(parts) >= 3:
                    obj_name = parts[1]
                    prop_name = parts[2]
                    o = bpy.data.objects.get(obj_name)
                    if o and prop_name in o:
                        o[prop_name] = bool(value)
        del scene[mask_key]

    # Refresh viewport
    if context.active_object and context.active_object.type == 'MESH':
        try:
            if context.active_object.mode == 'OBJECT':
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass

    print(f"Heavy collections visibility and mask properties restored for '{char_col.name}'.")


def _ensure_lowest_hhp_character_selected_for_action(context):
    """
    Ensure the active object is the lowest-enumeration HHP character mesh in the lowest-enumeration
    Char (HHP) collection context. If not, auto-select it and return (obj, col, True).

    Returns:
      (obj, char_col, did_auto_select, error_message)
    """
    # If current active is already valid (and lowest), do nothing.
    obj, char_col, err = _get_target_hhp_character_for_current_collection(context, auto_select=False)
    if obj and char_col and not err:
        return obj, char_col, False, None

    active = getattr(context, "active_object", None)

    def _pick_lowest_mesh_in_char_collection(col):
        meshes = [o for o in list(getattr(col, "objects", [])) if _is_hhp_character_mesh(o)]
        if not meshes:
            return None
        meshes.sort(key=lambda o: (_get_base_name(o.name).lower(), _get_enumeration_number(o.name), o.name.lower()))
        return meshes[0]

    # Try to infer the "current" Char (HHP) collection from whatever is active.
    if active is not None:
        chosen_col = _find_char_hhp_collection_for_object(context, active)
        target = _pick_lowest_mesh_in_char_collection(chosen_col) if chosen_col else None
        if target:
            _hhp_select_make_active(context, target)
            # Re-resolve to also normalize collection/mesh lowest-enum constraints.
            obj2, col2, _err2 = _get_target_hhp_character_for_current_collection(context, auto_select=True)
            return obj2 or target, col2 or chosen_col, True, None

    # Fallback: select the lowest-enumeration HHP character mesh we can find in visible Char (HHP) collections.
    target = _auto_select_hhp_character_for_current_context(context)
    if target:
        obj2, col2, _err2 = _get_target_hhp_character_for_current_collection(context, auto_select=True)
        return obj2 or target, col2, True, None

    return None, None, False, "No HHP character mesh found in the current view to operate on."

def find_collections_recursive(collection, prefixes):
    matched_collections = []
    for child in collection.children:
        for prefix in prefixes:
            if child.name.startswith(prefix):
                matched_collections.append(child)
        # Recurse into children
        matched_collections.extend(find_collections_recursive(child, prefixes))
    return matched_collections

# Function for "Bind to Active" button
def add_surface_deform_to_selected(source_obj):
    if not source_obj or source_obj.type != 'MESH':
        print("Active object is not a mesh or is not selected.")
        return

    initial_selection = bpy.context.selected_objects.copy()
    initial_active = bpy.context.view_layer.objects.active

    bpy.ops.object.mode_set(mode='OBJECT')

    for obj in initial_selection:
        if obj == source_obj:
            continue

        surf_deform_mod = obj.modifiers.new(name="SurfaceDeform", type='SURFACE_DEFORM')
        surf_deform_mod.target = source_obj
        surf_deform_mod.show_in_editmode = True
        surf_deform_mod.show_on_cage = True

        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.surfacedeform_bind(modifier=surf_deform_mod.name)

    bpy.ops.object.select_all(action='DESELECT')
    for obj in initial_selection:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = initial_active

    print("Surface Deform modifiers added and bound to the active object.")

# Function for "Bind to Proxy" - excludes the original active mesh
def add_surface_deform_to_selected_excluding_active(source_obj, exclude_obj):
    if not source_obj or source_obj.type != 'MESH':
        print("Active object is not a mesh or is not selected.")
        return

    initial_selection = bpy.context.selected_objects.copy()
    initial_active = bpy.context.view_layer.objects.active

    bpy.ops.object.mode_set(mode='OBJECT')

    for obj in initial_selection:
        if obj == source_obj or obj == exclude_obj:
            continue

        surf_deform_mod = obj.modifiers.new(name="SurfaceDeform", type='SURFACE_DEFORM')
        surf_deform_mod.target = source_obj
        surf_deform_mod.show_in_editmode = True
        surf_deform_mod.show_on_cage = True

        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.surfacedeform_bind(modifier=surf_deform_mod.name)

    bpy.ops.object.select_all(action='DESELECT')
    for obj in initial_selection:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = initial_active

    print("Surface Deform modifiers added and bound to the proxy object.")

# Function for "Toggle Armatures (Smart)" button
def set_armature_state():
    pose_count = sum(1 for obj in bpy.data.objects if obj.type == 'ARMATURE' and obj.data.pose_position == 'POSE')
    rest_count = sum(1 for obj in bpy.data.objects if obj.type == 'ARMATURE' and obj.data.pose_position == 'REST')

    desired_state = 'REST' if pose_count > rest_count else 'POSE'

    for obj in bpy.data.objects:
        if obj.type == 'ARMATURE':
            obj.data.pose_position = desired_state
            obj.update_tag()
    bpy.context.view_layer.update()

    print(f"All armatures set to {desired_state} position.")

# Function for "Setup Render Basics" button
def setup_render_basics():
    # General render settings
    bpy.context.scene.unit_settings.system = 'METRIC'
    bpy.context.scene.render.use_simplify = True
    bpy.context.scene.render.simplify_subdivision = 0
    bpy.context.scene.render.simplify_subdivision_render = 3
    bpy.context.scene.render.use_motion_blur = False
    bpy.context.scene.sync_mode = 'AUDIO_SYNC'
    bpy.context.scene.render.use_persistent_data = True
    
    # Cycles settings
    if bpy.context.scene.cycles.transparent_max_bounces < 100:
        bpy.context.scene.cycles.transparent_max_bounces = 100
    
    # Eevee settings
    bpy.context.scene.eevee.use_taa_reprojection = False
    bpy.context.scene.eevee.use_shadow_jitter_viewport = False
    bpy.context.scene.eevee.taa_samples = 64
    bpy.context.scene.eevee.taa_render_samples = 64
    bpy.context.scene.eevee.use_overscan = True
    bpy.context.scene.eevee.overscan_size = 3
    bpy.context.scene.eevee.use_shadows = True
    bpy.context.scene.eevee.shadow_resolution_scale = 0.5
    bpy.context.scene.eevee.shadow_ray_count = 1
    bpy.context.scene.eevee.shadow_step_count = 6
    bpy.context.scene.eevee.use_raytracing = True
    bpy.context.scene.eevee.ray_tracing_method = 'SCREEN'
    bpy.context.scene.eevee.ray_tracing_options.resolution_scale = '1'
    bpy.context.scene.eevee.ray_tracing_options.trace_max_roughness = 0.5
    bpy.context.scene.eevee.ray_tracing_options.screen_trace_quality = 0.25
    bpy.context.scene.eevee.ray_tracing_options.screen_trace_thickness = 0.2
    bpy.context.scene.eevee.ray_tracing_options.use_denoise = True
    bpy.context.scene.eevee.ray_tracing_options.denoise_spatial = True
    bpy.context.scene.eevee.ray_tracing_options.denoise_temporal = True
    bpy.context.scene.eevee.ray_tracing_options.denoise_bilateral = True
    bpy.context.scene.eevee.fast_gi_method = 'GLOBAL_ILLUMINATION'
    bpy.context.scene.eevee.fast_gi_resolution = '2'
    bpy.context.scene.eevee.fast_gi_ray_count = 2
    bpy.context.scene.eevee.fast_gi_step_count = 8
    bpy.context.scene.eevee.fast_gi_quality = 0.25
    bpy.context.scene.eevee.fast_gi_distance = 0
    bpy.context.scene.eevee.fast_gi_thickness_near = 0.25
    bpy.context.scene.eevee.fast_gi_thickness_far = 0.785398
    bpy.context.scene.eevee.fast_gi_bias = 0.05
    print("Render setup basics applied.")

# Panel class
class HHP_PT_OptimizePanel(bpy.types.Panel):
    bl_label = "Optimize / Tools (HHP)"
    bl_idname = "HHP_PT_optimize_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Char (HHP)"
    bl_parent_id = "CHAR_HHP_PT_Panel"  # Set parent panel
    bl_options = {'HIDE_HEADER'}  # Hide the header
    bl_order = 15
    
    @classmethod
    def poll(cls, context):
        # Only show this panel if OPTIMIZE is selected in the mode selector
        return context.scene.hhp_panel_mode.selected_panel == 'OPTIMIZE'

    def draw(self, context):
        layout = self.layout

        # Create a box layout
        box = layout.box()
        box.label(text="Limit Texture Size (VRAM Optimizer)")
        col = box.column(align=True)
        col.operator("file.find_missing_files", text="Re-Link Textures")
        col.prop(bpy.context.preferences.system, "gl_texture_limit", text="")

        # Check state on the active HHP character mesh (scoped, avoids affecting duplicates)
        char_obj, _char_col, _err = _get_target_hhp_character_for_current_collection(context)
        materials_linked_by_object = is_material_linked_by_object([char_obj]) if char_obj else False

        # Prepare the label for the playback method
        scene = context.scene
        sync_mode = scene.sync_mode

        if sync_mode == 'NONE':
            playback_label = "Play Every Frame"
        elif sync_mode == 'AUDIO_SYNC':
            playback_label = "Sync to Audio"
        elif sync_mode == 'FRAME_DROP':
            playback_label = "Frame Dropping"
        else:
            playback_label = "Unknown"

        # Create aligned column for two-column button layout
        col = layout.column(align=True)
        
        # Row 1: Toggle optimized materials | Toggle optimized view
        row = col.row(align=True)
        row.operator("hhp.flip_material_link", text="Toggle optimized materials", icon='MATERIAL', depress=materials_linked_by_object)
        row.operator("hhp.toggle_heavy_collections", text="Toggle optimized view", icon='HIDE_OFF', depress=is_heavy_collections_hidden(context))

        # Row 1.5: Use Optimized Normals toggle (below both buttons)
        row = col.row(align=True)
        row.prop(
            context.scene,
            "hhp_use_optimized_normals",
            text="Use Optimized Normals (Recommended)",
            icon='NORMALS_VERTEX',
            toggle=True,
        )
        
        # Row 2: Inflate SK by active | Bind to active
        row = col.row(align=True)
        row.operator("hhp.inflate_sk_by_active", text="Inflate SK by active", icon='SHAPEKEY_DATA')
        row.operator("hhp.bind_surface_deform", text="Bind to active", icon='MOD_LATTICE')
        
        # Row 3: Toggle armatures | Toggle playback method
        row = col.row(align=True)
        row.operator("hhp.toggle_armature_smart", text="Toggle armatures", icon='ARMATURE_DATA')
        row.operator("hhp.toggle_playback_method", text=playback_label, icon='PLAY')
        
        # Row 4: Create HHP Mask (full width since it's alone)
        row = col.row(align=True)
        row.operator("hhp.create_mask", text="Create HHP Mask", icon='MOD_MASK')

        # Add the Subsurface conversion button in its own full-width row
        row = layout.row(align=True)
        row.menu("SHADER_SSS_MT_menu", text="Shader setup", icon='BLENDER')

# Operator for "Flip Material Link"
class HHP_OT_FlipMaterialLink(bpy.types.Operator):
    bl_idname = "hhp.flip_material_link"
    bl_label = "Flip Material Link"
    bl_description = "Switches to optimized HHP materials for fast realtime animation playback. Handy to have on while animating"

    def execute(self, context):
        char_obj, _char_col, did_select, err = _ensure_lowest_hhp_character_selected_for_action(context)
        if not char_obj:
            self.report({'ERROR'}, err or "No HHP character mesh found to operate on.")
            return {'CANCELLED'}
        if did_select:
            self.report(
                {'WARNING'},
                "An HHP character mesh (Not a duplicate of it) must be selected for this action to take effect. "
                "The Helper Agent noticed this and selected it for you. You may now use this action."
            )
            return {'CANCELLED'}

        toggle_material_link([char_obj])
        return {'FINISHED'}

# Operator for "Toggle Heavy Collections"
class HHP_OT_ToggleHeavyCollections(bpy.types.Operator):
    bl_idname = "hhp.toggle_heavy_collections"
    bl_label = "Toggle Optimized View"
    bl_description = "Toggle optimized view mode: hide heavy collections (Clothes, Hair, Appendages) and disable mask properties for better performance."

    def execute(self, context):
        _char_obj, _char_col, did_select, err = _ensure_lowest_hhp_character_selected_for_action(context)
        if not _char_obj:
            self.report({'ERROR'}, err or "No HHP character mesh found to operate on.")
            return {'CANCELLED'}
        if did_select:
            self.report(
                {'WARNING'},
                "An HHP character mesh (Not a duplicate of it) must be selected for this action to take effect. "
                "The Helper Agent noticed this and selected it for you. You may now use this action."
            )
            return {'CANCELLED'}

        toggle_heavy_collections(context)
        return {'FINISHED'}

# Modified Operator for "Bind to Active"
class HHP_OT_BindSurfaceDeform(bpy.types.Operator):
    bl_idname = "hhp.bind_surface_deform"
    bl_label = "Bind Surface Deform"
    bl_description = "Bind surface deform modifiers from selected objects using the active object as target."

    def execute(self, context):
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.popup_menu(self.draw_menu, title="Bind Options")
        return {'FINISHED'}

    def draw_menu(self, menu, context):
        layout = menu.layout
        layout.operator("hhp.bind_surface_deform_normal", text="Bind to Active")
        layout.operator("hhp.bind_surface_deform_forced", text="Bind to Active (Forced)")
        layout.separator()
        layout.operator("hhp.bind_to_proxy_of_active", text="Bind to Proxy of Active")
        layout.operator("hhp.bind_to_proxy_of_active_forced", text="Bind to Proxy of Active (Forced)")

# Function to find proxy meshes with the same mesh data as the active object
def find_proxy_meshes(source_mesh):
    """Find all meshes that share the same mesh data as the source mesh"""
    if not source_mesh or source_mesh.type != 'MESH':
        return []
    
    # Find all objects with the same mesh data
    proxy_candidates = [
        obj for obj in bpy.data.objects
        if obj.type == 'MESH' and obj.data == source_mesh.data and obj != source_mesh
    ]
    
    return proxy_candidates

# New Operator for normal binding
class HHP_OT_BindSurfaceDeformNormal(bpy.types.Operator):
    bl_idname = "hhp.bind_surface_deform_normal"
    bl_label = "Bind Surface Deform Normal"
    bl_description = "Bind with surface deform modifiers from selected objects using the active object as target"

    def execute(self, context):
        source_obj = bpy.context.active_object
        add_surface_deform_to_selected(source_obj)
        return {'FINISHED'}

# New Operator for forced binding
class HHP_OT_BindSurfaceDeformForced(bpy.types.Operator):
    bl_idname = "hhp.bind_surface_deform_forced"
    bl_label = "Bind Surface Deform Forced"
    bl_description = "Bind with surface deform modifiers using triangulation method for difficult geometry"

    def execute(self, context):
        # Script 1: Add triangulate modifier
        if bpy.context.active_object and bpy.context.active_object.type == 'MESH':
            obj = bpy.context.active_object
            triangulate_mod = obj.modifiers.new(name="Triangulate", type='TRIANGULATE')
            triangulate_mod.quad_method = 'FIXED'
            triangulate_mod.ngon_method = 'BEAUTY'
            triangulate_mod.min_vertices = 4
            print("Triangulate modifier added with specified settings.")
        else:
            print("No suitable active object found or the active object cannot have modifiers.")

        # Script 2: Add surface deform
        source_obj = bpy.context.active_object
        add_surface_deform_to_selected(source_obj)

        # Script 3: Remove triangulate modifier
        if bpy.context.active_object and bpy.context.active_object.type == 'MESH':
            obj = bpy.context.active_object
            last_triangulate_modifier = None
            
            for modifier in obj.modifiers:
                if modifier.type == 'TRIANGULATE':
                    last_triangulate_modifier = modifier
            
            if last_triangulate_modifier:
                obj.modifiers.remove(last_triangulate_modifier)
                print("Last Triangulate modifier removed.")
            else:
                print("No Triangulate modifier found.")
        else:
            print("No suitable active mesh object found.")

        return {'FINISHED'}

# Operator for binding to deform proxy
class HHP_OT_BindToProxyOfActive(bpy.types.Operator):
    bl_idname = "hhp.bind_to_proxy_of_active"
    bl_label = "Bind to Proxy of Active"
    bl_description = "Bind with surface deform modifiers to a proxy mesh that shares the same mesh data as the active object"

    def execute(self, context):
        active_obj = bpy.context.active_object
        if not active_obj or active_obj.type != 'MESH':
            self.report({'ERROR'}, "Active object must be a mesh")
            return {'CANCELLED'}

        proxy_meshes = find_proxy_meshes(active_obj)
        if not proxy_meshes:
            self.report({'ERROR'}, "No proxy meshes found that share the same mesh data as the active object")
            return {'CANCELLED'}

        # Store the proxy meshes for the popup menu
        bpy.context.scene['proxy_meshes'] = [obj.name for obj in proxy_meshes]
        context.window_manager.popup_menu(self.draw_proxy_menu, title="Select Proxy Mesh")
        return {'FINISHED'}

    def draw_proxy_menu(self, menu, context):
        layout = menu.layout
        if 'proxy_meshes' in context.scene:
            proxy_names = context.scene['proxy_meshes']
            for proxy_name in proxy_names:
                proxy_obj = bpy.data.objects.get(proxy_name)
                if proxy_obj:
                    op = layout.operator("hhp.bind_to_proxy_execute", text=proxy_name)
                    op.proxy_name = proxy_name
                    op.is_forced = False

# Operator for binding to deform proxy (forced)
class HHP_OT_BindToProxyOfActiveForced(bpy.types.Operator):
    bl_idname = "hhp.bind_to_proxy_of_active_forced"
    bl_label = "Bind to Proxy of Active (Forced)"
    bl_description = "Bind with surface deform modifiers to a proxy mesh using triangulation method for difficult geometry"

    def execute(self, context):
        active_obj = bpy.context.active_object
        if not active_obj or active_obj.type != 'MESH':
            self.report({'ERROR'}, "Active object must be a mesh")
            return {'CANCELLED'}

        proxy_meshes = find_proxy_meshes(active_obj)
        if not proxy_meshes:
            self.report({'ERROR'}, "No proxy meshes found that share the same mesh data as the active object")
            return {'CANCELLED'}

        # Store the proxy meshes for the popup menu
        bpy.context.scene['proxy_meshes'] = [obj.name for obj in proxy_meshes]
        context.window_manager.popup_menu(self.draw_proxy_menu, title="Select Proxy Mesh")
        return {'FINISHED'}

    def draw_proxy_menu(self, menu, context):
        layout = menu.layout
        if 'proxy_meshes' in context.scene:
            proxy_names = context.scene['proxy_meshes']
            for proxy_name in proxy_names:
                proxy_obj = bpy.data.objects.get(proxy_name)
                if proxy_obj:
                    op = layout.operator("hhp.bind_to_proxy_execute", text=proxy_name)
                    op.proxy_name = proxy_name
                    op.is_forced = True

# Operator to execute the actual binding to proxy
class HHP_OT_BindToProxyExecute(bpy.types.Operator):
    bl_idname = "hhp.bind_to_proxy_execute"
    bl_label = "Execute Bind to Proxy"
    bl_description = "Execute the binding to the selected proxy mesh"

    proxy_name: bpy.props.StringProperty()
    is_forced: bpy.props.BoolProperty(default=False)

    def execute(self, context):
        proxy_obj = bpy.data.objects.get(self.proxy_name)
        if not proxy_obj:
            self.report({'ERROR'}, f"Proxy object '{self.proxy_name}' not found")
            return {'CANCELLED'}

        # Store the original active object to exclude it from binding
        original_active = bpy.context.view_layer.objects.active

        if self.is_forced:
            # Add triangulate modifier to proxy
            triangulate_mod = proxy_obj.modifiers.new(name="Triangulate", type='TRIANGULATE')
            triangulate_mod.quad_method = 'FIXED'
            triangulate_mod.ngon_method = 'BEAUTY'
            triangulate_mod.min_vertices = 4
            print(f"Triangulate modifier added to {proxy_obj.name}")

        # Add surface deform using the proxy as target, but exclude the original active mesh
        add_surface_deform_to_selected_excluding_active(proxy_obj, original_active)

        if self.is_forced:
            # Remove triangulate modifier from proxy
            last_triangulate_modifier = None
            for modifier in proxy_obj.modifiers:
                if modifier.type == 'TRIANGULATE':
                    last_triangulate_modifier = modifier
            
            if last_triangulate_modifier:
                proxy_obj.modifiers.remove(last_triangulate_modifier)
                print(f"Triangulate modifier removed from {proxy_obj.name}")

        # Clean up the stored proxy meshes
        if 'proxy_meshes' in context.scene:
            del context.scene['proxy_meshes']

        return {'FINISHED'}

# Operator for "Toggle Armatures (Smart)"
class HHP_OT_ToggleArmatureSmart(bpy.types.Operator):
    bl_idname = "hhp.toggle_armature_smart"
    bl_label = "Toggle Armatures (Smart)"
    bl_description = "Toggle between REST and POSE modes for armatures based on current state."

    def execute(self, context):
        set_armature_state()
        return {'FINISHED'}

# Operator for "Setup Render Basics"
class HHP_OT_SetupRenderBasics(bpy.types.Operator):
    bl_idname = "hhp.setup_render_basics"
    bl_label = "Setup Render Basics"
    bl_description = "Apply basic render settings for both Eevee and Cycles engines for optimal character rendering and performance"

    def execute(self, context):
        setup_render_basics()
        self.report({'INFO'}, "Render setup basics applied")
        return {'FINISHED'}

# Operator for "Toggle Playback Method"
class HHP_OT_TogglePlaybackMethod(bpy.types.Operator):
    bl_idname = "hhp.toggle_playback_method"
    bl_label = "Toggle Playback Method"
    bl_description = "Toggle playback method between 'Sync to Audio' and 'Play Every Frame'."

    def execute(self, context):
        scene = context.scene
        current_mode = scene.sync_mode

        if current_mode == 'AUDIO_SYNC':
            scene.sync_mode = 'NONE'
            self.report({'INFO'}, "Playback method set to 'Play Every Frame'")
        else:
            scene.sync_mode = 'AUDIO_SYNC'
            self.report({'INFO'}, "Playback method set to 'Sync to Audio'")

        return {'FINISHED'}

# Register the panel and operators
def register():
    use_optimized_normals_node.register_properties()
    bpy.utils.register_class(HHP_PT_OptimizePanel)
    bpy.utils.register_class(HHP_OT_FlipMaterialLink)
    bpy.utils.register_class(HHP_OT_ToggleHeavyCollections)
    bpy.utils.register_class(HHP_OT_BindSurfaceDeform)
    bpy.utils.register_class(HHP_OT_BindSurfaceDeformNormal)
    bpy.utils.register_class(HHP_OT_BindSurfaceDeformForced)
    bpy.utils.register_class(HHP_OT_BindToProxyOfActive)
    bpy.utils.register_class(HHP_OT_BindToProxyOfActiveForced)
    bpy.utils.register_class(HHP_OT_BindToProxyExecute)
    bpy.utils.register_class(HHP_OT_ToggleArmatureSmart)
    bpy.utils.register_class(HHP_OT_SetupRenderBasics)
    bpy.utils.register_class(HHP_OT_TogglePlaybackMethod)

def unregister():
    bpy.utils.unregister_class(HHP_PT_OptimizePanel)
    bpy.utils.unregister_class(HHP_OT_FlipMaterialLink)
    bpy.utils.unregister_class(HHP_OT_ToggleHeavyCollections)
    bpy.utils.unregister_class(HHP_OT_BindSurfaceDeform)
    bpy.utils.unregister_class(HHP_OT_BindSurfaceDeformNormal)
    bpy.utils.unregister_class(HHP_OT_BindSurfaceDeformForced)
    bpy.utils.unregister_class(HHP_OT_BindToProxyOfActive)
    bpy.utils.unregister_class(HHP_OT_BindToProxyOfActiveForced)
    bpy.utils.unregister_class(HHP_OT_BindToProxyExecute)
    bpy.utils.unregister_class(HHP_OT_ToggleArmatureSmart)
    bpy.utils.unregister_class(HHP_OT_SetupRenderBasics)
    bpy.utils.unregister_class(HHP_OT_TogglePlaybackMethod)
    use_optimized_normals_node.unregister_properties()

if __name__ == "__main__":
    register()
