bl_info = {
    "name":        "Experimental Anim Builder",
    "description": "Panel with an Action selector + direct reference to the active Action's blending mode, with a toggleable wrench icon for advanced options, and a 'Create Base layer' button.",
    "author":      "Your Name",
    "version":     (1, 9),
    "blender":     (3, 0, 0),
    "location":    "3D View > Char (HHP) > EXPERIMENTAL - Anim Builder",
    "category":    "3D View"
}

import bpy

def create_base_layer_action():
    """
    1) Store current bone selection
    2) Switch to Pose Mode
    3) Create "AB_Base layer" Action, assign it, select all bones
    4) Clear transforms
    5) Keyframe at start & end frames
    6) Push action to NLA with REPLACE blend
    7) Restore bone selection
    """
    armature = bpy.context.object
    if not armature or armature.type != 'ARMATURE':
        print("No valid armature selected.")
        return
    
    selected_bones = [bone.name for bone in armature.data.bones if bone.select]

    # Pose mode
    if armature.mode != 'POSE':
        bpy.ops.object.mode_set(mode='POSE')

    # Create a new action and assign
    new_action = bpy.data.actions.new("AB_Base layer")
    armature.animation_data_create()
    armature.animation_data.action = new_action

    # Select all bones, clear transforms, set keyframes at start & end
    bpy.ops.pose.select_all(action='SELECT')
    bpy.ops.pose.transforms_clear()

    start_frame = bpy.context.scene.frame_start
    end_frame = bpy.context.scene.frame_end

    bpy.context.scene.frame_set(start_frame)
    bpy.ops.anim.keyframe_insert(type='LocRotScale')
    bpy.context.scene.frame_set(end_frame)
    bpy.ops.anim.keyframe_insert(type='LocRotScale')

    # Push Action to NLA
    armature.animation_data.action = None
    nla_track = armature.animation_data.nla_tracks.new()
    nla_track.name = "AB_Base layer"
    nla_strip = nla_track.strips.new("AB_Base layer", start_frame, new_action)
    nla_strip.blend_type = 'REPLACE'
    nla_strip.frame_start = start_frame
    nla_strip.frame_end = end_frame

    # Restore selection
    bpy.ops.pose.select_all(action='DESELECT')
    for bone in armature.data.bones:
        bone.select = (bone.name in selected_bones)


class HHP_OT_CreateBaseLayer(bpy.types.Operator):
    """Create a new base layer action and push it to NLA"""
    bl_idname = "hhp.create_base_layer"
    bl_label = "Create Base layer"
    bl_description = "Creates a new 'AB_Base layer' action and pushes it to the NLA"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        """
        This operator is only valid if:
          1. An Armature is active, AND
          2. No NLA strip name contains 'AB_Base layer' on the active Armature.
        """
        ob = context.active_object
        if not ob or ob.type != 'ARMATURE':
            return False
        
        # Check if there's already a strip whose name contains "AB_Base layer"
        if ob.animation_data:
            for track in ob.animation_data.nla_tracks:
                for strip in track.strips:
                    if "AB_Base layer" in strip.name:
                        return False
        
        return True

    def invoke(self, context, event):
        """
        Show a confirmation dialog to avoid accidental clicks.
        """
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        # Create the base layer action
        create_base_layer_action()
        
        # After creating the base layer, set the blending mode to REPLACE
        ob = context.active_object
        if ob and ob.type == 'ARMATURE' and ob.animation_data:
            ob.animation_data.action_blend_type = 'REPLACE'
        
        # Also clear the selected action from the preview selector
        context.scene.hhp_animbuilder_props.action = None

        self.report({'INFO'}, "AB_Base layer created and pushed to NLA.")
        return {'FINISHED'}

def update_action(self, context):
    """
    When a new Action is selected or cleared in the dropdown:
      - If an Action is selected, set the Armature to 'POSE' position
        and assign that Action as the active action.
      - If cleared (None), do not force Pose Position.
    """
    ob = context.active_object
    if not ob or ob.type != 'ARMATURE':
        return

    # If the user selected a valid Action, force Pose Position
    if self.action:
        ob.data.pose_position = 'POSE'

    ob.animation_data_create()
    ob.animation_data.action = self.action

class HHP_AnimBuilder_Properties(bpy.types.PropertyGroup):
    # Pointer to a Blender Action. Updating it triggers update_action().
    action: bpy.props.PointerProperty(
        type=bpy.types.Action,
        description="Select an Action to apply to the active Armature",
        update=update_action
    )

    # A boolean property for advanced options: toggled via an icon
    advanced_options: bpy.props.BoolProperty(
        name="",  # no visible label
        description="Advanced Options:\nShow or hide advanced features like the Base Layer button.",
        default=False
    )

class HHP_PT_ExperimentalAnimBuilder(bpy.types.Panel):
    bl_label = "EXPERIMENTAL - Anim Builder"
    bl_idname = "HHP_PT_experimental_anim_builder"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Char (HHP)"
    bl_order = 40
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene_props = context.scene.hhp_animbuilder_props
        ob = context.active_object

        # Create a box labeled "Preview Animation"
        box = layout.box()
        box.label(text="Preview Animation")

        # If there's no Armature, just display a message
        if not ob or ob.type != 'ARMATURE':
            box.label(text="An armature needs to be selected for anim preview")
            return

        # Otherwise, show the row: [Toggle Icon], [Action Selector], [Blend Mode]
        col = box.column(align=True)
        row = col.row(align=True)

        # Toggle with a wrench icon; highlight on/off with toggle=True, emboss=True
        row.prop(
            scene_props, 
            "advanced_options", 
            icon='MODIFIER',   # Wrench icon
            text="",           # No label
            emboss=True,
            toggle=True
        )

        # The Action Selector
        row.prop(scene_props, "action", text="")

        # The Blend Mode
        if not ob.animation_data:
            ob.animation_data_create()
        row.prop(ob.animation_data, "action_blend_type", text="")

        # If advanced options are enabled, show the "Create Base layer" button below
        if scene_props.advanced_options:
            col.operator("hhp.create_base_layer", text="Create Base layer")


# Registration
classes = (
    HHP_AnimBuilder_Properties,
    HHP_OT_CreateBaseLayer,
    HHP_PT_ExperimentalAnimBuilder,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.hhp_animbuilder_props = bpy.props.PointerProperty(type=HHP_AnimBuilder_Properties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.hhp_animbuilder_props

if __name__ == "__main__":
    register()
