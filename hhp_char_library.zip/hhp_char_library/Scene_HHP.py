import bpy
from bpy.types import Panel, Operator, PropertyGroup, Menu, UIList
import os
import bpy.utils.previews
from bpy.props import StringProperty, IntProperty, EnumProperty, BoolProperty, CollectionProperty
from bpy.app.handlers import persistent

# Global variable for custom icons
scene_custom_icons = None

def get_scene_blend_files(directories):
    """Find the most recent .blend file in each top-level subfolder of the given directories.
    If recursive search is enabled in preferences, find all .blend files in the directory structure.
    Sorts according to the 'sort_by_newest' preference from addon preferences."""
    blend_files_with_time = {} # Store path and mtime
    addon_prefs = bpy.context.preferences.addons[__package__].preferences
    
    recursive_search = addon_prefs.force_recursive_search # Simplified: only use preference
    
    for directory in directories:
        abs_dir = bpy.path.abspath(directory.path)  # Convert relative path to an absolute path
        if os.path.isdir(abs_dir):
            if recursive_search:
                # Recursive search - find all blend files in directory structure
                for dirpath, dirnames, filenames in os.walk(abs_dir):
                    for filename in filenames:
                        if filename.endswith(".blend") and not filename.startswith("._"):
                            file_path = os.path.join(dirpath, filename)
                            try:
                                # Use only the filename without .blend extension as the key
                                key_name = filename.replace('.blend', '')
                                if key_name not in blend_files_with_time:
                                    blend_files_with_time[key_name] = (file_path, os.path.getmtime(file_path))
                                elif os.path.getmtime(file_path) > blend_files_with_time[key_name][1]: # Keep newest if duplicate names
                                    blend_files_with_time[key_name] = (file_path, os.path.getmtime(file_path))
                            except Exception as e:
                                print(f"Error accessing file {file_path}: {e}")
            else:
                # Standard search - only top-level subfolders
                for subfolder in os.listdir(abs_dir):
                    subfolder_path = os.path.join(abs_dir, subfolder)
                    if os.path.isdir(subfolder_path):
                        recent_file = None
                        recent_time = -1
                        for file in os.listdir(subfolder_path):
                            if file.endswith(".blend") and not file.startswith("._"):
                                file_path = os.path.join(subfolder_path, file)
                                try:
                                    file_time = os.path.getmtime(file_path)
                                    if file_time > recent_time:
                                        recent_time = file_time
                                        recent_file = file_path
                                except Exception as e:
                                    print(f"Error accessing file {file_path}: {e}")
                        if recent_file:
                            blend_files_with_time[subfolder] = (recent_file, recent_time) # Store path and mtime
    
    # Sort based on preference
    if addon_prefs.sort_scene_list_by_newest:
        # Sort by modification time (newest first), then by name for tie-breaking
        sorted_items = sorted(blend_files_with_time.items(), key=lambda item: (item[1][1], item[0].lower()), reverse=True)
    else:
        # Sort alphabetically by name (subfolder or filename key)
        sorted_items = sorted(blend_files_with_time.items(), key=lambda item: item[0].lower())

    # Reconstruct blend_files dictionary with only names and paths for compatibility with load_scene_thumbnails
    blend_files = {name: path for name, (path, mtime) in sorted_items}
    return blend_files

def load_scene_thumbnails(blend_files):
    """Load thumbnails for scene blend files (from thumbnail.png/jpg/jpeg or the .blend itself)."""
    global scene_custom_icons
    if scene_custom_icons is None:
        scene_custom_icons = bpy.utils.previews.new()
    
    thumbnails = {}
    for subfolder, file_path in blend_files.items():
        try:
            blend_dir = os.path.dirname(file_path)
            
            # Check for thumbnail files in different formats
            thumbnail_found = False
            for ext in ['.png', '.jpg', '.jpeg']:
                thumbnail_path = os.path.join(blend_dir, f'thumbnail{ext}')
                if os.path.isfile(thumbnail_path):
                    thumb = scene_custom_icons.load(file_path, thumbnail_path, 'IMAGE')
                    thumbnails[file_path] = thumb
                    thumbnail_found = True
                    break
            
            # Fall back to using the blend file itself if no thumbnail image was found
            if not thumbnail_found:
                thumb = scene_custom_icons.load(file_path, file_path, 'BLEND')
                thumbnails[file_path] = thumb
                
        except Exception as e:
            print(f"Error loading thumbnail for {file_path}: {e}")
    
    return thumbnails

# PropertyGroup for collection items
class SceneCollectionItem(PropertyGroup):
    name: StringProperty(name="Collection Name")
    is_selected: BoolProperty(name="Selected", default=False)

# UI List for available collections
class SCENE_UL_AvailableCollections(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.label(text=item.name)

# UI List for selected collections
class SCENE_UL_SelectedCollections(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.label(text=item.name)

def _append_and_assign_world_from_first_scene(filepath: str, context, report):
    """
    Append the first scene from a .blend only to retrieve its world, then set it as active.
    This is used to mimic the ROOT_COLLECTION behavior for world assignment, even when the
    user is appending specific collections.
    """
    abs_path = bpy.path.abspath(filepath)
    if not abs_path or not os.path.isfile(abs_path):
        report({'ERROR'}, "Selected file does not exist")
        return False

    original_scenes = set(bpy.data.scenes.keys())
    original_collections = set(bpy.data.collections.keys())
    original_worlds = set(bpy.data.worlds.keys())

    temp_scene = None
    world_from_scene = None

    try:
        with bpy.data.libraries.load(abs_path, link=False) as (data_from, data_to):
            if data_from.scenes:
                data_to.scenes = [data_from.scenes[0]]
            else:
                data_to.scenes = []

        new_scenes = [s for s in bpy.data.scenes if s.name not in original_scenes]
        temp_scene = new_scenes[0] if new_scenes else None
        world_from_scene = temp_scene.world if temp_scene else None

        # Remove the temporary scene immediately (we only needed it to discover the world)
        if temp_scene:
            bpy.data.scenes.remove(temp_scene)

        # Best-effort cleanup: remove any newly created, now-unused collections from the temp scene append
        # (important so SELECT_COLLECTIONS doesn't leave extra imported hierarchy behind).
        # We only remove collections that are both NEW and unused (users==0).
        # Do multiple passes to handle parent/child ordering.
        for _ in range(3):
            removed_any = False
            for col in list(bpy.data.collections):
                if col.name in original_collections:
                    continue
                if col.users == 0:
                    try:
                        bpy.data.collections.remove(col, do_unlink=True)
                        removed_any = True
                    except Exception:
                        pass
            if not removed_any:
                break

        # Ensure newly appended worlds are kept (and match ROOT_COLLECTION behavior)
        for world_item in bpy.data.worlds:
            world_item.use_fake_user = True

        # Set the world from the file's first scene as active, if we found one
        if world_from_scene:
            actual_world = bpy.data.worlds.get(world_from_scene.name)
            if actual_world:
                context.scene.world = actual_world
                report({'INFO'}, f"World '{actual_world.name}' from appended scene set as active.")
                return True
            report({'WARNING'}, f"Could not find world '{world_from_scene.name}' in bpy.data.worlds to set as active.")
            return False

        # If we couldn't discover a specific world, still report whether any worlds were appended.
        new_world_names = [w for w in bpy.data.worlds.keys() if w not in original_worlds]
        if new_world_names:
            report({'INFO'}, f"Appended {len(new_world_names)} world(s), but couldn't detect which one is used by the file's first scene.")
            return True

        report({'INFO'}, "No specific world was found in the file's first scene.")
        return True

    except Exception as e:
        report({'WARNING'}, f"Could not append world: {e}")
        return False

class WM_OT_AppendSceneFromDirectory(Operator):
    bl_idname = 'wm.append_scene_from_directory'
    bl_label = 'Refresh Scene List'
    bl_description = 'Refresh the list of scene blend files from the directories'
    thumbnails = None
    
    def execute(self, context):
        # Get addon preferences
        addon_prefs = context.preferences.addons[__package__].preferences
        
        # Get blend files - this function now handles sorting based on preferences
        scene_blend_files = get_scene_blend_files(addon_prefs.scene_directories)
        
        # Clear existing icons
        global scene_custom_icons
        scene_custom_icons.clear()
        
        self.thumbnails = load_scene_thumbnails(scene_blend_files)
        
        # The scene_blend_files is already sorted by get_scene_blend_files
        # No need to sort again here.
        
        # Clear the current blend file list
        context.scene.scene_blend_file_list.clear()
        
        # Add blend files to the list (iterating over the sorted dict)
        for subfolder, file_path in scene_blend_files.items():
            icon_id = self.thumbnails[file_path].icon_id if file_path in self.thumbnails else 0
            display_name = subfolder
            new_item = context.scene.scene_blend_file_list.add()
            new_item.name = display_name
            new_item.file_path = file_path
            new_item.icon_id = icon_id
        
        # Select the first item if available
        if context.scene.scene_blend_file_list:
            context.scene.scene_blend_file_list_index = 0
        
        return {'FINISHED'}

class WM_OT_OpenSceneBlendFile(Operator):
    bl_idname = 'wm.open_scene_blend_file'
    bl_label = 'Open Scene File'
    bl_description = 'Open the selected scene blend file'
    filepath: StringProperty(subtype="FILE_PATH")
    
    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)
    
    def execute(self, context):
        # Check if the file exists
        if not os.path.isfile(self.filepath):
            self.report({'ERROR'}, "File does not exist: " + self.filepath)
            return {'CANCELLED'}
        
        # Open the blend file
        bpy.ops.wm.open_mainfile(filepath=self.filepath)
        return {'FINISHED'}


class WM_OT_AppendSceneFromFile(Operator):
    bl_idname = "wm.append_scene_from_file"
    bl_label = "Append from file"
    bl_description = "This allows you to freely pick a file not listed in the directory to append from"
    bl_options = {'REGISTER'}

    filepath: StringProperty(
        name="Blend File",
        description="Pick a .blend file to append from",
        subtype="FILE_PATH",
        default="",
    )
    filter_glob: StringProperty(default="*.blend", options={'HIDDEN'})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if not self.filepath:
            return {'CANCELLED'}

        abs_path = bpy.path.abspath(self.filepath)
        if not os.path.isfile(abs_path):
            self.report({'ERROR'}, "Selected file does not exist")
            return {'CANCELLED'}

        if not abs_path.lower().endswith(".blend"):
            self.report({'ERROR'}, "Please select a .blend file")
            return {'CANCELLED'}

        # Use the existing fallback append popup for scenes
        bpy.ops.wm.append_scene_options('INVOKE_DEFAULT', filepath=abs_path)
        return {'FINISHED'}

# Collection selection operators
class WM_OT_AddAllCollections(Operator):
    bl_idname = 'wm.add_all_collections'
    bl_label = 'Add All'
    bl_description = 'Add all available collections to the selection'
    
    def execute(self, context):
        # Clear existing selection
        context.scene.scene_selected_collections.clear()
        
        # Add all collections from available
        for collection in context.scene.scene_available_collections:
            new_item = context.scene.scene_selected_collections.add()
            new_item.name = collection.name
        
        return {'FINISHED'}

class WM_OT_AddCollection(Operator):
    bl_idname = 'wm.add_collection'
    bl_label = 'Add >>'
    bl_description = 'Add selected collection to the selection'
    
    def execute(self, context):
        index = context.scene.scene_available_collections_index
        
        if index >= 0 and index < len(context.scene.scene_available_collections):
            collection_name = context.scene.scene_available_collections[index].name
            
            # Check if already in selected list
            for item in context.scene.scene_selected_collections:
                if item.name == collection_name:
                    return {'FINISHED'}  # Already in list
            
            # Add to selected list
            new_item = context.scene.scene_selected_collections.add()
            new_item.name = collection_name
        
        return {'FINISHED'}

class WM_OT_RemoveCollection(Operator):
    bl_idname = 'wm.remove_collection'
    bl_label = '<< Remove'
    bl_description = 'Remove selected collection from the selection'
    
    def execute(self, context):
        index = context.scene.scene_selected_collections_index
        
        if index >= 0 and index < len(context.scene.scene_selected_collections):
            context.scene.scene_selected_collections.remove(index)
            context.scene.scene_selected_collections_index = max(0, index - 1)
        
        return {'FINISHED'}

class WM_OT_RemoveAllCollections(Operator):
    bl_idname = 'wm.remove_all_collections'
    bl_label = 'Remove All'
    bl_description = 'Remove all collections from the selection'
    
    def execute(self, context):
        context.scene.scene_selected_collections.clear()
        context.scene.scene_selected_collections_index = 0
        return {'FINISHED'}

class WM_OT_AppendSceneOptions(Operator):
    bl_idname = 'wm.append_scene_options'
    bl_label = 'Append Options'
    bl_description = 'Choose what to append from the scene file'
    bl_options = {'REGISTER', 'INTERNAL'}
    
    filepath: StringProperty(subtype="FILE_PATH")
    append_world: BoolProperty(
        name="Append world",
        description="Appends all worlds from the selected file and sets the active world",
        default=True,
    )
    
    action: EnumProperty(
        items=[
            ('ROOT_COLLECTION', 'Append Root Collection', 'Append the root collection with its full hierarchy intact', 'FILE_VOLUME', 0),
            ('SELECT_COLLECTIONS', 'User Selection', 'Select specific collections to append', 'RESTRICT_SELECT_OFF', 1)
        ],
        name="Action",
        description="What to append from the scene file",
        default='ROOT_COLLECTION'  # Set root collection as the default option
    )
    
    def invoke(self, context, event):
        # Clear previous collections lists
        context.scene.scene_available_collections.clear()
        context.scene.scene_selected_collections.clear()
        
        # Populate available collections list from the blend file
        if os.path.exists(self.filepath):
            with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
                for name in data_from.collections:
                    item = context.scene.scene_available_collections.add()
                    item.name = name
        
        # Increase dialog width to provide more space for the collection selection UI
        return context.window_manager.invoke_props_dialog(self, width=500)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Specified collection names not found in file.")
        layout.label(text="What would you like to append?")
        layout.prop(self, "append_world")
        layout.prop(self, "action", expand=True)
        
        # Show collection selection UI when SELECT_COLLECTIONS is selected
        if self.action == 'SELECT_COLLECTIONS':
            # Add some spacing
            layout.separator()
            
            # Two-column layout for collections
            row = layout.row()
            
            # Left column: Available collections
            left_col = row.column()
            left_col.label(text=f"Available Collections: {len(context.scene.scene_available_collections)}")
            button_row = left_col.row(align=True)
            button_row.operator('wm.add_all_collections', text="Add All")
            button_row.operator('wm.add_collection', text="Add >>")
            left_col.template_list(
                "SCENE_UL_AvailableCollections", "", 
                context.scene, "scene_available_collections", 
                context.scene, "scene_available_collections_index", 
                rows=9
            )
            
            # Right column: Selected collections
            right_col = row.column()
            right_col.label(text=f"Selected Collections: {len(context.scene.scene_selected_collections)}")
            button_row = right_col.row(align=True)
            button_row.operator('wm.remove_collection', text="<< Remove")
            button_row.operator('wm.remove_all_collections', text="Remove All")
            right_col.template_list(
                "SCENE_UL_SelectedCollections", "", 
                context.scene, "scene_selected_collections", 
                context.scene, "scene_selected_collections_index", 
                rows=9
            )
    
    def execute(self, context):
        if not self.filepath or not os.path.exists(self.filepath):
            self.report({'ERROR'}, "Selected file does not exist")
            return {'CANCELLED'}
        
        # Create a main collection to hold everything
        main_collection = None
        base_collection_name = "Scene (F)"
        collection_name = base_collection_name
        
        # Find the next available collection name with automatic numeration
        if base_collection_name in bpy.data.collections:
            counter = 1
            while True:
                numbered_name = f"{base_collection_name}.{counter:03d}"
                if numbered_name not in bpy.data.collections:
                    collection_name = numbered_name
                    break
                counter += 1
        
        # Create the collection and set its color
        main_collection = bpy.data.collections.new(collection_name)
        main_collection.color_tag = 'COLOR_08'  # Set the collection color tag
        context.scene.collection.children.link(main_collection)
        
        if self.action == 'ROOT_COLLECTION':
            # We need to append the scene to get access to its root collection
            original_scenes = set(bpy.data.scenes.keys())
            
            # Append the scene from the file
            with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
                # Just append the first scene if there are multiple
                if data_from.scenes:
                    data_to.scenes = [data_from.scenes[0]]
            
            # Get the newly appended scene
            new_scenes = [scene for scene in bpy.data.scenes if scene.name not in original_scenes]
            
            if not new_scenes:
                self.report({'WARNING'}, "Could not append scene from file")
                return {'CANCELLED'}
            
            appended_scene = new_scenes[0]
            
            # Make a copy of all the top-level collections in the scene's collection
            collections_to_copy = list(appended_scene.collection.children)
            objects_to_copy = list(appended_scene.collection.objects)
            world_from_appended_scene = appended_scene.world if self.append_world else None
            
            # Link all top-level collections to our main collection
            for collection in collections_to_copy:
                # Check if already linked
                if collection.name not in main_collection.children:
                    main_collection.children.link(collection)
            
            # Link all top-level objects to our main collection
            for obj in objects_to_copy:
                # Check if already linked
                if obj.name not in main_collection.objects:
                    main_collection.objects.link(obj)
            
            # Remove the temporary scene
            bpy.data.scenes.remove(appended_scene)
            
            # Switch to Object mode and deselect all
            if bpy.context.object and bpy.context.object.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            
            # Select all objects in the appended collections and loose objects
            for collection in collections_to_copy:
                for obj in collection.all_objects:
                    obj.select_set(True)
            for obj in objects_to_copy:
                obj.select_set(True)
            
            self.report({'INFO'}, f"Appended {len(collections_to_copy)} collections and {len(objects_to_copy)} loose objects to '{collection_name}'")

            if self.append_world:
                # Flag all worlds as fake users (covers pre-existing and newly imported from the temp scene)
                for world_item in bpy.data.worlds:
                    world_item.use_fake_user = True
                self.report({'INFO'}, f"All {len(bpy.data.worlds)} current worlds flagged as fake user.")

                # Set the world from the appended scene as active, if it exists
                if world_from_appended_scene:
                    # Ensure it's the actual world object from bpy.data.worlds
                    actual_world = bpy.data.worlds.get(world_from_appended_scene.name)
                    if actual_world:
                        context.scene.world = actual_world
                        self.report({'INFO'}, f"World '{actual_world.name}' from appended scene set as active.")
                    else:
                        self.report({'WARNING'}, f"Could not find world '{world_from_appended_scene.name}' in bpy.data.worlds to set as active.")
                else:
                    self.report({'INFO'}, "No specific world was part of the appended scene data to set as active.")
            
        else:  # 'SELECT_COLLECTIONS'
            # Check if any collections are selected
            if len(context.scene.scene_selected_collections) == 0:
                self.report({'WARNING'}, "No collections selected")
                return {'CANCELLED'}
            
            # Get the collection names to append
            collection_names = [item.name for item in context.scene.scene_selected_collections]
            
            # Append the selected collections
            with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
                data_to.collections = [name for name in data_from.collections if name in collection_names]
            
            # Link appended collections to the main collection
            for collection in data_to.collections:
                if collection is not None:
                    main_collection.children.link(collection)
            
            # Switch to Object mode and deselect all
            if bpy.context.object and bpy.context.object.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            
            # Select all objects in the appended collections
            for collection in data_to.collections:
                if collection is not None:
                    for obj in collection.all_objects:
                        obj.select_set(True)
            
            self.report({'INFO'}, f"Appended {len(data_to.collections)} selected collections to '{collection_name}'")

            # Optional: append + assign the world like ROOT_COLLECTION does
            if self.append_world:
                _append_and_assign_world_from_first_scene(self.filepath, context, self.report)
        
        return {'FINISHED'}

class WM_OT_AppendSelectedCollections(Operator):
    bl_idname = 'wm.append_selected_collections'
    bl_label = 'Select Collections to Append'
    bl_description = 'Select specific collections to append from the blend file'
    bl_options = {'REGISTER', 'INTERNAL'}
    
    filepath: StringProperty(subtype="FILE_PATH")
    
    def invoke(self, context, event):
        # Clear previous collections lists
        context.scene.scene_available_collections.clear()
        context.scene.scene_selected_collections.clear()
        
        # Populate available collections list from the blend file
        with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
            for name in data_from.collections:
                item = context.scene.scene_available_collections.add()
                item.name = name
        
        return context.window_manager.invoke_props_dialog(self, width=600)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Select Collections to Append:")
        
        # Two-column layout
        row = layout.row()
        
        # Left column: Available collections
        left_col = row.column()
        left_col.label(text=f"Available Collections ({len(context.scene.scene_available_collections)})")
        button_row = left_col.row(align=True)
        button_row.operator('wm.add_all_collections', text="Add All", icon='IMPORT')
        button_row.operator('wm.add_collection', text="Add →", icon='FORWARD')
        left_col.template_list(
            "SCENE_UL_AvailableCollections", "", 
            context.scene, "scene_available_collections", 
            context.scene, "scene_available_collections_index", 
            rows=10
        )
        
        # Right column: Selected collections
        right_col = row.column()
        right_col.label(text=f"Selected Collections ({len(context.scene.scene_selected_collections)})")
        button_row = right_col.row(align=True)
        button_row.operator('wm.remove_collection', text="← Remove", icon='BACK')
        button_row.operator('wm.remove_all_collections', text="Remove All", icon='X')
        right_col.template_list(
            "SCENE_UL_SelectedCollections", "", 
            context.scene, "scene_selected_collections", 
            context.scene, "scene_selected_collections_index", 
            rows=10
        )
    
    def execute(self, context):
        # Check if any collections are selected
        if len(context.scene.scene_selected_collections) == 0:
            self.report({'WARNING'}, "No collections selected")
            return {'CANCELLED'}
        
        # Create a main collection to hold everything
        main_collection = None
        base_collection_name = "Scene (F)"
        collection_name = base_collection_name
        
        # Find the next available collection name with automatic numeration
        if base_collection_name in bpy.data.collections:
            counter = 1
            while True:
                numbered_name = f"{base_collection_name}.{counter:03d}"
                if numbered_name not in bpy.data.collections:
                    collection_name = numbered_name
                    break
                counter += 1
        
        # Create the collection and set its color
        main_collection = bpy.data.collections.new(collection_name)
        main_collection.color_tag = 'COLOR_08'  # Set the collection color tag
        context.scene.collection.children.link(main_collection)
        
        # Get the collection names to append
        collection_names = [item.name for item in context.scene.scene_selected_collections]
        
        # Append the selected collections
        with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
            data_to.collections = [name for name in data_from.collections if name in collection_names]
        
        # Link appended collections to the main collection
        for collection in data_to.collections:
            if collection is not None:
                main_collection.children.link(collection)
        
        # Switch to Object mode and deselect all
        if bpy.context.object and bpy.context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        
        # Select all objects in the appended collections
        for collection in data_to.collections:
            if collection is not None:
                for obj in collection.all_objects:
                    obj.select_set(True)
        
        self.report({'INFO'}, f"Appended {len(data_to.collections)} collections to '{collection_name}'")
        return {'FINISHED'}

class WM_OT_AppendSelectedScene(Operator):
    bl_idname = 'wm.append_selected_scene'
    bl_label = 'Append Selected Scene'
    bl_description = 'Append collections from the selected scene file'
    filepath: StringProperty(subtype="FILE_PATH")
    
    def execute(self, context):
        # Check if the file exists
        if not self.filepath or not os.path.exists(self.filepath):
            self.report({'ERROR'}, "Selected file does not exist")
            return {'CANCELLED'}
        
        # NEW: Check if bypass is enabled
        if context.scene.scene_bypass_collection:
            bpy.ops.wm.append_scene_options('INVOKE_DEFAULT', filepath=self.filepath)
            return {'FINISHED'}
        
        # Get the collection names from preferences
        addon_prefs = context.preferences.addons[__package__].preferences
        collection_names = [item.name for item in addon_prefs.scene_collection_names]
        
        if not collection_names:
            # If no collection names are defined, show the popup menu
            bpy.ops.wm.append_scene_options('INVOKE_DEFAULT', filepath=self.filepath)
            return {'FINISHED'}
        
        # Check what collections are available in the file
        available_collections = []
        with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
            # Get collections that match our collection names
            available_collections = [name for name in data_from.collections if name in collection_names]
        
        if not available_collections:
            # If no matching collections found, show the popup menu
            bpy.ops.wm.append_scene_options('INVOKE_DEFAULT', filepath=self.filepath)
            return {'FINISHED'}
        
        # Append the collections
        appended_collections = []
        
        with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
            data_to.collections = available_collections
        
        # Link the collections to the scene
        existing_collection_names = [c.name for c in context.scene.collection.children]
        for collection in data_to.collections:
            # Check if the collection is already linked by name instead of by object reference
            if collection.name not in existing_collection_names:
                context.scene.collection.children.link(collection)
                appended_collections.append(collection)
        
        # Switch to Object mode and deselect all
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        
        # Select all objects in the appended collections
        for collection in appended_collections:
            for obj in collection.all_objects:
                obj.select_set(True)
        
        self.report({'INFO'}, f"Appended {len(appended_collections)} collections from {os.path.basename(self.filepath)}")

        # Append world from the same file
        # First, flag all *existing* worlds as fake users
        for world_item in bpy.data.worlds:
            world_item.use_fake_user = True
        if bpy.data.worlds:
            self.report({'INFO'}, f"Flagged {len(bpy.data.worlds)} existing world(s) as fake user.")

        original_world_names = set(w.name for w in bpy.data.worlds)
        worlds_appended_count = 0
        newly_appended_world = None

        try:
            with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
                data_to.worlds = data_from.worlds
            
            for world in data_to.worlds:
                if world and world.name not in original_world_names:
                    world.use_fake_user = True # Ensure newly appended are also flagged
                    worlds_appended_count += 1
                    if newly_appended_world is None:
                        newly_appended_world = world # Keep track of the first new world
            
            if newly_appended_world:
                context.scene.world = newly_appended_world
                self.report({'INFO'}, f"Appended {worlds_appended_count} world(s). '{newly_appended_world.name}' set as active.")
            elif worlds_appended_count > 0:
                 self.report({'INFO'}, f"Appended {worlds_appended_count} world(s), but none were newly unique to set as active.")
            else:
                self.report({'INFO'}, "No new worlds found in the file to append.")

        except Exception as e:
            self.report({'WARNING'}, f"Could not append worlds: {e}")

        return {'FINISHED'}

class WM_OT_AppendWorldFromScene(Operator):
    bl_idname = 'wm.append_world_from_scene'
    bl_label = 'Append World'
    bl_description = 'Append all worlds from the selected scene file, flag them as fake users, and set as active'
    filepath: StringProperty(subtype="FILE_PATH")
    
    def execute(self, context):
        # Check if the file exists
        if not self.filepath or not os.path.exists(self.filepath):
            self.report({'ERROR'}, "Selected file does not exist")
            return {'CANCELLED'}
        
        # Flag all existing worlds as fake users to prevent them from being deleted
        for world in bpy.data.worlds:
            world.use_fake_user = True
        
        # Store original world names
        original_world_names = set(bpy.data.worlds.keys())
        
        # Append the worlds
        with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
            data_to.worlds = data_from.worlds
        
        # Get newly added worlds and flag them as fake users
        new_worlds = [world for world in bpy.data.worlds if world.name not in original_world_names]
        
        for world in new_worlds:
            world.use_fake_user = True
        
        # Set the first new world as active if any were appended
        if new_worlds:
            context.scene.world = new_worlds[0]
            self.report({'INFO'}, f"Appended {len(new_worlds)} worlds from {os.path.basename(self.filepath)}. '{new_worlds[0].name}' set as active.")
        else:
            self.report({'INFO'}, f"No worlds found in {os.path.basename(self.filepath)}")
        
        return {'FINISHED'}

class HHP_OT_OpenScenePreferences(Operator):
    bl_idname = "hhp.open_scene_preferences"
    bl_label = "Scene Preferences"
    bl_description = "Open addon preferences and switch to Scene mode"
    
    def execute(self, context):
        # Switch to scene mode first
        prefs = context.preferences.addons[__package__].preferences
        prefs.mode = 'SCENE'
        
        # Then open preferences
        bpy.ops.preferences.addon_show(module=__package__)
        return {'FINISHED'}

class SCENE_HHP_PT_Panel(bpy.types.Panel):
    bl_label = "Scene (HHP)"
    bl_idname = "SCENE_HHP_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'
    bl_order = 35  # This will place it after Animation (30) but before Creator Tools (50)
    bl_options = {'DEFAULT_CLOSED'}
    bl_ui_units_x = 30  # Make panel wider
    
    def draw(self, context):
        layout = self.layout
        addon_prefs = context.preferences.addons[__package__].preferences
        
        # Check if scene directories are set up
        if not any(directory.path.strip() for directory in addon_prefs.scene_directories):
            warning_box = layout.box()
            warning_box.alert = True
            warning_box.label(text="Please select scene directories", icon='ERROR')
            col = warning_box.column(align=True)
            # Use our custom operator to switch to scene mode in preferences
            col.operator("hhp.open_scene_preferences", text="Open scene preferences", icon='PREFERENCES')
            return
        
        # Top toggles row
        toggles_row = layout.row(align=True)
        toggles_row.alignment = 'RIGHT' # Align the whole row of toggles to the right
        
        # Add debug mode toggles (only if debug mode is enabled)
        if addon_prefs.debug_mode:
            toggles_row.prop(addon_prefs, "enable_aha", text="", icon='USER', toggle=True)
            toggles_row.prop(context.scene, "scene_bypass_collection", text="", icon='GHOST_ENABLED', toggle=True)
        
        # Sort by newest and Recursive search toggles
        toggles_row.prop(addon_prefs, "sort_scene_list_by_newest", text="", icon='SORTTIME', toggle=True)
        toggles_row.prop(addon_prefs, "force_recursive_search", text="", icon='VIEWZOOM', toggle=True)
        
        # Buttons box
        box = layout.box()
        row = box.row(align=True)
        row.operator('wm.append_scene_from_directory', text="Refresh Scene List")
        
        # Scene blend file list
        layout.template_list(
            "APPEND_UL_BlendFileList", "scene_list",
            context.scene, "scene_blend_file_list",
            context.scene, "scene_blend_file_list_index"
        )
        
        # Show selected file and buttons
        if context.scene.scene_blend_file_list_index >= 0 and context.scene.scene_blend_file_list:
            scene_file = context.scene.scene_blend_file_list[context.scene.scene_blend_file_list_index]
            
            # Show thumbnail if available
            if scene_file.icon_id > 0:
                row = layout.row()
                row.template_icon(scene_file.icon_id, scale=6)
            
            # Top buttons
            button_box = layout.box()
            
            # Create a column with align=True for compact vertical layout
            buttons_col = button_box.column(align=True)
            
            # First row - Open and Append
            buttons_row = buttons_col.row(align=True)
            # Open file button
            open_button = buttons_row.operator('wm.open_scene_blend_file', text="Open (Edit Blend)", icon='FILE_FOLDER')
            open_button.filepath = scene_file.file_path
            # Append button with icon COLLECTION_COLOR_08
            append_button = buttons_row.operator('wm.append_selected_scene', text="Append Scene", icon='COLLECTION_COLOR_08')
            append_button.filepath = scene_file.file_path
            
            # Second row - Append World (in the column, no separator)
            world_row = buttons_col.row(align=True)
            world_button = world_row.operator('wm.append_world_from_scene', text="Append World", icon='WORLD')
            world_button.filepath = scene_file.file_path
            world_row.operator('wm.append_scene_from_file', text="Append from file", icon='FILE_BLEND')
        
    def draw_header(self, context):
        self.layout.label(icon='SCENE_DATA')  # Scene icon

# Scene blend file item
class SceneBlendFileItem(PropertyGroup):
    name: StringProperty()
    file_path: StringProperty()
    icon_id: IntProperty()

@persistent
def refresh_scene_blend_file_list_handler(dummy):
    """Handler to refresh the scene list on file load"""
    try:
        bpy.ops.wm.append_scene_from_directory()
    except Exception as e:
        print("Failed to refresh scene blend file list on file load:", e)

# List View for Scene Blend Files
class APPEND_UL_BlendFileList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # Display the name with the icon
            layout.label(text=item.name, icon_value=item.icon_id)
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon_value=item.icon_id)

def register():
    global scene_custom_icons
    scene_custom_icons = bpy.utils.previews.new()
    
    bpy.utils.register_class(SceneBlendFileItem)
    bpy.utils.register_class(SceneCollectionItem)
    bpy.utils.register_class(SCENE_UL_AvailableCollections)
    bpy.utils.register_class(SCENE_UL_SelectedCollections)
    bpy.utils.register_class(WM_OT_AddAllCollections)
    bpy.utils.register_class(WM_OT_AddCollection)
    bpy.utils.register_class(WM_OT_RemoveCollection)
    bpy.utils.register_class(WM_OT_RemoveAllCollections)
    bpy.utils.register_class(WM_OT_AppendSceneFromDirectory)
    bpy.utils.register_class(WM_OT_AppendSceneOptions)
    bpy.utils.register_class(WM_OT_AppendSelectedCollections)
    bpy.utils.register_class(WM_OT_AppendSelectedScene)
    bpy.utils.register_class(WM_OT_OpenSceneBlendFile)
    bpy.utils.register_class(WM_OT_AppendSceneFromFile)
    bpy.utils.register_class(WM_OT_AppendWorldFromScene)
    bpy.utils.register_class(HHP_OT_OpenScenePreferences)
    bpy.utils.register_class(SCENE_HHP_PT_Panel)
    bpy.utils.register_class(APPEND_UL_BlendFileList)
    
    bpy.types.Scene.scene_blend_file_list = bpy.props.CollectionProperty(type=SceneBlendFileItem)
    bpy.types.Scene.scene_blend_file_list_index = bpy.props.IntProperty(name="Index for scene_blend_file_list", default=-1)
    
    # Collection selection properties
    bpy.types.Scene.scene_available_collections = bpy.props.CollectionProperty(type=SceneCollectionItem)
    bpy.types.Scene.scene_available_collections_index = bpy.props.IntProperty(name="Index for available collections", default=0)
    bpy.types.Scene.scene_selected_collections = bpy.props.CollectionProperty(type=SceneCollectionItem)
    bpy.types.Scene.scene_selected_collections_index = bpy.props.IntProperty(name="Index for selected collections", default=0)
    
    # NEW: Bypass collection names toggle (debug feature)
    bpy.types.Scene.scene_bypass_collection = bpy.props.BoolProperty(
        name="Bypass Collection",
        description="When enabled, bypasses specified collection names and directly opens the fallback append popup",
        default=False
    )
    
    # Register the file load handler to auto-refresh scene list
    bpy.app.handlers.load_post.append(refresh_scene_blend_file_list_handler)
    
    # Initial refresh of the scene list (using a timer to ensure all is registered first)
    bpy.app.timers.register(lambda: bpy.ops.wm.append_scene_from_directory(), first_interval=0.5)

def unregister():
    # Clean up custom icons
    global scene_custom_icons
    if scene_custom_icons:
        bpy.utils.previews.remove(scene_custom_icons)
        scene_custom_icons = None
    
    # Remove the file load handler
    if refresh_scene_blend_file_list_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(refresh_scene_blend_file_list_handler)
        
    del bpy.types.Scene.scene_blend_file_list_index
    del bpy.types.Scene.scene_blend_file_list
    del bpy.types.Scene.scene_bypass_collection
    del bpy.types.Scene.scene_available_collections
    del bpy.types.Scene.scene_available_collections_index
    del bpy.types.Scene.scene_selected_collections
    del bpy.types.Scene.scene_selected_collections_index
    
    bpy.utils.unregister_class(APPEND_UL_BlendFileList)
    bpy.utils.unregister_class(SCENE_HHP_PT_Panel)
    bpy.utils.unregister_class(HHP_OT_OpenScenePreferences)
    bpy.utils.unregister_class(WM_OT_OpenSceneBlendFile)
    bpy.utils.unregister_class(WM_OT_AppendSceneFromFile)
    bpy.utils.unregister_class(WM_OT_AppendSelectedScene)
    bpy.utils.unregister_class(WM_OT_AppendSelectedCollections)
    bpy.utils.unregister_class(WM_OT_AppendSceneOptions)
    bpy.utils.unregister_class(WM_OT_AppendSceneFromDirectory)
    bpy.utils.unregister_class(WM_OT_RemoveAllCollections)
    bpy.utils.unregister_class(WM_OT_RemoveCollection)
    bpy.utils.unregister_class(WM_OT_AddCollection)
    bpy.utils.unregister_class(WM_OT_AddAllCollections)
    bpy.utils.unregister_class(SCENE_UL_SelectedCollections)
    bpy.utils.unregister_class(SCENE_UL_AvailableCollections)
    bpy.utils.unregister_class(SceneCollectionItem)
    bpy.utils.unregister_class(WM_OT_AppendWorldFromScene)
    bpy.utils.unregister_class(SceneBlendFileItem) 