"""Optional standalone Rigify runtime and generation source package."""
from . import generated_ui
