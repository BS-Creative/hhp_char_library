"""Rollback for HHP's orientation-aware digit bake; stock Rigify is unchanged."""
from importlib import import_module
import bpy

_POINT_FIELDS = ('interpolation', 'easing', 'amplitude', 'back', 'period', 'type',
                 'handle_left_type', 'handle_right_type', 'select_control_point',
                 'select_left_handle', 'select_right_handle')


def _bags(action):
    if action:
        for layer in action.layers:
            for strip in layer.strips:
                yield from strip.channelbags


def _points(curve):
    return [dict(co=tuple(point.co), handle_left=tuple(point.handle_left),
                 handle_right=tuple(point.handle_right),
                 **{name: getattr(point, name) for name in _POINT_FIELDS})
            for point in curve.keyframe_points]


def _restore_points(curve, values):
    for point in reversed(list(curve.keyframe_points)):
        curve.keyframe_points.remove(point, fast=True)
    curve.keyframe_points.add(len(values))
    for point, value in zip(curve.keyframe_points, values):
        point.co = value['co']
        for name in _POINT_FIELDS:
            setattr(point, name, value[name])
        point.handle_left = value['handle_left']
        point.handle_right = value['handle_right']
    curve.update()
    # Preserve authored handle coordinates, including custom AUTO handles.
    for point, value in zip(curve.keyframe_points, values):
        point.handle_left = value['handle_left']
        point.handle_right = value['handle_right']


def execute(operator, context):
    module, item, ik = operator._hhp_digit
    core = import_module(module.__package__ + '.hhp_rigify')
    arm = context.active_object
    pose = core._state(arm)
    frame, subframe = context.scene.frame_current, context.scene.frame_subframe
    owners = {}
    for owner in (arm, arm.data):
        ad = owner.animation_data
        owners[owner] = (ad.action if ad else None, ad.action_slot if ad else None,
                         {key: owner[key] for key in (core._PAUSE_ACTION, core._PAUSE_STATE) if key in owner})
    flags = {name: getattr(arm.data, name) for name in (
        'hhp_ragdoll_enabled', 'hhp_ragdoll_bake_enabled', 'hhp_ragdoll_keys_enabled',
        'hhp_ragdoll_pose_override') if hasattr(arm.data, name)}
    mute_state = [(curve, curve.mute) for curve in arm.animation_data.drivers]
    constraints = [(con, con.mute, con.influence) for pb in arm.pose.bones for con in pb.constraints]
    action = arm.animation_data.action
    bags = list(_bags(action))
    original_curves = {curve.as_pointer() for bag in bags for curve in bag.fcurves}
    original_groups = {bag.as_pointer(): {group.as_pointer() for group in bag.groups} for bag in bags}
    receiving = set(module.digit_key_bones(arm, item, ik))
    prefixes = tuple(arm.pose.bones[name].path_from_id() for name in receiving)
    snapshots = [(curve, _points(curve), curve.group) for bag in bags for curve in bag.fcurves
                 if any(curve.data_path.startswith(prefix + suffix) for prefix in prefixes for suffix in ('.', '['))]

    def restore():
        # Original curves are retained throughout application. Remove only
        # curves created by this attempt, then restore keys in-place.
        for bag in _bags(action):
            for curve in list(bag.fcurves):
                if curve.as_pointer() not in original_curves:
                    bag.fcurves.remove(curve)
        for curve, points, group in snapshots:
            _restore_points(curve, points)
            if curve.group != group:
                curve.group = group
        for bag in _bags(action):
            for group in list(bag.groups):
                if group.as_pointer() not in original_groups.get(bag.as_pointer(), set()):
                    bag.groups.remove(group)
        for owner, (original_action, slot, paused) in owners.items():
            ad = owner.animation_data
            if ad:
                if ad.action is not None:
                    ad.action_slot = None
                ad.action = original_action
                if original_action is not None:
                    ad.action_slot = slot
            for key in (core._PAUSE_ACTION, core._PAUSE_STATE):
                if key in owner:
                    del owner[key]
        context.scene.frame_set(frame, subframe=subframe)
        core._restore(arm, pose)
        for name, value in flags.items():
            setattr(arm.data, name, value)
        for owner, (_, _, paused) in owners.items():
            for key, value in paused.items():
                owner[key] = value
        for curve, muted in mute_state:
            curve.mute = muted
        for con, muted, influence in constraints:
            con.mute, con.influence = muted, influence
        core.update(arm)
        core.refresh_visibility(arm)

    try:
        operator.bake_init(context)
        curves = operator.execute_scan_curves(context, arm)
        if operator.report_bake_empty():
            restore()
            return {'CANCELLED'}
        operator.bake_save_state(context)
        bake_range, raw_range = operator.bake_clean_curves_in_range(context, curves)
        operator.execute_before_apply(context, arm, bake_range, raw_range)
        for current_frame in operator.bake_frames:
            context.scene.frame_set(current_frame)
            operator.apply_frame_state(context, arm, operator.bake_state.get(current_frame))
        context.scene.frame_set(operator.bake_current_frame)
    except Exception as exc:
        restore()
        operator.report({'ERROR'}, 'Digit bake was cancelled and restored: ' + str(exc))
        return {'CANCELLED'}
    # Delete empty receiving curves only after every fallible bake step passed.
    # Unrelated empty curves and their groups remain untouched.
    for bag in _bags(action):
        for curve in list(bag.fcurves):
            if curve.is_empty and any(curve.data_path.startswith(prefix + suffix)
                                     for prefix in prefixes for suffix in ('.', '[')):
                bag.fcurves.remove(curve)
    action.update_tag()
    return {'FINISHED'}
