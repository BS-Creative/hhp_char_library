"""Scope Rigify's authoring RNA to generation without enabling its add-on.

The vendored engine remains in this package's private Python namespace. Existing
registered Rigify authoring RNA is reused with its owning engine when enabled;
otherwise only temporary authoring properties/classes are registered. No menus,
global Rigify operators, user preferences, or external feature sets are installed.
"""
from contextlib import contextmanager
from importlib import import_module
from types import SimpleNamespace
import bpy


def _interface(engine):
    return SimpleNamespace(Generator=engine.generate.Generator,
        BaseGenerator=engine.base_generate.BaseGenerator,
        SuperFingerRig=import_module(engine.__name__ + '.rigs.limbs.super_finger').Rig)


@contextmanager
def _defer_generated_ui(engine):
    # The HHP builder replaces the intermediate script with its trusted stable
    # package. Registering random-ID UI here would leave duplicate panels and
    # replace the stable UI's shared RNA. Still let Rigify produce the source.
    template = engine.rig_ui_template
    had_exec = 'exec' in template.__dict__
    previous = template.__dict__.get('exec')
    template.exec = lambda source, namespace: None
    try:
        yield _interface(engine)
    finally:
        if had_exec:
            template.exec = previous
        else:
            del template.exec


@contextmanager
def generation_context():
    if hasattr(bpy.types.PoseBone, 'rigify_parameters'):
        # Shared authoring RNA belongs to the enabled external add-on. Do not
        # overwrite or remove its definitions, parameters, classes or handlers.
        engine = import_module('rigify')
        with _defer_generated_ui(engine) as interface:
            yield interface
        return
    stores = (bpy.types.PoseBone, bpy.types.Armature, bpy.types.WindowManager,
              bpy.types.BoneCollection, bpy.types.Object)
    before = {store: set(store.bl_rna.properties.keys()) for store in stores}
    handlers = list(bpy.app.handlers.load_post)
    engine_name = __package__ + '.vendor.rigify'
    engine = None
    registered = []
    try:
        engine = import_module(engine_name)
        action_layers = import_module(engine.__name__ + '.operators.action_layers')
        for cls in (engine.RigifyName, engine.RigifyParameters,
                    engine.RigifyBoneCollectionReference, engine.RigifyColorSet,
                    engine.RigifySelectionColors, action_layers.ActionSlot):
            # Distinct RNA identifiers prevent collisions with unrelated classes.
            if not cls.__name__.startswith('HHPCompat_'):
                cls.__name__ = 'HHPCompat_' + cls.__name__
            bpy.utils.register_class(cls)
            registered.append(cls)
        # The two use-time properties may already belong to the generated UI.
        if not hasattr(bpy.types.BoneCollection, 'rigify_ui_row'):
            bpy.types.BoneCollection.rigify_ui_row = bpy.props.IntProperty(default=0, min=0)
        if not hasattr(bpy.types.BoneCollection, 'rigify_ui_title'):
            bpy.types.BoneCollection.rigify_ui_title = bpy.props.StringProperty()
        engine.register_rna_properties()
        bpy.types.Armature.rigify_action_slots = bpy.props.CollectionProperty(
            type=action_layers.ActionSlot)
        bpy.types.Armature.rigify_active_action_slot = bpy.props.IntProperty(min=0, default=0)
        engine.register_rig_parameters()
        with _defer_generated_ui(engine) as interface:
            yield interface
    finally:
        for callback in list(bpy.app.handlers.load_post):
            if callback not in handlers and callback.__module__.startswith(engine_name):
                bpy.app.handlers.load_post.remove(callback)
        for store in reversed(stores):
            for name in set(store.bl_rna.properties.keys()) - before[store]:
                delattr(store, name)
        if engine is not None:
            engine.clear_rigify_parameters()
        for cls in reversed(registered):
            bpy.utils.unregister_class(cls)
