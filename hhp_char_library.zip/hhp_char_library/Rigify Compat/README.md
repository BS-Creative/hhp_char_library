# Rigify Compat

This optional folder provides HHP's generated Rigify controls, snapping operators,
and the Rigify generation engine. No separately enabled or installed Rigify add-on
is required. Blender's native bone constraints continue to evaluate existing rigs.

Keep this folder intact to retain all Rigify tools. Removing it or emptying it
leaves HHP Char Library's native Daz tools, Clear Pose, proportions, and ragdoll
available. You can still return an existing Rigify character to Daz mode. Restore
the folder to use Rigify matching, snapping, and generation again.

## Included source and license

- Rigify 0.6.10 from the official Blender 5.1.2 distribution.
- Copyright Blender Foundation and the authors named in each source file.
- GPL-2.0-or-later; the complete license is included in `COPYING`.
- Upstream project: <https://projects.blender.org/blender/blender-addons>.
- `SOURCE.json` records every included upstream source hash. The only vendor
  modifications convert absolute `rigify` imports into relative imports and guard
  four shared bake-property declarations so this private package does not replace
  another installed Rigify add-on or its property definitions.
- `generated_ui.py` is the Rigify-generated UI for HHP's topology, with stable
  operator identifiers, ownership-safe registration, and pose-aware digit snaps.
  `bake_transaction.py` restores receiving curves and posing state if an adapted
  digit bake fails. `generation.py` is HHP's
  adapter that scopes the author's RNA properties to a build operation.

Generation loads its engine only when requested. It does not enable an add-on,
save preferences, execute saved `.blend` Text blocks, or install Rigify's menus.
If the separate Rigify add-on is already enabled, generation respects its existing
authoring properties and uses that owning engine instead of replacing them.
