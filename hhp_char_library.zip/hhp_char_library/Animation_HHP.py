import bpy
from .modules import facs_shapekey_editor
from .modules import import_facs_csv
from .modules import export_facs_csv
from .modules import export_facs_json

# Create a menu class for the FACS import dropdown
class HHP_MT_import_facs_menu(bpy.types.Menu):
    bl_label = "Import from"
    bl_idname = "HHP_MT_import_facs_menu"
    
    def draw(self, context):
        layout = self.layout
        layout.operator("hhp.import_facs_json", text="JSON File - Nvidia Omniverse Audio2Face", icon='SHAPEKEY_DATA')
        layout.operator("hhp.import_facs_csv", text="CSV File - Live Link Face (iPhone App)", icon='FILE_TEXT')

# Create a menu class for the FACS export dropdown
class HHP_MT_export_facs_menu(bpy.types.Menu):
    bl_label = "Export to"
    bl_idname = "HHP_MT_export_facs_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("hhp.export_facs_json", text="JSON File", icon='SHAPEKEY_DATA')
        layout.operator("hhp.export_facs_csv", text="CSV File", icon='FILE_TEXT')


class ANIMATION_HHP_PT_Panel(bpy.types.Panel):
    bl_label = "Animation (HHP)"
    bl_idname = "ANIMATION_HHP_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'
    bl_parent_id = "CHAR_HHP_PT_Panel"  # Set parent panel
    bl_order = 30  # This will place it after Optimize (15) but before Creator Tools (50)
    bl_options = {'HIDE_HEADER'}  # Hide the header
    
    @classmethod
    def poll(cls, context):
        # Only show this panel if ANIMATION is selected in the mode selector
        return context.scene.hhp_panel_mode.selected_panel == 'ANIMATION'
    
    def draw(self, context):
        layout = self.layout
        main_col = layout.column(align=True)
        
        # Facial mocap / FACS section (collapsible)
        box = main_col.box()
        header = box.row(align=True)
        header.alignment = 'LEFT'
        icon = 'TRIA_DOWN' if context.window_manager.animation_facs_expanded else 'TRIA_RIGHT'
        header.prop(context.window_manager, "animation_facs_expanded", text="", icon=icon, emboss=False, icon_only=True)
        header.prop(context.window_manager, "animation_facs_expanded", text="Facial mocap / FACS", icon='SHAPEKEY_DATA', emboss=False)
        
        if context.window_manager.animation_facs_expanded:
            # Replace the import buttons with a dropdown menu
            import_export_box = box.box()
            row = import_export_box.row()
            row.menu("HHP_MT_import_facs_menu", text="Import from", icon='IMPORT')
            row.menu("HHP_MT_export_facs_menu", text="Export to", icon='EXPORT')
            
            # Add a separator between import and editor
            box.separator()
            
            # Add FACS shapekey editor
            facs_shapekey_editor.draw_facs_editor(box, context)
        

def register():
    wm = bpy.types.WindowManager
    # Expanded by default
    wm.animation_facs_expanded = bpy.props.BoolProperty(
        name="Animation FACS Expanded",
        description="Whether the Facial mocap / FACS section is expanded",
        default=True
    )
    bpy.utils.register_class(HHP_MT_import_facs_menu)
    bpy.utils.register_class(HHP_MT_export_facs_menu)
    bpy.utils.register_class(ANIMATION_HHP_PT_Panel)
    import_facs_csv.register()
    export_facs_csv.register()
    export_facs_json.register()


def unregister():
    wm = bpy.types.WindowManager
    del wm.animation_facs_expanded
    export_facs_json.unregister()
    export_facs_csv.unregister()
    import_facs_csv.unregister()
    bpy.utils.unregister_class(ANIMATION_HHP_PT_Panel)
    bpy.utils.unregister_class(HHP_MT_export_facs_menu)
    bpy.utils.unregister_class(HHP_MT_import_facs_menu)
