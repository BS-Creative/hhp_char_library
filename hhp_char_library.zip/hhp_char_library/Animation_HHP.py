import bpy
from .modules import facs_shapekey_editor
from .modules import import_facs_csv
from .modules import export_facs_csv
from .modules import export_facs_json
from .modules import correct_mouth_shape
from .modules import hhp_bs_anim_transfer

HHP_MESH_KEY = "Genesis8Female"


def is_hhp_character_mesh(obj):
    return (
        obj is not None
        and obj.type == 'MESH'
        and obj.data is not None
        and HHP_MESH_KEY in obj.data.name
        and "Deform Proxy" not in obj.name
    )

# Create a menu class for the FACS import dropdown
class HHP_MT_import_facs_menu(bpy.types.Menu):
    bl_label = "Import from"
    bl_idname = "HHP_MT_import_facs_menu"
    
    def draw(self, context):
        layout = self.layout
        layout.operator("hhp.import_facs_json", text="JSON File - Nvidia Omniverse Audio2Face", icon='SHAPEKEY_DATA')
        layout.operator("hhp.import_facs_csv", text="CSV File - Live Link Face (iPhone App)", icon='FILE_TEXT')

# Create a menu class for the FACS export dropdown
class HHP_MT_export_facs_menu(bpy.types.Menu):
    bl_label = "Export to"
    bl_idname = "HHP_MT_export_facs_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("hhp.export_facs_json", text="JSON File", icon='SHAPEKEY_DATA')
        layout.operator("hhp.export_facs_csv", text="CSV File", icon='FILE_TEXT')


class HHP_OT_correct_mouth_shape(bpy.types.Operator):
    bl_idname = "hhp.correct_mouth_shape"
    bl_label = "Correct mouth shape"
    bl_description = "Create a corrective Smooth modifier for the active HHP character mesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return is_hhp_character_mesh(getattr(context, "object", None))

    repeat: bpy.props.IntProperty(
        name="Repeat",
        description="Number of smoothing iterations",
        default=20,
        min=1
    )

    rest_source: bpy.props.EnumProperty(
        name="Rest Source",
        description="Choose the rest source for the corrective smooth modifier",
        items=[
            ('ORCO', "Original Coords", "Use the original mesh coordinates"),
            ('BIND', "Bind at start frame", "Bind the modifier using the current deformed state at the scene's start frame")
        ],
        default='BIND'
    )

    replace_existing: bpy.props.BoolProperty(
        name="Replace existing mouth corrective",
        description="If an 'HHP Mouth Corrective' modifier already exists on this mesh, remove it and create a fresh one. If disabled, a new one will be added (e.g. .001).",
        default=True,
    )

    def invoke(self, context, event):
        # If an existing corrective is found, default to replacing it (as requested).
        obj = getattr(context, "object", None)
        if obj and obj.type == 'MESH' and any(
            mod.type == 'CORRECTIVE_SMOOTH' and "HHP Mouth Corrective" in mod.name
            for mod in obj.modifiers
        ):
            self.replace_existing = True
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        column = self.layout.column(align=True)
        column.prop(self, "repeat")
        row = column.row(align=True)
        row.prop(self, "rest_source", expand=True)
        obj = getattr(context, "object", None)
        if obj and obj.type == 'MESH' and any(
            mod.type == 'CORRECTIVE_SMOOTH' and "HHP Mouth Corrective" in mod.name
            for mod in obj.modifiers
        ):
            column.prop(self, "replace_existing")

    def execute(self, context):
        try:
            correct_mouth_shape.apply_corrective_modifier(
                context,
                self.repeat,
                self.rest_source,
                replace_existing=self.replace_existing,
            )
        except (RuntimeError, ValueError) as err:
            self.report({'ERROR'}, str(err))
            return {'CANCELLED'}
        return {'FINISHED'}


class ANIMATION_HHP_PT_Panel(bpy.types.Panel):
    bl_label = "Animation (HHP)"
    bl_idname = "ANIMATION_HHP_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'
    bl_parent_id = "CHAR_HHP_PT_Panel"  # Set parent panel
    bl_order = 30  # This will place it after Optimize (15) but before Creator Tools (50)
    bl_options = {'HIDE_HEADER'}  # Hide the header
    
    @classmethod
    def poll(cls, context):
        # Only show this panel if ANIMATION is selected in the mode selector
        return context.scene.hhp_panel_mode.selected_panel == 'ANIMATION'
    
    def draw(self, context):
        layout = self.layout
        main_col = layout.column(align=True)

        wm = context.window_manager

        # Character Swap / Anim Transfer section (collapsible)
        transfer_box = main_col.box()
        header = transfer_box.row(align=True)
        header.alignment = 'LEFT'
        icon = 'TRIA_DOWN' if wm.animation_transfer_expanded else 'TRIA_RIGHT'
        header.prop(wm, "animation_transfer_expanded", text="", icon=icon, emboss=False, icon_only=True)
        header.prop(wm, "animation_transfer_expanded", text="Character Swap / Anim Transfer", icon='MOD_DATA_TRANSFER', emboss=False)

        if wm.animation_transfer_expanded:
            body = transfer_box.column(align=True)
            selected_hhp_meshes = [
                obj for obj in getattr(context, "selected_objects", [])
                if obj.type == 'MESH' and "Genesis8Female.Shape" in obj.name
            ]
            has_required_meshes = len(selected_hhp_meshes) >= 2

            row = body.row(align=True)
            transfer_btn_row = row.row(align=True)
            transfer_btn_row.enabled = has_required_meshes
            transfer_btn_row.operator("hhp.bs_anim_transfer", text="Animation Transfer +", icon='SHADERFX')
            row.operator("hhp.correct_mouth_shape", text="Correct mouth shape", icon='MOD_SMOOTH')
        
        # Facial mocap / FACS section (collapsible)
        box = main_col.box()
        header = box.row(align=True)
        header.alignment = 'LEFT'
        icon = 'TRIA_DOWN' if wm.animation_facs_expanded else 'TRIA_RIGHT'
        header.prop(wm, "animation_facs_expanded", text="", icon=icon, emboss=False, icon_only=True)
        header.prop(wm, "animation_facs_expanded", text="Facial mocap / FACS", icon='SHAPEKEY_DATA', emboss=False)
        
        if wm.animation_facs_expanded:
            # Replace the import buttons with a dropdown menu
            import_export_box = box.box()
            row = import_export_box.row()
            row.menu("HHP_MT_import_facs_menu", text="Import from", icon='IMPORT')
            row.menu("HHP_MT_export_facs_menu", text="Export to", icon='EXPORT')
            
            # Add a separator between import and editor
            box.separator()
            
            # Add FACS shapekey editor
            facs_shapekey_editor.draw_facs_editor(box, context)
        

def register():
    wm = bpy.types.WindowManager
    # Expanded by default
    wm.animation_transfer_expanded = bpy.props.BoolProperty(
        name="Animation Transfer Expanded",
        description="Whether the Character Swap / Anim Transfer section is expanded",
        default=True
    )
    wm.animation_facs_expanded = bpy.props.BoolProperty(
        name="Animation FACS Expanded",
        description="Whether the Facial mocap / FACS section is expanded",
        default=True
    )
    bpy.utils.register_class(HHP_MT_import_facs_menu)
    bpy.utils.register_class(HHP_MT_export_facs_menu)
    bpy.utils.register_class(HHP_OT_correct_mouth_shape)
    bpy.utils.register_class(ANIMATION_HHP_PT_Panel)
    hhp_bs_anim_transfer.register()
    import_facs_csv.register()
    export_facs_csv.register()
    export_facs_json.register()


def unregister():
    wm = bpy.types.WindowManager
    del wm.animation_transfer_expanded
    del wm.animation_facs_expanded
    export_facs_json.unregister()
    export_facs_csv.unregister()
    import_facs_csv.unregister()
    bpy.utils.unregister_class(ANIMATION_HHP_PT_Panel)
    bpy.utils.unregister_class(HHP_OT_correct_mouth_shape)
    bpy.utils.unregister_class(HHP_MT_export_facs_menu)
    bpy.utils.unregister_class(HHP_MT_import_facs_menu)
    hhp_bs_anim_transfer.unregister()
