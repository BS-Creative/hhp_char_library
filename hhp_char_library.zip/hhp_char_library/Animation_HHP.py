import bpy
from .modules import facs_shapekey_editor
from .modules import import_facs_csv
from .modules import export_facs_csv
from .modules import export_facs_json
from .modules import correct_mouth_shape
from .modules import correct_eyelids_shape
from .modules import hhp_bs_anim_transfer
from .modules import heavy_tools_loader

HHP_MESH_KEY = "Genesis8Female"
MISC_DATA_PROP = "HHP_misc_data"
CORRECTIVE_BIND_FRAMES_PROP = "shape_corrective_binding_frames"


def is_hhp_character_mesh(obj):
    return (
        obj is not None
        and obj.type == 'MESH'
        and obj.data is not None
        and HHP_MESH_KEY in obj.data.name
        and "Deform Proxy" not in obj.name
    )


def get_shape_corrective_slider_entries_in_modifier_order(obj, scene):
    if obj is None or obj.type != 'MESH':
        return []

    linked_meshes = [
        linked_obj for linked_obj in scene.objects
        if linked_obj.type == 'MESH' and linked_obj.data == obj.data and linked_obj != obj
    ]
    slider_owner_candidates = [obj] + linked_meshes

    slider_entries = []
    for mod in obj.modifiers:
        if mod.type != 'CORRECTIVE_SMOOTH':
            continue

        mod_name = mod.name
        is_shape_corrective = (
            (correct_mouth_shape.MOUTH_CORRECTIVE_KEY in mod_name)
            or (correct_eyelids_shape.EYELIDS_CORRECTIVE_KEY in mod_name)
        )
        if not is_shape_corrective:
            continue

        slider_owner = next(
            (
                candidate
                for candidate in slider_owner_candidates
                if mod_name in candidate.keys() and isinstance(candidate[mod_name], (int, float))
            ),
            None,
        )
        if slider_owner:
            slider_entries.append((slider_owner, f'["{mod_name}"]', mod_name, False))
        else:
            slider_entries.append((mod, "factor", mod_name, True))

    return slider_entries


def get_linked_meshes_for_shape_corrective(obj, scene):
    if obj is None or obj.type != 'MESH':
        return []

    linked_meshes = [
        linked_obj for linked_obj in scene.objects
        if linked_obj.type == 'MESH' and linked_obj.data == obj.data and linked_obj != obj
    ]
    return [obj] + linked_meshes


def get_shape_corrective_binding_frame(obj, scene, modifier_name):
    modifier = obj.modifiers.get(modifier_name) if obj and obj.type == 'MESH' else None
    if not modifier or modifier.type != 'CORRECTIVE_SMOOTH' or modifier.rest_source != 'BIND':
        return None

    for candidate in get_linked_meshes_for_shape_corrective(obj, scene):
        misc_data = candidate.get(MISC_DATA_PROP)
        if not hasattr(misc_data, "get"):
            continue

        bind_frames = misc_data.get(CORRECTIVE_BIND_FRAMES_PROP)
        if not hasattr(bind_frames, "get"):
            continue

        frame = bind_frames.get(modifier_name)
        if frame is not None:
            return int(frame)

    return None


def get_shape_corrective_delete_entries_in_modifier_order(obj):
    if obj is None or obj.type != 'MESH':
        return []

    entries = []
    for mod in obj.modifiers:
        if mod.type != 'CORRECTIVE_SMOOTH':
            continue

        mod_name = mod.name
        if correct_mouth_shape.MOUTH_CORRECTIVE_KEY in mod_name:
            entries.append(("hhp.delete_mouth_corrective", mod_name))
        elif correct_eyelids_shape.EYELIDS_CORRECTIVE_KEY in mod_name:
            entries.append(("hhp.delete_eyelids_corrective", mod_name))

    return entries

# Create a menu class for the FACS import dropdown
class HHP_MT_import_facs_menu(bpy.types.Menu):
    bl_label = "Import from"
    bl_idname = "HHP_MT_import_facs_menu"
    
    def draw(self, context):
        layout = self.layout
        layout.operator("hhp.import_facs_json", text="JSON File - Nvidia Omniverse Audio2Face", icon='SHAPEKEY_DATA')
        layout.operator("hhp.import_facs_csv", text="CSV File - Live Link Face (iPhone App)", icon='FILE_TEXT')
        if heavy_tools_loader.is_audio_mocap_available():
            layout.separator()
            layout.operator(
                "hhp.import_facs_audio",
                text="Audio File - Audio to Mocap",
                icon='SOUND',
            )

# Create a menu class for the FACS export dropdown
class HHP_MT_export_facs_menu(bpy.types.Menu):
    bl_label = "Export to"
    bl_idname = "HHP_MT_export_facs_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("hhp.export_facs_json", text="JSON File", icon='SHAPEKEY_DATA')
        layout.operator("hhp.export_facs_csv", text="CSV File", icon='FILE_TEXT')


class HHP_OT_correct_mouth_shape(bpy.types.Operator):
    bl_idname = "hhp.correct_mouth_shape"
    bl_label = "Correct mouth shape"
    bl_description = "Create a corrective Smooth modifier for the active HHP character mesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return is_hhp_character_mesh(getattr(context, "object", None))

    repeat: bpy.props.IntProperty(
        name="Repeat",
        description="Number of smoothing iterations",
        default=20,
        min=1
    )

    rest_source: bpy.props.EnumProperty(
        name="Rest Source",
        description="Choose the rest source for the corrective smooth modifier",
        items=[
            ('ORCO', "Original Coords", "Use the original mesh coordinates"),
            ('BIND', "Bind at start frame", "Bind the modifier using the deformed state at the scene's start frame"),
            ('BIND_CURRENT', "Bind at current frame", "Bind the modifier using the current deformed state at the current frame")
        ],
        default='ORCO'
    )

    replace_existing: bpy.props.BoolProperty(
        name="Replace existing mouth corrective",
        description="If an 'HHP Mouth Corrective' modifier already exists on this mesh, remove it and create a fresh one. If disabled, a new one will be added (e.g. .001).",
        default=False,
    )

    def invoke(self, context, event):
        obj = getattr(context, "object", None)
        if obj and obj.type == 'MESH' and any(
            mod.type == 'CORRECTIVE_SMOOTH' and "HHP Mouth Corrective" in mod.name
            for mod in obj.modifiers
        ):
            self.replace_existing = False
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        column = self.layout.column(align=True)
        column.prop(self, "repeat")
        column.prop(self, "rest_source", text="")
        obj = getattr(context, "object", None)
        if obj and obj.type == 'MESH' and any(
            mod.type == 'CORRECTIVE_SMOOTH' and "HHP Mouth Corrective" in mod.name
            for mod in obj.modifiers
        ):
            column.prop(self, "replace_existing")

    def execute(self, context):
        try:
            warning = correct_mouth_shape.apply_corrective_modifier(
                context,
                self.repeat,
                self.rest_source,
                replace_existing=self.replace_existing,
            )
            if warning:
                self.report({'WARNING'}, warning)
        except (RuntimeError, ValueError) as err:
            self.report({'ERROR'}, str(err))
            return {'CANCELLED'}
        return {'FINISHED'}


class HHP_OT_delete_mouth_corrective(bpy.types.Operator):
    bl_idname = "hhp.delete_mouth_corrective"
    bl_label = "Delete Mouth Corrective"
    bl_description = "Delete the selected mouth corrective from the active mesh and all linked meshes"
    bl_options = {'REGISTER', 'UNDO'}

    modifier_name: bpy.props.StringProperty(
        name="Mouth Corrective",
        description="Name of the mouth corrective modifier to delete",
    )

    @classmethod
    def poll(cls, context):
        return is_hhp_character_mesh(getattr(context, "object", None))

    def execute(self, context):
        try:
            correct_mouth_shape.delete_corrective_modifier(context, self.modifier_name)
        except ValueError as err:
            self.report({'ERROR'}, str(err))
            return {'CANCELLED'}

        self.report({'INFO'}, f"Deleted mouth corrective: {self.modifier_name}")
        return {'FINISHED'}


class HHP_MT_delete_mouth_corrective_menu(bpy.types.Menu):
    bl_label = "Delete Mouth Corrective"
    bl_idname = "HHP_MT_delete_mouth_corrective_menu"

    def draw(self, context):
        layout = self.layout
        obj = getattr(context, "object", None)
        modifier_names = sorted(correct_mouth_shape.get_mouth_corrective_names(obj))

        if not modifier_names:
            layout.label(text="No mouth corrective modifiers found", icon='INFO')
            return

        for modifier_name in modifier_names:
            op = layout.operator(
                "hhp.delete_mouth_corrective",
                text=modifier_name,
                icon='TRASH',
            )
            op.modifier_name = modifier_name


class HHP_OT_correct_eyelids_shape(bpy.types.Operator):
    bl_idname = "hhp.correct_eyelids_shape"
    bl_label = "Correct eyelids shape"
    bl_description = "Create a corrective Smooth modifier for eyelids on the active HHP character mesh and all linked meshes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return is_hhp_character_mesh(getattr(context, "object", None))

    repeat: bpy.props.IntProperty(
        name="Repeat",
        description="Number of smoothing iterations",
        default=20,
        min=1
    )

    rest_source: bpy.props.EnumProperty(
        name="Rest Source",
        description="Choose the rest source for the corrective smooth modifier",
        items=[
            ('ORCO', "Original Coords", "Use the original mesh coordinates"),
            ('BIND', "Bind at start frame", "Bind the modifier using the deformed state at the scene's start frame"),
            ('BIND_CURRENT', "Bind at current frame", "Bind the modifier using the current deformed state at the current frame")
        ],
        default='ORCO'
    )

    replace_existing: bpy.props.BoolProperty(
        name="Replace existing eyelids corrective",
        description="If an 'HHP Eyelids Corrective' modifier already exists on this mesh, remove it and create a fresh one. If disabled, a new one will be added (e.g. .001).",
        default=False,
    )

    def invoke(self, context, event):
        obj = getattr(context, "object", None)
        if obj and obj.type == 'MESH' and any(
            mod.type == 'CORRECTIVE_SMOOTH' and "HHP Eyelids Corrective" in mod.name
            for mod in obj.modifiers
        ):
            self.replace_existing = False
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        column = self.layout.column(align=True)
        column.prop(self, "repeat")
        column.prop(self, "rest_source", text="")
        obj = getattr(context, "object", None)
        if obj and obj.type == 'MESH' and any(
            mod.type == 'CORRECTIVE_SMOOTH' and "HHP Eyelids Corrective" in mod.name
            for mod in obj.modifiers
        ):
            column.prop(self, "replace_existing")

    def execute(self, context):
        try:
            warning = correct_eyelids_shape.apply_corrective_modifier(
                context,
                self.repeat,
                self.rest_source,
                replace_existing=self.replace_existing,
            )
            if warning:
                self.report({'WARNING'}, warning)
        except (RuntimeError, ValueError) as err:
            self.report({'ERROR'}, str(err))
            return {'CANCELLED'}
        return {'FINISHED'}


class HHP_OT_delete_eyelids_corrective(bpy.types.Operator):
    bl_idname = "hhp.delete_eyelids_corrective"
    bl_label = "Delete Eyelids Corrective"
    bl_description = "Delete the selected eyelids corrective from the active mesh and all linked meshes"
    bl_options = {'REGISTER', 'UNDO'}

    modifier_name: bpy.props.StringProperty(
        name="Eyelids Corrective",
        description="Name of the eyelids corrective modifier to delete",
    )

    @classmethod
    def poll(cls, context):
        return is_hhp_character_mesh(getattr(context, "object", None))

    def execute(self, context):
        try:
            correct_eyelids_shape.delete_corrective_modifier(context, self.modifier_name)
        except ValueError as err:
            self.report({'ERROR'}, str(err))
            return {'CANCELLED'}

        self.report({'INFO'}, f"Deleted eyelids corrective: {self.modifier_name}")
        return {'FINISHED'}


class HHP_MT_delete_eyelids_corrective_menu(bpy.types.Menu):
    bl_label = "Delete Eyelids Corrective"
    bl_idname = "HHP_MT_delete_eyelids_corrective_menu"

    def draw(self, context):
        layout = self.layout
        obj = getattr(context, "object", None)
        modifier_names = sorted(correct_eyelids_shape.get_eyelids_corrective_names(obj))

        if not modifier_names:
            layout.label(text="No eyelids corrective modifiers found", icon='INFO')
            return

        for modifier_name in modifier_names:
            op = layout.operator(
                "hhp.delete_eyelids_corrective",
                text=modifier_name,
                icon='TRASH',
            )
            op.modifier_name = modifier_name


class HHP_OT_open_correct_shape_menu(bpy.types.Operator):
    bl_idname = "hhp.open_correct_shape_menu"
    bl_label = "Correct Shape"
    bl_description = "Open shape correction menu for eyelids and mouth"

    @classmethod
    def poll(cls, context):
        return is_hhp_character_mesh(getattr(context, "object", None))

    def execute(self, context):
        bpy.ops.wm.call_menu(name="HHP_MT_correct_shape_menu")
        return {'FINISHED'}


class HHP_MT_correct_shape_menu(bpy.types.Menu):
    bl_label = "Correct Shape"
    bl_idname = "HHP_MT_correct_shape_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_DEFAULT'
        layout.operator("hhp.correct_eyelids_shape", text="Eyelids", icon='MOD_SMOOTH')
        layout.operator("hhp.correct_mouth_shape", text="Mouth", icon='MOD_SMOOTH')


class HHP_OT_delete_all_shape_correctives(bpy.types.Operator):
    bl_idname = "hhp.delete_all_shape_correctives"
    bl_label = "Delete All Correctives"
    bl_description = "Delete all mouth and eyelids corrective modifiers from the active mesh and all linked meshes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return is_hhp_character_mesh(getattr(context, "object", None))

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        obj = getattr(context, "object", None)
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "The active object must be a mesh to delete correctives.")
            return {'CANCELLED'}

        mouth_names = list(correct_mouth_shape.get_mouth_corrective_names(obj))
        eyelids_names = list(correct_eyelids_shape.get_eyelids_corrective_names(obj))

        if not mouth_names and not eyelids_names:
            self.report({'WARNING'}, "No mouth or eyelids corrective modifiers found.")
            return {'CANCELLED'}

        for modifier_name in mouth_names:
            correct_mouth_shape.delete_corrective_modifier(context, modifier_name)

        for modifier_name in eyelids_names:
            correct_eyelids_shape.delete_corrective_modifier(context, modifier_name)

        self.report({'INFO'}, "Deleted all mouth and eyelids correctives")
        return {'FINISHED'}


class HHP_MT_delete_shape_corrective_menu(bpy.types.Menu):
    bl_label = "Delete Corrective"
    bl_idname = "HHP_MT_delete_shape_corrective_menu"

    def draw(self, context):
        layout = self.layout
        obj = getattr(context, "object", None)

        ordered_entries = get_shape_corrective_delete_entries_in_modifier_order(obj)

        if not ordered_entries:
            layout.label(text="No corrective modifiers found", icon='INFO')
            return

        layout.operator(
            "hhp.delete_all_shape_correctives",
            text="Delete All",
            icon='TRASH',
        )
        layout.separator()

        for operator_id, modifier_name in ordered_entries:
            op = layout.operator(operator_id, text=modifier_name, icon='TRASH')
            op.modifier_name = modifier_name


class HHP_OT_select_shape_corrective_binding_frame(bpy.types.Operator):
    bl_idname = "hhp.select_shape_corrective_binding_frame"
    bl_label = "Go to Binding Frame"
    bl_description = "Go to the frame where this bound corrective was bound"
    bl_options = {'REGISTER', 'UNDO'}

    modifier_name: bpy.props.StringProperty(
        name="Corrective",
        description="Name of the bound corrective modifier",
    )

    @classmethod
    def poll(cls, context):
        return is_hhp_character_mesh(getattr(context, "object", None))

    def execute(self, context):
        frame = get_shape_corrective_binding_frame(
            getattr(context, "object", None),
            context.scene,
            self.modifier_name,
        )
        if frame is None:
            self.report({'WARNING'}, f"No binding frame saved for '{self.modifier_name}'.")
            return {'CANCELLED'}

        context.scene.frame_set(frame)
        self.report({'INFO'}, f"Selected binding frame {frame} for {self.modifier_name}")
        return {'FINISHED'}


class ANIMATION_HHP_PT_Panel(bpy.types.Panel):
    bl_label = "Animation (HHP)"
    bl_idname = "ANIMATION_HHP_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'
    bl_parent_id = "CHAR_HHP_PT_Panel"  # Set parent panel
    bl_order = 30  # This will place it after Optimize (15) but before Creator Tools (50)
    bl_options = {'HIDE_HEADER'}  # Hide the header
    
    @classmethod
    def poll(cls, context):
        # Only show this panel if ANIMATION is selected in the mode selector
        return context.scene.hhp_panel_mode.selected_panel == 'ANIMATION'
    
    def draw(self, context):
        layout = self.layout
        main_col = layout.column(align=True)

        wm = context.window_manager

        # Character Swap / Anim Transfer section (collapsible)
        transfer_box = main_col.box()
        header = transfer_box.row(align=True)
        header.alignment = 'LEFT'
        icon = 'TRIA_DOWN' if wm.animation_transfer_expanded else 'TRIA_RIGHT'
        header.prop(wm, "animation_transfer_expanded", text="", icon=icon, emboss=False, icon_only=True)
        header.prop(wm, "animation_transfer_expanded", text="Character Swap / Anim Transfer", icon='MOD_DATA_TRANSFER', emboss=False)

        if wm.animation_transfer_expanded:
            body = transfer_box.column(align=True)
            selected_hhp_meshes = [
                obj for obj in getattr(context, "selected_objects", [])
                if obj.type == 'MESH' and "Genesis8Female.Shape" in obj.name
            ]
            has_required_meshes = len(selected_hhp_meshes) >= 2

            row = body.row(align=True)
            transfer_btn_row = row.row(align=True)
            transfer_btn_row.enabled = has_required_meshes
            transfer_btn_row.operator("hhp.bs_anim_transfer", text="Animation Transfer +", icon='SHADERFX')

            shape_col = row.column(align=True)
            shape_col.operator("hhp.open_correct_shape_menu", text="Correct Shape", icon='MOD_SMOOTH')

            active_obj = getattr(context, "object", None)
            if is_hhp_character_mesh(active_obj):
                mouth_modifier_names = correct_mouth_shape.get_mouth_corrective_names(active_obj)
                eyelids_modifier_names = correct_eyelids_shape.get_eyelids_corrective_names(active_obj)
                if mouth_modifier_names or eyelids_modifier_names:
                    shape_col.menu(
                        "HHP_MT_delete_shape_corrective_menu",
                        text="Delete Corrective",
                        icon='TRASH',
                    )

                for slider_owner, property_path, slider_name, is_legacy_slider in get_shape_corrective_slider_entries_in_modifier_order(active_obj, context.scene):
                    slider_row = shape_col.row(align=True)
                    slider_row.alert = is_legacy_slider
                    slider_row.prop(slider_owner, property_path, text=slider_name, slider=True)
                    if get_shape_corrective_binding_frame(active_obj, context.scene, slider_name) is not None:
                        op = slider_row.operator(
                            "hhp.select_shape_corrective_binding_frame",
                            text="",
                            icon='RESTRICT_SELECT_OFF',
                        )
                        op.modifier_name = slider_name
        
        # Facial mocap / FACS section (collapsible)
        box = main_col.box()
        header = box.row(align=True)
        header.alignment = 'LEFT'
        icon = 'TRIA_DOWN' if wm.animation_facs_expanded else 'TRIA_RIGHT'
        header.prop(wm, "animation_facs_expanded", text="", icon=icon, emboss=False, icon_only=True)
        header.prop(wm, "animation_facs_expanded", text="Facial mocap / FACS", icon='SHAPEKEY_DATA', emboss=False)
        
        if wm.animation_facs_expanded:
            # Replace the import buttons with a dropdown menu
            import_export_box = box.box()
            row = import_export_box.row()
            row.menu("HHP_MT_import_facs_menu", text="Import from", icon='IMPORT')
            row.menu("HHP_MT_export_facs_menu", text="Export to", icon='EXPORT')

            if heavy_tools_loader.is_audio_mocap_model_loaded():
                row = import_export_box.row(align=True)
                row.operator(
                    "hhp.unload_audio_mocap_models",
                    text="Unload Processing Models",
                    icon='MEMORY',
                )
            
            # Add a separator between import and editor
            box.separator()
            
            # Add FACS shapekey editor
            facs_shapekey_editor.draw_facs_editor(box, context)
        

def register():
    wm = bpy.types.WindowManager
    # Expanded by default
    wm.animation_transfer_expanded = bpy.props.BoolProperty(
        name="Animation Transfer Expanded",
        description="Whether the Character Swap / Anim Transfer section is expanded",
        default=True
    )
    wm.animation_facs_expanded = bpy.props.BoolProperty(
        name="Animation FACS Expanded",
        description="Whether the Facial mocap / FACS section is expanded",
        default=True
    )
    bpy.utils.register_class(HHP_MT_import_facs_menu)
    bpy.utils.register_class(HHP_MT_export_facs_menu)
    bpy.utils.register_class(HHP_OT_correct_mouth_shape)
    bpy.utils.register_class(HHP_OT_delete_mouth_corrective)
    bpy.utils.register_class(HHP_MT_delete_mouth_corrective_menu)
    bpy.utils.register_class(HHP_OT_correct_eyelids_shape)
    bpy.utils.register_class(HHP_OT_delete_eyelids_corrective)
    bpy.utils.register_class(HHP_MT_delete_eyelids_corrective_menu)
    bpy.utils.register_class(HHP_OT_open_correct_shape_menu)
    bpy.utils.register_class(HHP_MT_correct_shape_menu)
    bpy.utils.register_class(HHP_OT_delete_all_shape_correctives)
    bpy.utils.register_class(HHP_MT_delete_shape_corrective_menu)
    bpy.utils.register_class(HHP_OT_select_shape_corrective_binding_frame)
    bpy.utils.register_class(ANIMATION_HHP_PT_Panel)
    hhp_bs_anim_transfer.register()
    heavy_tools_loader.register()
    import_facs_csv.register()
    export_facs_csv.register()
    export_facs_json.register()


def unregister():
    wm = bpy.types.WindowManager
    del wm.animation_transfer_expanded
    del wm.animation_facs_expanded
    heavy_tools_loader.unregister()
    export_facs_json.unregister()
    export_facs_csv.unregister()
    import_facs_csv.unregister()
    bpy.utils.unregister_class(ANIMATION_HHP_PT_Panel)
    bpy.utils.unregister_class(HHP_OT_select_shape_corrective_binding_frame)
    bpy.utils.unregister_class(HHP_MT_delete_shape_corrective_menu)
    bpy.utils.unregister_class(HHP_OT_delete_all_shape_correctives)
    bpy.utils.unregister_class(HHP_MT_correct_shape_menu)
    bpy.utils.unregister_class(HHP_OT_open_correct_shape_menu)
    bpy.utils.unregister_class(HHP_MT_delete_eyelids_corrective_menu)
    bpy.utils.unregister_class(HHP_OT_delete_eyelids_corrective)
    bpy.utils.unregister_class(HHP_OT_correct_eyelids_shape)
    bpy.utils.unregister_class(HHP_MT_delete_mouth_corrective_menu)
    bpy.utils.unregister_class(HHP_OT_delete_mouth_corrective)
    bpy.utils.unregister_class(HHP_OT_correct_mouth_shape)
    bpy.utils.unregister_class(HHP_MT_export_facs_menu)
    bpy.utils.unregister_class(HHP_MT_import_facs_menu)
    hhp_bs_anim_transfer.unregister()
