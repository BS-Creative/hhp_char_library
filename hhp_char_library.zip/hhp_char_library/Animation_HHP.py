import bpy
from .modules import facs_shapekey_editor
from .modules import import_facs_csv

# Create a menu class for the FACS import dropdown
class HHP_MT_import_facs_menu(bpy.types.Menu):
    bl_label = "Import from"
    bl_idname = "HHP_MT_import_facs_menu"
    
    def draw(self, context):
        layout = self.layout
        layout.operator("hhp.import_facs_json", text="JSON File - Nvidia Omniverse Audio2Face", icon='SHAPEKEY_DATA')
        layout.operator("hhp.import_facs_csv", text="CSV File - Live Link Face (iPhone App)", icon='FILE_TEXT')

class ANIMATION_HHP_PT_Panel(bpy.types.Panel):
    bl_label = "Animation (HHP)"
    bl_idname = "ANIMATION_HHP_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'
    bl_parent_id = "CHAR_HHP_PT_Panel"  # Set parent panel
    bl_order = 30  # This will place it after Optimize (15) but before Creator Tools (50)
    bl_options = {'HIDE_HEADER'}  # Hide the header
    
    @classmethod
    def poll(cls, context):
        # Only show this panel if ANIMATION is selected in the mode selector
        return context.scene.hhp_panel_mode.selected_panel == 'ANIMATION'
    
    def draw(self, context):
        layout = self.layout
        
        # Create a box without a label
        box = layout.box()
        col = box.column()
        col.label(text="Future facial motion capture and animation")
        col.label(text="tools will show here for subscribers.")
        
        # Add some spacing
        box.separator()
        
        # Add the subscription button with the link
        row = box.row()
        subscribe_op = row.operator("wm.url_open", text="Subscribe Now", icon='URL')
        subscribe_op.url = "https://www.patreon.com/login?ru=%2Fcheckout%2FBS_Creative%3Frid%3D23204798"

def register():
    bpy.utils.register_class(HHP_MT_import_facs_menu)
    bpy.utils.register_class(ANIMATION_HHP_PT_Panel)
    import_facs_csv.register()


def unregister():
    import_facs_csv.unregister()
    bpy.utils.unregister_class(ANIMATION_HHP_PT_Panel)
    bpy.utils.unregister_class(HHP_MT_import_facs_menu)