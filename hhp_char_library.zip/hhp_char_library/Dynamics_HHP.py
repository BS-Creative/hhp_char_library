import bpy
from bpy.types import Panel, Operator

# First, we need to add a property to store the visibility state
class HHPDynamicsProps(bpy.types.PropertyGroup):
    show_settings: bpy.props.BoolProperty(
        name="Show Settings",
        description="Show detailed dynamic paint and modifier settings",
        default=True
    )

class OBJECT_OT_PtcacheBakeAll(Operator):
    bl_idname = "object.dynamics_ptcache_bake_all"
    bl_label = "Bake All Physics"
    bl_description = "Bake all physics simulations in the scene"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        bpy.ops.ptcache.bake_all(bake=True)
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=400)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="WARNING: This will bake ALL physics in the scene including:")
        layout.label(text="• Cloth, Soft Body, and Rigid Body simulations")
        layout.label(text="• Dynamic Paint, Fluid, and Particle systems")
        layout.label(text="A final bake should only be initiated at the very end of the project.")
        layout.label(text="Are you sure you want to continue?", icon='ERROR')

class OBJECT_OT_PtcacheFreeBakeAll(Operator):
    bl_idname = "object.dynamics_ptcache_free_bake_all"
    bl_label = "Free All Bakes"
    bl_description = "Free all baked physics simulations in the scene"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        bpy.ops.ptcache.free_bake_all()
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=400)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="WARNING: This will delete ALL baked physics data in the scene:")
        layout.label(text="• All Dynamic Paint and physics simulation caches will be lost")
        layout.label(text="• You will need to rebake everything after this operation")
        layout.label(text="Are you sure you want to continue?", icon='ERROR')

class DYNAMICS_HHP_PT_Panel(Panel):
    bl_label = "Dynamics"
    bl_idname = "DYNAMICS_HHP_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'
    bl_parent_id = "CHAR_HHP_PT_Panel"
    bl_options = {'HIDE_HEADER'}  # Completely hide the panel header
    
    @classmethod
    def poll(cls, context):
        # Only show this panel when the Dynamics mode is selected
        return context.scene.hhp_panel_mode.selected_panel == 'DYNAMICS'
    
    def draw(self, context):
        layout = self.layout
        
        # Create a box without a label
        box = layout.box()
        col = box.column()
        col.label(text="Future fluids and dynamics tools")
        col.label(text="will show here for subscribers.")
        
        # Add some spacing
        box.separator()
        
        # Add the subscription button with the link
        row = box.row()
        subscribe_op = row.operator("wm.url_open", text="Subscribe Now", icon='URL')
        subscribe_op.url = "https://www.patreon.com/login?ru=%2Fcheckout%2FBS_Creative%3Frid%3D23204798"

# Registration
classes = (
    HHPDynamicsProps,
    OBJECT_OT_PtcacheBakeAll,
    OBJECT_OT_PtcacheFreeBakeAll,
    DYNAMICS_HHP_PT_Panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    # Register the property group
    bpy.types.Scene.hhp_dynamics_props = bpy.props.PointerProperty(type=HHPDynamicsProps)

def unregister():
    # Unregister the property group
    del bpy.types.Scene.hhp_dynamics_props
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
