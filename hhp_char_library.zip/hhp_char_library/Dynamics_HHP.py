import bpy
from bpy.types import Panel, Operator
import blf
import time


_FACE_MATERIAL_SUBSTRING = "Genesis 8 Female_Face"
_SHADER_LAYERS_GROUP_SUBSTRING = "(HHP)_Shader Layers"
_SHADER_LAYER_FINAL_GROUP_SUBSTRING = "(HHP) Shader Layer_FINAL"


def _find_material_by_substring(obj, substring):
    if not obj or obj.type != 'MESH' or not obj.data:
        return None
    for mat in getattr(obj.data, "materials", []) or []:
        if mat and substring in mat.name:
            return mat
    return None


def _find_group_node_by_tree_name_in_tree(node_tree, tree_name_substring):
    if not node_tree:
        return None
    for node in node_tree.nodes:
        if getattr(node, "type", None) == 'GROUP' and getattr(node, "node_tree", None):
            if tree_name_substring in node.node_tree.name:
                return node
    return None


def _is_on_optimized_materials(obj):
    if not obj or obj.type != 'MESH':
        return False
    has_proxy_material = any(
        slot.material and slot.material.name.startswith("(BS)_Proxy")
        for slot in getattr(obj, "material_slots", []) or []
    )
    linked_by_object = any(
        getattr(slot, "link", "") == 'OBJECT'
        for slot in getattr(obj, "material_slots", []) or []
    )
    return has_proxy_material or linked_by_object


def _selected_meshes(context):
    return [
        obj
        for obj in getattr(context, "selected_objects", []) or []
        if obj and obj.type == 'MESH'
    ]


def _any_selected_mesh_on_optimized_materials(context):
    return any(_is_on_optimized_materials(obj) for obj in _selected_meshes(context))


def _switch_selected_meshes_to_data_linked_materials(context):
    changed = 0
    mesh_count = 0
    for obj in _selected_meshes(context):
        mesh_count += 1
        for slot in getattr(obj, "material_slots", []) or []:
            try:
                if getattr(slot, "link", None) != 'DATA':
                    slot.link = 'DATA'
                    changed += 1
            except Exception:
                pass
    return mesh_count, changed


def _get_window_pointer(window):
    try:
        return window.as_pointer()
    except Exception:
        return id(window)


def _set_active_material(obj, material):
    if not obj or not material:
        return
    for index, slot in enumerate(getattr(obj, "material_slots", []) or []):
        if slot.material == material:
            obj.active_material_index = index
            break


def _set_node_editor_nested_group_path(space, material, shader_layers_node, final_node):
    if not space or not material or not getattr(material, "node_tree", None):
        return False
    if not shader_layers_node or not getattr(shader_layers_node, "node_tree", None):
        return False
    if not final_node or not getattr(final_node, "node_tree", None):
        return False

    try:
        space.path.start(material.node_tree)
        space.path.append(shader_layers_node.node_tree, shader_layers_node)
        space.path.append(final_node.node_tree, final_node)
    except TypeError:
        try:
            space.path.start(material.node_tree)
            space.path.append(shader_layers_node.node_tree)
            space.path.append(final_node.node_tree)
        except Exception:
            return False
    except Exception:
        return False

    return getattr(space, "edit_tree", None) == final_node.node_tree


def _open_shader_layer_final_in_new_window(context, obj, material, shader_layers_node, final_node):
    if not material or not shader_layers_node or not final_node:
        return False

    window_manager = context.window_manager
    before_windows = {_get_window_pointer(window) for window in window_manager.windows}
    result = bpy.ops.wm.window_new()
    if 'FINISHED' not in result:
        return False

    new_window = next(
        (
            window
            for window in window_manager.windows
            if _get_window_pointer(window) not in before_windows
        ),
        context.window,
    )
    if not new_window or not getattr(new_window, "screen", None):
        return False

    screen = new_window.screen
    area = max(screen.areas, key=lambda screen_area: screen_area.width * screen_area.height)
    area.type = 'NODE_EDITOR'
    region = next((reg for reg in area.regions if reg.type == 'WINDOW'), None)
    space = area.spaces.active
    if not region or not space:
        return False

    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass
    _set_active_material(obj, material)

    try:
        space.tree_type = 'ShaderNodeTree'
    except Exception:
        pass
    try:
        space.shader_type = 'OBJECT'
    except Exception:
        pass
    try:
        space.id = material
    except Exception:
        pass

    try:
        material_nodes = material.node_tree.nodes
        for node in material_nodes:
            node.select = False
        shader_layers_node.select = True
        material_nodes.active = shader_layers_node
    except Exception:
        pass

    entered_group = _set_node_editor_nested_group_path(space, material, shader_layers_node, final_node)
    if not entered_group:
        with context.temp_override(
            window=new_window,
            screen=screen,
            area=area,
            region=region,
            space_data=space,
            active_object=obj,
            object=obj,
            selected_objects=[obj] if obj else [],
        ):
            try:
                first_result = bpy.ops.node.group_edit(exit=False)
                if 'FINISHED' in first_result:
                    shader_layers_node.node_tree.nodes.active = final_node
                    final_node.select = True
                    second_result = bpy.ops.node.group_edit(exit=False)
                    entered_group = 'FINISHED' in second_result
            except Exception:
                pass

    try:
        area.tag_redraw()
    except Exception:
        pass

    return entered_group


def hhp_switch_viewports_to_solid(context):
    shading_state = []
    screens = []
    window_manager = getattr(context, "window_manager", None)
    if window_manager:
        for window in window_manager.windows:
            screen = getattr(window, "screen", None)
            if screen and screen not in screens:
                screens.append(screen)

    screen = getattr(context, "screen", None)
    if screen and screen not in screens:
        screens.append(screen)

    for screen in screens:
        for area in screen.areas:
            if area.type != 'VIEW_3D':
                continue
            for space in area.spaces:
                if space.type != 'VIEW_3D':
                    continue
                shading = getattr(space, "shading", None)
                if not shading:
                    continue
                shading_state.append((space, shading.type))
                shading.type = 'SOLID'
    return shading_state


def hhp_restore_viewport_shading(shading_state):
    for space, shading_type in shading_state:
        try:
            space.shading.type = shading_type
        except Exception:
            pass


def hhp_enable_simplify_zero_viewport(context):
    render = getattr(context.scene, "render", None)
    if not render or not hasattr(render, "use_simplify") or not hasattr(render, "simplify_subdivision"):
        return None

    use_simplify = render.use_simplify
    simplify_subdivision = render.simplify_subdivision
    if use_simplify and simplify_subdivision == 0:
        return None

    render.use_simplify = True
    render.simplify_subdivision = 0
    return (render, use_simplify, simplify_subdivision)


def hhp_restore_simplify_state(simplify_state):
    if not simplify_state:
        return

    render, use_simplify, simplify_subdivision = simplify_state
    try:
        render.use_simplify = use_simplify
        render.simplify_subdivision = simplify_subdivision
    except Exception:
        pass


def hhp_format_elapsed_time(start_time):
    elapsed = max(0.0, time.perf_counter() - start_time)
    if elapsed >= 60.0:
        minutes = int(elapsed // 60)
        seconds = elapsed - (minutes * 60)
        return f"{minutes}m {seconds:.1f}s"
    return f"{elapsed:.1f}s"


# First, we need to add a property to store the visibility state
class HHPDynamicsProps(bpy.types.PropertyGroup):
    show_settings: bpy.props.BoolProperty(
        name="Show Settings",
        description="Show detailed dynamic paint and modifier settings",
        default=True
    )
    
    fluid_mode: bpy.props.EnumProperty(
        name="Fluid Mode",
        description="Select which fluid system to use",
        items=[
            ('BLENDER', "Blender Default", "Use Blender's built-in fluid simulation system"),
            ('FLIP', "Flip Fluids", "Use the Flip Fluids addon (must be installed)"),
        ],
        default='BLENDER'
    )

class OBJECT_OT_PtcacheBakeAll(Operator):
    bl_idname = "object.dynamics_ptcache_bake_all"
    bl_label = "Progressive bake (Slower)"
    bl_description = "Real-time viewable bake for HHP Dynamic Paint canvases. You can watch the simulation as it bakes and press ESC to cancel"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        self._mixin = HHP_PTCacheDynamicPaintMixin()
        self._caches = self._mixin.collect_canvas_caches(context)
        if not self._caches:
            self.report({'WARNING'}, "No HHP-DP Dynamic Paint canvases found on selected meshes")
            return {'CANCELLED'}

        self._bake_start_time = time.perf_counter()
        self._simplify_state = hhp_enable_simplify_zero_viewport(context)
        self._viewport_shading_state = hhp_switch_viewports_to_solid(context)
        self._visibility_state = self._mixin.make_canvas_objects_visible(self._caches)
        self._start_frame, self._end_frame = self._mixin.get_canvas_cache_frame_range(context, self._caches)
        self._current_frame = self._start_frame
        self._timer = context.window_manager.event_timer_add(0.01, window=context.window)
        self._draw_handler = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_viewport_cancel_message,
            (),
            'WINDOW',
            'POST_PIXEL'
        )
        self.update_bake_status_text(context)

        try:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        except Exception:
            pass

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'ESC':
            return self.cancel_modal(context)

        if event.type != 'TIMER':
            return {'PASS_THROUGH'}

        if self._current_frame <= self._end_frame:
            context.scene.frame_set(self._current_frame)
            self._current_frame += 1
            self.update_bake_status_text(context)
            self.tag_view3d_redraw(context)
            return {'RUNNING_MODAL'}

        return self.finish_modal(context)

    def get_bake_progress_percent(self):
        total_frames = max(1, self._end_frame - self._start_frame + 1)
        completed_frames = min(max(self._current_frame - self._start_frame, 0), total_frames)
        return int((completed_frames / total_frames) * 100)

    def get_bake_status_text(self):
        return f"Baking {self.get_bake_progress_percent()}% - Press ESC to cancel bake"

    def update_bake_status_text(self, context):
        context.workspace.status_text_set(self.get_bake_status_text())

    def draw_viewport_cancel_message(self):
        font_id = 0
        blf.size(font_id, 18)
        blf.color(font_id, 1.0, 0.85, 0.1, 1.0)
        blf.position(font_id, 32, 72, 0)
        blf.draw(font_id, self.get_bake_status_text())

    def tag_view3d_redraw(self, context):
        screen = getattr(context, "screen", None)
        if not screen:
            return
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

    def save_current_cache(self, context):
        caches, failures = self._mixin._run_on_canvas_caches(context, lambda: bpy.ops.ptcache.bake_from_cache())
        return caches, failures

    def finish_modal(self, context):
        caches, failures = self.save_current_cache(context)
        self.cleanup_modal(context)
        elapsed_time = hhp_format_elapsed_time(self._bake_start_time)

        if failures:
            detail = "; ".join(f"{obj}: {surface}: {reason}" for obj, surface, reason in failures)
            self.report({'WARNING'}, f"Finished bake in {elapsed_time}; simulated frames {self._start_frame}-{self._end_frame}; baked {len(caches) - len(failures)} caches, {len(failures)} failed ({detail})")
        else:
            self.report({'INFO'}, f"Finished bake in {elapsed_time}; simulated frames {self._start_frame}-{self._end_frame} and baked {len(caches)} Dynamic Paint surface(s)")
        return {'FINISHED'}

    def cancel_modal(self, context):
        cancel_frame = max(self._start_frame, self._current_frame - 1)
        caches, failures = self.save_current_cache(context)
        self.cleanup_modal(context)
        elapsed_time = hhp_format_elapsed_time(self._bake_start_time)
        if failures:
            detail = "; ".join(f"{obj}: {surface}: {reason}" for obj, surface, reason in failures)
            self.report({'WARNING'}, f"Cancelled after {elapsed_time} at frame {cancel_frame}; saved partial cache for {len(caches) - len(failures)} caches, {len(failures)} failed ({detail})")
        else:
            self.report({'WARNING'}, f"Cancelled after {elapsed_time} at frame {cancel_frame}; saved partial cache for {len(caches)} Dynamic Paint surface(s)")
        return {'CANCELLED'}

    def cleanup_modal(self, context):
        if getattr(self, "_timer", None):
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        if getattr(self, "_draw_handler", None):
            bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
            self._draw_handler = None
        context.workspace.status_text_set(None)
        if getattr(self, "_visibility_state", None):
            self._mixin.restore_canvas_object_visibility(self._visibility_state)
            self._visibility_state = None
        if getattr(self, "_viewport_shading_state", None):
            hhp_restore_viewport_shading(self._viewport_shading_state)
            self._viewport_shading_state = None
        if getattr(self, "_simplify_state", None):
            hhp_restore_simplify_state(self._simplify_state)
            self._simplify_state = None
        self.tag_view3d_redraw(context)

    def invoke(self, context, event):
        return self.execute(context)


class OBJECT_OT_DynamicsPtcacheBakeOffline(Operator):
    bl_idname = "object.dynamics_ptcache_bake_offline"
    bl_label = "Offline bake (Faster)"
    bl_description = "Temporarily freezes Blender while the HHP Dynamic Paint bake runs for faster bakes"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        mixin = HHP_PTCacheDynamicPaintMixin()
        caches = mixin.collect_canvas_caches(context)
        if not caches:
            self.report({'WARNING'}, "No HHP-DP Dynamic Paint canvases found on selected meshes")
            return {'CANCELLED'}

        bake_start_time = time.perf_counter()
        viewport_shading_state = hhp_switch_viewports_to_solid(context)
        visibility_state = mixin.make_canvas_objects_visible(caches)
        try:
            start_frame, end_frame = mixin.simulate_canvas_cache_range(context, caches)
            caches, failures = mixin._run_on_canvas_caches(context, lambda: bpy.ops.ptcache.bake_from_cache())
        finally:
            mixin.restore_canvas_object_visibility(visibility_state)
            hhp_restore_viewport_shading(viewport_shading_state)

        elapsed_time = hhp_format_elapsed_time(bake_start_time)
        if failures:
            detail = "; ".join(f"{obj}: {surface}: {reason}" for obj, surface, reason in failures)
            self.report({'WARNING'}, f"Finished bake in {elapsed_time}; simulated frames {start_frame}-{end_frame}; baked {len(caches) - len(failures)} caches, {len(failures)} failed ({detail})")
        else:
            self.report({'INFO'}, f"Finished bake in {elapsed_time}; simulated frames {start_frame}-{end_frame} and baked {len(caches)} Dynamic Paint surface(s)")
        return {'FINISHED'}


class OBJECT_OT_DynamicsPtcacheBakeMenu(Operator):
    bl_idname = "object.dynamics_ptcache_bake_menu"
    bl_label = "Bake"
    bl_description = "Choose how to bake HHP Dynamic Paint caches"

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.popup_menu(self.draw_menu, title="Bake Options")
        return {'FINISHED'}

    def draw_menu(self, menu, context):
        layout = menu.layout
        layout.operator("object.dynamics_ptcache_bake_all", text="Progressive bake (Slower)", icon='PLAY')
        layout.operator("object.dynamics_ptcache_bake_offline", text="Offline bake (Faster)", icon='RENDER_STILL')

class OBJECT_OT_PtcacheFreeBakeAll(Operator):
    bl_idname = "object.dynamics_ptcache_free_bake_all"
    bl_label = "Free All Bakes"
    bl_description = "Free all baked physics simulations in the scene, including fluids and dynamics"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        bpy.ops.ptcache.free_bake_all()
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=400)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="WARNING: This will free ALL baked physics in the scene.", icon='ERROR')
        layout.label(text="This includes fluids and dynamics, not just HHP physics.")
        layout.label(text="You will need to rebake anything this clears.")


class HHP_PTCacheDynamicPaintMixin:
    """Utility mixin to gather Dynamic Paint canvas caches and run ptcache ops."""

    def collect_canvas_caches(self, context):
        """Return enabled HHP-DP canvas caches: (object, surface, point_cache)."""
        caches = []
        seen = set()
        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue
            for mod in obj.modifiers:
                if mod.type != 'DYNAMIC_PAINT' or "(HHP-DP)" not in mod.name:
                    continue
                # Respect modifier enable state
                if not (mod.show_viewport and mod.show_render):
                    continue
                canvas = getattr(mod, "canvas_settings", None)
                if not canvas or not getattr(canvas, "canvas_surfaces", None):
                    continue
                for surface in canvas.canvas_surfaces:
                    # Only bake/free enabled surfaces
                    if not surface.is_active:
                        continue
                    cache = getattr(surface, "point_cache", None)
                    if cache and id(cache) not in seen:
                        seen.add(id(cache))
                        caches.append((obj, surface, cache))
        return caches

    def count_baked_canvas_caches(self, context):
        baked_count = 0
        for _, _, cache in self.collect_canvas_caches(context):
            if getattr(cache, "is_baked", False):
                baked_count += 1
        return baked_count

    def collect_baked_canvas_cache_items(self, context):
        items = []
        for obj, surface, cache in self.collect_canvas_caches(context):
            if not getattr(cache, "is_baked", False):
                continue
            label = surface.name or "Dynamic Paint"
            items.append((obj, surface, cache, label))
        return items

    def count_unbaked_canvas_caches(self, context):
        unbaked_count = 0
        for _, _, cache in self.collect_canvas_caches(context):
            if not getattr(cache, "is_baked", False):
                unbaked_count += 1
        return unbaked_count

    def get_view3d_override(self, context):
        window = getattr(context, "window", None)
        screen = getattr(window, "screen", None) if window else None
        if not screen:
            return None
        area = next((a for a in screen.areas if a.type == 'VIEW_3D'), None)
        if not area:
            return None
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        space_data = area.spaces.active if area.spaces else None
        if not (region and space_data):
            return None
        return {
            "window": window,
            "screen": screen,
            "area": area,
            "region": region,
            "space_data": space_data,
        }

    def get_canvas_cache_frame_range(self, context, caches):
        start_frames = []
        end_frames = []
        for _, _, cache in caches:
            start_frames.append(getattr(cache, "frame_start", context.scene.frame_start))
            end_frames.append(getattr(cache, "frame_end", context.scene.frame_end))

        if not start_frames or not end_frames:
            return context.scene.frame_start, context.scene.frame_end
        return int(min(start_frames)), int(max(end_frames))

    def get_parent_collections(self, collection):
        parent_collections = []
        for parent in bpy.data.collections:
            if collection.name in parent.children.keys():
                parent_collections.append(parent)
                parent_collections.extend(self.get_parent_collections(parent))
        return parent_collections

    def make_canvas_objects_visible(self, caches):
        object_states = {}
        collection_states = {}

        for obj, _, _ in caches:
            if obj.name not in object_states:
                object_states[obj.name] = (
                    obj.hide_viewport,
                    obj.hide_render,
                    obj.hide_get() if hasattr(obj, "hide_get") else obj.hide_viewport
                )

            for col in getattr(obj, "users_collection", []):
                for visible_col in [col] + self.get_parent_collections(col):
                    if visible_col.name not in collection_states:
                        collection_states[visible_col.name] = visible_col.hide_viewport
                    visible_col.hide_viewport = False

            try:
                if hasattr(obj, "hide_set"):
                    obj.hide_set(False)
            except Exception:
                pass
            obj.hide_viewport = False
            obj.hide_render = False

        return object_states, collection_states

    def restore_canvas_object_visibility(self, visibility_state):
        object_states, collection_states = visibility_state

        for obj_name, (hide_viewport, hide_render, was_hidden) in object_states.items():
            obj = bpy.data.objects.get(obj_name)
            if not obj:
                continue
            obj.hide_viewport = hide_viewport
            obj.hide_render = hide_render
            try:
                if hasattr(obj, "hide_set"):
                    obj.hide_set(was_hidden)
            except Exception:
                pass

        for col_name, hide_viewport in collection_states.items():
            col = bpy.data.collections.get(col_name)
            if col:
                col.hide_viewport = hide_viewport

    def simulate_canvas_cache_range(self, context, caches):
        start_frame, end_frame = self.get_canvas_cache_frame_range(context, caches)
        try:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        except Exception:
            pass

        for frame in range(start_frame, end_frame + 1):
            context.scene.frame_set(frame)
        return start_frame, end_frame

    def _run_on_canvas_caches(self, context, op_callable):
        caches = self.collect_canvas_caches(context)
        if not caches:
            return caches, []

        view_layer = context.view_layer
        original_active = view_layer.objects.active
        original_mode = context.mode
        original_selection = list(context.selected_objects)
        failures = []

        def safe_object_mode():
            try:
                if context.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

        def safe_deselect_all():
            safe_object_mode()
            try:
                bpy.ops.object.select_all(action='DESELECT')
            except Exception:
                for obj in view_layer.objects:
                    obj.select_set(False)

        safe_object_mode()

        try:
            for obj, surface, cache in caches:
                safe_deselect_all()
                obj.select_set(True)
                view_layer.objects.active = obj

                try:
                    if obj.mode != 'OBJECT':
                        res = bpy.ops.object.mode_set(mode='OBJECT')
                        if isinstance(res, set) and 'FINISHED' not in res:
                            failures.append((obj.name, surface.name, "Failed to enter OBJECT mode"))
                            continue
                except Exception as exc:
                    failures.append((obj.name, surface.name, f"Failed to enter OBJECT mode: {exc}"))
                    continue

                override = {
                    "view_layer": view_layer,
                    "active_object": obj,
                    "selected_objects": [obj],
                    "object": obj,
                    "point_cache": cache,
                }
                view3d_override = self.get_view3d_override(context)
                if view3d_override:
                    override.update(view3d_override)

                try:
                    with context.temp_override(**override):
                        res = op_callable()
                        if isinstance(res, set) and 'FINISHED' not in res:
                            failures.append((obj.name, surface.name, "Operator cancelled"))
                except Exception as exc:
                    failures.append((obj.name, surface.name, str(exc)))
        finally:
            safe_deselect_all()
            for obj in original_selection:
                obj.select_set(True)
            if original_active:
                view_layer.objects.active = original_active
            try:
                if original_mode != context.mode:
                    bpy.ops.object.mode_set(mode=original_mode)
            except Exception:
                pass

        return caches, failures

    def _run_on_canvas_cache(self, context, object_name, surface_name, op_callable):
        obj = bpy.data.objects.get(object_name)
        if not obj or obj.type != 'MESH':
            return False, "Canvas object not found"

        target_surface = None
        target_cache = None
        for mod in obj.modifiers:
            if mod.type != 'DYNAMIC_PAINT' or "(HHP-DP)" not in mod.name:
                continue
            canvas = getattr(mod, "canvas_settings", None)
            if not canvas or not getattr(canvas, "canvas_surfaces", None):
                continue
            for surface in canvas.canvas_surfaces:
                if surface.name != surface_name:
                    continue
                target_surface = surface
                target_cache = getattr(surface, "point_cache", None)
                break
            if target_cache:
                break

        if not target_surface or not target_cache:
            return False, "Canvas cache not found"
        if not getattr(target_cache, "is_baked", False):
            return False, "Canvas cache is not baked"

        view_layer = context.view_layer
        original_active = view_layer.objects.active
        original_mode = context.mode
        original_selection = list(context.selected_objects)
        visibility_state = self.make_canvas_objects_visible([(obj, target_surface, target_cache)])

        def safe_object_mode():
            try:
                if context.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

        try:
            safe_object_mode()
            try:
                bpy.ops.object.select_all(action='DESELECT')
            except Exception:
                for selected_obj in view_layer.objects:
                    selected_obj.select_set(False)

            obj.select_set(True)
            view_layer.objects.active = obj

            override = {
                "view_layer": view_layer,
                "active_object": obj,
                "selected_objects": [obj],
                "object": obj,
                "point_cache": target_cache,
            }
            view3d_override = self.get_view3d_override(context)
            if view3d_override:
                override.update(view3d_override)

            with context.temp_override(**override):
                result = op_callable()
                if isinstance(result, set) and 'FINISHED' not in result:
                    return False, "Operator cancelled"
        except Exception as exc:
            return False, str(exc)
        finally:
            try:
                bpy.ops.object.select_all(action='DESELECT')
            except Exception:
                for selected_obj in view_layer.objects:
                    selected_obj.select_set(False)
            for selected_obj in original_selection:
                selected_obj.select_set(True)
            if original_active:
                view_layer.objects.active = original_active
            try:
                if original_mode != context.mode:
                    bpy.ops.object.mode_set(mode=original_mode)
            except Exception:
                pass
            self.restore_canvas_object_visibility(visibility_state)

        return True, None


class OBJECT_OT_DynamicsPtcacheBakeCurrent(HHP_PTCacheDynamicPaintMixin, Operator):
    bl_idname = "object.dynamics_ptcache_bake_current"
    bl_label = "Current Cache to Bake"
    bl_description = "Save the simulation cached up to the current frame as a bake for selected HHP Dynamic Paint canvases. Anything you saw simulating during animation playback will be kept as the baked result"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        caches, failures = self._run_on_canvas_caches(context, lambda: bpy.ops.ptcache.bake_from_cache())
        if not caches:
            self.report({'WARNING'}, "No HHP-DP Dynamic Paint canvases found on selected meshes")
            return {'CANCELLED'}

        if failures:
            detail = "; ".join(f"{obj}: {surface}: {reason}" for obj, surface, reason in failures)
            self.report({'WARNING'}, f"Baked {len(caches) - len(failures)} caches, {len(failures)} failed ({detail})")
        else:
            self.report({'INFO'}, f"Baked current cache for {len(caches)} Dynamic Paint surface(s)")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


class OBJECT_OT_DynamicsPtcacheFreeCurrent(HHP_PTCacheDynamicPaintMixin, Operator):
    bl_idname = "object.dynamics_ptcache_free_current"
    bl_label = "Delete Bake"
    bl_description = "Delete baked cache for Dynamic Paint canvases on selected meshes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        caches, failures = self._run_on_canvas_caches(context, lambda: bpy.ops.ptcache.free_bake())
        if not caches:
            self.report({'WARNING'}, "No HHP-DP Dynamic Paint canvases found on selected meshes")
            return {'CANCELLED'}

        if failures:
            detail = "; ".join(f"{obj}: {surface}: {reason}" for obj, surface, reason in failures)
            self.report({'WARNING'}, f"Deleted bake on {len(caches) - len(failures)} caches, {len(failures)} failed ({detail})")
        else:
            self.report({'INFO'}, f"Deleted bakes for {len(caches)} Dynamic Paint surface(s)")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


class OBJECT_OT_DynamicsPtcacheFreeBakedMenu(HHP_PTCacheDynamicPaintMixin, Operator):
    bl_idname = "object.dynamics_ptcache_free_baked_menu"
    bl_label = "Delete Individual Bake"
    bl_description = "Choose one baked HHP Dynamic Paint element to delete"

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.popup_menu(self.draw_menu, title="Delete Individual Bake")
        return {'FINISHED'}

    def draw_menu(self, menu, context):
        layout = menu.layout
        baked_items = self.collect_baked_canvas_cache_items(context)
        if not baked_items:
            layout.label(text="No baked HHP Dynamic Paint elements found", icon='INFO')
            return

        for obj, surface, _cache, label in baked_items:
            op = layout.operator(
                "object.dynamics_ptcache_free_baked_item",
                text=label,
                icon='MOD_DYNAMICPAINT',
            )
            op.object_name = obj.name
            op.surface_name = surface.name
            op.display_name = label


class OBJECT_OT_DynamicsPtcacheFreeBakedItem(HHP_PTCacheDynamicPaintMixin, Operator):
    bl_idname = "object.dynamics_ptcache_free_baked_item"
    bl_label = "Delete Individual Bake"
    bl_description = "Delete only this baked HHP Dynamic Paint element"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: bpy.props.StringProperty(options={'HIDDEN'})
    surface_name: bpy.props.StringProperty(options={'HIDDEN'})
    display_name: bpy.props.StringProperty(options={'HIDDEN'})

    def execute(self, context):
        success, error = self._run_on_canvas_cache(
            context,
            self.object_name,
            self.surface_name,
            lambda: bpy.ops.ptcache.free_bake(),
        )
        if not success:
            self.report({'WARNING'}, f"Could not delete bake for '{self.display_name}': {error}")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Deleted bake for '{self.display_name}'")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


class OBJECT_OT_DynamicsSwitchToOriginalMaterials(Operator):
    bl_idname = "object.hhp_dynamics_switch_to_original_materials"
    bl_label = "Switch to Original Materials"
    bl_description = "Set all selected mesh material slots to original material mode so shader layers can be edited"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mesh_count, changed = _switch_selected_meshes_to_data_linked_materials(context)
        if mesh_count == 0:
            self.report({'ERROR'}, "Select at least one mesh")
            return {'CANCELLED'}

        if changed:
            self.report({'INFO'}, f"Switched {mesh_count} selected mesh(es) back to original materials")
        else:
            self.report({'INFO'}, "Selected mesh material slots are already on original materials")
        return {'FINISHED'}


class OBJECT_OT_OpenShaderLayerVFX(Operator):
    bl_idname = "object.open_hhp_shader_layer_vfx"
    bl_label = "Shader Layer - VFX"
    bl_description = "Open the face material VFX shader layer node group in a new Shader Node Editor window"
    bl_options = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Active object must be a mesh")
            return {'CANCELLED'}

        if _any_selected_mesh_on_optimized_materials(context):
            self.report({'ERROR'}, "Switch to original materials before opening shader layers")
            return {'CANCELLED'}

        face_material = _find_material_by_substring(obj, _FACE_MATERIAL_SUBSTRING)
        if not face_material:
            self.report({'ERROR'}, "Shader Layer - VFX not found")
            return {'CANCELLED'}

        shader_layers_node = _find_group_node_by_tree_name_in_tree(
            face_material.node_tree if face_material.use_nodes else None,
            _SHADER_LAYERS_GROUP_SUBSTRING,
        )
        if not shader_layers_node or not getattr(shader_layers_node, "node_tree", None):
            self.report({'ERROR'}, "Could not find the Shader Layers node group")
            return {'CANCELLED'}

        final_node = _find_group_node_by_tree_name_in_tree(
            shader_layers_node.node_tree,
            _SHADER_LAYER_FINAL_GROUP_SUBSTRING,
        )
        if not final_node or not getattr(final_node, "node_tree", None):
            self.report({'ERROR'}, "Could not find the Shader Layer FINAL node group")
            return {'CANCELLED'}

        if not _open_shader_layer_final_in_new_window(
            context,
            obj,
            face_material,
            shader_layers_node,
            final_node,
        ):
            self.report({'ERROR'}, "Could not open Shader Layer - VFX")
            return {'CANCELLED'}

        self.report({'INFO'}, "Opened Shader Layer - VFX")
        return {'FINISHED'}


class DYNAMICS_HHP_PT_Panel(Panel):
    bl_label = "Dynamics"
    bl_idname = "DYNAMICS_HHP_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'
    bl_parent_id = "CHAR_HHP_PT_Panel"
    bl_options = {'HIDE_HEADER'}  # Completely hide the panel header
    
    @classmethod
    def poll(cls, context):
        # Only show this panel when the Dynamics mode is selected
        return context.scene.hhp_panel_mode.selected_panel == 'DYNAMICS'
    
    def draw(self, context):
        layout = self.layout
        wm = context.window_manager

        # Read debug mode from addon preferences (stored on the main package)
        addon_prefs_entry = context.preferences.addons.get(__package__)
        debug_enabled = bool(addon_prefs_entry and getattr(addon_prefs_entry.preferences, "debug_mode", False))

        # If debug is disabled, force the Human Fluids section closed
        if not debug_enabled:
            wm.dynamics_fluids_expanded = False

        main_col = layout.column(align=True)
        selected_meshes_on_optimized_materials = _any_selected_mesh_on_optimized_materials(context)
        
        # Human Fluids (collapsible)
        fluids_box = main_col.box()
        # Grey out the Human Fluids box when debug mode is off
        fluids_box.enabled = debug_enabled

        fluids_header = fluids_box.row(align=True)
        fluids_header.alignment = 'LEFT'
        icon = 'TRIA_DOWN' if wm.dynamics_fluids_expanded else 'TRIA_RIGHT'
        fluids_header.prop(wm, "dynamics_fluids_expanded", text="", icon=icon, emboss=False, icon_only=True)
        fluids_header.prop(
            wm,
            "dynamics_fluids_expanded",
            text="Human Fluids (Still in Development)",
            icon='PHYSICS',
            emboss=False
        )

        if wm.dynamics_fluids_expanded:
            # Add fluid mode selector above the setup button
            col = fluids_box.column(align=True)
            row = col.row(align=True)
            row.prop(context.scene.hhp_dynamics_props, "fluid_mode", expand=True)
            
            # Add CMN button in the Human Fluids box
            col.operator("object.setup_cmn_simulation", text="Setup Simulation (White fluid - CMN)", icon='PHYSICS')
        
        shader_box = main_col.box()
        active_obj = context.active_object
        if selected_meshes_on_optimized_materials:
            warn_col = shader_box.column(align=True)
            warn_col.alert = True
            warn_col.label(text="Attributes can't be changed while on optimized materials", icon='ERROR')
            action_row = warn_col.row(align=True)
            action_row.alert = False
            action_row.operator(
                "object.hhp_dynamics_switch_to_original_materials",
                text="Switch to Original Materials",
                icon='MATERIAL',
            )
        else:
            shader_col = shader_box.column(align=True)
            shader_col.enabled = bool(
                active_obj
                and active_obj.type == 'MESH'
                and "Genesis8Female.Shape" in active_obj.name
            )
            shader_col.operator(
                "object.open_hhp_shader_layer_vfx",
                text="Shader Layer - VFX",
                icon='NODETREE',
            )

        # Dynamic Paint (collapsible)
        dp_box = main_col.box()
        dp_box.enabled = not selected_meshes_on_optimized_materials
        dp_header = dp_box.row(align=True)
        dp_header.alignment = 'LEFT'
        icon = 'TRIA_DOWN' if context.window_manager.dynamics_paint_expanded else 'TRIA_RIGHT'
        dp_header.prop(context.window_manager, "dynamics_paint_expanded", text="", icon=icon, emboss=False, icon_only=True)
        dp_header.prop(context.window_manager, "dynamics_paint_expanded", text="Dynamic Paint", icon='MOD_DYNAMICPAINT', emboss=False)

        if context.window_manager.dynamics_paint_expanded:
            # Create a row for the two buttons to be side by side inside the box
            row = dp_box.row(align=True)
            row.operator("object.dynamic_pressure_canvas", text="Dynamic Paint (Canvas)", icon='MOD_DYNAMICPAINT')
            row.operator("object.dynamic_pressure_brush", text="Dynamic Paint (Brush)", icon='BRUSH_DATA')
        
        # Add dynamic controls for selected objects with HHP-DP modifiers
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        # Check if any selected objects have relevant modifiers before displaying the section
        has_relevant_modifiers = False
        for obj in selected_objects:
            for mod in obj.modifiers:
                if "(HHP-DP)" in mod.name:
                    has_relevant_modifiers = True
                    break
            if has_relevant_modifiers:
                break
        
        if context.window_manager.dynamics_paint_expanded and has_relevant_modifiers:
            # Create a settings header box with toggle
            settings_box = dp_box.box()
            header_row = settings_box.row()
            header_row.label(text="Settings", icon='MODIFIER')
            header_row.prop(context.scene.hhp_dynamics_props, "show_settings", text="", icon='SETTINGS', emboss=True)
            
            # Only show settings if the toggle is on
            if context.scene.hhp_dynamics_props.show_settings:
                # For each object with relevant modifiers
                for obj in selected_objects:
                    # Check if this object has any HHP-DP modifiers
                    has_hhp_modifiers = False
                    for mod in obj.modifiers:
                        if "(HHP-DP)" in mod.name:
                            has_hhp_modifiers = True
                            break
                    
                    if not has_hhp_modifiers:
                        continue
                    
                    # Create a box for this object
                    obj_box = settings_box.box()
                    obj_box.label(text=f"{obj.name}", icon='OBJECT_DATA')
                    
                    col = obj_box.column(align=True)
                    
                    # Find Dynamic Paint modifier
                    dp_mod = None
                    dp_brush_mod = None
                    for mod in obj.modifiers:
                        if mod.type == 'DYNAMIC_PAINT' and "(HHP-DP)" in mod.name:
                            if mod.brush_settings:
                                dp_brush_mod = mod
                            if mod.canvas_settings:
                                dp_mod = mod
                    
                    # Add Dynamic Paint Brush settings if modifier exists
                    if dp_brush_mod and dp_brush_mod.brush_settings:
                        # Header for brush settings - updated label
                        col.label(text="Dynamic Paint Brush:", icon='BRUSH_DATA')
                        
                        brush = dp_brush_mod.brush_settings
                        
                        # First row: Paint source and distance (removed falloff)
                        row = col.row(align=True)
                        row.prop(brush, "paint_source", text="Source")
                        row.prop(brush, "paint_distance", text="Distance")
                        
                        # Second row: Smudge toggle, strength, and wave factor
                        row = col.row(align=True)
                        row.prop(brush, "use_smudge", text="Smudge", icon='MOD_SMOOTH')
                        row.prop(brush, "smudge_strength", text="Smudge Str")
                        row.prop(brush, "wave_factor", text="Wave Str")
                        
                        # Add separator after brush settings
                        col.separator()
                    
                    # Add Dynamic Paint settings if modifier exists
                    if dp_mod and dp_mod.canvas_settings and dp_mod.canvas_settings.canvas_surfaces:
                        # Header for dynamic paint section
                        col.label(text="Dynamic Paint:", icon='MOD_DYNAMICPAINT')
                        
                        # Get the surfaces
                        surfaces = dp_mod.canvas_settings.canvas_surfaces
                        
                        # Show settings for each surface
                        for i, surface in enumerate(surfaces):
                            if surface.surface_type == 'DISPLACE':
                                # New Displace surface type settings over three rows
                                row = col.row(align=True)
                                row.prop(surface, "is_active", text="Displace", icon='MOD_DISPLACE')
                                row.prop(surface, "brush_influence_scale", text="Influence")
                                row.prop(surface, "use_incremental_displace", text="Incremental", icon='CHECKBOX_HLT')
                                
                                row2 = col.row(align=True)
                                row2.prop(surface, "use_dissolve", text="Dissolve", icon='CHECKBOX_HLT')
                                row2.prop(surface, "dissolve_speed", text="Dissolve Time")
                                row2.prop(surface, "depth_clamp", text="Max Displace")
                                
                                row3 = col.row(align=True)
                                row3.prop(surface, "displace_factor", text="Displace Factor")
                                
                                # Add brush collection selector row with no label (full width)
                                brush_row = col.row(align=True)
                                brush_row.prop(surface, "brush_collection", text="", icon='OUTLINER_COLLECTION')
                            else:
                                row = col.row(align=True)
                                # Determine icon and label based on surface type
                                icon = 'GROUP_VCOL'
                                label = "Vertex Color"
                                
                                if surface.surface_type == 'WEIGHT':
                                    icon = 'MOD_VERTEX_WEIGHT'
                                    label = "Displace"
                                elif surface.surface_type == 'WAVE':
                                    icon = 'MOD_WAVE'
                                    label = "Wave"
                                
                                # Add toggle and settings
                                row.prop(surface, "is_active", text=label, icon=icon)
                                
                                if surface.surface_type == 'PAINT':
                                    row.prop(surface, "dry_speed", text="Dry")
                                    row.prop(surface, "use_drying", text="Use Drying", icon='TIME')
                                elif surface.surface_type == 'WEIGHT':
                                    row.prop(surface, "dissolve_speed", text="Dissolve Time")
                                    row.prop(surface, "use_dissolve", text="Dissolve", icon='CHECKBOX_HLT')
                                elif surface.surface_type == 'WAVE':
                                    # First row: Toggle, Influence, Timescale
                                    row.prop(surface, "brush_influence_scale", text="Influence")
                                    row.prop(surface, "wave_timescale", text="Timescale")
                                    
                                    # Second row: Damping, Smoothness, Speed
                                    wave_row = col.row(align=True)
                                    wave_row.prop(surface, "wave_damping", text="Damping")
                                    wave_row.prop(surface, "wave_smoothness", text="Smoothness")
                                    wave_row.prop(surface, "wave_speed", text="Speed")
                                
                                # Add brush collection selector for all surface types (full width)
                                brush_row = col.row(align=True)
                                brush_row.prop(surface, "brush_collection", text="", icon='OUTLINER_COLLECTION')
                            
                            if i < len(surfaces) - 1:
                                col.separator(factor=1.0)
                        
                        # Add separator after all dynamic paint settings
                        col.separator()
                    
                    # Find and add displace modifier controls
                    disp_mod = None
                    for mod in obj.modifiers:
                        if mod.type == 'DISPLACE' and "(HHP-DP)" in mod.name:
                            disp_mod = mod
                            break
                    
                    if disp_mod:
                        # Header for displacement section
                        col.label(text="Displacement:", icon='MOD_DISPLACE')
                        
                        # Strength, Midlevel, and Direction in an aligned row
                        row = col.row(align=True)
                        row.prop(disp_mod, "strength", text="Strength")
                        row.prop(disp_mod, "mid_level", text="Midlevel")
                        row.prop(disp_mod, "direction", text="")
                    
                    # Find and add corrective smooth modifier controls
                    corr_mod = None
                    for mod in obj.modifiers:
                        if mod.type == 'CORRECTIVE_SMOOTH' and "(HHP-DP)" in mod.name:
                            corr_mod = mod
                            break
                    
                    if corr_mod:
                        # Add some space between sections
                        if disp_mod:
                            col.separator()
                        
                        # Header for corrective smooth section
                        col.label(text="Corrective Smooth:", icon='MOD_SMOOTH')
                        
                        # Factor, Repeat, and Pin Boundaries in an aligned row
                        row = col.row(align=True)
                        row.prop(corr_mod, "factor", text="Factor")
                        row.prop(corr_mod, "iterations", text="Repeat")
                        # Use the correct property name for pin boundary and add an icon
                        row.prop(corr_mod, "use_pin_boundary", text="Pin Boundaries", icon='PINNED')
        
        # Create a column with align=True for the rebind and bake/free buttons (only when expanded)
        if context.window_manager.dynamics_paint_expanded:
            col = dp_box.column(align=True)
            
            # Add the Rebind button
            col.operator("object.rebind_dynamic_paint", text="Rebind Dynamic Paint", icon='FILE_REFRESH')
            # Add current cache bake/delete buttons
            row_current = col.row(align=True)
            ptcache_dynamic_paint_mixin = HHP_PTCacheDynamicPaintMixin()
            unbaked_canvas_count = ptcache_dynamic_paint_mixin.count_unbaked_canvas_caches(context)
            bake_text = f"Current Cache to Bake ({unbaked_canvas_count})" if unbaked_canvas_count else "Current Cache to Bake"
            bake_current_col = row_current.column(align=True)
            bake_current_col.enabled = unbaked_canvas_count > 0
            bake_current_col.operator("object.dynamics_ptcache_bake_current", text=bake_text, icon='RECOVER_LAST')
            baked_canvas_count = ptcache_dynamic_paint_mixin.count_baked_canvas_caches(context)
            delete_text = f"Delete Bake ({baked_canvas_count} Baked)" if baked_canvas_count else "Delete Bake"
            delete_menu_col = row_current.column(align=True)
            delete_menu_col.enabled = baked_canvas_count > 0
            delete_menu_col.alert = baked_canvas_count > 0
            delete_menu_col.operator("object.dynamics_ptcache_free_baked_menu", text="", icon='DOWNARROW_HLT')
            delete_col = row_current.column(align=True)
            delete_col.alert = baked_canvas_count > 0
            delete_col.operator("object.dynamics_ptcache_free_current", text=delete_text, icon='TRASH')
            
            # Add bake and free buttons in a row (within the aligned column)
            row = col.row(align=True)
            bake_all_text = f"Bake ({unbaked_canvas_count})" if unbaked_canvas_count else "Bake"
            bake_col = row.column(align=True)
            bake_col.enabled = unbaked_canvas_count > 0
            bake_col.operator("object.dynamics_ptcache_bake_menu", text=bake_all_text, icon='PHYSICS')
            row.operator("object.dynamics_ptcache_free_bake_all", text="Free All", icon='X')

# Registration
classes = (
    HHPDynamicsProps,
    OBJECT_OT_PtcacheBakeAll,
    OBJECT_OT_DynamicsPtcacheBakeOffline,
    OBJECT_OT_DynamicsPtcacheBakeMenu,
    OBJECT_OT_PtcacheFreeBakeAll,
    OBJECT_OT_DynamicsPtcacheBakeCurrent,
    OBJECT_OT_DynamicsPtcacheFreeCurrent,
    OBJECT_OT_DynamicsPtcacheFreeBakedMenu,
    OBJECT_OT_DynamicsPtcacheFreeBakedItem,
    OBJECT_OT_DynamicsSwitchToOriginalMaterials,
    OBJECT_OT_OpenShaderLayerVFX,
    DYNAMICS_HHP_PT_Panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    # Register the property group
    bpy.types.Scene.hhp_dynamics_props = bpy.props.PointerProperty(type=HHPDynamicsProps)
    # WindowManager expand/collapse states, expanded by default
    wm = bpy.types.WindowManager
    wm.dynamics_fluids_expanded = bpy.props.BoolProperty(
        name="Dynamics Fluids Expanded",
        description="Whether the Human Fluids section is expanded",
        default=True
    )
    wm.dynamics_paint_expanded = bpy.props.BoolProperty(
        name="Dynamics Paint Expanded",
        description="Whether the Dynamic Paint section is expanded",
        default=True
    )
    # Import and register modules
    from .modules import CMN_setup
    CMN_setup.register()

def unregister():
    # Unregister the property group
    del bpy.types.Scene.hhp_dynamics_props
    # Remove WindowManager props
    wm = bpy.types.WindowManager
    del wm.dynamics_fluids_expanded
    del wm.dynamics_paint_expanded
    # Unregister modules
    from .modules import CMN_setup
    CMN_setup.unregister()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
