import bpy
from bpy.types import Panel, Operator

# First, we need to add a property to store the visibility state
class HHPDynamicsProps(bpy.types.PropertyGroup):
    show_settings: bpy.props.BoolProperty(
        name="Show Settings",
        description="Show detailed dynamic paint and modifier settings",
        default=True
    )
    
    fluid_mode: bpy.props.EnumProperty(
        name="Fluid Mode",
        description="Select which fluid system to use",
        items=[
            ('BLENDER', "Blender Default", "Use Blender's built-in fluid simulation system"),
            ('FLIP', "Flip Fluids", "Use the Flip Fluids addon (must be installed)"),
        ],
        default='BLENDER'
    )

class OBJECT_OT_PtcacheBakeAll(Operator):
    bl_idname = "object.dynamics_ptcache_bake_all"
    bl_label = "Bake All Physics"
    bl_description = "Bake all physics simulations in the scene"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        bpy.ops.ptcache.bake_all(bake=True)
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=400)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="WARNING: This will bake ALL physics in the scene including:")
        layout.label(text="• Cloth, Soft Body, and Rigid Body simulations")
        layout.label(text="• Dynamic Paint, Fluid, and Particle systems")
        layout.label(text="A final bake should only be initiated at the very end of the project.")
        layout.label(text="Are you sure you want to continue?", icon='ERROR')

class OBJECT_OT_PtcacheFreeBakeAll(Operator):
    bl_idname = "object.dynamics_ptcache_free_bake_all"
    bl_label = "Free All Bakes"
    bl_description = "Free all baked physics simulations in the scene"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        bpy.ops.ptcache.free_bake_all()
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=400)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="WARNING: This will delete ALL baked physics data in the scene:")
        layout.label(text="• All Dynamic Paint and physics simulation caches will be lost")
        layout.label(text="• You will need to rebake everything after this operation")
        layout.label(text="Are you sure you want to continue?", icon='ERROR')


class HHP_PTCacheDynamicPaintMixin:
    """Utility mixin to gather Dynamic Paint canvas caches and run ptcache ops."""

    def collect_canvas_caches(self, context):
        """Return enabled HHP-DP canvas caches: (object, surface, point_cache)."""
        caches = []
        seen = set()
        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue
            for mod in obj.modifiers:
                if mod.type != 'DYNAMIC_PAINT' or "(HHP-DP)" not in mod.name:
                    continue
                # Respect modifier enable state
                if not (mod.show_viewport and mod.show_render):
                    continue
                canvas = getattr(mod, "canvas_settings", None)
                if not canvas or not getattr(canvas, "canvas_surfaces", None):
                    continue
                for surface in canvas.canvas_surfaces:
                    # Only bake/free enabled surfaces
                    if not surface.is_active:
                        continue
                    cache = getattr(surface, "point_cache", None)
                    if cache and id(cache) not in seen:
                        seen.add(id(cache))
                        caches.append((obj, surface, cache))
        return caches

    def get_view3d_override(self, context):
        window = getattr(context, "window", None)
        screen = getattr(window, "screen", None) if window else None
        if not screen:
            return None
        area = next((a for a in screen.areas if a.type == 'VIEW_3D'), None)
        if not area:
            return None
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        space_data = area.spaces.active if area.spaces else None
        if not (region and space_data):
            return None
        return {
            "window": window,
            "screen": screen,
            "area": area,
            "region": region,
            "space_data": space_data,
        }

    def _run_on_canvas_caches(self, context, op_callable):
        caches = self.collect_canvas_caches(context)
        if not caches:
            return caches, []

        view_layer = context.view_layer
        original_active = view_layer.objects.active
        original_mode = context.mode
        original_selection = list(context.selected_objects)
        failures = []

        try:
            for obj, surface, cache in caches:
                bpy.ops.object.select_all(action='DESELECT')
                obj.select_set(True)
                view_layer.objects.active = obj

                try:
                    if obj.mode != 'OBJECT':
                        res = bpy.ops.object.mode_set(mode='OBJECT')
                        if isinstance(res, set) and 'FINISHED' not in res:
                            failures.append((obj.name, surface.name, "Failed to enter OBJECT mode"))
                            continue
                except Exception as exc:
                    failures.append((obj.name, surface.name, f"Failed to enter OBJECT mode: {exc}"))
                    continue

                override = {
                    "view_layer": view_layer,
                    "active_object": obj,
                    "selected_objects": [obj],
                    "object": obj,
                    "point_cache": cache,
                }
                view3d_override = self.get_view3d_override(context)
                if view3d_override:
                    override.update(view3d_override)

                try:
                    with context.temp_override(**override):
                        res = op_callable()
                        if isinstance(res, set) and 'FINISHED' not in res:
                            failures.append((obj.name, surface.name, "Operator cancelled"))
                except Exception as exc:
                    failures.append((obj.name, surface.name, str(exc)))
        finally:
            bpy.ops.object.select_all(action='DESELECT')
            for obj in original_selection:
                obj.select_set(True)
            if original_active:
                view_layer.objects.active = original_active
            try:
                if original_mode != context.mode:
                    bpy.ops.object.mode_set(mode=original_mode)
            except Exception:
                pass

        return caches, failures


class OBJECT_OT_DynamicsPtcacheBakeCurrent(HHP_PTCacheDynamicPaintMixin, Operator):
    bl_idname = "object.dynamics_ptcache_bake_current"
    bl_label = "Current Cache to Bake"
    bl_description = "Bake current cache for Dynamic Paint canvases on selected meshes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        caches, failures = self._run_on_canvas_caches(context, lambda: bpy.ops.ptcache.bake_from_cache())
        if not caches:
            self.report({'WARNING'}, "No HHP-DP Dynamic Paint canvases found on selected meshes")
            return {'CANCELLED'}

        if failures:
            detail = "; ".join(f"{obj}: {surface}: {reason}" for obj, surface, reason in failures)
            self.report({'WARNING'}, f"Baked {len(caches) - len(failures)} caches, {len(failures)} failed ({detail})")
        else:
            self.report({'INFO'}, f"Baked current cache for {len(caches)} Dynamic Paint surface(s)")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


class OBJECT_OT_DynamicsPtcacheFreeCurrent(HHP_PTCacheDynamicPaintMixin, Operator):
    bl_idname = "object.dynamics_ptcache_free_current"
    bl_label = "Delete Bake"
    bl_description = "Delete baked cache for Dynamic Paint canvases on selected meshes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        caches, failures = self._run_on_canvas_caches(context, lambda: bpy.ops.ptcache.free_bake())
        if not caches:
            self.report({'WARNING'}, "No HHP-DP Dynamic Paint canvases found on selected meshes")
            return {'CANCELLED'}

        if failures:
            detail = "; ".join(f"{obj}: {surface}: {reason}" for obj, surface, reason in failures)
            self.report({'WARNING'}, f"Deleted bake on {len(caches) - len(failures)} caches, {len(failures)} failed ({detail})")
        else:
            self.report({'INFO'}, f"Deleted bakes for {len(caches)} Dynamic Paint surface(s)")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

class DYNAMICS_HHP_PT_Panel(Panel):
    bl_label = "Dynamics"
    bl_idname = "DYNAMICS_HHP_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'
    bl_parent_id = "CHAR_HHP_PT_Panel"
    bl_options = {'HIDE_HEADER'}  # Completely hide the panel header
    
    @classmethod
    def poll(cls, context):
        # Only show this panel when the Dynamics mode is selected
        return context.scene.hhp_panel_mode.selected_panel == 'DYNAMICS'
    
    def draw(self, context):
        layout = self.layout
        wm = context.window_manager

        # Read debug mode from addon preferences (stored on the main package)
        addon_prefs_entry = context.preferences.addons.get(__package__)
        debug_enabled = bool(addon_prefs_entry and getattr(addon_prefs_entry.preferences, "debug_mode", False))

        # If debug is disabled, force the Human Fluids section closed
        if not debug_enabled:
            wm.dynamics_fluids_expanded = False

        main_col = layout.column(align=True)
        
        # Human Fluids (collapsible)
        fluids_box = main_col.box()
        # Grey out the Human Fluids box when debug mode is off
        fluids_box.enabled = debug_enabled

        fluids_header = fluids_box.row(align=True)
        fluids_header.alignment = 'LEFT'
        icon = 'TRIA_DOWN' if wm.dynamics_fluids_expanded else 'TRIA_RIGHT'
        fluids_header.prop(wm, "dynamics_fluids_expanded", text="", icon=icon, emboss=False, icon_only=True)
        fluids_header.prop(
            wm,
            "dynamics_fluids_expanded",
            text="Human Fluids (Still in Development)",
            icon='PHYSICS',
            emboss=False
        )

        if wm.dynamics_fluids_expanded:
            # Add fluid mode selector above the setup button
            col = fluids_box.column(align=True)
            row = col.row(align=True)
            row.prop(context.scene.hhp_dynamics_props, "fluid_mode", expand=True)
            
            # Add CMN button in the Human Fluids box
            col.operator("object.setup_cmn_simulation", text="Setup Simulation (White fluid - CMN)", icon='PHYSICS')
        
        # Dynamic Paint (collapsible)
        dp_box = main_col.box()
        dp_header = dp_box.row(align=True)
        dp_header.alignment = 'LEFT'
        icon = 'TRIA_DOWN' if context.window_manager.dynamics_paint_expanded else 'TRIA_RIGHT'
        dp_header.prop(context.window_manager, "dynamics_paint_expanded", text="", icon=icon, emboss=False, icon_only=True)
        dp_header.prop(context.window_manager, "dynamics_paint_expanded", text="Dynamic Paint", icon='MOD_DYNAMICPAINT', emboss=False)

        if context.window_manager.dynamics_paint_expanded:
            # Create a row for the two buttons to be side by side inside the box
            row = dp_box.row(align=True)
            row.operator("object.dynamic_pressure_canvas", text="Dynamic Paint (Canvas)", icon='MOD_DYNAMICPAINT')
            row.operator("object.dynamic_pressure_brush", text="Dynamic Paint (Brush)", icon='BRUSH_DATA')
        
        # Add dynamic controls for selected objects with HHP-DP modifiers
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        # Check if any selected objects have relevant modifiers before displaying the section
        has_relevant_modifiers = False
        for obj in selected_objects:
            for mod in obj.modifiers:
                if "(HHP-DP)" in mod.name:
                    has_relevant_modifiers = True
                    break
            if has_relevant_modifiers:
                break
        
        if context.window_manager.dynamics_paint_expanded and has_relevant_modifiers:
            # Create a settings header box with toggle
            settings_box = dp_box.box()
            header_row = settings_box.row()
            header_row.label(text="Settings", icon='MODIFIER')
            header_row.prop(context.scene.hhp_dynamics_props, "show_settings", text="", icon='SETTINGS', emboss=True)
            
            # Only show settings if the toggle is on
            if context.scene.hhp_dynamics_props.show_settings:
                # For each object with relevant modifiers
                for obj in selected_objects:
                    # Check if this object has any HHP-DP modifiers
                    has_hhp_modifiers = False
                    for mod in obj.modifiers:
                        if "(HHP-DP)" in mod.name:
                            has_hhp_modifiers = True
                            break
                    
                    if not has_hhp_modifiers:
                        continue
                    
                    # Create a box for this object
                    obj_box = settings_box.box()
                    obj_box.label(text=f"{obj.name}", icon='OBJECT_DATA')
                    
                    col = obj_box.column(align=True)
                    
                    # Find Dynamic Paint modifier
                    dp_mod = None
                    dp_brush_mod = None
                    for mod in obj.modifiers:
                        if mod.type == 'DYNAMIC_PAINT' and "(HHP-DP)" in mod.name:
                            if mod.brush_settings:
                                dp_brush_mod = mod
                            if mod.canvas_settings:
                                dp_mod = mod
                    
                    # Add Dynamic Paint Brush settings if modifier exists
                    if dp_brush_mod and dp_brush_mod.brush_settings:
                        # Header for brush settings - updated label
                        col.label(text="Dynamic Paint Brush:", icon='BRUSH_DATA')
                        
                        brush = dp_brush_mod.brush_settings
                        
                        # First row: Paint source and distance (removed falloff)
                        row = col.row(align=True)
                        row.prop(brush, "paint_source", text="Source")
                        row.prop(brush, "paint_distance", text="Distance")
                        
                        # Second row: Smudge toggle, strength, and wave factor
                        row = col.row(align=True)
                        row.prop(brush, "use_smudge", text="Smudge", icon='MOD_SMOOTH')
                        row.prop(brush, "smudge_strength", text="Smudge Str")
                        row.prop(brush, "wave_factor", text="Wave Str")
                        
                        # Add separator after brush settings
                        col.separator()
                    
                    # Add Dynamic Paint settings if modifier exists
                    if dp_mod and dp_mod.canvas_settings and dp_mod.canvas_settings.canvas_surfaces:
                        # Header for dynamic paint section
                        col.label(text="Dynamic Paint:", icon='MOD_DYNAMICPAINT')
                        
                        # Get the surfaces
                        surfaces = dp_mod.canvas_settings.canvas_surfaces
                        
                        # Show settings for each surface
                        for i, surface in enumerate(surfaces):
                            if surface.surface_type == 'DISPLACE':
                                # New Displace surface type settings over three rows
                                row = col.row(align=True)
                                row.prop(surface, "is_active", text="Displace", icon='MOD_DISPLACE')
                                row.prop(surface, "brush_influence_scale", text="Influence")
                                row.prop(surface, "use_incremental_displace", text="Incremental", icon='CHECKBOX_HLT')
                                
                                row2 = col.row(align=True)
                                row2.prop(surface, "use_dissolve", text="Dissolve", icon='CHECKBOX_HLT')
                                row2.prop(surface, "dissolve_speed", text="Dissolve Time")
                                row2.prop(surface, "depth_clamp", text="Max Displace")
                                
                                row3 = col.row(align=True)
                                row3.prop(surface, "displace_factor", text="Displace Factor")
                                
                                # Add brush collection selector row with no label (full width)
                                brush_row = col.row(align=True)
                                brush_row.prop(surface, "brush_collection", text="", icon='OUTLINER_COLLECTION')
                            else:
                                row = col.row(align=True)
                                # Determine icon and label based on surface type
                                icon = 'GROUP_VCOL'
                                label = "Vertex Color"
                                
                                if surface.surface_type == 'WEIGHT':
                                    icon = 'MOD_VERTEX_WEIGHT'
                                    label = "Displace"
                                elif surface.surface_type == 'WAVE':
                                    icon = 'MOD_WAVE'
                                    label = "Wave"
                                
                                # Add toggle and settings
                                row.prop(surface, "is_active", text=label, icon=icon)
                                
                                if surface.surface_type == 'PAINT':
                                    row.prop(surface, "dry_speed", text="Dry")
                                    row.prop(surface, "use_drying", text="Use Drying", icon='TIME')
                                elif surface.surface_type == 'WEIGHT':
                                    row.prop(surface, "dissolve_speed", text="Dissolve Time")
                                    row.prop(surface, "use_dissolve", text="Dissolve", icon='CHECKBOX_HLT')
                                elif surface.surface_type == 'WAVE':
                                    # First row: Toggle, Influence, Timescale
                                    row.prop(surface, "brush_influence_scale", text="Influence")
                                    row.prop(surface, "wave_timescale", text="Timescale")
                                    
                                    # Second row: Damping, Smoothness, Speed
                                    wave_row = col.row(align=True)
                                    wave_row.prop(surface, "wave_damping", text="Damping")
                                    wave_row.prop(surface, "wave_smoothness", text="Smoothness")
                                    wave_row.prop(surface, "wave_speed", text="Speed")
                                
                                # Add brush collection selector for all surface types (full width)
                                brush_row = col.row(align=True)
                                brush_row.prop(surface, "brush_collection", text="", icon='OUTLINER_COLLECTION')
                            
                            if i < len(surfaces) - 1:
                                col.separator(factor=1.0)
                        
                        # Add separator after all dynamic paint settings
                        col.separator()
                    
                    # Find and add displace modifier controls
                    disp_mod = None
                    for mod in obj.modifiers:
                        if mod.type == 'DISPLACE' and "(HHP-DP)" in mod.name:
                            disp_mod = mod
                            break
                    
                    if disp_mod:
                        # Header for displacement section
                        col.label(text="Displacement:", icon='MOD_DISPLACE')
                        
                        # Strength, Midlevel, and Direction in an aligned row
                        row = col.row(align=True)
                        row.prop(disp_mod, "strength", text="Strength")
                        row.prop(disp_mod, "mid_level", text="Midlevel")
                        row.prop(disp_mod, "direction", text="")
                    
                    # Find and add corrective smooth modifier controls
                    corr_mod = None
                    for mod in obj.modifiers:
                        if mod.type == 'CORRECTIVE_SMOOTH' and "(HHP-DP)" in mod.name:
                            corr_mod = mod
                            break
                    
                    if corr_mod:
                        # Add some space between sections
                        if disp_mod:
                            col.separator()
                        
                        # Header for corrective smooth section
                        col.label(text="Corrective Smooth:", icon='MOD_SMOOTH')
                        
                        # Factor, Repeat, and Pin Boundaries in an aligned row
                        row = col.row(align=True)
                        row.prop(corr_mod, "factor", text="Factor")
                        row.prop(corr_mod, "iterations", text="Repeat")
                        # Use the correct property name for pin boundary and add an icon
                        row.prop(corr_mod, "use_pin_boundary", text="Pin Boundaries", icon='PINNED')
        
        # Create a column with align=True for the rebind and bake/free buttons (only when expanded)
        if context.window_manager.dynamics_paint_expanded:
            col = dp_box.column(align=True)
            
            # Add the Rebind button
            col.operator("object.rebind_dynamic_paint", text="Rebind Dynamic Paint", icon='FILE_REFRESH')
            # Add current cache bake/delete buttons
            row_current = col.row(align=True)
            row_current.operator("object.dynamics_ptcache_bake_current", text="Current Cache to Bake", icon='RECOVER_LAST')
            row_current.operator("object.dynamics_ptcache_free_current", text="Delete Bake", icon='TRASH')
            
            # Add bake and free buttons in a row (within the aligned column)
            row = col.row(align=True)
            row.operator("object.dynamics_ptcache_bake_all", text="Bake All", icon='PHYSICS')
            row.operator("object.dynamics_ptcache_free_bake_all", text="Free All", icon='X')

# Registration
classes = (
    HHPDynamicsProps,
    OBJECT_OT_PtcacheBakeAll,
    OBJECT_OT_PtcacheFreeBakeAll,
    OBJECT_OT_DynamicsPtcacheBakeCurrent,
    OBJECT_OT_DynamicsPtcacheFreeCurrent,
    DYNAMICS_HHP_PT_Panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    # Register the property group
    bpy.types.Scene.hhp_dynamics_props = bpy.props.PointerProperty(type=HHPDynamicsProps)
    # WindowManager expand/collapse states, expanded by default
    wm = bpy.types.WindowManager
    wm.dynamics_fluids_expanded = bpy.props.BoolProperty(
        name="Dynamics Fluids Expanded",
        description="Whether the Human Fluids section is expanded",
        default=True
    )
    wm.dynamics_paint_expanded = bpy.props.BoolProperty(
        name="Dynamics Paint Expanded",
        description="Whether the Dynamic Paint section is expanded",
        default=True
    )
    # Import and register modules
    from .modules import CMN_setup
    CMN_setup.register()

def unregister():
    # Unregister the property group
    del bpy.types.Scene.hhp_dynamics_props
    # Remove WindowManager props
    wm = bpy.types.WindowManager
    del wm.dynamics_fluids_expanded
    del wm.dynamics_paint_expanded
    # Unregister modules
    from .modules import CMN_setup
    CMN_setup.unregister()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
