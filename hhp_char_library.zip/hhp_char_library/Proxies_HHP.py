import bpy
from bpy.props import BoolProperty

# Define getter and setter functions for the collection custom property
def get_show_collection(self):
    return not self.hide_viewport

def set_show_collection(self, value):
    self.hide_viewport = not value

class OBJECT_OT_ToggleModifierVisibility(bpy.types.Operator):
    bl_idname = "object.toggle_modifier_visibility"
    bl_label = "Toggle Modifier Visibility"
    bl_description = "Toggle the visibility of a modifier in both viewport and render"

    object_name: bpy.props.StringProperty()
    modifier_name: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        if obj is None:
            self.report({'ERROR'}, f"Object '{self.object_name}' not found")
            return {'CANCELLED'}
        mod = obj.modifiers.get(self.modifier_name)
        if mod is None:
            self.report({'ERROR'}, f"Modifier '{self.modifier_name}' not found on object '{self.object_name}'")
            return {'CANCELLED'}

        new_state = not (mod.show_viewport and mod.show_render)
        mod.show_viewport = new_state
        mod.show_render = new_state

        # If the modifier is being enabled, make sure the target mesh is visible
        if new_state:
            target_obj = None
            # For Mesh Deform and Surface Deform modifiers
            if mod.type == 'MESH_DEFORM':
                target_obj = mod.object
            elif mod.type == 'SURFACE_DEFORM':
                target_obj = mod.target

            if target_obj:
                # Make the target object visible in viewport
                target_obj.hide_viewport = False

                # Make sure the collections the target object is in are visible
                for collection in target_obj.users_collection:
                    self.make_collection_visible(collection)
        return {'FINISHED'}

    def make_collection_visible(self, collection):
        # Make this collection visible
        collection.hide_viewport = False
        # Recursively make parent collections visible
        parent_collections = [
            parent for parent in bpy.data.collections if collection.name in parent.children.keys()
        ]
        for parent in parent_collections:
            self.make_collection_visible(parent)

class OBJECT_OT_BindUnbindHHPModifiers(bpy.types.Operator):
    bl_idname = "object.bind_unbind_hhp_modifiers"
    bl_label = "Rebind Modifiers"
    bl_description = "Update and rebind (HHP) physics to scene"

    def execute(self, context):
        # Stop the animation playback
        bpy.ops.screen.animation_cancel(restore_frame=False)

        # Go to the scene start frame
        context.scene.frame_set(context.scene.frame_start)

        # Set playback method to 'Play Every Frame'
        context.scene.sync_mode = 'NONE'

        # Store the initial selection and active object
        initial_selection = context.selected_objects.copy()
        initial_active = context.view_layer.objects.active

        # Create an empty list to store new selections (Surface Deform and Mesh Deform targets)
        new_selection = []

        # Dictionaries to store original states
        modifier_states = {}
        target_object_states = {}
        collection_states = {}

        # Function to recursively collect parent collections
        def get_all_parent_collections(collection):
            parent_collections = []
            for parent in bpy.data.collections:
                if collection.name in parent.children.keys():
                    parent_collections.append(parent)
                    parent_collections.extend(get_all_parent_collections(parent))
            return parent_collections

        # Iterate over all initially selected objects
        for obj in initial_selection:
            # Check if the object has any modifiers
            if obj.modifiers:
                for mod in obj.modifiers:
                    # Process only modifiers that start with "(HHP)"
                    if mod.name.startswith('(HHP)'):
                        # Store the modifier's show_viewport and show_render states
                        modifier_states[(obj.name, mod.name)] = (mod.show_viewport, mod.show_render)

                        # Enable the modifier
                        mod.show_viewport = True
                        mod.show_render = True

                        # If the modifier is a Surface Deform or Mesh Deform modifier, select its target/object
                        target_obj = None
                        if mod.type == 'SURFACE_DEFORM' and mod.target:
                            target_obj = mod.target
                        elif mod.type == 'MESH_DEFORM' and mod.object:
                            target_obj = mod.object

                        if target_obj:
                            # Store the target object's visibility state if not already stored
                            if target_obj.name not in target_object_states:
                                target_object_states[target_obj.name] = (
                                    target_obj.hide_viewport, target_obj.hide_render
                                )

                            # Make the target object visible
                            target_obj.hide_viewport = False
                            target_obj.hide_render = False
                            target_obj.select_set(True)
                            new_selection.append(target_obj)

                            # Store and enable the collections and parent collections
                            for collection in target_obj.users_collection:
                                # Collect all parent collections
                                all_collections = [collection] + get_all_parent_collections(collection)
                                for col in all_collections:
                                    if col.name not in collection_states:
                                        collection_states[col.name] = col.hide_viewport
                                        col.hide_viewport = False

        # Deselect the initial objects
        for obj in initial_selection:
            obj.select_set(False)

        # If we have new objects to select, make one active and run the cache update script before entering edit mode
        if new_selection:
            # Set the first object in the new selection as the active object
            context.view_layer.objects.active = new_selection[0]

            # Run the cache settings update on the selected objects
            # Get the start and end frames from the timeline
            start_frame = context.scene.frame_start
            end_frame = context.scene.frame_end

            # Function to update cache settings of physics modifiers
            def update_cache_settings(obj, start_frame, end_frame):
                for mod in obj.modifiers:
                    if mod.type in {
                        'CLOTH', 'SOFT_BODY', 'FLUID', 'DYNAMIC_PAINT', 'SMOKE', 'PARTICLE_SYSTEM', 'COLLISION'
                    }:
                        if hasattr(mod, 'point_cache'):
                            mod.point_cache.frame_start = start_frame
                            mod.point_cache.frame_end = end_frame
                        if hasattr(mod, 'cache'):
                            mod.cache.frame_start = start_frame
                            mod.cache.frame_end = end_frame

            # Iterate over all objects in new_selection
            for obj in new_selection:
                if obj.type == 'MESH':
                    update_cache_settings(obj, start_frame, end_frame)

            # Enter and immediately exit edit mode
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')

        # Deselect all objects to start fresh
        bpy.ops.object.select_all(action='DESELECT')

        # Restore the initial selection
        for obj in initial_selection:
            obj.select_set(True)

        # Restore the initial active object
        context.view_layer.objects.active = initial_active

        # Define the variables
        rebind_at_start = True  # You can change this later
        viewport_enabled = True  # Control whether to include viewport-disabled modifiers
        render_enabled = True    # Control whether to include render-disabled modifiers

        def unbind_modifiers(obj):
            for modifier in obj.modifiers:
                # Process only modifiers that start with "(HHP)"
                if not modifier.name.startswith('(HHP)'):
                    continue

                if viewport_enabled and not modifier.show_viewport:
                    continue  # Skip modifiers disabled in viewport
                if render_enabled and not modifier.show_render:
                    continue  # Skip modifiers disabled in render
                if modifier.type == 'MESH_DEFORM' and modifier.is_bound:
                    context.view_layer.objects.active = obj
                    bpy.ops.object.meshdeform_bind(modifier=modifier.name)
                elif modifier.type == 'SURFACE_DEFORM' and modifier.is_bound:
                    context.view_layer.objects.active = obj
                    bpy.ops.object.surfacedeform_bind(modifier=modifier.name)
                elif modifier.type == 'CORRECTIVE_SMOOTH' and modifier.is_bind:
                    context.view_layer.objects.active = obj
                    bpy.ops.object.correctivesmooth_bind(modifier=modifier.name)

        def unbind_modifiers_from_selected():
            selected_objects = context.selected_objects
            for obj in selected_objects:
                unbind_modifiers(obj)

        def bind_modifiers(obj):
            # Store the original active object
            original_active_object = context.view_layer.objects.active

            # Make the object active
            context.view_layer.objects.active = obj

            # Iterate over the modifiers in the same order as the modifier stack
            for modifier in obj.modifiers:
                # Process only modifiers that start with "(HHP)"
                if not modifier.name.startswith('(HHP)'):
                    continue

                if viewport_enabled and not modifier.show_viewport:
                    continue  # Skip modifiers disabled in viewport
                if render_enabled and not modifier.show_render:
                    continue  # Skip modifiers disabled in render
                if modifier.type == 'MESH_DEFORM' and not modifier.is_bound:
                    bpy.ops.object.meshdeform_bind(modifier=modifier.name)
                elif modifier.type == 'SURFACE_DEFORM' and not modifier.is_bound:
                    bpy.ops.object.surfacedeform_bind(modifier=modifier.name)
                elif modifier.type == 'CORRECTIVE_SMOOTH' and not modifier.is_bind:
                    bpy.ops.object.correctivesmooth_bind(modifier=modifier.name)

            # Restore the original active object
            context.view_layer.objects.active = original_active_object

        def bind_modifiers_from_selected():
            selected_objects = context.selected_objects
            for obj in selected_objects:
                bind_modifiers(obj)

        try:
            # Unbind the modifiers from all selected objects
            unbind_modifiers_from_selected()

            # Bind the modifiers to all selected objects
            bind_modifiers_from_selected()
        finally:
            # Restore the modifier states
            for (obj_name, mod_name), (show_viewport, show_render) in modifier_states.items():
                obj = bpy.data.objects.get(obj_name)
                if obj:
                    mod = obj.modifiers.get(mod_name)
                    if mod:
                        mod.show_viewport = show_viewport
                        mod.show_render = show_render

            # Restore the hide_viewport and hide_render states of target objects
            for obj_name, (hide_viewport, hide_render) in target_object_states.items():
                obj = bpy.data.objects.get(obj_name)
                if obj:
                    obj.hide_viewport = hide_viewport
                    obj.hide_render = hide_render

            # Restore the hide_viewport states of collections
            for col_name, hide_viewport in collection_states.items():
                col = bpy.data.collections.get(col_name)
                if col:
                    col.hide_viewport = hide_viewport

        return {'FINISHED'}

class OBJECT_OT_PtcacheBakeAll(bpy.types.Operator):
    bl_idname = "object.ptcache_bake_all"
    bl_label = "Bake All Physics"
    bl_description = "Bake all physics simulations in the scene"

    def execute(self, context):
        bpy.ops.ptcache.bake_all(bake=True)
        return {'FINISHED'}

class OBJECT_OT_PtcacheFreeBakeAll(bpy.types.Operator):
    bl_idname = "object.ptcache_free_bake_all"
    bl_label = "Free All Bakes"
    bl_description = "Free all baked physics simulations in the scene"

    def execute(self, context):
        bpy.ops.ptcache.free_bake_all()
        return {'FINISHED'}

class OBJECT_PT_ProxiesVisibilityPanel(bpy.types.Panel):
    """Panel to reflect and toggle visibility of 'Proxies (HHP)' collections with clickable text and greyed out subcollections."""
    bl_label = "Proxies (HHP)"
    bl_idname = "OBJECT_PT_proxies_visibility_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'  # Ensure this matches the 'Char (HHP)' category
    bl_order = 10  # Place it after the 'Char (HHP)' panel
    bl_options = {'DEFAULT_CLOSED'}  # Panel is closed by default

    def draw(self, context):
        layout = self.layout

        # Proxies list as in your provided script
        proxies_collections = self.find_proxies_collections()

        # Use a grid flow for the proxies list
        col = layout.column(align=True)
        flow = col.grid_flow(row_major=True, columns=1, even_columns=False, even_rows=False, align=True)

        for collection, level, parent_hidden, is_top_level in proxies_collections:
            row = flow.row(align=True)
            clean_name = collection.name.split(".")[0]

            # Set the icon
            icon = 'NONE' if is_top_level else 'DOT'

            # Set the active state (greyed out appearance)
            row.active = True if is_top_level else not parent_hidden

            # Display the custom property as a toggle button with clickable text and icon
            row.prop(collection, "show_collection", text=clean_name, toggle=True, icon=icon)

        # Collect modifiers into a list
        modifiers_list = []
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                for mod in obj.modifiers:
                    if mod.type in {'MESH_DEFORM', 'SURFACE_DEFORM'}:
                        if mod.name.startswith("(HHP) SurfaceDeform - ") or mod.name.startswith("(HHP) MeshDeform - "):
                            # Extract the display name after "- "
                            mod_display_name = mod.name.split("- ", 1)[1] if "- " in mod.name else mod.name
                            modifiers_list.append((obj, mod, mod_display_name))

        if modifiers_list:
            # Now, create the modifier box and arrange the buttons
            modifier_box = layout.box()
            modifier_box.label(text="Physics", icon='MODIFIER')

            # Arrange buttons in 2 columns
            col = modifier_box.column(align=True)
            row = None  # Initialize row variable
            for index, (obj, mod, mod_display_name) in enumerate(modifiers_list):
                if index % 2 == 0:
                    # Start a new row every 2 buttons
                    row = col.row(align=True)
                # Create an operator button to toggle the modifier visibility
                op = row.operator(
                    "object.toggle_modifier_visibility",
                    text=mod_display_name,
                    depress=mod.show_viewport and mod.show_render  # Makes the button glow blue when enabled
                )
                op.object_name = obj.name
                op.modifier_name = mod.name

            # Add a separator
            col.separator()

            # Add the new button to rebind modifiers
            col.operator(
                "object.bind_unbind_hhp_modifiers",
                text="Rebind Physics",
                icon='FILE_REFRESH'
            )

            # Add the new buttons for baking and freeing cache
            row = col.row(align=True)
            row.operator("object.ptcache_bake_all", text="Bake All", icon='PHYSICS')
            row.operator("object.ptcache_free_bake_all", text="Free All", icon='X')

    def collect_collections(self, collection, collection_list, parent_hidden=False, is_top_level=False, processed_collections=None):
        if processed_collections is None:
            processed_collections = set()
        if collection in processed_collections:
            return
        processed_collections.add(collection)

        collection_list.append((collection, 0, parent_hidden, is_top_level))

        # Determine if current parent is hidden
        current_parent_hidden = parent_hidden or collection.hide_viewport

        # Process children collections
        for child in collection.children:
            self.collect_collections(
                child,
                collection_list,
                parent_hidden=current_parent_hidden,
                is_top_level=False,
                processed_collections=processed_collections
            )

    def find_proxies_collections(self):
        """Find all 'Proxies (HHP)' collections inside the parent collections of selected meshes."""
        proxies_collections = []
        processed_collections = set()

        # Collect parent collections of selected meshes
        parent_collections = set()
        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH':
                parent_collections.update(obj.users_collection)

        # Traverse parent collections in order
        for collection in bpy.data.collections:
            if collection in parent_collections:
                for sub_collection in collection.children:
                    if sub_collection.name.startswith("Proxies (HHP)") and sub_collection not in processed_collections:
                        self.collect_collections(
                            sub_collection,
                            proxies_collections,
                            parent_hidden=False,
                            is_top_level=True,
                            processed_collections=processed_collections
                        )
        return proxies_collections

    def make_collection_visible(self, collection):
        # Make this collection visible
        collection.hide_viewport = False
        # Recursively make parent collections visible
        parent_collections = [
            parent for parent in bpy.data.collections if collection.name in parent.children.keys()
        ]
        for parent in parent_collections:
            self.make_collection_visible(parent)

def register():
    # Add the custom property to bpy.types.Collection
    bpy.types.Collection.show_collection = BoolProperty(
        name="",
        description="Toggle Collection Visibility",
        get=get_show_collection,
        set=set_show_collection
    )
    bpy.utils.register_class(OBJECT_OT_ToggleModifierVisibility)
    bpy.utils.register_class(OBJECT_OT_BindUnbindHHPModifiers)
    bpy.utils.register_class(OBJECT_OT_PtcacheBakeAll)
    bpy.utils.register_class(OBJECT_OT_PtcacheFreeBakeAll)
    bpy.utils.register_class(OBJECT_PT_ProxiesVisibilityPanel)

def unregister():
    bpy.utils.unregister_class(OBJECT_PT_ProxiesVisibilityPanel)
    bpy.utils.unregister_class(OBJECT_OT_PtcacheFreeBakeAll)
    bpy.utils.unregister_class(OBJECT_OT_PtcacheBakeAll)
    bpy.utils.unregister_class(OBJECT_OT_BindUnbindHHPModifiers)
    bpy.utils.unregister_class(OBJECT_OT_ToggleModifierVisibility)
    # Remove the custom property from bpy.types.Collection
    del bpy.types.Collection.show_collection

if __name__ == "__main__":
    register()
