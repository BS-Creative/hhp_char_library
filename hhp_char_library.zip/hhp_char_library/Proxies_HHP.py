import bpy
from bpy.props import BoolProperty, StringProperty, PointerProperty, IntProperty, FloatProperty
from bpy.types import PropertyGroup, UIList
import json
import re

# Define getter and setter functions for the collection custom property
def get_show_collection(self):
    return not self.hide_viewport

def set_show_collection(self, value):
    self.hide_viewport = not value


def get_show_object_viewport(self):
    """Return viewport visibility only (ignore render visibility)."""
    return not self.hide_viewport


def set_show_object_viewport(self, value):
    """Control only the viewport visibility (leave render visibility unchanged)."""
    self.hide_viewport = not value

class OBJECT_OT_ToggleModifierVisibility(bpy.types.Operator):
    bl_idname = "object.toggle_modifier_visibility"
    bl_label = "Toggle Modifier Visibility"
    bl_description = "Toggle the visibility of a modifier in both viewport and render"

    object_name: bpy.props.StringProperty()
    modifier_name: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        if obj is None:
            self.report({'ERROR'}, f"Object '{self.object_name}' not found")
            return {'CANCELLED'}
        mod = obj.modifiers.get(self.modifier_name)
        if mod is None:
            self.report({'ERROR'}, f"Modifier '{self.modifier_name}' not found on object '{self.object_name}'")
            return {'CANCELLED'}

        new_state = not (mod.show_viewport and mod.show_render)
        mod.show_viewport = new_state
        mod.show_render = new_state

        # If the modifier is being enabled, make sure the target mesh is visible
        if new_state:
            target_obj = None
            # For Mesh Deform and Surface Deform modifiers
            if mod.type == 'MESH_DEFORM':
                target_obj = mod.object
            elif mod.type == 'SURFACE_DEFORM':
                target_obj = mod.target

            if target_obj:
                # Make the target object visible in viewport
                target_obj.hide_viewport = False

                # Make sure the collections the target object is in are visible
                for collection in target_obj.users_collection:
                    self.make_collection_visible(collection)
        return {'FINISHED'}

    def make_collection_visible(self, collection):
        # Make this collection visible
        collection.hide_viewport = False
        # Recursively make parent collections visible
        parent_collections = [
            parent for parent in bpy.data.collections if collection.name in parent.children.keys()
        ]
        for parent in parent_collections:
            self.make_collection_visible(parent)

class OBJECT_OT_BindUnbindHHPModifiers(bpy.types.Operator):
    bl_idname = "object.bind_unbind_hhp_modifiers"
    bl_label = "Rebind Modifiers"
    bl_description = "Update and rebind physics modifiers to scene"
    
    skip_sync_check: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def has_hhp_modifiers(self, obj):
        """Check if an object has HHP modifiers"""
        if obj.type != 'MESH':
            return False
        for mod in obj.modifiers:
            if mod.type == 'SURFACE_DEFORM' and (mod.name.startswith('(HHP)') or mod.name.startswith('(HHPs)')):
                return True
        return False

    def check_sync_choices_needed(self, context):
        """Check if any selected meshes need source selection for syncing"""
        choices_needed = {}
        
        for selected_obj in context.selected_objects:
            if selected_obj.type != 'MESH':
                continue
                
            # Find all linked meshes that share the same mesh data
            linked_meshes = [obj for obj in bpy.data.objects 
                           if obj.type == 'MESH' and obj.data == selected_obj.data and obj != selected_obj]
            
            if not linked_meshes:
                continue
                
            # Separate wire-type and non-wire-type meshes
            # Wire-type: display_type == 'WIRE' OR (display_type != 'WIRE' AND no HHP modifiers)
            # Non-wire-type: display_type != 'WIRE' AND has HHP modifiers
            wire_type_meshes = [obj for obj in linked_meshes 
                               if obj.display_type == 'WIRE' or not self.has_hhp_modifiers(obj)]
            non_wire_type_meshes = [obj for obj in linked_meshes 
                                   if obj.display_type != 'WIRE' and self.has_hhp_modifiers(obj)]
            
            # Check if selected object is wire-type or non-wire-type
            selected_is_wire_type = (selected_obj.display_type == 'WIRE' or not self.has_hhp_modifiers(selected_obj))
            
            # Check if we need source selection
            if selected_is_wire_type:
                # Selected mesh is wire-type, need to sync from non-wire-type
                if len(non_wire_type_meshes) > 1:
                    choices_needed[selected_obj.name] = {
                        'type': 'wire_to_nonwire',
                        'sources': [obj.name for obj in non_wire_type_meshes],
                        'targets': [obj.name for obj in linked_meshes]  # ALL linked meshes
                    }
            else:
                # Selected mesh is non-wire-type
                if linked_meshes:  # Has linked meshes to sync to
                    if len(non_wire_type_meshes) > 0:  # Has other non-wire-type options
                        all_non_wire_type = [selected_obj] + non_wire_type_meshes
                        choices_needed[selected_obj.name] = {
                            'type': 'nonwire_to_wire',
                            'sources': [obj.name for obj in all_non_wire_type],
                            'targets': [obj.name for obj in linked_meshes]  # ALL linked meshes
                        }
        
        return choices_needed if choices_needed else None

    def draw_sync_menu(self, menu, context):
        """Draw the sync source selection menu"""
        layout = menu.layout
        if 'sync_choices_data' in context.scene:
            choices_data = context.scene['sync_choices_data']
            for mesh_name, choice_data in choices_data.items():
                for source_name in choice_data['sources']:
                    op = layout.operator("object.select_sync_source", text=source_name)
                    op.mesh_name = mesh_name
                    op.source_name = source_name
                layout.separator()

    def execute(self, context):
        # Check if we need source selection for wire/non-wire syncing (unless skipping)
        if not self.skip_sync_check:
            sync_choices_needed = self.check_sync_choices_needed(context)
            if sync_choices_needed:
                # Store the sync choices data and show popup
                context.scene['sync_choices_data'] = sync_choices_needed
                context.window_manager.popup_menu(self.draw_sync_menu, title="Choose sync source")
                return {'FINISHED'}
        
        return self.execute_rebind(context)

    def execute_rebind(self, context):
        # Store the current simplify settings
        original_use_simplify = context.scene.render.use_simplify
        original_simplify_subdivision = context.scene.render.simplify_subdivision
        
        # Check if we need to change simplify settings
        need_to_restore_simplify = False
        if not (original_use_simplify and original_simplify_subdivision == 0):
            # Set simplify to on with level 0 for viewport
            context.scene.render.use_simplify = True
            context.scene.render.simplify_subdivision = 0
            need_to_restore_simplify = True
        
        # Stop the animation playback
        bpy.ops.screen.animation_cancel(restore_frame=False)

        # Go to the scene start frame
        context.scene.frame_set(context.scene.frame_start)

        # Set playback method to 'Play Every Frame'
        context.scene.sync_mode = 'NONE'

        # Store the initial selection and active object
        initial_selection = context.selected_objects.copy()
        initial_active = context.view_layer.objects.active

        # Create an empty list to store new selections (Surface Deform and Mesh Deform targets)
        new_selection = []

        # Dictionaries to store original states
        modifier_states = {}
        target_object_states = {}
        collection_states = {}

        # Save the original selection
        original_selection = initial_selection.copy()

        # Build union_selection: add all meshes sharing the same mesh data as those originally selected
        union_selection = initial_selection.copy()
        shared_mesh_data = {obj.data for obj in original_selection if obj.type == 'MESH'}
        for obj in bpy.data.objects:
            if obj.type == 'MESH' and obj.data in shared_mesh_data and obj not in union_selection:
                union_selection.append(obj)

        # Sync surface deform strengths based on wire/non-wire display types
        sync_source_choices = context.scene.get('sync_source_choices', {})
        
        for selected_obj in original_selection:
            if selected_obj.type != 'MESH':
                continue
            
            # Find all linked meshes that share the same mesh data
            linked_meshes = [obj for obj in union_selection 
                           if obj.type == 'MESH' and obj.data == selected_obj.data and obj != selected_obj]
            
            if not linked_meshes:
                continue
                
            # Separate wire-type and non-wire-type meshes (same logic as check_sync_choices_needed)
            wire_type_meshes = [obj for obj in linked_meshes 
                               if obj.display_type == 'WIRE' or not self.has_hhp_modifiers(obj)]
            non_wire_type_meshes = [obj for obj in linked_meshes 
                                   if obj.display_type != 'WIRE' and self.has_hhp_modifiers(obj)]
            
            # Check if selected object is wire-type or non-wire-type
            selected_is_wire_type = (selected_obj.display_type == 'WIRE' or not self.has_hhp_modifiers(selected_obj))
            
            # Determine source and target meshes for syncing
            source_obj = None
            target_meshes = []
            
            if selected_is_wire_type:
                # Selected mesh is wire-type, sync from non-wire-type
                if len(non_wire_type_meshes) == 1:
                    source_obj = non_wire_type_meshes[0]
                    target_meshes = linked_meshes + [selected_obj]  # ALL linked meshes + selected mesh
                elif len(non_wire_type_meshes) > 1 and selected_obj.name in sync_source_choices:
                    source_name = sync_source_choices[selected_obj.name]
                    source_obj = bpy.data.objects.get(source_name)
                    target_meshes = linked_meshes + [selected_obj]  # ALL linked meshes + selected mesh
            else:
                # Selected mesh is non-wire-type, sync to ALL linked meshes (excluding source)
                if linked_meshes:
                    if len(non_wire_type_meshes) == 0:
                        # Only this non-wire-type mesh exists
                        source_obj = selected_obj
                        target_meshes = linked_meshes  # ALL linked meshes (selected mesh is source)
                    elif selected_obj.name in sync_source_choices:
                        # User chose source from multiple non-wire-type options
                        source_name = sync_source_choices[selected_obj.name]
                        source_obj = bpy.data.objects.get(source_name)
                        # Include all linked meshes + selected mesh, but exclude the source
                        all_meshes = linked_meshes + [selected_obj]
                        target_meshes = [obj for obj in all_meshes if obj != source_obj]
                    else:
                        # Default to selected mesh as source
                        source_obj = selected_obj
                        target_meshes = linked_meshes  # ALL linked meshes (selected mesh is source)
            
            # Perform the syncing
            if source_obj and target_meshes:
                # Get HHP surface deform modifiers from the source mesh
                source_surface_mods = []
                for mod in source_obj.modifiers:
                    if mod.type == 'SURFACE_DEFORM' and (mod.name.startswith('(HHP)') or mod.name.startswith('(HHPs)')):
                        source_surface_mods.append(mod)
                
                # Sync strengths to target meshes
                for target_obj in target_meshes:
                    for source_mod in source_surface_mods:
                        # Find corresponding modifier by name in target mesh
                        target_mod = target_obj.modifiers.get(source_mod.name)
                        if target_mod and target_mod.type == 'SURFACE_DEFORM':
                            target_mod.strength = source_mod.strength

        # Helper function to recursively get all child collections of a given collection
        def get_all_child_collections(coll):
            child_cols = []
            for child in coll.children:
                child_cols.append(child)
                child_cols.extend(get_all_child_collections(child))
            return child_cols

        # For every originally selected mesh, store and enable the viewport state for its parent collections
        # and all nested subcollections.
        for obj in original_selection:
            if obj.type == 'MESH':
                for col in obj.users_collection:
                    if col.name not in collection_states:
                        collection_states[col.name] = col.hide_viewport
                        col.hide_viewport = False  # Enable (make visible)
                    for child in get_all_child_collections(col):
                        if child.name not in collection_states:
                            collection_states[child.name] = child.hide_viewport
                            child.hide_viewport = False  # Enable (make visible)

        # Function to recursively collect parent collections
        def get_all_parent_collections(collection):
            parent_collections = []
            for parent in bpy.data.collections:
                if collection.name in parent.children.keys():
                    parent_collections.append(parent)
                    parent_collections.extend(get_all_parent_collections(parent))
            return parent_collections

        # Iterate over all initially selected objects
        for obj in initial_selection:
            # Check if the object has any modifiers
            if obj.modifiers:
                for mod in obj.modifiers:
                    # Process modifiers that start with "(HHP)" or "(HHPs)"
                    if mod.name.startswith('(HHP)') or mod.name.startswith('(HHPs)'):
                        # Store the modifier's show_viewport and show_render states
                        modifier_states[(obj.name, mod.name)] = (mod.show_viewport, mod.show_render)

                        # Enable the modifier
                        mod.show_viewport = True
                        mod.show_render = True

                        # If the modifier is a Surface Deform or Mesh Deform modifier, select its target/object
                        target_obj = None
                        if mod.type == 'SURFACE_DEFORM' and mod.target:
                            target_obj = mod.target
                        elif mod.type == 'MESH_DEFORM' and mod.object:
                            target_obj = mod.object

                        if target_obj:
                            # Store the target object's visibility state if not already stored
                            if target_obj.name not in target_object_states:
                                target_object_states[target_obj.name] = (
                                    target_obj.hide_viewport, target_obj.hide_render
                                )

                            # Make the target object visible
                            target_obj.hide_viewport = False
                            target_obj.hide_render = False
                            target_obj.select_set(True)
                            new_selection.append(target_obj)

                            # Store and enable the collections and parent collections
                            for collection in target_obj.users_collection:
                                # Collect all parent collections
                                all_collections = [collection] + get_all_parent_collections(collection)
                                for col in all_collections:
                                    if col.name not in collection_states:
                                        collection_states[col.name] = col.hide_viewport
                                        col.hide_viewport = False

        # Deselect the initial objects
        for obj in initial_selection:
            obj.select_set(False)

        # Update cache simulation frames to match timeline
        # This ensures that when physics targets are rebound, they use the correct frame range from the scene
        # Function to update cache settings of physics modifiers
        def update_cache_settings(obj, start_frame, end_frame):
            for mod in obj.modifiers:
                if mod.type in {
                    'CLOTH', 'SOFT_BODY', 'FLUID', 'DYNAMIC_PAINT', 'SMOKE', 'PARTICLE_SYSTEM', 'COLLISION'
                }:
                    if hasattr(mod, 'point_cache'):
                        mod.point_cache.frame_start = start_frame
                        mod.point_cache.frame_end = end_frame
                    if hasattr(mod, 'cache'):
                        mod.cache.frame_start = start_frame
                        mod.cache.frame_end = end_frame

        # If we have new target objects to update (the physics proxies)
        if new_selection:
            # Get the start and end frames from the timeline
            start_frame = context.scene.frame_start
            end_frame = context.scene.frame_end
            
            # Set the first object in the new selection as the active object
            context.view_layer.objects.active = new_selection[0]

            # Update cache settings for all physics target objects (in new_selection)
            for obj in new_selection:
                if obj.type == 'MESH':
                    update_cache_settings(obj, start_frame, end_frame)

            # Enter and immediately exit edit mode
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.object.mode_set(mode='OBJECT')

        # Deselect all objects to start fresh
        bpy.ops.object.select_all(action='DESELECT')

        # Instead of restoring just the initial selection, restore the union selection,
        # which now includes all meshes sharing the same mesh data.
        for obj in union_selection:
            obj.select_set(True)

        # Set the active object from the union selection if available.
        if union_selection:
            context.view_layer.objects.active = union_selection[0]

        # Define the variables
        rebind_at_start = True  # You can change this later
        viewport_enabled = True  # Control whether to include viewport-disabled modifiers
        render_enabled = True    # Control whether to include render-disabled modifiers

        def unbind_modifiers(obj):
            for modifier in obj.modifiers:
                # Process only modifiers that start with "(HHP)"
                if not modifier.name.startswith('(HHP)'):
                    continue  # Skip modifiers that do not start with '(HHP)'

                if viewport_enabled and not modifier.show_viewport:
                    continue  # Skip modifiers disabled in viewport
                if render_enabled and not modifier.show_render:
                    continue  # Skip modifiers disabled in render
                if modifier.type == 'MESH_DEFORM' and modifier.is_bound:
                    context.view_layer.objects.active = obj
                    bpy.ops.object.meshdeform_bind(modifier=modifier.name)
                elif modifier.type == 'SURFACE_DEFORM' and modifier.is_bound:
                    context.view_layer.objects.active = obj
                    bpy.ops.object.surfacedeform_bind(modifier=modifier.name)
                elif modifier.type == 'CORRECTIVE_SMOOTH' and modifier.is_bind:
                    context.view_layer.objects.active = obj
                    bpy.ops.object.correctivesmooth_bind(modifier=modifier.name)

        def unbind_modifiers_from_selected():
            selected_objects = context.selected_objects
            for obj in selected_objects:
                unbind_modifiers(obj)

        def bind_modifiers(obj):
            # Store the original active object
            original_active_object = context.view_layer.objects.active
            
            # Make the object active
            context.view_layer.objects.active = obj
            
            # Iterate over the modifiers in the same order as the modifier stack
            for modifier in obj.modifiers:
                # Process only modifiers that start with "(HHP)"
                if not modifier.name.startswith('(HHP)'):
                    continue  # Skip modifiers that do not start with '(HHP)'

                if viewport_enabled and not modifier.show_viewport:
                    continue  # Skip modifiers disabled in viewport
                if render_enabled and not modifier.show_render:
                    continue  # Skip modifiers disabled in render
                
                # Apply gravity factor from scene settings to cloth modifiers
                if modifier.type == 'CLOTH':
                    modifier.settings.effector_weights.gravity = context.scene.hhp_props.gravity_factor
                
                if modifier.type == 'MESH_DEFORM' and not modifier.is_bound:
                    bpy.ops.object.meshdeform_bind(modifier=modifier.name)
                elif modifier.type == 'SURFACE_DEFORM' and not modifier.is_bound:
                    bpy.ops.object.surfacedeform_bind(modifier=modifier.name)
                elif modifier.type == 'CORRECTIVE_SMOOTH' and not modifier.is_bind:
                    bpy.ops.object.correctivesmooth_bind(modifier=modifier.name)
            
            # Restore the original active object
            context.view_layer.objects.active = original_active_object

        def bind_modifiers_from_selected():
            selected_objects = context.selected_objects
            for obj in selected_objects:
                bind_modifiers(obj)

        try:
            # Unbind the modifiers from all selected objects
            unbind_modifiers_from_selected()

            # Bind the modifiers to all selected objects
            bind_modifiers_from_selected()
        finally:
            # Restore the modifier states
            for (obj_name, mod_name), (show_viewport, show_render) in modifier_states.items():
                obj = bpy.data.objects.get(obj_name)
                if obj:
                    mod = obj.modifiers.get(mod_name)
                    if mod:
                        mod.show_viewport = show_viewport
                        mod.show_render = show_render

            # Restore the hide_viewport and hide_render states of target objects
            for obj_name, (hide_viewport, hide_render) in target_object_states.items():
                obj = bpy.data.objects.get(obj_name)
                if obj:
                    obj.hide_viewport = hide_viewport
                    obj.hide_render = hide_render

            # Restore the hide_viewport states of collections
            for col_name, hide_viewport in collection_states.items():
                col = bpy.data.collections.get(col_name)
                if col:
                    col.hide_viewport = hide_viewport

            # Restore the original selection and active object
            bpy.ops.object.select_all(action='DESELECT')
            for obj in original_selection:
                obj.select_set(True)
            context.view_layer.objects.active = initial_active

            # Restore the original simplify settings if we changed them
            if need_to_restore_simplify:
                context.scene.render.use_simplify = original_use_simplify
                context.scene.render.simplify_subdivision = original_simplify_subdivision

        return {'FINISHED'}

class OBJECT_OT_SelectSyncSource(bpy.types.Operator):
    bl_idname = "object.select_sync_source"
    bl_label = "Select Sync Source"
    bl_description = "Select source mesh for syncing surface deform strengths"

    mesh_name: bpy.props.StringProperty()
    source_name: bpy.props.StringProperty()

    def execute(self, context):
        # Store the choice and check if all choices are made
        if 'sync_source_choices' not in context.scene:
            context.scene['sync_source_choices'] = {}
        
        # Convert string properties to dict-like access
        choices = dict(context.scene.get('sync_source_choices', {}))
        choices[self.mesh_name] = self.source_name
        context.scene['sync_source_choices'] = choices
        
        # Check if all required choices have been made
        if 'sync_choices_data' in context.scene:
            choices_data = context.scene['sync_choices_data']
            all_chosen = all(mesh_name in choices for mesh_name in choices_data.keys())
            
            if all_chosen:
                # All choices made, proceed with rebind
                bpy.ops.object.bind_unbind_hhp_modifiers('EXEC_DEFAULT', skip_sync_check=True)
                
                # Clean up stored data
                if 'sync_choices_data' in context.scene:
                    del context.scene['sync_choices_data']
                if 'sync_source_choices' in context.scene:
                    del context.scene['sync_source_choices']
        
        return {'FINISHED'}

class OBJECT_OT_PtcacheBakeAll(bpy.types.Operator):
    bl_idname = "object.ptcache_bake_all"
    bl_label = "Bake All Physics"
    bl_description = "Bake all physics simulations in the scene"

    def execute(self, context):
        bpy.ops.ptcache.bake_all(bake=True)
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

class OBJECT_OT_PtcacheFreeBakeAll(bpy.types.Operator):
    bl_idname = "object.ptcache_free_bake_all"
    bl_label = "Free All Bakes"
    bl_description = "Free all baked physics simulations in the scene"

    def execute(self, context):
        bpy.ops.ptcache.free_bake_all()
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

class HHP_UL_LatticeShapekeysList(UIList):
    """UIList for lattice shapekeys"""
    
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # Split layout to give more space to name 
            split = layout.split(factor=0.6)
            
            # Left side - shape key name (editable with full name)
            row = split.row()
            row.prop(item, "name", text="", emboss=False, icon='SHAPEKEY_DATA')
            
            # Right side - value and mute (hidden for Basis shapekey)
            if index > 0:  # Only show controls for non-Basis shapekeys
                row = split.row(align=True)
                row.alignment = 'RIGHT'
                
                # Value slider
                slider_row = row.row(align=True)
                slider_row.enabled = True
                
                if item.mute:
                    slider_row.active = False
                else:
                    slider_row.active = True
                
                slider_row.ui_units_x = 4
                slider_row.prop(item, "value", text="", emboss=False, slider=True)
                
                # Mute checkbox
                row.prop(item, "mute", text="", emboss=False, toggle=True)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='SHAPEKEY_DATA')
    
    def filter_items(self, context, data, propname):
        """Show all lattice shapekeys with search functionality"""
        shape_keys = getattr(data, propname)
        flags = [0] * len(shape_keys)
        
        # Show all shapekeys
        for i, key in enumerate(shape_keys):
            flags[i] = self.bitflag_filter_item
        
        # Handle search within visible keys
        if self.filter_name:
            for i, key in enumerate(shape_keys):
                if flags[i]:
                    if self.filter_name.lower() not in key.name.lower():
                        flags[i] = 0
        
        return flags, []

class OBJECT_OT_PhysicsFramerateMultiplier(bpy.types.Operator):
    bl_idname = "object.physics_framerate_multiplier"
    bl_label = "Physics Framerate Multiplier"
    bl_description = "Adjust the physics framerate multiplier for physics simulations based on the selected action."
    bl_options = {'REGISTER', 'UNDO'}

    action: bpy.props.EnumProperty(
        items=[
            ('RESET', 'Reset to default', 'Reset physics multipliers to their original baseline values.', 'LOOP_BACK', 0),
            ('CONVERT', 'Match to scene framerate', 'Convert physics multipliers to align with the current scene framerate.', 'NONE', 1),
            ('MULTIPLY', 'Multiply defaults by number', 'Multiply the default physics multipliers by a custom factor, as specified via the slider.', 'NONE', 2)
        ],
        name="Action"
    )
    multiplier: bpy.props.FloatProperty(
        name="Multiplier",
        description="Multiplier value",
        default=1.0,
        min=0.0,
        soft_max=10.0
    )
    confirm_mode: bpy.props.EnumProperty(
        name="Confirmation Mode",
        description="Choose whether to use original defaults or set user adjusted values as default",
        items=[
            ('ORIGINAL', "Use original defaults", "Keep the original baseline values"),
            ('USER', "Set user adjusted values as default", "Use user adjusted multipliers as the new default")
        ],
        default='ORIGINAL'
    )

    def check_manual_adjustment(self, context):
        # Iterate over selected mesh objects and check if any target has been manually adjusted.
        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue
            for mod in obj.modifiers:
                if mod.type in {'SURFACE_DEFORM', 'MESH_DEFORM'}:
                    target = None
                    if mod.type == 'SURFACE_DEFORM':
                        target = mod.target
                    elif mod.type == 'MESH_DEFORM':
                        target = mod.object
                    if target is None:
                        continue
                    if "phs_baseline" in target:
                        baseline = target["phs_baseline"]
                        # Get current physics value from the first available physics simulation modifier.
                        current_value = None
                        for phy_mod in target.modifiers:
                            if phy_mod.type == 'CLOTH':
                                current_value = phy_mod.settings.time_scale
                                break
                        stored_converted = target.get("phs_converted", baseline)
                        if current_value is not None:
                            # If current value differs from both baseline and stored converted value,
                            # assume it was manually adjusted.
                            if abs(current_value - baseline) > 1e-5 and abs(current_value - stored_converted) > 1e-5:
                                return True
        return False

    def execute(self, context):
        scene_fps = context.scene.render.fps
        # Determine conversion factor based on scene fps; baseline is assumed to be 60fps
        conv_factor = 60.0 / scene_fps if scene_fps != 0 else 1.0

        processed_targets = set()

        # Iterate over selected mesh objects
        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue
            for mod in obj.modifiers:
                if mod.type in {'SURFACE_DEFORM', 'MESH_DEFORM'}:
                    # Get the target object: for SURFACE_DEFORM it's mod.target, for MESH_DEFORM it's mod.object
                    target = None
                    if mod.type == 'SURFACE_DEFORM':
                        target = mod.target
                    elif mod.type == 'MESH_DEFORM':
                        target = mod.object
                    if target is None:
                        continue

                    if target.name in processed_targets:
                        continue
                    processed_targets.add(target.name)

                    # Get the current physics multiplier from the first available physics simulation modifier.
                    current_value = None
                    for phy_mod in target.modifiers:
                        if phy_mod.type == 'CLOTH':
                            current_value = phy_mod.settings.time_scale
                            break
                    if current_value is None:
                        current_value = 1.0

                    # Store the baseline if not already stored.
                    if "phs_baseline" not in target:
                        target["phs_baseline"] = current_value
                    baseline = target["phs_baseline"]

                    # Check whether manual adjustment occurred:
                    # If current value does not match either the stored baseline or the last changed value,
                    # then the user has manually edited the multiplier.
                    stored_changed = target.get("phs_converted", baseline)

                    if (abs(current_value - baseline) > 1e-5 and abs(current_value - stored_changed) > 1e-5):
                        # A manual adjustment is detected.
                        if self.confirm_mode == 'USER':
                            # Replace the old baseline with the user-adjusted value.
                            target["phs_baseline"] = current_value
                            baseline = current_value
                        elif self.confirm_mode == 'ORIGINAL':
                            # Revert to the stored baseline.
                            current_value = baseline

                    # Now compute the new multiplier ("changed set") based on the (possibly updated) baseline.
                    if self.action == 'CONVERT':
                        new_value = baseline * conv_factor
                    elif self.action == 'MULTIPLY':
                        new_value = baseline * self.multiplier
                    elif self.action == 'RESET':
                        new_value = baseline
                    else:
                        new_value = baseline

                    # Store the new multiplier value (changed set) for reference/restoration.
                    target["phs_converted"] = new_value

                    # Now update the time_scale for all physics simulation modifiers.
                    for phy_mod in target.modifiers:
                        if phy_mod.type == 'CLOTH':
                            phy_mod.settings.time_scale = new_value
                            # Apply gravity factor from scene settings
                            phy_mod.settings.effector_weights.gravity = context.scene.hhp_props.gravity_factor

        self.report({'INFO'}, f"Action '{self.action}' applied to {len(processed_targets)} physics target(s).")
        return {'FINISHED'}

    def invoke(self, context, event):
        if self.check_manual_adjustment(context):
            return context.window_manager.invoke_props_dialog(self, width=400)
        if self.action == 'MULTIPLY':
            return context.window_manager.invoke_props_dialog(self, width=400)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        if self.check_manual_adjustment(context):
            layout.label(text="Multipliers adjusted by user.", icon='ERROR')
            layout.label(text="Choose default settings:")
            layout.prop(self, "confirm_mode", expand=True)
        if self.action == 'MULTIPLY':
            layout.prop(self, "multiplier")

class OBJECT_PT_ProxiesVisibilityPanel(bpy.types.Panel):
    """Panel to reflect and toggle visibility of 'Proxies (HHP)' collections with clickable text and greyed out subcollections."""
    bl_label = "Physics / Proxies (HHP)"
    bl_idname = "OBJECT_PT_proxies_visibility_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'  # Ensure this matches the 'Char (HHP)' category
    bl_parent_id = "CHAR_HHP_PT_Panel"  # Set parent panel
    bl_order = 10  # Place it after the 'Char (HHP)' panel
    bl_options = {'HIDE_HEADER'}  # Hide the header
    
    @classmethod
    def poll(cls, context):
        # Only show this panel if PROXIES is selected in the mode selector
        return context.scene.hhp_panel_mode.selected_panel == 'PROXIES'

    def draw(self, context):
        layout = self.layout
        props = context.scene.hhp_props
        obj = context.active_object

        # Proxies list as in your provided script
        proxies_collections = self.find_proxies_collections()

        # Use a grid flow for the proxies list
        col = layout.column(align=True)
        flow = col.grid_flow(row_major=True, columns=1, even_columns=False, even_rows=False, align=True)

        linked_name_tag = "Collision - Linked (DO NOT EDIT MESH)"

        for collection, level, parent_hidden, is_top_level in proxies_collections:
            row = flow.row(align=True)

            if is_top_level and collection.name.startswith("Collision"):
                # Collect collision objects for this collection
                collision_objects = self.collect_collision_objects(collection)
                non_linked_objects = [o for o in collision_objects if linked_name_tag not in o.name]
                linked_objects = [o for o in collision_objects if linked_name_tag in o.name]

                # Show main checkbox
                row.prop(collection, "show_collection", text="Collide & interact with physics")

                # When enabled, list all objects in the Collision collection directly
                # under this checkbox in two aligned columns. Linked objects are pushed
                # to the bottom and drawn greyed out (but still togglable).
                if collection.show_collection and collision_objects:
                    # If the only objects are linked collision proxies, show the
                    # "Generate optimized collision" button above the list as an alert row.
                    if not non_linked_objects:
                        alert_row = col.row(align=True)
                        alert_row.alert = True
                        op = alert_row.operator(
                            "hhp.generate_optimized_collision",
                            text="Generate optimized collision",
                            icon='MOD_DECIM'
                        )
                        op.collection_name = collection.name

                    ordered_objects = non_linked_objects + linked_objects

                    for i in range(0, len(ordered_objects), 2):
                        # If this is the last remaining object and there is no pair,
                        # let it span the full row width (no second, empty column).
                        if i + 1 >= len(ordered_objects):
                            single_obj = ordered_objects[i]
                            single_name = single_obj.name.split(".")[0]
                            single_row = col.row(align=True)
                            single_col = single_row.row(align=True)
                            if single_obj in linked_objects:
                                single_col.active = False  # Greyed out but still togglable
                            single_col.prop(
                                single_obj,
                                "show_object_viewport",
                                text=single_name,
                                toggle=True,
                                icon='OBJECT_DATA'
                            )
                        else:
                            obj_row = col.row(align=True)

                            # Left column
                            left_obj = ordered_objects[i]
                            left_name = left_obj.name.split(".")[0]
                            left_col = obj_row.row(align=True)
                            if left_obj in linked_objects:
                                left_col.active = False  # Greyed out but still togglable
                            left_col.prop(
                                left_obj,
                                "show_object_viewport",
                                text=left_name,
                                toggle=True,
                                icon='OBJECT_DATA'
                            )

                            # Right column
                            right_obj = ordered_objects[i + 1]
                            right_name = right_obj.name.split(".")[0]
                            right_col = obj_row.row(align=True)
                            if right_obj in linked_objects:
                                right_col.active = False  # Greyed out but still togglable
                            right_col.prop(
                                right_obj,
                                "show_object_viewport",
                                text=right_name,
                                toggle=True,
                                icon='OBJECT_DATA'
                            )
            else:
                clean_name = collection.name.split(".")[0]

                # Set the icon
                icon = 'NONE' if is_top_level else 'DOT'

                # Set the active state (greyed out appearance)
                row.active = True if is_top_level else not parent_hidden

                # Display the custom property as a toggle button with clickable text and icon
                row.prop(collection, "show_collection", text=clean_name, toggle=True, icon=icon)

        # Collect modifiers into a list
        modifiers_list = []
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                for mod in obj.modifiers:
                    if mod.type in {'MESH_DEFORM', 'SURFACE_DEFORM'}:
                        if mod.name.startswith("(HHP)") or mod.name.startswith("(HHPs)"):
                            # Extract the display name after "- "
                            mod_display_name = mod.name.split("- ", 1)[1] if "- " in mod.name else mod.name
                            modifiers_list.append((obj, mod, mod_display_name))

        if modifiers_list:
            # Now, create the modifier box and arrange the buttons
            modifier_box = layout.box()
            # Create a row for the Physics label and Show advanced button
            header_row = modifier_box.row()
            header_row.label(text="Physics", icon='MODIFIER')
            header_row.prop(context.scene.hhp_props, "show_strength", text="", icon='SETTINGS', emboss=True)

            # Arrange buttons in 2 columns
            col = modifier_box.column(align=True)
            
            # Create buttons row
            for i in range(0, len(modifiers_list), 2):
                row = col.row(align=True)
                # First column
                obj, mod, mod_display_name = modifiers_list[i]
                op = row.operator(
                    "object.toggle_modifier_visibility",
                    text=mod_display_name,
                    depress=mod.show_viewport and mod.show_render
                )
                op.object_name = obj.name
                op.modifier_name = mod.name
                
                # Second column if available
                if i + 1 < len(modifiers_list):
                    obj2, mod2, mod_display_name2 = modifiers_list[i + 1]
                    op = row.operator(
                        "object.toggle_modifier_visibility",
                        text=mod_display_name2,
                        depress=mod2.show_viewport and mod2.show_render
                    )
                    op.object_name = obj2.name
                    op.modifier_name = mod2.name

                # BS_Inflate proxy displace sliders and lattice strength sliders (show when toggle is on)
                if i + 1 < len(modifiers_list):
                    # Two column mode
                    left_target = mod.target if mod.type == 'SURFACE_DEFORM' else None
                    right_target = mod2.target if mod2.type == 'SURFACE_DEFORM' else None
                    left_enabled = mod.show_viewport and mod.show_render
                    right_enabled = mod2.show_viewport and mod2.show_render
                    
                    # BS_Inflate sliders (only when modifiers are enabled)
                    if ((left_target and "BS_Inflate" in left_target and left_enabled) or 
                        (right_target and "BS_Inflate" in right_target and right_enabled)):
                        bs_inflate_row = col.row(align=True)
                        left_bs_col = bs_inflate_row.column(align=True)
                        right_bs_col = bs_inflate_row.column(align=True)
                        
                        if left_target and "BS_Inflate" in left_target and left_enabled:
                            left_bs_col.prop(left_target, '["BS_Inflate"]', text=f"{obj.name} Proxy Displace")
                        else:
                            left_bs_col.label(text="")
                            
                        if right_target and "BS_Inflate" in right_target and right_enabled:
                            right_bs_col.prop(right_target, '["BS_Inflate"]', text=f"{obj2.name} Proxy Displace")
                        else:
                            right_bs_col.label(text="")
                    
                    # Lattice modifier strength sliders (only when modifiers are enabled)
                    left_lattice_mods = [m for m in obj.modifiers if m.type == 'LATTICE'] if left_enabled else []
                    right_lattice_mods = [m for m in obj2.modifiers if m.type == 'LATTICE'] if right_enabled else []
                    
                    max_lattice_count = max(len(left_lattice_mods), len(right_lattice_mods))
                    for lattice_idx in range(max_lattice_count):
                        lattice_row = col.row(align=True)
                        left_lattice_col = lattice_row.column(align=True)
                        right_lattice_col = lattice_row.column(align=True)
                        
                        if lattice_idx < len(left_lattice_mods):
                            left_lattice_mod = left_lattice_mods[lattice_idx]
                            left_lattice_col.prop(left_lattice_mod, "strength", text=f"{obj.name} {left_lattice_mod.name} Strength", slider=True)
                        else:
                            left_lattice_col.label(text="")
                            
                        if lattice_idx < len(right_lattice_mods):
                            right_lattice_mod = right_lattice_mods[lattice_idx]
                            right_lattice_col.prop(right_lattice_mod, "strength", text=f"{obj2.name} {right_lattice_mod.name} Strength", slider=True)
                        else:
                            right_lattice_col.label(text="")
                else:
                    # Single mode
                    left_target = mod.target if mod.type == 'SURFACE_DEFORM' else None
                    left_enabled = mod.show_viewport and mod.show_render
                    
                    # BS_Inflate slider (only when modifier is enabled)
                    if left_target and "BS_Inflate" in left_target and left_enabled:
                        single_bs_inflate = col.row(align=True)
                        single_bs_inflate.prop(left_target, '["BS_Inflate"]', text=f"{obj.name} Proxy Displace")
                    
                    # Lattice modifier strength sliders (only when modifier is enabled)
                    if left_enabled:
                        left_lattice_mods = [m for m in obj.modifiers if m.type == 'LATTICE']
                        for lattice_mod in left_lattice_mods:
                            single_lattice = col.row(align=True)
                            single_lattice.prop(lattice_mod, "strength", text=f"{obj.name} {lattice_mod.name} Strength", slider=True)

                # If show_strength is enabled, add strength slider and cloth settings in a unified, aligned layout
                if context.scene.hhp_props.show_strength:
                    # Strength slider row: use two columns if a second modifier exists, otherwise use a single full-width row
                    if i + 1 < len(modifiers_list):
                        strength_row = col.row(align=True)
                        left_col = strength_row.column(align=True)
                        right_col = strength_row.column(align=True)
                        # Left column strength slider
                        if mod.type == 'SURFACE_DEFORM':
                            left_col.prop(mod, "strength", text=mod_display_name)
                        else:
                            left_col.label(text="")
                        # Right column strength slider
                        if mod2.type == 'SURFACE_DEFORM':
                            right_col.prop(mod2, "strength", text=mod_display_name2)
                        else:
                            right_col.label(text="")
                    else:
                        single_strength = col.row(align=True)
                        if mod.type == 'SURFACE_DEFORM':
                            single_strength.prop(mod, "strength", text=mod_display_name)
                        else:
                            single_strength.label(text="")
                    # Prepare cloth modifiers for both columns
                    left_cloth = None
                    if mod.type == 'SURFACE_DEFORM':
                        target = mod.target
                        if target and any(m.type == 'CLOTH' for m in target.modifiers):
                            left_cloth = next((m for m in target.modifiers if m.type == 'CLOTH'), None)
                    right_cloth = None
                    if i + 1 < len(modifiers_list) and mod2.type == 'SURFACE_DEFORM':
                        target = mod2.target
                        if target and any(m.type == 'CLOTH' for m in target.modifiers):
                            right_cloth = next((m for m in target.modifiers if m.type == 'CLOTH'), None)
                    
                    # Define single_mode based on whether a second modifier exists
                    single_mode = (i + 1 >= len(modifiers_list))
                    
                    # Add gravity sliders for cloth modifiers
                    if left_cloth or right_cloth:
                        # Row for gravity sliders
                        if not single_mode:
                            gravity_row = col.row(align=True)
                            left_gravity = gravity_row.column(align=True)
                            if left_cloth:
                                left_gravity.prop(left_cloth.settings.effector_weights, "gravity", text=f"{mod_display_name} Gravity", slider=True)
                            else:
                                left_gravity.label(text="")
                            right_gravity = gravity_row.column(align=True)
                            if right_cloth:
                                right_gravity.prop(right_cloth.settings.effector_weights, "gravity", text=f"{mod_display_name2} Gravity", slider=True)
                            else:
                                right_gravity.label(text="")
                        else:
                            gravity_row = col.row(align=True)
                            if left_cloth:
                                gravity_row.prop(left_cloth.settings.effector_weights, "gravity", text=f"{mod_display_name} Gravity", slider=True)
                            else:
                                gravity_row.label(text="")

                    if left_cloth or right_cloth:
                        # Row for collision toggles (if single, use full width; otherwise split into two columns)
                        if not single_mode:
                            toggle_row = col.row(align=True)
                            left_toggle = toggle_row.column(align=True)
                            if left_cloth:
                                left_toggle_inner = left_toggle.row(align=True)
                                left_toggle_inner.prop(left_cloth.collision_settings, "use_collision", text="Collision", icon='INDIRECT_ONLY_ON')
                                left_toggle_inner.prop(left_cloth.collision_settings, "use_self_collision", text="Self Col", icon='INDIRECT_ONLY_ON')
                            else:
                                left_toggle.label(text="")
                            right_toggle = toggle_row.column(align=True)
                            if right_cloth:
                                right_toggle_inner = right_toggle.row(align=True)
                                right_toggle_inner.prop(right_cloth.collision_settings, "use_collision", text="Collision", icon='INDIRECT_ONLY_ON')
                                right_toggle_inner.prop(right_cloth.collision_settings, "use_self_collision", text="Self Col", icon='INDIRECT_ONLY_ON')
                            else:
                                right_toggle.label(text="")
                        else:
                            toggle_row = col.row(align=True)
                            if left_cloth:
                                toggle_row.prop(left_cloth.collision_settings, "use_collision", text="Collision", icon='INDIRECT_ONLY_ON')
                                toggle_row.prop(left_cloth.collision_settings, "use_self_collision", text="Self Col", icon='INDIRECT_ONLY_ON')
                            else:
                                toggle_row.label(text="")

                        # Row for distance settings (always shown)
                        if not single_mode:
                            distance_row = col.row(align=True)
                            left_distance = distance_row.column(align=True)
                            if left_cloth:
                                left_dist_inner = left_distance.row(align=True)
                                left_dist_inner.prop(left_cloth.collision_settings, "distance_min", text="Col. Dist")
                                left_dist_inner.prop(left_cloth.collision_settings, "self_distance_min", text="Self Col. Dist")
                            else:
                                left_distance.label(text="")
                            right_distance = distance_row.column(align=True)
                            if right_cloth:
                                right_dist_inner = right_distance.row(align=True)
                                right_dist_inner.prop(right_cloth.collision_settings, "distance_min", text="Col. Dist")
                                right_dist_inner.prop(right_cloth.collision_settings, "self_distance_min", text="Self Col. Dist")
                            else:
                                right_distance.label(text="")
                        else:
                            distance_row = col.row(align=True)
                            if left_cloth:
                                distance_row.prop(left_cloth.collision_settings, "distance_min", text="Col. Dist")
                                distance_row.prop(left_cloth.collision_settings, "self_distance_min", text="Self Col. Dist")
                            else:
                                distance_row.label(text="")

                        # Row for quality steps (Quality and Collision Quality)
                        if not single_mode:
                            quality_row = col.row(align=True)
                            left_quality = quality_row.column(align=True)
                            if left_cloth:
                                left_quality_inner = left_quality.row(align=True)
                                left_quality_inner.prop(left_cloth.settings, "quality", text="Quality")
                                left_quality_inner.prop(left_cloth.collision_settings, "collision_quality", text="Col Qual")
                            else:
                                left_quality.label(text="")
                            right_quality = quality_row.column(align=True)
                            if right_cloth:
                                right_quality_inner = right_quality.row(align=True)
                                right_quality_inner.prop(right_cloth.settings, "quality", text="Quality")
                                right_quality_inner.prop(right_cloth.collision_settings, "collision_quality", text="Col Qual")
                            else:
                                right_quality.label(text="")
                        else:
                            quality_row = col.row(align=True)
                            if left_cloth:
                                quality_row.prop(left_cloth.settings, "quality", text="Quality")
                                quality_row.prop(left_cloth.collision_settings, "collision_quality", text="Col Qual")
                            else:
                                quality_row.label(text="")

                    # Add subdiv/unsubdiv cage buttons row (for advanced cage editing)
                    if left_cloth or right_cloth:
                        if not single_mode:
                            cage_row = col.row(align=True)
                            # Left column: subdiv and unsubdiv side-by-side (for left_cloth)
                            left_cage = left_cloth
                            left_cage_col = cage_row.column(align=True)
                            if left_cage:
                                left_hhp_enabled = mod.show_viewport and mod.show_render
                                left_target = left_cage.id_data
                                left_subdiv_count = left_target.get("cage_subdiv_count", 0)
                                # Use HHP modifier's state to determine physics enabled state
                                left_physics_enabled = left_hhp_enabled
                                # Create two sub-columns in the same row for left unsubdiv and subdiv buttons
                                left_cage_inner = left_cage_col.row(align=True)
                                left_unsubdiv_col = left_cage_inner.column(align=True)
                                left_subdiv_col = left_cage_inner.column(align=True)
                                left_unsubdiv_col.enabled = left_physics_enabled and (left_subdiv_count > 0)
                                left_subdiv_col.enabled = left_physics_enabled
                                op_unsubdiv = left_unsubdiv_col.operator("hhp.unsubdiv_cage", text="Unsubdiv Cage", icon='MOD_REMESH')
                                op_unsubdiv.target_name = left_target.name
                                op_subdiv = left_subdiv_col.operator("hhp.subdiv_cage", text="Subdiv Cage", icon='MOD_SUBSURF')
                                op_subdiv.target_name = left_target.name
                            else:
                                left_cage_col.label(text="")

                            # Right column: subdiv and unsubdiv side-by-side (for right_cloth)
                            right_cage = right_cloth
                            right_cage_col = cage_row.column(align=True)
                            if right_cage:
                                right_hhp_enabled = mod2.show_viewport and mod2.show_render
                                right_target = right_cage.id_data
                                right_subdiv_count = right_target.get("cage_subdiv_count", 0)
                                # Use the HHP modifier's state for the right side as well
                                right_physics_enabled = right_hhp_enabled
                                right_cage_inner = right_cage_col.row(align=True)
                                right_unsubdiv_col = right_cage_inner.column(align=True)
                                right_subdiv_col = right_cage_inner.column(align=True)
                                right_unsubdiv_col.enabled = right_physics_enabled and (right_subdiv_count > 0)
                                right_subdiv_col.enabled = right_physics_enabled
                                op_unsubdiv = right_unsubdiv_col.operator("hhp.unsubdiv_cage", text="Unsubdiv Cage", icon='MOD_REMESH')
                                op_unsubdiv.target_name = right_target.name
                                op_subdiv = right_subdiv_col.operator("hhp.subdiv_cage", text="Subdiv Cage", icon='MOD_SUBSURF')
                                op_subdiv.target_name = right_target.name
                            else:
                                right_cage_col.label(text="")
                        else:
                            # Single mode: show buttons for left_cloth only
                            cage_row = col.row(align=True)
                            if left_cloth:
                                left_hhp_enabled = mod.show_viewport and mod.show_render
                                left_target = left_cloth.id_data
                                left_subdiv_count = left_target.get("cage_subdiv_count", 0)
                                # Use HHP modifier's state to determine physics enabled state
                                left_physics_enabled = left_hhp_enabled
                                unsubdiv_col = cage_row.column(align=True)
                                subdiv_col = cage_row.column(align=True)
                                unsubdiv_col.enabled = left_physics_enabled and (left_subdiv_count > 0)
                                subdiv_col.enabled = left_physics_enabled
                                op_unsubdiv = unsubdiv_col.operator("hhp.unsubdiv_cage", text="Unsubdiv Cage", icon='MOD_REMESH')
                                op_unsubdiv.target_name = left_target.name
                                op_subdiv = subdiv_col.operator("hhp.subdiv_cage", text="Subdiv Cage", icon='MOD_SUBSURF')
                                op_subdiv.target_name = left_target.name
                            else:
                                cage_row.label(text="")
                    
                    # Add a separator between this item block and the next one if more modifiers follow
                    if i + 2 < len(modifiers_list):
                        col.separator(factor=4.0)

            # Add a separator
            col.separator()

            # Physics framerate multiplier menu - moved outside advanced settings
            col.operator_menu_enum(
                "object.physics_framerate_multiplier",
                "action",
                text="Physics framerate multiplier",
                icon='TIME'
            )
            col.separator()

            # If show advanced is enabled, add the physics framerate multiplier menu
            if context.scene.hhp_props.show_strength:
                # Advanced settings section was here
                # Physics framerate multiplier removed from here
                col.separator()

            # Add the new button to rebind modifiers
            col.operator(
                "object.bind_unbind_hhp_modifiers",
                text="Rebind Physics",
                icon='FILE_REFRESH'
            )

            # Add the new buttons for baking and freeing cache with confirmation
            row = col.row(align=True)
            row.operator("object.ptcache_bake_all", text="Bake All", icon='PHYSICS')
            row.operator("object.ptcache_free_bake_all", text="Free All", icon='X')

        # ----- Modified code starts here -----
        # Check for selected meshes with 'BS_Inflate' custom property OR cloth/soft body modifiers
        eligible_objects = []
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                has_bs_inflate = "BS_Inflate" in obj
                has_physics = any(m.type in {'CLOTH', 'SOFT_BODY'} for m in obj.modifiers)
                if has_bs_inflate or has_physics:
                    eligible_objects.append(obj)

        if eligible_objects:
            # Create a box
            box = layout.box()
            box.label(text="Displace selected proxies", icon='MODIFIER')
            for obj in eligible_objects:
                row = box.row(align=True)
                
                # Only show BS_Inflate slider if the object has that property
                if "BS_Inflate" in obj:
                    row.prop(obj, '["BS_Inflate"]', text=obj.name)

                # Add the Edit Cage buttons in the same row
                if props.is_edit_cage:
                    row.operator("hhp.finalize_cage_edit", text="Finalize Cage Edit", icon='CHECKMARK')
                else:
                    row.operator("hhp.edit_cage", text="Edit Cage (With Shapekey)", icon='SCULPTMODE_HLT')
        # ----- Modified code ends here -----

        # Lattice Shapekeys Section - Show when the active object is a lattice
        active_obj = context.active_object
        if active_obj and active_obj.type == 'LATTICE':
            lattice_box = layout.box()
            lattice_box.label(text="Lattice shapekeyes", icon='LATTICE_DATA')
            
            # Create the full shapekey editor interface
            draw_lattice_shapekey_editor(lattice_box, context, active_obj)

    def collect_collections(self, collection, collection_list, parent_hidden=False, is_top_level=False, processed_collections=None, level=0):
        if processed_collections is None:
            processed_collections = set()
        if collection in processed_collections:
            return
        processed_collections.add(collection)

        collection_list.append((collection, level, parent_hidden, is_top_level))

        # Determine if current parent is hidden
        current_parent_hidden = parent_hidden or collection.hide_viewport

        # Process children collections
        for child in collection.children:
            self.collect_collections(
                child,
                collection_list,
                parent_hidden=current_parent_hidden,
                is_top_level=False,
                processed_collections=processed_collections,
                level=level+1
            )

    def find_proxies_collections(self):
        """Find all 'Proxies (HHP)' and 'Collision' collections among the sibling collections of selected meshes."""
        proxies_collections = []
        processed_collections = set()

        # Collect parent collections of selected meshes
        parent_collections = set()
        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH':
                parent_collections.update(obj.users_collection)

        # Traverse parent collections
        for collection in parent_collections:
            # Find 'Proxies (HHP)' and 'Collision' collections among their children
            for sub_collection in collection.children:
                if (sub_collection.name.startswith("Proxies (HHP)") or sub_collection.name.startswith("Collision")) and sub_collection not in processed_collections:
                    self.collect_collections(
                        sub_collection,
                        proxies_collections,
                        parent_hidden=False,
                        is_top_level=True,
                        processed_collections=processed_collections
                    )
        return proxies_collections

    def collect_collision_objects(self, root_collection):
        """Recursively collect all objects from a Collision collection hierarchy."""
        objects = []

        def _recurse(coll):
            # Add all objects directly in this collection
            for obj in coll.objects:
                if obj not in objects:
                    objects.append(obj)
            # Recurse into child collections
            for child in coll.children:
                _recurse(child)

        _recurse(root_collection)
        return objects

    def make_collection_visible(self, collection):
        # Make this collection visible
        collection.hide_viewport = False
        # Recursively make parent collections visible
        parent_collections = [
            parent for parent in bpy.data.collections if collection.name in parent.children.keys()
        ]
        for parent in parent_collections:
            self.make_collection_visible(parent)


class HHP_OT_GenerateOptimizedCollision(bpy.types.Operator):
    """Generate an optimized collision mesh from the linked collision proxy."""
    bl_idname = "hhp.generate_optimized_collision"
    bl_label = "Generate optimized collision"
    bl_description = "Generate an optimized collision mesh from the linked collision proxy and decimate it to 0.25"
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(
        name="Collision Collection Name",
        description="Name of the Collision collection to generate optimized collision for"
    )

    def invoke(self, context, event):
        # Ask the user for confirmation before executing
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        collection = bpy.data.collections.get(self.collection_name)
        if not collection:
            self.report({'ERROR'}, f"Collision collection '{self.collection_name}' not found")
            return {'CANCELLED'}

        # Gather all objects in this collision collection hierarchy
        collision_objects = []

        def _recurse(coll):
            for obj in coll.objects:
                collision_objects.append(obj)
            for child in coll.children:
                _recurse(child)

        _recurse(collection)

        linked_name_tag = "Collision - Linked (DO NOT EDIT MESH)"
        linked_objects = [o for o in collision_objects if linked_name_tag in o.name]

        if not linked_objects:
            self.report({'ERROR'}, "No linked collision proxy found in this collection")
            return {'CANCELLED'}

        # Pick the linked object with the lowest enumeration:
        # base name (no .001) -> 0, otherwise use the numeric suffix.
        def enum_index(obj_name):
            m = re.search(r"\.(\d{3})$", obj_name)
            return int(m.group(1)) if m else 0

        source_obj = min(linked_objects, key=lambda o: enum_index(o.name))

        # Duplicate the object
        new_obj = source_obj.copy()
        # Make it a single user so it is no longer linked
        if new_obj.data:
            new_obj.data = new_obj.data.copy()

        # Rename to "Collision - Fullbody (Optimized)"
        new_obj.name = "Collision - Fullbody (Optimized)"

        # Link to the same collections as the source object
        for coll in source_obj.users_collection:
            if new_obj.name not in coll.objects:
                coll.objects.link(new_obj)

        # Ensure the new optimized mesh is enabled in viewport before further steps
        try:
            new_obj.hide_viewport = False
        except Exception:
            pass

        # Store current selection, active object and mode
        view_layer = context.view_layer
        original_active = view_layer.objects.active
        original_selection = [obj for obj in view_layer.objects if obj.select_get()]
        original_mode = 'OBJECT'
        if original_active:
            try:
                original_mode = original_active.mode
            except AttributeError:
                original_mode = 'OBJECT'

        # Make new_obj active and selected to apply edit-mode decimate
        bpy.ops.object.mode_set(mode='OBJECT')
        for obj in view_layer.objects:
            obj.select_set(False)
        new_obj.select_set(True)
        view_layer.objects.active = new_obj

        try:
            # Enter edit mode and perform decimate at 0.25, like:
            # edit mode > unhide all > select all > decimate to 0.25
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.reveal(select=True)
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.decimate(ratio=0.25)
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception as e:
            self.report({'WARNING'}, f"Could not perform edit-mode decimate: {e}")

        # Toggle visibility: turn off all linked collision proxies and turn on the new mesh
        for obj in linked_objects:
            try:
                obj.hide_viewport = True
            except Exception:
                pass

        try:
            new_obj.hide_viewport = False
        except Exception:
            pass

        # Restore original selection, active object and mode
        for obj in view_layer.objects:
            obj.select_set(False)
        for obj in original_selection:
            if obj.name in view_layer.objects:
                view_layer.objects[obj.name].select_set(True)
        if original_active and original_active.name in view_layer.objects:
            view_layer.objects.active = view_layer.objects[original_active.name]
            try:
                bpy.ops.object.mode_set(mode=original_mode)
            except Exception:
                pass

        self.report({'INFO'}, f"Generated optimized collision from '{source_obj.name}'")
        return {'FINISHED'}

class HHPProperties(PropertyGroup):
    """Stores temporary data for the cage editing process."""
    is_edit_cage: BoolProperty(
        name="Is Edit Cage Active",
        description="True when we are in the middle of cage editing",
        default=False
    )
    stored_object_name: StringProperty(
        name="Stored Object Name",
        description="Name of the mesh used for cage editing",
        default=""
    )
    stored_display_type: StringProperty(
        name="Stored Display Type",
        description="Original display type of the mesh",
        default=""
    )
    stored_modifier_states: StringProperty(
        name="Stored Modifiers States (JSON)",
        description="JSON string storing modifiers' viewport visibility",
        default=""
    )
    show_strength: BoolProperty(
        name="Show advanced",
        description="Show advanced settings for HHP physics",
        default=False
    )
    gravity_factor: FloatProperty(
        name="Gravity Factor",
        description="Controls the strength of gravity in physics simulations",
        default=1.0,
        min=0.0,
        max=1.0,
        precision=2
    )
    cage_subdiv_count: IntProperty(
        name="Cage Subdivision Count",
        description="Number of subdivisions applied to the cage (available unsubdiv operations)",
        default=0,
        min=0
    )

class HHP_OT_EditCage(bpy.types.Operator):
    """Edit cage shape with a new shapekey."""
    bl_idname = "hhp.edit_cage"
    bl_label = "Edit Cage (With Shapekey)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Active object is not a mesh.")
            return {'CANCELLED'}

        # Check for Cloth / Soft Body modifiers
        cloth_soft_mod_found = any(m.type in {'CLOTH', 'SOFT_BODY'} for m in obj.modifiers)
        if not cloth_soft_mod_found:
            self.report({'ERROR'}, "Active mesh has no Cloth or Soft Body modifiers.")
            return {'CANCELLED'}

        props = context.scene.hhp_props
        props.stored_object_name = obj.name

        # Store current visibility state of all modifiers
        modifiers_info = []
        for mod in obj.modifiers:
            modifiers_info.append({
                'name': mod.name,
                'type': mod.type,
                'show_viewport': mod.show_viewport
            })
        props.stored_modifier_states = json.dumps(modifiers_info)

        # Store current display type
        props.stored_display_type = obj.display_type

        # Set display type to SOLID
        obj.display_type = 'SOLID'

        # Switch to OBJECT mode
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Deselect all objects, select only the active one
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        # Disable all modifiers
        for mod in obj.modifiers:
            mod.show_viewport = False

        # Enter local view
        bpy.ops.view3d.localview(frame_selected=False)

        # Add shape keys (Basis if missing, plus "(BS)_SculptShapeKey")
        if not obj.data.shape_keys:
            obj.shape_key_add(name='Basis', from_mix=False)
        obj.shape_key_add(name="(BS)_SculptShapeKey", from_mix=False)
        # Make this shape key active
        obj.active_shape_key_index = len(obj.data.shape_keys.key_blocks) - 1
        # Set its value to 1
        obj.active_shape_key.value = 1

        # Enter sculpt mode
        bpy.ops.object.mode_set(mode='SCULPT')

        # Flag that we are in "edit cage" mode
        props.is_edit_cage = True

        return {'FINISHED'}

class HHP_OT_FinalizeCageEdit(bpy.types.Operator):
    """Finalize the Cage Edit (All Modifiers)."""
    bl_idname = "hhp.finalize_cage_edit"
    bl_label = "Finalize Cage Edit"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.hhp_props
        obj_name = props.stored_object_name
        if not obj_name:
            self.report({'ERROR'}, "No stored object name found. Cannot finalize.")
            return {'CANCELLED'}

        obj = bpy.data.objects.get(obj_name)
        if not obj:
            self.report({'ERROR'}, f"Object '{obj_name}' no longer exists.")
            return {'CANCELLED'}

        # Restore all modifiers' viewport visibility
        stored_modifiers = []
        if props.stored_modifier_states:
            stored_modifiers = json.loads(props.stored_modifier_states)

        for mod_state in stored_modifiers:
            mod_name = mod_state.get('name')
            show_viewport = mod_state.get('show_viewport', True)
            mod = obj.modifiers.get(mod_name)
            if mod:
                mod.show_viewport = show_viewport

        # Restore original display type
        if props.stored_display_type:
            obj.display_type = props.stored_display_type

        # Force an edit mode -> object mode cycle to refresh viewport
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.object.mode_set(mode='OBJECT')

        # Exit local view (if still in local view)
        bpy.ops.view3d.localview(frame_selected=False)

        # Reset the toggle
        props.is_edit_cage = False

        return {'FINISHED'}

class HHP_OT_SubdivCage(bpy.types.Operator):
    bl_idname = "hhp.subdiv_cage"
    bl_label = "Subdiv Cage"
    bl_description = "Subdivide the physics cage for better collision detection. This is heavy and is not recommended for non-advanced users."

    target_name: bpy.props.StringProperty(name="Target Object Name")

    def execute(self, context):
        target = bpy.data.objects.get(self.target_name)
        if not target:
            self.report({'ERROR'}, f"Target object '{self.target_name}' not found")
            return {'CANCELLED'}

        # Store original selection, active object and its mode
        orig_sel = context.selected_objects.copy()
        orig_active = context.view_layer.objects.active
        orig_mode = orig_active.mode if orig_active else 'OBJECT'

        bpy.ops.object.select_all(action='DESELECT')
        target.select_set(True)
        context.view_layer.objects.active = target

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.reveal(select=True)
        bpy.ops.mesh.select_all(action='SELECT')

        bpy.ops.mesh.subdivide(number_cuts=1, smoothness=1.00)

        bpy.ops.object.mode_set(mode=orig_mode)
        bpy.ops.object.select_all(action='DESELECT')
        for ob in orig_sel:
            ob.select_set(True)
        context.view_layer.objects.active = orig_active

        # Increment the subdiv count for the target object
        current_count = target.get("cage_subdiv_count", 0)
        target["cage_subdiv_count"] = current_count + 1

        return {'FINISHED'}

class HHP_OT_UnsubdivCage(bpy.types.Operator):
    bl_idname = "hhp.unsubdiv_cage"
    bl_label = "Unsubdiv Cage"
    bl_description = "Unsubdivide the physics cage for faster simulation"

    target_name: bpy.props.StringProperty(name="Target Object Name")

    def execute(self, context):
        target = bpy.data.objects.get(self.target_name)
        if not target:
            self.report({'ERROR'}, f"Target object '{self.target_name}' not found")
            return {'CANCELLED'}

        current_count = target.get("cage_subdiv_count", 0)
        if current_count < 1:
            self.report({'WARNING'}, "No subdiv operations to undo for this target.")
            return {'CANCELLED'}

        # Store original selection, active object and its mode
        orig_sel = context.selected_objects.copy()
        orig_active = context.view_layer.objects.active
        orig_mode = orig_active.mode if orig_active else 'OBJECT'

        bpy.ops.object.select_all(action='DESELECT')
        target.select_set(True)
        context.view_layer.objects.active = target

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.reveal(select=True)
        bpy.ops.mesh.select_all(action='SELECT')

        bpy.ops.mesh.unsubdivide(iterations=2)

        bpy.ops.object.mode_set(mode=orig_mode)
        bpy.ops.object.select_all(action='DESELECT')
        for ob in orig_sel:
            ob.select_set(True)
        context.view_layer.objects.active = orig_active

        # Decrement the subdiv count for the target object
        target["cage_subdiv_count"] = current_count - 1

        return {'FINISHED'}

# -------------------------------------------------------------------
# Lattice Shapekey Editor
# -------------------------------------------------------------------

def draw_lattice_shapekey_editor(layout, context, obj):
    """Draw lattice shapekey list in Blender style with category filters"""
    if not obj or obj.type != 'LATTICE':
        layout.label(text="Select a lattice object")
        return
        
    # Create main column
    main_col = layout.column(align=True)
    
    # Draw the list with add/copy/remove buttons
    list_row = main_col.row()
    
    # Left side - the list
    list_col = list_row.column()
    rows = 12
    
    # Show the template_list (empty if no shapekeys)
    if obj.data.shape_keys:
        list_col.template_list(
            "HHP_UL_LatticeShapekeysList", "",
            obj.data.shape_keys, "key_blocks",
            obj, "active_shape_key_index",
            rows=rows
        )
    else:
        # Just show empty space
        pass
    
    # Right side - add/copy/remove buttons
    buttons_col = list_row.column(align=True)
    buttons_col.operator("hhp.add_lattice_shapekey", text="", icon='ADD')
    buttons_col.operator("hhp.copy_lattice_shapekey", text="", icon='DUPLICATE')
    buttons_col.operator("hhp.remove_lattice_shapekey", text="", icon='REMOVE')
    
    if not obj.data.shape_keys:
        return
        
    shape_keys = obj.data.shape_keys
    wm = context.window_manager
    
    # Controls
    if obj.data.shape_keys:
        controls_row = main_col.row(align=True)
        
        # Left column: Mute controls
        left_col = controls_row.column(align=True)
        
        # Check if any shapekeys are muted (excluding basis if it exists)
        any_muted = False
        for i, sk in enumerate(obj.data.shape_keys.key_blocks):
            if i > 0 and sk.mute:  # Skip basis shapekey if it exists
                any_muted = True
                break
        
        # Mute toggle button
        mute_row = left_col.row(align=True)
        if any_muted:
            mute_row.alert = True
        
        mute_op = mute_row.operator("hhp.toggle_lattice_shapekey_mute", 
                                   text="Unmute" if any_muted else "Mute",
                                   icon='HIDE_ON' if any_muted else 'HIDE_OFF')
        mute_op.mute_state = not any_muted
        
        # Right column: Edit controls
        right_col = controls_row.column(align=True)
        right_col.prop(obj, "show_only_shape_key", text="Shapekey Lock")
        right_col.prop(obj, "use_shape_key_edit_mode", text="Edit Mode")
        
        # Set values button
        set_values_row = main_col.row(align=True)
        set_values_row.operator("hhp.set_lattice_shapekey_values", text="Set Values", icon='RNA')
        
        # Min/Max controls if we have an active shapekey (excluding basis)
        if obj.active_shape_key and obj.active_shape_key_index > 0:
            control_key = obj.active_shape_key
            min_max_row = main_col.row(align=True)
            min_max_row.prop(control_key, "slider_min", text="Range Min")
            min_max_row.prop(control_key, "slider_max", text="Max")
            
            # Vertex Group
            main_col.prop_search(control_key, "vertex_group", obj, "vertex_groups", text="")



class HHP_OT_SetLatticeShapekeyValues(bpy.types.Operator):
    """Set values for lattice shapekeys"""
    bl_idname = "hhp.set_lattice_shapekey_values"
    bl_label = "Set Lattice Shapekey Values"
    bl_description = "Set all lattice shapekeys to the specified value (excluding Basis)"
    bl_options = {'REGISTER', 'UNDO'}
    
    value: bpy.props.FloatProperty(
        name="Value",
        description="Value to set for all lattice shapekeys",
        default=0.0,
        min=0.0,
        soft_max=1.0,
        max=10.0,
        precision=3
    )
    keyframe: bpy.props.BoolProperty(
        name="Keyframe Values",
        description="If enabled, keyframe the shapekeys when setting values",
        default=False
    )
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.prop(self, "value", slider=True)
        row.prop(self, "keyframe", text="", icon='KEYINGSET')
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'LATTICE' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        current_frame = context.scene.frame_current
        
        # Set values for all shapekeys except Basis (index 0)
        for i, sk in enumerate(obj.data.shape_keys.key_blocks):
            if i > 0:  # Skip basis shapekey if it exists
                sk.value = self.value
                if self.keyframe:
                    sk.keyframe_insert("value", frame=current_frame)
        
        return {'FINISHED'}

class HHP_OT_ToggleLatticeShapekeyMute(bpy.types.Operator):
    """Toggle mute state for lattice shapekeys"""
    bl_idname = "hhp.toggle_lattice_shapekey_mute"
    bl_label = "Toggle Lattice Shapekey Mute"
    bl_description = "Toggle mute state for all lattice shapekeys (excluding Basis)"
    bl_options = {'REGISTER', 'UNDO'}
    
    mute_state: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'LATTICE' and obj.data.shape_keys
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'LATTICE' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        # Apply mute state to all shapekeys except Basis (index 0)
        for i, sk in enumerate(obj.data.shape_keys.key_blocks):
            if i > 0:  # Skip basis shapekey if it exists
                sk.mute = self.mute_state
        
        return {'FINISHED'}

class HHP_OT_AddLatticeShapekey(bpy.types.Operator):
    """Add a new lattice shapekey"""
    bl_idname = "hhp.add_lattice_shapekey"
    bl_label = "Add Lattice Shapekey"
    bl_description = "Add a new shapekey to the lattice"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'LATTICE'
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'LATTICE':
            self.report({'ERROR'}, "Active object is not a lattice")
            return {'CANCELLED'}
        
        # If no shape keys exist, create "Basis" as the first one
        if not obj.data.shape_keys:
            new_key = obj.shape_key_add(name="Basis", from_mix=False)
            new_key.value = 1.0  # Set value to 1.00
            obj.active_shape_key_index = 0
            self.report({'INFO'}, "Added shapekey 'Basis' with value 1.0")
            return {'FINISHED'}
        
        # Find the next key number based on stack position (ignoring Basis)
        existing_keys = obj.data.shape_keys.key_blocks
        non_basis_count = len(existing_keys) - 1  # Subtract 1 for Basis
        next_number = non_basis_count + 1
        
        # Create new shapekey
        new_key_name = f"Key {next_number}"
        new_key = obj.shape_key_add(name=new_key_name, from_mix=False)
        new_key.value = 1.0  # Set value to 1.00
        
        # Set as active
        for i, sk in enumerate(obj.data.shape_keys.key_blocks):
            if sk.name == new_key_name:
                obj.active_shape_key_index = i
                break
        
        self.report({'INFO'}, f"Added shapekey '{new_key_name}' with value 1.0")
        return {'FINISHED'}

class HHP_OT_CopyLatticeShapekey(bpy.types.Operator):
    """Copy the active lattice shapekey"""
    bl_idname = "hhp.copy_lattice_shapekey"
    bl_label = "Copy Lattice Shapekey"
    bl_description = "Copy the active shapekey"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'LATTICE' and obj.data.shape_keys and 
                obj.active_shape_key and obj.active_shape_key_index > 0)
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'LATTICE' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        if not obj.active_shape_key or obj.active_shape_key_index <= 0:
            self.report({'ERROR'}, "No valid shapekey selected (cannot copy Basis)")
            return {'CANCELLED'}
        
        active_key = obj.active_shape_key
        
        # Get base name without existing enumeration
        base_name = active_key.name
        # Remove existing .001, .002, etc. enumeration if present
        import re
        base_name = re.sub(r'\.\d{3}$', '', base_name)
        
        # Find next available enumeration number
        counter = 1
        copy_name = f"{base_name}.{counter:03d}"
        while copy_name in [sk.name for sk in obj.data.shape_keys.key_blocks]:
            counter += 1
            copy_name = f"{base_name}.{counter:03d}"
        
        # Create new shapekey from the active one
        new_key = obj.shape_key_add(name=copy_name, from_mix=False)
        new_key.value = active_key.value
        new_key.slider_min = active_key.slider_min
        new_key.slider_max = active_key.slider_max
        new_key.mute = active_key.mute
        
        # Copy the shape data
        for i, point in enumerate(active_key.data):
            new_key.data[i].co = point.co.copy()
        
        # Set as active
        for i, sk in enumerate(obj.data.shape_keys.key_blocks):
            if sk.name == copy_name:
                obj.active_shape_key_index = i
                break
        
        self.report({'INFO'}, f"Copied shapekey as '{copy_name}'")
        return {'FINISHED'}

class HHP_OT_RemoveLatticeShapekey(bpy.types.Operator):
    """Remove the active lattice shapekey"""
    bl_idname = "hhp.remove_lattice_shapekey"
    bl_label = "Remove Lattice Shapekey"
    bl_description = "Remove the active shapekey (including Basis)"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'LATTICE' and obj.data.shape_keys and 
                obj.active_shape_key)
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'LATTICE' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        if not obj.active_shape_key:
            self.report({'ERROR'}, "No shapekey selected")
            return {'CANCELLED'}
        
        active_key = obj.active_shape_key
        key_name = active_key.name
        
        # Remove the shapekey
        obj.shape_key_remove(active_key)
        
        self.report({'INFO'}, f"Removed shapekey '{key_name}'")
        return {'FINISHED'}



def register():
    bpy.utils.register_class(HHPProperties)
    bpy.types.Scene.hhp_props = PointerProperty(type=HHPProperties)
    
    # Add the custom property to bpy.types.Collection
    bpy.types.Collection.show_collection = BoolProperty(
        name="",
        description="Toggle Collection Visibility",
        get=get_show_collection,
        set=set_show_collection
    )
    # Add a custom property to bpy.types.Object for viewport-only visibility toggling
    bpy.types.Object.show_object_viewport = BoolProperty(
        name="",
        description="Toggle Object Viewport Visibility",
        get=get_show_object_viewport,
        set=set_show_object_viewport
    )
    bpy.utils.register_class(HHP_OT_GenerateOptimizedCollision)
    
    bpy.utils.register_class(HHP_UL_LatticeShapekeysList)
    bpy.utils.register_class(HHP_OT_SetLatticeShapekeyValues)
    bpy.utils.register_class(HHP_OT_ToggleLatticeShapekeyMute)
    bpy.utils.register_class(HHP_OT_AddLatticeShapekey)
    bpy.utils.register_class(HHP_OT_CopyLatticeShapekey)
    bpy.utils.register_class(HHP_OT_RemoveLatticeShapekey)
    bpy.utils.register_class(HHP_OT_EditCage)
    bpy.utils.register_class(HHP_OT_FinalizeCageEdit)
    bpy.utils.register_class(OBJECT_OT_ToggleModifierVisibility)
    bpy.utils.register_class(OBJECT_OT_SelectSyncSource)
    bpy.utils.register_class(OBJECT_OT_BindUnbindHHPModifiers)
    bpy.utils.register_class(OBJECT_OT_PtcacheBakeAll)
    bpy.utils.register_class(OBJECT_OT_PtcacheFreeBakeAll)
    bpy.utils.register_class(OBJECT_OT_PhysicsFramerateMultiplier)
    bpy.utils.register_class(OBJECT_PT_ProxiesVisibilityPanel)
    bpy.utils.register_class(HHP_OT_SubdivCage)
    bpy.utils.register_class(HHP_OT_UnsubdivCage)

def unregister():
    bpy.utils.unregister_class(HHP_OT_RemoveLatticeShapekey)
    bpy.utils.unregister_class(HHP_OT_CopyLatticeShapekey)
    bpy.utils.unregister_class(HHP_OT_AddLatticeShapekey)
    bpy.utils.unregister_class(HHP_OT_ToggleLatticeShapekeyMute)
    bpy.utils.unregister_class(HHP_OT_SetLatticeShapekeyValues)
    bpy.utils.unregister_class(HHP_UL_LatticeShapekeysList)
    bpy.utils.unregister_class(OBJECT_PT_ProxiesVisibilityPanel)
    bpy.utils.unregister_class(OBJECT_OT_PtcacheFreeBakeAll)
    bpy.utils.unregister_class(OBJECT_OT_PtcacheBakeAll)
    bpy.utils.unregister_class(OBJECT_OT_BindUnbindHHPModifiers)
    bpy.utils.unregister_class(OBJECT_OT_SelectSyncSource)
    bpy.utils.unregister_class(OBJECT_OT_ToggleModifierVisibility)
    bpy.utils.unregister_class(HHP_OT_FinalizeCageEdit)
    bpy.utils.unregister_class(HHP_OT_EditCage)
    bpy.utils.unregister_class(OBJECT_OT_PhysicsFramerateMultiplier)
    bpy.utils.unregister_class(HHP_OT_UnsubdivCage)
    bpy.utils.unregister_class(HHP_OT_SubdivCage)
    bpy.utils.unregister_class(HHP_OT_GenerateOptimizedCollision)
    del bpy.types.Scene.hhp_props
    bpy.utils.unregister_class(HHPProperties)
    # Remove the custom property from bpy.types.Collection
    del bpy.types.Collection.show_collection
    # Remove the custom property from bpy.types.Object
    del bpy.types.Object.show_object_viewport

if __name__ == "__main__":
    register()
