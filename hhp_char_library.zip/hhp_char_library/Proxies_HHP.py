import bpy
from bpy.props import BoolProperty, StringProperty, PointerProperty, IntProperty, FloatProperty, EnumProperty
from bpy.types import PropertyGroup, UIList
import blf
import json
import re
import time
from contextlib import contextmanager
from bpy.app.handlers import persistent
from .modules import physics_autobake
from .modules import character_membership


HHP_CAGE_TOPOLOGY_PROP = "hhp_original_cage_topology"
HHP_PHYSICS_SHAPE_PRESET_PROP = "hhp_physics_shape_preset"
HHP_PHYSICS_MASS_BASELINE_PROP = "hhp_physics_mass_baseline"
HHP_PHYSICS_PRESSURE_BASELINE_PROP = "hhp_physics_pressure_baseline"
HHP_PHYSICS_MASS_CHANGED_PROP = "hhp_physics_mass_changed"
HHP_PHYSICS_PRESSURE_CHANGED_PROP = "hhp_physics_pressure_changed"


def hhp_get_cloth_modifier(obj):
    if obj is None or obj.type != 'MESH':
        return None
    return next((mod for mod in obj.modifiers if mod.type == 'CLOTH'), None)


def hhp_store_physics_shape_defaults(target):
    cloth = hhp_get_cloth_modifier(target)
    if cloth is None:
        return None

    current_mass = cloth.settings.mass
    current_pressure = cloth.settings.pressure_factor
    if HHP_PHYSICS_MASS_BASELINE_PROP not in target:
        target[HHP_PHYSICS_MASS_BASELINE_PROP] = current_mass
    if HHP_PHYSICS_PRESSURE_BASELINE_PROP not in target:
        target[HHP_PHYSICS_PRESSURE_BASELINE_PROP] = current_pressure
    if HHP_PHYSICS_MASS_CHANGED_PROP not in target:
        target[HHP_PHYSICS_MASS_CHANGED_PROP] = current_mass
    if HHP_PHYSICS_PRESSURE_CHANGED_PROP not in target:
        target[HHP_PHYSICS_PRESSURE_CHANGED_PROP] = current_pressure
    return cloth


def hhp_apply_physics_shape_preset(target, preset):
    cloth = hhp_store_physics_shape_defaults(target)
    if cloth is None:
        return

    settings = cloth.settings
    baseline_mass = float(target.get(HHP_PHYSICS_MASS_BASELINE_PROP, settings.mass))
    baseline_pressure = float(target.get(HHP_PHYSICS_PRESSURE_BASELINE_PROP, settings.pressure_factor))

    if preset == 'NATURAL_PRESERVE_SHAPE':
        settings.mass = baseline_mass
        settings.pressure_factor = 2000.0
    elif preset == 'FIRM':
        settings.mass = baseline_mass / 6.0
        settings.pressure_factor = 2000.0
    else:
        settings.mass = baseline_mass
        settings.pressure_factor = baseline_pressure

    target[HHP_PHYSICS_MASS_CHANGED_PROP] = settings.mass
    target[HHP_PHYSICS_PRESSURE_CHANGED_PROP] = settings.pressure_factor


def hhp_update_physics_shape_preset(self, context):
    hhp_apply_physics_shape_preset(self, self.hhp_physics_shape_preset)


def hhp_deform_modifier_target(mod):
    if mod.type == 'SURFACE_DEFORM':
        return mod.target
    if mod.type == 'MESH_DEFORM':
        return mod.object
    return None


def hhp_is_hhp_proxy_object(obj):
    for collection in getattr(obj, "users_collection", []):
        if "Proxies (HHP)" in hhp_collection_or_parent_base_names(collection):
            return True
    return False


def hhp_store_object_physics_shape_defaults(obj):
    if obj is None or obj.type != 'MESH':
        return

    if hhp_is_hhp_proxy_object(obj):
        hhp_store_physics_shape_defaults(obj)

    for mod in obj.modifiers:
        if hhp_is_deform_modifier(mod):
            hhp_store_physics_shape_defaults(hhp_deform_modifier_target(mod))


def hhp_store_collection_physics_shape_defaults(collection):
    for obj in collection.objects:
        hhp_store_object_physics_shape_defaults(obj)
    for child in collection.children:
        hhp_store_collection_physics_shape_defaults(child)


def hhp_switch_viewports_to_solid(context):
    shading_state = []
    screens = []
    window_manager = getattr(context, "window_manager", None)
    if window_manager:
        for window in window_manager.windows:
            screen = getattr(window, "screen", None)
            if screen and screen not in screens:
                screens.append(screen)

    screen = getattr(context, "screen", None)
    if screen and screen not in screens:
        screens.append(screen)

    for screen in screens:
        for area in screen.areas:
            if area.type != 'VIEW_3D':
                continue
            for space in area.spaces:
                if space.type != 'VIEW_3D':
                    continue
                shading = getattr(space, "shading", None)
                if not shading:
                    continue
                shading_state.append((space, shading.type))
                shading.type = 'SOLID'
    return shading_state


def hhp_restore_viewport_shading(shading_state):
    for space, shading_type in shading_state:
        try:
            space.shading.type = shading_type
        except Exception:
            pass


def hhp_enable_simplify_zero_viewport(context):
    render = getattr(context.scene, "render", None)
    if not render or not hasattr(render, "use_simplify") or not hasattr(render, "simplify_subdivision"):
        return None

    use_simplify = render.use_simplify
    simplify_subdivision = render.simplify_subdivision
    if use_simplify and simplify_subdivision == 0:
        return None

    render.use_simplify = True
    render.simplify_subdivision = 0
    return (render, use_simplify, simplify_subdivision)


def hhp_restore_simplify_state(simplify_state):
    if not simplify_state:
        return

    render, use_simplify, simplify_subdivision = simplify_state
    try:
        render.use_simplify = use_simplify
        render.simplify_subdivision = simplify_subdivision
    except Exception:
        pass


def hhp_format_elapsed_time(start_time):
    elapsed = max(0.0, time.perf_counter() - start_time)
    if elapsed >= 60.0:
        minutes = int(elapsed // 60)
        seconds = elapsed - (minutes * 60)
        return f"{minutes}m {seconds:.1f}s"
    return f"{elapsed:.1f}s"


# Define getter and setter functions for the collection custom property
def get_show_collection(self):
    return not self.hide_viewport

def set_show_collection(self, value):
    self.hide_viewport = not value


def get_show_object_viewport(self):
    """Return viewport visibility only (ignore render visibility)."""
    return not self.hide_viewport


def set_show_object_viewport(self, value):
    """Control only the viewport visibility (leave render visibility unchanged)."""
    self.hide_viewport = not value


def hhp_collection_base_name(collection_name):
    return re.sub(r"\.\d{3}$", "", collection_name)


def hhp_collection_contains_object(collection, obj):
    if obj.name in collection.objects.keys():
        return True
    return any(hhp_collection_contains_object(child, obj) for child in collection.children)


def hhp_parent_collections(collection):
    parents = []
    for parent in bpy.data.collections:
        if collection.name in parent.children.keys():
            parents.append(parent)
            parents.extend(hhp_parent_collections(parent))
    return parents


def hhp_collection_or_parent_base_names(collection):
    return {
        hhp_collection_base_name(col.name)
        for col in [collection] + hhp_parent_collections(collection)
    }


def hhp_physics_element_category(obj):
    is_clothes_or_appendage = False

    for collection in getattr(obj, "users_collection", []):
        base_name = hhp_collection_base_name(collection.name)
        ancestry_names = hhp_collection_or_parent_base_names(collection)

        if base_name == "Char (HHP)":
            return 'PRIMARY'
        if "Clothes" in ancestry_names or "Appendages" in ancestry_names:
            is_clothes_or_appendage = True

    if is_clothes_or_appendage:
        return 'SECONDARY'
    return 'OTHER'


def hhp_physics_element_icon(obj):
    category = hhp_physics_element_category(obj)
    if category == 'PRIMARY':
        return 'STRIP_COLOR_01'
    if category == 'SECONDARY':
        return 'STRIP_COLOR_05'
    return 'STRIP_COLOR_08'


def hhp_is_in_excluded_physics_collection(obj):
    excluded_collection_names = {"Proxies (HHP)", "Collision"}
    excluded_collections = [
        collection for collection in bpy.data.collections
        if hhp_collection_base_name(collection.name) in excluded_collection_names
    ]
    return any(hhp_collection_contains_object(collection, obj) for collection in excluded_collections)


def hhp_is_visible_in_viewport(obj, context):
    if obj.hide_viewport:
        return False
    if hasattr(obj, "hide_get") and obj.hide_get():
        return False
    return obj.visible_get(view_layer=context.view_layer)


def hhp_collection_is_visible_in_hhp_path(layer_collection, target_collection, path_visible=True, has_char_parent=False):
    collection = layer_collection.collection
    collection_visible = not getattr(collection, "hide_viewport", False)
    layer_visible = not layer_collection.exclude and not getattr(layer_collection, "hide_viewport", False)
    current_path_visible = path_visible and collection_visible and layer_visible
    current_has_char_parent = has_char_parent or hhp_collection_base_name(collection.name) == "Char (HHP)"

    if collection == target_collection:
        return current_path_visible and current_has_char_parent

    return any(
        hhp_collection_is_visible_in_hhp_path(
            child,
            target_collection,
            current_path_visible,
            current_has_char_parent
        )
        for child in layer_collection.children
    )


def hhp_is_visible_in_hhp_collection_path(obj, context):
    layer_root = context.view_layer.layer_collection
    return any(
        hhp_collection_is_visible_in_hhp_path(layer_root, collection)
        for collection in getattr(obj, "users_collection", [])
    )


def hhp_has_physics_modifier(obj):
    if obj.type != 'MESH':
        return False
    return any(
        mod.type in {'MESH_DEFORM', 'SURFACE_DEFORM'} and (mod.name.startswith("(HHP)") or mod.name.startswith("(HHPs)"))
        for mod in obj.modifiers
    )


def hhp_is_deform_modifier(mod):
    return (
        mod.type in {'MESH_DEFORM', 'SURFACE_DEFORM'}
        and (mod.name.startswith("(HHP)") or mod.name.startswith("(HHPs)"))
    )


def hhp_is_active_physics_modifier(mod):
    """Return enabled HHP/HHPs modifiers whose proxy state may be refreshed."""
    return (
        mod.name.startswith(('(HHP)', '(HHPs)'))
        and mod.type in {'SURFACE_DEFORM', 'MESH_DEFORM', 'CORRECTIVE_SMOOTH', 'CLOTH'}
        and mod.show_viewport and mod.show_render
    )


def hhp_is_active_rebind_modifier(mod):
    """Return enabled (HHP) modifiers whose bind data may be rebuilt.

    The "s" in (HHPs) means "static": those modifiers still have their proxies
    refreshed, but their existing bind data must never be unbound or rebuilt.
    """
    return mod.name.startswith('(HHP)') and hhp_is_active_physics_modifier(mod)


def hhp_collect_linked_rebind_meshes(context, source_objects):
    """Include same-data meshes in this scene, regardless of object visibility."""
    mesh_data = {obj.data for obj in source_objects if obj.type == 'MESH'}
    return [obj for obj in context.scene.objects
            if obj.type == 'MESH' and obj.data in mesh_data]


@contextmanager
def hhp_rebind_mesh_visibility(context, objects):
    """Temporarily expose linked bind owners, then restore their visibility."""
    view_layer = context.view_layer
    owners = [obj for obj in objects
              if any(hhp_is_active_physics_modifier(mod) for mod in obj.modifiers)]
    owner_collections = {col for obj in owners for col in obj.users_collection}
    layer_states = []
    owner_layers = []
    collection_states = {}
    object_states = []

    def collect_paths(layer, ancestors=()):
        # Excluding a parent also changes descendant exclusion flags in Blender.
        # Snapshot the entire tree before touching any path and restore top-down.
        layer_states.append((layer, layer.exclude, layer.hide_viewport))
        path = ancestors + (layer,)
        if layer.collection in owner_collections:
            for item in path:
                if item not in owner_layers:
                    owner_layers.append(item)
                    col = item.collection
                    collection_states[col] = (col.hide_viewport, col.hide_select)
        for child in layer.children:
            collect_paths(child, path)

    collect_paths(view_layer.layer_collection)
    try:
        for col in collection_states:
            col.hide_viewport = False
            col.hide_select = False
        for layer in owner_layers:
            layer.exclude = False
            layer.hide_viewport = False
        view_layer.update()
        for obj in owners:
            if obj.name not in view_layer.objects:
                continue
            object_states.append((obj, obj.hide_viewport, obj.hide_select,
                                  obj.hide_get(view_layer=view_layer)))
            obj.hide_viewport = False
            obj.hide_select = False
            obj.hide_set(False, view_layer=view_layer)
        view_layer.update()
        yield
    finally:
        for obj, hide_viewport, hide_select, hidden in object_states:
            obj.hide_set(hidden, view_layer=view_layer)
            obj.hide_viewport = hide_viewport
            obj.hide_select = hide_select
        for col, (hide_viewport, hide_select) in collection_states.items():
            col.hide_viewport = hide_viewport
            col.hide_select = hide_select
        for layer, excluded, hidden in layer_states:
            if layer.exclude != excluded:
                layer.exclude = excluded
            layer.hide_viewport = hidden
        view_layer.update()


def hhp_collect_scope_physics_objects(context):
    if context.scene.hhp_props.physics_display_scope == 'ALL':
        return hhp_collect_visible_physics_objects(context)

    physics_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
    if context.active_object and context.active_object.type == 'MESH' and context.active_object not in physics_objects:
        physics_objects.append(context.active_object)
    return physics_objects


def hhp_collect_visible_physics_objects(context):
    physics_objects = []
    seen_objects = set()
    excluded_branch_names = {"Proxies (HHP)", "Collision"}

    def collect_from_layer_collection(layer_collection, path_visible=True, in_char_tree=False, in_excluded_branch=False):
        collection = layer_collection.collection
        base_name = hhp_collection_base_name(collection.name)
        collection_visible = not getattr(collection, "hide_viewport", False)
        layer_visible = not layer_collection.exclude and not getattr(layer_collection, "hide_viewport", False)
        current_path_visible = path_visible and collection_visible and layer_visible
        current_in_char_tree = in_char_tree or base_name == "Char (HHP)"
        current_excluded_branch = in_excluded_branch or (current_in_char_tree and base_name in excluded_branch_names)

        if current_path_visible and current_in_char_tree and not current_excluded_branch:
            for obj in collection.objects:
                if obj.name in seen_objects:
                    continue
                if (
                    obj.type == 'MESH'
                    and hhp_is_visible_in_viewport(obj, context)
                    and hhp_has_physics_modifier(obj)
                ):
                    seen_objects.add(obj.name)
                    physics_objects.append(obj)

        for child in layer_collection.children:
            collect_from_layer_collection(
                child,
                current_path_visible,
                current_in_char_tree,
                current_excluded_branch
            )

    collect_from_layer_collection(context.view_layer.layer_collection)
    return physics_objects


class OBJECT_OT_ToggleModifierVisibility(bpy.types.Operator):
    bl_idname = "object.toggle_modifier_visibility"
    bl_label = "Toggle Modifier Visibility"
    bl_description = "Toggle the visibility of a modifier in both viewport and render"

    object_name: bpy.props.StringProperty()
    modifier_name: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        if obj is None:
            self.report({'ERROR'}, f"Object '{self.object_name}' not found")
            return {'CANCELLED'}
        mod = obj.modifiers.get(self.modifier_name)
        if mod is None:
            self.report({'ERROR'}, f"Modifier '{self.modifier_name}' not found on object '{self.object_name}'")
            return {'CANCELLED'}

        new_state = not (mod.show_viewport and mod.show_render)
        mod.show_viewport = new_state
        mod.show_render = new_state

        # If the modifier is being enabled, make sure the target mesh is visible
        if new_state:
            target_obj = None
            # For Mesh Deform and Surface Deform modifiers
            if mod.type == 'MESH_DEFORM':
                target_obj = mod.object
            elif mod.type == 'SURFACE_DEFORM':
                target_obj = mod.target

            if target_obj:
                # Make the target object visible in viewport
                target_obj.hide_viewport = False
                target_obj.hide_set(False, view_layer=context.view_layer)

                # Make sure the collections the target object is in are visible
                for collection in target_obj.users_collection:
                    self.make_collection_visible(collection)
        return {'FINISHED'}

    def make_collection_visible(self, collection):
        # Make this collection visible
        collection.hide_viewport = False
        # Recursively make parent collections visible
        parent_collections = [
            parent for parent in bpy.data.collections if collection.name in parent.children.keys()
        ]
        for parent in parent_collections:
            self.make_collection_visible(parent)


class OBJECT_OT_ToggleHHPPhysicsGroupVisibility(bpy.types.Operator):
    bl_idname = "object.toggle_hhp_physics_group_visibility"
    bl_label = "Toggle HHP Physics Group"
    bl_description = "Toggle grouped HHP physics modifiers"

    group: bpy.props.EnumProperty(
        name="Physics Group",
        items=[
            ('PRIMARY', "Primary", "Toggle on/off all primary HHP character physics (anything directly affecting the character mesh such as breast jiggle, belly flop, butt cheek jiggle, etc...)"),
            ('SECONDARY', "Secondary", "Toggle on/off all secondary HHP physics (anything attached to the character such as hair, accessories, clothes, etc...)"),
        ],
        default='PRIMARY'
    )

    @classmethod
    def description(cls, context, properties):
        if properties.group == 'PRIMARY':
            return "Toggle on/off all primary HHP character physics (anything directly affecting the character mesh such as breast jiggle, belly flop, butt cheek jiggle, etc...)"
        return "Toggle on/off all secondary HHP physics (anything attached to the character such as hair, accessories, clothes, etc...)"

    def execute(self, context):
        modifiers = []
        for obj in hhp_collect_scope_physics_objects(context):
            if hhp_physics_element_category(obj) != self.group:
                continue
            for mod in obj.modifiers:
                if hhp_is_deform_modifier(mod):
                    modifiers.append((obj, mod))

        if not modifiers:
            group_name = "primary" if self.group == 'PRIMARY' else "secondary"
            self.report({'WARNING'}, f"No {group_name} HHP physics found")
            return {'CANCELLED'}

        new_state = not all(mod.show_viewport and mod.show_render for _, mod in modifiers)
        for obj, mod in modifiers:
            mod.show_viewport = new_state
            mod.show_render = new_state
            if new_state:
                target_obj = mod.object if mod.type == 'MESH_DEFORM' else mod.target
                if target_obj:
                    target_obj.hide_viewport = False
                    target_obj.hide_set(False, view_layer=context.view_layer)
                    for collection in target_obj.users_collection:
                        self.make_collection_visible(collection)

        return {'FINISHED'}

    def make_collection_visible(self, collection):
        collection.hide_viewport = False
        for parent in [parent for parent in bpy.data.collections if collection.name in parent.children.keys()]:
            self.make_collection_visible(parent)


class OBJECT_OT_BindUnbindHHPModifiers(bpy.types.Operator):
    bl_idname = "object.bind_unbind_hhp_modifiers"
    bl_label = "Rebind Modifiers"
    bl_description = "Refresh enabled HHP proxy targets and rebind only (HHP) modifiers; keep (HHPs) bind data unchanged"
    
    skip_sync_check: bpy.props.BoolProperty(default=False, options={'HIDDEN'})
    rebind_all_visible: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def has_hhp_modifiers(self, obj):
        """Check if an object has HHP modifiers"""
        if obj.type != 'MESH':
            return False
        for mod in obj.modifiers:
            if mod.type == 'SURFACE_DEFORM' and (mod.name.startswith('(HHP)') or mod.name.startswith('(HHPs)')):
                return True
        return False

    def check_sync_choices_needed(self, context):
        """Check if any selected meshes need source selection for syncing"""
        choices_needed = {}
        
        for selected_obj in context.selected_objects:
            if selected_obj.type != 'MESH':
                continue
                
            # Find all linked meshes that share the same mesh data
            linked_meshes = [obj for obj in hhp_collect_linked_rebind_meshes(context, [selected_obj])
                             if obj != selected_obj]
            
            if not linked_meshes:
                continue
                
            # Separate wire-type and non-wire-type meshes
            # Wire-type: display_type == 'WIRE' OR (display_type != 'WIRE' AND no HHP modifiers)
            # Non-wire-type: display_type != 'WIRE' AND has HHP modifiers
            wire_type_meshes = [obj for obj in linked_meshes 
                               if obj.display_type == 'WIRE' or not self.has_hhp_modifiers(obj)]
            non_wire_type_meshes = [obj for obj in linked_meshes 
                                   if obj.display_type != 'WIRE' and self.has_hhp_modifiers(obj)]
            
            # Check if selected object is wire-type or non-wire-type
            selected_is_wire_type = (selected_obj.display_type == 'WIRE' or not self.has_hhp_modifiers(selected_obj))
            
            # Check if we need source selection
            if selected_is_wire_type:
                # Selected mesh is wire-type, need to sync from non-wire-type
                if len(non_wire_type_meshes) > 1:
                    choices_needed[selected_obj.name] = {
                        'type': 'wire_to_nonwire',
                        'sources': [obj.name for obj in non_wire_type_meshes],
                        'targets': [obj.name for obj in linked_meshes]  # ALL linked meshes
                    }
            else:
                # Selected mesh is non-wire-type
                if linked_meshes:  # Has linked meshes to sync to
                    if len(non_wire_type_meshes) > 0:  # Has other non-wire-type options
                        all_non_wire_type = [selected_obj] + non_wire_type_meshes
                        choices_needed[selected_obj.name] = {
                            'type': 'nonwire_to_wire',
                            'sources': [obj.name for obj in all_non_wire_type],
                            'targets': [obj.name for obj in linked_meshes]  # ALL linked meshes
                        }
        
        return choices_needed if choices_needed else None

    def draw_sync_menu(self, menu, context):
        """Draw the sync source selection menu"""
        layout = menu.layout
        if 'sync_choices_data' in context.scene:
            choices_data = context.scene['sync_choices_data']
            for mesh_name, choice_data in choices_data.items():
                for source_name in choice_data['sources']:
                    op = layout.operator("object.select_sync_source", text=source_name)
                    op.mesh_name = mesh_name
                    op.source_name = source_name
                layout.separator()

    def execute(self, context):
        if self.rebind_all_visible:
            return self.execute_all_visible_rebind(context)

        # Check if we need source selection for wire/non-wire syncing (unless skipping)
        if not self.skip_sync_check:
            sync_choices_needed = self.check_sync_choices_needed(context)
            if sync_choices_needed:
                # Store the sync choices data and show popup
                context.scene['sync_choices_data'] = sync_choices_needed
                context.scene['sync_rebind_all_visible'] = False
                context.window_manager.popup_menu(self.draw_sync_menu, title="Choose sync source")
                return {'FINISHED'}
        
        return self.execute_rebind(context)

    def execute_all_visible_rebind(self, context):
        visible_physics_objects = [
            obj for obj in hhp_collect_visible_physics_objects(context)
            if any(hhp_is_active_physics_modifier(mod) for mod in obj.modifiers)
        ]
        if not visible_physics_objects:
            self.report({'WARNING'}, "No visible HHP physics meshes found")
            return {'CANCELLED'}

        view_layer = context.view_layer
        original_selection = list(context.selected_objects)
        original_active = view_layer.objects.active
        original_mode = original_active.mode if original_active else 'OBJECT'

        try:
            if context.mode != 'OBJECT':
                try:
                    bpy.ops.object.mode_set(mode='OBJECT')
                except Exception:
                    pass

            try:
                bpy.ops.object.select_all(action='DESELECT')
            except Exception:
                for obj in view_layer.objects:
                    obj.select_set(False)
            for obj in visible_physics_objects:
                obj.select_set(True)
            view_layer.objects.active = visible_physics_objects[0]

            if not self.skip_sync_check:
                sync_choices_needed = self.check_sync_choices_needed(context)
                if sync_choices_needed:
                    context.scene['sync_choices_data'] = sync_choices_needed
                    context.scene['sync_rebind_all_visible'] = True
                    context.window_manager.popup_menu(self.draw_sync_menu, title="Choose sync source")
                    return {'FINISHED'}

            return self.execute_rebind(context)
        finally:
            try:
                bpy.ops.object.select_all(action='DESELECT')
            except Exception:
                for obj in view_layer.objects:
                    obj.select_set(False)
            for obj in original_selection:
                if obj.name in view_layer.objects:
                    obj.select_set(True)
            if original_active and original_active.name in view_layer.objects:
                view_layer.objects.active = original_active
                try:
                    if original_mode != 'OBJECT':
                        bpy.ops.object.mode_set(mode=original_mode)
                except Exception:
                    pass

    def execute_rebind(self, context):
        initial_selection = list(context.selected_objects)
        union_selection = initial_selection.copy()
        for obj in hhp_collect_linked_rebind_meshes(context, initial_selection):
            if obj not in union_selection:
                union_selection.append(obj)
        with hhp_rebind_mesh_visibility(context, union_selection):
            return self.execute_linked_rebind(context, initial_selection, union_selection)

    def execute_linked_rebind(self, context, initial_selection, union_selection):
        if not any(hhp_is_active_physics_modifier(mod)
                   for obj in union_selection for mod in obj.modifiers):
            self.report({'WARNING'}, "No enabled HHP physics elements to refresh or rebind")
            return {'CANCELLED'}
        # Store the current simplify settings
        original_use_simplify = context.scene.render.use_simplify
        original_simplify_subdivision = context.scene.render.simplify_subdivision

        # Store selection/mode before rebind and force Object Mode for binding operators.
        view_layer = context.view_layer
        initial_active = view_layer.objects.active
        initial_mode = initial_active.mode if initial_active else 'OBJECT'

        try:
            if context.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass
        
        # Check if we need to change simplify settings
        need_to_restore_simplify = False
        if not (original_use_simplify and original_simplify_subdivision == 0):
            # Set simplify to on with level 0 for viewport
            context.scene.render.use_simplify = True
            context.scene.render.simplify_subdivision = 0
            need_to_restore_simplify = True
        
        # Stop the animation playback
        bpy.ops.screen.animation_cancel(restore_frame=False)

        # Go to the scene start frame
        context.scene.frame_set(context.scene.frame_start)

        # Set playback method to 'Play Every Frame'
        context.scene.sync_mode = 'NONE'

        # Create an empty list to store new selections (Surface Deform and Mesh Deform targets)
        new_selection = []

        # Dictionaries to store original states
        target_object_states = {}
        collection_states = {}
        layer_collection_states = {}

        # Save the original selection
        original_selection = initial_selection.copy()

        # Sync surface deform strengths based on wire/non-wire display types
        sync_source_choices = context.scene.get('sync_source_choices', {})
        
        for selected_obj in original_selection:
            if selected_obj.type != 'MESH':
                continue
            
            # Find all linked meshes that share the same mesh data
            linked_meshes = [obj for obj in union_selection 
                           if obj.type == 'MESH' and obj.data == selected_obj.data and obj != selected_obj]
            
            if not linked_meshes:
                continue
                
            # Separate wire-type and non-wire-type meshes (same logic as check_sync_choices_needed)
            wire_type_meshes = [obj for obj in linked_meshes 
                               if obj.display_type == 'WIRE' or not self.has_hhp_modifiers(obj)]
            non_wire_type_meshes = [obj for obj in linked_meshes 
                                   if obj.display_type != 'WIRE' and self.has_hhp_modifiers(obj)]
            
            # Check if selected object is wire-type or non-wire-type
            selected_is_wire_type = (selected_obj.display_type == 'WIRE' or not self.has_hhp_modifiers(selected_obj))
            
            # Determine source and target meshes for syncing
            source_obj = None
            target_meshes = []
            
            if selected_is_wire_type:
                # Selected mesh is wire-type, sync from non-wire-type
                if len(non_wire_type_meshes) == 1:
                    source_obj = non_wire_type_meshes[0]
                    target_meshes = linked_meshes + [selected_obj]  # ALL linked meshes + selected mesh
                elif len(non_wire_type_meshes) > 1 and selected_obj.name in sync_source_choices:
                    source_name = sync_source_choices[selected_obj.name]
                    source_obj = bpy.data.objects.get(source_name)
                    target_meshes = linked_meshes + [selected_obj]  # ALL linked meshes + selected mesh
            else:
                # Selected mesh is non-wire-type, sync to ALL linked meshes (excluding source)
                if linked_meshes:
                    if len(non_wire_type_meshes) == 0:
                        # Only this non-wire-type mesh exists
                        source_obj = selected_obj
                        target_meshes = linked_meshes  # ALL linked meshes (selected mesh is source)
                    elif selected_obj.name in sync_source_choices:
                        # User chose source from multiple non-wire-type options
                        source_name = sync_source_choices[selected_obj.name]
                        source_obj = bpy.data.objects.get(source_name)
                        # Include all linked meshes + selected mesh, but exclude the source
                        all_meshes = linked_meshes + [selected_obj]
                        target_meshes = [obj for obj in all_meshes if obj != source_obj]
                    else:
                        # Default to selected mesh as source
                        source_obj = selected_obj
                        target_meshes = linked_meshes  # ALL linked meshes (selected mesh is source)
            
            # Perform the syncing
            if source_obj and target_meshes:
                # Get HHP surface deform modifiers from the source mesh
                source_surface_mods = []
                for mod in source_obj.modifiers:
                    if mod.type == 'SURFACE_DEFORM' and hhp_is_active_physics_modifier(mod):
                        source_surface_mods.append(mod)
                
                # Sync strengths to target meshes
                for target_obj in target_meshes:
                    for source_mod in source_surface_mods:
                        # Find corresponding modifier by name in target mesh
                        target_mod = target_obj.modifiers.get(source_mod.name)
                        if (target_mod and target_mod.type == 'SURFACE_DEFORM'
                                and hhp_is_active_physics_modifier(target_mod)):
                            target_mod.strength = source_mod.strength

        # Helper function to recursively get all child collections of a given collection
        def get_all_child_collections(coll):
            child_cols = []
            for child in coll.children:
                child_cols.append(child)
                child_cols.extend(get_all_child_collections(child))
            return child_cols

        # Find all LayerCollections that wrap a given Collection (recurses view layer tree)
        def find_layer_collections_for_collection(layer_collection, collection):
            matches = []
            if layer_collection.collection == collection:
                matches.append(layer_collection)
            for child in layer_collection.children:
                matches.extend(find_layer_collections_for_collection(child, collection))
            return matches

        # Enable a collection and its entire sub-tree in the active view layer (exclude=False)
        def enable_layer_collection_tree(collection):
            layer_collections = find_layer_collections_for_collection(
                context.view_layer.layer_collection, collection
            )

            def enable_recursive(layer_coll):
                lc_id = layer_coll.as_pointer()
                if lc_id not in layer_collection_states:
                    layer_collection_states[lc_id] = (
                        layer_coll,
                        layer_coll.exclude,
                        layer_coll.hide_viewport,
                    )
                layer_coll.exclude = False
                layer_coll.hide_viewport = False
                for child_lc in layer_coll.children:
                    enable_recursive(child_lc)

            for lc in layer_collections:
                enable_recursive(lc)

        # For every originally selected mesh, store and enable the viewport state for its parent collections
        # and all nested subcollections.
        for obj in original_selection:
            if obj.type == 'MESH':
                for col in obj.users_collection:
                    if col.name not in collection_states:
                        collection_states[col.name] = col.hide_viewport
                        col.hide_viewport = False  # Enable (make visible)
                        enable_layer_collection_tree(col)
                    for child in get_all_child_collections(col):
                        if child.name not in collection_states:
                            collection_states[child.name] = child.hide_viewport
                            child.hide_viewport = False  # Enable (make visible)
                            enable_layer_collection_tree(child)

        # Function to recursively collect parent collections
        def get_all_parent_collections(collection):
            parent_collections = []
            for parent in bpy.data.collections:
                if collection.name in parent.children.keys():
                    parent_collections.append(parent)
                    parent_collections.extend(get_all_parent_collections(parent))
            return parent_collections

        # Prepare only enabled elements, including enabled linked counterparts.
        for obj in union_selection:
            # Check if the object has any modifiers
            if obj.modifiers:
                for mod in obj.modifiers:
                    # Refresh targets only for enabled physics elements.
                    if hhp_is_active_physics_modifier(mod):

                        # If the modifier is a Surface Deform or Mesh Deform modifier, select its target/object
                        target_obj = None
                        if mod.type == 'SURFACE_DEFORM' and mod.target:
                            target_obj = mod.target
                        elif mod.type == 'MESH_DEFORM' and mod.object:
                            target_obj = mod.object

                        if target_obj:
                            # Include the target's complete collection path before
                            # trying to select it. An object in an excluded branch
                            # is not part of the ViewLayer and select_set() fails.
                            for collection in target_obj.users_collection:
                                all_collections = (
                                    [collection]
                                    + get_all_parent_collections(collection)
                                )
                                for col in all_collections:
                                    if col.name not in collection_states:
                                        collection_states[col.name] = (
                                            col.hide_viewport
                                        )
                                        col.hide_viewport = False
                                    enable_layer_collection_tree(col)
                            context.view_layer.update()

                            # hide_get() is only valid once the object belongs to
                            # the active view layer.
                            if target_obj.name not in target_object_states:
                                target_object_states[target_obj.name] = (
                                    target_obj.hide_viewport,
                                    target_obj.hide_render,
                                    target_obj.hide_get(),
                                )

                            # Make the target object visible
                            target_obj.hide_viewport = False
                            target_obj.hide_render = False
                            target_obj.hide_set(False)
                            target_obj.select_set(True)
                            if target_obj not in new_selection:
                                new_selection.append(target_obj)

        # Deselect the initial objects
        for obj in initial_selection:
            obj.select_set(False)

        # Update cache simulation frames to match timeline
        # This ensures that when physics targets are rebound, they use the correct frame range from the scene
        # Function to update cache settings of physics modifiers
        def update_cache_settings(obj, start_frame, end_frame):
            for mod in obj.modifiers:
                if not (mod.show_viewport and mod.show_render):
                    continue
                if mod.type in {
                    'CLOTH', 'SOFT_BODY', 'FLUID', 'DYNAMIC_PAINT', 'SMOKE', 'PARTICLE_SYSTEM', 'COLLISION'
                }:
                    if hasattr(mod, 'point_cache'):
                        mod.point_cache.frame_start = start_frame
                        mod.point_cache.frame_end = end_frame
                    if hasattr(mod, 'cache'):
                        mod.cache.frame_start = start_frame
                        mod.cache.frame_end = end_frame

        # If we have new target objects to update (the physics proxies)
        if new_selection:
            # Get the start and end frames from the timeline
            start_frame = context.scene.frame_start
            end_frame = context.scene.frame_end
            
            # Set the first object in the new selection as the active object
            context.view_layer.objects.active = new_selection[0]

            # Update cache settings for all physics target objects (in new_selection)
            for obj in new_selection:
                if obj.type == 'MESH':
                    update_cache_settings(obj, start_frame, end_frame)

            # Enter and immediately exit edit mode to refresh the target mesh.
            # If a target was also part of the original selection, it was
            # deselected above, so make sure Blender has a selected active mesh.
            edit_target = next(
                (obj for obj in new_selection if obj.type == 'MESH' and obj.name in view_layer.objects),
                None
            )
            if edit_target:
                try:
                    edit_target.select_set(True)
                    view_layer.objects.active = edit_target
                    if context.active_object == edit_target:
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.object.mode_set(mode='OBJECT')
                except RuntimeError:
                    pass

        # Deselect all objects to start fresh
        bpy.ops.object.select_all(action='DESELECT')

        # Instead of restoring just the initial selection, restore the union selection,
        # which now includes all meshes sharing the same mesh data.
        for obj in union_selection:
            if obj.name in view_layer.objects:
                obj.select_set(True)

        # Set the active object from the union selection if available.
        if union_selection:
            context.view_layer.objects.active = union_selection[0]

        def unbind_modifiers(obj):
            for modifier in obj.modifiers:
                if not hhp_is_active_rebind_modifier(modifier):
                    continue
                if modifier.type == 'MESH_DEFORM' and modifier.is_bound:
                    context.view_layer.objects.active = obj
                    bpy.ops.object.meshdeform_bind(modifier=modifier.name)
                elif modifier.type == 'SURFACE_DEFORM' and modifier.is_bound:
                    context.view_layer.objects.active = obj
                    bpy.ops.object.surfacedeform_bind(modifier=modifier.name)
                elif modifier.type == 'CORRECTIVE_SMOOTH' and modifier.is_bind:
                    context.view_layer.objects.active = obj
                    bpy.ops.object.correctivesmooth_bind(modifier=modifier.name)

        def unbind_modifiers_from_selected():
            for obj in union_selection:
                unbind_modifiers(obj)

        def bind_modifiers(obj):
            if not any(hhp_is_active_rebind_modifier(mod) for mod in obj.modifiers):
                return
            # Store the original active object
            original_active_object = context.view_layer.objects.active
            
            # Make the object active
            context.view_layer.objects.active = obj
            
            # Iterate over the modifiers in the same order as the modifier stack
            for modifier in obj.modifiers:
                if not hhp_is_active_rebind_modifier(modifier):
                    continue
                
                # Apply gravity factor from scene settings to cloth modifiers
                if modifier.type == 'CLOTH':
                    modifier.settings.effector_weights.gravity = context.scene.hhp_props.gravity_factor
                
                if modifier.type == 'MESH_DEFORM' and not modifier.is_bound:
                    bpy.ops.object.meshdeform_bind(modifier=modifier.name)
                elif modifier.type == 'SURFACE_DEFORM' and not modifier.is_bound:
                    bpy.ops.object.surfacedeform_bind(modifier=modifier.name)
                elif modifier.type == 'CORRECTIVE_SMOOTH' and not modifier.is_bind:
                    bpy.ops.object.correctivesmooth_bind(modifier=modifier.name)
            
            # Restore the original active object
            context.view_layer.objects.active = original_active_object

        def bind_modifiers_from_selected():
            for obj in union_selection:
                bind_modifiers(obj)

        try:
            # Unbind the modifiers from all selected objects
            unbind_modifiers_from_selected()

            # Bind the modifiers to all selected objects
            bind_modifiers_from_selected()
        finally:
            # Restore all target-object visibility states
            for obj_name, (
                hide_viewport,
                hide_render,
                hidden,
            ) in target_object_states.items():
                obj = bpy.data.objects.get(obj_name)
                if obj:
                    obj.hide_viewport = hide_viewport
                    obj.hide_render = hide_render
                    obj.hide_set(hidden)

            # Restore the hide_viewport states of collections
            for col_name, hide_viewport in collection_states.items():
                col = bpy.data.collections.get(col_name)
                if col:
                    col.hide_viewport = hide_viewport

            # Restore the exclude and hide states of layer collections
            for _, (
                layer_coll,
                exclude_state,
                hide_viewport_state,
            ) in layer_collection_states.items():
                layer_coll.exclude = exclude_state
                layer_coll.hide_viewport = hide_viewport_state

            # Restore the original selection and active object
            try:
                bpy.ops.object.select_all(action='DESELECT')
            except Exception:
                for obj in context.view_layer.objects:
                    obj.select_set(False)
            for obj in original_selection:
                obj.select_set(True)
            if initial_active:
                context.view_layer.objects.active = initial_active
                try:
                    if initial_mode != 'OBJECT':
                        bpy.ops.object.mode_set(mode=initial_mode)
                except Exception:
                    pass

            # Restore the original simplify settings if we changed them
            if need_to_restore_simplify:
                context.scene.render.use_simplify = original_use_simplify
                context.scene.render.simplify_subdivision = original_simplify_subdivision

        return {'FINISHED'}

class OBJECT_OT_SelectSyncSource(bpy.types.Operator):
    bl_idname = "object.select_sync_source"
    bl_label = "Select Sync Source"
    bl_description = "Select source mesh for syncing surface deform strengths"

    mesh_name: bpy.props.StringProperty()
    source_name: bpy.props.StringProperty()

    def execute(self, context):
        # Store the choice and check if all choices are made
        if 'sync_source_choices' not in context.scene:
            context.scene['sync_source_choices'] = {}
        
        # Convert string properties to dict-like access
        choices = dict(context.scene.get('sync_source_choices', {}))
        choices[self.mesh_name] = self.source_name
        context.scene['sync_source_choices'] = choices
        
        # Check if all required choices have been made
        if 'sync_choices_data' in context.scene:
            choices_data = context.scene['sync_choices_data']
            all_chosen = all(mesh_name in choices for mesh_name in choices_data.keys())
            
            if all_chosen:
                # All choices made, proceed with rebind
                rebind_all_visible = bool(context.scene.get('sync_rebind_all_visible', False))
                bpy.ops.object.bind_unbind_hhp_modifiers(
                    'EXEC_DEFAULT',
                    skip_sync_check=True,
                    rebind_all_visible=rebind_all_visible
                )
                
                # Clean up stored data
                if 'sync_choices_data' in context.scene:
                    del context.scene['sync_choices_data']
                if 'sync_source_choices' in context.scene:
                    del context.scene['sync_source_choices']
                if 'sync_rebind_all_visible' in context.scene:
                    del context.scene['sync_rebind_all_visible']
        
        return {'FINISHED'}

class OBJECT_OT_PtcacheBakeAll(bpy.types.Operator):
    bl_idname = "object.ptcache_bake_all"
    bl_label = "Progressive bake (Slower)"
    bl_description = "Real-time viewable bake for HHP proxy physics. You can watch the simulation as it bakes and press ESC to cancel"
    use_all_visible: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def execute(self, context):
        self._mixin = HHP_PTCacheProxyMixin()
        self._source_objects = hhp_collect_visible_physics_objects(context) if self.use_all_visible else None
        self._proxies = self._mixin.collect_proxy_targets(context, self._source_objects)
        if not self._proxies:
            self.report({'WARNING'}, "No HHP/HHPs proxy targets found")
            return {'CANCELLED'}

        self._bake_start_time = time.perf_counter()
        self._simplify_state = hhp_enable_simplify_zero_viewport(context)
        self._viewport_shading_state = hhp_switch_viewports_to_solid(context)
        self._visibility_state = self._mixin.make_proxy_targets_visible(self._proxies)
        self._start_frame, self._end_frame = self._mixin.get_proxy_cache_frame_range(context, self._proxies)
        self._current_frame = self._start_frame
        self._timer = context.window_manager.event_timer_add(0.01, window=context.window)
        self._draw_handler = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_viewport_cancel_message,
            (),
            'WINDOW',
            'POST_PIXEL'
        )
        self.update_bake_status_text(context)

        try:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        except Exception:
            pass

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'ESC':
            return self.cancel_modal(context)

        if event.type != 'TIMER':
            return {'RUNNING_MODAL'}

        if self._current_frame <= self._end_frame:
            context.scene.frame_set(self._current_frame)
            self._current_frame += 1
            self.update_bake_status_text(context)
            self.tag_view3d_redraw(context)
            return {'RUNNING_MODAL'}

        return self.finish_modal(context)

    def get_bake_progress_percent(self):
        total_frames = max(1, self._end_frame - self._start_frame + 1)
        completed_frames = min(max(self._current_frame - self._start_frame, 0), total_frames)
        return int((completed_frames / total_frames) * 100)

    def get_bake_status_text(self):
        return f"Baking {self.get_bake_progress_percent()}% - Press ESC to cancel bake"

    def update_bake_status_text(self, context):
        context.workspace.status_text_set(self.get_bake_status_text())

    def draw_viewport_cancel_message(self):
        font_id = 0
        blf.size(font_id, 18)
        blf.color(font_id, 1.0, 0.85, 0.1, 1.0)
        blf.position(font_id, 32, 72, 0)
        blf.draw(font_id, self.get_bake_status_text())

    def tag_view3d_redraw(self, context):
        screen = getattr(context, "screen", None)
        if not screen:
            return
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

    def save_current_cache(self, context):
        proxies, failures = self._mixin._run_on_proxies(
            context,
            lambda: bpy.ops.ptcache.bake_from_cache(),
            self._source_objects
        )
        return proxies, failures

    def finish_modal(self, context):
        proxies, failures = self.save_current_cache(context)
        self.cleanup_modal(context)
        elapsed_time = hhp_format_elapsed_time(self._bake_start_time)

        if failures:
            detail = "; ".join(f"{name}: {reason}" for name, reason in failures)
            self.report({'WARNING'}, f"Finished bake in {elapsed_time}; simulated frames {self._start_frame}-{self._end_frame}; baked {len(proxies) - len(failures)} proxies, {len(failures)} failed ({detail})")
        else:
            self.report({'INFO'}, f"Finished bake in {elapsed_time}; simulated frames {self._start_frame}-{self._end_frame} and baked {len(proxies)} proxy objects")
        return {'FINISHED'}

    def cancel_modal(self, context):
        cancel_frame = max(self._start_frame, self._current_frame - 1)
        proxies, failures = self.save_current_cache(context)
        self.cleanup_modal(context)
        elapsed_time = hhp_format_elapsed_time(self._bake_start_time)
        if failures:
            detail = "; ".join(f"{name}: {reason}" for name, reason in failures)
            self.report({'WARNING'}, f"Cancelled after {elapsed_time} at frame {cancel_frame}; saved partial cache for {len(proxies) - len(failures)} proxies, {len(failures)} failed ({detail})")
        else:
            self.report({'WARNING'}, f"Cancelled after {elapsed_time} at frame {cancel_frame}; saved partial cache for {len(proxies)} proxy objects")
        return {'CANCELLED'}

    def cleanup_modal(self, context):
        if getattr(self, "_timer", None):
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        if getattr(self, "_draw_handler", None):
            bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
            self._draw_handler = None
        context.workspace.status_text_set(None)
        if getattr(self, "_visibility_state", None):
            self._mixin.restore_proxy_target_visibility(self._visibility_state)
            self._visibility_state = None
        if getattr(self, "_viewport_shading_state", None):
            hhp_restore_viewport_shading(self._viewport_shading_state)
            self._viewport_shading_state = None
        if getattr(self, "_simplify_state", None):
            hhp_restore_simplify_state(self._simplify_state)
            self._simplify_state = None
        self.tag_view3d_redraw(context)

    def invoke(self, context, event):
        return self.execute(context)


class OBJECT_OT_PtcacheBakeOffline(bpy.types.Operator):
    bl_idname = "object.ptcache_bake_offline"
    bl_label = "Offline bake (Faster)"
    bl_description = "Temporarily freezes Blender while the HHP proxy bake runs for faster bakes"
    use_all_visible: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def execute(self, context):
        mixin = HHP_PTCacheProxyMixin()
        source_objects = hhp_collect_visible_physics_objects(context) if self.use_all_visible else None
        proxies = mixin.collect_proxy_targets(context, source_objects)
        if not proxies:
            self.report({'WARNING'}, "No HHP/HHPs proxy targets found")
            return {'CANCELLED'}

        bake_start_time = time.perf_counter()
        viewport_shading_state = hhp_switch_viewports_to_solid(context)
        visibility_state = mixin.make_proxy_targets_visible(proxies)
        try:
            start_frame, end_frame = mixin.simulate_proxy_cache_range(context, proxies)
            proxies, failures = mixin._run_on_proxies(context, lambda: bpy.ops.ptcache.bake_from_cache(), source_objects)
        finally:
            mixin.restore_proxy_target_visibility(visibility_state)
            hhp_restore_viewport_shading(viewport_shading_state)

        elapsed_time = hhp_format_elapsed_time(bake_start_time)
        if failures:
            detail = "; ".join(f"{name}: {reason}" for name, reason in failures)
            self.report({'WARNING'}, f"Finished bake in {elapsed_time}; simulated frames {start_frame}-{end_frame}; baked {len(proxies) - len(failures)} proxies, {len(failures)} failed ({detail})")
        else:
            self.report({'INFO'}, f"Finished bake in {elapsed_time}; simulated frames {start_frame}-{end_frame} and baked {len(proxies)} proxy objects")
        return {'FINISHED'}


class OBJECT_OT_PtcacheBakeMenu(bpy.types.Operator):
    bl_idname = "object.ptcache_bake_menu"
    bl_label = "Bake"
    bl_description = "Choose how to bake HHP proxy physics"
    use_all_visible: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.popup_menu(self.draw_menu, title="Bake Options")
        return {'FINISHED'}

    def draw_menu(self, menu, context):
        layout = menu.layout
        progressive_op = layout.operator("object.ptcache_bake_all", text="Progressive bake (Slower)", icon='PLAY')
        progressive_op.use_all_visible = self.use_all_visible

        offline_op = layout.operator("object.ptcache_bake_offline", text="Offline bake (Faster)", icon='RENDER_STILL')
        offline_op.use_all_visible = self.use_all_visible

class OBJECT_OT_PtcacheFreeBakeAll(bpy.types.Operator):
    bl_idname = "object.ptcache_free_bake_all"
    bl_label = "Free All Bakes"
    bl_description = "Free all baked physics simulations in the scene, including fluids and dynamics"

    def execute(self, context):
        bpy.ops.ptcache.free_bake_all()
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        layout.label(text="WARNING: This will free ALL baked physics in the scene.", icon='ERROR')
        layout.label(text="This includes fluids and dynamics, not just HHP physics.")
        layout.label(text="You will need to rebake anything this clears.")

class HHP_PTCacheProxyMixin:
    """Utility mixin to gather proxy targets and run ptcache ops without leaving UI in an inconsistent state."""

    @staticmethod
    def get_proxy_point_cache(proxy):
        for mod in proxy.modifiers:
            if getattr(mod, "point_cache", None):
                return mod.point_cache
        return None

    def collect_proxy_targets(self, context, source_objects=None):
        proxies = []
        seen = set()
        physics_objects = source_objects if source_objects is not None else context.selected_objects
        for obj in physics_objects:
            if obj.type != 'MESH':
                continue
            for mod in obj.modifiers:
                if not (mod.show_viewport and mod.show_render):
                    continue
                if mod.type in {'SURFACE_DEFORM', 'MESH_DEFORM'} and (mod.name.startswith('(HHP)') or mod.name.startswith('(HHPs)')):
                    target = mod.target if mod.type == 'SURFACE_DEFORM' else mod.object
                    if target and target.type == 'MESH' and target.name not in seen:
                        seen.add(target.name)
                        proxies.append(target)
        return proxies

    def count_baked_proxy_targets(self, context, source_objects=None):
        baked_count = 0
        for proxy in self.collect_proxy_targets(context, source_objects):
            cache = self.get_proxy_point_cache(proxy)
            if cache and getattr(cache, "is_baked", False):
                baked_count += 1
        return baked_count

    def collect_baked_proxy_cache_items(self, context, source_objects=None):
        items = []
        seen = set()
        physics_objects = source_objects if source_objects is not None else context.selected_objects
        for obj in physics_objects:
            if obj.type != 'MESH':
                continue
            for mod in obj.modifiers:
                if not (mod.show_viewport and mod.show_render):
                    continue
                if not hhp_is_deform_modifier(mod):
                    continue

                proxy = mod.target if mod.type == 'SURFACE_DEFORM' else mod.object
                if not proxy or proxy.type != 'MESH' or proxy.name in seen:
                    continue

                cache = self.get_proxy_point_cache(proxy)
                if not cache or not getattr(cache, "is_baked", False):
                    continue

                seen.add(proxy.name)
                display_name = mod.name.split("- ", 1)[1] if "- " in mod.name else mod.name
                items.append((obj, mod, proxy, cache, display_name))
        return items

    def count_unbaked_proxy_targets(self, context, source_objects=None):
        unbaked_count = 0
        for proxy in self.collect_proxy_targets(context, source_objects):
            cache = self.get_proxy_point_cache(proxy)
            if cache and not getattr(cache, "is_baked", False):
                unbaked_count += 1
        return unbaked_count

    def get_view3d_override(self, context):
        window = getattr(context, "window", None)
        screen = getattr(window, "screen", None) if window else None
        if not screen:
            return None
        area = next((a for a in screen.areas if a.type == 'VIEW_3D'), None)
        if not area:
            return None
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        space_data = area.spaces.active if area.spaces else None
        if not (region and space_data):
            return None
        return {
            "window": window,
            "screen": screen,
            "area": area,
            "region": region,
            "space_data": space_data,
        }

    def get_proxy_cache_frame_range(self, context, proxies):
        start_frames = []
        end_frames = []
        for proxy in proxies:
            cache = self.get_proxy_point_cache(proxy)
            if not cache:
                continue
            start_frames.append(getattr(cache, "frame_start", context.scene.frame_start))
            end_frames.append(getattr(cache, "frame_end", context.scene.frame_end))

        if not start_frames or not end_frames:
            return context.scene.frame_start, context.scene.frame_end
        return int(min(start_frames)), int(max(end_frames))

    def get_parent_collections(self, collection):
        parent_collections = []
        for parent in bpy.data.collections:
            if collection.name in parent.children.keys():
                parent_collections.append(parent)
                parent_collections.extend(self.get_parent_collections(parent))
        return parent_collections

    def make_proxy_targets_visible(self, proxies):
        proxy_states = {}
        collection_states = {}

        for proxy in proxies:
            if proxy.name not in proxy_states:
                proxy_states[proxy.name] = (
                    proxy.hide_viewport,
                    proxy.hide_render,
                    proxy.hide_get() if hasattr(proxy, "hide_get") else proxy.hide_viewport
                )

            for col in getattr(proxy, "users_collection", []):
                for visible_col in [col] + self.get_parent_collections(col):
                    if visible_col.name not in collection_states:
                        collection_states[visible_col.name] = visible_col.hide_viewport
                    visible_col.hide_viewport = False

            try:
                if hasattr(proxy, "hide_set"):
                    proxy.hide_set(False)
            except Exception:
                pass
            proxy.hide_viewport = False
            proxy.hide_render = False

        return proxy_states, collection_states

    def restore_proxy_target_visibility(self, visibility_state):
        proxy_states, collection_states = visibility_state

        for proxy_name, (hide_viewport, hide_render, was_hidden) in proxy_states.items():
            proxy = bpy.data.objects.get(proxy_name)
            if not proxy:
                continue
            proxy.hide_viewport = hide_viewport
            proxy.hide_render = hide_render
            try:
                if hasattr(proxy, "hide_set"):
                    proxy.hide_set(was_hidden)
            except Exception:
                pass

        for col_name, hide_viewport in collection_states.items():
            col = bpy.data.collections.get(col_name)
            if col:
                col.hide_viewport = hide_viewport

    def simulate_proxy_cache_range(self, context, proxies):
        start_frame, end_frame = self.get_proxy_cache_frame_range(context, proxies)
        try:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        except Exception:
            pass

        for frame in range(start_frame, end_frame + 1):
            context.scene.frame_set(frame)
        return start_frame, end_frame

    def _run_on_proxies(self, context, op_callable, source_objects=None):
        proxies = self.collect_proxy_targets(context, source_objects)
        if not proxies:
            return proxies, []

        view_layer = context.view_layer
        original_active = view_layer.objects.active
        original_mode = context.mode
        original_selection = list(context.selected_objects)
        failures = []

        def safe_object_mode():
            try:
                if context.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

        def safe_deselect_all():
            safe_object_mode()
            try:
                bpy.ops.object.select_all(action='DESELECT')
            except Exception:
                for obj in view_layer.objects:
                    obj.select_set(False)

        safe_object_mode()

        try:
            for proxy in proxies:
                hide_viewport = proxy.hide_viewport
                hide_render = proxy.hide_render
                was_hidden = proxy.hide_get() if hasattr(proxy, "hide_get") else proxy.hide_viewport

                # Find a usable point cache on the proxy (cloth/soft body etc.)
                active_cache = self.get_proxy_point_cache(proxy)
                if not active_cache:
                    failures.append((proxy.name, "No point cache found on proxy"))
                    continue

                collections_state = [(col, col.hide_viewport) for col in getattr(proxy, "users_collection", [])]

                try:
                    for col, _ in collections_state:
                        col.hide_viewport = False
                    if hasattr(proxy, "hide_set"):
                        proxy.hide_set(False)
                except Exception:
                    pass
                proxy.hide_viewport = False
                proxy.hide_render = False

                override_base = {
                    "view_layer": view_layer,
                    "active_object": proxy,
                    "selected_objects": [proxy],
                    "object": proxy,
                }
                view3d_override = self.get_view3d_override(context)
                if view3d_override:
                    override_base.update(view3d_override)
                override_base["point_cache"] = active_cache

                with context.temp_override(**override_base):
                    if proxy.mode != 'OBJECT':
                        try:
                            res = bpy.ops.object.mode_set(mode='OBJECT')
                            if 'FINISHED' not in res:
                                failures.append((proxy.name, "Failed to enter OBJECT mode"))
                                continue
                        except Exception as exc:
                            failures.append((proxy.name, f"Failed to enter OBJECT mode: {exc}"))
                            continue

                    try:
                        res = op_callable()
                        if isinstance(res, set) and 'FINISHED' not in res:
                            failures.append((proxy.name, "Operator cancelled"))
                    except Exception as exc:
                        failures.append((proxy.name, str(exc)))

                proxy.hide_viewport = hide_viewport
                proxy.hide_render = hide_render
                try:
                    if hasattr(proxy, "hide_set"):
                        proxy.hide_set(was_hidden)
                except Exception:
                    pass
                for col, hidden in collections_state:
                    col.hide_viewport = hidden
        finally:
            safe_deselect_all()
            for obj in original_selection:
                obj.select_set(True)
            if original_active:
                view_layer.objects.active = original_active
                try:
                    if original_mode != context.mode:
                        bpy.ops.object.mode_set(mode=original_mode)
                except Exception:
                    pass

        return proxies, failures

    def _run_on_proxy_cache(self, context, proxy_name, op_callable):
        proxy = bpy.data.objects.get(proxy_name)
        if not proxy or proxy.type != 'MESH':
            return False, "Proxy target not found"

        active_cache = self.get_proxy_point_cache(proxy)
        if not active_cache:
            return False, "No point cache found on proxy"
        if not getattr(active_cache, "is_baked", False):
            return False, "Proxy cache is not baked"

        view_layer = context.view_layer
        original_active = view_layer.objects.active
        original_mode = context.mode
        original_selection = list(context.selected_objects)
        visibility_state = self.make_proxy_targets_visible([proxy])

        def safe_object_mode():
            try:
                if context.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

        try:
            safe_object_mode()
            try:
                bpy.ops.object.select_all(action='DESELECT')
            except Exception:
                for selected_obj in view_layer.objects:
                    selected_obj.select_set(False)

            proxy.select_set(True)
            view_layer.objects.active = proxy

            override = {
                "view_layer": view_layer,
                "active_object": proxy,
                "selected_objects": [proxy],
                "object": proxy,
                "point_cache": active_cache,
            }
            view3d_override = self.get_view3d_override(context)
            if view3d_override:
                override.update(view3d_override)

            with context.temp_override(**override):
                result = op_callable()
                if isinstance(result, set) and 'FINISHED' not in result:
                    return False, "Operator cancelled"
        except Exception as exc:
            return False, str(exc)
        finally:
            try:
                bpy.ops.object.select_all(action='DESELECT')
            except Exception:
                for selected_obj in view_layer.objects:
                    selected_obj.select_set(False)
            for selected_obj in original_selection:
                selected_obj.select_set(True)
            if original_active:
                view_layer.objects.active = original_active
            try:
                if original_mode != context.mode:
                    bpy.ops.object.mode_set(mode=original_mode)
            except Exception:
                pass
            self.restore_proxy_target_visibility(visibility_state)

        return True, None

class OBJECT_OT_PtcacheBakeCurrent(HHP_PTCacheProxyMixin, bpy.types.Operator):
    bl_idname = "object.hhp_ptcache_bake_current"
    bl_label = "Current Cache to Bake"
    bl_description = "Save the simulation cached up to the current frame as a bake for HHP/HHPs proxy physics in the current Show Physics For scope. Anything you saw simulating during animation playback will be kept as the baked result"
    bl_options = {'REGISTER', 'UNDO'}
    use_all_visible: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def execute(self, context):
        source_objects = hhp_collect_visible_physics_objects(context) if self.use_all_visible else None
        proxies, failures = self._run_on_proxies(context, lambda: bpy.ops.ptcache.bake_from_cache(), source_objects)
        if not proxies:
            self.report({'WARNING'}, "No HHP/HHPs proxy targets found")
            return {'CANCELLED'}

        if failures:
            detail = "; ".join(f"{name}: {reason}" for name, reason in failures)
            self.report({'WARNING'}, f"Baked {len(proxies) - len(failures)} proxies, {len(failures)} failed ({detail})")
        else:
            self.report({'INFO'}, f"Baked current cache for {len(proxies)} proxy objects")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

class OBJECT_OT_PtcacheFreeCurrent(HHP_PTCacheProxyMixin, bpy.types.Operator):
    bl_idname = "object.hhp_ptcache_free_current"
    bl_label = "Delete Bake"
    bl_description = "Delete baked cache for HHP/HHPs proxy physics in the current Show Physics For scope"
    bl_options = {'REGISTER', 'UNDO'}
    use_all_visible: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def execute(self, context):
        source_objects = hhp_collect_visible_physics_objects(context) if self.use_all_visible else None
        proxies, failures = self._run_on_proxies(context, lambda: bpy.ops.ptcache.free_bake(), source_objects)
        if not proxies:
            self.report({'WARNING'}, "No HHP/HHPs proxy targets found")
            return {'CANCELLED'}

        if failures:
            detail = "; ".join(f"{name}: {reason}" for name, reason in failures)
            self.report({'WARNING'}, f"Deleted bake on {len(proxies) - len(failures)} proxies, {len(failures)} failed ({detail})")
        else:
            self.report({'INFO'}, f"Deleted bakes for {len(proxies)} proxy objects")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


class OBJECT_OT_PtcacheFreeBakedMenu(HHP_PTCacheProxyMixin, bpy.types.Operator):
    bl_idname = "object.hhp_ptcache_free_baked_menu"
    bl_label = "Delete Individual Bake"
    bl_description = "Choose one baked HHP/HHPs physics element to delete"
    use_all_visible: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.popup_menu(self.draw_menu, title="Delete Individual Bake")
        return {'FINISHED'}

    def draw_menu(self, menu, context):
        layout = menu.layout
        source_objects = hhp_collect_visible_physics_objects(context) if self.use_all_visible else None
        baked_items = self.collect_baked_proxy_cache_items(context, source_objects)
        if not baked_items:
            layout.label(text="No baked HHP/HHPs physics elements found", icon='INFO')
            return

        for obj, _mod, proxy, _cache, display_name in baked_items:
            op = layout.operator(
                "object.hhp_ptcache_free_baked_item",
                text=display_name,
                icon=hhp_physics_element_icon(obj),
            )
            op.proxy_name = proxy.name
            op.display_name = display_name


class OBJECT_OT_PtcacheFreeBakedItem(HHP_PTCacheProxyMixin, bpy.types.Operator):
    bl_idname = "object.hhp_ptcache_free_baked_item"
    bl_label = "Delete Individual Bake"
    bl_description = "Delete only this baked HHP/HHPs physics element"
    bl_options = {'REGISTER', 'UNDO'}

    proxy_name: bpy.props.StringProperty(options={'HIDDEN'})
    display_name: bpy.props.StringProperty(options={'HIDDEN'})

    def execute(self, context):
        success, error = self._run_on_proxy_cache(
            context,
            self.proxy_name,
            lambda: bpy.ops.ptcache.free_bake(),
        )
        if not success:
            self.report({'WARNING'}, f"Could not delete bake for '{self.display_name}': {error}")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Deleted bake for '{self.display_name}'")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


class HHP_UL_LatticeShapekeysList(UIList):
    """UIList for lattice shapekeys"""
    
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # Split layout to give more space to name 
            split = layout.split(factor=0.6)
            
            # Left side - shape key name (editable with full name)
            row = split.row()
            row.prop(item, "name", text="", emboss=False, icon='SHAPEKEY_DATA')
            
            # Right side - value and mute (hidden for Basis shapekey)
            if index > 0:  # Only show controls for non-Basis shapekeys
                row = split.row(align=True)
                row.alignment = 'RIGHT'
                
                # Value slider
                slider_row = row.row(align=True)
                slider_row.enabled = True
                
                if item.mute:
                    slider_row.active = False
                else:
                    slider_row.active = True
                
                slider_row.ui_units_x = 4
                slider_row.prop(item, "value", text="", emboss=False, slider=True)
                
                # Mute checkbox
                row.prop(item, "mute", text="", emboss=False, toggle=True)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='SHAPEKEY_DATA')
    
    def filter_items(self, context, data, propname):
        """Show all lattice shapekeys with search functionality"""
        shape_keys = getattr(data, propname)
        flags = [0] * len(shape_keys)
        
        # Show all shapekeys
        for i, key in enumerate(shape_keys):
            flags[i] = self.bitflag_filter_item
        
        # Handle search within visible keys
        if self.filter_name:
            for i, key in enumerate(shape_keys):
                if flags[i]:
                    if self.filter_name.lower() not in key.name.lower():
                        flags[i] = 0
        
        return flags, []

class OBJECT_OT_PhysicsFramerateMultiplier(bpy.types.Operator):
    bl_idname = "object.physics_framerate_multiplier"
    bl_label = "Physics Framerate Multiplier"
    bl_description = "Adjust the physics framerate multiplier for physics simulations based on the selected action."
    bl_options = {'REGISTER', 'UNDO'}

    action: bpy.props.EnumProperty(
        items=[
            ('RESET', 'Reset to default', 'Reset physics multipliers to their original baseline values.', 'LOOP_BACK', 0),
            ('CONVERT', 'Match to scene framerate', 'Convert physics multipliers to align with the current scene framerate.', 'NONE', 1),
            ('MULTIPLY', 'Multiply defaults by number', 'Multiply the default physics multipliers by a custom factor, as specified via the slider.', 'NONE', 2)
        ],
        name="Action"
    )
    multiplier: bpy.props.FloatProperty(
        name="Multiplier",
        description="Multiplier value",
        default=1.0,
        min=0.0,
        soft_max=10.0
    )
    confirm_mode: bpy.props.EnumProperty(
        name="Confirmation Mode",
        description="Choose whether to use original defaults or set user adjusted values as default",
        items=[
            ('ORIGINAL', "Use original defaults", "Keep the original baseline values"),
            ('USER', "Set user adjusted values as default", "Use user adjusted multipliers as the new default")
        ],
        default='ORIGINAL'
    )

    def _iter_collection_objects_recursive(self, collection):
        """Yield every object inside a collection and its nested child collections."""
        for obj in collection.objects:
            yield obj
        for child in collection.children:
            yield from self._iter_collection_objects_recursive(child)

    def _iter_scene_collections_recursive(self, collection):
        """Yield every collection linked under the active scene."""
        yield collection
        for child in collection.children:
            yield from self._iter_scene_collections_recursive(child)

    def _iter_hhp_character_collections(self, context):
        """Yield scene collections that look like HHP character roots."""
        for collection in self._iter_scene_collections_recursive(context.scene.collection):
            if any(child.name.startswith("Proxies (HHP)") for child in collection.children):
                yield collection

    def _iter_scene_proxy_collection_targets(self, context):
        """Yield mesh objects inside every scene HHP proxy collection."""
        for character_collection in self._iter_hhp_character_collections(context):
            for proxies_collection in character_collection.children:
                if not proxies_collection.name.startswith("Proxies (HHP)"):
                    continue
                for obj in self._iter_collection_objects_recursive(proxies_collection):
                    if obj.type == 'MESH':
                        yield obj

    def _is_hhp_deform_modifier(self, mod):
        return (
            mod.type in {'SURFACE_DEFORM', 'MESH_DEFORM'}
            and (mod.name.startswith('(HHP)') or mod.name.startswith('(HHPs)'))
        )

    def _iter_scene_modifier_targets(self, context):
        """Yield proxy objects referenced by HHP deform modifiers on scene meshes."""
        for obj in context.scene.objects:
            if obj.type != 'MESH':
                continue
            for mod in obj.modifiers:
                if not self._is_hhp_deform_modifier(mod):
                    continue
                if mod.type == 'SURFACE_DEFORM':
                    if mod.target is not None:
                        yield mod.target
                elif mod.type == 'MESH_DEFORM':
                    if mod.object is not None:
                        yield mod.object

    def _iter_physics_targets(self, context):
        """Yield all proxy targets that should receive the framerate multiplier."""
        yield from self._iter_scene_modifier_targets(context)
        yield from self._iter_scene_proxy_collection_targets(context)

    def _get_current_physics_value(self, target):
        for phy_mod in target.modifiers:
            if phy_mod.type == 'CLOTH':
                return phy_mod.settings.time_scale
        return None

    def _apply_physics_value(self, context, target, value):
        for phy_mod in target.modifiers:
            if phy_mod.type == 'CLOTH':
                phy_mod.settings.time_scale = value
                # Apply gravity factor from scene settings
                phy_mod.settings.effector_weights.gravity = context.scene.hhp_props.gravity_factor

    def _target_processed_key(self, target):
        return target.as_pointer()

    def _has_manual_physics_adjustment(self, current_value, baseline, stored_changed):
        return (
            abs(current_value - baseline) > 1e-5
            and abs(current_value - stored_changed) > 1e-5
        )

    def check_manual_adjustment(self, context):
        # Check every affected scene proxy target.
        processed_targets = set()
        for target in self._iter_physics_targets(context):
            target_key = self._target_processed_key(target)
            if target_key in processed_targets:
                continue
            if "phs_baseline" in target:
                baseline = target["phs_baseline"]
                current_value = self._get_current_physics_value(target)
                stored_converted = target.get("phs_converted", baseline)
                if current_value is not None:
                    processed_targets.add(target_key)
                    # If current value differs from both baseline and stored converted value,
                    # assume it was manually adjusted.
                    if self._has_manual_physics_adjustment(current_value, baseline, stored_converted):
                        return True
        return False

    def execute(self, context):
        scene_fps = context.scene.render.fps
        # Determine conversion factor based on scene fps; baseline is assumed to be 60fps
        conv_factor = 60.0 / scene_fps if scene_fps != 0 else 1.0
        use_current_values_as_defaults = self.confirm_mode == 'USER' and self.check_manual_adjustment(context)

        processed_targets = set()

        for target in self._iter_physics_targets(context):
            target_key = self._target_processed_key(target)
            if target_key in processed_targets:
                continue

            # Get the current physics multiplier from the first available physics simulation modifier.
            current_value = self._get_current_physics_value(target)
            if current_value is None:
                continue
            processed_targets.add(target_key)

            # Store the baseline if not already stored.
            if "phs_baseline" not in target:
                target["phs_baseline"] = current_value
            baseline = target["phs_baseline"]

            # Check whether manual adjustment occurred:
            # If current value does not match either the stored baseline or the last changed value,
            # then the user has manually edited the multiplier.
            stored_changed = target.get("phs_converted", baseline)

            if use_current_values_as_defaults and abs(current_value - baseline) > 1e-5:
                # The dialog choice should promote the current adjusted values consistently,
                # including values that match a previously stored tool-applied multiplier.
                target["phs_baseline"] = current_value
                baseline = current_value
            elif self._has_manual_physics_adjustment(current_value, baseline, stored_changed):
                # A manual adjustment is detected.
                if self.confirm_mode == 'USER':
                    # Replace the old baseline with the user-adjusted value.
                    target["phs_baseline"] = current_value
                    baseline = current_value
                elif self.confirm_mode == 'ORIGINAL':
                    # Revert to the stored baseline.
                    current_value = baseline

            # Now compute the new multiplier ("changed set") based on the (possibly updated) baseline.
            if self.action == 'CONVERT':
                new_value = baseline * conv_factor
            elif self.action == 'MULTIPLY':
                new_value = baseline * self.multiplier
            elif self.action == 'RESET':
                new_value = baseline
            else:
                new_value = baseline

            # Store the new multiplier value (changed set) for reference/restoration.
            target["phs_converted"] = new_value

            # Now update the time_scale for all physics simulation modifiers.
            self._apply_physics_value(context, target, new_value)

        self.report({'INFO'}, f"Action '{self.action}' applied to {len(processed_targets)} physics target(s).")
        return {'FINISHED'}

    def invoke(self, context, event):
        if self.check_manual_adjustment(context):
            return context.window_manager.invoke_props_dialog(self, width=400)
        if self.action == 'MULTIPLY':
            return context.window_manager.invoke_props_dialog(self, width=400)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        if self.check_manual_adjustment(context):
            layout.label(text="Multipliers adjusted by user.", icon='ERROR')
            layout.label(text="Choose default settings:")
            layout.prop(self, "confirm_mode", expand=True)
        if self.action == 'MULTIPLY':
            layout.prop(self, "multiplier")

class OBJECT_PT_ProxiesVisibilityPanel(bpy.types.Panel):
    """Panel to reflect and toggle visibility of 'Proxies (HHP)' collections with clickable text and greyed out subcollections."""
    bl_label = "Physics / Proxies (HHP)"
    bl_idname = "OBJECT_PT_proxies_visibility_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'  # Ensure this matches the 'Char (HHP)' category
    bl_parent_id = "CHAR_HHP_PT_Panel"  # Set parent panel
    bl_order = 10  # Place it after the 'Char (HHP)' panel
    bl_options = {'HIDE_HEADER'}  # Hide the header
    
    @classmethod
    def poll(cls, context):
        # Only show this panel if PROXIES is selected in the mode selector
        return context.scene.hhp_panel_mode.selected_panel == 'PROXIES'

    def draw(self, context):
        layout = self.layout
        props = context.scene.hhp_props
        obj = context.active_object

        # Proxies list as in your provided script
        proxies_collections = self.find_proxies_collections(context)

        # Use a grid flow for the proxies list
        col = layout.column(align=True)

        linked_name_tag = "Collision - Linked (DO NOT EDIT MESH)"

        for collection, level, parent_hidden, is_top_level in proxies_collections:
            if is_top_level and collection.name.startswith("Collision"):
                col.separator(factor=0.5)
            section_col = col.column(align=True)
            row = section_col.row(align=True)

            if is_top_level and collection.name.startswith("Collision"):
                # Collect collision objects for this collection
                collision_objects = self.collect_collision_objects(collection)
                non_linked_objects = [o for o in collision_objects if linked_name_tag not in o.name]
                linked_objects = [o for o in collision_objects if linked_name_tag in o.name]
                collision_only_selection = self.is_collision_only_selection(context, collection)
                selected_collision_objects = self.selected_objects_in_collection(context, collection)

                # Show main checkbox
                if collision_only_selection:
                    row.alert = True
                    row.enabled = False
                row.prop(collection, "show_collection", text="Collide & interact with physics")

                def draw_collision_object_toggle(parent_layout, collision_obj):
                    clean_name = collision_obj.name.split(".")[0]
                    object_row = parent_layout.row(align=True)
                    if collision_only_selection and collision_obj in selected_collision_objects:
                        object_row.alert = True
                        object_row.enabled = False
                    elif collision_obj in linked_objects:
                        object_row.active = False
                    object_row.prop(
                        collision_obj,
                        "show_object_viewport",
                        text=clean_name,
                        toggle=True,
                        icon='OBJECT_DATA'
                    )

                # When enabled, list all objects in the Collision collection directly
                # under this checkbox in two aligned columns. Linked objects are pushed
                # to the bottom and drawn greyed out.
                if collection.show_collection and collision_objects:
                    # If the only objects are linked collision proxies, show the
                    # "Generate optimized collision" button above the list as an alert row.
                    if not non_linked_objects:
                        alert_row = section_col.row(align=True)
                        alert_row.alert = True
                        op = alert_row.operator(
                            "hhp.generate_optimized_collision",
                            text="Generate optimized collision",
                            icon='MOD_DECIM'
                        )
                        op.collection_name = collection.name

                    ordered_objects = non_linked_objects + linked_objects

                    for i in range(0, len(ordered_objects), 2):
                        # If this is the last remaining object and there is no pair,
                        # let it span the full row width (no second, empty column).
                        if i + 1 >= len(ordered_objects):
                            single_obj = ordered_objects[i]
                            single_row = section_col.row(align=True)
                            draw_collision_object_toggle(single_row, single_obj)
                        else:
                            obj_row = section_col.row(align=True)

                            # Left column
                            left_obj = ordered_objects[i]
                            left_col = obj_row.column(align=True)
                            draw_collision_object_toggle(left_col, left_obj)

                            # Right column
                            right_obj = ordered_objects[i + 1]
                            right_col = obj_row.column(align=True)
                            draw_collision_object_toggle(right_col, right_obj)
                col.separator(factor=0.5)
            else:
                clean_name = collection.name.split(".")[0]

                # Set the icon
                icon = 'NONE' if is_top_level else 'DOT'

                # Set the active state (greyed out appearance)
                row.active = True if is_top_level else not parent_hidden

                # Display the custom property as a toggle button with clickable text and icon
                row.prop(collection, "show_collection", text=clean_name, toggle=True, icon=icon)

        # Collect modifiers into a list
        def collect_hhp_physics_modifiers(physics_objects):
            modifiers = []
            for obj in physics_objects:
                if obj.type == 'MESH':
                    for mod in obj.modifiers:
                        if mod.type in {'MESH_DEFORM', 'SURFACE_DEFORM'}:
                            if mod.name.startswith("(HHP)") or mod.name.startswith("(HHPs)"):
                                # Extract the display name after "- "
                                mod_display_name = mod.name.split("- ", 1)[1] if "- " in mod.name else mod.name
                                modifiers.append((obj, mod, mod_display_name))
            return modifiers

        physics_scope = context.scene.hhp_props.physics_display_scope
        selected_physics_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if context.active_object and context.active_object.type == 'MESH' and context.active_object not in selected_physics_objects:
            selected_physics_objects.append(context.active_object)
        all_physics_objects = hhp_collect_visible_physics_objects(context) if physics_scope == 'ALL' else []
        available_modifiers_list = collect_hhp_physics_modifiers(all_physics_objects) if physics_scope == 'ALL' else []
        modifiers_list = (
            collect_hhp_physics_modifiers(selected_physics_objects)
            if physics_scope == 'SELECTED'
            else available_modifiers_list
        )

        # Check for selected meshes with 'BS_Inflate' custom property OR cloth/soft body modifiers
        eligible_objects = []
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                has_bs_inflate = "BS_Inflate" in obj
                has_physics = any(m.type in {'CLOTH', 'SOFT_BODY'} for m in obj.modifiers)
                if has_bs_inflate or has_physics:
                    eligible_objects.append(obj)

        if eligible_objects:
            box = layout.box()
            box.label(text="Displace selected proxies", icon='MODIFIER')
            for obj in eligible_objects:
                row = box.row(align=True)

                # Only show BS_Inflate slider if the object has that property
                if "BS_Inflate" in obj:
                    row.prop(obj, '["BS_Inflate"]', text=obj.name)

                # Add the Edit Cage buttons in the same row
                if props.is_edit_cage:
                    row.operator("hhp.finalize_cage_edit", text="Finalize Cage Edit", icon='CHECKMARK')
                else:
                    row.operator("hhp.edit_cage", text="Edit Cage (With Shapekey)", icon='SCULPTMODE_HLT')

        show_unlock = character_membership.needs_full_character(context)
        if available_modifiers_list or physics_scope == 'SELECTED' or show_unlock:
            # Now, create the modifier box and arrange the buttons
            modifier_box = layout.box()
            # Create a row for the Physics label and Show advanced button
            header_row = modifier_box.row(align=True)
            header_row.label(text="Physics", icon='MODIFIER')
            primary_toggle = header_row.operator(
                "object.toggle_hhp_physics_group_visibility",
                text="",
                icon='STRIP_COLOR_01'
            )
            primary_toggle.group = 'PRIMARY'
            secondary_toggle = header_row.operator(
                "object.toggle_hhp_physics_group_visibility",
                text="",
                icon='STRIP_COLOR_05'
            )
            secondary_toggle.group = 'SECONDARY'
            header_row.prop(context.scene.hhp_props, "physics_display_scope", text="")
            header_row.prop(context.scene.hhp_props, "show_strength", text="", icon='SETTINGS', emboss=True)

            if show_unlock:
                character_membership.draw_unlock_button(modifier_box)

            # Arrange buttons in 2 columns
            col = modifier_box.column(align=True)

            if not modifiers_list:
                col.label(text="No HHP physics found on the active or selected meshes", icon='INFO')
            
            # Create buttons row
            for i in range(0, len(modifiers_list), 2):
                row = col.row(align=True)
                # First column
                obj, mod, mod_display_name = modifiers_list[i]
                op = row.operator(
                    "object.toggle_modifier_visibility",
                    text=mod_display_name,
                    depress=mod.show_viewport and mod.show_render,
                    icon=hhp_physics_element_icon(obj)
                )
                op.object_name = obj.name
                op.modifier_name = mod.name
                
                # Second column if available
                if i + 1 < len(modifiers_list):
                    obj2, mod2, mod_display_name2 = modifiers_list[i + 1]
                    op = row.operator(
                        "object.toggle_modifier_visibility",
                        text=mod_display_name2,
                        depress=mod2.show_viewport and mod2.show_render,
                        icon=hhp_physics_element_icon(obj2)
                    )
                    op.object_name = obj2.name
                    op.modifier_name = mod2.name

                # If show_strength is enabled, add strength slider and cloth settings in a unified, aligned layout
                if context.scene.hhp_props.show_strength:
                    left_enabled = mod.show_viewport and mod.show_render
                    right_enabled = False
                    if i + 1 < len(modifiers_list):
                        right_enabled = mod2.show_viewport and mod2.show_render

                    if not left_enabled and not right_enabled:
                        continue

                    # Prepare cloth modifiers for both columns before drawing advanced controls.
                    left_target = hhp_deform_modifier_target(mod)
                    left_cloth = hhp_get_cloth_modifier(left_target) if left_enabled else None
                    right_target = None
                    right_cloth = None
                    if i + 1 < len(modifiers_list):
                        right_target = hhp_deform_modifier_target(mod2)
                        right_cloth = hhp_get_cloth_modifier(right_target) if right_enabled else None

                    # Preset dropdown row: use two columns if a second modifier exists, otherwise use a single full-width row.
                    if i + 1 < len(modifiers_list):
                        preset_row = col.split(factor=0.5, align=True)
                        left_preset = preset_row.column(align=True)
                        if left_cloth:
                            left_preset.prop(left_target, "hhp_physics_shape_preset", text="")
                        else:
                            left_preset.label(text="")
                        right_preset = preset_row.column(align=True)
                        if right_cloth:
                            right_preset.prop(right_target, "hhp_physics_shape_preset", text="")
                        else:
                            right_preset.label(text="")
                    else:
                        preset_row = col.row(align=True)
                        if left_cloth:
                            preset_row.prop(left_target, "hhp_physics_shape_preset", text="")
                        else:
                            preset_row.label(text="")

                    # Strength slider row: use two columns if a second modifier exists, otherwise use a single full-width row
                    if i + 1 < len(modifiers_list):
                        strength_row = col.split(factor=0.5, align=True)
                        left_col = strength_row.column(align=True)
                        right_col = strength_row.column(align=True)
                        # Left column strength slider
                        if left_enabled and mod.type == 'SURFACE_DEFORM':
                            left_col.prop(mod, "strength", text="Deform Strength")
                        else:
                            left_col.label(text="")
                        # Right column strength slider
                        if right_enabled and mod2.type == 'SURFACE_DEFORM':
                            right_col.prop(mod2, "strength", text="Deform Strength")
                        else:
                            right_col.label(text="")
                    else:
                        single_strength = col.row(align=True)
                        if left_enabled and mod.type == 'SURFACE_DEFORM':
                            single_strength.prop(mod, "strength", text="Deform Strength")
                        else:
                            single_strength.label(text="")
                    
                    # Define single_mode based on whether a second modifier exists
                    single_mode = (i + 1 >= len(modifiers_list))
                    
                    # Add cloth simulation sliders above gravity for cloth modifiers
                    if left_cloth or right_cloth:
                        if not single_mode:
                            speed_row = col.split(factor=0.5, align=True)
                            left_speed = speed_row.column(align=True)
                            if left_cloth:
                                left_speed.prop(left_cloth.settings, "time_scale", text="Speed Multiplier")
                            else:
                                left_speed.label(text="")
                            right_speed = speed_row.column(align=True)
                            if right_cloth:
                                right_speed.prop(right_cloth.settings, "time_scale", text="Speed Multiplier")
                            else:
                                right_speed.label(text="")

                            mass_row = col.split(factor=0.5, align=True)
                            left_mass = mass_row.column(align=True)
                            if left_cloth:
                                left_mass.prop(left_cloth.settings, "mass", text="Vertex Mass", slider=True)
                            else:
                                left_mass.label(text="")
                            right_mass = mass_row.column(align=True)
                            if right_cloth:
                                right_mass.prop(right_cloth.settings, "mass", text="Vertex Mass", slider=True)
                            else:
                                right_mass.label(text="")

                            pressure_row = col.split(factor=0.5, align=True)
                            left_pressure = pressure_row.column(align=True)
                            if left_cloth:
                                left_pressure.prop(left_cloth.settings, "pressure_factor", text="Pressure Scale", slider=True)
                            else:
                                left_pressure.label(text="")
                            right_pressure = pressure_row.column(align=True)
                            if right_cloth:
                                right_pressure.prop(right_cloth.settings, "pressure_factor", text="Pressure Scale", slider=True)
                            else:
                                right_pressure.label(text="")

                            gravity_row = col.split(factor=0.5, align=True)
                            left_gravity = gravity_row.column(align=True)
                            if left_cloth:
                                left_gravity.prop(left_cloth.settings.effector_weights, "gravity", text="Gravity", slider=True)
                            else:
                                left_gravity.label(text="")
                            right_gravity = gravity_row.column(align=True)
                            if right_cloth:
                                right_gravity.prop(right_cloth.settings.effector_weights, "gravity", text="Gravity", slider=True)
                            else:
                                right_gravity.label(text="")
                        else:
                            speed_row = col.row(align=True)
                            if left_cloth:
                                speed_row.prop(left_cloth.settings, "time_scale", text="Speed Multiplier")
                            else:
                                speed_row.label(text="")

                            mass_row = col.row(align=True)
                            if left_cloth:
                                mass_row.prop(left_cloth.settings, "mass", text="Vertex Mass", slider=True)
                            else:
                                mass_row.label(text="")

                            pressure_row = col.row(align=True)
                            if left_cloth:
                                pressure_row.prop(left_cloth.settings, "pressure_factor", text="Pressure Scale", slider=True)
                            else:
                                pressure_row.label(text="")

                            gravity_row = col.row(align=True)
                            if left_cloth:
                                gravity_row.prop(left_cloth.settings.effector_weights, "gravity", text="Gravity", slider=True)
                            else:
                                gravity_row.label(text="")

                    if left_cloth or right_cloth:
                        # Row for collision toggles (if single, use full width; otherwise split into two columns)
                        if not single_mode:
                            toggle_row = col.split(factor=0.5, align=True)
                            left_toggle = toggle_row.column(align=True)
                            if left_cloth:
                                left_toggle_inner = left_toggle.row(align=True)
                                left_toggle_inner.prop(left_cloth.collision_settings, "use_collision", text="Collision", icon='INDIRECT_ONLY_ON')
                                left_toggle_inner.prop(left_cloth.collision_settings, "use_self_collision", text="Self Col", icon='INDIRECT_ONLY_ON')
                            else:
                                left_toggle.label(text="")
                            right_toggle = toggle_row.column(align=True)
                            if right_cloth:
                                right_toggle_inner = right_toggle.row(align=True)
                                right_toggle_inner.prop(right_cloth.collision_settings, "use_collision", text="Collision", icon='INDIRECT_ONLY_ON')
                                right_toggle_inner.prop(right_cloth.collision_settings, "use_self_collision", text="Self Col", icon='INDIRECT_ONLY_ON')
                            else:
                                right_toggle.label(text="")
                        else:
                            toggle_row = col.row(align=True)
                            if left_cloth:
                                toggle_row.prop(left_cloth.collision_settings, "use_collision", text="Collision", icon='INDIRECT_ONLY_ON')
                                toggle_row.prop(left_cloth.collision_settings, "use_self_collision", text="Self Col", icon='INDIRECT_ONLY_ON')
                            else:
                                toggle_row.label(text="")

                        # Row for distance settings (always shown)
                        if not single_mode:
                            distance_row = col.split(factor=0.5, align=True)
                            left_distance = distance_row.column(align=True)
                            if left_cloth:
                                left_dist_inner = left_distance.row(align=True)
                                left_dist_inner.prop(left_cloth.collision_settings, "distance_min", text="Col. Dist")
                                left_dist_inner.prop(left_cloth.collision_settings, "self_distance_min", text="Self Col. Dist")
                            else:
                                left_distance.label(text="")
                            right_distance = distance_row.column(align=True)
                            if right_cloth:
                                right_dist_inner = right_distance.row(align=True)
                                right_dist_inner.prop(right_cloth.collision_settings, "distance_min", text="Col. Dist")
                                right_dist_inner.prop(right_cloth.collision_settings, "self_distance_min", text="Self Col. Dist")
                            else:
                                right_distance.label(text="")
                        else:
                            distance_row = col.row(align=True)
                            if left_cloth:
                                distance_row.prop(left_cloth.collision_settings, "distance_min", text="Col. Dist")
                                distance_row.prop(left_cloth.collision_settings, "self_distance_min", text="Self Col. Dist")
                            else:
                                distance_row.label(text="")

                        # Impulse clamping below collision distance (object and self)
                        if not single_mode:
                            clamp_row = col.split(factor=0.5, align=True)
                            left_clamp = clamp_row.column(align=True)
                            if left_cloth:
                                left_clamp_inner = left_clamp.row(align=True)
                                left_clamp_inner.prop(left_cloth.collision_settings, "impulse_clamp", text="Col. Clamp")
                                left_clamp_inner.prop(left_cloth.collision_settings, "self_impulse_clamp", text="Self Col. Clamp")
                            else:
                                left_clamp.label(text="")
                            right_clamp = clamp_row.column(align=True)
                            if right_cloth:
                                right_clamp_inner = right_clamp.row(align=True)
                                right_clamp_inner.prop(right_cloth.collision_settings, "impulse_clamp", text="Col. Clamp")
                                right_clamp_inner.prop(right_cloth.collision_settings, "self_impulse_clamp", text="Self Col. Clamp")
                            else:
                                right_clamp.label(text="")
                        else:
                            clamp_row = col.row(align=True)
                            if left_cloth:
                                clamp_row.prop(left_cloth.collision_settings, "impulse_clamp", text="Col. Clamp")
                                clamp_row.prop(left_cloth.collision_settings, "self_impulse_clamp", text="Self Col. Clamp")
                            else:
                                clamp_row.label(text="")

                        # Row for quality steps (Quality and Collision Quality)
                        if not single_mode:
                            quality_row = col.split(factor=0.5, align=True)
                            left_quality = quality_row.column(align=True)
                            if left_cloth:
                                left_quality_inner = left_quality.row(align=True)
                                left_quality_inner.prop(left_cloth.settings, "quality", text="Quality")
                                left_quality_inner.prop(left_cloth.collision_settings, "collision_quality", text="Col Qual")
                            else:
                                left_quality.label(text="")
                            right_quality = quality_row.column(align=True)
                            if right_cloth:
                                right_quality_inner = right_quality.row(align=True)
                                right_quality_inner.prop(right_cloth.settings, "quality", text="Quality")
                                right_quality_inner.prop(right_cloth.collision_settings, "collision_quality", text="Col Qual")
                            else:
                                right_quality.label(text="")
                        else:
                            quality_row = col.row(align=True)
                            if left_cloth:
                                quality_row.prop(left_cloth.settings, "quality", text="Quality")
                                quality_row.prop(left_cloth.collision_settings, "collision_quality", text="Col Qual")
                            else:
                                quality_row.label(text="")

                    # Add restore/subdiv cage buttons row (for advanced cage editing)
                    if left_cloth or right_cloth:
                        if not single_mode:
                            cage_row = col.split(factor=0.5, align=True)
                            # Left column: restore and subdiv side-by-side (for left_cloth)
                            left_cage = left_cloth
                            left_cage_col = cage_row.column(align=True)
                            if left_cage:
                                left_hhp_enabled = mod.show_viewport and mod.show_render
                                left_target = left_cage.id_data
                                left_has_stored_cage = HHP_CAGE_TOPOLOGY_PROP in left_target
                                left_subdiv_count = left_target.get("cage_subdiv_count", 0)
                                # Use HHP modifier's state to determine physics enabled state
                                left_physics_enabled = left_hhp_enabled
                                # Create two sub-columns in the same row for left restore and subdiv buttons
                                left_cage_inner = left_cage_col.row(align=True)
                                left_cage_action_col = left_cage_inner.column(align=True)
                                left_subdiv_col = left_cage_inner.column(align=True)
                                left_subdiv_col.enabled = left_physics_enabled
                                if left_has_stored_cage:
                                    left_cage_action_col.enabled = left_physics_enabled
                                    op_restore = left_cage_action_col.operator("hhp.restore_cage", text="Restore Cage", icon='LOOP_BACK')
                                    op_restore.target_name = left_target.name
                                elif left_subdiv_count > 0:
                                    left_cage_action_col.enabled = left_physics_enabled
                                    op_unsubdiv = left_cage_action_col.operator("hhp.unsubdiv_cage", text="Unsubdiv Cage", icon='MOD_REMESH')
                                    op_unsubdiv.target_name = left_target.name
                                else:
                                    left_cage_action_col.enabled = False
                                    op_restore = left_cage_action_col.operator("hhp.restore_cage", text="Restore Cage", icon='LOOP_BACK')
                                    op_restore.target_name = left_target.name
                                op_subdiv = left_subdiv_col.operator("hhp.subdiv_cage", text="Subdiv Cage", icon='MOD_SUBSURF')
                                op_subdiv.target_name = left_target.name
                            else:
                                left_cage_col.label(text="")

                            # Right column: restore and subdiv side-by-side (for right_cloth)
                            right_cage = right_cloth
                            right_cage_col = cage_row.column(align=True)
                            if right_cage:
                                right_hhp_enabled = mod2.show_viewport and mod2.show_render
                                right_target = right_cage.id_data
                                right_has_stored_cage = HHP_CAGE_TOPOLOGY_PROP in right_target
                                right_subdiv_count = right_target.get("cage_subdiv_count", 0)
                                # Use the HHP modifier's state for the right side as well
                                right_physics_enabled = right_hhp_enabled
                                right_cage_inner = right_cage_col.row(align=True)
                                right_cage_action_col = right_cage_inner.column(align=True)
                                right_subdiv_col = right_cage_inner.column(align=True)
                                right_subdiv_col.enabled = right_physics_enabled
                                if right_has_stored_cage:
                                    right_cage_action_col.enabled = right_physics_enabled
                                    op_restore = right_cage_action_col.operator("hhp.restore_cage", text="Restore Cage", icon='LOOP_BACK')
                                    op_restore.target_name = right_target.name
                                elif right_subdiv_count > 0:
                                    right_cage_action_col.enabled = right_physics_enabled
                                    op_unsubdiv = right_cage_action_col.operator("hhp.unsubdiv_cage", text="Unsubdiv Cage", icon='MOD_REMESH')
                                    op_unsubdiv.target_name = right_target.name
                                else:
                                    right_cage_action_col.enabled = False
                                    op_restore = right_cage_action_col.operator("hhp.restore_cage", text="Restore Cage", icon='LOOP_BACK')
                                    op_restore.target_name = right_target.name
                                op_subdiv = right_subdiv_col.operator("hhp.subdiv_cage", text="Subdiv Cage", icon='MOD_SUBSURF')
                                op_subdiv.target_name = right_target.name
                            else:
                                right_cage_col.label(text="")

                            # Pin Group slots (one per cloth target)
                            pin_row = col.split(factor=0.5, align=True)
                            left_pin_col = pin_row.column(align=True)
                            if left_cloth:
                                left_target = left_cloth.id_data
                                left_pin_row = left_pin_col.row(align=True)
                                left_pin_row.prop_search(
                                    left_cloth.settings,
                                    "vertex_group_mass",
                                    left_target,
                                    "vertex_groups",
                                    text=""
                                )
                                left_pin_quick = left_pin_row.operator("hhp.pin_quick_swap", text="", icon='PINNED')
                                left_pin_quick.target_name = left_target.name
                            else:
                                left_pin_col.label(text="")

                            right_pin_col = pin_row.column(align=True)
                            if right_cloth:
                                right_target = right_cloth.id_data
                                right_pin_row = right_pin_col.row(align=True)
                                right_pin_row.prop_search(
                                    right_cloth.settings,
                                    "vertex_group_mass",
                                    right_target,
                                    "vertex_groups",
                                    text=""
                                )
                                right_pin_quick = right_pin_row.operator("hhp.pin_quick_swap", text="", icon='PINNED')
                                right_pin_quick.target_name = right_target.name
                            else:
                                right_pin_col.label(text="")
                        else:
                            # Single mode: show buttons for left_cloth only
                            cage_row = col.row(align=True)
                            if left_cloth:
                                left_hhp_enabled = mod.show_viewport and mod.show_render
                                left_target = left_cloth.id_data
                                left_has_stored_cage = HHP_CAGE_TOPOLOGY_PROP in left_target
                                left_subdiv_count = left_target.get("cage_subdiv_count", 0)
                                # Use HHP modifier's state to determine physics enabled state
                                left_physics_enabled = left_hhp_enabled
                                cage_action_col = cage_row.column(align=True)
                                subdiv_col = cage_row.column(align=True)
                                subdiv_col.enabled = left_physics_enabled
                                if left_has_stored_cage:
                                    cage_action_col.enabled = left_physics_enabled
                                    op_restore = cage_action_col.operator("hhp.restore_cage", text="Restore Cage", icon='LOOP_BACK')
                                    op_restore.target_name = left_target.name
                                elif left_subdiv_count > 0:
                                    cage_action_col.enabled = left_physics_enabled
                                    op_unsubdiv = cage_action_col.operator("hhp.unsubdiv_cage", text="Unsubdiv Cage", icon='MOD_REMESH')
                                    op_unsubdiv.target_name = left_target.name
                                else:
                                    cage_action_col.enabled = False
                                    op_restore = cage_action_col.operator("hhp.restore_cage", text="Restore Cage", icon='LOOP_BACK')
                                    op_restore.target_name = left_target.name
                                op_subdiv = subdiv_col.operator("hhp.subdiv_cage", text="Subdiv Cage", icon='MOD_SUBSURF')
                                op_subdiv.target_name = left_target.name

                                pin_row = col.row(align=True)
                                pin_row.prop_search(
                                    left_cloth.settings,
                                    "vertex_group_mass",
                                    left_target,
                                    "vertex_groups",
                                    text=""
                                )
                                pin_quick = pin_row.operator("hhp.pin_quick_swap", text="", icon='PINNED')
                                pin_quick.target_name = left_target.name
                            else:
                                cage_row.label(text="")
                    
                    # Add a separator between this item block and the next one if more modifiers follow
                    if i + 2 < len(modifiers_list):
                        col.separator(factor=4.0)

            # Proxy displace and lattice strength sliders stay grouped below all HHP modifier buttons.
            for i in range(0, len(modifiers_list), 2):
                obj, mod, _mod_display_name = modifiers_list[i]

                if i + 1 < len(modifiers_list):
                    obj2, mod2, _mod_display_name2 = modifiers_list[i + 1]
                    left_target = mod.target if mod.type == 'SURFACE_DEFORM' else None
                    right_target = mod2.target if mod2.type == 'SURFACE_DEFORM' else None
                    left_enabled = mod.show_viewport and mod.show_render
                    right_enabled = mod2.show_viewport and mod2.show_render

                    left_has_bs_inflate = left_target and "BS_Inflate" in left_target and left_enabled
                    right_has_bs_inflate = right_target and "BS_Inflate" in right_target and right_enabled

                    if left_has_bs_inflate and right_has_bs_inflate:
                        bs_inflate_row = col.row(align=True)
                        left_bs_col = bs_inflate_row.column(align=True)
                        right_bs_col = bs_inflate_row.column(align=True)
                        left_bs_col.prop(left_target, '["BS_Inflate"]', text=f"{obj.name} Proxy Displace")
                        right_bs_col.prop(right_target, '["BS_Inflate"]', text=f"{obj2.name} Proxy Displace")
                    elif left_has_bs_inflate:
                        bs_inflate_row = col.row(align=True)
                        bs_inflate_row.prop(left_target, '["BS_Inflate"]', text=f"{obj.name} Proxy Displace")
                    elif right_has_bs_inflate:
                        bs_inflate_row = col.row(align=True)
                        bs_inflate_row.prop(right_target, '["BS_Inflate"]', text=f"{obj2.name} Proxy Displace")

                    left_lattice_mods = [m for m in obj.modifiers if m.type == 'LATTICE'] if left_enabled else []
                    right_lattice_mods = [m for m in obj2.modifiers if m.type == 'LATTICE'] if right_enabled else []

                    max_lattice_count = max(len(left_lattice_mods), len(right_lattice_mods))
                    for lattice_idx in range(max_lattice_count):
                        left_lattice_mod = left_lattice_mods[lattice_idx] if lattice_idx < len(left_lattice_mods) else None
                        right_lattice_mod = right_lattice_mods[lattice_idx] if lattice_idx < len(right_lattice_mods) else None

                        if left_lattice_mod and right_lattice_mod:
                            lattice_row = col.row(align=True)
                            left_lattice_col = lattice_row.column(align=True)
                            right_lattice_col = lattice_row.column(align=True)
                            left_lattice_col.prop(left_lattice_mod, "strength", text=f"{obj.name} {left_lattice_mod.name} Strength", slider=True)
                            right_lattice_col.prop(right_lattice_mod, "strength", text=f"{obj2.name} {right_lattice_mod.name} Strength", slider=True)
                        elif left_lattice_mod:
                            lattice_row = col.row(align=True)
                            lattice_row.prop(left_lattice_mod, "strength", text=f"{obj.name} {left_lattice_mod.name} Strength", slider=True)
                        elif right_lattice_mod:
                            lattice_row = col.row(align=True)
                            lattice_row.prop(right_lattice_mod, "strength", text=f"{obj2.name} {right_lattice_mod.name} Strength", slider=True)
                else:
                    left_target = mod.target if mod.type == 'SURFACE_DEFORM' else None
                    left_enabled = mod.show_viewport and mod.show_render

                    if left_target and "BS_Inflate" in left_target and left_enabled:
                        single_bs_inflate = col.row(align=True)
                        single_bs_inflate.prop(left_target, '["BS_Inflate"]', text=f"{obj.name} Proxy Displace")

                    if left_enabled:
                        left_lattice_mods = [m for m in obj.modifiers if m.type == 'LATTICE']
                        for lattice_mod in left_lattice_mods:
                            single_lattice = col.row(align=True)
                            single_lattice.prop(lattice_mod, "strength", text=f"{obj.name} {lattice_mod.name} Strength", slider=True)

            # Add a separator
            col.separator()

            # Physics framerate multiplier menu - moved outside advanced settings
            col.operator_menu_enum(
                "object.physics_framerate_multiplier",
                "action",
                text="Physics framerate multiplier",
                icon='TIME'
            )
            col.separator()

            # If show advanced is enabled, add the physics framerate multiplier menu
            if context.scene.hhp_props.show_strength:
                # Advanced settings section was here
                # Physics framerate multiplier removed from here
                col.separator()

            # Add the new button to rebind modifiers
            rebind_op = col.operator(
                "object.bind_unbind_hhp_modifiers",
                text="Rebind Physics",
                icon='FILE_REFRESH'
            )
            rebind_op.rebind_all_visible = physics_scope == 'ALL'

            row = col.row(align=True)
            ptcache_proxy_mixin = HHP_PTCacheProxyMixin()
            cache_source_objects = all_physics_objects if physics_scope == 'ALL' else None
            unbaked_proxy_count = ptcache_proxy_mixin.count_unbaked_proxy_targets(context, cache_source_objects)
            bake_text = f"Current Cache to Bake ({unbaked_proxy_count})" if unbaked_proxy_count else "Current Cache to Bake"
            bake_current_col = row.column(align=True)
            bake_current_col.enabled = unbaked_proxy_count > 0
            bake_current_op = bake_current_col.operator("object.hhp_ptcache_bake_current", text=bake_text, icon='RECOVER_LAST')
            bake_current_op.use_all_visible = physics_scope == 'ALL'
            baked_proxy_count = ptcache_proxy_mixin.count_baked_proxy_targets(context, cache_source_objects)
            delete_text = f"Delete Bake ({baked_proxy_count} Baked)" if baked_proxy_count else "Delete Bake"
            delete_menu_col = row.column(align=True)
            delete_menu_col.enabled = baked_proxy_count > 0
            delete_menu_col.alert = baked_proxy_count > 0
            delete_menu_op = delete_menu_col.operator("object.hhp_ptcache_free_baked_menu", text="", icon='DOWNARROW_HLT')
            delete_menu_op.use_all_visible = physics_scope == 'ALL'
            delete_col = row.column(align=True)
            delete_col.alert = baked_proxy_count > 0
            delete_op = delete_col.operator("object.hhp_ptcache_free_current", text=delete_text, icon='TRASH')
            delete_op.use_all_visible = physics_scope == 'ALL'

            # Add bake/free buttons with confirmation
            row = col.row(align=True)
            bake_all_text = f"Bake ({unbaked_proxy_count})" if unbaked_proxy_count else "Bake"
            bake_col = row.column(align=True)
            bake_col.enabled = unbaked_proxy_count > 0
            bake_menu_op = bake_col.operator("object.ptcache_bake_menu", text=bake_all_text, icon='PHYSICS')
            bake_menu_op.use_all_visible = physics_scope == 'ALL'
            row.prop(context.scene.hhp_props, "auto_bake", text="", icon='REC', toggle=True)
            row.operator("object.ptcache_free_bake_all", text="Free All", icon='X')

        # Lattice Shapekeys Section - Show when the active object is a lattice
        active_obj = context.active_object
        if active_obj and active_obj.type == 'LATTICE':
            lattice_box = layout.box()
            lattice_box.label(text="Lattice shapekeyes", icon='LATTICE_DATA')
            
            # Create the full shapekey editor interface
            draw_lattice_shapekey_editor(lattice_box, context, active_obj)

    def collect_collections(self, collection, collection_list, parent_hidden=False, is_top_level=False, processed_collections=None, level=0):
        if processed_collections is None:
            processed_collections = set()
        if collection in processed_collections:
            return
        processed_collections.add(collection)

        collection_list.append((collection, level, parent_hidden, is_top_level))

        # Determine if current parent is hidden
        current_parent_hidden = parent_hidden or collection.hide_viewport

        # Process children collections
        for child in collection.children:
            self.collect_collections(
                child,
                collection_list,
                parent_hidden=current_parent_hidden,
                is_top_level=False,
                processed_collections=processed_collections,
                level=level+1
            )

    def selected_objects_with_active(self, context):
        selected_objects = list(getattr(context, "selected_objects", []) or [])
        active_obj = getattr(context, "active_object", None)
        if active_obj and active_obj not in selected_objects:
            selected_objects.append(active_obj)
        return selected_objects

    def find_char_hhp_collection_for_object(self, obj):
        for collection in getattr(obj, "users_collection", []) or []:
            for candidate in [collection] + hhp_parent_collections(collection):
                if hhp_collection_base_name(candidate.name) == "Char (HHP)":
                    return candidate
        return None

    def find_selected_char_hhp_collections(self, context):
        char_collections = []
        for obj in self.selected_objects_with_active(context):
            char_collection = self.find_char_hhp_collection_for_object(obj)
            if char_collection and char_collection not in char_collections:
                char_collections.append(char_collection)
        char_collections.sort(key=lambda collection: collection.name)
        return char_collections

    def find_parent_char_hhp_collection(self, collection):
        for candidate in [collection] + hhp_parent_collections(collection):
            if hhp_collection_base_name(candidate.name) == "Char (HHP)":
                return candidate
        return None

    def selected_objects_in_collection(self, context, collection):
        return [
            obj for obj in self.selected_objects_with_active(context)
            if hhp_collection_contains_object(collection, obj)
        ]

    def is_collision_only_selection(self, context, collision_collection):
        char_collection = self.find_parent_char_hhp_collection(collision_collection)
        selected_objects = self.selected_objects_with_active(context)
        if char_collection:
            selected_in_char = [
                obj for obj in selected_objects
                if hhp_collection_contains_object(char_collection, obj)
            ]
        else:
            selected_in_char = self.selected_objects_in_collection(context, collision_collection)

        return bool(selected_in_char) and all(
            hhp_collection_contains_object(collision_collection, obj)
            for obj in selected_in_char
        )

    def find_proxies_collections(self, context=None):
        """Find 'Proxies (HHP)' and 'Collision' collections for selected Char (HHP) trees."""
        context = context or bpy.context
        proxies_collections = []
        processed_collections = set()

        for collection in self.find_selected_char_hhp_collections(context):
            for sub_collection in collection.children:
                base_name = hhp_collection_base_name(sub_collection.name)
                if sub_collection in processed_collections:
                    continue

                if base_name == "Collision":
                    processed_collections.add(sub_collection)
                    proxies_collections.append((sub_collection, 0, False, True))
                elif base_name == "Proxies (HHP)":
                    self.collect_collections(
                        sub_collection,
                        proxies_collections,
                        parent_hidden=False,
                        is_top_level=True,
                        processed_collections=processed_collections
                    )
        return proxies_collections

    def collect_collision_objects(self, root_collection):
        """Recursively collect all objects from a Collision collection hierarchy."""
        objects = []

        def _recurse(coll):
            # Add all objects directly in this collection
            for obj in coll.objects:
                if obj not in objects:
                    objects.append(obj)
            # Recurse into child collections
            for child in coll.children:
                _recurse(child)

        _recurse(root_collection)
        return objects

    def make_collection_visible(self, collection):
        # Make this collection visible
        collection.hide_viewport = False
        # Recursively make parent collections visible
        parent_collections = [
            parent for parent in bpy.data.collections if collection.name in parent.children.keys()
        ]
        for parent in parent_collections:
            self.make_collection_visible(parent)


class HHP_OT_GenerateOptimizedCollision(bpy.types.Operator):
    """Generate an optimized collision mesh from the linked collision proxy."""
    bl_idname = "hhp.generate_optimized_collision"
    bl_label = "Generate optimized collision"
    bl_description = "Generate an optimized collision mesh from the linked collision proxy and decimate it to 0.25"
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(
        name="Collision Collection Name",
        description="Name of the Collision collection to generate optimized collision for"
    )

    def invoke(self, context, event):
        # Ask the user for confirmation before executing
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        collection = bpy.data.collections.get(self.collection_name)
        if not collection:
            self.report({'ERROR'}, f"Collision collection '{self.collection_name}' not found")
            return {'CANCELLED'}

        # Gather all objects in this collision collection hierarchy
        collision_objects = []

        def _recurse(coll):
            for obj in coll.objects:
                collision_objects.append(obj)
            for child in coll.children:
                _recurse(child)

        _recurse(collection)

        linked_name_tag = "Collision - Linked (DO NOT EDIT MESH)"
        linked_objects = [o for o in collision_objects if linked_name_tag in o.name]

        if not linked_objects:
            self.report({'ERROR'}, "No linked collision proxy found in this collection")
            return {'CANCELLED'}

        # Pick the linked object with the lowest enumeration:
        # base name (no .001) -> 0, otherwise use the numeric suffix.
        def enum_index(obj_name):
            m = re.search(r"\.(\d{3})$", obj_name)
            return int(m.group(1)) if m else 0

        source_obj = min(linked_objects, key=lambda o: enum_index(o.name))

        # Duplicate the object
        new_obj = source_obj.copy()
        # Make it a single user so it is no longer linked
        if new_obj.data:
            new_obj.data = new_obj.data.copy()

        # Remove all materials from the optimized collision mesh
        # (collision proxies should not carry shading/material data)
        if new_obj.type == 'MESH' and new_obj.data:
            try:
                new_obj.data.materials.clear()
            except Exception:
                pass

        # Rename to "Collision - Fullbody (Optimized)"
        new_obj.name = "Collision - Fullbody (Optimized)"

        # Link to the same collections as the source object
        for coll in source_obj.users_collection:
            if new_obj.name not in coll.objects:
                coll.objects.link(new_obj)

        # Ensure the new optimized mesh is enabled in viewport before further steps
        try:
            new_obj.hide_viewport = False
        except Exception:
            pass

        # Store current selection, active object and mode
        view_layer = context.view_layer
        original_active = view_layer.objects.active
        original_selection = [obj for obj in view_layer.objects if obj.select_get()]
        original_mode = 'OBJECT'
        if original_active:
            try:
                original_mode = original_active.mode
            except AttributeError:
                original_mode = 'OBJECT'

        # Make new_obj active and selected to apply edit-mode decimate
        bpy.ops.object.mode_set(mode='OBJECT')
        for obj in view_layer.objects:
            obj.select_set(False)
        new_obj.select_set(True)
        view_layer.objects.active = new_obj

        try:
            # Enter edit mode and perform decimate at 0.25, like:
            # edit mode > unhide all > select all > decimate to 0.25
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.reveal(select=True)
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.decimate(ratio=0.25)
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception as e:
            self.report({'WARNING'}, f"Could not perform edit-mode decimate: {e}")

        # Toggle visibility: turn off all linked collision proxies and turn on the new mesh
        for obj in linked_objects:
            try:
                obj.hide_viewport = True
            except Exception:
                pass

        try:
            new_obj.hide_viewport = False
        except Exception:
            pass

        # Restore original selection, active object and mode
        for obj in view_layer.objects:
            obj.select_set(False)
        for obj in original_selection:
            if obj.name in view_layer.objects:
                view_layer.objects[obj.name].select_set(True)
        if original_active and original_active.name in view_layer.objects:
            view_layer.objects.active = view_layer.objects[original_active.name]
            try:
                bpy.ops.object.mode_set(mode=original_mode)
            except Exception:
                pass

        self.report({'INFO'}, f"Generated optimized collision from '{source_obj.name}'")
        return {'FINISHED'}

class HHPProperties(PropertyGroup):
    """Stores temporary data for the cage editing process."""
    auto_bake: BoolProperty(
        name="Auto Bake HHP Physics",
        description="Convert enabled HHP physics caches in the current Show Physics For scope to bakes when playback reaches each simulation's end frame",
        default=False,
    )
    is_edit_cage: BoolProperty(
        name="Is Edit Cage Active",
        description="True when we are in the middle of cage editing",
        default=False
    )
    stored_object_name: StringProperty(
        name="Stored Object Name",
        description="Name of the mesh used for cage editing",
        default=""
    )
    stored_display_type: StringProperty(
        name="Stored Display Type",
        description="Original display type of the mesh",
        default=""
    )
    stored_modifier_states: StringProperty(
        name="Stored Modifiers States (JSON)",
        description="JSON string storing modifiers' viewport visibility",
        default=""
    )
    show_strength: BoolProperty(
        name="Show advanced",
        description="Show advanced settings for HHP physics",
        default=False
    )
    physics_display_scope: EnumProperty(
        name="Show Physics For",
        description="Choose which HHP physics controls are shown in the physics list",
        items=[
            ('ALL', "All Visible", "Show HHP physics for all visible HHP meshes in the scene", 'FILE_VOLUME', 0),
            ('SELECTED', "Selected Mesh", "Show HHP physics for the active and selected meshes", 'RESTRICT_SELECT_OFF', 1),
        ],
        default='ALL'
    )
    gravity_factor: FloatProperty(
        name="Gravity Factor",
        description="Controls the strength of gravity in physics simulations",
        default=1.0,
        min=0.0,
        max=1.0,
        precision=2
    )
    cage_subdiv_count: IntProperty(
        name="Cage Subdivision Count",
        description="Number of subdivisions applied to the cage since the original topology was stored",
        default=0,
        min=0
    )

class HHP_OT_EditCage(bpy.types.Operator):
    """Edit cage shape with a new shapekey."""
    bl_idname = "hhp.edit_cage"
    bl_label = "Edit Cage (With Shapekey)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Active object is not a mesh.")
            return {'CANCELLED'}

        # Check for Cloth / Soft Body modifiers
        cloth_soft_mod_found = any(m.type in {'CLOTH', 'SOFT_BODY'} for m in obj.modifiers)
        if not cloth_soft_mod_found:
            self.report({'ERROR'}, "Active mesh has no Cloth or Soft Body modifiers.")
            return {'CANCELLED'}

        props = context.scene.hhp_props
        props.stored_object_name = obj.name

        # Store current visibility state of all modifiers
        modifiers_info = []
        for mod in obj.modifiers:
            modifiers_info.append({
                'name': mod.name,
                'type': mod.type,
                'show_viewport': mod.show_viewport
            })
        props.stored_modifier_states = json.dumps(modifiers_info)

        # Store current display type
        props.stored_display_type = obj.display_type

        # Set display type to SOLID
        obj.display_type = 'SOLID'

        # Switch to OBJECT mode
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Deselect all objects, select only the active one
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        # Disable all modifiers
        for mod in obj.modifiers:
            mod.show_viewport = False

        # Enter local view
        bpy.ops.view3d.localview(frame_selected=False)

        # Add shape keys (Basis if missing, plus "(BS)_SculptShapeKey")
        if not obj.data.shape_keys:
            obj.shape_key_add(name='Basis', from_mix=False)
        obj.shape_key_add(name="(BS)_SculptShapeKey", from_mix=False)
        # Make this shape key active
        obj.active_shape_key_index = len(obj.data.shape_keys.key_blocks) - 1
        # Set its value to 1
        obj.active_shape_key.value = 1

        # Enter sculpt mode
        bpy.ops.object.mode_set(mode='SCULPT')

        # Flag that we are in "edit cage" mode
        props.is_edit_cage = True

        return {'FINISHED'}

class HHP_OT_FinalizeCageEdit(bpy.types.Operator):
    """Finalize the Cage Edit (All Modifiers)."""
    bl_idname = "hhp.finalize_cage_edit"
    bl_label = "Finalize Cage Edit"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.hhp_props
        obj_name = props.stored_object_name
        if not obj_name:
            self.report({'ERROR'}, "No stored object name found. Cannot finalize.")
            return {'CANCELLED'}

        obj = bpy.data.objects.get(obj_name)
        if not obj:
            self.report({'ERROR'}, f"Object '{obj_name}' no longer exists.")
            return {'CANCELLED'}

        # Restore all modifiers' viewport visibility
        stored_modifiers = []
        if props.stored_modifier_states:
            stored_modifiers = json.loads(props.stored_modifier_states)

        for mod_state in stored_modifiers:
            mod_name = mod_state.get('name')
            show_viewport = mod_state.get('show_viewport', True)
            mod = obj.modifiers.get(mod_name)
            if mod:
                mod.show_viewport = show_viewport

        # Restore original display type
        if props.stored_display_type:
            obj.display_type = props.stored_display_type

        # Force an edit mode -> object mode cycle to refresh viewport
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.object.mode_set(mode='OBJECT')

        # Exit local view (if still in local view)
        bpy.ops.view3d.localview(frame_selected=False)

        # Reset the toggle
        props.is_edit_cage = False

        return {'FINISHED'}

def hhp_capture_cage_topology(target):
    mesh = target.data
    topology = {
        "vertices": [list(vertex.co) for vertex in mesh.vertices],
        "edges": [list(edge.vertices) for edge in mesh.edges],
        "faces": [list(poly.vertices) for poly in mesh.polygons],
        "vertex_groups": [],
        "shape_keys": [],
    }

    for group in target.vertex_groups:
        group_data = {
            "name": group.name,
            "lock_weight": group.lock_weight,
            "weights": [],
        }
        for vertex in mesh.vertices:
            for weight in vertex.groups:
                if weight.group == group.index:
                    group_data["weights"].append([vertex.index, weight.weight])
                    break
        topology["vertex_groups"].append(group_data)

    shape_keys = getattr(mesh, "shape_keys", None)
    if shape_keys:
        topology["active_shape_key_index"] = target.active_shape_key_index
        for key_block in shape_keys.key_blocks:
            topology["shape_keys"].append({
                "name": key_block.name,
                "value": key_block.value,
                "mute": key_block.mute,
                "slider_min": key_block.slider_min,
                "slider_max": key_block.slider_max,
                "coords": [list(point.co) for point in key_block.data],
            })

    return json.dumps(topology, separators=(',', ':'))


def hhp_restore_cage_topology(target, topology_json):
    topology = json.loads(topology_json)
    vertices = topology.get("vertices", [])
    edges = topology.get("edges", [])
    faces = topology.get("faces", [])

    if not vertices:
        raise ValueError("Stored cage topology has no vertices")

    target.shape_key_clear()

    mesh = target.data
    mesh.clear_geometry()
    mesh.from_pydata(vertices, edges, faces)
    mesh.update()

    while target.vertex_groups:
        target.vertex_groups.remove(target.vertex_groups[0])

    for group_data in topology.get("vertex_groups", []):
        group = target.vertex_groups.new(name=group_data.get("name", "Group"))
        group.lock_weight = group_data.get("lock_weight", False)
        for vertex_index, weight in group_data.get("weights", []):
            if 0 <= vertex_index < len(mesh.vertices):
                group.add([vertex_index], weight, 'REPLACE')

    for key_data in topology.get("shape_keys", []):
        key_block = target.shape_key_add(name=key_data.get("name", "Key"), from_mix=False)
        for point, coord in zip(key_block.data, key_data.get("coords", [])):
            point.co = coord
        key_block.value = key_data.get("value", 0.0)
        key_block.mute = key_data.get("mute", False)
        key_block.slider_min = key_data.get("slider_min", 0.0)
        key_block.slider_max = key_data.get("slider_max", 1.0)

    active_shape_key_index = topology.get("active_shape_key_index", 0)
    if target.data.shape_keys and target.data.shape_keys.key_blocks:
        target.active_shape_key_index = min(active_shape_key_index, len(target.data.shape_keys.key_blocks) - 1)


class HHP_OT_SubdivCage(bpy.types.Operator):
    bl_idname = "hhp.subdiv_cage"
    bl_label = "Subdiv Cage"
    bl_description = "Subdivide the physics cage for better collision detection. This is heavy and is not recommended for non-advanced users."

    target_name: bpy.props.StringProperty(name="Target Object Name")

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        target = bpy.data.objects.get(self.target_name)
        if not target:
            self.report({'ERROR'}, f"Target object '{self.target_name}' not found")
            return {'CANCELLED'}

        # Store original selection, active object and its mode
        orig_sel = context.selected_objects.copy()
        orig_active = context.view_layer.objects.active
        orig_mode = orig_active.mode if orig_active else 'OBJECT'

        current_count = target.get("cage_subdiv_count", 0)
        if current_count == 0 and HHP_CAGE_TOPOLOGY_PROP not in target:
            target[HHP_CAGE_TOPOLOGY_PROP] = hhp_capture_cage_topology(target)

        bpy.ops.object.select_all(action='DESELECT')
        target.select_set(True)
        context.view_layer.objects.active = target

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.reveal(select=True)
        bpy.ops.mesh.select_all(action='SELECT')

        bpy.ops.mesh.subdivide(number_cuts=1, smoothness=1.00)

        bpy.ops.object.mode_set(mode=orig_mode)
        bpy.ops.object.select_all(action='DESELECT')
        for ob in orig_sel:
            ob.select_set(True)
        context.view_layer.objects.active = orig_active

        # Increment the subdiv count for the target object
        target["cage_subdiv_count"] = current_count + 1

        return {'FINISHED'}

class HHP_OT_RestoreCage(bpy.types.Operator):
    bl_idname = "hhp.restore_cage"
    bl_label = "Restore Cage"
    bl_description = "Restore the physics cage to the original topology stored before subdivision"

    target_name: bpy.props.StringProperty(name="Target Object Name")

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        target = bpy.data.objects.get(self.target_name)
        if not target:
            self.report({'ERROR'}, f"Target object '{self.target_name}' not found")
            return {'CANCELLED'}

        topology_json = target.get(HHP_CAGE_TOPOLOGY_PROP)
        if not topology_json:
            self.report({'WARNING'}, "No stored cage topology found for this target.")
            return {'CANCELLED'}

        # Store original selection, active object and its mode
        orig_sel = context.selected_objects.copy()
        orig_active = context.view_layer.objects.active
        orig_mode = orig_active.mode if orig_active else 'OBJECT'

        bpy.ops.object.select_all(action='DESELECT')
        target.select_set(True)
        context.view_layer.objects.active = target

        if target.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        try:
            hhp_restore_cage_topology(target, topology_json)
        except Exception as error:
            self.report({'ERROR'}, f"Failed to restore cage topology: {error}")
            result = {'CANCELLED'}
        else:
            if HHP_CAGE_TOPOLOGY_PROP in target:
                del target[HHP_CAGE_TOPOLOGY_PROP]
            target["cage_subdiv_count"] = 0
            result = {'FINISHED'}
        finally:
            if orig_active == target and orig_mode != 'OBJECT':
                try:
                    bpy.ops.object.mode_set(mode=orig_mode)
                except Exception:
                    pass
            bpy.ops.object.select_all(action='DESELECT')
            for ob in orig_sel:
                ob.select_set(True)
            context.view_layer.objects.active = orig_active

        return result

class HHP_OT_UnsubdivCage(bpy.types.Operator):
    bl_idname = "hhp.unsubdiv_cage"
    bl_label = "Unsubdiv Cage"
    bl_description = "Unsubdivide the physics cage when no original cage topology snapshot is stored"

    target_name: bpy.props.StringProperty(name="Target Object Name")

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        target = bpy.data.objects.get(self.target_name)
        if not target:
            self.report({'ERROR'}, f"Target object '{self.target_name}' not found")
            return {'CANCELLED'}

        current_count = target.get("cage_subdiv_count", 0)
        if current_count < 1:
            self.report({'WARNING'}, "No subdiv operations to undo for this target.")
            return {'CANCELLED'}

        # Store original selection, active object and its mode
        orig_sel = context.selected_objects.copy()
        orig_active = context.view_layer.objects.active
        orig_mode = orig_active.mode if orig_active else 'OBJECT'

        bpy.ops.object.select_all(action='DESELECT')
        target.select_set(True)
        context.view_layer.objects.active = target

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.reveal(select=True)
        bpy.ops.mesh.select_all(action='SELECT')

        bpy.ops.mesh.unsubdivide(iterations=2)

        if orig_active == target and orig_mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode=orig_mode)
            except Exception:
                bpy.ops.object.mode_set(mode='OBJECT')
        else:
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.select_all(action='DESELECT')
        for ob in orig_sel:
            ob.select_set(True)
        context.view_layer.objects.active = orig_active

        target["cage_subdiv_count"] = current_count - 1

        return {'FINISHED'}

class HHP_OT_PinQuickSwap(bpy.types.Operator):
    bl_idname = "hhp.pin_quick_swap"
    bl_label = "Pin quick swap"
    bl_description = "Quickly swap the cloth pin group using supported proxy vertex groups"
    bl_property = "vertex_group_name"

    target_name: bpy.props.StringProperty(name="Target Object Name")

    def pin_group_items(self, context):
        target = bpy.data.objects.get(self.target_name)
        if not target or target.type != 'MESH':
            return [("__NONE__", "No matching pin groups", "No valid proxy mesh found")]

        items = []
        for vg in target.vertex_groups:
            vg_name = vg.name.casefold()
            if "(bs) hair pin" in vg_name or "(bs) easy sim pin" in vg_name:
                items.append((vg.name, vg.name, f"Set pin group to {vg.name}"))

        if not items:
            return [("__NONE__", "No matching pin groups", "No '(BS) Hair Pin' or '(BS) Easy Sim Pin' groups found")]

        return items

    vertex_group_name: bpy.props.EnumProperty(
        name="Pin quick swap",
        description="Choose a supported pin vertex group",
        items=pin_group_items
    )

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if self.vertex_group_name == "__NONE__":
            self.report({'WARNING'}, "No matching pin groups available")
            return {'CANCELLED'}

        target = bpy.data.objects.get(self.target_name)
        if not target:
            self.report({'ERROR'}, f"Target object '{self.target_name}' not found")
            return {'CANCELLED'}

        cloth_mod = next((m for m in target.modifiers if m.type == 'CLOTH'), None)
        if not cloth_mod:
            self.report({'ERROR'}, f"No cloth modifier found on '{target.name}'")
            return {'CANCELLED'}

        cloth_mod.settings.vertex_group_mass = self.vertex_group_name
        return {'FINISHED'}

# -------------------------------------------------------------------
# Lattice Shapekey Editor
# -------------------------------------------------------------------

def draw_lattice_shapekey_editor(layout, context, obj):
    """Draw lattice shapekey list in Blender style with category filters"""
    if not obj or obj.type != 'LATTICE':
        layout.label(text="Select a lattice object")
        return
        
    # Create main column
    main_col = layout.column(align=True)
    
    # Draw the list with add/copy/remove buttons
    list_row = main_col.row()
    
    # Left side - the list
    list_col = list_row.column()
    rows = 12
    
    # Show the template_list (empty if no shapekeys)
    if obj.data.shape_keys:
        list_col.template_list(
            "HHP_UL_LatticeShapekeysList", "",
            obj.data.shape_keys, "key_blocks",
            obj, "active_shape_key_index",
            rows=rows
        )
    else:
        # Just show empty space
        pass
    
    # Right side - add/copy/remove buttons
    buttons_col = list_row.column(align=True)
    buttons_col.operator("hhp.add_lattice_shapekey", text="", icon='ADD')
    buttons_col.operator("hhp.copy_lattice_shapekey", text="", icon='DUPLICATE')
    buttons_col.operator("hhp.remove_lattice_shapekey", text="", icon='REMOVE')
    
    if not obj.data.shape_keys:
        return
        
    shape_keys = obj.data.shape_keys
    wm = context.window_manager
    
    # Controls
    if obj.data.shape_keys:
        controls_row = main_col.row(align=True)
        
        # Left column: Mute controls
        left_col = controls_row.column(align=True)
        
        # Check if any shapekeys are muted (excluding basis if it exists)
        any_muted = False
        for i, sk in enumerate(obj.data.shape_keys.key_blocks):
            if i > 0 and sk.mute:  # Skip basis shapekey if it exists
                any_muted = True
                break
        
        # Mute toggle button
        mute_row = left_col.row(align=True)
        if any_muted:
            mute_row.alert = True
        
        mute_op = mute_row.operator("hhp.toggle_lattice_shapekey_mute", 
                                   text="Unmute" if any_muted else "Mute",
                                   icon='HIDE_ON' if any_muted else 'HIDE_OFF')
        mute_op.mute_state = not any_muted
        
        # Right column: Edit controls
        right_col = controls_row.column(align=True)
        right_col.prop(obj, "show_only_shape_key", text="Shapekey Lock")
        right_col.prop(obj, "use_shape_key_edit_mode", text="Edit Mode")
        
        # Set values button
        set_values_row = main_col.row(align=True)
        set_values_row.operator("hhp.set_lattice_shapekey_values", text="Set Values", icon='RNA')
        
        # Min/Max controls if we have an active shapekey (excluding basis)
        if obj.active_shape_key and obj.active_shape_key_index > 0:
            control_key = obj.active_shape_key
            min_max_row = main_col.row(align=True)
            min_max_row.prop(control_key, "slider_min", text="Range Min")
            min_max_row.prop(control_key, "slider_max", text="Max")
            
            # Vertex Group
            main_col.prop_search(control_key, "vertex_group", obj, "vertex_groups", text="")



class HHP_OT_SetLatticeShapekeyValues(bpy.types.Operator):
    """Set values for lattice shapekeys"""
    bl_idname = "hhp.set_lattice_shapekey_values"
    bl_label = "Set Lattice Shapekey Values"
    bl_description = "Set all lattice shapekeys to the specified value (excluding Basis)"
    bl_options = {'REGISTER', 'UNDO'}
    
    value: bpy.props.FloatProperty(
        name="Value",
        description="Value to set for all lattice shapekeys",
        default=0.0,
        min=0.0,
        soft_max=1.0,
        max=10.0,
        precision=3
    )
    keyframe: bpy.props.BoolProperty(
        name="Keyframe Values",
        description="If enabled, keyframe the shapekeys when setting values",
        default=False
    )
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.prop(self, "value", slider=True)
        row.prop(self, "keyframe", text="", icon='KEYINGSET')
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'LATTICE' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        current_frame = context.scene.frame_current
        
        # Set values for all shapekeys except Basis (index 0)
        for i, sk in enumerate(obj.data.shape_keys.key_blocks):
            if i > 0:  # Skip basis shapekey if it exists
                sk.value = self.value
                if self.keyframe:
                    sk.keyframe_insert("value", frame=current_frame)
        
        return {'FINISHED'}

class HHP_OT_ToggleLatticeShapekeyMute(bpy.types.Operator):
    """Toggle mute state for lattice shapekeys"""
    bl_idname = "hhp.toggle_lattice_shapekey_mute"
    bl_label = "Toggle Lattice Shapekey Mute"
    bl_description = "Toggle mute state for all lattice shapekeys (excluding Basis)"
    bl_options = {'REGISTER', 'UNDO'}
    
    mute_state: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'LATTICE' and obj.data.shape_keys
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'LATTICE' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        # Apply mute state to all shapekeys except Basis (index 0)
        for i, sk in enumerate(obj.data.shape_keys.key_blocks):
            if i > 0:  # Skip basis shapekey if it exists
                sk.mute = self.mute_state
        
        return {'FINISHED'}

class HHP_OT_AddLatticeShapekey(bpy.types.Operator):
    """Add a new lattice shapekey"""
    bl_idname = "hhp.add_lattice_shapekey"
    bl_label = "Add Lattice Shapekey"
    bl_description = "Add a new shapekey to the lattice"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'LATTICE'
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'LATTICE':
            self.report({'ERROR'}, "Active object is not a lattice")
            return {'CANCELLED'}
        
        # If no shape keys exist, create "Basis" as the first one
        if not obj.data.shape_keys:
            new_key = obj.shape_key_add(name="Basis", from_mix=False)
            new_key.value = 1.0  # Set value to 1.00
            obj.active_shape_key_index = 0
            self.report({'INFO'}, "Added shapekey 'Basis' with value 1.0")
            return {'FINISHED'}
        
        # Find the next key number based on stack position (ignoring Basis)
        existing_keys = obj.data.shape_keys.key_blocks
        non_basis_count = len(existing_keys) - 1  # Subtract 1 for Basis
        next_number = non_basis_count + 1
        
        # Create new shapekey
        new_key_name = f"Key {next_number}"
        new_key = obj.shape_key_add(name=new_key_name, from_mix=False)
        new_key.value = 1.0  # Set value to 1.00
        
        # Set as active
        for i, sk in enumerate(obj.data.shape_keys.key_blocks):
            if sk.name == new_key_name:
                obj.active_shape_key_index = i
                break
        
        self.report({'INFO'}, f"Added shapekey '{new_key_name}' with value 1.0")
        return {'FINISHED'}

class HHP_OT_CopyLatticeShapekey(bpy.types.Operator):
    """Copy the active lattice shapekey"""
    bl_idname = "hhp.copy_lattice_shapekey"
    bl_label = "Copy Lattice Shapekey"
    bl_description = "Copy the active shapekey"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'LATTICE' and obj.data.shape_keys and 
                obj.active_shape_key and obj.active_shape_key_index > 0)
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'LATTICE' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        if not obj.active_shape_key or obj.active_shape_key_index <= 0:
            self.report({'ERROR'}, "No valid shapekey selected (cannot copy Basis)")
            return {'CANCELLED'}
        
        active_key = obj.active_shape_key
        
        # Get base name without existing enumeration
        base_name = active_key.name
        # Remove existing .001, .002, etc. enumeration if present
        import re
        base_name = re.sub(r'\.\d{3}$', '', base_name)
        
        # Find next available enumeration number
        counter = 1
        copy_name = f"{base_name}.{counter:03d}"
        while copy_name in [sk.name for sk in obj.data.shape_keys.key_blocks]:
            counter += 1
            copy_name = f"{base_name}.{counter:03d}"
        
        # Create new shapekey from the active one
        new_key = obj.shape_key_add(name=copy_name, from_mix=False)
        new_key.value = active_key.value
        new_key.slider_min = active_key.slider_min
        new_key.slider_max = active_key.slider_max
        new_key.mute = active_key.mute
        
        # Copy the shape data
        for i, point in enumerate(active_key.data):
            new_key.data[i].co = point.co.copy()
        
        # Set as active
        for i, sk in enumerate(obj.data.shape_keys.key_blocks):
            if sk.name == copy_name:
                obj.active_shape_key_index = i
                break
        
        self.report({'INFO'}, f"Copied shapekey as '{copy_name}'")
        return {'FINISHED'}

class HHP_OT_RemoveLatticeShapekey(bpy.types.Operator):
    """Remove the active lattice shapekey"""
    bl_idname = "hhp.remove_lattice_shapekey"
    bl_label = "Remove Lattice Shapekey"
    bl_description = "Remove the active shapekey (including Basis)"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'LATTICE' and obj.data.shape_keys and 
                obj.active_shape_key)
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'LATTICE' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        if not obj.active_shape_key:
            self.report({'ERROR'}, "No shapekey selected")
            return {'CANCELLED'}
        
        active_key = obj.active_shape_key
        key_name = active_key.name
        
        # Remove the shapekey
        obj.shape_key_remove(active_key)
        
        self.report({'INFO'}, f"Removed shapekey '{key_name}'")
        return {'FINISHED'}



def hhp_collect_autobake_caches(context):
    mixin = HHP_PTCacheProxyMixin()
    proxies = mixin.collect_proxy_targets(context, hhp_collect_scope_physics_objects(context))
    for proxy in proxies:
        for mod in proxy.modifiers:
            cache = getattr(mod, "point_cache", None)
            if cache is not None and mod.show_viewport and mod.show_render:
                yield proxy, cache, cache.frame_end


@persistent
def hhp_physics_autobake_frame_post(scene, _depsgraph=None):
    if getattr(getattr(scene, "hhp_props", None), "auto_bake", False):
        physics_autobake.bake_at_playback_end(scene, hhp_collect_autobake_caches)


def register():
    bpy.utils.register_class(HHPProperties)
    bpy.types.Scene.hhp_props = PointerProperty(type=HHPProperties)
    if hhp_physics_autobake_frame_post not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(hhp_physics_autobake_frame_post)
    
    # Add the custom property to bpy.types.Collection
    bpy.types.Collection.show_collection = BoolProperty(
        name="",
        description="Toggle Collection Visibility",
        get=get_show_collection,
        set=set_show_collection
    )
    # Add a custom property to bpy.types.Object for viewport-only visibility toggling
    bpy.types.Object.show_object_viewport = BoolProperty(
        name="",
        description="Toggle Object Viewport Visibility",
        get=get_show_object_viewport,
        set=set_show_object_viewport
    )
    bpy.types.Object.hhp_physics_shape_preset = EnumProperty(
        name="Physics Feel",
        description="Choose how this HHP physics element balances natural movement and shape preservation",
        items=[
            ('NATURAL', "Natural (Default)", "Reset vertex mass and pressure scale to the saved default values", 'MOD_CLOTH', 0),
            ('NATURAL_PRESERVE_SHAPE', "Natural (Preserve shape)", "Use the saved default vertex mass and set pressure scale to 2000", 'MOD_CLOTH', 1),
            ('FIRM', "Firm", "Use one sixth of the saved default vertex mass and set pressure scale to 2000", 'MOD_CLOTH', 2),
        ],
        default='NATURAL',
        update=hhp_update_physics_shape_preset
    )
    bpy.utils.register_class(HHP_OT_GenerateOptimizedCollision)
    
    bpy.utils.register_class(HHP_UL_LatticeShapekeysList)
    bpy.utils.register_class(HHP_OT_SetLatticeShapekeyValues)
    bpy.utils.register_class(HHP_OT_ToggleLatticeShapekeyMute)
    bpy.utils.register_class(HHP_OT_AddLatticeShapekey)
    bpy.utils.register_class(HHP_OT_CopyLatticeShapekey)
    bpy.utils.register_class(HHP_OT_RemoveLatticeShapekey)
    bpy.utils.register_class(HHP_OT_EditCage)
    bpy.utils.register_class(HHP_OT_FinalizeCageEdit)
    bpy.utils.register_class(OBJECT_OT_ToggleModifierVisibility)
    bpy.utils.register_class(OBJECT_OT_ToggleHHPPhysicsGroupVisibility)
    bpy.utils.register_class(OBJECT_OT_SelectSyncSource)
    bpy.utils.register_class(OBJECT_OT_BindUnbindHHPModifiers)
    bpy.utils.register_class(OBJECT_OT_PtcacheBakeAll)
    bpy.utils.register_class(OBJECT_OT_PtcacheBakeOffline)
    bpy.utils.register_class(OBJECT_OT_PtcacheBakeMenu)
    bpy.utils.register_class(OBJECT_OT_PtcacheFreeBakeAll)
    bpy.utils.register_class(OBJECT_OT_PtcacheBakeCurrent)
    bpy.utils.register_class(OBJECT_OT_PtcacheFreeCurrent)
    bpy.utils.register_class(OBJECT_OT_PtcacheFreeBakedMenu)
    bpy.utils.register_class(OBJECT_OT_PtcacheFreeBakedItem)
    bpy.utils.register_class(OBJECT_OT_PhysicsFramerateMultiplier)
    bpy.utils.register_class(OBJECT_PT_ProxiesVisibilityPanel)
    bpy.utils.register_class(HHP_OT_SubdivCage)
    bpy.utils.register_class(HHP_OT_RestoreCage)
    bpy.utils.register_class(HHP_OT_UnsubdivCage)
    bpy.utils.register_class(HHP_OT_PinQuickSwap)

def unregister():
    if hhp_physics_autobake_frame_post in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(hhp_physics_autobake_frame_post)
    bpy.utils.unregister_class(HHP_OT_RemoveLatticeShapekey)
    bpy.utils.unregister_class(HHP_OT_CopyLatticeShapekey)
    bpy.utils.unregister_class(HHP_OT_AddLatticeShapekey)
    bpy.utils.unregister_class(HHP_OT_ToggleLatticeShapekeyMute)
    bpy.utils.unregister_class(HHP_OT_SetLatticeShapekeyValues)
    bpy.utils.unregister_class(HHP_UL_LatticeShapekeysList)
    bpy.utils.unregister_class(OBJECT_PT_ProxiesVisibilityPanel)
    bpy.utils.unregister_class(OBJECT_OT_PtcacheFreeBakeAll)
    bpy.utils.unregister_class(OBJECT_OT_PtcacheBakeMenu)
    bpy.utils.unregister_class(OBJECT_OT_PtcacheBakeOffline)
    bpy.utils.unregister_class(OBJECT_OT_PtcacheBakeAll)
    bpy.utils.unregister_class(OBJECT_OT_BindUnbindHHPModifiers)
    bpy.utils.unregister_class(OBJECT_OT_SelectSyncSource)
    bpy.utils.unregister_class(OBJECT_OT_ToggleHHPPhysicsGroupVisibility)
    bpy.utils.unregister_class(OBJECT_OT_ToggleModifierVisibility)
    bpy.utils.unregister_class(OBJECT_OT_PtcacheFreeBakedItem)
    bpy.utils.unregister_class(OBJECT_OT_PtcacheFreeBakedMenu)
    bpy.utils.unregister_class(OBJECT_OT_PtcacheFreeCurrent)
    bpy.utils.unregister_class(OBJECT_OT_PtcacheBakeCurrent)
    bpy.utils.unregister_class(HHP_OT_FinalizeCageEdit)
    bpy.utils.unregister_class(HHP_OT_EditCage)
    bpy.utils.unregister_class(OBJECT_OT_PhysicsFramerateMultiplier)
    bpy.utils.unregister_class(HHP_OT_PinQuickSwap)
    bpy.utils.unregister_class(HHP_OT_UnsubdivCage)
    bpy.utils.unregister_class(HHP_OT_RestoreCage)
    bpy.utils.unregister_class(HHP_OT_SubdivCage)
    bpy.utils.unregister_class(HHP_OT_GenerateOptimizedCollision)
    del bpy.types.Scene.hhp_props
    bpy.utils.unregister_class(HHPProperties)
    # Remove the custom property from bpy.types.Collection
    del bpy.types.Collection.show_collection
    # Remove the custom property from bpy.types.Object
    del bpy.types.Object.show_object_viewport
    del bpy.types.Object.hhp_physics_shape_preset

if __name__ == "__main__":
    register()
