import bpy
from bpy.props import BoolProperty

# Define unique getter and setter functions for the collection custom property
def get_show_collection_render(self):
    return not self.hide_viewport and not self.hide_render

def set_show_collection_render(self, value):
    self.hide_viewport = not value
    self.hide_render = not value

class OBJECT_PT_ClothingAccessoriesPanel(bpy.types.Panel):
    """Panel to reflect and toggle visibility of 'Clothes' collections with clickable text."""
    bl_label = "Clothing and Accessories (HHP)"
    bl_idname = "OBJECT_PT_clothing_accessories_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'
    bl_order = 30  # Set the panel order to 30
    bl_options = {'DEFAULT_CLOSED'}  # Panel is closed by default

    def draw(self, context):
        layout = self.layout

        # Clothes collections list
        clothes_collections = self.find_clothes_collections()

        # Use a grid flow for the clothes list
        col = layout.column(align=True)
        flow = col.grid_flow(row_major=True, columns=1, even_columns=False, even_rows=False, align=True)

        for collection, level, parent_hidden, is_top_level in clothes_collections:
            row = flow.row(align=True)
            clean_name = collection.name.split(".")[0]

            # Set the icon
            icon = 'NONE' if is_top_level else 'DOT'

            # Set the active state (greyed out appearance)
            row.active = True if is_top_level else not parent_hidden

            # Display the custom property as a toggle button with clickable text and icon
            row.prop(collection, "show_collection_render", text=clean_name, toggle=True, icon=icon)

    def collect_collections(self, collection, collection_list, parent_hidden=False, is_top_level=False, processed_collections=None):
        if processed_collections is None:
            processed_collections = set()
        if collection in processed_collections:
            return
        processed_collections.add(collection)

        collection_list.append((collection, 0, parent_hidden, is_top_level))

        # Determine if current parent is hidden (consider both viewport and render)
        current_parent_hidden = parent_hidden or collection.hide_viewport or collection.hide_render

        # Process children collections
        for child in collection.children:
            self.collect_collections(
                child,
                collection_list,
                parent_hidden=current_parent_hidden,
                is_top_level=False,
                processed_collections=processed_collections
            )

    def find_clothes_collections(self):
        """Find all 'Clothes' collections inside the parent collections of selected meshes."""
        clothes_collections = []
        processed_collections = set()

        # Collect parent collections of selected meshes
        parent_collections = set()
        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH':
                parent_collections.update(obj.users_collection)

        # Traverse parent collections in order
        for collection in bpy.data.collections:
            if collection in parent_collections:
                for sub_collection in collection.children:
                    if sub_collection.name.startswith("Clothes") and sub_collection not in processed_collections:
                        self.collect_collections(
                            sub_collection,
                            clothes_collections,
                            parent_hidden=False,
                            is_top_level=True,
                            processed_collections=processed_collections
                        )
        return clothes_collections

def register():
    # Add the unique custom property to bpy.types.Collection
    bpy.types.Collection.show_collection_render = BoolProperty(
        name="",
        description="Toggle Collection Visibility (Viewport and Render)",
        get=get_show_collection_render,
        set=set_show_collection_render
    )
    bpy.utils.register_class(OBJECT_PT_ClothingAccessoriesPanel)

def unregister():
    bpy.utils.unregister_class(OBJECT_PT_ClothingAccessoriesPanel)
    # Remove the custom property from bpy.types.Collection
    del bpy.types.Collection.show_collection_render

if __name__ == "__main__":
    register()
