import bpy
from bpy.props import BoolProperty
import json

# Define unique getter and setter functions for the collection custom property
def get_show_collection_render(self):
    return not self.hide_viewport and not self.hide_render

def set_show_collection_render(self, value):
    self.hide_viewport = not value
    self.hide_render = not value

# Define unique getter and setter functions for the object custom property
def get_show_object_render(self):
    return not self.hide_viewport and not self.hide_render

def set_show_object_render(self, value):
    self.hide_viewport = not value
    self.hide_render = not value

# Helper functions for capturing and applying outfit presets
def capture_collection_state(collection):
    state = {
        "hide_viewport": collection.hide_viewport,
        "hide_render": collection.hide_render,
        "objects": {}
    }
    for obj in collection.objects:
        state["objects"][obj.name] = {
            "hide_viewport": obj.hide_viewport,
            "hide_render": obj.hide_render
        }
    child_states = {}
    for child in collection.children:
        child_states[child.name] = capture_collection_state(child)
    if child_states:
        state["child_collections"] = child_states
    return state

def capture_outfit_preset(context):
    active_obj = context.active_object
    presets = {"Clothes": {}, "Appendages": {}}
    if not active_obj:
        return presets
    parent_collections = set(active_obj.users_collection)
    for collection in bpy.data.collections:
        if collection in parent_collections:
            for sub_collection in collection.children:
                if sub_collection.name.startswith("Clothes"):
                    presets["Clothes"][sub_collection.name] = capture_collection_state(sub_collection)
                elif sub_collection.name.startswith("Appendages"):
                    presets["Appendages"][sub_collection.name] = capture_collection_state(sub_collection)
    return presets

def apply_child_collections_state(child_data):
    for coll_name, state in child_data.items():
        coll = bpy.data.collections.get(coll_name)
        if coll:
            coll.hide_viewport = state.get("hide_viewport", coll.hide_viewport)
            coll.hide_render = state.get("hide_render", coll.hide_render)
            for obj in coll.objects:
                obj_state = state.get("objects", {}).get(obj.name)
                if obj_state:
                    obj.hide_viewport = obj_state.get("hide_viewport", obj.hide_viewport)
                    obj.hide_render = obj_state.get("hide_render", obj.hide_render)
            if "child_collections" in state:
                apply_child_collections_state(state["child_collections"])

def apply_outfit_preset(preset_data):
    for category, collections_data in preset_data.items():
        for coll_name, state in collections_data.items():
            coll = bpy.data.collections.get(coll_name)
            if coll:
                coll.hide_viewport = state.get("hide_viewport", coll.hide_viewport)
                coll.hide_render = state.get("hide_render", coll.hide_render)
                for obj in coll.objects:
                    obj_state = state.get("objects", {}).get(obj.name)
                    if obj_state:
                        obj.hide_viewport = obj_state.get("hide_viewport", obj.hide_viewport)
                        obj.hide_render = obj_state.get("hide_render", obj.hide_render)
                if "child_collections" in state:
                    apply_child_collections_state(state["child_collections"])

def update_active_outfit_preset(self, context):
    preset_name = self.active_outfit_preset
    if "outfit_presets" not in self:
        return
    presets = self["outfit_presets"]
    if preset_name not in presets:
        return
    preset_data = presets[preset_name]
    apply_outfit_preset(preset_data)

def outfit_preset_items(self, context):
    obj = context.object
    if not obj or "outfit_presets" not in obj:
        return []
    return [(name, name, "") for name in obj["outfit_presets"].keys()]

# New operator classes for preset management
class OT_AddOutfitPreset(bpy.types.Operator):
    bl_idname = "object.add_outfit_preset"
    bl_label = "Add Outfit Preset"
    bl_description = "Add a new outfit preset"
    
    preset_name: bpy.props.StringProperty(
        name="Preset Name",
        default="New Preset",
        options={'SKIP_SAVE'}  # This prevents remembering the previous input
    )
    
    def invoke(self, context, event):
        self.preset_name = "New Preset"  # Reset to default name each time
        wm = context.window_manager
        return wm.invoke_props_dialog(self)
    
    def execute(self, context):
        active_obj = context.active_object
        if not active_obj:
            self.report({'WARNING'}, "No active object.")
            return {'CANCELLED'}
        preset_data = capture_outfit_preset(context)
        if "outfit_presets" not in active_obj:
            active_obj["outfit_presets"] = {}
        presets = active_obj["outfit_presets"]
        if self.preset_name in presets:
            self.report({'WARNING'}, "Preset with same name exists. Choose a different name.")
            return {'CANCELLED'}
        presets[self.preset_name] = preset_data
        active_obj.active_outfit_preset = self.preset_name
        self.report({'INFO'}, f"Preset '{self.preset_name}' added.")
        return {'FINISHED'}

class OT_RemoveOutfitPreset(bpy.types.Operator):
    bl_idname = "object.remove_outfit_preset"
    bl_label = "Remove Outfit Preset"
    bl_description = "Remove the selected outfit preset"
    
    def execute(self, context):
        active_obj = context.active_object
        if not active_obj:
            self.report({'WARNING'}, "No active object.")
            return {'CANCELLED'}
        if "outfit_presets" not in active_obj:
            self.report({'WARNING'}, "No presets to remove.")
            return {'CANCELLED'}
        presets = active_obj["outfit_presets"]
        preset_name = active_obj.active_outfit_preset
        if preset_name not in presets:
            self.report({'WARNING'}, "Selected preset not found.")
            return {'CANCELLED'}
        del presets[preset_name]
        if presets:
            active_obj.active_outfit_preset = list(presets.keys())[0]
        else:
            active_obj.active_outfit_preset = ""
        self.report({'INFO'}, f"Preset '{preset_name}' removed.")
        return {'FINISHED'}

class OT_RenameOutfitPreset(bpy.types.Operator):
    bl_idname = "object.rename_outfit_preset"
    bl_label = "Rename Outfit Preset"
    bl_description = "Rename the selected outfit preset"

    new_name: bpy.props.StringProperty(name="New Preset Name", default="")
    
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)
    
    def execute(self, context):
        active_obj = context.active_object
        if not active_obj or "outfit_presets" not in active_obj:
            self.report({'WARNING'}, "No active preset to rename.")
            return {'CANCELLED'}
        presets = active_obj["outfit_presets"]
        old_name = active_obj.active_outfit_preset
        if old_name not in presets:
            self.report({'WARNING'}, "No preset found.")
            return {'CANCELLED'}
        if self.new_name in presets:
            self.report({'WARNING'}, "Preset with this new name already exists.")
            return {'CANCELLED'}
        presets[self.new_name] = presets.pop(old_name)
        active_obj.active_outfit_preset = self.new_name
        self.report({'INFO'}, f"Preset renamed from '{old_name}' to '{self.new_name}'.")
        return {'FINISHED'}

class OBJECT_PT_ClothingAccessoriesPanel(bpy.types.Panel):
    """Panel to reflect and toggle visibility of 'Clothes' and 'Appendages' collections with clickable text."""
    bl_label = "Clothing and Accessories (HHP)"
    bl_idname = "OBJECT_PT_clothing_accessories_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'
    bl_order = 30  # Set the panel order to 30
    bl_options = {'DEFAULT_CLOSED'}  # Panel is closed by default

    def draw(self, context):
        layout = self.layout
        active_obj = context.active_object
        if active_obj and active_obj.type == 'MESH':
            # Create a single row for all controls with alignment
            row = layout.row(align=True)
            # Dropdown takes most of the space
            row.prop(active_obj, "active_outfit_preset", text="")
            # Buttons (no separator needed with align=True)
            row.operator("object.add_outfit_preset", text="", icon="ADD")
            row.operator("object.remove_outfit_preset", text="", icon="REMOVE")
            row.operator("object.rename_outfit_preset", text="", icon="GREASEPENCIL")

        # Create a main row with two columns: one for Clothes and one for Appendages
        main_row = layout.row(align=True)
        
        # Left column for Clothes collections
        col_clothes = main_row.column(align=True)
        col_clothes.label(text="Clothes")
        clothes_collections = self.find_clothes_collections()
        for collection, current_hidden, is_top_level, objects in clothes_collections:
            row = col_clothes.row(align=True)
            clean_name = collection.name.split(".")[0]
            icon = 'OUTLINER_COLLECTION'
            row.active = True
            row.prop(collection, "show_collection_render", text=clean_name, toggle=True, icon=icon)
            if not current_hidden and objects:
                box = col_clothes.box()
                box_col = box.column(align=True)
                for obj, obj_hidden in objects:
                    obj_row = box_col.row(align=True)
                    obj_name = obj.name.split(".")[0]
                    obj_icon = 'OBJECT_DATA'
                    obj_row.active = True
                    obj_row.prop(obj, "show_object_render", text=obj_name, toggle=True, icon=obj_icon)

        # Right column for Appendages collections
        col_appendages = main_row.column(align=True)
        col_appendages.label(text="Appendages")
        appendages_collections = self.find_appendages_collections()
        for collection, current_hidden, is_top_level, objects in appendages_collections:
            row = col_appendages.row(align=True)
            clean_name = collection.name.split(".")[0]
            icon = 'OUTLINER_COLLECTION'
            row.active = True
            row.prop(collection, "show_collection_render", text=clean_name, toggle=True, icon=icon)
            if not current_hidden and objects:
                box = col_appendages.box()
                box_col = box.column(align=True)
                for obj, obj_hidden in objects:
                    obj_row = box_col.row(align=True)
                    obj_name = obj.name.split(".")[0]
                    obj_icon = 'OBJECT_DATA'
                    obj_row.active = True
                    obj_row.prop(obj, "show_object_render", text=obj_name, toggle=True, icon=obj_icon)

    def collect_collections(self, collection, collection_list, parent_hidden=False, is_top_level=False, processed_collections=None):
        if processed_collections is None:
            processed_collections = set()
        if collection in processed_collections:
            return
        processed_collections.add(collection)

        # Determine if current collection is hidden (consider both viewport and render)
        current_hidden = parent_hidden or collection.hide_viewport or collection.hide_render

        # Collect objects in the collection if it's not hidden
        objects = []
        if not current_hidden:
            for obj in collection.objects:
                obj_hidden = obj.hide_viewport or obj.hide_render
                objects.append((obj, obj_hidden))

        # Append the collection and its objects
        collection_list.append((collection, current_hidden, is_top_level, objects))

        # Only process child collections if the current collection is not hidden
        if not current_hidden:
            for child in collection.children:
                self.collect_collections(
                    child,
                    collection_list,
                    parent_hidden=current_hidden,
                    is_top_level=False,
                    processed_collections=processed_collections
                )

    def find_clothes_collections(self):
        """Find all 'Clothes' collections inside the parent collections of selected meshes."""
        clothes_collections = []
        processed_collections = set()

        # Collect parent collections of selected meshes
        parent_collections = set()
        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH':
                parent_collections.update(obj.users_collection)

        # Traverse parent collections in order and collect "Clothes" sub-collections
        for collection in bpy.data.collections:
            if collection in parent_collections:
                for sub_collection in collection.children:
                    if sub_collection.name.startswith("Clothes") and sub_collection not in processed_collections:
                        self.collect_collections(
                            sub_collection,
                            clothes_collections,
                            parent_hidden=False,
                            is_top_level=True,
                            processed_collections=processed_collections
                        )
        return clothes_collections

    def find_appendages_collections(self):
        """Find all 'Appendages' collections inside the parent collections of selected meshes."""
        appendages_collections = []
        processed_collections = set()

        # Collect parent collections of selected meshes
        parent_collections = set()
        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH':
                parent_collections.update(obj.users_collection)

        # Traverse parent collections in order and collect "Appendages" sub-collections
        for collection in bpy.data.collections:
            if collection in parent_collections:
                for sub_collection in collection.children:
                    if sub_collection.name.startswith("Appendages") and sub_collection not in processed_collections:
                        self.collect_collections(
                            sub_collection,
                            appendages_collections,
                            parent_hidden=False,
                            is_top_level=True,
                            processed_collections=processed_collections
                        )
        return appendages_collections

def register():
    # Add the unique custom property to bpy.types.Collection
    bpy.types.Collection.show_collection_render = BoolProperty(
        name="",
        description="Toggle Collection Visibility (Viewport and Render)",
        get=get_show_collection_render,
        set=set_show_collection_render
    )
    # Add the unique custom property to bpy.types.Object
    bpy.types.Object.show_object_render = BoolProperty(
        name="",
        description="Toggle Object Visibility (Viewport and Render)",
        get=get_show_object_render,
        set=set_show_object_render
    )
    bpy.utils.register_class(OBJECT_PT_ClothingAccessoriesPanel)
    bpy.utils.register_class(OT_AddOutfitPreset)
    bpy.utils.register_class(OT_RemoveOutfitPreset)
    bpy.utils.register_class(OT_RenameOutfitPreset)

    bpy.types.Object.active_outfit_preset = bpy.props.EnumProperty(
        name="Preset",
        description="Select an outfit preset",
        items=outfit_preset_items,
        update=update_active_outfit_preset
    )

def unregister():
    bpy.utils.unregister_class(OBJECT_PT_ClothingAccessoriesPanel)
    bpy.utils.unregister_class(OT_AddOutfitPreset)
    bpy.utils.unregister_class(OT_RemoveOutfitPreset)
    bpy.utils.unregister_class(OT_RenameOutfitPreset)
    # Remove the custom properties
    del bpy.types.Collection.show_collection_render
    del bpy.types.Object.show_object_render
    del bpy.types.Object.active_outfit_preset

if __name__ == "__main__":
    register()
