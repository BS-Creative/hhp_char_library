import bpy

class CustomizePanel(bpy.types.Panel):
    bl_label = "Customize (HHP)"
    bl_idname = "CHAR_PT_Customize_HHP"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Char (HHP)"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 20  # Position in the panel stack

    def draw(self, context):
        layout = self.layout
        obj = context.object

        # Check if an object is selected
        if obj is None:
            layout.label(text="No object selected")
            return

        # Define property groups as per your mapping
        initial_setup_props = [
            'Abs', 'Base Color (Switch)', 'Detail Bump', 'Detail Bump - Face',
            'Hue', 'Max Roughness', 'Normal (Switch)', 'Normal Contrast (Body)',
            'Normal Contrast (Clavicle)', 'Normal Contrast (Face)', 'Saturation',
            'Subsurface', 'Value'
        ]

        deformation_correction_props = [
            'Correct Eyelids', 'Displace Clothing', 'Eye socket push back'
        ]

        effects_shaders_props = [
            'Feet Dirt', 'Gens used', 'Goosebumps', 'Hand Veins', 'Piercing Bumps',
            'Tan Lines', 'Throat Bulge (Color)', 'Throat Bulge (Neck Bump)',
            'Throat Bulge (SK Deform)', 'Throat Bulge (Veins Bump)', 'Vascularity',
            'Wetness', 'Wetness (Switch)'
        ]

        # Sliders to be placed at the top of the Initial Setup box
        special_initial_setup_props = [
            'Hue', 'Saturation', 'Value', 'Base Color (Switch)', 'Normal (Switch)'
        ]

        # Remove special props from initial_setup_props to avoid duplication
        remaining_initial_setup_props = [
            prop for prop in initial_setup_props if prop not in special_initial_setup_props
        ]

        # Function to draw properties in columns
        def draw_props(obj, props_list, box):
            existing_props = [prop for prop in props_list if prop in obj]
            if not existing_props:
                return  # Don't display the group if none of the properties are present
            col = box.column(align=True)
            rows = (len(existing_props) + 1) // 2
            for i in range(rows):
                row = col.row(align=True)
                props_in_row = []
                for j in range(2):
                    index = i * 2 + j
                    if index < len(existing_props):
                        prop = existing_props[index]
                        props_in_row.append(prop)
                if len(props_in_row) == 1:
                    # Make the single slider fill the entire row
                    row.prop(obj, f'["{props_in_row[0]}"]', text=props_in_row[0])
                else:
                    for prop in props_in_row:
                        row.prop(obj, f'["{prop}"]', text=prop)

        # Function to draw shape keys in columns
        def draw_shape_keys(obj, shape_keys_list, box):
            key_blocks = obj.data.shape_keys.key_blocks
            existing_keys = [key for key in shape_keys_list if key in key_blocks]
            if not existing_keys:
                return
            col = box.column(align=True)
            rows = (len(existing_keys) + 1) // 2
            for i in range(rows):
                row = col.row(align=True)
                keys_in_row = []
                for j in range(2):
                    index = i * 2 + j
                    if index < len(existing_keys):
                        key_name = existing_keys[index]
                        keys_in_row.append(key_name)
                if len(keys_in_row) == 1:
                    # Make the single slider fill the entire row
                    row.prop(key_blocks[keys_in_row[0]], 'value', text=keys_in_row[0])
                else:
                    for key_name in keys_in_row:
                        row.prop(key_blocks[key_name], 'value', text=key_name)

        # Keep track of displayed properties
        displayed_props = set()

        # Initial Setup Section
        initial_box = layout.box()
        initial_box.label(text="Initial Setup", icon="PREFERENCES")

        # Draw special initial setup props at the top, separated by a line
        special_existing_props = [prop for prop in special_initial_setup_props if prop in obj]
        if special_existing_props:
            special_col = initial_box.column(align=True)
            rows = (len(special_existing_props) + 1) // 2
            for i in range(rows):
                row = special_col.row(align=True)
                props_in_row = []
                for j in range(2):
                    index = i * 2 + j
                    if index < len(special_existing_props):
                        prop = special_existing_props[index]
                        props_in_row.append(prop)
                        displayed_props.add(prop)
                if len(props_in_row) == 1:
                    # Make the single slider fill the entire row
                    row.prop(obj, f'["{props_in_row[0]}"]', text=props_in_row[0])
                else:
                    for prop in props_in_row:
                        row.prop(obj, f'["{prop}"]', text=prop)
                        displayed_props.add(prop)
            # Add a separator line
            initial_box.separator()

        # Draw the remaining initial setup props
        draw_props(obj, remaining_initial_setup_props, initial_box)
        displayed_props.update([prop for prop in remaining_initial_setup_props if prop in obj])

        # Deformation & Correction Section
        deform_box = layout.box()
        deform_box.label(text="Deformation & Correction", icon="MODIFIER")
        draw_props(obj, deformation_correction_props, deform_box)
        displayed_props.update([prop for prop in deformation_correction_props if prop in obj])

        # Add a separator and label for shapekey morphs
        deform_box.separator()
        deform_box.label(text="Shapekey Morphs", icon="SHAPEKEY_DATA")

        # Collect and draw the specified shape keys
        if obj.data and obj.data.shape_keys and obj.data.shape_keys.key_blocks:
            key_blocks = obj.data.shape_keys.key_blocks
            # Collect shape keys matching names or starting with 'Torso -'
            shape_key_names = [
                'Heels & Boots bend',
                'Elin female bend',
                'Heels (Squished feet)',
                'Thicken lids',
                'Thicken Lips',
                'Nipples hide',
                'Nipples pinch base',
            ]
            shape_keys_to_draw = []
            for key_name in key_blocks.keys():
                if key_name in shape_key_names or key_name.startswith('Torso -'):
                    shape_keys_to_draw.append(key_name)
            if shape_keys_to_draw:
                # Draw the shape keys
                draw_shape_keys(obj, shape_keys_to_draw, deform_box)

        # Add separator and label with boolean property for extra morphs
        deform_box.separator()
        row = deform_box.row(align=True)
        row.label(text="Extra Morphs (Advanced)", icon="SHAPEKEY_DATA")  # Changed icon here
        row.prop(context.window_manager, "show_extra_morphs", text="Show Extra Morphs")

        # If the boolean is True, draw the extra shape keys
        if context.window_manager.show_extra_morphs:
            extra_shape_key_names = [
                'Long nails',
                'Sexy Short Nails',
                'Extra Long Nails',
                'Extra sharp long nails',
                'real feet 1',
                'real feet 2',
                'real feet 3',
                'real feet 4',
                'real feet 5',
                'real feet 6',
                'Hitomi feet',
                'Tekken Feet & Legs',
                'real toes 5',
                'custom feet 1',
                'Necdaz_feet',
                'Feet fatness',
                'Feet (Real Ndaz)',
                'Feet fatness - Cassie',
                'feet preset - Haruka / Young',
                'Genesis8Female__PBMNailsLength',
                'Genesis8Female__PBMChameleonROse_2_Tnails',
                'Genesis8Female__PBMChameleonROse_2_Fnails2',
                'Genesis8Female__PBMChameleonROse_2_Fnails'
            ]
            # Collect and draw the extra shape keys in the given order
            if obj.data.shape_keys:
                key_blocks = obj.data.shape_keys.key_blocks
                existing_extra_keys = [key_name for key_name in extra_shape_key_names if key_name in key_blocks]
                if existing_extra_keys:
                    draw_shape_keys(obj, existing_extra_keys, deform_box)

        # Effects & Shaders Section
        effects_box = layout.box()
        effects_box.label(text="Effects & Shaders", icon="SHADING_RENDERED")
        draw_props(obj, effects_shaders_props, effects_box)
        displayed_props.update([prop for prop in effects_shaders_props if prop in obj])

        # Add separator and label for Makeup
        effects_box.separator()
        effects_box.label(text="Makeup", icon="SHADING_RENDERED")

        # Draw the Makeup node group properties
        def draw_node_group_inputs(obj, node_group_name_keyword, exclude_sockets, layout):
            node_group_node = None
            for slot in obj.material_slots:
                material = slot.material
                if material and material.use_nodes:
                    nodes = material.node_tree.nodes
                    for node in nodes:
                        if node.type == 'GROUP' and node.node_tree and node_group_name_keyword in node.node_tree.name:
                            node_group_node = node
                            break
                    if node_group_node:
                        break  # Found the node group, no need to search further
            if not node_group_node:
                layout.label(text="No node group containing '{}' found.".format(node_group_name_keyword))
                return

            # Now, for each input socket of the node group
            inputs = node_group_node.inputs
            existing_sockets = [socket for socket in inputs if socket.name not in exclude_sockets]
            if not existing_sockets:
                layout.label(text="No inputs to display.")
                return

            # Prepare the ordered_sockets list
            ordered_sockets = []
            current_row = []
            for socket in existing_sockets:
                # Determine if the socket is a color picker
                is_color_socket = socket.type == 'RGBA'

                if is_color_socket:
                    if current_row:
                        ordered_sockets.append(current_row)
                        current_row = []
                    ordered_sockets.append([socket])  # Color socket occupies its own row
                else:
                    current_row.append(socket)
                    if len(current_row) == 2:
                        ordered_sockets.append(current_row)
                        current_row = []
            if current_row:
                ordered_sockets.append(current_row)

            # Now, draw the sockets
            col = layout.column(align=True)
            for sockets_in_row in ordered_sockets:
                row = col.row(align=True)
                if len(sockets_in_row) == 1:
                    socket = sockets_in_row[0]
                    if socket.is_linked:
                        linked_node = socket.links[0].from_node
                        if hasattr(linked_node.outputs[0], 'default_value'):
                            row.prop(linked_node.outputs[0], 'default_value', text=socket.name)
                        else:
                            row.label(text="Unsupported node type: {}".format(linked_node.type))
                    else:
                        row.prop(socket, 'default_value', text=socket.name)
                else:
                    for socket in sockets_in_row:
                        if socket.is_linked:
                            linked_node = socket.links[0].from_node
                            if hasattr(linked_node.outputs[0], 'default_value'):
                                row.prop(linked_node.outputs[0], 'default_value', text=socket.name)
                            else:
                                row.label(text="Unsupported node type: {}".format(linked_node.type))
                        else:
                            row.prop(socket, 'default_value', text=socket.name)

        # Call the function
        draw_node_group_inputs(obj, "Makeup_HHP", ["Base Color", "Roughness"], effects_box)

        # Collect any remaining custom properties for 'Misc' section
        all_custom_props = set(obj.keys())

        # Exclude built-in properties
        built_in_props = set(prop.identifier for prop in obj.bl_rna.properties)

        # Calculate misc_props
        misc_props = all_custom_props - displayed_props - built_in_props

        # Exclude properties starting with '_'
        misc_props = [prop for prop in misc_props if not prop.startswith('_')]

        # Draw Misc Section if there are any properties
        if misc_props:
            misc_box = layout.box()
            misc_box.label(text="Misc", icon="DOT")
            draw_props(obj, sorted(misc_props), misc_box)

def register():
    bpy.utils.register_class(CustomizePanel)
    bpy.types.WindowManager.show_extra_morphs = bpy.props.BoolProperty(
        name="Show Extra Morphs", default=False)

def unregister():
    bpy.utils.unregister_class(CustomizePanel)
    del bpy.types.WindowManager.show_extra_morphs

if __name__ == "__main__":
    register()
