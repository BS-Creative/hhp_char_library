import bpy
from bpy.props import BoolProperty, EnumProperty
from bpy.types import UIList, Operator
from .Optimize_HHP import is_material_linked_by_object, is_heavy_collections_hidden

def get_default_shapekey_legacy_view():
    """Get the default shapekey view mode from scene or addon preferences"""
    # First try to get from scene (persists with blend file)
    scene = bpy.context.scene
    if hasattr(scene, 'shapekey_legacy_view'):
        return scene.shapekey_legacy_view
    
    # Fallback to addon preferences for new files
    try:
        prefs = bpy.context.preferences.addons[__package__].preferences
        # Invert the logic since preference tracks "use new view" but we need "use legacy view"
        default_value = not prefs.default_shapekey_view_new
        # Set it in scene for persistence
        scene.shapekey_legacy_view = default_value
        return default_value
    except:
        # Final fallback to True (legacy view) if preferences can't be accessed
        return True

# -------------------------------------------------------------------
# Shapekey Lists and Categories
# -------------------------------------------------------------------

# Define shapekey category hierarchy
SHAPEKEY_MAJOR_CATEGORIES = {
    'HOT_LIST': {
        'name': "Hot List",
        'icon': 'BOOKMARKS',
        'description': "Quick access to frequently used shapekeys",
        'subcategories': []
    },
    'FIX': {
        'name': "Fix",
        'icon': 'TOOL_SETTINGS',
        'description': "Corrective shapekeys for fixing mesh deformation issues and geometry problems",
        'subcategories': ['FIX']
    },
    'EMOTE': {
        'name': "Emote", 
        'icon': 'USER',
        'description': "Facial expressions, emotions, and utility shapekeys for character animation",
        'subcategories': ['EXPRESSION', 'UTILITY']
    },
    'ALL': {
        'name': "All",
        'icon': 'FILE_VOLUME',
        'description': "Complete list of all shapekeys available on the current mesh",
        'subcategories': []
    },
    'CUSTOMIZE': {
        'name': "Customize",
        'icon': 'BRUSHES_ALL', 
        'description': "Body shape customization and character variation shapekeys",
        'subcategories': ['PRESET', 'HEAD', 'TORSO', 'ARM', 'HAND', 'LEG', 'FEET', 'GENITALS', 'PROPORTION']
    }
}

SHAPEKEY_PREFIXES = {
    'EXPRESSION': "Expression - ",
    'PRESET': "Preset - ",
    'HEAD': "Head - ",
    'TORSO': "Torso - ",
    'ARM': "Arm - ",
    'HAND': "Hand - ",
    'LEG': "Leg - ",
    'FEET': "Feet - ",
    'GENITALS': "Genitals - ",
    'PROPORTION': "Proportion - ",
    'UTILITY': "Utility - ",
    'FIX': "Fix - "
}

SUBCATEGORY_INFO = {
    'EXPRESSION': {'name': "Expression", 'description': "Facial expressions and emotional states"},
    'UTILITY': {'name': "Utility", 'description': "Utility and helper shapekeys for various purposes"},
    'PRESET': {'name': "Preset", 'description': "Pre-configured body shape presets and combinations"},
    'HEAD': {'name': "Head", 'description': "Head shape modifications and facial features"},
    'TORSO': {'name': "Torso", 'description': "Body torso and chest area shape modifications"},
    'ARM': {'name': "Arm", 'description': "Arm shape and muscle definition adjustments"},
    'HAND': {'name': "Hand", 'description': "Hand shape and finger modifications"},
    'LEG': {'name': "Leg", 'description': "Leg shape and muscle definition adjustments"},
    'FEET': {'name': "Feet", 'description': "Foot shape and toe modifications"},
    'GENITALS': {'name': "Genitals", 'description': "Genital area shape modifications"},
    'PROPORTION': {'name': "Proportion", 'description': "Overall body proportions and scaling adjustments"},
    'FIX': {'name': "Fix", 'description': "Corrective shapekeys for mesh deformation fixes"}
}

def get_shapekeys_by_prefix(shape_keys, prefix):
    """Get all shapekeys that start with the given prefix (supports both '-' and '|' separators)"""
    # Create both versions of the prefix (with '-' and '|')
    prefix_dash = prefix
    prefix_pipe = prefix.replace(' - ', ' | ')
    
    return [sk.name for sk in shape_keys if sk.name.startswith(prefix_dash) or sk.name.startswith(prefix_pipe)]

def get_hot_list_shapekeys(shape_keys):
    """Get shapekeys for the Hot List category"""
    hot_list_keys = []
    
    # Specific named shapekeys to include
    specific_keys = [
        "Feet - Heels & Boots Bend",
        "Feet - Elin Female Bend", 
        "Feet - Heels (Squished)",
        "Fix - Fit feet",
        "Fix - Thicken Lips",
        "Fix - Thicken Lids",
        "Fix - Upper teeth adjust",
        "Fix - Lower teeth adjust",
        "Fix - Nipples Hide",
        "Fix - Breast Hide",
        "Torso | Chest - Nipples Pinch Base"
    ]
    
    for sk in shape_keys:
        sk_name = sk.name
        
        # Check for prefix-based includes (case insensitive)
        if (sk_name.lower().startswith("head preset -") or 
            sk_name.lower().startswith("mouth preset -") or
            sk_name.startswith("Char -")):
            hot_list_keys.append(sk_name)
        # Check for specific named shapekeys
        elif sk_name in specific_keys:
            hot_list_keys.append(sk_name)
    
    return hot_list_keys

def get_shapekeys_by_category(shape_keys, category):
    """Get shapekeys for a specific category"""
    if category == 'ALL':
        # Return all shapekeys (not just categorized ones)
        return [sk.name for sk in shape_keys]
    elif category == 'HOT_LIST':
        return get_hot_list_shapekeys(shape_keys)
    elif category in SHAPEKEY_PREFIXES:
        return get_shapekeys_by_prefix(shape_keys, SHAPEKEY_PREFIXES[category])
    else:
        return []

def get_shapekeys_by_major_category(shape_keys, major_category):
    """Get all shapekeys for a major category"""
    if major_category not in SHAPEKEY_MAJOR_CATEGORIES:
        return []
    
    all_keys = []
    subcategories = SHAPEKEY_MAJOR_CATEGORIES[major_category]['subcategories']
    for subcat in subcategories:
        if subcat in SHAPEKEY_PREFIXES:
            all_keys.extend(get_shapekeys_by_prefix(shape_keys, SHAPEKEY_PREFIXES[subcat]))
    return all_keys

def get_all_categorized_shapekeys(shape_keys):
    """Get all shapekeys that belong to any category (Hot List + all prefixed categories)"""
    categorized_keys = set()
    
    # Add Hot List shapekeys
    categorized_keys.update(get_hot_list_shapekeys(shape_keys))
    
    # Add all prefix-based shapekeys
    for prefix in SHAPEKEY_PREFIXES.values():
        categorized_keys.update(get_shapekeys_by_prefix(shape_keys, prefix))
    
    return list(categorized_keys)

class HHP_UL_CustomShapekeysList(UIList):
    """UIList for custom shapekeys similar to FACS implementation"""
    
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # Split layout to give more space to name (changed from 0.5 to 0.6)
            split = layout.split(factor=0.6)
            
            # Left side - shape key name (editable with full name)
            row = split.row()
            row.prop(item, "name", text="", emboss=False, icon='SHAPEKEY_DATA')
            
            # Right side - value and mute (hidden for Basis shapekey)
            if index > 0:  # Only show controls for non-Basis shapekeys
                row = split.row(align=True)
                row.alignment = 'RIGHT'
                
                # Value slider
                slider_row = row.row(align=True)
                slider_row.enabled = True
                
                if item.mute:
                    slider_row.active = False
                else:
                    slider_row.active = True
                
                slider_row.ui_units_x = 4
                slider_row.prop(item, "value", text="", emboss=False, slider=True)
                
                # Mute checkbox
                row.prop(item, "mute", text="", emboss=False, toggle=True)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='SHAPEKEY_DATA')
    
    def filter_items(self, context, data, propname):
        """Filter items based on current category"""
        shape_keys = getattr(data, propname)
        flags = [0] * len(shape_keys)
        
        # Get current filter categories from window manager
        wm = context.window_manager
        major_category = getattr(wm, 'shapekey_major_category', 'HOT_LIST')
        subcategory = getattr(wm, 'shapekey_subcategory', 'HOT_LIST')
        
        if major_category == 'ALL':
            # Show all shapekeys for "All" category
            for i, key in enumerate(shape_keys):
                flags[i] = self.bitflag_filter_item
        elif major_category == 'HOT_LIST':
            # Show Hot List shapekeys
            target_keys = get_hot_list_shapekeys(shape_keys)
            for i, key in enumerate(shape_keys):
                if key.name in target_keys:
                    flags[i] = self.bitflag_filter_item
        else:
            # Get target keys based on subcategory
            target_keys = get_shapekeys_by_category(shape_keys, subcategory)
            
            # Filter by category
            for i, key in enumerate(shape_keys):
                if key.name in target_keys:
                    flags[i] = self.bitflag_filter_item
        
        # Handle search within visible keys
        if self.filter_name:
            for i, key in enumerate(shape_keys):
                if flags[i]:
                    if self.filter_name.lower() not in key.name.lower():
                        flags[i] = 0
        
        return flags, []

class HHP_OT_SetCustomShapekeyValues(Operator):
    """Set values for custom shapekeys"""
    bl_idname = "hhp.set_custom_shapekey_values"
    bl_label = "Set Shapekey Values"
    bl_description = "Set all visible shapekeys to the specified value"
    bl_options = {'REGISTER', 'UNDO'}
    
    value: bpy.props.FloatProperty(
        name="Value",
        description="Value to set for all visible shapekeys",
        default=0.0,
        min=0.0,
        soft_max=1.0,
        max=10.0,
        precision=3
    )
    keyframe: bpy.props.BoolProperty(
        name="Keyframe Values",
        description="If enabled, keyframe the shapekeys when setting values",
        default=False
    )
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.prop(self, "value", slider=True)
        row.prop(self, "keyframe", text="", icon='KEYINGSET')
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        wm = context.window_manager
        major_category = getattr(wm, 'shapekey_major_category', 'HOT_LIST')
        subcategory = getattr(wm, 'shapekey_subcategory', 'HOT_LIST')
        current_frame = context.scene.frame_current
        
        if major_category == 'ALL':
            # Set values for all shapekeys
            for sk in obj.data.shape_keys.key_blocks:
                sk.value = self.value
                if self.keyframe:
                    sk.keyframe_insert("value", frame=current_frame)
        elif major_category == 'HOT_LIST':
            # Set values for Hot List shapekeys
            target_keys = get_hot_list_shapekeys(obj.data.shape_keys.key_blocks)
            for sk in obj.data.shape_keys.key_blocks:
                if sk.name in target_keys:
                    sk.value = self.value
                    if self.keyframe:
                        sk.keyframe_insert("value", frame=current_frame)
        else:
            # Get target keys based on subcategory
            target_keys = get_shapekeys_by_category(obj.data.shape_keys.key_blocks, subcategory)
            
            # Set values for target shapekeys
            for sk in obj.data.shape_keys.key_blocks:
                if sk.name in target_keys:
                    sk.value = self.value
                    if self.keyframe:
                        sk.keyframe_insert("value", frame=current_frame)
        
        return {'FINISHED'}

class HHP_OT_ToggleCustomShapekeyMute(Operator):
    """Toggle mute state for custom shapekeys"""
    bl_idname = "hhp.toggle_custom_shapekey_mute"
    bl_label = "Toggle Shapekey Mute"
    bl_description = "Toggle mute state for all visible shapekeys"
    bl_options = {'REGISTER', 'UNDO'}
    
    mute_state: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.data.shape_keys
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        wm = context.window_manager
        major_category = getattr(wm, 'shapekey_major_category', 'HOT_LIST')
        subcategory = getattr(wm, 'shapekey_subcategory', 'HOT_LIST')
        
        if major_category == 'ALL':
            # Apply mute state to all shapekeys
            for sk in obj.data.shape_keys.key_blocks:
                sk.mute = self.mute_state
        elif major_category == 'HOT_LIST':
            # Apply mute state to Hot List shapekeys
            target_keys = get_hot_list_shapekeys(obj.data.shape_keys.key_blocks)
            for sk in obj.data.shape_keys.key_blocks:
                if sk.name in target_keys:
                    sk.mute = self.mute_state
        else:
            # Get target keys based on subcategory
            target_keys = get_shapekeys_by_category(obj.data.shape_keys.key_blocks, subcategory)
            
            # Apply mute state to target shapekeys
            for sk in obj.data.shape_keys.key_blocks:
                if sk.name in target_keys:
                    sk.mute = self.mute_state
        
        return {'FINISHED'}

class HHP_OT_AddMeshShapekey(bpy.types.Operator):
    """Add a new mesh shapekey"""
    bl_idname = "hhp.add_mesh_shapekey"
    bl_label = "Add Mesh Shapekey"
    bl_description = "Add a new shapekey to the mesh"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Active object is not a mesh")
            return {'CANCELLED'}
        
        # If no shape keys exist, create "Basis" as the first one
        if not obj.data.shape_keys:
            new_key = obj.shape_key_add(name="Basis", from_mix=False)
            new_key.value = 1.0  # Set value to 1.00
            obj.active_shape_key_index = 0
            self.report({'INFO'}, "Added shapekey 'Basis' with value 1.0")
            return {'FINISHED'}
        
        # Find the next key number based on stack position (ignoring Basis)
        existing_keys = obj.data.shape_keys.key_blocks
        non_basis_count = len(existing_keys) - 1  # Subtract 1 for Basis
        next_number = non_basis_count + 1
        
        # Create new shapekey
        new_key_name = f"Key {next_number}"
        new_key = obj.shape_key_add(name=new_key_name, from_mix=False)
        new_key.value = 1.0  # Set value to 1.00
        
        # Set as active
        for i, sk in enumerate(obj.data.shape_keys.key_blocks):
            if sk.name == new_key_name:
                obj.active_shape_key_index = i
                break
        
        self.report({'INFO'}, f"Added shapekey '{new_key_name}' with value 1.0")
        return {'FINISHED'}

class HHP_OT_CopyMeshShapekey(bpy.types.Operator):
    """Copy the active mesh shapekey"""
    bl_idname = "hhp.copy_mesh_shapekey"
    bl_label = "Copy Mesh Shapekey"
    bl_description = "Copy the active shapekey"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH' and obj.data.shape_keys and 
                obj.active_shape_key and obj.active_shape_key_index > 0)
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        if not obj.active_shape_key or obj.active_shape_key_index <= 0:
            self.report({'ERROR'}, "No valid shapekey selected (cannot copy Basis)")
            return {'CANCELLED'}
        
        active_key = obj.active_shape_key
        
        # Get base name without existing enumeration
        base_name = active_key.name
        # Remove existing .001, .002, etc. enumeration if present
        import re
        base_name = re.sub(r'\.\d{3}$', '', base_name)
        
        # Find next available enumeration number
        counter = 1
        copy_name = f"{base_name}.{counter:03d}"
        while copy_name in [sk.name for sk in obj.data.shape_keys.key_blocks]:
            counter += 1
            copy_name = f"{base_name}.{counter:03d}"
        
        # Create new shapekey from the active one
        new_key = obj.shape_key_add(name=copy_name, from_mix=False)
        new_key.value = active_key.value
        new_key.slider_min = active_key.slider_min
        new_key.slider_max = active_key.slider_max
        new_key.mute = active_key.mute
        
        # Copy the shape data
        for i, point in enumerate(active_key.data):
            new_key.data[i].co = point.co.copy()
        
        # Set as active
        for i, sk in enumerate(obj.data.shape_keys.key_blocks):
            if sk.name == copy_name:
                obj.active_shape_key_index = i
                break
        
        self.report({'INFO'}, f"Copied shapekey as '{copy_name}'")
        return {'FINISHED'}

class HHP_OT_RemoveMeshShapekey(bpy.types.Operator):
    """Remove the active mesh shapekey"""
    bl_idname = "hhp.remove_mesh_shapekey"
    bl_label = "Remove Mesh Shapekey"
    bl_description = "Remove the active shapekey (including Basis)"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH' and obj.data.shape_keys and 
                obj.active_shape_key)
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        if not obj.active_shape_key:
            self.report({'ERROR'}, "No shapekey selected")
            return {'CANCELLED'}
        
        active_key = obj.active_shape_key
        key_name = active_key.name
        
        # Remove the shapekey
        obj.shape_key_remove(active_key)
        
        self.report({'INFO'}, f"Removed shapekey '{key_name}'")
        return {'FINISHED'}

class HHP_MT_AssignShapekeyCategory(bpy.types.Menu):
    """Menu for assigning shapekey categories"""
    bl_label = "Assign to Category"
    bl_idname = "HHP_MT_AssignShapekeyCategory"
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH' and obj.data.shape_keys and 
                obj.active_shape_key and obj.active_shape_key_index > 0)
    
    def draw(self, context):
        layout = self.layout
        
        # Add Hotlist option first
        op = layout.operator("hhp.assign_mesh_shapekey_category", text="Hotlist")
        op.category = 'HOTLIST'
        
        layout.separator()
        
        # Add all other categories
        op = layout.operator("hhp.assign_mesh_shapekey_category", text="Fix")
        op.category = 'FIX'
        
        op = layout.operator("hhp.assign_mesh_shapekey_category", text="Expression")
        op.category = 'EXPRESSION'
        
        op = layout.operator("hhp.assign_mesh_shapekey_category", text="Utility")
        op.category = 'UTILITY'
        
        op = layout.operator("hhp.assign_mesh_shapekey_category", text="Preset")
        op.category = 'PRESET'
        
        op = layout.operator("hhp.assign_mesh_shapekey_category", text="Head")
        op.category = 'HEAD'
        
        op = layout.operator("hhp.assign_mesh_shapekey_category", text="Torso")
        op.category = 'TORSO'
        
        op = layout.operator("hhp.assign_mesh_shapekey_category", text="Arm")
        op.category = 'ARM'
        
        op = layout.operator("hhp.assign_mesh_shapekey_category", text="Hand")
        op.category = 'HAND'
        
        op = layout.operator("hhp.assign_mesh_shapekey_category", text="Leg")
        op.category = 'LEG'
        
        op = layout.operator("hhp.assign_mesh_shapekey_category", text="Feet")
        op.category = 'FEET'
        
        op = layout.operator("hhp.assign_mesh_shapekey_category", text="Genitals")
        op.category = 'GENITALS'
        
        op = layout.operator("hhp.assign_mesh_shapekey_category", text="Proportion")
        op.category = 'PROPORTION'

class HHP_OT_AssignMeshShapekeyCategory(bpy.types.Operator):
    """Assign the active mesh shapekey to a category"""
    bl_idname = "hhp.assign_mesh_shapekey_category"
    bl_label = "Assign to Category"
    bl_description = "Assign the selected shapekey to a category (adds category prefix)"
    bl_options = {'REGISTER', 'UNDO'}
    
    category: bpy.props.StringProperty()
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH' and obj.data.shape_keys and 
                obj.active_shape_key and obj.active_shape_key_index > 0)
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.data.shape_keys:
            self.report({'ERROR'}, "Active object has no shape keys")
            return {'CANCELLED'}
        
        if not obj.active_shape_key or obj.active_shape_key_index <= 0:
            self.report({'ERROR'}, "No valid shapekey selected (cannot assign category to Basis)")
            return {'CANCELLED'}
        
        active_key = obj.active_shape_key
        old_name = active_key.name
        
        # Get the category prefix (add Hotlist support)
        if self.category == 'HOTLIST':
            prefix = "Char - "
        else:
            prefix = SHAPEKEY_PREFIXES.get(self.category, "")
        
        # Remove any existing category prefix first (including Char -)
        clean_name = old_name
        all_prefixes = list(SHAPEKEY_PREFIXES.values()) + ["Char - "]
        for cat_prefix in all_prefixes:
            if clean_name.startswith(cat_prefix):
                clean_name = clean_name[len(cat_prefix):]
                break
        
        # Apply new category prefix
        new_name = f"{prefix}{clean_name}"
        
        # Check if name already exists
        counter = 1
        original_new_name = new_name
        while new_name in [sk.name for sk in obj.data.shape_keys.key_blocks if sk != active_key]:
            new_name = f"{original_new_name}.{counter:03d}"
            counter += 1
        
        # Rename the shapekey
        active_key.name = new_name
        
        self.report({'INFO'}, f"Renamed '{old_name}' to '{new_name}'")
        return {'FINISHED'}

class HHP_OT_SetShapekeyMajorCategory(Operator):
    """Set the major shapekey category"""
    bl_idname = "hhp.set_shapekey_major_category"
    bl_label = "Set Major Category"
    bl_description = "Set the major shapekey category"
    
    category: bpy.props.StringProperty()
    
    @classmethod
    def description(cls, context, properties):
        # Show dynamic description based on category
        if properties.category in SHAPEKEY_MAJOR_CATEGORIES:
            return SHAPEKEY_MAJOR_CATEGORIES[properties.category]['description']
        return "Set the major shapekey category"
    
    def execute(self, context):
        wm = context.window_manager
        wm.shapekey_major_category = self.category
        
        # Set default subcategory for the major category
        if self.category in SHAPEKEY_MAJOR_CATEGORIES:
            subcategories = SHAPEKEY_MAJOR_CATEGORIES[self.category]['subcategories']
            if subcategories:
                wm.shapekey_subcategory = subcategories[0]
            elif self.category in ['ALL', 'HOT_LIST']:
                # "All" and "Hot List" categories have no subcategories
                wm.shapekey_subcategory = self.category
        
        return {'FINISHED'}

class HHP_OT_SetShapekeySubcategory(Operator):
    """Set the shapekey subcategory"""
    bl_idname = "hhp.set_shapekey_subcategory"
    bl_label = "Set Subcategory"
    bl_description = "Set the shapekey subcategory"
    
    subcategory: bpy.props.StringProperty()
    
    @classmethod
    def description(cls, context, properties):
        # Show dynamic description based on subcategory
        if properties.subcategory in SUBCATEGORY_INFO:
            return SUBCATEGORY_INFO[properties.subcategory]['description']
        return "Set the shapekey subcategory"
    
    def execute(self, context):
        wm = context.window_manager
        wm.shapekey_subcategory = self.subcategory
        return {'FINISHED'}

class HHP_OT_ToggleLegacyShapekeyView(Operator):
    """Toggle between new categorized view and legacy 2-column view"""
    bl_idname = "hhp.toggle_legacy_shapekey_view"
    bl_label = "Switch to Legacy View (Deprecated)"
    bl_description = "Toggle between new categorized shapekey system and original 2-column layout"
    bl_options = {'REGISTER', 'UNDO'}
    
    # Reset these every time to prevent remembering last selection
    conversion_mode: bpy.props.EnumProperty(
        name="Mode",
        description="Choose whether to convert shapekeys when switching views",
        items=[
            ('CONVERT_AND_SWITCH', "Convert and switch view", "Convert shapekeys to appropriate naming and switch view"),
            ('ONLY_SWITCH', "Only switch view", "Switch view without converting shapekey names")
        ],
        default='CONVERT_AND_SWITCH',
        options={'SKIP_SAVE'}  # Don't save this property
    )
    
    def invoke(self, context, event):
        # Reset to default every time
        self.conversion_mode = 'CONVERT_AND_SWITCH'
        
        # Show confirmation dialog with conversion options
        return context.window_manager.invoke_props_dialog(self, width=450)
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        is_legacy = getattr(scene, 'shapekey_legacy_view', get_default_shapekey_legacy_view())
        
        # Title and warning
        if not is_legacy:
            layout.label(text="Switch to Legacy View (Deprecated)", icon='PREFERENCES')
        else:
            layout.label(text="Switch to New View", icon='PREFERENCES')
        
        layout.separator()
        
        # Warning box
        warning_box = layout.box()
        warning_box.alert = True
        warning_col = warning_box.column(align=True)
        warning_col.label(text="⚠ SAVE YOUR FILE BEFORE PROCEEDING!", icon='ERROR')
        warning_col.label(text="Conversion cannot be undone automatically.")
        
        layout.separator()
        
        # Information
        info_box = layout.box()
        info_col = info_box.column(align=True)
        info_col.label(text="To see the view as intended, conversion is recommended:", icon='INFO')
        
        if not is_legacy:
            # Going to legacy view
            info_col.label(text="• Legacy view works best with old shapekey names")
            info_col.label(text="• Reverse update will convert new names to old names")
            
            # Custom mode selector for legacy view
            layout.separator()
            mode_col = layout.column(align=True)
            mode_col.label(text="Mode:")
            
            mode_row1 = mode_col.row(align=True)
            mode_row1.prop_enum(self, "conversion_mode", 'CONVERT_AND_SWITCH', text="Reverse update and switch view")
            
            mode_row2 = mode_col.row(align=True) 
            mode_row2.prop_enum(self, "conversion_mode", 'ONLY_SWITCH', text="Only switch view")
            
        else:
            # Going to new view  
            info_col.label(text="• New view works best with new shapekey names")
            info_col.label(text="• Update will convert old names to new names")
            
            # Custom mode selector for new view
            layout.separator()
            mode_col = layout.column(align=True)
            mode_col.label(text="Mode:")
            
            mode_row1 = mode_col.row(align=True)
            mode_row1.prop_enum(self, "conversion_mode", 'CONVERT_AND_SWITCH', text="Update and switch view")
            
            mode_row2 = mode_col.row(align=True)
            mode_row2.prop_enum(self, "conversion_mode", 'ONLY_SWITCH', text="Only switch view")
    
    def execute(self, context):
        scene = context.scene
        is_legacy = getattr(scene, 'shapekey_legacy_view', get_default_shapekey_legacy_view())
        
        # Handle conversion if requested
        if self.conversion_mode == 'CONVERT_AND_SWITCH':
            # Run the shapekey name updater directly without popup
            if not is_legacy:
                # Going to legacy view - use reverse conversion
                bpy.ops.hhp.update_shapekey_names('EXEC_DEFAULT', reverse_conversion=True)
            else:
                # Going to new view - use normal conversion  
                bpy.ops.hhp.update_shapekey_names('EXEC_DEFAULT', reverse_conversion=False)
        
        # Switch the view
        scene.shapekey_legacy_view = not is_legacy
        
        return {'FINISHED'}

def draw_legacy_shapekey_editor(layout, context):
    """Draw legacy 2-column shapekey layout (original system)"""
    obj = context.active_object
    if not obj or obj.type != 'MESH':
        layout.label(text="Select a mesh object")
        return
        
    if not obj.data.shape_keys:
        layout.label(text="Object has no shape keys")
        return

    wm = context.window_manager
    
    # Add toggle button at the top of legacy view
    toggle_row = layout.row(align=True)
    toggle_row.label(text="Legacy View (2-Column Layout)", icon='PREFERENCES')
    toggle_row.operator("hhp.toggle_legacy_shapekey_view", 
                       text="Switch to New View", 
                       icon='PREFERENCES')
    
    layout.separator()

    # Main shapekeys from old system
    main_shape_keys = [
        'Heels & Boots bend', 'Elin female bend', 'Heels (Squished feet)',
        'Thicken lids', 'Thicken Lips', 'Nipples hide', 'Nipples pinch base'
    ]
    draw_shape_keys(obj, main_shape_keys, layout)
    
    # Auto-detected Torso-/Char- keys
    if obj.data and obj.data.shape_keys and obj.data.shape_keys.key_blocks:
        sk_block = obj.data.shape_keys.key_blocks
        auto_keys = [k for k in sk_block.keys()
                     if k.startswith('Torso -') or k.startswith('Char -')]
        if auto_keys:
            draw_shape_keys(obj, auto_keys, layout)
    
    layout.separator()
    layout.label(text="Extra Morphs")
    
    # Extra morphs from old system
    extra_keys = [
        'Long nails', 'Sexy Short Nails', 'Extra Long Nails', 'Extra sharp long nails',
        'real feet 1', 'real feet 2', 'real feet 3', 'real feet 4', 'real feet 5', 'real feet 6',
        'Hitomi feet', 'Tekken Feet & Legs', 'real toes 5', 'custom feet 1', 'Necdaz_feet',
        'Feet fatness', 'Feet (Real Ndaz)', 'Feet fatness - Cassie', 'feet preset - Haruka / Young',
        'Genesis8Female__PBMNailsLength', 'Genesis8Female__PBMChameleonROse_2_Tnails',
        'Genesis8Female__PBMChameleonROse_2_Fnails2', 'Genesis8Female__PBMChameleonROse_2_Fnails'
    ]
    draw_shape_keys(obj, extra_keys, layout)

def draw_custom_shapekey_editor(layout, context):
    """Draw custom shapekey list in Blender style with hierarchical categories"""
    obj = context.active_object
    if not obj or obj.type != 'MESH':
        layout.label(text="Select a mesh object")
        return
        
    if not obj.data.shape_keys:
        layout.label(text="Object has no shape keys")
        return
        
    shape_keys = obj.data.shape_keys
    wm = context.window_manager
    
    # Check if legacy view is enabled
    if getattr(context.scene, 'shapekey_legacy_view', get_default_shapekey_legacy_view()):
        draw_legacy_shapekey_editor(layout, context)
        return
    
    # Create main column
    main_col = layout.column(align=True)
    
    # Major category filter in a box - single row with all categories
    major_box = main_col.box()
    major_row = major_box.row(align=True)
    
    # Add update shapekey names button (icon only) to the left
    major_row.operator("hhp.update_shapekey_names", text="", icon='FILE_REFRESH')
    
    # All categories in one row: Hot List, Emote, Customize, Fix, All
    category_order = ['HOT_LIST', 'EMOTE', 'CUSTOMIZE', 'FIX', 'ALL']
    for major_key in category_order:
        major_info = SHAPEKEY_MAJOR_CATEGORIES[major_key]
        is_active = getattr(wm, 'shapekey_major_category', 'HOT_LIST') == major_key
        
        # Create button with tooltip using operator
        button = major_row.operator("hhp.set_shapekey_major_category", 
                                   text=major_info['name'], 
                                   icon=major_info['icon'],
                                   depress=is_active)
        button.category = major_key
    
    # Add legacy view toggle button to the right of All
    is_legacy_active = getattr(context.scene, 'shapekey_legacy_view', get_default_shapekey_legacy_view())
    major_row.operator("hhp.toggle_legacy_shapekey_view", 
                      text="", 
                      icon='PREFERENCES',
                      depress=is_legacy_active)
    
    # Get current major category
    current_major = getattr(wm, 'shapekey_major_category', 'HOT_LIST')
    current_subcategory = getattr(wm, 'shapekey_subcategory', 'HOT_LIST')
    
    # Show subcategories based on current major category
    if current_major in SHAPEKEY_MAJOR_CATEGORIES and current_major not in ['ALL', 'HOT_LIST']:
        subcategories = SHAPEKEY_MAJOR_CATEGORIES[current_major]['subcategories']
        
        if current_major == 'CUSTOMIZE':
            # Create rows of subcategory buttons (3 per row for better layout)
            sub_buttons_per_row = 3
            for i in range(0, len(subcategories), sub_buttons_per_row):
                sub_row = main_col.row(align=True)
                for j in range(sub_buttons_per_row):
                    if i + j < len(subcategories):
                        subcat = subcategories[i + j]
                        is_active = current_subcategory == subcat
                        sub_info = SUBCATEGORY_INFO[subcat]
                        op = sub_row.operator("hhp.set_shapekey_subcategory",
                                            text=sub_info['name'],
                                            depress=is_active)
                        op.subcategory = subcat
        else:
            # Regular subcategory row for Fix and Emote
            if len(subcategories) > 1:
                sub_row = main_col.row(align=True)
                for subcat in subcategories:
                    is_active = current_subcategory == subcat
                    sub_info = SUBCATEGORY_INFO[subcat]
                    op = sub_row.operator("hhp.set_shapekey_subcategory",
                                        text=sub_info['name'],
                                        depress=is_active)
                    op.subcategory = subcat
    
    # Draw the list with add/copy/remove buttons (only in "All" mode)
    if current_major == 'ALL':
        list_row = main_col.row()
        
        # Left side - the list
        list_col = list_row.column()
        rows = 16
        list_col.template_list(
            "HHP_UL_CustomShapekeysList", "",
            shape_keys, "key_blocks",
            obj, "active_shape_key_index",
            rows=rows
        )
        
        # Right side - assign/add/copy/remove buttons
        buttons_col = list_row.column(align=True)
        buttons_col.menu("HHP_MT_AssignShapekeyCategory", text="", icon='FILE_FOLDER')
        buttons_col.separator()
        buttons_col.operator("hhp.add_mesh_shapekey", text="", icon='ADD')
        buttons_col.operator("hhp.copy_mesh_shapekey", text="", icon='DUPLICATE')
        buttons_col.operator("hhp.remove_mesh_shapekey", text="", icon='REMOVE')
    else:
        # Regular list without buttons for other categories
        rows = 16
        main_col.template_list(
            "HHP_UL_CustomShapekeysList", "",
            shape_keys, "key_blocks",
            obj, "active_shape_key_index",
            rows=rows
        )
    
    # Controls
    if obj.data.shape_keys:
        controls_row = main_col.row(align=True)
        
        # Left column: Mute controls
        left_col = controls_row.column(align=True)
        
        # Check if any visible shapekeys are muted
        if current_major == 'ALL':
            # Check all shapekeys for mute state
            any_muted = False
            for sk in obj.data.shape_keys.key_blocks:
                if sk.mute:
                    any_muted = True
                    break
        elif current_major == 'HOT_LIST':
            # Check Hot List shapekeys for mute state
            target_keys = get_hot_list_shapekeys(obj.data.shape_keys.key_blocks)
            any_muted = False
            for sk in obj.data.shape_keys.key_blocks:
                if sk.name in target_keys and sk.mute:
                    any_muted = True
                    break
        else:
            target_keys = get_shapekeys_by_category(obj.data.shape_keys.key_blocks, current_subcategory)
            
            any_muted = False
            for sk in obj.data.shape_keys.key_blocks:
                if sk.name in target_keys and sk.mute:
                    any_muted = True
                    break
        
        # Mute toggle button
        mute_row = left_col.row(align=True)
        if any_muted:
            mute_row.alert = True
        
        mute_op = mute_row.operator("hhp.toggle_custom_shapekey_mute", 
                                   text="Unmute" if any_muted else "Mute",
                                   icon='HIDE_ON' if any_muted else 'HIDE_OFF')
        mute_op.mute_state = not any_muted
        
        # Right column: Edit controls
        right_col = controls_row.column(align=True)
        right_col.prop(obj, "show_only_shape_key", text="Shapekey Lock")
        right_col.prop(obj, "use_shape_key_edit_mode", text="Edit Mode")
        
        # Set values button
        set_values_row = main_col.row(align=True)
        set_values_row.operator("hhp.set_custom_shapekey_values", text="Set Values", icon='RNA')
        
        # Min/Max controls if we have an active shapekey
        if current_major == 'ALL':
            # For "All" category, show controls for any active shapekey
            if obj.active_shape_key:
                control_key = obj.active_shape_key
                min_max_row = main_col.row(align=True)
                min_max_row.prop(control_key, "slider_min", text="Range Min")
                min_max_row.prop(control_key, "slider_max", text="Max")
                
                # Vertex Group
                main_col.prop_search(control_key, "vertex_group", obj, "vertex_groups", text="")
        elif current_major == 'HOT_LIST':
            # For "Hot List" category, show controls for active shapekey if it's in the hot list
            if obj.active_shape_key:
                hot_list_keys = get_hot_list_shapekeys(obj.data.shape_keys.key_blocks)
                if obj.active_shape_key.name in hot_list_keys:
                    control_key = obj.active_shape_key
                    min_max_row = main_col.row(align=True)
                    min_max_row.prop(control_key, "slider_min", text="Range Min")
                    min_max_row.prop(control_key, "slider_max", text="Max")
                    
                    # Vertex Group
                    main_col.prop_search(control_key, "vertex_group", obj, "vertex_groups", text="")
        else:
            if obj.active_shape_key and obj.active_shape_key.name in target_keys:
                control_key = obj.active_shape_key
                min_max_row = main_col.row(align=True)
                min_max_row.prop(control_key, "slider_min", text="Range Min")
                min_max_row.prop(control_key, "slider_max", text="Max")
                
                # Vertex Group
                main_col.prop_search(control_key, "vertex_group", obj, "vertex_groups", text="")

# -------------------------------------------------------------------
# Helper functions
# -------------------------------------------------------------------

def draw_single_column_compact(obj, props_list, layout, disabled_names=None):
    """
    Draw each property in one tightly packed column (no extra spacing).
    """
    existing_props = [p for p in props_list if p in obj.keys()]
    if not existing_props:
        return

    if disabled_names is None:
        disabled_names = set()

    col = layout.column(align=True)  # <--- Single column, align=True for compact spacing
    for prop in existing_props:
        row = col.row(align=True)
        row.enabled = prop not in disabled_names
        row.prop(obj, f'["{prop}"]', text=prop)


def draw_props_two_columns(obj, props_list, layout, disabled_names=None):
    """
    Draw the given properties in 2 columns, preserving compact alignment,
    with each row possibly containing up to 2 props.
    Booleans are displayed as clickable text instead of checkboxes.
    """
    existing_props = [p for p in props_list if p in obj.keys()]
    if not existing_props:
        return

    if disabled_names is None:
        disabled_names = set()

    col = layout.column(align=True)
    rows = (len(existing_props) + 1) // 2
    idx = 0
    for _ in range(rows):
        row = col.row(align=True)
        for _col in range(2):
            if idx < len(existing_props):
                prop_name = existing_props[idx]
                prop_value = obj[prop_name]
                
                # Check if the property is a boolean
                if isinstance(prop_value, bool):
                    # Bool: clickable text
                    sub = row.row(align=True)
                    sub.enabled = prop_name not in disabled_names
                    sub.prop(obj, f'["{prop_name}"]', text=prop_name, toggle=True)
                else:
                    # Regular property
                    sub = row.row(align=True)
                    sub.enabled = prop_name not in disabled_names
                    sub.prop(obj, f'["{prop_name}"]', text=prop_name)
                idx += 1


def draw_shape_keys(obj, shape_keys_list, layout):
    """
    Draw shape keys in 2 columns, preserving alignment.
    (Shape keys do NOT appear in obj.keys().)
    """
    sk = getattr(obj.data, "shape_keys", None)
    if not (sk and sk.key_blocks):
        return

    key_blocks = sk.key_blocks
    existing_keys = [k for k in shape_keys_list if k in key_blocks]
    if not existing_keys:
        return

    col = layout.column(align=True)
    rows = (len(existing_keys) + 1) // 2
    idx = 0
    for _ in range(rows):
        row = col.row(align=True)
        for _col in range(2):
            if idx < len(existing_keys):
                key_name = existing_keys[idx]
                row.prop(key_blocks[key_name], 'value', text=key_name)
                idx += 1


def draw_node_group_inputs(obj, node_group_name_keyword, exclude_sockets, layout):
    """
    Draws node group inputs in 2 columns (RGBA -> single row).
    """
    node_group_node = None
    for slot in obj.material_slots:
        mat = slot.material
        if mat and mat.use_nodes:
            for node in mat.node_tree.nodes:
                if (node.type == 'GROUP'
                    and node.node_tree
                    and node_group_name_keyword in node.node_tree.name):
                    node_group_node = node
                    break
        if node_group_node:
            break

    if not node_group_node:
        layout.label(text=f"No node group containing '{node_group_name_keyword}' found.")
        return

    inputs = node_group_node.inputs
    existing_sockets = [s for s in inputs if s.name not in exclude_sockets]
    if not existing_sockets:
        layout.label(text="No inputs to display.")
        return

    ordered = []
    current_row = []
    for sock in existing_sockets:
        is_color = (sock.type == 'RGBA')
        if is_color:
            if current_row:
                ordered.append(current_row)
                current_row = []
            ordered.append([sock])  # color alone in a row
        else:
            current_row.append(sock)
            if len(current_row) == 2:
                ordered.append(current_row)
                current_row = []
    if current_row:
        ordered.append(current_row)

    col = layout.column(align=True)
    for row_socks in ordered:
        row = col.row(align=True)
        if len(row_socks) == 1:
            sock = row_socks[0]
            if sock.is_linked:
                linked_node = sock.links[0].from_node
                if hasattr(linked_node.outputs[0], 'default_value'):
                    row.prop(linked_node.outputs[0], 'default_value', text=sock.name)
                else:
                    row.label(text=f"Unsupported node type: {linked_node.type}")
            else:
                row.prop(sock, 'default_value', text=sock.name)
        else:
            for sock in row_socks:
                if sock.is_linked:
                    linked_node = sock.links[0].from_node
                    if hasattr(linked_node.outputs[0], 'default_value'):
                        row.prop(linked_node.outputs[0], 'default_value', text=sock.name)
                    else:
                        row.label(text=f"Unsupported node type: {linked_node.type}")
                else:
                    row.prop(sock, 'default_value', text=sock.name)


def draw_node_group_inputs_in_material(obj, material_name_keyword, node_group_name_keyword, exclude_sockets, layout):
    """
    Draws node group inputs in 2 columns (RGBA -> single row).
    Searches for a node group with node_group_name_keyword within a material containing material_name_keyword.
    """
    node_group_node = None
    target_material = None
    
    # First find the material with the specified keyword
    for slot in obj.material_slots:
        mat = slot.material
        if mat and material_name_keyword in mat.name:
            target_material = mat
            break
    
    if not target_material:
        layout.label(text=f"No material containing '{material_name_keyword}' found.")
        return
    
    # Then find the node group within that material
    if target_material.use_nodes:
        for node in target_material.node_tree.nodes:
            if (node.type == 'GROUP'
                and node.node_tree
                and node_group_name_keyword in node.node_tree.name):
                node_group_node = node
                break

    if not node_group_node:
        layout.label(text=f"No node group containing '{node_group_name_keyword}' found in material '{target_material.name}'.")
        return

    inputs = node_group_node.inputs
    existing_sockets = [s for s in inputs if s.name not in exclude_sockets]
    if not existing_sockets:
        layout.label(text="No inputs to display.")
        return

    ordered = []
    current_row = []
    for sock in existing_sockets:
        is_color = (sock.type == 'RGBA')
        if is_color:
            if current_row:
                ordered.append(current_row)
                current_row = []
            ordered.append([sock])  # color alone in a row
        else:
            current_row.append(sock)
            if len(current_row) == 2:
                ordered.append(current_row)
                current_row = []
    if current_row:
        ordered.append(current_row)

    col = layout.column(align=True)
    for row_socks in ordered:
        row = col.row(align=True)
        if len(row_socks) == 1:
            sock = row_socks[0]
            if sock.is_linked:
                linked_node = sock.links[0].from_node
                if hasattr(linked_node.outputs[0], 'default_value'):
                    row.prop(linked_node.outputs[0], 'default_value', text=sock.name)
                else:
                    row.label(text=f"Unsupported node type: {linked_node.type}")
            else:
                row.prop(sock, 'default_value', text=sock.name)
        else:
            for sock in row_socks:
                if sock.is_linked:
                    linked_node = sock.links[0].from_node
                    if hasattr(linked_node.outputs[0], 'default_value'):
                        row.prop(linked_node.outputs[0], 'default_value', text=sock.name)
                    else:
                        row.label(text=f"Unsupported node type: {linked_node.type}")
                else:
                    row.prop(sock, 'default_value', text=sock.name)


def draw_node_group_inputs_clean(obj, node_group_name_keyword, exclude_sockets, layout):
    """
    Draws node group inputs in 2 columns with clean styling:
    - Colors show only swatch (no text label)
    - Bools show as clickable text
    """
    node_group_node = None
    for slot in obj.material_slots:
        mat = slot.material
        if mat and mat.use_nodes:
            for node in mat.node_tree.nodes:
                if (node.type == 'GROUP'
                    and node.node_tree
                    and node_group_name_keyword in node.node_tree.name):
                    node_group_node = node
                    break
        if node_group_node:
            break

    if not node_group_node:
        layout.label(text="No compatible node group found with this version of the model")
        return

    inputs = node_group_node.inputs
    existing_sockets = [s for s in inputs if s.name not in exclude_sockets]
    if not existing_sockets:
        layout.label(text="No inputs to display.")
        return

    ordered = []
    current_row = []
    for sock in existing_sockets:
        # Treat all sockets the same - two per row
        current_row.append(sock)
        if len(current_row) == 2:
            ordered.append(current_row)
            current_row = []
    if current_row:
        ordered.append(current_row)

    col = layout.column(align=True)
    for row_socks in ordered:
        row = col.row(align=True)
        if len(row_socks) == 1:
            sock = row_socks[0]
            if sock.is_linked:
                linked_node = sock.links[0].from_node
                if hasattr(linked_node.outputs[0], 'default_value'):
                    if sock.type == 'RGBA':
                        # Color: show only swatch, hover shows name automatically
                        row.prop(linked_node.outputs[0], 'default_value', text="")
                    elif linked_node.outputs[0].bl_rna.properties.get('default_value').type == 'BOOLEAN':
                        # Bool: clickable text
                        row.prop(linked_node.outputs[0], 'default_value', text=sock.name, toggle=True)
                    else:
                        row.prop(linked_node.outputs[0], 'default_value', text=sock.name)
                else:
                    row.label(text=f"Unsupported node type: {linked_node.type}")
            else:
                if sock.type == 'RGBA':
                    # Color: show only swatch, hover shows name automatically
                    row.prop(sock, 'default_value', text="")
                elif hasattr(sock, 'default_value') and isinstance(sock.default_value, bool):
                    # Bool: clickable text
                    row.prop(sock, 'default_value', text=sock.name, toggle=True)
                else:
                    row.prop(sock, 'default_value', text=sock.name)
        else:
            for sock in row_socks:
                if sock.is_linked:
                    linked_node = sock.links[0].from_node
                    if hasattr(linked_node.outputs[0], 'default_value'):
                        if sock.type == 'RGBA':
                            # Color: show only swatch, hover shows name automatically
                            row.prop(linked_node.outputs[0], 'default_value', text="")
                        elif linked_node.outputs[0].bl_rna.properties.get('default_value').type == 'BOOLEAN':
                            # Bool: clickable text
                            row.prop(linked_node.outputs[0], 'default_value', text=sock.name, toggle=True)
                        else:
                            row.prop(linked_node.outputs[0], 'default_value', text=sock.name)
                    else:
                        row.label(text=f"Unsupported node type: {linked_node.type}")
                else:
                    if sock.type == 'RGBA':
                        # Color: show only swatch, hover shows name automatically
                        row.prop(sock, 'default_value', text="")
                    elif hasattr(sock, 'default_value') and isinstance(sock.default_value, bool):
                        # Bool: clickable text
                        row.prop(sock, 'default_value', text=sock.name, toggle=True)
                    else:
                        row.prop(sock, 'default_value', text=sock.name)


def draw_node_group_inputs_in_material_clean(obj, material_name_keyword, node_group_name_keyword, exclude_sockets, layout):
    """
    Draws node group inputs in 2 columns with clean styling:
    - Colors show only swatch (no text label)
    - Bools show as clickable text
    Searches for a node group with node_group_name_keyword within a material containing material_name_keyword.
    """
    node_group_node = None
    target_material = None
    
    # First find the material with the specified keyword
    for slot in obj.material_slots:
        mat = slot.material
        if mat and material_name_keyword in mat.name:
            target_material = mat
            break
    
    if not target_material:
        layout.label(text=f"No material containing '{material_name_keyword}' found.")
        return
    
    # Then find the node group within that material
    if target_material.use_nodes:
        for node in target_material.node_tree.nodes:
            if (node.type == 'GROUP'
                and node.node_tree
                and node_group_name_keyword in node.node_tree.name):
                node_group_node = node
                break

    if not node_group_node:
        layout.label(text="No compatible node group found with this version of the model")
        return

    inputs = node_group_node.inputs
    existing_sockets = [s for s in inputs if s.name not in exclude_sockets]
    if not existing_sockets:
        layout.label(text="No inputs to display.")
        return

    ordered = []
    current_row = []
    for sock in existing_sockets:
        # Treat all sockets the same - two per row
        current_row.append(sock)
        if len(current_row) == 2:
            ordered.append(current_row)
            current_row = []
    if current_row:
        ordered.append(current_row)

    col = layout.column(align=True)
    for row_socks in ordered:
        row = col.row(align=True)
        if len(row_socks) == 1:
            sock = row_socks[0]
            if sock.is_linked:
                linked_node = sock.links[0].from_node
                if hasattr(linked_node.outputs[0], 'default_value'):
                    if sock.type == 'RGBA':
                        # Color: show only swatch, hover shows name automatically
                        row.prop(linked_node.outputs[0], 'default_value', text="")
                    elif linked_node.outputs[0].bl_rna.properties.get('default_value').type == 'BOOLEAN':
                        # Bool: clickable text
                        row.prop(linked_node.outputs[0], 'default_value', text=sock.name, toggle=True)
                    else:
                        row.prop(linked_node.outputs[0], 'default_value', text=sock.name)
                else:
                    row.label(text=f"Unsupported node type: {linked_node.type}")
            else:
                if sock.type == 'RGBA':
                    # Color: show only swatch, hover shows name automatically
                    row.prop(sock, 'default_value', text="")
                elif hasattr(sock, 'default_value') and isinstance(sock.default_value, bool):
                    # Bool: clickable text
                    row.prop(sock, 'default_value', text=sock.name, toggle=True)
                else:
                    row.prop(sock, 'default_value', text=sock.name)
        else:
            for sock in row_socks:
                if sock.is_linked:
                    linked_node = sock.links[0].from_node
                    if hasattr(linked_node.outputs[0], 'default_value'):
                        if sock.type == 'RGBA':
                            # Color: show only swatch, hover shows name automatically
                            row.prop(linked_node.outputs[0], 'default_value', text="")
                        elif linked_node.outputs[0].bl_rna.properties.get('default_value').type == 'BOOLEAN':
                            # Bool: clickable text
                            row.prop(linked_node.outputs[0], 'default_value', text=sock.name, toggle=True)
                        else:
                            row.prop(linked_node.outputs[0], 'default_value', text=sock.name)
                    else:
                        row.label(text=f"Unsupported node type: {linked_node.type}")
                else:
                    if sock.type == 'RGBA':
                        # Color: show only swatch, hover shows name automatically
                        row.prop(sock, 'default_value', text="")
                    elif hasattr(sock, 'default_value') and isinstance(sock.default_value, bool):
                        # Bool: clickable text
                        row.prop(sock, 'default_value', text=sock.name, toggle=True)
                    else:
                        row.prop(sock, 'default_value', text=sock.name)


# -------------------------------------------------------------------
# Section Mode Toggle Operators 
# -------------------------------------------------------------------

class HHP_OT_ToggleCustomizePanelSectionInitial(bpy.types.Operator):
    bl_idname = "hhp.toggle_customize_section_initial"
    bl_label = "Initial Setup"
    bl_description = "Initial Setup - Character initialization options (Base values and textures) - Not saved in presets"
    
    def execute(self, context):
        wm = context.window_manager
        if wm.custom_panel_section == 'INITIAL_SETUP':
            # No-op when clicking the same section again (keep it active)
            pass
        else:
            wm.custom_panel_section = 'INITIAL_SETUP'
        return {'FINISHED'}

class HHP_OT_ToggleCustomizePanelSectionShapekeys(bpy.types.Operator):
    bl_idname = "hhp.toggle_customize_section_shapekeys"
    bl_label = "Shapekey Morphs"
    bl_description = "Shapekey Morphs - Character shape customization with shapekeys / blendshapes"
    
    def execute(self, context):
        wm = context.window_manager
        if wm.custom_panel_section == 'SHAPEKEY_MORPHS':
            # No-op when clicking the same section again (keep it active)
            pass
        else:
            wm.custom_panel_section = 'SHAPEKEY_MORPHS'
        return {'FINISHED'}

class HHP_OT_ToggleCustomizePanelSectionEffects(bpy.types.Operator):
    bl_idname = "hhp.toggle_customize_section_effects"
    bl_label = "Effects & Shaders"
    bl_description = "Effects & Shaders - shader based customization and Visual effects"
    
    def execute(self, context):
        wm = context.window_manager
        if wm.custom_panel_section == 'EFFECTS_SHADERS':
            # No-op when clicking the same section again (keep it active)
            pass
        else:
            wm.custom_panel_section = 'EFFECTS_SHADERS'
        return {'FINISHED'}

class HHP_OT_ToggleCustomizePanelSectionClothing(bpy.types.Operator):
    bl_idname = "hhp.toggle_customize_section_clothing"
    bl_label = "Clothing & Accessories"
    bl_description = "Clothing & Accessories - Manage character clothing and accessories"
    
    def execute(self, context):
        wm = context.window_manager
        if wm.custom_panel_section == 'CLOTHING':
            # No-op when clicking the same section again (keep it active)
            pass
        else:
            wm.custom_panel_section = 'CLOTHING'
        return {'FINISHED'}

class HHP_OT_ToggleCustomizePanelSectionMisc(bpy.types.Operator):
    bl_idname = "hhp.toggle_customize_section_misc"
    bl_label = "Misc"
    bl_description = "Misc - Miscellaneous properties and masking options for toggling mesh parts on / off"
    
    def execute(self, context):
        wm = context.window_manager
        if wm.custom_panel_section == 'MISC':
            # No-op when clicking the same section again (keep it active)
            pass
        else:
            wm.custom_panel_section = 'MISC'
        return {'FINISHED'}

# -------------------------------------------------------------------
# Main Panel with Single Dropdown
# -------------------------------------------------------------------

class CustomizePanel(bpy.types.Panel):
    bl_label = "Customize (HHP)"
    bl_idname = "CHAR_PT_Customize_HHP"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Char (HHP)"
    bl_parent_id = "CHAR_HHP_PT_Panel"  # Set parent panel
    bl_options = {'HIDE_HEADER'}  # Hide the header
    bl_order = 20
    
    @classmethod
    def poll(cls, context):
        # Only show this panel if CUSTOMIZE is selected in the mode selector
        return context.scene.hhp_panel_mode.selected_panel == 'CUSTOMIZE'

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        obj = context.object

        if not obj:
            section_box = layout.box()
            section_box.label(text="An HHP character mesh must be selected for customization", icon='ERROR')
            section_box.alert = True
            return

        # Add optimized materials warning and toggles
        selected_objects = context.selected_objects
        materials_linked = is_material_linked_by_object(selected_objects)
        heavy_hidden = is_heavy_collections_hidden()
        optimized_materials = any(slot.material and slot.material.name.startswith("(BS)_Proxy") for slot in obj.material_slots)
        if optimized_materials:
            layout.label(text="Model is on optimized materials: driven shaders can't be edited in this mode", icon='ERROR')
        if heavy_hidden:
            layout.label(text="Model is on optimized view: clothing can't be edited in this mode", icon='ERROR')

        grid = layout.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=True, align=True)
        grid.operator("hhp.flip_material_link", text="Toggle optimized materials", icon='MATERIAL', depress=materials_linked)
        grid.operator("hhp.toggle_heavy_collections", text="Toggle optimized view", icon='HIDE_OFF', depress=heavy_hidden)

        # Only show the preset selector and panel section dropdown if the active mesh's data name contains "Genesis8Female" and the object name does not contain "Deform Proxy"
        if obj and obj.type == 'MESH' and obj.data and "Genesis8Female" in obj.data.name and "Deform Proxy" not in obj.name:
            # Panel section container box with mode selector and preset controls
            section_box = layout.box()
            
            # Add mode selector for section modes
            mode_row = section_box.row(align=True)
            
            # Left side: Mode selector buttons
            left_side = mode_row.row(align=True)
            
            # Initial Setup button
            initial_btn = left_side.operator("hhp.toggle_customize_section_initial", text="", icon='QUIT', 
                                          depress=wm.custom_panel_section=='INITIAL_SETUP')
            
            # Shapekey Morphs button
            shapekey_btn = left_side.operator("hhp.toggle_customize_section_shapekeys", text="", icon='SHAPEKEY_DATA', 
                                           depress=wm.custom_panel_section=='SHAPEKEY_MORPHS')
            
            # Effects & Shaders button
            effects_btn = left_side.operator("hhp.toggle_customize_section_effects", text="", icon='MATERIAL', 
                                          depress=wm.custom_panel_section=='EFFECTS_SHADERS')
            
            # Clothing & Accessories button
            clothing_btn = left_side.operator("hhp.toggle_customize_section_clothing", text="", icon='MOD_CLOTH', 
                                           depress=wm.custom_panel_section=='CLOTHING')
            
            # Misc button
            misc_btn = left_side.operator("hhp.toggle_customize_section_misc", text="", icon='MOD_MASK', 
                                       depress=wm.custom_panel_section=='MISC')
            
            # Right side: Preset dropdown and buttons
            right_side = mode_row.row(align=True)
            right_side.prop(obj, "active_preset", text="", icon="MOD_CLOTH")
            # Preset buttons in separate row so only buttons get disabled when optimized view is active
            preset_buttons = right_side.row(align=True)
            preset_buttons.enabled = not heavy_hidden
            preset_buttons.operator("object.add_preset", text="", icon="ADD")
            preset_buttons.operator("object.remove_preset", text="", icon="REMOVE")
            preset_buttons.operator("object.rename_preset", text="", icon="PRESET")
            preset_buttons.operator("object.overwrite_preset", text="", icon="FILE_TICK")
            preset_buttons.operator("object.update_all_presets", text="", icon="FILE_REFRESH")
        else:
            # Ensure section_box is defined even if the object doesn't meet the criteria.
            section_box = layout.box()
            section_box.label(text="An HHP character mesh must be selected for customization", icon='ERROR')
            section_box.alert = True
            return

        # ------------------------------------------------------------------
        # Define known property sets, so they don't show up in Misc.
        # ------------------------------------------------------------------
        first_six_props = [
            "Displace Deform Proxy",
            "Displace Clothing",
            "Base Color (Switch)",
            "Normal (Switch)",
            "Hue",
            "Saturation",
            "Value"
        ]
        leftover_setup_props = [
            'Eye socket push back', 'Correct Eyelids',
            'Detail Bump - Face', 'Detail Bump',
            'Micro Skin Detail', 'Pore Skin Detail',
            'Normal Contrast (Face)', 'Normal Contrast (Body)',
            'Normal Contrast (Genitals)', 'Normal Contrast (Clavicle)',
            'Subsurface', 'Max Roughness',
            'Abs'
        ]
        all_initial_setup = set(first_six_props + leftover_setup_props)

        effects_shaders_props = [
            'Feet Dirt', 'Gens used', 'Goosebumps', 'Hand Veins', 'Piercing Bumps',
            'Tan Lines', 'Throat Bulge (Color)', 'Throat Bulge (Neck Bump)',
            'Throat Bulge (SK Deform)', 'Throat Bulge (Veins Bump)', 'Vascularity',
            'Wetness', 'Wetness (Switch)'
        ]

        allocated_props = all_initial_setup.union(effects_shaders_props)

        # All user-defined properties on this object
        all_custom_props = set(obj.keys())
        built_in_props = set(p.identifier for p in obj.bl_rna.properties)

        # Exclude certain addon helper properties from showing in Misc
        excluded_misc_props = {
            "orig_subsurface",
            "presets",
            "proxify_target",
            "hops",
            "ant_landscape",
            "MM",
        }

        leftover_for_misc = [
            p for p in sorted(all_custom_props - built_in_props)
            if p not in allocated_props and p not in excluded_misc_props and not p.startswith('_')
        ]

        # Show whichever section is chosen directly in the same box:
        if wm.custom_panel_section == 'INITIAL_SETUP':
            # Grey out selected properties when optimized materials are enabled
            disabled_when_optimized = set()
            if optimized_materials:
                disabled_when_optimized = {
                    "Base Color (Switch)",
                    "Normal (Switch)",
                    "Hue",
                    "Saturation",
                    "Value",
                    "Detail Bump - Face",
                    "Detail Bump",
                    "Micro Skin Detail",
                    "Pore Skin Detail",
                    "Normal Contrast (Face)",
                    "Normal Contrast (Body)",
                    "Normal Contrast (Genitals)",
                    "Normal Contrast (Clavicle)",
                    "Subsurface",
                    "Max Roughness",
                    "Abs",
                }
            draw_single_column_compact(obj, first_six_props, section_box, disabled_names=disabled_when_optimized)
            section_box.separator()
            draw_props_two_columns(obj, leftover_setup_props, section_box, disabled_names=disabled_when_optimized)

        elif wm.custom_panel_section == 'SHAPEKEY_MORPHS':
            draw_custom_shapekey_editor(section_box, context)

        elif wm.custom_panel_section == 'EFFECTS_SHADERS':
            # Create main column with tighter spacing
            main_col = section_box.column(align=True)
            
            # Shader FX section in its own collapsible box
            shader_fx_box = main_col.box()
            # Disable ShaderFX when optimized materials is active
            shader_fx_box.enabled = not any(slot.material and slot.material.name.startswith("(BS)_Proxy") for slot in obj.material_slots)
            shader_fx_header = shader_fx_box.row(align=True)
            shader_fx_header.alignment = 'LEFT'
            icon = 'TRIA_DOWN' if wm.effects_shader_fx_expanded else 'TRIA_RIGHT'
            shader_fx_header.prop(wm, "effects_shader_fx_expanded", text="", icon=icon, emboss=False, icon_only=True)
            shader_fx_header.prop(wm, "effects_shader_fx_expanded", text="Shader FX", icon='SHADERFX', emboss=False)
            
            if wm.effects_shader_fx_expanded:
                draw_props_two_columns(obj, effects_shaders_props, shader_fx_box)
            
            # Makeup section in its own collapsible box
            makeup_box = main_col.box()
            makeup_header = makeup_box.row(align=True)
            makeup_header.alignment = 'LEFT'
            icon = 'TRIA_DOWN' if wm.effects_makeup_expanded else 'TRIA_RIGHT'
            makeup_header.prop(wm, "effects_makeup_expanded", text="", icon=icon, emboss=False, icon_only=True)
            makeup_header.prop(wm, "effects_makeup_expanded", text="Makeup", icon='BRUSHES_ALL', emboss=False)
            
            if wm.effects_makeup_expanded:
                draw_node_group_inputs_clean(obj, "Makeup_HHP", ["Base Color", "Roughness"], makeup_box)
            
            # Fingernails section in its own collapsible box
            fingernails_box = main_col.box()
            fingernails_header = fingernails_box.row(align=True)
            fingernails_header.alignment = 'LEFT'
            icon = 'TRIA_DOWN' if wm.effects_fingernails_expanded else 'TRIA_RIGHT'
            fingernails_header.prop(wm, "effects_fingernails_expanded", text="", icon=icon, emboss=False, icon_only=True)
            fingernails_header.prop(wm, "effects_fingernails_expanded", text="Fingernails", icon='BRUSHES_ALL', emboss=False)
            
            if wm.effects_fingernails_expanded:
                draw_node_group_inputs_in_material_clean(obj, "Genesis 8 Female_Fingernails", "Fingernails (HHP)", [], fingernails_box)
            
            # Toenails section in its own collapsible box
            toenails_box = main_col.box()
            toenails_header = toenails_box.row(align=True)
            toenails_header.alignment = 'LEFT'
            icon = 'TRIA_DOWN' if wm.effects_toenails_expanded else 'TRIA_RIGHT'
            toenails_header.prop(wm, "effects_toenails_expanded", text="", icon=icon, emboss=False, icon_only=True)
            toenails_header.prop(wm, "effects_toenails_expanded", text="Toenails", icon='BRUSHES_ALL', emboss=False)
            
            if wm.effects_toenails_expanded:
                draw_node_group_inputs_in_material_clean(obj, "Genesis 8 Female_Toenails", "Toenails (HHP)", [], toenails_box)

        elif wm.custom_panel_section == 'CLOTHING':
            main_row = section_box.row(align=True)
            # Disable clothing controls when optimized collections mode is active
            main_row.enabled = not heavy_hidden

            # Left column: Clothes collections
            col_clothes = main_row.column(align=True)
            col_clothes.label(text="Clothes")
            clothes_collections = self.find_clothes_collections(context)
            for collection, current_hidden, is_top_level, objects in clothes_collections:
                row = col_clothes.row(align=True)
                clean_name = collection.name.split(".")[0]
                icon = 'OUTLINER_COLLECTION'
                row.active = True
                row.prop(collection, "show_collection_render", text=clean_name, toggle=True, icon=icon)
                if not current_hidden and objects:
                    inner_box = col_clothes.box()
                    inner_col = inner_box.column(align=True)
                    for obj_item, obj_hidden in objects:
                        obj_row = inner_col.row(align=True)
                        obj_name = obj_item.name.split(".")[0]
                        obj_icon = 'OBJECT_DATA'
                        obj_row.active = True
                        obj_row.prop(obj_item, "show_object_render", text=obj_name, toggle=True, icon=obj_icon)

            # Right column: Appendages collections
            col_appendages = main_row.column(align=True)
            col_appendages.label(text="Appendages")
            appendages_collections = self.find_appendages_collections(context)
            for collection, current_hidden, is_top_level, objects in appendages_collections:
                row = col_appendages.row(align=True)
                clean_name = collection.name.split(".")[0]
                icon = 'OUTLINER_COLLECTION'
                row.active = True
                row.prop(collection, "show_collection_render", text=clean_name, toggle=True, icon=icon)
                if not current_hidden and objects:
                    inner_box = col_appendages.box()
                    inner_col = inner_box.column(align=True)
                    for obj_item, obj_hidden in objects:
                        obj_row = inner_col.row(align=True)
                        obj_name = obj_item.name.split(".")[0]
                        obj_icon = 'OBJECT_DATA'
                        obj_row.active = True
                        obj_row.prop(obj_item, "show_object_render", text=obj_name, toggle=True, icon=obj_icon)

        elif wm.custom_panel_section == 'MISC':
            if leftover_for_misc:
                draw_props_two_columns(obj, leftover_for_misc, section_box)
            else:
                section_box.label(text="No misc properties found.")

    def collect_collections(self, collection, collection_list, parent_hidden=False, is_top_level=False, processed_collections=None):
        if processed_collections is None:
            processed_collections = set()
        if collection in processed_collections:
            return
        processed_collections.add(collection)

        # Determine if current collection is hidden (viewport or render)
        current_hidden = parent_hidden or collection.hide_viewport or collection.hide_render

        # Collect objects if the collection is not hidden
        objects = []
        if not current_hidden:
            for obj in collection.objects:
                obj_hidden = obj.hide_viewport or obj.hide_render
                objects.append((obj, obj_hidden))

        collection_list.append((collection, current_hidden, is_top_level, objects))

        # Process child collections if not hidden
        if not current_hidden:
            for child in collection.children:
                self.collect_collections(
                    child,
                    collection_list,
                    parent_hidden=current_hidden,
                    is_top_level=False,
                    processed_collections=processed_collections
                )

    def find_clothes_collections(self, context):
        """Find all 'Clothes' collections from the specific character HHP collection of the active mesh."""
        clothes_collections = []
        processed_collections = set()
        
        # Find the specific character HHP collection for the active object
        active_obj = context.active_object
        if not active_obj:
            return clothes_collections
        
        char_collection = find_character_hhp_collection(active_obj)
        if not char_collection:
            return clothes_collections
        
        # Only search within this specific character collection's hierarchy
        def search_for_clothes_recursive(collection):
            for sub_collection in collection.children:
                if sub_collection.name.startswith("Clothes") and sub_collection not in processed_collections:
                    self.collect_collections(
                        sub_collection,
                        clothes_collections,
                        parent_hidden=False,
                        is_top_level=True,
                        processed_collections=processed_collections
                    )
                # Continue searching child collections
                search_for_clothes_recursive(sub_collection)
        
        search_for_clothes_recursive(char_collection)
        return clothes_collections

    def find_appendages_collections(self, context):
        """Find all 'Appendages' collections from the specific character HHP collection of the active mesh."""
        appendages_collections = []
        processed_collections = set()
        
        # Find the specific character HHP collection for the active object
        active_obj = context.active_object
        if not active_obj:
            return appendages_collections
        
        char_collection = find_character_hhp_collection(active_obj)
        if not char_collection:
            return appendages_collections
        
        # Only search within this specific character collection's hierarchy
        def search_for_appendages_recursive(collection):
            for sub_collection in collection.children:
                if sub_collection.name.startswith("Appendages") and sub_collection not in processed_collections:
                    self.collect_collections(
                        sub_collection,
                        appendages_collections,
                        parent_hidden=False,
                        is_top_level=True,
                        processed_collections=processed_collections
                    )
                # Continue searching child collections
                search_for_appendages_recursive(sub_collection)
        
        search_for_appendages_recursive(char_collection)
        return appendages_collections


# -------------------------------------------------------------------
# Registration
# -------------------------------------------------------------------

def register():
    # Register preset management classes
    bpy.utils.register_class(HHP_PresetItem)
    bpy.utils.register_class(HHP_UL_PresetsList)
    bpy.utils.register_class(HHP_OT_MovePresetUp)
    bpy.utils.register_class(HHP_OT_MovePresetDown)
    
    # Register shapekey list classes
    bpy.utils.register_class(HHP_UL_CustomShapekeysList)
    bpy.utils.register_class(HHP_OT_SetCustomShapekeyValues)
    bpy.utils.register_class(HHP_OT_ToggleCustomShapekeyMute)
    bpy.utils.register_class(HHP_OT_SetShapekeyMajorCategory)
    bpy.utils.register_class(HHP_OT_SetShapekeySubcategory)
    bpy.utils.register_class(HHP_OT_ToggleLegacyShapekeyView)
    bpy.utils.register_class(HHP_OT_AddMeshShapekey)
    bpy.utils.register_class(HHP_OT_CopyMeshShapekey)
    bpy.utils.register_class(HHP_OT_RemoveMeshShapekey)
    bpy.utils.register_class(HHP_MT_AssignShapekeyCategory)
    bpy.utils.register_class(HHP_OT_AssignMeshShapekeyCategory)
    
    bpy.utils.register_class(HHP_OT_ToggleCustomizePanelSectionInitial)
    bpy.utils.register_class(HHP_OT_ToggleCustomizePanelSectionShapekeys)
    bpy.utils.register_class(HHP_OT_ToggleCustomizePanelSectionEffects)
    bpy.utils.register_class(HHP_OT_ToggleCustomizePanelSectionClothing)
    bpy.utils.register_class(HHP_OT_ToggleCustomizePanelSectionMisc)
    bpy.utils.register_class(CustomizePanel)
    bpy.utils.register_class(OT_AddPreset)
    bpy.utils.register_class(OT_OverwritePreset)
    bpy.utils.register_class(HHP_OT_UpdateAllPresets)
    bpy.utils.register_class(OT_RemovePreset)
    bpy.utils.register_class(HHP_OT_RenamePreset)
    
    wm = bpy.types.WindowManager
    wm.custom_panel_section = bpy.props.EnumProperty(
        name="Panel Section",
        description="Choose which section to display",
        items=[
            ('INITIAL_SETUP',     "Initial Setup",    ""),
            ('SHAPEKEY_MORPHS',   "Shapekey Morphs",  ""),
            ('EFFECTS_SHADERS',   "Effects & Shaders",""),
            ('CLOTHING',        "Clothing & Accessories", ""),
            ('MISC',              "Misc",             "")
        ],
        default='INITIAL_SETUP'
    )
    wm.shapekey_major_category = bpy.props.EnumProperty(
        name="Major Category",
        description="Select major shapekey category",
        items=[
            ('HOT_LIST', "Hot List", "Quick access to frequently used shapekeys"),
            ('FIX', "Fix", "Corrective shapekeys for fixing mesh deformation issues and geometry problems"),
            ('EMOTE', "Emote", "Facial expressions, emotions, and utility shapekeys for character animation"),
            ('ALL', "All", "Complete list of all shapekeys available on the current mesh"),
            ('CUSTOMIZE', "Customize", "Body shape customization and character variation shapekeys")
        ],
        default='HOT_LIST'
    )
    wm.shapekey_subcategory = bpy.props.EnumProperty(
        name="Subcategory",
        description="Select shapekey subcategory",
        items=[
            ('EXPRESSION', "Expression", "Facial expressions and emotional states"),
            ('PRESET', "Preset", "Pre-configured body shape presets and combinations"),
            ('HEAD', "Head", "Head shape modifications and facial features"),
            ('TORSO', "Torso", "Body torso and chest area shape modifications"),
            ('ARM', "Arm", "Arm shape and muscle definition adjustments"),
            ('HAND', "Hand", "Hand shape and finger modifications"),
            ('LEG', "Leg", "Leg shape and muscle definition adjustments"),
            ('FEET', "Feet", "Foot shape and toe modifications"),
            ('GENITALS', "Genitals", "Genital area shape modifications"),
            ('PROPORTION', "Proportion", "Overall body proportions and scaling adjustments"),
            ('UTILITY', "Utility", "Utility and helper shapekeys for various purposes"),
            ('FIX', "Fix", "Corrective shapekeys for mesh deformation fixes"),
            ('ALL', "All", "Complete list of all shapekeys available on the current mesh"),
            ('HOT_LIST', "Hot List", "Quick access to frequently used shapekeys")
        ],
        default='HOT_LIST'
    )
    # Get default value from addon preferences
    try:
        prefs = bpy.context.preferences.addons[__package__].preferences
        # Invert the logic since preference tracks "use new view" but we need "use legacy view"
        default_legacy_view = not prefs.default_shapekey_view_new
    except:
        default_legacy_view = True
    
    # Register as Scene property so it persists with the blend file
    bpy.types.Scene.shapekey_legacy_view = bpy.props.BoolProperty(
        name="Legacy View",
        description="Use legacy 2-column shapekey layout instead of categorized system",
        default=default_legacy_view
    )
    
    # Register preset management properties
    bpy.types.Scene.hhp_preset_items = bpy.props.CollectionProperty(type=HHP_PresetItem)
    bpy.types.Scene.hhp_preset_index = bpy.props.IntProperty(
        name="Active Preset Index",
        description="Index of the currently selected preset in the list",
        default=0
    )
    bpy.types.Collection.show_collection_render = BoolProperty(
         name="",
         description="Toggle Collection Visibility (Viewport and Render)",
         get=get_show_collection_render,
         set=set_show_collection_render
    )
    bpy.types.Object.show_object_render = BoolProperty(
         name="",
         description="Toggle Object Visibility (Viewport and Render)",
         get=get_show_object_render,
         set=set_show_object_render
    )
    bpy.types.Object.active_preset = bpy.props.EnumProperty(
         name="Preset",
         description="Select a preset",
         items=preset_items,
         update=update_active_preset
    )
    # Effects & Shaders expand/collapse states
    wm.effects_shader_fx_expanded = bpy.props.BoolProperty(
        name="Shader FX Expanded",
        description="Whether the Shader FX section is expanded",
        default=True
    )
    wm.effects_makeup_expanded = bpy.props.BoolProperty(
        name="Makeup Expanded", 
        description="Whether the Makeup section is expanded",
        default=False
    )
    wm.effects_fingernails_expanded = bpy.props.BoolProperty(
        name="Fingernails Expanded",
        description="Whether the Fingernails section is expanded", 
        default=False
    )
    wm.effects_toenails_expanded = bpy.props.BoolProperty(
        name="Toenails Expanded",
        description="Whether the Toenails section is expanded",
        default=False
    )

def unregister():
    wm = bpy.types.WindowManager
    del wm.custom_panel_section
    del wm.shapekey_major_category
    del wm.shapekey_subcategory
    del wm.effects_shader_fx_expanded
    del wm.effects_makeup_expanded
    del wm.effects_fingernails_expanded
    del wm.effects_toenails_expanded
    del bpy.types.Scene.shapekey_legacy_view
    del bpy.types.Scene.hhp_preset_items
    del bpy.types.Scene.hhp_preset_index
    
    bpy.utils.unregister_class(HHP_OT_RenamePreset)
    bpy.utils.unregister_class(OT_RemovePreset)
    bpy.utils.unregister_class(HHP_OT_UpdateAllPresets)
    bpy.utils.unregister_class(OT_OverwritePreset)
    bpy.utils.unregister_class(OT_AddPreset)
    bpy.utils.unregister_class(CustomizePanel)
    bpy.utils.unregister_class(HHP_OT_ToggleCustomizePanelSectionMisc)
    bpy.utils.unregister_class(HHP_OT_ToggleCustomizePanelSectionClothing)
    bpy.utils.unregister_class(HHP_OT_ToggleCustomizePanelSectionEffects)
    bpy.utils.unregister_class(HHP_OT_ToggleCustomizePanelSectionShapekeys)
    bpy.utils.unregister_class(HHP_OT_ToggleCustomizePanelSectionInitial)
    
    # Unregister shapekey list classes
    bpy.utils.unregister_class(HHP_OT_AssignMeshShapekeyCategory)
    bpy.utils.unregister_class(HHP_MT_AssignShapekeyCategory)
    bpy.utils.unregister_class(HHP_OT_RemoveMeshShapekey)
    bpy.utils.unregister_class(HHP_OT_CopyMeshShapekey)
    bpy.utils.unregister_class(HHP_OT_AddMeshShapekey)
    bpy.utils.unregister_class(HHP_OT_ToggleLegacyShapekeyView)
    bpy.utils.unregister_class(HHP_OT_SetShapekeySubcategory)
    bpy.utils.unregister_class(HHP_OT_SetShapekeyMajorCategory)
    bpy.utils.unregister_class(HHP_OT_ToggleCustomShapekeyMute)
    bpy.utils.unregister_class(HHP_OT_SetCustomShapekeyValues)
    bpy.utils.unregister_class(HHP_UL_CustomShapekeysList)
    
    # Unregister preset management classes
    bpy.utils.unregister_class(HHP_OT_MovePresetDown)
    bpy.utils.unregister_class(HHP_OT_MovePresetUp)
    bpy.utils.unregister_class(HHP_UL_PresetsList)
    bpy.utils.unregister_class(HHP_PresetItem)
    
    del bpy.types.Collection.show_collection_render
    del bpy.types.Object.show_object_render
    del bpy.types.Object.active_preset

if __name__ == "__main__":
    register()

# ---- Clothing & Outfit Preset Definitions (moved from Clothing_HHP.py) ----

def get_show_collection_render(self):
    return not self.hide_viewport and not self.hide_render

def set_show_collection_render(self, value):
    self.hide_viewport = not value
    self.hide_render = not value

def get_show_object_render(self):
    return not self.hide_viewport and not self.hide_render

def set_show_object_render(self, value):
    self.hide_viewport = not value
    self.hide_render = not value

def capture_collection_state(collection):
    """
    Capture the state of a collection and its objects.
    
    Object states are stored with their full names (including enumeration) to preserve
    enumeration information for intelligent mapping when applying presets.
    """
    state = {
        "hide_viewport": collection.hide_viewport,
        "hide_render": collection.hide_render,
        "objects": {}
    }
    for obj in collection.objects:
        # Store object state with full name to preserve enumeration information
        state["objects"][obj.name] = {
            "hide_viewport": obj.hide_viewport,
            "hide_render": obj.hide_render
        }
    child_states = {}
    for child in collection.children:
        # Store child collection state with full name to preserve enumeration
        child_states[child.name] = capture_collection_state(child)
    if child_states:
        state["child_collections"] = child_states
    return state

def find_character_hhp_collection(active_obj):
    """
    Find the specific character HHP collection that contains the active object.
    
    This is critical for ensuring presets only work within their own character's collection,
    preventing cross-contamination between different characters in the scene.
    
    Returns the character collection (e.g., "Char (HHP)", "Char HHP", "Char (F)") 
    that contains the active object, or None if not found.
    """
    if not active_obj:
        return None
    
    # Walk up the collection hierarchy to find a collection starting with "Char (HHP)" or "Char HHP"
    for collection in active_obj.users_collection:
        current_collection = collection
        while current_collection:
            if (current_collection.name.startswith("Char (HHP)") or 
                current_collection.name.startswith("Char HHP") or
                current_collection.name.startswith("Char (F)")):
                return current_collection
            # Check if this collection has a parent by looking through all collections
            parent_collection = None
            for potential_parent in bpy.data.collections:
                if current_collection in potential_parent.children.values():
                    parent_collection = potential_parent
                    break
            current_collection = parent_collection
    return None

def get_base_name(name):
    """
    Get the base name of a collection or object, removing Blender's automatic enumeration suffix.
    
    Examples:
    - "Clothes" -> "Clothes"
    - "Clothes.001" -> "Clothes"
    - "shirt.002" -> "shirt"
    - "Appendages.005" -> "Appendages"
    """
    if '.' in name:
        # Check if the part after the last dot is a number (Blender's enumeration)
        parts = name.rsplit('.', 1)
        if len(parts) == 2 and parts[1].isdigit():
            return parts[0]
    return name

def get_enumeration_number(name):
    """
    Get the enumeration number from a name, or 0 if no enumeration.
    
    Examples:
    - "Clothes" -> 0
    - "Clothes.001" -> 1
    - "shirt.002" -> 2
    - "Appendages.005" -> 5
    """
    if '.' in name:
        parts = name.rsplit('.', 1)
        if len(parts) == 2 and parts[1].isdigit():
            return int(parts[1])
    return 0

def sort_by_enumeration(names):
    """
    Sort a list of names by their enumeration numbers.
    
    Examples:
    - ["Clothes.003", "Clothes.001", "Clothes.002"] -> ["Clothes.001", "Clothes.002", "Clothes.003"]
    - ["shirt", "shirt.002", "shirt.001"] -> ["shirt", "shirt.001", "shirt.002"]
    """
    return sorted(names, key=get_enumeration_number)

def get_base_collection_name(collection_name):
    """
    Get the base name of a collection, removing Blender's automatic enumeration suffix.
    
    This is a wrapper around get_base_name for backwards compatibility.
    """
    return get_base_name(collection_name)

def capture_outfit_preset(context):
    """
    Capture the current state of clothes and appendages collections for the active character only.
    
    This function now scopes to only the specific character HHP collection that contains
    the active object, preventing presets from affecting other characters in the scene.
    
    Collection names are stored with their full names (including enumeration) to preserve
    enumeration information for intelligent mapping when applying presets.
    
    INTELLIGENT ENUMERATION SYSTEM:
    When the same character is appended multiple times, Blender automatically enumerates
    collections and objects (e.g., "Clothes.001", "Clothes.002", "shirt.001", etc.).
    
    This system preserves the enumeration information so that when applying presets:
    - If preset has ["Clothes.002", "Clothes.003", "Clothes.004"]
    - And target has ["Clothes.011", "Clothes.012", "Clothes.013"]  
    - It maps: .002→.011, .003→.012, .004→.013 (nth to nth based on enumeration order)
    
    This ensures presets work correctly across multiple character instances with different
    enumeration suffixes while maintaining precise control over which items are affected.
    """
    active_obj = context.active_object
    presets = {"Clothes": {}, "Appendages": {}}
    if not active_obj:
        return presets
    
    # Find the specific character HHP collection for this object
    char_collection = find_character_hhp_collection(active_obj)
    if not char_collection:
        return presets
    
    # Only look within this specific character collection's hierarchy
    def search_collections_recursive(collection):
        for sub_collection in collection.children:
            if sub_collection.name.startswith("Clothes"):
                # Store with full name to preserve enumeration information
                presets["Clothes"][sub_collection.name] = capture_collection_state(sub_collection)
            elif sub_collection.name.startswith("Appendages"):
                # Store with full name to preserve enumeration information
                presets["Appendages"][sub_collection.name] = capture_collection_state(sub_collection)
            # Recursively search child collections
            search_collections_recursive(sub_collection)
    
    search_collections_recursive(char_collection)
    return presets

def apply_child_collections_state(child_data, char_collection_names=None):
    """
    Apply child collection states with support for enumerated collection names.
    
    This function uses intelligent enumeration mapping to handle cases where child 
    collections might have been enumerated by Blender when the same character 
    was appended multiple times.
    """
    # If char_collection_names is not provided, get them from the current active object
    if char_collection_names is None:
        active_obj = bpy.context.active_object
        if not active_obj:
            return
        char_collection = find_character_hhp_collection(active_obj)
        if not char_collection:
            return
        
        char_collection_names = set()
        def collect_names_recursive(collection):
            char_collection_names.add(collection.name)
            for child in collection.children:
                collect_names_recursive(child)
        collect_names_recursive(char_collection)
    
    # Get all preset collection names
    preset_collection_names = list(child_data.keys())
    
    # Find matching collections using enumeration mapping
    collection_mappings = find_matching_collections_by_enumeration_mapping(preset_collection_names, char_collection_names)
    
    for preset_name, coll in collection_mappings:
        state = child_data[preset_name]
        coll.hide_viewport = state.get("hide_viewport", coll.hide_viewport)
        coll.hide_render = state.get("hide_render", coll.hide_render)
        
        # Apply object states using enumeration mapping
        preset_obj_names = list(state.get("objects", {}).keys())
        object_mappings = find_matching_object_by_enumeration_mapping(preset_obj_names, coll)
        
        for preset_obj_name, obj in object_mappings:
            obj_state = state["objects"][preset_obj_name]
            obj.hide_viewport = obj_state.get("hide_viewport", obj.hide_viewport)
            obj.hide_render = obj_state.get("hide_render", obj.hide_render)
        
        if "child_collections" in state:
            apply_child_collections_state(state["child_collections"], char_collection_names)

def group_items_by_base_name(item_names):
    """
    Group item names by their base names.
    
    Returns a dictionary where keys are base names and values are lists of full names.
    Example: {"Clothes": ["Clothes", "Clothes.001", "Clothes.002"]}
    """
    groups = {}
    for name in item_names:
        base_name = get_base_name(name)
        if base_name not in groups:
            groups[base_name] = []
        groups[base_name].append(name)
    
    # Sort each group by enumeration
    for base_name in groups:
        groups[base_name] = sort_by_enumeration(groups[base_name])
    
    return groups

def create_enumeration_mapping(preset_names, target_names):
    """
    Create a mapping between preset names and target names based on enumeration order.
    
    For each base name, maps the nth preset item to the nth target item.
    
    Example:
    - preset_names: ["Clothes.002", "Clothes.003", "Clothes.004"]
    - target_names: ["Clothes.011", "Clothes.012", "Clothes.013"]
    - result: {"Clothes.002": "Clothes.011", "Clothes.003": "Clothes.012", "Clothes.004": "Clothes.013"}
    """
    mapping = {}
    
    # Group both preset and target names by base name
    preset_groups = group_items_by_base_name(preset_names)
    target_groups = group_items_by_base_name(target_names)
    
    # Create mappings for each base name group
    for base_name in preset_groups:
        if base_name in target_groups:
            preset_list = preset_groups[base_name]
            target_list = target_groups[base_name]
            
            # Map in order: first preset to first target, second to second, etc.
            for i, preset_name in enumerate(preset_list):
                if i < len(target_list):
                    mapping[preset_name] = target_list[i]
    
    return mapping

def find_matching_collections_by_enumeration_mapping(preset_names, char_collection_names):
    """
    Find collections using intelligent enumeration mapping.
    
    This handles cases where there are multiple collections with the same base name,
    mapping them based on their enumeration order.
    """
    # Get collections that exist in the character hierarchy
    existing_target_names = []
    for collection_name in char_collection_names:
        if bpy.data.collections.get(collection_name):
            existing_target_names.append(collection_name)
    
    # Create enumeration mapping
    mapping = create_enumeration_mapping(preset_names, existing_target_names)
    
    # Return collections based on mapping
    result = []
    for preset_name in preset_names:
        if preset_name in mapping:
            target_name = mapping[preset_name]
            coll = bpy.data.collections.get(target_name)
            if coll:
                result.append((preset_name, coll))
    
    return result

def find_matching_object_by_enumeration_mapping(preset_obj_names, collection):
    """
    Find objects in a collection using intelligent enumeration mapping.
    
    This handles cases where there are multiple objects with the same base name,
    mapping them based on their enumeration order.
    """
    # Get object names that exist in the collection
    existing_obj_names = [obj.name for obj in collection.objects]
    
    # Create enumeration mapping
    mapping = create_enumeration_mapping(preset_obj_names, existing_obj_names)
    
    # Return objects based on mapping
    result = []
    for preset_obj_name in preset_obj_names:
        if preset_obj_name in mapping:
            target_name = mapping[preset_obj_name]
            for obj in collection.objects:
                if obj.name == target_name:
                    result.append((preset_obj_name, obj))
                    break
    
    return result

def apply_outfit_preset(preset_data):
    """
    Apply outfit preset data to the active character only.
    
    This function now ensures that presets only affect collections within the same
    character HHP collection hierarchy, preventing cross-contamination between characters.
    
    It uses intelligent enumeration mapping to handle cases where the same character
    is appended multiple times with different enumeration suffixes.
    
    ENUMERATION MAPPING PROCESS:
    1. Groups preset items and target items by base name
    2. Sorts each group by enumeration number (0, 1, 2, 3...)
    3. Maps nth preset item to nth target item within each base name group
    4. Applies states only to successfully mapped items
    
    This allows presets to work seamlessly across character instances regardless
    of their enumeration suffixes while maintaining precise item-to-item mapping.
    """
    active_obj = bpy.context.active_object
    if not active_obj:
        return
    
    # Find the specific character HHP collection for this object
    char_collection = find_character_hhp_collection(active_obj)
    if not char_collection:
        return
    
    # Create a set of all collection names within this character's hierarchy
    char_collection_names = set()
    def collect_names_recursive(collection):
        char_collection_names.add(collection.name)
        for child in collection.children:
            collect_names_recursive(child)
    
    collect_names_recursive(char_collection)
    
    for category, collections_data in preset_data.items():
        # Get all preset collection names for this category
        preset_collection_names = list(collections_data.keys())
        
        # Find matching collections using enumeration mapping
        collection_mappings = find_matching_collections_by_enumeration_mapping(preset_collection_names, char_collection_names)
        
        for preset_name, coll in collection_mappings:
            state = collections_data[preset_name]
            coll.hide_viewport = state.get("hide_viewport", coll.hide_viewport)
            coll.hide_render = state.get("hide_render", coll.hide_render)
            
            # Apply object states using enumeration mapping
            preset_obj_names = list(state.get("objects", {}).keys())
            object_mappings = find_matching_object_by_enumeration_mapping(preset_obj_names, coll)
            
            for preset_obj_name, obj in object_mappings:
                obj_state = state["objects"][preset_obj_name]
                obj.hide_viewport = obj_state.get("hide_viewport", obj.hide_viewport)
                obj.hide_render = obj_state.get("hide_render", obj.hide_render)
            
            if "child_collections" in state:
                apply_child_collections_state(state["child_collections"], char_collection_names)

def update_active_preset(self, context):
    preset_name = self.active_preset
    if "presets" not in self:
        return
    presets = self["presets"]
    if preset_name not in presets:
        return
    preset_data = presets[preset_name]
    apply_preset(preset_data)

def preset_items(self, context):
    obj = context.object
    if not obj or "presets" not in obj or not obj["presets"]:
        return [("NONE", "None", "No presets available")]
    return [(name, name, "") for name in obj["presets"].keys()]

# Operator classes for outfit preset management

class OT_AddPreset(bpy.types.Operator):
    bl_idname = "object.add_preset"
    bl_label = "Add Preset"
    bl_description = "Add a new preset"
    
    preset_name: bpy.props.StringProperty(
        name="Preset Name",
        default="Original File",
        options={'SKIP_SAVE'}
    )
    
    def invoke(self, context, event):
        active_obj = context.active_object
        if not active_obj:
            # No active object: use "Original File" as a safe default label
            self.preset_name = "Original File"
        else:
            presets = active_obj.get("presets", {})
            # If no presets are found on this object, first preset defaults to "Original File"
            if not presets:
                self.preset_name = "Original File"
            else:
                # Check if there's a current preset selected
                current_preset = getattr(active_obj, 'active_preset', 'NONE')
                if current_preset != 'NONE' and current_preset in presets:
                    # If the current preset is literally "Original File", suggest "New Preset" instead
                    if current_preset == "Original File":
                        self.preset_name = "New Preset"
                    else:
                        # Use the same name as the current preset
                        self.preset_name = current_preset
                else:
                    # There are presets but no valid active one → use generic new name
                    self.preset_name = "New Preset"
        
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=450)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Add New Preset", icon='ADD')
        layout.separator()
        
        # Preset name input
        layout.prop(self, "preset_name")
        layout.separator()
        
        # Information about what will be captured
        info_box = layout.box()
        info_col = info_box.column(align=True)
        info_col.label(text="This preset will capture:", icon='INFO')
        info_col.label(text="• Categorized shapekeys")
        info_col.label(text="• Clothing and appendages collections")
        info_col.label(text="• Effects & shader properties")
        info_col.label(text="• Makeup, fingernails & toenails values")
        info_col.label(text="• Misc properties")
        
        layout.separator()
        note_box = layout.box()
        note_col = note_box.column(align=True)
        note_col.label(text="Note: Initial setup properties are not included", icon='INFO')
        note_col.label(text="in presets as they are initialization settings.")
    
    def execute(self, context):
        active_obj = context.active_object
        if not active_obj:
            self.report({'WARNING'}, "No active object.")
            return {'CANCELLED'}
        preset_data = capture_preset(context)
        if "presets" not in active_obj:
            active_obj["presets"] = {}
        presets = active_obj["presets"]
        
        # Handle name conflicts by auto-enumerating
        final_name = self.preset_name
        if final_name in presets:
            # Remove existing enumeration if present to get base name
            import re
            base_name = re.sub(r'\.\d{3}$', '', final_name)
            
            # Find next available enumeration number
            counter = 1
            final_name = f"{base_name}.{counter:03d}"
            while final_name in presets:
                counter += 1
                final_name = f"{base_name}.{counter:03d}"
        
        presets[final_name] = preset_data
        active_obj.active_preset = final_name
        
        # Show appropriate message
        if final_name != self.preset_name:
            self.report({'INFO'}, f"Preset '{final_name}' added (auto-enumerated from '{self.preset_name}').")
        else:
            self.report({'INFO'}, f"Preset '{final_name}' added.")
        
        return {'FINISHED'}

class OT_RemovePreset(bpy.types.Operator):
    bl_idname = "object.remove_preset"
    bl_label = "Remove Preset"
    bl_description = "Remove the selected preset"
    
    def invoke(self, context, event):
        active_obj = context.active_object
        if not active_obj:
            self.report({'WARNING'}, "No active object.")
            return {'CANCELLED'}
        if "presets" not in active_obj:
            self.report({'WARNING'}, "No presets to remove.")
            return {'CANCELLED'}
        preset_name = active_obj.active_preset
        if preset_name not in active_obj["presets"]:
            self.report({'WARNING'}, "Selected preset not found.")
            return {'CANCELLED'}
        
        # Show simple confirmation dialog
        return context.window_manager.invoke_confirm(self, event)
    
    def draw(self, context):
        # Not needed for simple confirmation
        pass
    
    def execute(self, context):
        active_obj = context.active_object
        if not active_obj:
            self.report({'WARNING'}, "No active object.")
            return {'CANCELLED'}
        if "presets" not in active_obj:
            self.report({'WARNING'}, "No presets to remove.")
            return {'CANCELLED'}
        presets = active_obj["presets"]
        preset_name = active_obj.active_preset
        if preset_name not in presets:
            self.report({'WARNING'}, "Selected preset not found.")
            return {'CANCELLED'}
        del presets[preset_name]
        if presets:
            active_obj.active_preset = list(presets.keys())[0]
        else:
            active_obj.active_preset = "NONE"
        self.report({'INFO'}, f"Preset '{preset_name}' removed.")
        return {'FINISHED'}

# -------------------------------------------------------------------
# Preset Management Classes - PropertyGroup and UIList
# -------------------------------------------------------------------

class HHP_PresetItem(bpy.types.PropertyGroup):
    """Property group for preset items in the UIList"""
    name: bpy.props.StringProperty(
        name="Preset Name",
        description="Name of the preset",
        default="",
        update=lambda self, context: None  # We'll handle updates manually
    )
    original_name: bpy.props.StringProperty(
        name="Original Name",
        description="Original name of the preset for tracking renames",
        default=""
    )

class HHP_UL_PresetsList(UIList):
    """UIList for preset management with inline renaming"""
    
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        preset_name = item.name
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            # Split layout to show number on the left
            split = layout.split(factor=0.1, align=True)
            
            # Left side - preset number
            split.label(text=f"{index + 1}.")
            
            # Right side - allow inline editing of preset names like modifiers
            split.prop(item, "name", text="", emboss=False, icon='PRESET')
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon='PRESET')

class HHP_OT_MovePresetUp(bpy.types.Operator):
    """Move preset up in the list"""
    bl_idname = "hhp.move_preset_up"
    bl_label = "Move Preset Up"
    bl_description = "Move the preset up in the list"
    bl_options = {'REGISTER'}
    
    index: bpy.props.IntProperty()
    
    @classmethod
    def poll(cls, context):
        return (context.active_object and 
                "presets" in context.active_object and 
                len(context.scene.hhp_preset_items) > 1)
    
    def execute(self, context):
        active_obj = context.active_object
        preset_list = context.scene.hhp_preset_items
        
        if self.index <= 0 or self.index >= len(preset_list):
            return {'CANCELLED'}
        
        # Swap items in the preset list
        preset_list.move(self.index, self.index - 1)
        
        # Rebuild the presets dictionary in the new order
        rebuild_presets_dict_from_list(context)
        
        # Update the active index
        context.scene.hhp_preset_index = self.index - 1
        
        return {'FINISHED'}

class HHP_OT_MovePresetDown(bpy.types.Operator):
    """Move preset down in the list"""
    bl_idname = "hhp.move_preset_down"
    bl_label = "Move Preset Down"
    bl_description = "Move the preset down in the list"
    bl_options = {'REGISTER'}
    
    index: bpy.props.IntProperty()
    
    @classmethod
    def poll(cls, context):
        return (context.active_object and 
                "presets" in context.active_object and 
                len(context.scene.hhp_preset_items) > 1)
    
    def execute(self, context):
        active_obj = context.active_object
        preset_list = context.scene.hhp_preset_items
        
        if self.index < 0 or self.index >= len(preset_list) - 1:
            return {'CANCELLED'}
        
        # Swap items in the preset list
        preset_list.move(self.index, self.index + 1)
        
        # Rebuild the presets dictionary in the new order
        rebuild_presets_dict_from_list(context)
        
        # Update the active index
        context.scene.hhp_preset_index = self.index + 1
        
        return {'FINISHED'}

def rebuild_presets_dict_from_list(context):
    """Helper function to rebuild the presets dictionary based on the current list order"""
    active_obj = context.active_object
    if not active_obj or "presets" not in active_obj:
        return
    
    old_presets = active_obj["presets"]
    new_presets = {}
    
    for item in context.scene.hhp_preset_items:
        if item.name in old_presets:
            new_presets[item.name] = old_presets[item.name]
        # Handle renamed presets
        elif item.original_name in old_presets:
            new_presets[item.name] = old_presets[item.original_name]
    
    active_obj["presets"] = new_presets

def sync_preset_list_with_object(context):
    """Helper function to sync the UIList with the active object's presets"""
    active_obj = context.active_object
    
    # Clear existing list
    context.scene.hhp_preset_items.clear()
    
    if not active_obj or "presets" not in active_obj:
        return
    
    presets = active_obj["presets"]
    
    # Add presets to the list in current order
    for preset_name in presets.keys():
        item = context.scene.hhp_preset_items.add()
        item.name = preset_name
        item.original_name = preset_name
    
    # Set active index
    current_preset = active_obj.active_preset
    for i, item in enumerate(context.scene.hhp_preset_items):
        if item.name == current_preset:
            context.scene.hhp_preset_index = i
            break

class HHP_OT_RenamePreset(bpy.types.Operator):
    """Manage presets - rename and reorder"""
    bl_idname = "object.rename_preset"
    bl_label = "Manage Presets"
    bl_description = "Manage presets - rename and reorder like modifiers"
    bl_options = {'REGISTER'}
    
    def invoke(self, context, event):
        # Populate the preset list from the active object
        sync_preset_list_with_object(context)
        return context.window_manager.invoke_props_dialog(self, width=400)
    
    def draw(self, context):
        layout = self.layout
        active_obj = context.active_object
        
        if not active_obj or "presets" not in active_obj or not active_obj["presets"]:
            layout.label(text="No presets to manage", icon='INFO')
            return
        
        # Title
        layout.label(text="Manage Presets", icon='PRESET')
        layout.separator()
        
        # Preset list with controls
        row = layout.row()
        col = row.column()
        
        # List display
        col.template_list(
            "HHP_UL_PresetsList", "",
            context.scene, "hhp_preset_items",
            context.scene, "hhp_preset_index",
            rows=12
        )
        
        # Move buttons column
        col2 = row.column(align=True)
        col2.operator("hhp.move_preset_up", text="", icon='TRIA_UP').index = context.scene.hhp_preset_index
        col2.operator("hhp.move_preset_down", text="", icon='TRIA_DOWN').index = context.scene.hhp_preset_index
        
        layout.separator()
        
        # Instructions
        box = layout.box()
        box_col = box.column(align=True)
        box_col.label(text="Instructions:", icon='INFO')
        box_col.label(text="• Click on preset names to rename them")
        box_col.label(text="• Use arrows to reorder presets")
        box_col.label(text="• Changes are applied immediately")
    
    def execute(self, context):
        # Apply any pending name changes
        self.apply_name_changes(context)
        return {'FINISHED'}
    

    
    def apply_name_changes(self, context):
        """Apply any name changes to the actual presets"""
        active_obj = context.active_object
        if not active_obj or "presets" not in active_obj:
            return
        
        old_presets = active_obj["presets"]
        new_presets = {}
        current_active = active_obj.active_preset
        new_active = current_active
        
        for item in context.scene.hhp_preset_items:
            old_name = item.original_name
            new_name = item.name
            
            # Validate new name
            if new_name != old_name and new_name in old_presets:
                # Name collision - revert to original
                item.name = old_name
                new_name = old_name
            
            if old_name in old_presets:
                new_presets[new_name] = old_presets[old_name]
                
                # Update active preset if it was renamed
                if current_active == old_name:
                    new_active = new_name
        
        # Update the object
        active_obj["presets"] = new_presets
        active_obj.active_preset = new_active

# New operator to overwrite the current preset
class OT_OverwritePreset(bpy.types.Operator):
    bl_idname = "object.overwrite_preset"
    bl_label = "Overwrite Preset"
    bl_description = "Overwrite the current selected preset with the current settings"

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Overwrite preset?")

    def execute(self, context):
        active_obj = context.active_object
        if not active_obj:
            self.report({'WARNING'}, "No active object.")
            return {'CANCELLED'}
        preset_name = active_obj.active_preset
        if preset_name == "NONE" or "presets" not in active_obj or preset_name not in active_obj["presets"]:
            self.report({'WARNING'}, "No preset selected to overwrite.")
            return {'CANCELLED'}
        preset_data = capture_preset(context)
        active_obj["presets"][preset_name] = preset_data
        self.report({'INFO'}, f"Preset '{preset_name}' updated.")
        return {'FINISHED'}

# New function to capture the full preset data (except MISC)
def capture_preset(context):
    active_obj = context.active_object
    data = {}
    # Capture collections state
    data["collections"] = capture_outfit_preset(context)

    # Note: INITIAL_SETUP properties are excluded from presets as they are initialization settings

    # Capture EFFECTS_SHADERS properties
    effects_shaders_keys = [
         "Feet Dirt", "Gens used", "Goosebumps", "Hand Veins", "Piercing Bumps",
         "Tan Lines", "Throat Bulge (Color)", "Throat Bulge (Neck Bump)",
         "Throat Bulge (SK Deform)", "Throat Bulge (Veins Bump)", "Vascularity",
         "Wetness", "Wetness (Switch)"
    ]
    data["effects_shaders"] = {}
    for key in effects_shaders_keys:
         if key in active_obj.keys():
              data["effects_shaders"][key] = active_obj[key]

    # Capture SHAPEKEY_MORPHS values - capture all categorized shapekeys
    data["shapekeys"] = {}
    if active_obj.data and active_obj.data.shape_keys and active_obj.data.shape_keys.key_blocks:
         sk_block = active_obj.data.shape_keys.key_blocks
         # Capture only categorized shapekeys (Hot List + all prefixed categories)
         categorized_keys = get_all_categorized_shapekeys(sk_block)
         for key in categorized_keys:
             if key in sk_block:
                 data["shapekeys"][key] = sk_block[key].value

    # Capture MISC properties - all user-defined keys that are not allocated, excluding "orig_subsurface" and "presets"
    initial_setup_keys = [
         "Displace Deform Proxy",
         "Displace Clothing",
         "Base Color (Switch)",
         "Normal (Switch)",
         "Hue",
         "Saturation",
         "Value",
         "Eye socket push back", "Correct Eyelids",
         "Detail Bump - Face", "Detail Bump",
         "Micro Skin Detail", "Pore Skin Detail",
         "Normal Contrast (Face)", "Normal Contrast (Body)",
         "Normal Contrast (Genitals)", "Normal Contrast (Clavicle)",
         "Subsurface", "Max Roughness",
         "Abs"
    ]
    allocated_props = set(initial_setup_keys) | set(effects_shaders_keys)
    all_custom_props = set(active_obj.keys())
    built_in_props = set(p.identifier for p in active_obj.bl_rna.properties)
    misc_keys = [ key for key in sorted(all_custom_props - built_in_props)
                  if key not in allocated_props and key not in {"orig_subsurface", "presets"} and not key.startswith('_') ]
    data["misc"] = {}
    for key in misc_keys:
         data["misc"][key] = active_obj[key]

    # Capture NODE_GROUPS values - makeup, fingernails, toenails
    data["node_groups"] = {}
    
    # Capture Makeup node group
    makeup_values = capture_node_group_inputs(active_obj, "Makeup_HHP", ["Base Color", "Roughness"])
    if makeup_values:
        data["node_groups"]["makeup"] = makeup_values
    
    # Capture Fingernails node group
    fingernails_values = capture_node_group_inputs_in_material(active_obj, "Genesis 8 Female_Fingernails", "Fingernails (HHP)", [])
    if fingernails_values:
        data["node_groups"]["fingernails"] = fingernails_values
    
    # Capture Toenails node group
    toenails_values = capture_node_group_inputs_in_material(active_obj, "Genesis 8 Female_Toenails", "Toenails (HHP)", [])
    if toenails_values:
        data["node_groups"]["toenails"] = toenails_values

    return data

# New function to apply a preset (collections + custom properties)
def apply_preset(preset_data):
    active_obj = bpy.context.active_object
    if not active_obj:
         return
    # Apply collections state
    if "collections" in preset_data:
         apply_outfit_preset(preset_data["collections"])
    # Note: INITIAL_SETUP properties are not applied from presets
    # Apply EFFECTS_SHADERS custom properties
    if "effects_shaders" in preset_data:
         for key, value in preset_data["effects_shaders"].items():
              active_obj[key] = value
    # Apply SHAPEKEY_MORPHS values
    if "shapekeys" in preset_data and active_obj.data and active_obj.data.shape_keys:
         for key, value in preset_data["shapekeys"].items():
              if key in active_obj.data.shape_keys.key_blocks:
                     active_obj.data.shape_keys.key_blocks[key].value = value
    # Apply MISC properties
    if "misc" in preset_data:
         for key, value in preset_data["misc"].items():
              active_obj[key] = value
    
    # Apply NODE_GROUPS values - makeup, fingernails, toenails
    if "node_groups" in preset_data:
        node_groups_data = preset_data["node_groups"]
        
        # Apply Makeup node group
        if "makeup" in node_groups_data:
            apply_node_group_inputs(active_obj, "Makeup_HHP", ["Base Color", "Roughness"], node_groups_data["makeup"])
        
        # Apply Fingernails node group
        if "fingernails" in node_groups_data:
            apply_node_group_inputs_in_material(active_obj, "Genesis 8 Female_Fingernails", "Fingernails (HHP)", [], node_groups_data["fingernails"])
        
        # Apply Toenails node group
        if "toenails" in node_groups_data:
            apply_node_group_inputs_in_material(active_obj, "Genesis 8 Female_Toenails", "Toenails (HHP)", [], node_groups_data["toenails"])

class HHP_OT_UpdateAllPresets(bpy.types.Operator):
    """Update all presets to include newly added items"""
    bl_idname = "object.update_all_presets"
    bl_label = "Update All Presets"
    bl_description = "Update all existing presets to include newly added shapekeys, clothing, and other items"
    bl_options = {'REGISTER', 'UNDO'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=500)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Update All Presets", icon='FILE_REFRESH')
        layout.separator()
        
        # Warning box
        warning_box = layout.box()
        warning_box.alert = True
        warning_col = warning_box.column(align=True)
        warning_col.label(text="⚠ SAVE YOUR FILE BEFORE PROCEEDING!", icon='ERROR')
        warning_col.label(text="This will modify all existing presets.")
        
        layout.separator()
        
        # Information
        info_box = layout.box()
        info_col = info_box.column(align=True)
        info_col.label(text="This will update all presets to include:", icon='INFO')
        info_col.label(text="• Newly added categorized shapekeys")
        info_col.label(text="• New clothing and appendages collections")
        info_col.label(text="• New effects & shader properties")
        info_col.label(text="• New makeup, fingernails & toenails values")
        info_col.label(text="• New misc properties")
        layout.separator()
        info_col.label(text="New items will use their current values/states.")
        info_col.label(text="Changed values (relative to the active preset) will be applied to all presets.")
    
    def execute(self, context):
        active_obj = context.active_object
        if not active_obj:
            self.report({'WARNING'}, "No active object.")
            return {'CANCELLED'}
        
        if "presets" not in active_obj or not active_obj["presets"]:
            self.report({'WARNING'}, "No presets found to update.")
            return {'CANCELLED'}
        
        # Get current state to identify new items
        current_data = capture_preset(context)
        presets = active_obj["presets"]
        updated_count = 0
        
        # Compute delta relative to the active preset: only what changed compared to it
        active_preset_name = getattr(active_obj, 'active_preset', 'NONE')
        active_preset_data = presets.get(active_preset_name) if active_preset_name in presets else None
        
        def values_differ(a, b):
            # Numeric tolerance-aware comparison for floats and sequences
            try:
                import math
                # If both are sequences (e.g., color/vec), compare element-wise
                if hasattr(a, '__iter__') and hasattr(b, '__iter__'):
                    a_list = list(a)
                    b_list = list(b)
                    if len(a_list) != len(b_list):
                        return True
                    for av, bv in zip(a_list, b_list):
                        if isinstance(av, float) or isinstance(bv, float):
                            if not math.isfinite(float(av)) or not math.isfinite(float(bv)):
                                if av != bv:
                                    return True
                            else:
                                if abs(float(av) - float(bv)) > 1e-6:
                                    return True
                        else:
                            if av != bv:
                                return True
                    return False
                # Floats
                if isinstance(a, float) or isinstance(b, float):
                    if not math.isfinite(float(a)) or not math.isfinite(float(b)):
                        return a != b
                    return abs(float(a) - float(b)) > 1e-6
            except Exception:
                pass
            # Fallback exact compare
            return a != b
        
        def build_diff(current, baseline):
            diff = {}
            if not current:
                return diff
            baseline = baseline or {}
            
            # shapekeys
            if "shapekeys" in current:
                for sk, val in current["shapekeys"].items():
                    base_val = (baseline.get("shapekeys", {}) or {}).get(sk)
                    if base_val is None or values_differ(val, base_val):
                        diff.setdefault("shapekeys", {})[sk] = val
            
            # effects_shaders
            if "effects_shaders" in current:
                for k, val in current["effects_shaders"].items():
                    base_val = (baseline.get("effects_shaders", {}) or {}).get(k)
                    if base_val is None or values_differ(val, base_val):
                        diff.setdefault("effects_shaders", {})[k] = val
            
            # misc
            if "misc" in current:
                for k, val in current["misc"].items():
                    base_val = (baseline.get("misc", {}) or {}).get(k)
                    if base_val is None or values_differ(val, base_val):
                        diff.setdefault("misc", {})[k] = val
            
            # node_groups (two-level)
            if "node_groups" in current:
                for group_name, inputs in current["node_groups"].items():
                    base_group = (baseline.get("node_groups", {}) or {}).get(group_name, {})
                    for inp_name, inp_val in inputs.items():
                        base_val = base_group.get(inp_name)
                        if base_val is None or values_differ(inp_val, base_val):
                            diff.setdefault("node_groups", {}).setdefault(group_name, {})[inp_name] = inp_val
            
            # collections: propagate changed states vs baseline (visibility flags and entire collection state)
            if "collections" in current:
                base_collections = baseline.get("collections", {}) if baseline else {}
                for cat, colls in current["collections"].items():
                    base_cat = base_collections.get(cat, {})
                    for coll_name, coll_state in colls.items():
                        base_coll = base_cat.get(coll_name)
                        
                        # If collection doesn't exist in baseline, include entire state as a change
                        if not base_coll:
                            diff.setdefault("collections", {}).setdefault(cat, {})[coll_name] = coll_state
                            continue
                        
                        # Compare top-level flags if present
                        for flag in ("hide_viewport", "hide_render"):
                            cur_v = coll_state.get(flag)
                            base_v = base_coll.get(flag)
                            if cur_v is not None and (base_v is None or cur_v != base_v):
                                diff.setdefault("collections", {}).setdefault(cat, {}).setdefault(coll_name, {})[flag] = cur_v
                        
                        # Objects visibility state
                        cur_objs = coll_state.get("objects", {}) or {}
                        base_objs = base_coll.get("objects", {}) or {}
                        for obj_name, obj_state in cur_objs.items():
                            base_obj_state = base_objs.get(obj_name, {})
                            for flag in ("hide_viewport", "hide_render"):
                                cur_v = obj_state.get(flag)
                                base_v = base_obj_state.get(flag)
                                if cur_v is not None and (base_v is None or cur_v != base_v):
                                    diff.setdefault("collections", {}).setdefault(cat, {}).setdefault(coll_name, {}).setdefault("objects", {}).setdefault(obj_name, {})[flag] = cur_v
                        
                        # Child collections state
                        cur_children = coll_state.get("child_collections", {}) or {}
                        base_children = base_coll.get("child_collections", {}) or {}
                        for child_name, child_state in cur_children.items():
                            base_child = base_children.get(child_name)
                            
                            # If child doesn't exist in baseline, include entire state
                            if not base_child:
                                diff.setdefault("collections", {}).setdefault(cat, {}).setdefault(coll_name, {}).setdefault("child_collections", {})[child_name] = child_state
                                continue
                            
                            # Compare child collection flags
                            for flag in ("hide_viewport", "hide_render"):
                                cur_v = child_state.get(flag)
                                base_v = base_child.get(flag)
                                if cur_v is not None and (base_v is None or cur_v != base_v):
                                    diff.setdefault("collections", {}).setdefault(cat, {}).setdefault(coll_name, {}).setdefault("child_collections", {}).setdefault(child_name, {})[flag] = cur_v
                            
                            # Child objects visibility
                            cur_child_objs = child_state.get("objects", {}) or {}
                            base_child_objs = base_child.get("objects", {}) or {}
                            for obj_name, obj_state in cur_child_objs.items():
                                base_obj_state = base_child_objs.get(obj_name, {})
                                for flag in ("hide_viewport", "hide_render"):
                                    cur_v = obj_state.get(flag)
                                    base_v = base_obj_state.get(flag)
                                    if cur_v is not None and (base_v is None or cur_v != base_v):
                                        diff.setdefault("collections", {}).setdefault(cat, {}).setdefault(coll_name, {}).setdefault("child_collections", {}).setdefault(child_name, {}).setdefault("objects", {}).setdefault(obj_name, {})[flag] = cur_v
            
            return diff
        
        diff_from_active = build_diff(current_data, active_preset_data) if active_preset_data else {}
        
        for preset_name, preset_data in presets.items():
            # Track if this preset was modified
            modified = False
            
            # First, apply differences relative to the active preset (so all presets get the same changes)
            if diff_from_active:
                # shapekeys
                for sk, val in (diff_from_active.get("shapekeys", {}) or {}).items():
                    if "shapekeys" not in preset_data:
                        preset_data["shapekeys"] = {}
                    needs_set = True
                    try:
                        prev = preset_data["shapekeys"][sk]
                        needs_set = prev != val
                    except Exception:
                        needs_set = True
                    if needs_set:
                        preset_data["shapekeys"][sk] = val
                        modified = True
                # effects_shaders
                for k, val in (diff_from_active.get("effects_shaders", {}) or {}).items():
                    if "effects_shaders" not in preset_data:
                        preset_data["effects_shaders"] = {}
                    needs_set = True
                    try:
                        prev = preset_data["effects_shaders"][k]
                        needs_set = prev != val
                    except Exception:
                        needs_set = True
                    if needs_set:
                        preset_data["effects_shaders"][k] = val
                        modified = True
                # misc
                for k, val in (diff_from_active.get("misc", {}) or {}).items():
                    if "misc" not in preset_data:
                        preset_data["misc"] = {}
                    needs_set = True
                    try:
                        prev = preset_data["misc"][k]
                        needs_set = prev != val
                    except Exception:
                        needs_set = True
                    if needs_set:
                        preset_data["misc"][k] = val
                        modified = True
                # node_groups
                for gname, inputs in (diff_from_active.get("node_groups", {}) or {}).items():
                    if "node_groups" not in preset_data:
                        preset_data["node_groups"] = {}
                    if gname not in preset_data["node_groups"]:
                        preset_data["node_groups"][gname] = {}
                    group = preset_data["node_groups"][gname]
                    for iname, ival in inputs.items():
                        needs_set = True
                        try:
                            prev = group[iname]
                            needs_set = prev != ival
                        except Exception:
                            needs_set = True
                        if needs_set:
                            group[iname] = ival
                            modified = True
                # collections (apply changed flags and states)
                def apply_collection_changes_recursive(dst_dict, changes_dict, path_for_debug=""):
                    nonlocal modified
                    for key, val in changes_dict.items():
                        # If val is a dict with nested structure, recurse
                        if isinstance(val, dict) and key in ("objects", "child_collections"):
                            if key not in dst_dict:
                                dst_dict[key] = {}
                            apply_collection_changes_recursive(dst_dict[key], val, path_for_debug + "/" + key)
                        elif isinstance(val, dict):
                            # It's a sub-dict (like a collection or object entry), recurse into it
                            if key not in dst_dict:
                                dst_dict[key] = {}
                            apply_collection_changes_recursive(dst_dict[key], val, path_for_debug + "/" + key)
                        else:
                            # It's a scalar value (like hide_viewport, hide_render)
                            needs_set = True
                            try:
                                prev = dst_dict[key]
                                needs_set = prev != val
                            except Exception:
                                needs_set = True
                            if needs_set:
                                dst_dict[key] = val
                                modified = True
                
                for cat, colls in (diff_from_active.get("collections", {}) or {}).items():
                    if "collections" not in preset_data:
                        preset_data["collections"] = {}
                    if cat not in preset_data["collections"]:
                        preset_data["collections"][cat] = {}
                    for coll_name, coll_changes in colls.items():
                        if coll_name not in preset_data["collections"][cat]:
                            preset_data["collections"][cat][coll_name] = {}
                        coll_dst = preset_data["collections"][cat][coll_name]
                        apply_collection_changes_recursive(coll_dst, coll_changes, f"{cat}/{coll_name}")
            
            # Update collections - add any new collections/objects
            if "collections" in current_data:
                if "collections" not in preset_data:
                    preset_data["collections"] = {}
                
                for category, collections_data in current_data["collections"].items():
                    if category not in preset_data["collections"]:
                        preset_data["collections"][category] = {}
                    
                    for collection_name, collection_state in collections_data.items():
                        if collection_name not in preset_data["collections"][category]:
                            # New collection - add with current state
                            preset_data["collections"][category][collection_name] = collection_state
                            modified = True
                        else:
                            # Existing collection - check for new objects
                            existing_collection = preset_data["collections"][category][collection_name]
                            if "objects" not in existing_collection:
                                existing_collection["objects"] = {}
                            
                            current_objects = collection_state.get("objects", {})
                            for obj_name, obj_state in current_objects.items():
                                if obj_name not in existing_collection["objects"]:
                                    # New object - add with current state
                                    existing_collection["objects"][obj_name] = obj_state
                                    modified = True
                            
                            # Check for new child collections
                            if "child_collections" in collection_state:
                                if "child_collections" not in existing_collection:
                                    existing_collection["child_collections"] = {}
                                self._update_child_collections_recursive(
                                    collection_state["child_collections"],
                                    existing_collection["child_collections"]
                                )
            
            # Update shapekeys - add any new categorized shapekeys
            if "shapekeys" in current_data:
                if "shapekeys" not in preset_data:
                    preset_data["shapekeys"] = {}
                
                for shapekey_name, value in current_data["shapekeys"].items():
                    if shapekey_name not in preset_data["shapekeys"]:
                        # New shapekey - add with current value
                        preset_data["shapekeys"][shapekey_name] = value
                        modified = True
            
            # Update effects_shaders - add any new properties
            if "effects_shaders" in current_data:
                if "effects_shaders" not in preset_data:
                    preset_data["effects_shaders"] = {}
                
                for prop_name, value in current_data["effects_shaders"].items():
                    if prop_name not in preset_data["effects_shaders"]:
                        # New property - add with current value
                        preset_data["effects_shaders"][prop_name] = value
                        modified = True
            
            # Update misc - add any new properties
            if "misc" in current_data:
                if "misc" not in preset_data:
                    preset_data["misc"] = {}
                
                for prop_name, value in current_data["misc"].items():
                    if prop_name not in preset_data["misc"]:
                        # New property - add with current value
                        preset_data["misc"][prop_name] = value
                        modified = True
            
            # Update node_groups - add any new node group values
            if "node_groups" in current_data:
                if "node_groups" not in preset_data:
                    preset_data["node_groups"] = {}
                
                for group_name, group_values in current_data["node_groups"].items():
                    if group_name not in preset_data["node_groups"]:
                        # New node group - add with current values
                        preset_data["node_groups"][group_name] = group_values
                        modified = True
                    else:
                        # Existing node group - check for new inputs
                        existing_group = preset_data["node_groups"][group_name]
                        for input_name, input_value in group_values.items():
                            if input_name not in existing_group:
                                # New input - add with current value
                                existing_group[input_name] = input_value
                                modified = True
            
            if modified:
                updated_count += 1
        
        self.report({'INFO'}, f"Updated {updated_count} presets with changes and new items.")
        return {'FINISHED'}
    
    def _update_child_collections_recursive(self, current_child_data, preset_child_data):
        """Recursively update child collections data"""
        for child_name, child_state in current_child_data.items():
            if child_name not in preset_child_data:
                # New child collection - add with current state
                preset_child_data[child_name] = child_state
            else:
                # Existing child collection - check for new objects
                existing_child = preset_child_data[child_name]
                if "objects" not in existing_child:
                    existing_child["objects"] = {}
                
                current_objects = child_state.get("objects", {})
                for obj_name, obj_state in current_objects.items():
                    if obj_name not in existing_child["objects"]:
                        # New object - add with current state
                        existing_child["objects"][obj_name] = obj_state
                
                # Recursively update nested child collections
                if "child_collections" in child_state:
                    if "child_collections" not in existing_child:
                        existing_child["child_collections"] = {}
                    self._update_child_collections_recursive(
                        child_state["child_collections"],
                        existing_child["child_collections"]
                    )

def capture_node_group_inputs(obj, node_group_name_keyword, exclude_sockets):
    """
    Capture node group input values for presets.
    Returns a dictionary of socket names to values.
    """
    node_group_node = None
    for slot in obj.material_slots:
        mat = slot.material
        if mat and mat.use_nodes:
            for node in mat.node_tree.nodes:
                if (node.type == 'GROUP'
                    and node.node_tree
                    and node_group_name_keyword in node.node_tree.name):
                    node_group_node = node
                    break
        if node_group_node:
            break

    if not node_group_node:
        return {}

    inputs = node_group_node.inputs
    existing_sockets = [s for s in inputs if s.name not in exclude_sockets]
    if not existing_sockets:
        return {}

    captured_values = {}
    for sock in existing_sockets:
        if sock.is_linked:
            linked_node = sock.links[0].from_node
            if hasattr(linked_node.outputs[0], 'default_value'):
                captured_values[sock.name] = linked_node.outputs[0].default_value
        else:
            if hasattr(sock, 'default_value'):
                captured_values[sock.name] = sock.default_value
    
    return captured_values

def capture_node_group_inputs_in_material(obj, material_name_keyword, node_group_name_keyword, exclude_sockets):
    """
    Capture node group input values from a specific material for presets.
    Returns a dictionary of socket names to values.
    """
    node_group_node = None
    target_material = None
    
    # First find the material with the specified keyword
    for slot in obj.material_slots:
        mat = slot.material
        if mat and material_name_keyword in mat.name:
            target_material = mat
            break
    
    if not target_material:
        return {}
    
    # Then find the node group within that material
    if target_material.use_nodes:
        for node in target_material.node_tree.nodes:
            if (node.type == 'GROUP'
                and node.node_tree
                and node_group_name_keyword in node.node_tree.name):
                node_group_node = node
                break

    if not node_group_node:
        return {}

    inputs = node_group_node.inputs
    existing_sockets = [s for s in inputs if s.name not in exclude_sockets]
    if not existing_sockets:
        return {}

    captured_values = {}
    for sock in existing_sockets:
        if sock.is_linked:
            linked_node = sock.links[0].from_node
            if hasattr(linked_node.outputs[0], 'default_value'):
                captured_values[sock.name] = linked_node.outputs[0].default_value
        else:
            if hasattr(sock, 'default_value'):
                captured_values[sock.name] = sock.default_value
    
    return captured_values

def apply_node_group_inputs(obj, node_group_name_keyword, exclude_sockets, values):
    """
    Apply node group input values from presets.
    """
    node_group_node = None
    for slot in obj.material_slots:
        mat = slot.material
        if mat and mat.use_nodes:
            for node in mat.node_tree.nodes:
                if (node.type == 'GROUP'
                    and node.node_tree
                    and node_group_name_keyword in node.node_tree.name):
                    node_group_node = node
                    break
        if node_group_node:
            break

    if not node_group_node or not values:
        return

    inputs = node_group_node.inputs
    existing_sockets = [s for s in inputs if s.name not in exclude_sockets]
    if not existing_sockets:
        return

    for sock in existing_sockets:
        if sock.name in values:
            if sock.is_linked:
                linked_node = sock.links[0].from_node
                if hasattr(linked_node.outputs[0], 'default_value'):
                    linked_node.outputs[0].default_value = values[sock.name]
            else:
                if hasattr(sock, 'default_value'):
                    sock.default_value = values[sock.name]

def apply_node_group_inputs_in_material(obj, material_name_keyword, node_group_name_keyword, exclude_sockets, values):
    """
    Apply node group input values from presets to a specific material.
    """
    node_group_node = None
    target_material = None
    
    # First find the material with the specified keyword
    for slot in obj.material_slots:
        mat = slot.material
        if mat and material_name_keyword in mat.name:
            target_material = mat
            break
    
    if not target_material or not values:
        return
    
    # Then find the node group within that material
    if target_material.use_nodes:
        for node in target_material.node_tree.nodes:
            if (node.type == 'GROUP'
                and node.node_tree
                and node_group_name_keyword in node.node_tree.name):
                node_group_node = node
                break

    if not node_group_node:
        return

    inputs = node_group_node.inputs
    existing_sockets = [s for s in inputs if s.name not in exclude_sockets]
    if not existing_sockets:
        return

    for sock in existing_sockets:
        if sock.name in values:
            if sock.is_linked:
                linked_node = sock.links[0].from_node
                if hasattr(linked_node.outputs[0], 'default_value'):
                    linked_node.outputs[0].default_value = values[sock.name]
            else:
                if hasattr(sock, 'default_value'):
                    sock.default_value = values[sock.name]
