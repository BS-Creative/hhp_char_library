import bpy
from bpy.props import BoolProperty

# -------------------------------------------------------------------
# Helper functions
# -------------------------------------------------------------------

def draw_single_column_compact(obj, props_list, layout):
    """
    Draw each property in one tightly packed column (no extra spacing).
    """
    existing_props = [p for p in props_list if p in obj.keys()]
    if not existing_props:
        return

    col = layout.column(align=True)  # <--- Single column, align=True for compact spacing
    for prop in existing_props:
        col.prop(obj, f'["{prop}"]', text=prop)


def draw_props_two_columns(obj, props_list, layout):
    """
    Draw the given properties in 2 columns, preserving compact alignment,
    with each row possibly containing up to 2 props.
    """
    existing_props = [p for p in props_list if p in obj.keys()]
    if not existing_props:
        return

    col = layout.column(align=True)
    rows = (len(existing_props) + 1) // 2
    idx = 0
    for _ in range(rows):
        row = col.row(align=True)
        for _col in range(2):
            if idx < len(existing_props):
                prop_name = existing_props[idx]
                row.prop(obj, f'["{prop_name}"]', text=prop_name)
                idx += 1


def draw_shape_keys(obj, shape_keys_list, layout):
    """
    Draw shape keys in 2 columns, preserving alignment.
    (Shape keys do NOT appear in obj.keys().)
    """
    sk = getattr(obj.data, "shape_keys", None)
    if not (sk and sk.key_blocks):
        return

    key_blocks = sk.key_blocks
    existing_keys = [k for k in shape_keys_list if k in key_blocks]
    if not existing_keys:
        return

    col = layout.column(align=True)
    rows = (len(existing_keys) + 1) // 2
    idx = 0
    for _ in range(rows):
        row = col.row(align=True)
        for _col in range(2):
            if idx < len(existing_keys):
                key_name = existing_keys[idx]
                row.prop(key_blocks[key_name], 'value', text=key_name)
                idx += 1


def draw_node_group_inputs(obj, node_group_name_keyword, exclude_sockets, layout):
    """
    Draws node group inputs in 2 columns (RGBA -> single row).
    """
    node_group_node = None
    for slot in obj.material_slots:
        mat = slot.material
        if mat and mat.use_nodes:
            for node in mat.node_tree.nodes:
                if (node.type == 'GROUP'
                    and node.node_tree
                    and node_group_name_keyword in node.node_tree.name):
                    node_group_node = node
                    break
        if node_group_node:
            break

    if not node_group_node:
        layout.label(text=f"No node group containing '{node_group_name_keyword}' found.")
        return

    inputs = node_group_node.inputs
    existing_sockets = [s for s in inputs if s.name not in exclude_sockets]
    if not existing_sockets:
        layout.label(text="No inputs to display.")
        return

    ordered = []
    current_row = []
    for sock in existing_sockets:
        is_color = (sock.type == 'RGBA')
        if is_color:
            if current_row:
                ordered.append(current_row)
                current_row = []
            ordered.append([sock])  # color alone in a row
        else:
            current_row.append(sock)
            if len(current_row) == 2:
                ordered.append(current_row)
                current_row = []
    if current_row:
        ordered.append(current_row)

    col = layout.column(align=True)
    for row_socks in ordered:
        row = col.row(align=True)
        if len(row_socks) == 1:
            sock = row_socks[0]
            if sock.is_linked:
                linked_node = sock.links[0].from_node
                if hasattr(linked_node.outputs[0], 'default_value'):
                    row.prop(linked_node.outputs[0], 'default_value', text=sock.name)
                else:
                    row.label(text=f"Unsupported node type: {linked_node.type}")
            else:
                row.prop(sock, 'default_value', text=sock.name)
        else:
            for sock in row_socks:
                if sock.is_linked:
                    linked_node = sock.links[0].from_node
                    if hasattr(linked_node.outputs[0], 'default_value'):
                        row.prop(linked_node.outputs[0], 'default_value', text=sock.name)
                    else:
                        row.label(text=f"Unsupported node type: {linked_node.type}")
                else:
                    row.prop(sock, 'default_value', text=sock.name)


# -------------------------------------------------------------------
# Section Mode Toggle Operators 
# -------------------------------------------------------------------

class HHP_OT_ToggleCustomizePanelSectionInitial(bpy.types.Operator):
    bl_idname = "hhp.toggle_customize_section_initial"
    bl_label = "Initial Setup"
    bl_description = "Initial Setup - Character initialization options (Base values and textures)"
    
    def execute(self, context):
        wm = context.window_manager
        if wm.custom_panel_section == 'INITIAL_SETUP':
            # No-op when clicking the same section again (keep it active)
            pass
        else:
            wm.custom_panel_section = 'INITIAL_SETUP'
        return {'FINISHED'}

class HHP_OT_ToggleCustomizePanelSectionShapekeys(bpy.types.Operator):
    bl_idname = "hhp.toggle_customize_section_shapekeys"
    bl_label = "Shapekey Morphs"
    bl_description = "Shapekey Morphs - Character shape customization with shapekeys / blendshapes"
    
    def execute(self, context):
        wm = context.window_manager
        if wm.custom_panel_section == 'SHAPEKEY_MORPHS':
            # No-op when clicking the same section again (keep it active)
            pass
        else:
            wm.custom_panel_section = 'SHAPEKEY_MORPHS'
        return {'FINISHED'}

class HHP_OT_ToggleCustomizePanelSectionEffects(bpy.types.Operator):
    bl_idname = "hhp.toggle_customize_section_effects"
    bl_label = "Effects & Shaders"
    bl_description = "Effects & Shaders - shader based customization and Visual effects"
    
    def execute(self, context):
        wm = context.window_manager
        if wm.custom_panel_section == 'EFFECTS_SHADERS':
            # No-op when clicking the same section again (keep it active)
            pass
        else:
            wm.custom_panel_section = 'EFFECTS_SHADERS'
        return {'FINISHED'}

class HHP_OT_ToggleCustomizePanelSectionClothing(bpy.types.Operator):
    bl_idname = "hhp.toggle_customize_section_clothing"
    bl_label = "Clothing & Accessories"
    bl_description = "Clothing & Accessories - Manage character clothing and accessories"
    
    def execute(self, context):
        wm = context.window_manager
        if wm.custom_panel_section == 'CLOTHING':
            # No-op when clicking the same section again (keep it active)
            pass
        else:
            wm.custom_panel_section = 'CLOTHING'
        return {'FINISHED'}

class HHP_OT_ToggleCustomizePanelSectionMisc(bpy.types.Operator):
    bl_idname = "hhp.toggle_customize_section_misc"
    bl_label = "Misc"
    bl_description = "Misc - Miscellaneous properties and masking options for toggling mesh parts on / off"
    
    def execute(self, context):
        wm = context.window_manager
        if wm.custom_panel_section == 'MISC':
            # No-op when clicking the same section again (keep it active)
            pass
        else:
            wm.custom_panel_section = 'MISC'
        return {'FINISHED'}

# -------------------------------------------------------------------
# Main Panel with Single Dropdown
# -------------------------------------------------------------------

class CustomizePanel(bpy.types.Panel):
    bl_label = "Customize (HHP)"
    bl_idname = "CHAR_PT_Customize_HHP"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Char (HHP)"
    bl_parent_id = "CHAR_HHP_PT_Panel"  # Set parent panel
    bl_options = {'HIDE_HEADER'}  # Hide the header
    bl_order = 20
    
    @classmethod
    def poll(cls, context):
        # Only show this panel if CUSTOMIZE is selected in the mode selector
        return context.scene.hhp_panel_mode.selected_panel == 'CUSTOMIZE'

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        obj = context.object

        if not obj:
            layout.label(text="No object selected")
            return

        # Only show the preset selector and panel section dropdown if the active mesh's data name contains "Genesis8Female" and the object name does not contain "Deform Proxy"
        if obj and obj.type == 'MESH' and obj.data and "Genesis8Female" in obj.data.name and "Deform Proxy" not in obj.name:
            # Panel section container box with mode selector and preset controls
            section_box = layout.box()
            
            # Add mode selector for section modes
            mode_row = section_box.row(align=True)
            
            # Left side: Mode selector buttons
            left_side = mode_row.row(align=True)
            
            # Initial Setup button
            initial_btn = left_side.operator("hhp.toggle_customize_section_initial", text="", icon='QUIT', 
                                          depress=wm.custom_panel_section=='INITIAL_SETUP')
            
            # Shapekey Morphs button
            shapekey_btn = left_side.operator("hhp.toggle_customize_section_shapekeys", text="", icon='SHAPEKEY_DATA', 
                                           depress=wm.custom_panel_section=='SHAPEKEY_MORPHS')
            
            # Effects & Shaders button
            effects_btn = left_side.operator("hhp.toggle_customize_section_effects", text="", icon='MATERIAL', 
                                          depress=wm.custom_panel_section=='EFFECTS_SHADERS')
            
            # Clothing & Accessories button
            clothing_btn = left_side.operator("hhp.toggle_customize_section_clothing", text="", icon='MOD_CLOTH', 
                                           depress=wm.custom_panel_section=='CLOTHING')
            
            # Misc button
            misc_btn = left_side.operator("hhp.toggle_customize_section_misc", text="", icon='MOD_MASK', 
                                       depress=wm.custom_panel_section=='MISC')
            
            # Right side: Preset dropdown and buttons
            right_side = mode_row.row(align=True)
            right_side.prop(obj, "active_preset", text="", icon="MOD_CLOTH")
            right_side.operator("object.overwrite_preset", text="", icon="FILE_TICK")
            right_side.operator("object.add_preset", text="", icon="ADD")
            right_side.operator("object.remove_preset", text="", icon="REMOVE")
            right_side.operator("object.rename_preset", text="", icon="GREASEPENCIL")
        else:
            # Ensure section_box is defined even if the object doesn't meet the criteria.
            section_box = layout.box()
            section_box.label(text="Select an HHP character mesh")
            return

        # ------------------------------------------------------------------
        # Define known property sets, so they don't show up in Misc.
        # ------------------------------------------------------------------
        first_six_props = [
            "Displace Clothing",
            "Base Color (Switch)",
            "Normal (Switch)",
            "Hue",
            "Saturation",
            "Value"
        ]
        leftover_setup_props = [
            'Eye socket push back', 'Correct Eyelids',
            'Abs', 'Detail Bump', 'Detail Bump - Face', 'Max Roughness',
            'Normal Contrast (Body)', 'Normal Contrast (Clavicle)',
            'Normal Contrast (Face)', 'Subsurface'
        ]
        all_initial_setup = set(first_six_props + leftover_setup_props)

        effects_shaders_props = [
            'Feet Dirt', 'Gens used', 'Goosebumps', 'Hand Veins', 'Piercing Bumps',
            'Tan Lines', 'Throat Bulge (Color)', 'Throat Bulge (Neck Bump)',
            'Throat Bulge (SK Deform)', 'Throat Bulge (Veins Bump)', 'Vascularity',
            'Wetness', 'Wetness (Switch)'
        ]

        allocated_props = all_initial_setup.union(effects_shaders_props)

        # All user-defined properties on this object
        all_custom_props = set(obj.keys())
        built_in_props = set(p.identifier for p in obj.bl_rna.properties)

        leftover_for_misc = [
            p for p in sorted(all_custom_props - built_in_props)
            if p not in allocated_props and p not in {"orig_subsurface", "presets"} and not p.startswith('_')
        ]

        # Show whichever section is chosen directly in the same box:
        if wm.custom_panel_section == 'INITIAL_SETUP':
            draw_single_column_compact(obj, first_six_props, section_box)
            section_box.separator()
            draw_props_two_columns(obj, leftover_setup_props, section_box)

        elif wm.custom_panel_section == 'SHAPEKEY_MORPHS':
            main_shape_keys = [
                'Heels & Boots bend', 'Elin female bend', 'Heels (Squished feet)',
                'Thicken lids', 'Thicken Lips', 'Nipples hide', 'Nipples pinch base'
            ]
            draw_shape_keys(obj, main_shape_keys, section_box)
            if obj.data and obj.data.shape_keys and obj.data.shape_keys.key_blocks:
                sk_block = obj.data.shape_keys.key_blocks
                auto_keys = [k for k in sk_block.keys()
                             if k.startswith('Torso -') or k.startswith('Char -')]
                if auto_keys:
                    draw_shape_keys(obj, auto_keys, section_box)
            section_box.separator()
            section_box.label(text="Extra Morphs")
            extra_keys = [
                'Long nails', 'Sexy Short Nails', 'Extra Long Nails', 'Extra sharp long nails',
                'real feet 1', 'real feet 2', 'real feet 3', 'real feet 4', 'real feet 5', 'real feet 6',
                'Hitomi feet', 'Tekken Feet & Legs', 'real toes 5', 'custom feet 1', 'Necdaz_feet',
                'Feet fatness', 'Feet (Real Ndaz)', 'Feet fatness - Cassie', 'feet preset - Haruka / Young',
                'Genesis8Female__PBMNailsLength', 'Genesis8Female__PBMChameleonROse_2_Tnails',
                'Genesis8Female__PBMChameleonROse_2_Fnails2', 'Genesis8Female__PBMChameleonROse_2_Fnails'
            ]
            draw_shape_keys(obj, extra_keys, section_box)

        elif wm.custom_panel_section == 'EFFECTS_SHADERS':
            draw_props_two_columns(obj, effects_shaders_props, section_box)
            section_box.separator()
            section_box.label(text="Makeup")
            draw_node_group_inputs(obj, "Makeup_HHP", ["Base Color", "Roughness"], section_box)

        elif wm.custom_panel_section == 'CLOTHING':
            main_row = section_box.row(align=True)

            # Left column: Clothes collections
            col_clothes = main_row.column(align=True)
            col_clothes.label(text="Clothes")
            clothes_collections = self.find_clothes_collections(context)
            for collection, current_hidden, is_top_level, objects in clothes_collections:
                row = col_clothes.row(align=True)
                clean_name = collection.name.split(".")[0]
                icon = 'OUTLINER_COLLECTION'
                row.active = True
                row.prop(collection, "show_collection_render", text=clean_name, toggle=True, icon=icon)
                if not current_hidden and objects:
                    inner_box = col_clothes.box()
                    inner_col = inner_box.column(align=True)
                    for obj_item, obj_hidden in objects:
                        obj_row = inner_col.row(align=True)
                        obj_name = obj_item.name.split(".")[0]
                        obj_icon = 'OBJECT_DATA'
                        obj_row.active = True
                        obj_row.prop(obj_item, "show_object_render", text=obj_name, toggle=True, icon=obj_icon)

            # Right column: Appendages collections
            col_appendages = main_row.column(align=True)
            col_appendages.label(text="Appendages")
            appendages_collections = self.find_appendages_collections(context)
            for collection, current_hidden, is_top_level, objects in appendages_collections:
                row = col_appendages.row(align=True)
                clean_name = collection.name.split(".")[0]
                icon = 'OUTLINER_COLLECTION'
                row.active = True
                row.prop(collection, "show_collection_render", text=clean_name, toggle=True, icon=icon)
                if not current_hidden and objects:
                    inner_box = col_appendages.box()
                    inner_col = inner_box.column(align=True)
                    for obj_item, obj_hidden in objects:
                        obj_row = inner_col.row(align=True)
                        obj_name = obj_item.name.split(".")[0]
                        obj_icon = 'OBJECT_DATA'
                        obj_row.active = True
                        obj_row.prop(obj_item, "show_object_render", text=obj_name, toggle=True, icon=obj_icon)

        elif wm.custom_panel_section == 'MISC':
            if leftover_for_misc:
                draw_props_two_columns(obj, leftover_for_misc, section_box)
            else:
                section_box.label(text="No misc properties found.")

    def collect_collections(self, collection, collection_list, parent_hidden=False, is_top_level=False, processed_collections=None):
        if processed_collections is None:
            processed_collections = set()
        if collection in processed_collections:
            return
        processed_collections.add(collection)

        # Determine if current collection is hidden (viewport or render)
        current_hidden = parent_hidden or collection.hide_viewport or collection.hide_render

        # Collect objects if the collection is not hidden
        objects = []
        if not current_hidden:
            for obj in collection.objects:
                obj_hidden = obj.hide_viewport or obj.hide_render
                objects.append((obj, obj_hidden))

        collection_list.append((collection, current_hidden, is_top_level, objects))

        # Process child collections if not hidden
        if not current_hidden:
            for child in collection.children:
                self.collect_collections(
                    child,
                    collection_list,
                    parent_hidden=current_hidden,
                    is_top_level=False,
                    processed_collections=processed_collections
                )

    def find_clothes_collections(self, context):
        """Find all 'Clothes' collections from the parent collections of selected meshes."""
        clothes_collections = []
        processed_collections = set()
        parent_collections = set()
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                parent_collections.update(obj.users_collection)
        for collection in bpy.data.collections:
            if collection in parent_collections:
                for sub_collection in collection.children:
                    if sub_collection.name.startswith("Clothes") and sub_collection not in processed_collections:
                        self.collect_collections(
                            sub_collection,
                            clothes_collections,
                            parent_hidden=False,
                            is_top_level=True,
                            processed_collections=processed_collections
                        )
        return clothes_collections

    def find_appendages_collections(self, context):
        """Find all 'Appendages' collections from the parent collections of selected meshes."""
        appendages_collections = []
        processed_collections = set()
        parent_collections = set()
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                parent_collections.update(obj.users_collection)
        for collection in bpy.data.collections:
            if collection in parent_collections:
                for sub_collection in collection.children:
                    if sub_collection.name.startswith("Appendages") and sub_collection not in processed_collections:
                        self.collect_collections(
                            sub_collection,
                            appendages_collections,
                            parent_hidden=False,
                            is_top_level=True,
                            processed_collections=processed_collections
                        )
        return appendages_collections


# -------------------------------------------------------------------
# Registration
# -------------------------------------------------------------------

def register():
    bpy.utils.register_class(HHP_OT_ToggleCustomizePanelSectionInitial)
    bpy.utils.register_class(HHP_OT_ToggleCustomizePanelSectionShapekeys)
    bpy.utils.register_class(HHP_OT_ToggleCustomizePanelSectionEffects)
    bpy.utils.register_class(HHP_OT_ToggleCustomizePanelSectionClothing)
    bpy.utils.register_class(HHP_OT_ToggleCustomizePanelSectionMisc)
    bpy.utils.register_class(CustomizePanel)
    bpy.utils.register_class(OT_AddPreset)
    bpy.utils.register_class(OT_OverwritePreset)
    bpy.utils.register_class(OT_RemovePreset)
    bpy.utils.register_class(OT_RenamePreset)
    
    wm = bpy.types.WindowManager
    wm.custom_panel_section = bpy.props.EnumProperty(
        name="Panel Section",
        description="Choose which section to display",
        items=[
            ('INITIAL_SETUP',     "Initial Setup",    ""),
            ('SHAPEKEY_MORPHS',   "Shapekey Morphs",  ""),
            ('EFFECTS_SHADERS',   "Effects & Shaders",""),
            ('CLOTHING',        "Clothing & Accessories", ""),
            ('MISC',              "Misc",             "")
        ],
        default='INITIAL_SETUP'
    )
    bpy.types.Collection.show_collection_render = BoolProperty(
         name="",
         description="Toggle Collection Visibility (Viewport and Render)",
         get=get_show_collection_render,
         set=set_show_collection_render
    )
    bpy.types.Object.show_object_render = BoolProperty(
         name="",
         description="Toggle Object Visibility (Viewport and Render)",
         get=get_show_object_render,
         set=set_show_object_render
    )
    bpy.types.Object.active_preset = bpy.props.EnumProperty(
         name="Preset",
         description="Select a preset",
         items=preset_items,
         update=update_active_preset
    )

def unregister():
    wm = bpy.types.WindowManager
    del wm.custom_panel_section
    
    bpy.utils.unregister_class(OT_RenamePreset)
    bpy.utils.unregister_class(OT_RemovePreset)
    bpy.utils.unregister_class(OT_OverwritePreset)
    bpy.utils.unregister_class(OT_AddPreset)
    bpy.utils.unregister_class(CustomizePanel)
    bpy.utils.unregister_class(HHP_OT_ToggleCustomizePanelSectionMisc)
    bpy.utils.unregister_class(HHP_OT_ToggleCustomizePanelSectionClothing)
    bpy.utils.unregister_class(HHP_OT_ToggleCustomizePanelSectionEffects)
    bpy.utils.unregister_class(HHP_OT_ToggleCustomizePanelSectionShapekeys)
    bpy.utils.unregister_class(HHP_OT_ToggleCustomizePanelSectionInitial)
    
    del bpy.types.Collection.show_collection_render
    del bpy.types.Object.show_object_render
    del bpy.types.Object.active_preset

if __name__ == "__main__":
    register()

# ---- Clothing & Outfit Preset Definitions (moved from Clothing_HHP.py) ----

def get_show_collection_render(self):
    return not self.hide_viewport and not self.hide_render

def set_show_collection_render(self, value):
    self.hide_viewport = not value
    self.hide_render = not value

def get_show_object_render(self):
    return not self.hide_viewport and not self.hide_render

def set_show_object_render(self, value):
    self.hide_viewport = not value
    self.hide_render = not value

def capture_collection_state(collection):
    state = {
        "hide_viewport": collection.hide_viewport,
        "hide_render": collection.hide_render,
        "objects": {}
    }
    for obj in collection.objects:
        state["objects"][obj.name] = {
            "hide_viewport": obj.hide_viewport,
            "hide_render": obj.hide_render
        }
    child_states = {}
    for child in collection.children:
        child_states[child.name] = capture_collection_state(child)
    if child_states:
        state["child_collections"] = child_states
    return state

def capture_outfit_preset(context):
    active_obj = context.active_object
    presets = {"Clothes": {}, "Appendages": {}}
    if not active_obj:
        return presets
    parent_collections = set(active_obj.users_collection)
    for collection in bpy.data.collections:
        if collection in parent_collections:
            for sub_collection in collection.children:
                if sub_collection.name.startswith("Clothes"):
                    presets["Clothes"][sub_collection.name] = capture_collection_state(sub_collection)
                elif sub_collection.name.startswith("Appendages"):
                    presets["Appendages"][sub_collection.name] = capture_collection_state(sub_collection)
    return presets

def apply_child_collections_state(child_data):
    for coll_name, state in child_data.items():
        coll = bpy.data.collections.get(coll_name)
        if coll:
            coll.hide_viewport = state.get("hide_viewport", coll.hide_viewport)
            coll.hide_render = state.get("hide_render", coll.hide_render)
            for obj in coll.objects:
                obj_state = state.get("objects", {}).get(obj.name)
                if obj_state:
                    obj.hide_viewport = obj_state.get("hide_viewport", obj.hide_viewport)
                    obj.hide_render = obj_state.get("hide_render", obj.hide_render)
            if "child_collections" in state:
                apply_child_collections_state(state["child_collections"])

def apply_outfit_preset(preset_data):
    for category, collections_data in preset_data.items():
        for coll_name, state in collections_data.items():
            coll = bpy.data.collections.get(coll_name)
            if coll:
                coll.hide_viewport = state.get("hide_viewport", coll.hide_viewport)
                coll.hide_render = state.get("hide_render", coll.hide_render)
                for obj in coll.objects:
                    obj_state = state.get("objects", {}).get(obj.name)
                    if obj_state:
                        obj.hide_viewport = obj_state.get("hide_viewport", obj.hide_viewport)
                        obj.hide_render = obj_state.get("hide_render", obj.hide_render)
                if "child_collections" in state:
                    apply_child_collections_state(state["child_collections"])

def update_active_preset(self, context):
    preset_name = self.active_preset
    if "presets" not in self:
        return
    presets = self["presets"]
    if preset_name not in presets:
        return
    preset_data = presets[preset_name]
    apply_preset(preset_data)

def preset_items(self, context):
    obj = context.object
    if not obj or "presets" not in obj or not obj["presets"]:
        return [("NONE", "None", "No presets available")]
    return [(name, name, "") for name in obj["presets"].keys()]

# Operator classes for outfit preset management

class OT_AddPreset(bpy.types.Operator):
    bl_idname = "object.add_preset"
    bl_label = "Add Preset"
    bl_description = "Add a new preset"
    
    preset_name: bpy.props.StringProperty(
        name="Preset Name",
        default="New Preset",
        options={'SKIP_SAVE'}
    )
    
    def invoke(self, context, event):
        self.preset_name = "New Preset"  # Reset every time
        wm = context.window_manager
        return wm.invoke_props_dialog(self)
    
    def execute(self, context):
        active_obj = context.active_object
        if not active_obj:
            self.report({'WARNING'}, "No active object.")
            return {'CANCELLED'}
        preset_data = capture_preset(context)
        if "presets" not in active_obj:
            active_obj["presets"] = {}
        presets = active_obj["presets"]
        if self.preset_name in presets:
            self.report({'WARNING'}, "Preset with same name exists. Choose a different name.")
            return {'CANCELLED'}
        presets[self.preset_name] = preset_data
        active_obj.active_preset = self.preset_name
        self.report({'INFO'}, f"Preset '{self.preset_name}' added.")
        return {'FINISHED'}

class OT_RemovePreset(bpy.types.Operator):
    bl_idname = "object.remove_preset"
    bl_label = "Remove Preset"
    bl_description = "Remove the selected preset"
    
    def execute(self, context):
        active_obj = context.active_object
        if not active_obj:
            self.report({'WARNING'}, "No active object.")
            return {'CANCELLED'}
        if "presets" not in active_obj:
            self.report({'WARNING'}, "No presets to remove.")
            return {'CANCELLED'}
        presets = active_obj["presets"]
        preset_name = active_obj.active_preset
        if preset_name not in presets:
            self.report({'WARNING'}, "Selected preset not found.")
            return {'CANCELLED'}
        del presets[preset_name]
        if presets:
            active_obj.active_preset = list(presets.keys())[0]
        else:
            active_obj.active_preset = "NONE"
        self.report({'INFO'}, f"Preset '{preset_name}' removed.")
        return {'FINISHED'}

class OT_RenamePreset(bpy.types.Operator):
    bl_idname = "object.rename_preset"
    bl_label = "Rename Preset"
    bl_description = "Rename the selected preset"

    new_name: bpy.props.StringProperty(name="New Preset Name", default="")
    
    def invoke(self, context, event):
        active_obj = context.active_object
        if active_obj:
            self.new_name = active_obj.active_preset
        else:
            self.new_name = ""
        wm = context.window_manager
        return wm.invoke_props_dialog(self)
    
    def execute(self, context):
        active_obj = context.active_object
        if not active_obj or "presets" not in active_obj:
            self.report({'WARNING'}, "No active preset to rename.")
            return {'CANCELLED'}
        presets = active_obj["presets"]
        old_name = active_obj.active_preset
        if old_name not in presets:
            self.report({'WARNING'}, "No preset found.")
            return {'CANCELLED'}
        if self.new_name in presets:
            self.report({'WARNING'}, "Preset with this new name already exists.")
            return {'CANCELLED'}
        presets[self.new_name] = presets.pop(old_name)
        active_obj.active_preset = self.new_name
        self.report({'INFO'}, f"Preset renamed from '{old_name}' to '{self.new_name}'.")
        return {'FINISHED'}

# New operator to overwrite the current preset
class OT_OverwritePreset(bpy.types.Operator):
    bl_idname = "object.overwrite_preset"
    bl_label = "Overwrite Preset"
    bl_description = "Overwrite the current selected preset with the current settings"

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Overwrite preset?")

    def execute(self, context):
        active_obj = context.active_object
        if not active_obj:
            self.report({'WARNING'}, "No active object.")
            return {'CANCELLED'}
        preset_name = active_obj.active_preset
        if preset_name == "NONE" or "presets" not in active_obj or preset_name not in active_obj["presets"]:
            self.report({'WARNING'}, "No preset selected to overwrite.")
            return {'CANCELLED'}
        preset_data = capture_preset(context)
        active_obj["presets"][preset_name] = preset_data
        self.report({'INFO'}, f"Preset '{preset_name}' updated.")
        return {'FINISHED'}

# New function to capture the full preset data (except MISC)
def capture_preset(context):
    active_obj = context.active_object
    data = {}
    # Capture collections state
    data["collections"] = capture_outfit_preset(context)

    # Capture INITIAL_SETUP properties
    initial_setup_keys = [
         "Displace Clothing",
         "Base Color (Switch)",
         "Normal (Switch)",
         "Hue",
         "Saturation",
         "Value",
         "Eye socket push back", "Correct Eyelids",
         "Abs", "Detail Bump", "Detail Bump - Face", "Max Roughness",
         "Normal Contrast (Body)", "Normal Contrast (Clavicle)",
         "Normal Contrast (Face)", "Subsurface"
    ]
    data["initial_setup"] = {}
    for key in initial_setup_keys:
         if key in active_obj.keys():
              data["initial_setup"][key] = active_obj[key]

    # Capture EFFECTS_SHADERS properties
    effects_shaders_keys = [
         "Feet Dirt", "Gens used", "Goosebumps", "Hand Veins", "Piercing Bumps",
         "Tan Lines", "Throat Bulge (Color)", "Throat Bulge (Neck Bump)",
         "Throat Bulge (SK Deform)", "Throat Bulge (Veins Bump)", "Vascularity",
         "Wetness", "Wetness (Switch)"
    ]
    data["effects_shaders"] = {}
    for key in effects_shaders_keys:
         if key in active_obj.keys():
              data["effects_shaders"][key] = active_obj[key]

    # Capture SHAPEKEY_MORPHS values - capture main morphs, extra morphs, and auto-detected keys
    data["shapekeys"] = {}
    if active_obj.data and active_obj.data.shape_keys and active_obj.data.shape_keys.key_blocks:
         sk_block = active_obj.data.shape_keys.key_blocks
         main_shape_keys = ['Heels & Boots bend', 'Elin female bend', 'Heels (Squished feet)',
                             'Thicken lids', 'Thicken Lips', 'Nipples hide', 'Nipples pinch base']
         extra_morph_keys = [
            'Long nails', 'Sexy Short Nails', 'Extra Long Nails', 'Extra sharp long nails',
            'real feet 1', 'real feet 2', 'real feet 3', 'real feet 4', 'real feet 5', 'real feet 6',
            'Hitomi feet', 'Tekken Feet & Legs', 'real toes 5', 'custom feet 1', 'Necdaz_feet',
            'Feet fatness', 'Feet (Real Ndaz)', 'Feet fatness - Cassie', 'feet preset - Haruka / Young',
            'Genesis8Female__PBMNailsLength', 'Genesis8Female__PBMChameleonROse_2_Tnails',
            'Genesis8Female__PBMChameleonROse_2_Fnails2', 'Genesis8Female__PBMChameleonROse_2_Fnails'
         ]
         for key in main_shape_keys:
             if key in sk_block:
                 data["shapekeys"][key] = sk_block[key].value
         # Auto-detected morphs (e.g. Torso - or Char - keys)
         for key in sk_block.keys():
             if key.startswith("Torso -") or key.startswith("Char -"):
                 data["shapekeys"][key] = sk_block[key].value
         for key in extra_morph_keys:
             if key in sk_block:
                 data["shapekeys"][key] = sk_block[key].value

    # Capture MISC properties - all user-defined keys that are not allocated, excluding "orig_subsurface" and "presets"
    allocated_props = set(initial_setup_keys) | set(effects_shaders_keys)
    all_custom_props = set(active_obj.keys())
    built_in_props = set(p.identifier for p in active_obj.bl_rna.properties)
    misc_keys = [ key for key in sorted(all_custom_props - built_in_props)
                  if key not in allocated_props and key not in {"orig_subsurface", "presets"} and not key.startswith('_') ]
    data["misc"] = {}
    for key in misc_keys:
         data["misc"][key] = active_obj[key]

    return data

# New function to apply a preset (collections + custom properties)
def apply_preset(preset_data):
    active_obj = bpy.context.active_object
    if not active_obj:
         return
    # Apply collections state
    if "collections" in preset_data:
         apply_outfit_preset(preset_data["collections"])
    # Apply INITIAL_SETUP custom properties
    if "initial_setup" in preset_data:
         for key, value in preset_data["initial_setup"].items():
              active_obj[key] = value
    # Apply EFFECTS_SHADERS custom properties
    if "effects_shaders" in preset_data:
         for key, value in preset_data["effects_shaders"].items():
              active_obj[key] = value
    # Apply SHAPEKEY_MORPHS values
    if "shapekeys" in preset_data and active_obj.data and active_obj.data.shape_keys:
         for key, value in preset_data["shapekeys"].items():
              if key in active_obj.data.shape_keys.key_blocks:
                     active_obj.data.shape_keys.key_blocks[key].value = value
    # Apply MISC properties
    if "misc" in preset_data:
         for key, value in preset_data["misc"].items():
              active_obj[key] = value
