import bpy

# -------------------------------------------------------------------
# Helper functions
# -------------------------------------------------------------------

def draw_single_column_compact(obj, props_list, layout):
    """
    Draw each property in one tightly packed column (no extra spacing).
    """
    existing_props = [p for p in props_list if p in obj.keys()]
    if not existing_props:
        return

    col = layout.column(align=True)  # <--- Single column, align=True for compact spacing
    for prop in existing_props:
        col.prop(obj, f'["{prop}"]', text=prop)


def draw_props_two_columns(obj, props_list, layout):
    """
    Draw the given properties in 2 columns, preserving compact alignment,
    with each row possibly containing up to 2 props.
    """
    existing_props = [p for p in props_list if p in obj.keys()]
    if not existing_props:
        return

    col = layout.column(align=True)
    rows = (len(existing_props) + 1) // 2
    idx = 0
    for _ in range(rows):
        row = col.row(align=True)
        for _col in range(2):
            if idx < len(existing_props):
                prop_name = existing_props[idx]
                row.prop(obj, f'["{prop_name}"]', text=prop_name)
                idx += 1


def draw_shape_keys(obj, shape_keys_list, layout):
    """
    Draw shape keys in 2 columns, preserving alignment.
    (Shape keys do NOT appear in obj.keys().)
    """
    sk = getattr(obj.data, "shape_keys", None)
    if not (sk and sk.key_blocks):
        return

    key_blocks = sk.key_blocks
    existing_keys = [k for k in shape_keys_list if k in key_blocks]
    if not existing_keys:
        return

    col = layout.column(align=True)
    rows = (len(existing_keys) + 1) // 2
    idx = 0
    for _ in range(rows):
        row = col.row(align=True)
        for _col in range(2):
            if idx < len(existing_keys):
                key_name = existing_keys[idx]
                row.prop(key_blocks[key_name], 'value', text=key_name)
                idx += 1


def draw_node_group_inputs(obj, node_group_name_keyword, exclude_sockets, layout):
    """
    Draws node group inputs in 2 columns (RGBA -> single row).
    """
    node_group_node = None
    for slot in obj.material_slots:
        mat = slot.material
        if mat and mat.use_nodes:
            for node in mat.node_tree.nodes:
                if (node.type == 'GROUP'
                    and node.node_tree
                    and node_group_name_keyword in node.node_tree.name):
                    node_group_node = node
                    break
        if node_group_node:
            break

    if not node_group_node:
        layout.label(text=f"No node group containing '{node_group_name_keyword}' found.")
        return

    inputs = node_group_node.inputs
    existing_sockets = [s for s in inputs if s.name not in exclude_sockets]
    if not existing_sockets:
        layout.label(text="No inputs to display.")
        return

    ordered = []
    current_row = []
    for sock in existing_sockets:
        is_color = (sock.type == 'RGBA')
        if is_color:
            if current_row:
                ordered.append(current_row)
                current_row = []
            ordered.append([sock])  # color alone in a row
        else:
            current_row.append(sock)
            if len(current_row) == 2:
                ordered.append(current_row)
                current_row = []
    if current_row:
        ordered.append(current_row)

    col = layout.column(align=True)
    for row_socks in ordered:
        row = col.row(align=True)
        if len(row_socks) == 1:
            sock = row_socks[0]
            if sock.is_linked:
                linked_node = sock.links[0].from_node
                if hasattr(linked_node.outputs[0], 'default_value'):
                    row.prop(linked_node.outputs[0], 'default_value', text=sock.name)
                else:
                    row.label(text=f"Unsupported node type: {linked_node.type}")
            else:
                row.prop(sock, 'default_value', text=sock.name)
        else:
            for sock in row_socks:
                if sock.is_linked:
                    linked_node = sock.links[0].from_node
                    if hasattr(linked_node.outputs[0], 'default_value'):
                        row.prop(linked_node.outputs[0], 'default_value', text=sock.name)
                    else:
                        row.label(text=f"Unsupported node type: {linked_node.type}")
                else:
                    row.prop(sock, 'default_value', text=sock.name)


# -------------------------------------------------------------------
# Main Panel with Single Dropdown
# -------------------------------------------------------------------

class CustomizePanel(bpy.types.Panel):
    bl_label = "Customize (HHP)"
    bl_idname = "CHAR_PT_Customize_HHP"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Char (HHP)"
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 20

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        obj = context.object

        if not obj:
            layout.label(text="No object selected")
            return

        # Single drop-down row (no label)
        row = layout.row()
        row.prop(wm, "custom_panel_section", text="")

        # ------------------------------------------------------------------
        # Define known property sets, so they don't show up in Misc.
        # ------------------------------------------------------------------
        first_six_props = [
            "Displace Clothing",
            "Base Color (Switch)",
            "Normal (Switch)",
            "Hue",
            "Saturation",
            "Value"
        ]
        leftover_setup_props = [
            'Eye socket push back', 'Correct Eyelids',
            'Abs', 'Detail Bump', 'Detail Bump - Face', 'Max Roughness',
            'Normal Contrast (Body)', 'Normal Contrast (Clavicle)',
            'Normal Contrast (Face)', 'Subsurface'
        ]
        all_initial_setup = set(first_six_props + leftover_setup_props)

        effects_shaders_props = [
            'Feet Dirt', 'Gens used', 'Goosebumps', 'Hand Veins', 'Piercing Bumps',
            'Tan Lines', 'Throat Bulge (Color)', 'Throat Bulge (Neck Bump)',
            'Throat Bulge (SK Deform)', 'Throat Bulge (Veins Bump)', 'Vascularity',
            'Wetness', 'Wetness (Switch)'
        ]

        allocated_props = all_initial_setup.union(effects_shaders_props)

        # All user-defined properties on this object
        all_custom_props = set(obj.keys())
        built_in_props = set(p.identifier for p in obj.bl_rna.properties)

        leftover_for_misc = [
            p for p in sorted(all_custom_props - built_in_props)
            if p not in allocated_props and not p.startswith('_')
        ]

        # Show whichever section is chosen
        if wm.custom_panel_section == 'INITIAL_SETUP':
            box = layout.box()
            # Single-column for first 6 (vertically aligned & compact)
            draw_single_column_compact(obj, first_six_props, box)
            box.separator()
            # Two-column for leftover
            draw_props_two_columns(obj, leftover_setup_props, box)

        elif wm.custom_panel_section == 'SHAPEKEY_MORPHS':
            box = layout.box()
            main_shape_keys = [
                'Heels & Boots bend', 'Elin female bend', 'Heels (Squished feet)',
                'Thicken lids', 'Thicken Lips', 'Nipples hide', 'Nipples pinch base'
            ]
            draw_shape_keys(obj, main_shape_keys, box)

            # Also auto-detect shape keys starting with "Torso -" or "Char -"
            if obj.data and obj.data.shape_keys and obj.data.shape_keys.key_blocks:
                sk_block = obj.data.shape_keys.key_blocks
                auto_keys = [k for k in sk_block.keys()
                             if k.startswith('Torso -') or k.startswith('Char -')]
                if auto_keys:
                    draw_shape_keys(obj, auto_keys, box)

            box.separator()
            box.label(text="Extra Morphs")
            extra_keys = [
                'Long nails', 'Sexy Short Nails', 'Extra Long Nails', 'Extra sharp long nails',
                'real feet 1', 'real feet 2', 'real feet 3', 'real feet 4', 'real feet 5', 'real feet 6',
                'Hitomi feet', 'Tekken Feet & Legs', 'real toes 5', 'custom feet 1', 'Necdaz_feet',
                'Feet fatness', 'Feet (Real Ndaz)', 'Feet fatness - Cassie', 'feet preset - Haruka / Young',
                'Genesis8Female__PBMNailsLength', 'Genesis8Female__PBMChameleonROse_2_Tnails',
                'Genesis8Female__PBMChameleonROse_2_Fnails2', 'Genesis8Female__PBMChameleonROse_2_Fnails'
            ]
            draw_shape_keys(obj, extra_keys, box)

        elif wm.custom_panel_section == 'EFFECTS_SHADERS':
            box = layout.box()
            draw_props_two_columns(obj, effects_shaders_props, box)
            box.separator()
            box.label(text="Makeup")
            draw_node_group_inputs(obj, "Makeup_HHP", ["Base Color", "Roughness"], box)

        elif wm.custom_panel_section == 'MISC':
            box = layout.box()
            if leftover_for_misc:
                draw_props_two_columns(obj, leftover_for_misc, box)
            else:
                box.label(text="No leftover properties.")


# -------------------------------------------------------------------
# Registration
# -------------------------------------------------------------------

def register():
    bpy.utils.register_class(CustomizePanel)
    wm = bpy.types.WindowManager
    wm.custom_panel_section = bpy.props.EnumProperty(
        name="Panel Section",
        description="Choose which section to display",
        items=[
            ('INITIAL_SETUP',     "Initial Setup",    ""),
            ('SHAPEKEY_MORPHS',   "Shapekey Morphs",  ""),
            ('EFFECTS_SHADERS',   "Effects & Shaders",""),
            ('MISC',              "Misc",             "")
        ],
        default='INITIAL_SETUP'
    )

def unregister():
    wm = bpy.types.WindowManager
    del wm.custom_panel_section
    bpy.utils.unregister_class(CustomizePanel)

if __name__ == "__main__":
    register()
