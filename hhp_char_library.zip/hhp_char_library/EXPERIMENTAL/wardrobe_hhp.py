"""Experimental HHP wardrobe package import and export tools."""

import json
import os
import re
import tempfile
import uuid

import bpy
from bpy.props import BoolProperty, CollectionProperty, StringProperty
from bpy.types import FileHandler, Operator, OperatorFileListElement
from bpy_extras.io_utils import ExportHelper, ImportHelper

from ..Customize_HHP import apply_outfit_preset, capture_outfit_preset
from ..modules import append_clothing


HHPW_EXTENSION = ".hhpw"
HHPW_FORMAT_VERSION = 1
HHPW_PAYLOAD_PREFIX = "HHPW Payload - "
WARDROBE_COLLECTION_BASE = "Wardrobe (HHP)"
HHPW_DRIVER_REMAP_KEY = "_hhpw_shapekey_driver_remap"
HHPW_ASSET_ROLE_KEY = "_hhpw_asset_role"

# Only these list-like properties are traversed when hunting for external
# references. Geometry containers hold no Object/Collection pointers and are far
# too large to walk.
NESTED_WALK_COLLECTIONS = frozenset({
    "modifiers", "constraints", "particle_systems", "canvas_surfaces",
    "drivers", "fcurves", "variables", "targets", "nla_tracks", "strips",
    "shader_effects", "grease_pencil_modifiers",
})
NESTED_WALK_MAX_DEPTH = 8
NESTED_WALK_MAX_STRUCTS = 50000

def _base_name(name):
    return re.sub(r"\.\d+$", "", name or "")


def _enumeration_number(name):
    match = re.search(r"\.(\d+)$", name or "")
    return int(match.group(1)) if match else 0


def _selected_or_scene_meshes(context, selected_only):
    source = context.selected_objects if selected_only else context.scene.objects
    return [obj for obj in source if obj.type == 'MESH']


def _collect_needed_char_specific_proxies(primary_objects):
    """Collect only Char Specific Proxy objects referenced by exported assets."""
    primary_pointers = {obj.as_pointer() for obj in primary_objects}
    collected = {}
    pending = list(primary_objects)
    visited = set()

    def add_if_proxy(value):
        if not isinstance(value, bpy.types.Object):
            return
        pointer = value.as_pointer()
        if pointer in primary_pointers or pointer in collected:
            return
        if not append_clothing.object_is_in_collection_base(
            value,
            "Char Specific Proxies",
        ):
            return
        collected[pointer] = value
        pending.append(value)

    def inspect_driver_targets(id_data):
        animation_data = getattr(id_data, "animation_data", None)
        for fcurve in getattr(animation_data, "drivers", ()) or ():
            driver = getattr(fcurve, "driver", None)
            for variable in getattr(driver, "variables", ()) or ():
                for target in getattr(variable, "targets", ()) or ():
                    add_if_proxy(getattr(target, "id", None))

    while pending:
        obj = pending.pop()
        pointer = obj.as_pointer()
        if pointer in visited:
            continue
        visited.add(pointer)

        for modifier in obj.modifiers:
            for prop in modifier.bl_rna.properties:
                if (
                    prop.identifier == "rna_type"
                    or prop.type != 'POINTER'
                ):
                    continue
                try:
                    add_if_proxy(getattr(modifier, prop.identifier))
                except Exception:
                    continue
            try:
                modifier_keys = list(modifier.keys())
            except (AttributeError, TypeError, RuntimeError):
                modifier_keys = []
            for key in modifier_keys:
                try:
                    add_if_proxy(modifier[key])
                except Exception:
                    continue

        inspect_driver_targets(obj)
        data = getattr(obj, "data", None)
        inspect_driver_targets(data)
        inspect_driver_targets(getattr(data, "shape_keys", None))

    return list(collected.values())


def _iter_material_images(objects):
    images = {}
    visited_node_trees = set()

    def visit_node_tree(node_tree):
        if node_tree is None:
            return
        pointer = node_tree.as_pointer()
        if pointer in visited_node_trees:
            return
        visited_node_trees.add(pointer)

        for node in node_tree.nodes:
            image = getattr(node, "image", None)
            if image is not None:
                images[image.as_pointer()] = image
            nested_tree = getattr(node, "node_tree", None)
            if nested_tree is not None:
                visit_node_tree(nested_tree)

    for obj in objects:
        data = getattr(obj, "data", None)
        for material in getattr(data, "materials", ()) or ():
            if material is not None and material.use_nodes:
                visit_node_tree(material.node_tree)

    return list(images.values())


def _image_is_packed(image):
    packed_file = getattr(image, "packed_file", None)
    packed_files = getattr(image, "packed_files", None)
    return bool(packed_file or (packed_files is not None and len(packed_files) > 0))


def _pack_material_images(objects):
    newly_packed = []
    for image in _iter_material_images(objects):
        if _image_is_packed(image) or image.source in {'GENERATED', 'VIEWER'}:
            continue
        try:
            image.pack()
        except Exception as exc:
            raise RuntimeError(
                f"Could not embed texture '{image.name}': {exc}"
            ) from exc
        if not _image_is_packed(image):
            raise RuntimeError(f"Could not embed texture '{image.name}'")
        newly_packed.append(image)
    return newly_packed


def _restore_image_packing(images):
    for image in images:
        try:
            if image.name in bpy.data.images and _image_is_packed(image):
                image.unpack(method='USE_ORIGINAL')
        except Exception as exc:
            print(f"HHPW: Could not restore packing for '{image.name}': {exc}")


def _detach_external_references(objects):
    """Temporarily clear Object/Collection references so they are not exported."""
    restorations = []
    visited_node_trees = set()
    visited_structs = set()
    exported_object_pointers = {obj.as_pointer() for obj in objects}

    def is_external_reference(value):
        if isinstance(value, bpy.types.Object):
            return value.as_pointer() not in exported_object_pointers
        return isinstance(value, bpy.types.Collection)

    def clear_rna_pointers(owner):
        if owner is None or not hasattr(owner, "bl_rna"):
            return
        for prop in owner.bl_rna.properties:
            if (
                prop.identifier == "rna_type"
                or prop.type != 'POINTER'
                or prop.is_readonly
            ):
                continue
            try:
                value = getattr(owner, prop.identifier)
            except Exception:
                continue
            if not is_external_reference(value):
                continue
            restorations.append(("RNA", owner, prop.identifier, value))
            try:
                setattr(owner, prop.identifier, None)
            except Exception as exc:
                raise RuntimeError(
                    f"Could not detach external reference '{prop.identifier}'"
                ) from exc

    def clear_id_properties(owner):
        if owner is None or not hasattr(owner, "keys"):
            return
        try:
            keys = list(owner.keys())
        except (AttributeError, TypeError, RuntimeError):
            return
        for key in keys:
            try:
                value = owner[key]
            except Exception:
                continue
            if is_external_reference(value):
                restorations.append(("ID_PROPERTY", owner, key, value))
                try:
                    owner[key] = None
                except Exception:
                    try:
                        del owner[key]
                    except Exception as exc:
                        raise RuntimeError(
                            f"Could not detach external custom-property reference '{key}'"
                        ) from exc
            elif hasattr(value, "keys"):
                clear_id_properties(value)

    def clear_driver_targets(id_data):
        animation_data = getattr(id_data, "animation_data", None)
        if animation_data is None:
            return
        for fcurve in getattr(animation_data, "drivers", ()) or ():
            driver = getattr(fcurve, "driver", None)
            for variable in getattr(driver, "variables", ()) or ():
                for target in getattr(variable, "targets", ()) or ():
                    target_id = getattr(target, "id", None)
                    if not is_external_reference(target_id):
                        continue
                    restorations.append(("DRIVER", target, "id", target_id))
                    target.id = None

    def clear_node_tree(node_tree):
        if node_tree is None:
            return
        pointer = node_tree.as_pointer()
        if pointer in visited_node_trees:
            return
        visited_node_trees.add(pointer)
        clear_driver_targets(node_tree)
        clear_id_properties(node_tree)
        for node in node_tree.nodes:
            clear_rna_pointers(node)
            clear_id_properties(node)
            nested_tree = getattr(node, "node_tree", None)
            if nested_tree is not None:
                clear_node_tree(nested_tree)

    def walk_struct(owner, depth=0):
        """Clear external references anywhere inside a datablock's sub-structs.

        Physics settings, effector weights, particle systems and driver targets
        live in nested structs, and anything still pointed at gets pulled into
        the exported file as an indirect dependency.
        """
        if owner is None or depth > NESTED_WALK_MAX_DEPTH:
            return
        if not hasattr(owner, "bl_rna"):
            return
        if len(visited_structs) > NESTED_WALK_MAX_STRUCTS:
            return
        try:
            identity = (owner.as_pointer(), type(owner).__name__)
        except Exception:
            identity = None
        if identity is not None:
            if identity in visited_structs:
                return
            visited_structs.add(identity)

        for prop in owner.bl_rna.properties:
            identifier = prop.identifier
            if identifier == "rna_type":
                continue
            if prop.type == 'POINTER':
                try:
                    value = getattr(owner, identifier)
                except Exception:
                    continue
                if is_external_reference(value):
                    if prop.is_readonly:
                        continue
                    try:
                        setattr(owner, identifier, None)
                    except Exception as exc:
                        print(
                            f"HHPW: Could not detach '{identifier}' on "
                            f"{owner!r}: {exc}"
                        )
                        continue
                    restorations.append(("RNA", owner, identifier, value))
                    continue
                if isinstance(value, bpy.types.ID):
                    continue
                walk_struct(value, depth + 1)
            elif prop.type == 'COLLECTION':
                if identifier not in NESTED_WALK_COLLECTIONS:
                    continue
                try:
                    items = getattr(owner, identifier)
                except Exception:
                    continue
                for item in items:
                    if item is None or isinstance(item, bpy.types.ID):
                        continue
                    walk_struct(item, depth + 1)

    try:
        for obj in objects:
            transform_state = (
                obj.matrix_basis.copy(),
                obj.matrix_parent_inverse.copy(),
                obj.matrix_world.copy(),
            )
            restorations.append(("OBJECT_TRANSFORM", obj, "", transform_state))
            had_parent = obj.parent is not None
            # matrix_world holds the constrained result, so baking it into the
            # local matrix would make constraints apply twice on import.
            is_constrained = any(
                not constraint.mute for constraint in obj.constraints
            )
            walk_struct(obj)
            if had_parent and not is_constrained:
                obj.matrix_world = transform_state[2]
            clear_id_properties(obj)

            for constraint in obj.constraints:
                clear_id_properties(constraint)

            for modifier in obj.modifiers:
                clear_id_properties(modifier)
                clear_node_tree(getattr(modifier, "node_group", None))

            for particle_system in getattr(obj, "particle_systems", ()) or ():
                walk_struct(getattr(particle_system, "settings", None))

            data = getattr(obj, "data", None)
            walk_struct(data)
            clear_id_properties(data)
            shape_keys = getattr(data, "shape_keys", None)
            walk_struct(shape_keys)

            for material in getattr(data, "materials", ()) or ():
                if material is None:
                    continue
                clear_driver_targets(material)
                clear_id_properties(material)
                if material.use_nodes:
                    clear_node_tree(material.node_tree)
    except Exception:
        _restore_external_references(restorations)
        raise

    return restorations


def _restore_external_references(restorations):
    for kind, owner, identifier, value in reversed(restorations):
        try:
            if kind == "RNA":
                setattr(owner, identifier, value)
            elif kind == "DRIVER":
                owner.id = value
            elif kind == "OBJECT_TRANSFORM":
                owner.matrix_basis = value[0]
                owner.matrix_parent_inverse = value[1]
            else:
                owner[identifier] = value
        except Exception as exc:
            print(
                f"HHPW: Could not restore external reference "
                f"'{identifier}': {exc}"
            )


def _attach_driver_remap_metadata(objects):
    """Store external object and shape-key driver roles without their target objects."""
    exported_object_pointers = {obj.as_pointer() for obj in objects}
    property_states = []

    for obj in objects:
        records = []

        def capture_driver_owner(id_data, owner_kind):
            animation_data = getattr(id_data, "animation_data", None)
            if animation_data is None:
                return
            for fcurve_index, fcurve in enumerate(animation_data.drivers):
                driver = getattr(fcurve, "driver", None)
                for variable_index, variable in enumerate(
                    getattr(driver, "variables", ()) or ()
                ):
                    for target_index, target in enumerate(variable.targets):
                        target_id = getattr(target, "id", None)
                        if (
                            not isinstance(target_id, bpy.types.Object)
                            or target_id.as_pointer() in exported_object_pointers
                            or target_id.type not in {'ARMATURE', 'MESH'}
                        ):
                            continue
                        records.append({
                            "fcurve_index": fcurve_index,
                            "data_path": fcurve.data_path,
                            "array_index": fcurve.array_index,
                            "variable_index": variable_index,
                            "target_index": target_index,
                            "target_kind": target_id.type,
                            "owner": owner_kind,
                        })

        capture_driver_owner(obj, "OBJECT")
        data = getattr(obj, "data", None)
        capture_driver_owner(getattr(data, "shape_keys", None), "SHAPE_KEYS")

        if not records:
            continue
        had_property = HHPW_DRIVER_REMAP_KEY in obj
        previous_value = obj.get(HHPW_DRIVER_REMAP_KEY) if had_property else None
        property_states.append((obj, had_property, previous_value))
        obj[HHPW_DRIVER_REMAP_KEY] = json.dumps(records, separators=(",", ":"))

    return property_states


def _attach_asset_role_metadata(primary_objects, proxy_objects):
    property_states = []
    primary_pointers = {obj.as_pointer() for obj in primary_objects}
    for obj in [*primary_objects, *proxy_objects]:
        had_property = HHPW_ASSET_ROLE_KEY in obj
        previous_value = obj.get(HHPW_ASSET_ROLE_KEY) if had_property else None
        property_states.append((obj, had_property, previous_value))
        obj[HHPW_ASSET_ROLE_KEY] = (
            "PRIMARY" if obj.as_pointer() in primary_pointers else "CHAR_SPECIFIC_PROXY"
        )
    return property_states


def _restore_asset_role_metadata(property_states):
    for obj, had_property, previous_value in property_states:
        try:
            if had_property:
                obj[HHPW_ASSET_ROLE_KEY] = previous_value
            elif HHPW_ASSET_ROLE_KEY in obj:
                del obj[HHPW_ASSET_ROLE_KEY]
        except Exception as exc:
            print(f"HHPW: Could not restore asset role on '{obj.name}': {exc}")


def _restore_driver_remap_metadata(property_states):
    for obj, had_property, previous_value in property_states:
        try:
            if had_property:
                obj[HHPW_DRIVER_REMAP_KEY] = previous_value
            elif HHPW_DRIVER_REMAP_KEY in obj:
                del obj[HHPW_DRIVER_REMAP_KEY]
        except Exception as exc:
            print(
                f"HHPW: Could not restore temporary driver metadata on "
                f"'{obj.name}': {exc}"
            )


def _list_unexpected_payload_objects(blend_path, expected_names):
    """Report objects that were pulled in as unwanted indirect dependencies."""
    try:
        with bpy.data.libraries.load(blend_path) as (data_from, _data_to):
            written_names = list(data_from.objects)
    except Exception as exc:
        print(f"HHPW: Could not verify exported contents: {exc}")
        return []
    return [name for name in written_names if name not in expected_names]


def _write_hhpw(filepath, objects):
    output_path = os.path.abspath(bpy.path.abspath(filepath))
    output_directory = os.path.dirname(output_path)
    os.makedirs(output_directory, exist_ok=True)

    proxy_objects = _collect_needed_char_specific_proxies(objects)
    export_objects = [*objects, *proxy_objects]
    payload = bpy.data.collections.new(f"{HHPW_PAYLOAD_PREFIX}{uuid.uuid4().hex}")
    packed_images = []
    detached_references = []
    driver_metadata_states = []
    asset_role_states = []
    temp_blend_path = ""
    unexpected_objects = []
    try:
        for obj in export_objects:
            payload.objects.link(obj)

        manifest = {
            "format": "HHPW",
            "version": HHPW_FORMAT_VERSION,
            "object_names": [obj.name for obj in objects],
            "char_specific_proxy_names": [obj.name for obj in proxy_objects],
        }
        payload["hhpw_manifest"] = json.dumps(manifest, separators=(",", ":"))

        packed_images = _pack_material_images(export_objects)
        asset_role_states = _attach_asset_role_metadata(objects, proxy_objects)
        driver_metadata_states = _attach_driver_remap_metadata(export_objects)
        detached_references = _detach_external_references(export_objects)
        file_descriptor, temp_blend_path = tempfile.mkstemp(
            prefix=".hhpw_export_",
            suffix=".blend",
            dir=output_directory,
        )
        os.close(file_descriptor)
        os.remove(temp_blend_path)

        bpy.data.libraries.write(
            temp_blend_path,
            {payload},
            path_remap='RELATIVE_ALL',
            fake_user=True,
            compress=True,
        )
        unexpected_objects = _list_unexpected_payload_objects(
            temp_blend_path,
            {obj.name for obj in export_objects},
        )
        os.replace(temp_blend_path, output_path)
        temp_blend_path = ""
    finally:
        if temp_blend_path and os.path.exists(temp_blend_path):
            os.remove(temp_blend_path)
        _restore_external_references(detached_references)
        _restore_driver_remap_metadata(driver_metadata_states)
        _restore_asset_role_metadata(asset_role_states)
        _restore_image_packing(packed_images)
        if payload.name in bpy.data.collections:
            bpy.data.collections.remove(payload)
    return unexpected_objects


def _safe_filename(name):
    safe_name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    return safe_name or "Wardrobe Mesh"


def _enumerated_filepath(directory, stem):
    candidate = os.path.join(directory, f"{stem}{HHPW_EXTENSION}")
    if not os.path.exists(candidate):
        return candidate
    index = 1
    while True:
        candidate = os.path.join(
            directory,
            f"{stem}.{index:03d}{HHPW_EXTENSION}",
        )
        if not os.path.exists(candidate):
            return candidate
        index += 1


def _find_clothes_collection(source_mesh):
    collections = append_clothing.find_clothes_collections_in_parent(source_mesh)
    if not collections:
        return None
    return min(
        collections,
        key=lambda collection: (
            _enumeration_number(collection.name),
            collection.name.lower(),
        ),
    )


def _find_automatic_deform_target(context, source_mesh):
    primary_proxies = append_clothing.find_primary_fullbody_proxy(source_mesh)
    if primary_proxies:
        return min(
            primary_proxies,
            key=lambda obj: (
                _enumeration_number(obj.name),
                obj.name.lower(),
            ),
        )

    shared_data_meshes = [
        obj for obj in context.scene.objects
        if obj.type == 'MESH'
        and obj is not source_mesh
        and obj.data == source_mesh.data
    ]
    if shared_data_meshes:
        return min(
            shared_data_meshes,
            key=lambda obj: (
                _enumeration_number(obj.name),
                obj.name.lower(),
            ),
        )
    return source_mesh


def _assign_missing_remap_targets(collections, deform_target):
    assigned = 0
    for collection in collections:
        for obj in collection.all_objects:
            if obj.type != 'MESH':
                continue
            for modifier in obj.modifiers:
                if modifier.type == 'SURFACE_DEFORM' and modifier.target is None:
                    modifier.target = deform_target
                    assigned += 1
    return assigned


def _remap_captured_drivers(collections, source_mesh, source_armature):
    remapped = 0
    visited_objects = set()

    for collection in collections:
        for obj in collection.all_objects:
            pointer = obj.as_pointer()
            if pointer in visited_objects or obj.type != 'MESH':
                continue
            visited_objects.add(pointer)

            raw_records = obj.get(HHPW_DRIVER_REMAP_KEY)
            if not isinstance(raw_records, str):
                continue
            try:
                records = json.loads(raw_records)
            except (TypeError, ValueError):
                records = []
            try:
                del obj[HHPW_DRIVER_REMAP_KEY]
            except Exception:
                pass

            for record in records:
                owner = (
                    obj
                    if record.get("owner") == "OBJECT"
                    else getattr(obj.data, "shape_keys", None)
                )
                animation_data = getattr(owner, "animation_data", None)
                if animation_data is None:
                    continue
                fcurves = list(animation_data.drivers)
                fcurve = None
                fcurve_index = record.get("fcurve_index", -1)
                if 0 <= fcurve_index < len(fcurves):
                    candidate = fcurves[fcurve_index]
                    if (
                        candidate.data_path == record.get("data_path")
                        and candidate.array_index == record.get("array_index")
                    ):
                        fcurve = candidate
                if fcurve is None:
                    fcurve = next(
                        (
                            candidate for candidate in fcurves
                            if candidate.data_path == record.get("data_path")
                            and candidate.array_index == record.get("array_index")
                        ),
                        None,
                    )
                if fcurve is None:
                    continue

                variables = list(fcurve.driver.variables)
                variable_index = record.get("variable_index", -1)
                if not 0 <= variable_index < len(variables):
                    continue
                targets = list(variables[variable_index].targets)
                target_index = record.get("target_index", -1)
                if not 0 <= target_index < len(targets):
                    continue

                remap_target = (
                    source_armature
                    if record.get("target_kind") == 'ARMATURE'
                    else source_mesh
                )
                if remap_target is not None:
                    targets[target_index].id = remap_target
                    remapped += 1

    return remapped


def _remap_char_specific_proxy_constraints(collections, source_armature):
    if source_armature is None:
        return
    for collection in collections:
        for obj in collection.all_objects:
            if obj.get(HHPW_ASSET_ROLE_KEY) != "CHAR_SPECIFIC_PROXY":
                continue
            if obj.type != 'LATTICE':
                continue
            for constraint in obj.constraints:
                if constraint.type == 'CHILD_OF':
                    constraint.target = source_armature


def _find_or_create_wardrobe_collection(clothes_collection):
    candidates = [
        collection for collection in clothes_collection.children
        if _base_name(collection.name) == WARDROBE_COLLECTION_BASE
    ]
    if candidates:
        return min(
            candidates,
            key=lambda collection: (
                _enumeration_number(collection.name),
                collection.name.lower(),
            ),
        )

    wardrobe = bpy.data.collections.new(WARDROBE_COLLECTION_BASE)
    wardrobe.color_tag = 'NONE'
    clothes_collection.children.link(wardrobe)
    return wardrobe


def _find_or_create_child_collection(parent, base_name):
    candidates = [
        collection for collection in parent.children
        if _base_name(collection.name) == base_name
    ]
    if candidates:
        return min(
            candidates,
            key=lambda collection: (
                _enumeration_number(collection.name),
                collection.name.lower(),
            ),
        )

    collection = bpy.data.collections.new(base_name)
    collection.color_tag = 'NONE'
    parent.children.link(collection)
    return collection


def _find_or_create_hhp_collection_hierarchy(scene_collection):
    """Create the reference HHP hierarchy when importing without a character."""
    char_root = _find_or_create_child_collection(scene_collection, "Char (HHP)")
    proxy_root = _find_or_create_child_collection(char_root, "Proxies (HHP)")
    _find_or_create_child_collection(proxy_root, "Deform")
    _find_or_create_child_collection(proxy_root, "Physics - BS")
    _find_or_create_child_collection(proxy_root, "Physics - HP")
    char_specific = _find_or_create_child_collection(
        proxy_root,
        "Char Specific Proxies",
    )

    _find_or_create_child_collection(char_root, "Collision")
    _find_or_create_child_collection(char_root, "Controllers (HHP)")
    _find_or_create_child_collection(char_root, "Block Proxy")
    clothes = _find_or_create_child_collection(char_root, "Clothes")
    appendages = _find_or_create_child_collection(char_root, "Appendages")
    _find_or_create_child_collection(appendages, "Hair")
    _find_or_create_child_collection(appendages, "Eyes")
    _find_or_create_child_collection(appendages, "Char Appendage")
    _find_or_create_child_collection(char_root, "Default assets")
    _find_or_create_child_collection(char_root, "Genesis8Female_Widgets")

    return clothes, char_specific


def _find_or_create_char_specific_proxy_collection(
    source_mesh,
):
    candidates = (
        append_clothing.find_char_specific_proxies_collections_in_parent(
            source_mesh
        )
        if source_mesh is not None
        else []
    )
    if candidates:
        return min(
            candidates,
            key=lambda collection: (
                _enumeration_number(collection.name),
                collection.name.lower(),
            ),
        )

    if source_mesh is None:
        return None

    char_root = append_clothing.get_top_parent_collection(source_mesh)
    if char_root is None:
        return None
    proxy_roots = [
        collection for collection in char_root.children
        if _base_name(collection.name) == "Proxies (HHP)"
    ]
    if proxy_roots:
        proxy_root = min(
            proxy_roots,
            key=lambda collection: (
                _enumeration_number(collection.name),
                collection.name.lower(),
            ),
        )
    else:
        proxy_root = bpy.data.collections.new("Proxies (HHP)")
        proxy_root.color_tag = 'NONE'
        char_root.children.link(proxy_root)

    proxy_collection = bpy.data.collections.new("Char Specific Proxies")
    proxy_collection.color_tag = 'NONE'
    proxy_root.children.link(proxy_collection)
    return proxy_collection


def _ensure_collection_visible(context, collection):
    """Unhide a collection and its hierarchy in data and the active view layer."""
    collections_to_show = {collection}
    pending = [collection]
    while pending:
        child = pending.pop()
        for parent in bpy.data.collections:
            if child.name in parent.children and parent not in collections_to_show:
                collections_to_show.add(parent)
                pending.append(parent)

    for item in collections_to_show:
        item.hide_viewport = False
        item.hide_render = False

    def reveal_layer_path(layer_collection, target, path):
        current_path = path + [layer_collection]
        if layer_collection.collection == target:
            for layer_item in current_path:
                layer_item.exclude = False
                layer_item.hide_viewport = False
            return True
        for child_layer in layer_collection.children:
            if reveal_layer_path(child_layer, target, current_path):
                return True
        return False

    reveal_layer_path(
        context.view_layer.layer_collection,
        collection,
        [],
    )


def _unhide_collection_in_view_layer(context, collection):
    """Unhide and include a collection without changing viewport/render toggles."""
    def reveal_layer_path(layer_collection, target, path):
        current_path = path + [layer_collection]
        if layer_collection.collection == target:
            for layer_item in current_path:
                layer_item.exclude = False
                layer_item.hide_viewport = False
            return True
        for child_layer in layer_collection.children:
            if reveal_layer_path(child_layer, target, current_path):
                return True
        return False

    reveal_layer_path(
        context.view_layer.layer_collection,
        collection,
        [],
    )


def _remove_loaded_data(collections, objects):
    for obj in objects:
        if obj is not None and obj.name in bpy.data.objects:
            bpy.data.objects.remove(obj, do_unlink=True)
    for collection in collections:
        if collection is not None and collection.name in bpy.data.collections:
            bpy.data.collections.remove(collection)


def _read_manifest(payload):
    raw_manifest = payload.get("hhpw_manifest")
    if not isinstance(raw_manifest, str):
        return None
    try:
        manifest = json.loads(raw_manifest)
    except (TypeError, ValueError):
        return None
    if (
        manifest.get("format") != "HHPW"
        or manifest.get("version") != HHPW_FORMAT_VERSION
    ):
        return None
    return manifest


def _load_hhpw_payload(filepath):
    original_object_pointers = {obj.as_pointer() for obj in bpy.data.objects}
    payload_names = []

    with bpy.data.libraries.load(filepath, link=False) as (data_from, data_to):
        payload_names = [
            name for name in data_from.collections
            if name.startswith(HHPW_PAYLOAD_PREFIX)
        ]
        if not payload_names:
            raise RuntimeError("The file does not contain a valid HHPW payload")
        data_to.collections = payload_names

    loaded_collections = [
        collection for collection in data_to.collections
        if collection is not None
    ]
    loaded_objects = [
        obj for obj in bpy.data.objects
        if obj.as_pointer() not in original_object_pointers
    ]

    valid_payloads = [
        collection for collection in loaded_collections
        if _read_manifest(collection) is not None
    ]
    if not valid_payloads:
        _remove_loaded_data(loaded_collections, loaded_objects)
        raise RuntimeError(
            "The file is not a supported HHPW package or uses a newer version"
        )
    return valid_payloads, loaded_objects


def _remove_indirect_dependencies(loaded_objects, intended_pointers):
    """Discard objects a package dragged along that are not part of the asset."""
    removed_names = []
    for obj in loaded_objects:
        if obj is None:
            continue
        try:
            name = obj.name
        except ReferenceError:
            continue
        if name not in bpy.data.objects:
            continue
        if bpy.data.objects[name] is not obj:
            continue
        if obj.as_pointer() in intended_pointers:
            continue
        removed_names.append(name)
        bpy.data.objects.remove(obj, do_unlink=True)
    if removed_names:
        print(f"HHPW: Discarded imported dependencies: {removed_names}")
    return removed_names


def _merge_payload_into_wardrobe(
    payload_collections,
    wardrobe,
    source_mesh,
    proxy_collection=None,
):
    imported_objects = []
    for payload in payload_collections:
        for obj in list(payload.objects):
            role = obj.get(HHPW_ASSET_ROLE_KEY, "PRIMARY")
            if HHPW_ASSET_ROLE_KEY in obj:
                del obj[HHPW_ASSET_ROLE_KEY]
            target_collection = wardrobe
            if role == "CHAR_SPECIFIC_PROXY":
                if proxy_collection is None:
                    proxy_collection = (
                        _find_or_create_char_specific_proxy_collection(source_mesh)
                    )
                if proxy_collection is not None:
                    target_collection = proxy_collection

            if obj.name not in target_collection.objects:
                target_collection.objects.link(obj)
            payload.objects.unlink(obj)
            if role != "CHAR_SPECIFIC_PROXY":
                imported_objects.append(obj)

        for child in list(payload.children):
            if child.name not in wardrobe.children:
                wardrobe.children.link(child)
            payload.children.unlink(child)

        for parent in list(bpy.data.collections):
            if payload.name in parent.children:
                parent.children.unlink(payload)
        if payload.name in bpy.context.scene.collection.children:
            bpy.context.scene.collection.children.unlink(payload)
        bpy.data.collections.remove(payload)
    return imported_objects, proxy_collection


def _update_outfit_presets(context, source_mesh, imported_objects):
    if not imported_objects or "presets" not in source_mesh or not source_mesh["presets"]:
        return
    original_active = context.view_layer.objects.active
    context.view_layer.objects.active = source_mesh
    current_state = capture_outfit_preset(context)
    try:
        append_clothing.update_presets_after_append(source_mesh, imported_objects)
        apply_outfit_preset(current_state)
    finally:
        context.view_layer.objects.active = original_active


def _select_imported_objects(context, imported_objects):
    if context.mode != 'OBJECT':
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except RuntimeError:
            pass

    for obj in context.view_layer.objects:
        obj.select_set(False)

    selected_objects = [
        obj for obj in imported_objects
        if append_clothing.is_valid_object(obj)
        and obj.name in context.view_layer.objects
    ]
    for obj in selected_objects:
        obj.select_set(True)
    if selected_objects:
        context.view_layer.objects.active = selected_objects[0]


class HHP_WARDROBE_OT_export(Operator, ExportHelper):
    """Export Blender-native wardrobe meshes and their embedded material textures."""

    bl_idname = "hhp_wardrobe.export_hhpw"
    bl_label = "Export .hhpw"
    bl_description = (
        "Export meshes with their mesh data, modifiers, materials, and embedded "
        "material textures as an experimental HHP wardrobe package"
    )
    bl_options = {'REGISTER'}

    filename_ext = HHPW_EXTENSION
    filter_glob: StringProperty(default="*.hhpw", options={'HIDDEN'})
    selected_meshes_only: BoolProperty(
        name="Selected Meshes Only",
        description="Export only selected mesh objects instead of every mesh in the scene",
        default=True,
    )
    export_each_mesh_separately: BoolProperty(
        name="Export Each Mesh Separately",
        description="Create one HHPW file per mesh instead of storing all exported meshes in one file",
        default=False,
    )
    use_object_names_as_export_names: BoolProperty(
        name="Use Object Names as Export Names",
        description="Name each separate HHPW file after its exported mesh object",
        default=True,
    )

    def draw(self, context):
        layout = self.layout
        selected_only_row = layout.row()
        selected_only_row.enabled = False
        selected_only_row.prop(self, "selected_meshes_only")
        layout.prop(self, "export_each_mesh_separately")
        if self.export_each_mesh_separately:
            layout.prop(self, "use_object_names_as_export_names")

    def invoke(self, context, event):
        selected_objects = list(context.selected_objects)
        if not selected_objects:
            self.report({'ERROR'}, "Select at least one mesh object to export as HHPW")
            return {'CANCELLED'}
        if any(obj.type != 'MESH' for obj in selected_objects):
            self.report(
                {'ERROR'},
                "Only mesh objects can be exported as HHPW",
            )
            return {'CANCELLED'}

        self.selected_meshes_only = True
        active = context.active_object
        if active is not None and active.type == 'MESH':
            self.filepath = bpy.path.ensure_ext(
                _safe_filename(active.name),
                self.filename_ext,
            )
        return ExportHelper.invoke(self, context, event)

    def execute(self, context):
        self.selected_meshes_only = True
        if any(obj.type != 'MESH' for obj in context.selected_objects):
            self.report({'ERROR'}, "Only mesh objects can be exported as HHPW")
            return {'CANCELLED'}
        meshes = _selected_or_scene_meshes(context, self.selected_meshes_only)
        if not meshes:
            scope = "selected" if self.selected_meshes_only else "scene"
            self.report({'ERROR'}, f"No {scope} mesh objects are available to export")
            return {'CANCELLED'}

        unexpected_objects = []
        try:
            if self.export_each_mesh_separately:
                directory = os.path.dirname(os.path.abspath(bpy.path.abspath(self.filepath)))
                chosen_export_name = os.path.splitext(
                    os.path.basename(self.filepath)
                )[0].strip()
                if not self.use_object_names_as_export_names and not chosen_export_name:
                    self.report({'ERROR'}, "Enter an export name")
                    return {'CANCELLED'}
                exported_paths = []
                for obj in meshes:
                    export_stem = (
                        _safe_filename(obj.name)
                        if self.use_object_names_as_export_names
                        else _safe_filename(chosen_export_name)
                    )
                    filepath = _enumerated_filepath(directory, export_stem)
                    unexpected_objects += _write_hhpw(filepath, [obj])
                    exported_paths.append(filepath)
                self.report(
                    {'INFO'},
                    f"Exported {len(exported_paths)} separate HHPW files to '{directory}'",
                )
            else:
                filepath = bpy.path.ensure_ext(self.filepath, self.filename_ext)
                unexpected_objects += _write_hhpw(filepath, meshes)
                self.report(
                    {'INFO'},
                    f"Exported {len(meshes)} mesh(es) to '{filepath}'",
                )
        except Exception as exc:
            self.report({'ERROR'}, f"HHPW export failed: {exc}")
            return {'CANCELLED'}

        if unexpected_objects:
            unique_names = sorted(set(unexpected_objects))
            print(f"HHPW: Unexpected objects included in export: {unique_names}")
            preview = ", ".join(unique_names[:3])
            if len(unique_names) > 3:
                preview += f", +{len(unique_names) - 3} more"
            self.report(
                {'WARNING'},
                f"Extra objects were pulled in as dependencies: {preview}",
            )
        return {'FINISHED'}


class HHP_WARDROBE_OT_import_select(Operator, ImportHelper):
    """Choose one or more experimental HHP wardrobe packages to import."""

    bl_idname = "hhp_wardrobe.import_hhpw"
    bl_label = "Import .hhpw"
    bl_description = (
        "Choose HHPW wardrobe packages to import and remap to an HHP character"
    )
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = HHPW_EXTENSION
    filter_glob: StringProperty(default="*.hhpw", options={'HIDDEN'})
    filepath: StringProperty(
        name="File Path",
        description="HHPW wardrobe package to import",
        subtype='FILE_PATH',
        options={'SKIP_SAVE'},
    )
    files: CollectionProperty(
        name="HHPW Files",
        type=OperatorFileListElement,
        options={'HIDDEN', 'SKIP_SAVE'},
    )
    directory: StringProperty(subtype='DIR_PATH', options={'HIDDEN', 'SKIP_SAVE'})
    filepaths_json: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    source_mesh_name: StringProperty(
        name="Source Mesh",
        description="HHP character mesh that receives and remaps the imported wardrobe meshes",
    )

    def draw(self, context):
        row = self.layout.row(align=True)
        row.prop_search(
            self,
            "source_mesh_name",
            bpy.data,
            "objects",
            text="Source Mesh",
        )

    def invoke(self, context, event):
        if not self.source_mesh_name:
            source_mesh = (
                append_clothing.find_highest_visible_hhp_character_mesh(context)
            )
            if source_mesh is not None:
                self.source_mesh_name = source_mesh.name
        if self.filepath:
            return self.execute(context)
        return ImportHelper.invoke(self, context, event)

    def execute(self, context):
        if not self.filepaths_json:
            if self.files:
                filepaths = [
                    os.path.join(self.directory, item.name)
                    for item in self.files
                ]
            else:
                filepaths = [self.filepath]
            self.filepaths_json = json.dumps(filepaths)
        if not self.source_mesh_name:
            source_mesh = (
                append_clothing.find_highest_visible_hhp_character_mesh(context)
            )
            if source_mesh is not None:
                self.source_mesh_name = source_mesh.name
        return _HHPWImportExecution.execute(self, context)


class _HHPWImportExecution:
    """Shared HHPW import execution used by file selection and drag-and-drop."""

    def execute(self, context):
        source_mesh = bpy.data.objects.get(self.source_mesh_name)
        if source_mesh is not None and source_mesh.type != 'MESH':
            source_mesh = None

        armature_modifier = (
            next(
                (
                    modifier for modifier in source_mesh.modifiers
                    if modifier.type == 'ARMATURE' and modifier.object is not None
                ),
                None,
            )
            if source_mesh is not None
            else None
        )
        remap_import = source_mesh is not None and armature_modifier is not None

        if remap_import:
            clothes_collection = _find_clothes_collection(source_mesh)
            if clothes_collection is None:
                char_root = append_clothing.get_top_parent_collection(source_mesh)
                if char_root is None:
                    remap_import = False
                else:
                    clothes_collection = bpy.data.collections.new("Clothes")
                    clothes_collection.color_tag = 'COLOR_03'
                    char_root.children.link(clothes_collection)

        if not remap_import:
            source_mesh = None
            armature_modifier = None
            clothes_collection, no_remap_proxy_collection = (
                _find_or_create_hhp_collection_hierarchy(
                    context.scene.collection
                )
            )
        else:
            no_remap_proxy_collection = None

        wardrobe = _find_or_create_wardrobe_collection(clothes_collection)
        _ensure_collection_visible(context, wardrobe)
        deform_target = (
            _find_automatic_deform_target(context, source_mesh)
            if remap_import
            else None
        )
        try:
            filepaths = json.loads(self.filepaths_json)
        except (TypeError, ValueError):
            filepaths = []
        if not filepaths:
            self.report({'ERROR'}, "No HHPW files were selected")
            return {'CANCELLED'}

        all_imported_objects = []
        all_clash_records = []
        target_proxy_collection = no_remap_proxy_collection
        imported_file_count = 0

        for filepath in filepaths:
            filepath = os.path.abspath(bpy.path.abspath(filepath))
            if not os.path.isfile(filepath):
                self.report({'WARNING'}, f"Skipped missing file: {filepath}")
                continue

            if remap_import:
                char_root = append_clothing.get_top_parent_collection(source_mesh)
                existing_roots = (
                    [char_root] if char_root is not None else [clothes_collection]
                )
                existing_assets = append_clothing.collect_mesh_assets_by_base(
                    existing_roots,
                    include_char_specific=True,
                )
                existing_collection_bases = set(
                    append_clothing.collect_descendant_collection_bases(
                        existing_roots
                    )
                )
                existing_collection_bases.update(
                    append_clothing.collect_descendant_collection_bases(
                        [clothes_collection]
                    )
                )
            else:
                existing_assets = {}
                existing_collection_bases = set()

            payload_collections = []
            loaded_objects = []
            try:
                payload_collections, loaded_objects = _load_hhpw_payload(filepath)
                intended_pointers = {
                    obj.as_pointer()
                    for payload in payload_collections
                    for obj in payload.all_objects
                }
                for payload in payload_collections:
                    wardrobe.children.link(payload)

                clash_records = []
                if remap_import:
                    clash_records = append_clothing.build_asset_clash_records(
                        payload_collections,
                        existing_assets,
                        existing_collection_bases,
                    )
                    preserved_targets = {
                        record["appended_obj"].as_pointer()
                        for record in clash_records
                        if record.get("is_surface_deform_target")
                        and record.get("appended_obj") is not None
                    }

                    append_clothing.WM_OT_AppendClothingExecute.apply_remapping_to_appended_meshes(
                        self,
                        context,
                        payload_collections,
                        source_mesh.name,
                        source_mesh.name,
                        preserved_targets,
                    )
                    _assign_missing_remap_targets(
                        payload_collections,
                        deform_target,
                    )
                    _remap_captured_drivers(
                        payload_collections,
                        source_mesh,
                        armature_modifier.object,
                    )
                    _remap_char_specific_proxy_constraints(
                        payload_collections,
                        armature_modifier.object,
                    )
                _remove_indirect_dependencies(loaded_objects, intended_pointers)
                clash_records = [
                    record for record in clash_records
                    if append_clothing.is_valid_object(record.get("appended_obj"))
                    and append_clothing.is_valid_object(record.get("existing_obj"))
                ]
                imported_objects, imported_proxy_collection = (
                    _merge_payload_into_wardrobe(
                        payload_collections,
                        wardrobe,
                        source_mesh,
                        proxy_collection=target_proxy_collection,
                    )
                )
                if imported_proxy_collection is not None:
                    target_proxy_collection = imported_proxy_collection
                    _unhide_collection_in_view_layer(
                        context,
                        target_proxy_collection,
                    )
                all_imported_objects.extend(imported_objects)
                all_clash_records.extend(clash_records)
                imported_file_count += 1
            except Exception as exc:
                _remove_loaded_data(payload_collections, loaded_objects)
                self.report(
                    {'WARNING'},
                    f"Could not import '{os.path.basename(filepath)}': {exc}",
                )

        if not imported_file_count:
            self.report({'ERROR'}, "No HHPW packages were imported")
            return {'CANCELLED'}

        clash_popup_opened = False
        if remap_import:
            _update_outfit_presets(context, source_mesh, all_imported_objects)
            char_root = append_clothing.get_top_parent_collection(source_mesh)
            clash_popup_opened = append_clothing.launch_asset_clash_resolver(
                context,
                all_clash_records,
                char_root_collection=char_root,
                char_specific_proxy_collection=target_proxy_collection,
            )

        message = (
            f"Imported {len(all_imported_objects)} object(s) from "
            f"{imported_file_count} HHPW package(s) into '{wardrobe.name}'"
        )
        if clash_popup_opened:
            message += "; resolve asset clashes in the popup"
        elif not remap_import:
            message += "; no HHP mesh found, imported without remapping"
        _select_imported_objects(context, all_imported_objects)
        self.report({'INFO'}, message)
        return {'FINISHED'}


class HHP_WARDROBE_FH_import(FileHandler):
    """Handle HHPW files dropped into a Blender 3D View."""

    bl_idname = "HHP_WARDROBE_FH_import"
    bl_label = "Import HHP Wardrobe"
    bl_import_operator = HHP_WARDROBE_OT_import_select.bl_idname
    bl_file_extensions = HHPW_EXTENSION

    @classmethod
    def poll_drop(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'


def draw_wardrobe_box(layout, context):
    """Draw the collapsible Wardrobe (HHP) box in the experimental panel."""
    box = layout.box()
    header = box.row(align=True)
    header.alignment = 'LEFT'
    expanded = getattr(context.window_manager, "hhp_wardrobe_expanded", True)
    icon = 'TRIA_DOWN' if expanded else 'TRIA_RIGHT'
    header.prop(
        context.window_manager,
        "hhp_wardrobe_expanded",
        text="",
        icon=icon,
        emboss=False,
        icon_only=True,
    )
    header.prop(
        context.window_manager,
        "hhp_wardrobe_expanded",
        text="Wardrobe (HHP)",
        icon='MOD_CLOTH',
        emboss=False,
    )

    if expanded:
        actions = box.row(align=True)
        actions.operator(HHP_WARDROBE_OT_import_select.bl_idname, icon='IMPORT')
        actions.operator(HHP_WARDROBE_OT_export.bl_idname, icon='EXPORT')


classes = (
    HHP_WARDROBE_OT_export,
    HHP_WARDROBE_OT_import_select,
    HHP_WARDROBE_FH_import,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.hhp_wardrobe_expanded = BoolProperty(
        name="Wardrobe (HHP) Expanded",
        description="Show or hide the experimental Wardrobe (HHP) tools",
        default=True,
    )


def unregister():
    if hasattr(bpy.types.WindowManager, "hhp_wardrobe_expanded"):
        del bpy.types.WindowManager.hhp_wardrobe_expanded
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
