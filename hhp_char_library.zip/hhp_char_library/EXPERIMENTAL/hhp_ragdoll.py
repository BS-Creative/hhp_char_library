"""hhp ragdol - single-armature HHP ragdoll physics tools."""

bl_info = {
    "name": "hhp ragdol",
    "author": "HHP",
    "version": (1, 12, 0),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > HHP Ragdoll",
    "description": "Build, tune, and control HHP ragdoll physics",
    "category": "Animation",
}

import copy
import itertools
import json
import math
from contextlib import contextmanager
from mathutils import Matrix, Vector

import bmesh
import bpy
from bpy.app.handlers import persistent
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, IntProperty,
                       PointerProperty)
from bpy.types import Operator, PropertyGroup

from ..modules import hhp_naming, physics_autobake


COLLECTION_NAME = "HHP_Ragdoll"
BAKE_COLLECTION_NAME = "HHP_Ragdoll"
BODY_PREFIX = "HHP_Ragdoll Body "
JOINT_PREFIX = "HHP_Ragdoll Joint "
TARGET_PREFIX = "HHP_Ragdoll Target "
CTRL_PREFIX = "HHP_RD_CTRL_"
HELPER_PREFIX = "HHP_RD_BAKE_"
PHYSICS_PREFIX = "HHP Ragdoll Physics"
BAKE_PREFIX = "HHP Ragdoll Bake"
SOURCE_NAME = "Ragdoll Animation Source"
TESTING_FLOOR_NAME = "HHP - Ragdoll floor temp"
FORWARD = Vector((0.0, -1.0, 0.0))
UP = Vector((0.0, 0.0, 1.0))
WEIGHT_THRESHOLD = 0.35
MAX_HULL_POINTS = 320
_SYNCING = False
_TOGGLING_RAGDOLL = False
_TOGGLING_PART = False
_AUTO_BAKING = False
_ACTIVE_SEGMENT_CACHE = {}
BAKE_PART_STATE_KEY = "hhp_rd_part_state_before_cache_bake"
BAKE_PART_COUNT_KEY = "hhp_rd_part_count_before_cache_bake"
BAKE_END_STATE_KEY = "hhp_rd_cache_end_before_bake"
FINGER_MODE_KEY = "hhp_rd_finger_generation"
TOE_MODE_KEY = "hhp_rd_toe_generation"
TOE_CLIPPED_COLLISIONS_KEY = "hhp_rd_toe_clipped_collisions"
CLIPPED_COLLISIONS_KEY = "hhp_rd_clipped_collisions"
CLIP_BODY_COLLISIONS_KEY = "hhp_rd_clip_body_collisions"
CLIP_FINGER_COLLISIONS_KEY = "hhp_rd_clip_finger_collisions"
CLIP_TOE_COLLISIONS_KEY = "hhp_rd_clip_toe_collisions"
ACTIVE_SEGMENTS_KEY = "hhp_rd_active_segments"
RAGDOLL_VERSION = "1.9.0"
NATIVE_BAKE_ACTION_KEY = 'hhp_rd_native_bake'
NATIVE_BAKE_MUTES_KEY = 'hhp_rd_native_constraint_mutes'
NATIVE_BAKE_MODES_KEY = 'hhp_rd_native_rotation_modes'
FINGER_DIGITS = ("Thumb", "Index", "Mid", "Ring", "Pinky")
FINGER_CURL_FACTORS = {
    "Thumb": 0.12,
    "Index": 0.25,
    "Mid": 0.65,
    "Ring": 1.10,
    "Pinky": 1.60,
}
FINGER_SEGMENTS_L = tuple(
    f"Finger {digit} {index}.L"
    for digit in FINGER_DIGITS for index in range(1, 4)
)
FINGER_SEGMENTS_R = tuple(
    f"Finger {digit} {index}.R"
    for digit in FINGER_DIGITS for index in range(1, 4)
)
FINGER_WHOLE_SEGMENTS_L = tuple(
    f"Finger {digit}.L" for digit in FINGER_DIGITS)
FINGER_WHOLE_SEGMENTS_R = tuple(
    f"Finger {digit}.R" for digit in FINGER_DIGITS)
FINGER_COMBINED_SEGMENTS_L = ("Fingers Combined.L", "Finger Thumb.L")
FINGER_COMBINED_SEGMENTS_R = ("Fingers Combined.R", "Finger Thumb.R")
TOE_VARIANT_SEGMENTS_L = (
    "Toes Combined.L", "Toe Big.L",
    "Toe Small 1.L", "Toe Small 2.L", "Toe Small 3.L", "Toe Small 4.L",
)
TOE_VARIANT_SEGMENTS_R = (
    "Toes Combined.R", "Toe Big.R",
    "Toe Small 1.R", "Toe Small 2.R", "Toe Small 3.R", "Toe Small 4.R",
)
FOLLOWER_SEGMENTS = (
    "Lower Torso", "Upper Torso",
    "Upper Arm.L", "Forearm.L", "Upper Arm.R", "Forearm.R",
    "Thigh.L", "Shin.L", "Thigh.R", "Shin.R",
)


PART_TOGGLES = (
    ("hhp_ragdoll_hip_enabled", "Hip", ("Pelvis",), "ARMATURE_DATA"),
    ("hhp_ragdoll_head_enabled", "Head", ("Head",), "USER"),
    ("hhp_ragdoll_hand_l_enabled", "Left Hand", ("Hand.L",), "VIEW_PAN"),
    ("hhp_ragdoll_hand_r_enabled", "Right Hand", ("Hand.R",), "VIEW_PAN"),
    (
        "hhp_ragdoll_foot_l_enabled",
        "Left Foot",
        ("Foot.L", "Ball.L"),
        "MOD_DYNAMICPAINT",
    ),
    (
        "hhp_ragdoll_foot_r_enabled",
        "Right Foot",
        ("Foot.R", "Ball.R"),
        "MOD_DYNAMICPAINT",
    ),
    (
        "hhp_ragdoll_toes_l_enabled",
        "Left Toes",
        ("Toes.L",) + TOE_VARIANT_SEGMENTS_L,
        "MOD_DYNAMICPAINT",
    ),
    (
        "hhp_ragdoll_toes_r_enabled",
        "Right Toes",
        ("Toes.R",) + TOE_VARIANT_SEGMENTS_R,
        "MOD_DYNAMICPAINT",
    ),
    (
        "hhp_ragdoll_fingers_l_enabled",
        "Left Fingers",
        (
            FINGER_SEGMENTS_L
            + FINGER_WHOLE_SEGMENTS_L
            + FINGER_COMBINED_SEGMENTS_L
        ),
        "VIEW_PAN",
    ),
    (
        "hhp_ragdoll_fingers_r_enabled",
        "Right Fingers",
        (
            FINGER_SEGMENTS_R
            + FINGER_WHOLE_SEGMENTS_R
            + FINGER_COMBINED_SEGMENTS_R
        ),
        "VIEW_PAN",
    ),
    (
        "hhp_ragdoll_followers_enabled",
        "Followers",
        FOLLOWER_SEGMENTS,
        "BONE_DATA",
    ),
)
SEGMENT_PART_PROPERTIES = {
    segment: property_name
    for property_name, _label, segments, _icon in PART_TOGGLES
    for segment in segments
}
def seg(reference, start, end, bones, parent, radius, mass, joint,
        extras=(), prefixes=(), suffix=None, collision_margin=.004,
        use_bone_axes=False, natural_curl_factor=1.0):
    return {
        "reference": reference, "start": start, "end": end,
        "bones": list(bones), "parent": parent, "radius": radius,
        "mass": mass, "joint": joint, "hull_extras": list(extras),
        "hull_prefixes": list(prefixes), "hull_suffix": suffix,
        "collision_margin": collision_margin,
        "use_bone_axes": use_bone_axes,
        "natural_curl_factor": natural_curl_factor,
    }


SEGMENTS = {
    "Pelvis": seg("hip", ("hip", "HEAD"), ("hip", "TAIL"),
                  ["hip", "pelvis"], None, .12, 10.0, None,
                  extras=["Genitals", "Anus"], prefixes=["Glute"]),
    "Lower Torso": seg("abdomenLower", ("abdomenLower", "HEAD"),
                       ("chestLower", "HEAD"),
                       ["abdomenLower", "abdomenUpper"], "Pelvis",
                       .115, 7.0, "SPINE"),
    "Upper Torso": seg("chestLower", ("chestLower", "HEAD"),
                       ("neckLower", "HEAD"),
                       ["chestLower", "chestUpper", "lCollar", "rCollar"],
                       "Lower Torso", .145, 12.0, "SPINE",
                       extras=["lPectoral", "rPectoral"]),
    "Head": seg("head", ("neckLower", "HEAD"), ("head", "TAIL"),
                ["neckLower", "neckUpper", "head"], "Upper Torso",
                .095, 5.0, "NECK",
                extras=["lowerJaw", "lEar", "rEar", "lEye", "rEye",
                        "upperTeeth", "lowerTeeth"]),
    "Upper Arm.L": seg("lShldrBend", ("lShldrBend", "HEAD"),
                       ("lForearmBend", "HEAD"),
                       ["lShldrBend", "lShldrTwist"], "Upper Torso",
                       .055, 2.6, "SHOULDER"),
    "Forearm.L": seg("lForearmBend", ("lForearmBend", "HEAD"),
                     ("lHand", "HEAD"),
                     ["lForearmBend", "lForearmTwist"], "Upper Arm.L",
                     .045, 1.4, "ELBOW"),
    "Hand.L": seg("lHand", ("lHand", "HEAD"), ("lHand", "TAIL"),
                  ["lHand"], "Forearm.L", .045, .55, "WRIST",
                  prefixes=["lCarpal"]),
    "Upper Arm.R": seg("rShldrBend", ("rShldrBend", "HEAD"),
                       ("rForearmBend", "HEAD"),
                       ["rShldrBend", "rShldrTwist"], "Upper Torso",
                       .055, 2.6, "SHOULDER"),
    "Forearm.R": seg("rForearmBend", ("rForearmBend", "HEAD"),
                     ("rHand", "HEAD"),
                     ["rForearmBend", "rForearmTwist"], "Upper Arm.R",
                     .045, 1.4, "ELBOW"),
    "Hand.R": seg("rHand", ("rHand", "HEAD"), ("rHand", "TAIL"),
                  ["rHand"], "Forearm.R", .045, .55, "WRIST",
                  prefixes=["rCarpal"]),
    "Thigh.L": seg("lThighBend", ("lThighBend", "HEAD"),
                   ("lShin", "HEAD"),
                   ["lThighBend", "lThighTwist"], "Pelvis",
                   .075, 7.5, "HIP",
                   extras=["ThighTweak_01.l", "ThighTweak_02.l",
                           "ThighTweak_03.l"]),
    "Shin.L": seg("lShin", ("lShin", "HEAD"), ("lFoot", "HEAD"),
                  ["lShin"], "Thigh.L", .06, 3.5, "KNEE"),
    "Foot.L": seg("lFoot", ("lFoot", "HEAD"),
                  ("Metatarsals.l", "HEAD"), ["lFoot"], "Shin.L",
                  .055, .7, "ANKLE"),
    "Ball.L": seg("Metatarsals.l", ("Metatarsals.l", "HEAD"),
                  ("Toe.l", "HEAD"), ["Metatarsals.l"], "Foot.L",
                  .04, .2, "BALL"),
    "Toes.L": seg("Toe.l", ("Toe.l", "HEAD"), ("Toe.l", "TAIL"),
                  ["Toe.l"], "Ball.L", .032, .15, "TOE",
                  prefixes=["SmallToe", "BigToe"], suffix=".l"),
    "Thigh.R": seg("rThighBend", ("rThighBend", "HEAD"),
                   ("rShin", "HEAD"),
                   ["rThighBend", "rThighTwist"], "Pelvis",
                   .075, 7.5, "HIP",
                   extras=["ThighTweak_01.r", "ThighTweak_02.r",
                           "ThighTweak_03.r"]),
    "Shin.R": seg("rShin", ("rShin", "HEAD"), ("rFoot", "HEAD"),
                  ["rShin"], "Thigh.R", .06, 3.5, "KNEE"),
    "Foot.R": seg("rFoot", ("rFoot", "HEAD"),
                  ("Metatarsals.r", "HEAD"), ["rFoot"], "Shin.R",
                  .055, .7, "ANKLE"),
    "Ball.R": seg("Metatarsals.r", ("Metatarsals.r", "HEAD"),
                  ("Toe.r", "HEAD"), ["Metatarsals.r"], "Foot.R",
                  .04, .2, "BALL"),
    "Toes.R": seg("Toe.r", ("Toe.r", "HEAD"), ("Toe.r", "TAIL"),
                  ["Toe.r"], "Ball.R", .032, .15, "TOE",
                  prefixes=["SmallToe", "BigToe"], suffix=".r"),
}

for side, prefix in (("L", "l"), ("R", "r")):
    for digit in FINGER_DIGITS:
        parent = f"Hand.{side}"
        for index in range(1, 4):
            bone_name = f"{prefix}{digit}{index}"
            segment_name = f"Finger {digit} {index}.{side}"
            base_radius = .014 if digit == "Thumb" else .011
            base_mass = .018 if digit == "Thumb" else .012
            SEGMENTS[segment_name] = seg(
                bone_name,
                (bone_name, "HEAD"),
                (bone_name, "TAIL"),
                [bone_name],
                parent,
                base_radius * (1.0 - .12 * (index - 1)),
                base_mass * (1.0 - .2 * (index - 1)),
                "FINGER_BASE" if index == 1 else "FINGER_HINGE",
                collision_margin=0.0,
                use_bone_axes=True,
                natural_curl_factor=FINGER_CURL_FACTORS[digit],
            )
            parent = segment_name

CORE_SEGMENT_NAMES = tuple(name for name in SEGMENTS if not name.startswith(
    "Finger "))
SEGMENT_CATALOG = copy.deepcopy(SEGMENTS)


def digit_bones(prefix, digit):
    return [f"{prefix}{digit}{index}" for index in range(1, 4)]


for side, prefix in (("L", "l"), ("R", "r")):
    for digit in FINGER_DIGITS:
        bones = digit_bones(prefix, digit)
        segment_name = f"Finger {digit}.{side}"
        SEGMENT_CATALOG[segment_name] = seg(
            bones[0], (bones[0], "HEAD"), (bones[-1], "TAIL"),
            bones, f"Hand.{side}",
            .014 if digit == "Thumb" else .011,
            .04 if digit == "Thumb" else .03,
            "FINGER_BASE",
            collision_margin=0.0,
            use_bone_axes=True,
            natural_curl_factor=FINGER_CURL_FACTORS[digit],
        )
    combined_bones = [
        bone
        for digit in ("Mid", "Ring", "Pinky")
        for bone in digit_bones(prefix, digit)
    ]
    SEGMENT_CATALOG[f"Fingers Combined.{side}"] = seg(
        f"{prefix}Mid1",
        (f"{prefix}Mid1", "HEAD"),
        (f"{prefix}Mid3", "TAIL"),
        combined_bones,
        f"Hand.{side}",
        .025,
        .09,
        "FINGER_BASE",
        collision_margin=0.0,
        use_bone_axes=True,
        natural_curl_factor=1.1167,
    )

for side, suffix in (("L", "l"), ("R", "r")):
    big_bones = [f"BigToe.{suffix}", f"BigToe_2.{suffix}"]
    SEGMENT_CATALOG[f"Toe Big.{side}"] = seg(
        big_bones[0], (big_bones[0], "HEAD"), (big_bones[-1], "TAIL"),
        big_bones, f"Ball.{side}", .018, .04, "TOE",
        collision_margin=0.0,
    )
    small_groups = {
        index: [
            f"SmallToe{index}.{suffix}",
            f"SmallToe{index}_2.{suffix}",
        ]
        for index in range(1, 5)
    }
    combined_bones = [
        bone for index in range(1, 5) for bone in small_groups[index]
    ]
    SEGMENT_CATALOG[f"Toes Combined.{side}"] = seg(
        f"SmallToe2.{suffix}",
        (f"SmallToe2.{suffix}", "HEAD"),
        (f"SmallToe2_2.{suffix}", "TAIL"),
        combined_bones,
        f"Ball.{side}",
        .03,
        .10,
        "TOE",
        collision_margin=0.0,
    )
    for index, bones in small_groups.items():
        SEGMENT_CATALOG[f"Toe Small {index}.{side}"] = seg(
            bones[0], (bones[0], "HEAD"), (bones[-1], "TAIL"),
            bones, f"Ball.{side}", .013, .02, "TOE",
            collision_margin=0.0,
        )


def hhp_rig_version(armature, mesh=None):
    """Prefer the character's version property, then inspect older rigs."""
    if mesh is None:
        mesh = next((obj for obj in bpy.data.objects
                     if obj.type == 'MESH' and 'HHP Version' in obj
                     and obj.find_armature() == armature), None)
    if mesh is not None and 'HHP Version' in mesh:
        try:
            return int(float(mesh['HHP Version']))
        except (TypeError, ValueError):
            pass
    return 5 if 'hip(drv)' in armature.data.bones else 4


def rig_bone_name(armature, name):
    """Resolve legacy segment names against the actual HHP4 or HHP5 rig."""
    if armature is None or name in armature.data.bones:
        return name
    base, dot, side = name.rpartition(".")
    if dot and side in {"l", "r"} and (
            base in {"Metatarsals", "Toe", "BigToe", "BigToe_2"}
            or base.startswith("SmallToe")):
        candidate = side + base
        if candidate in armature.data.bones:
            return candidate
    return name


def rig_segment_spec(armature, spec):
    """Keep the shared segment catalog unchanged while resolving one rig."""
    result = copy.deepcopy(spec)
    result["reference"] = rig_bone_name(armature, spec["reference"])
    for endpoint in ("start", "end"):
        name, tip = spec[endpoint]
        result[endpoint] = (rig_bone_name(armature, name), tip)
    for field in ("bones", "hull_extras"):
        result[field] = [rig_bone_name(armature, name) for name in spec[field]]
    if hhp_rig_version(armature) >= 5 and spec["joint"]:
        result["use_bone_axes"] = True
        result["joint_bone"] = result["start"][0]
    suffix = spec["hull_suffix"]
    if suffix in {".l", ".r"} and rig_bone_name(
            armature, "Toe" + suffix) != "Toe" + suffix:
        result["hull_prefixes"] = [suffix[1:] + name
                                   for name in spec["hull_prefixes"]]
        result["hull_suffix"] = None
    return result


def compose_segments(finger_mode="SINGLE", toe_mode="SINGLE", armature=None):
    """Return the exact segment graph for the selected build methods."""
    result = {
        name: copy.deepcopy(SEGMENT_CATALOG[name])
        for name in CORE_SEGMENT_NAMES
    }
    for side, prefix in (("L", "l"), ("R", "r")):
        hand = result[f"Hand.{side}"]
        if finger_mode == "SINGLE":
            hand["hull_prefixes"] = [
                f"{prefix}Thumb", f"{prefix}Index", f"{prefix}Mid",
                f"{prefix}Ring", f"{prefix}Pinky", f"{prefix}Carpal",
            ]
        else:
            hand["hull_prefixes"] = [f"{prefix}Carpal"]
            if finger_mode == "COMBINED":
                names = (
                    f"Fingers Combined.{side}",
                    *(
                        f"Finger {digit} {index}.{side}"
                        for digit in ("Thumb", "Index")
                        for index in range(1, 4)
                    ),
                )
            elif finger_mode == "INDIVIDUAL":
                names = tuple(
                    f"Finger {digit} {index}.{side}"
                    for digit in FINGER_DIGITS for index in range(1, 4)
                )
            else:
                names = tuple(
                    f"Finger {digit} {index}.{side}"
                    for digit in FINGER_DIGITS for index in range(1, 4)
                )
            for name in names:
                result[name] = copy.deepcopy(SEGMENT_CATALOG[name])

    if toe_mode != "SINGLE":
        result.pop("Toes.L", None)
        result.pop("Toes.R", None)
        for side, suffix in (("L", "l"), ("R", "r")):
            result[f"Ball.{side}"]["bones"].append(f"Toe.{suffix}")
            if toe_mode == "COMBINED":
                names = (f"Toes Combined.{side}", f"Toe Big.{side}")
            else:
                names = (
                    f"Toe Big.{side}",
                    *(f"Toe Small {index}.{side}" for index in range(1, 5)),
                )
            for name in names:
                result[name] = copy.deepcopy(SEGMENT_CATALOG[name])
    if armature is not None:
        result = {name: rig_segment_spec(armature, spec)
                  for name, spec in result.items()}
    return result


def infer_generation_modes(existing_names):
    if any(name.startswith("Fingers Combined.") for name in existing_names):
        finger_mode = "COMBINED"
    elif any(name.startswith("Finger ") and " 1." in name
             for name in existing_names):
        finger_mode = "INDIVIDUAL"
    elif any(name in existing_names for name in FINGER_WHOLE_SEGMENTS_L):
        finger_mode = "INDIVIDUAL"
    else:
        finger_mode = "SINGLE"

    if any(name.startswith("Toes Combined.") for name in existing_names):
        toe_mode = "COMBINED"
    elif any(name.startswith("Toe Small ") for name in existing_names):
        toe_mode = "INDIVIDUAL"
    else:
        toe_mode = "SINGLE"
    return finger_mode, toe_mode


def generation_modes(armature):
    data = armature.data
    finger_mode = data.get(FINGER_MODE_KEY)
    toe_mode = data.get(TOE_MODE_KEY)
    if finger_mode and toe_mode:
        return finger_mode, toe_mode
    collection = bpy.data.collections.get(COLLECTION_NAME)
    existing = {
        obj.get("hhp_rd_segment") for obj in collection.objects
        if obj.get("hhp_rd_segment")
    } if collection else set()
    return infer_generation_modes(existing)


def active_segments(armature):
    finger_mode, toe_mode = generation_modes(armature)
    encoded = armature.data.get(ACTIVE_SEGMENTS_KEY)
    bone_signature = tuple(rig_bone_name(armature, name)
                           for name in ("Metatarsals.l", "Toe.l",
                                        "Metatarsals.r", "Toe.r"))
    signature = (finger_mode, toe_mode, str(encoded or ""), bone_signature)
    cache_key = armature.data.as_pointer()
    cached = _ACTIVE_SEGMENT_CACHE.get(cache_key)
    if cached is not None and cached[0] == signature:
        return cached[1]

    composed = compose_segments(finger_mode, toe_mode, armature)
    if encoded:
        try:
            names = json.loads(encoded)
        except (TypeError, ValueError):
            names = []
        result = {
            name: (copy.deepcopy(composed[name]) if name in composed
                   else rig_segment_spec(armature, SEGMENT_CATALOG[name]))
            for name in names if name in composed or name in SEGMENT_CATALOG
        }
    else:
        result = composed
    _ACTIVE_SEGMENT_CACHE[cache_key] = (signature, result)
    return result


def segment_spec(armature, segment_name):
    result = active_segments(armature).get(segment_name)
    if result is None and segment_name in SEGMENT_CATALOG:
        result = rig_segment_spec(armature, SEGMENT_CATALOG[segment_name])
    return result


def bone_part_segment(segment_name, bone_name):
    """Return the UI part that controls a bone sharing another part's body."""
    if segment_name == "Ball.L" and bone_name in {"Toe.l", "lToe"}:
        return "Toes.L"
    if segment_name == "Ball.R" and bone_name in {"Toe.r", "rToe"}:
        return "Toes.R"
    return segment_name


def active_part_segments(armature, property_name):
    return {
        name for name in active_segments(armature)
        if SEGMENT_PART_PROPERTIES.get(name) == property_name
    }

# Keep SEGMENTS as the complete lookup catalog for compatibility with older
# files and operators while runtime iteration uses active_segments().
SEGMENTS = SEGMENT_CATALOG


JOINT_PROFILES = {
    "SPINE": {"x": (-8, 20), "y": 10, "z": 10, "ref": FORWARD,
              "stiffness": 6.0, "damping": 1.0},
    "NECK": {"x": (-35, 40), "y": 30, "z": 50, "ref": FORWARD,
             "stiffness": 3.0, "damping": 1.0},
    "SHOULDER": {"x": (-40, 100), "y": 75, "z": 35, "ref": FORWARD,
                 "stiffness": 1.5, "damping": .9},
    "ELBOW": {"x": (-5, 140), "y": 0, "z": 20, "ref": FORWARD,
              "stiffness": 1.0, "damping": .9},
    "WRIST": {"x": (-60, 60), "y": 25, "z": 10, "ref": FORWARD,
              "stiffness": .8, "damping": .7},
    "HIP": {"x": (-18, 110), "y": 40, "z": 25, "ref": FORWARD,
            "stiffness": 2.5, "damping": 1.0},
    "KNEE": {"x": (-135, 4), "y": 0, "z": 8, "ref": FORWARD,
             "stiffness": 1.0, "damping": .9},
    "ANKLE": {"x": (-45, 22), "y": 15, "z": 10, "ref": UP,
              "stiffness": 1.5, "damping": .8},
    # The metatarsal break is nearly rigid in a real foot; the visible
    # bend belongs at the toe joint, so BALL is stiff and narrow while
    # TOE is wide and loose.
    "BALL": {"x": (-8, 25), "y": 4, "z": 4, "ref": UP,
             "stiffness": 2.5, "damping": .9},
    "TOE": {"x": (-40, 75), "y": 5, "z": 5, "ref": UP,
            "stiffness": .15, "damping": .35},
    # Bone-local X is flexion. Keep Y/Z narrow so the resting bias curls
    # into the palm instead of splaying sideways.
    "FINGER_BASE": {"x": (-95, -16), "y": 8, "z": 8, "ref": FORWARD,
                    "stiffness": .2, "damping": .4},
    # Segments 2 and 3 are anatomical hinge joints: they curl on X but
    # should have virtually no sideways Y bend. Segment 1 retains the wider
    # FINGER_BASE Y range for natural knuckle spreading.
    "FINGER_HINGE": {"x": (-115, -24), "y": .25, "z": 6, "ref": FORWARD,
                     "stiffness": .12, "damping": .35},
}


def joint_profile(armature, spec):
    """Read HHP5's authored local joint limits without changing HHP4 profiles."""
    profile = dict(JOINT_PROFILES[spec["joint"]])
    if hhp_rig_version(armature) < 5:
        return profile
    bone = armature.pose.bones.get(spec.get("joint_bone", spec["reference"]))
    limit = next((c for c in bone.constraints
                  if c.type == 'LIMIT_ROTATION' and c.owner_space == 'LOCAL'), None) if bone else None
    # Joint X is bone X, joint Y is -bone Z, and joint Z is bone Y.
    # Keep this mapping explicit: a wrist's large bend is on bone Z, whereas
    # fingers, thumbs, knees and elbows bend on bone X in HHP5.
    fallback = (profile['x'], (-profile['y'], profile['y']),
                (-profile['z'], profile['z']))
    if spec['joint'] in {'FINGER_BASE', 'FINGER_HINGE', 'BALL'}:
        lower, upper = fallback[0]
        fallback = ((-upper, -lower), *fallback[1:])
    limits = []
    for axis, sign, default in zip(('x', 'z', 'y'), (1, -1, 1), fallback):
        if limit and getattr(limit, 'use_limit_' + axis):
            lower = math.degrees(getattr(limit, 'min_' + axis))
            upper = math.degrees(getattr(limit, 'max_' + axis))
            limits.append((lower, upper) if sign > 0 else (-upper, -lower))
        else:
            limits.append(default)
    profile['limits'] = tuple(limits)
    return profile


def safe_name(name):
    return name.replace(" ", "_").replace(".", "_")


def control_name(bone_name):
    return CTRL_PREFIX + safe_name(bone_name)


def helper_name(bone_name):
    return HELPER_PREFIX + safe_name(bone_name)


def armature_poll(_self, obj):
    return obj is not None and obj.type == "ARMATURE"


def mesh_poll(_self, obj):
    return obj is not None and obj.type == "MESH"


def hhp_name_key(name):
    base, dot, suffix = name.rpartition(".")
    if dot and suffix.isdigit():
        return (base.lower(), int(suffix), name.lower())
    return (name.lower(), 0, name.lower())


def is_hhp_character_mesh(obj):
    """Match the HHP library's character-mesh detection."""
    return (
        obj is not None
        and obj.type == "MESH"
        and hhp_naming.name_startswith_any(obj.name, hhp_naming.CHAR_MESH_OBJECT_NAMES)
        and not hhp_naming.is_deform_proxy_name(obj.name)
    )


def is_hhp_character_armature(obj):
    """Match armatures whose object names begin with an HHP character prefix."""
    return (
        obj is not None
        and obj.type == "ARMATURE"
        and hhp_naming.name_startswith_any(obj.name, hhp_naming.CHAR_ARMATURE_NAMES)
    )


def collection_parent_map(root):
    parents = {}
    stack = [root]
    seen = set()
    while stack:
        collection = stack.pop()
        if collection in seen:
            continue
        seen.add(collection)
        for child in collection.children:
            parents.setdefault(child, collection)
            stack.append(child)
    return parents


def char_collection_for_object(context, obj):
    if obj is None:
        return None
    parents = collection_parent_map(context.scene.collection)
    candidates = []
    for start in obj.users_collection:
        collection = start
        highest = None
        while collection is not None:
            if "Char (HHP)" in collection.name:
                highest = collection
            collection = parents.get(collection)
        if highest is not None:
            candidates.append(highest)
    return min(candidates, key=lambda item: hhp_name_key(item.name),
               default=None)


def visible_char_collections(context):
    flags = {}

    def walk_layer(layer, excluded=False, hidden=False):
        effective_excluded = excluded or layer.exclude
        effective_hidden = hidden or layer.hide_viewport
        flags[layer.collection] = (effective_excluded, effective_hidden)
        for child in layer.children:
            walk_layer(child, effective_excluded, effective_hidden)

    walk_layer(context.view_layer.layer_collection)
    result = []
    stack = [context.scene.collection]
    seen = set()
    while stack:
        collection = stack.pop()
        if collection in seen:
            continue
        seen.add(collection)
        stack.extend(collection.children)
        excluded, hidden = flags.get(collection, (True, True))
        if ("Char (HHP)" in collection.name
                and not collection.hide_viewport
                and not excluded and not hidden):
            result.append(collection)
    return sorted(result, key=lambda item: hhp_name_key(item.name))


def find_layer_collection(layer, collection):
    """Locate the view-layer entry for a collection so it can be eye-hidden.

    Eye visibility keeps objects in the dependency graph, so rigid bodies
    keep simulating.  Collection.hide_viewport ("Disable in Viewports")
    must never be used on HHP_Ragdoll: it removes the bodies from the
    depsgraph and freezes the whole simulation.
    """
    if layer.collection == collection:
        return layer
    for child in layer.children:
        found = find_layer_collection(child, collection)
        if found is not None:
            return found
    return None


def ragdoll_layer_collection(context):
    collection = bpy.data.collections.get(COLLECTION_NAME)
    if collection is None:
        return None
    return find_layer_collection(
        context.view_layer.layer_collection, collection)


def heal_ragdoll_collection_visibility(context):
    """Repair files saved while HHP_Ragdoll was disabled in the viewport."""
    collection = bpy.data.collections.get(COLLECTION_NAME)
    if collection is None:
        return
    if collection.hide_viewport:
        collection.hide_viewport = False
        layer = find_layer_collection(
            context.view_layer.layer_collection, collection)
        if layer is not None:
            layer.hide_viewport = True


def auto_hhp_character(context):
    """Return the visible HHP mesh/armature in the current character context."""
    active = context.active_object
    preferred = char_collection_for_object(context, active)
    candidates = []
    if preferred is not None and preferred in visible_char_collections(context):
        candidates.append(preferred)
    candidates.extend(
        collection for collection in visible_char_collections(context)
        if collection not in candidates)

    for collection in candidates:
        meshes = sorted(
            (obj for obj in collection.objects
             if is_hhp_character_mesh(obj) and obj.visible_get()),
            key=lambda item: hhp_name_key(item.name),
        )
        if not meshes:
            continue
        mesh = meshes[0]
        armature = next(
            (modifier.object for modifier in mesh.modifiers
             if modifier.type == "ARMATURE"
             and is_hhp_character_armature(modifier.object)
             and modifier.object.visible_get()),
            None,
        )
        if armature is None:
            armatures = sorted(
                (obj for obj in collection.objects
                 if is_hhp_character_armature(obj) and obj.visible_get()),
                key=lambda item: hhp_name_key(item.name),
            )
            armature = armatures[0] if armatures else None
        if armature is not None:
            return armature, mesh
    return None, None


def _tuning_update(_self, context):
    if context and context.scene:
        apply_tuning(context.scene)


def _preset_update(self, context):
    values = {
        "BS_DEFAULT": (
            0.2, 1.0, 1.0, 1.0, 0.2, 4.0,
            0.5, 1.0, 1.0, 0.7, 0.05,
        ),
        "BS_LEGACY": (
            0.2, 1.0, 1.0, 1.0, 0.2, 0.2,
            0.5, 1.0, 1.0, 0.7, 0.05,
        ),
        "STABLE": (
            0.7, 1.0, 1.0, 1.0, 0.2, 4.0,
            1.6, 1.0, 1.0, 0.7, 0.05,
        ),
        "RAGDOLL_BASE": (
            1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 0.7, 0.05,
        ),
    }[self.preset]
    (
        self.stiffness,
        self.toe_rotation,
        self.finger_bending,
        self.finger_natural_curling,
        self.finger_stiffness,
        self.toe_stiffness,
        self.damping,
        self.weight,
        self.speed,
        self.friction,
        self.bounciness,
    ) = values
    if context and context.scene:
        apply_tuning(context.scene)


class HHP_RD_Settings(PropertyGroup):
    """Scene-local setup and tuning settings for hhp ragdol."""

    armature: PointerProperty(
        name="Armature",
        type=bpy.types.Object,
        poll=armature_poll,
        description="Real character armature to receive the ragdoll",
    )
    body_mesh: PointerProperty(
        name="Body Mesh",
        type=bpy.types.Object,
        poll=mesh_poll,
        description="Skinned character mesh used to build fitted hulls",
    )
    preset: EnumProperty(
        name="Preset",
        items=(
            (
                "BS_DEFAULT",
                "(BS) Default",
                "Use the recommended HHP ragdoll tuning values",
            ),
            (
                "BS_LEGACY",
                "(BS) Legacy",
                "Use the BS default values with legacy 0.2 finger and toe "
                "stiffness",
            ),
            (
                "STABLE",
                "Stable",
                "Use stable joint settings with stronger damping and toes",
            ),
            (
                "RAGDOLL_BASE",
                "Ragdoll base values",
                "Use the original generated ragdoll tuning values",
            ),
        ),
        default="BS_DEFAULT",
        update=_preset_update,
        description="Choose a complete ragdoll tuning preset",
    )
    stiffness: FloatProperty(
        name="Stiffness",
        default=0.2,
        min=0.0,
        soft_max=5.0,
        max=100.0,
        step=10,
        precision=2,
        update=_tuning_update,
        description=(
            "Muscle-tone multiplier for body joint springs other than the "
            "dedicated finger and toe joints"
        ),
    )
    finger_stiffness: FloatProperty(
        name="Finger Stiffness",
        default=4.0,
        min=0.0,
        soft_max=5.0,
        max=100.0,
        step=10,
        precision=2,
        update=_tuning_update,
        description=(
            "Finger-joint spring stiffness. Higher values return articulated "
            "fingers to their natural curl more strongly"
        ),
    )
    toe_stiffness: FloatProperty(
        name="Toe Stiffness",
        default=4.0,
        min=0.0,
        soft_max=5.0,
        max=100.0,
        step=10,
        precision=2,
        update=_tuning_update,
        description=(
            "Ball and toe-joint spring stiffness. Higher values return toes "
            "toward their normal pose more strongly"
        ),
    )
    toe_rotation: FloatProperty(
        name="Allow Toe Bending",
        default=1.0,
        min=0.0,
        soft_max=1.0,
        max=3.0,
        step=10,
        precision=2,
        update=_tuning_update,
        description=(
            "Multiplier for ball and toe joint rotation limits. "
            "Zero prevents rotation at those joints"
        ),
    )
    finger_bending: FloatProperty(
        name="Allow Finger Bending",
        default=1.0,
        min=0.0,
        soft_max=1.0,
        max=3.0,
        step=10,
        precision=2,
        update=_tuning_update,
        description=(
            "Multiplier for finger knuckle rotation limits. "
            "One uses the current default range; zero prevents bending"
        ),
    )
    finger_natural_curling: FloatProperty(
        name="Finger Natural Curling",
        default=1.0,
        min=0.0,
        soft_max=2.0,
        max=10.0,
        step=10,
        precision=2,
        update=_tuning_update,
        description=(
            "Amount of weighted inward resting curl, with very little on the "
            "thumb and index and progressively more toward the pinky"
        ),
    )
    damping: FloatProperty(
        name="Damping",
        default=0.5,
        min=0.0,
        soft_max=5.0,
        max=100.0,
        step=10,
        precision=2,
        update=_tuning_update,
        description=(
            "Joint spring damping multiplier. Higher values stop limbs "
            "swinging quickly, lower values leave them loose and wobbly"
        ),
    )
    weight: FloatProperty(
        name="Weight",
        default=1.0,
        min=0.1,
        soft_max=5.0,
        max=100.0,
        step=10,
        precision=2,
        update=_tuning_update,
        description=(
            "Body mass multiplier over the anatomical ~52 kg distribution. "
            "Heavier falls hit harder and drag joints further"
        ),
    )
    speed: FloatProperty(
        name="Speed",
        default=1.0,
        min=0.01,
        soft_max=2.0,
        max=10.0,
        step=10,
        precision=2,
        update=_tuning_update,
        description=(
            "Simulation time scale. Below 1 gives slow motion, above 1 "
            "speeds the physics up relative to the animation"
        ),
    )
    friction: FloatProperty(
        name="Friction",
        default=0.7,
        min=0.0,
        max=1.0,
        step=10,
        precision=2,
        update=_tuning_update,
        description=(
            "Surface friction of the ragdoll bodies. Low values slide "
            "along the ground, high values grip it"
        ),
    )
    bounciness: FloatProperty(
        name="Bounciness",
        default=0.05,
        min=0.0,
        max=1.0,
        step=10,
        precision=2,
        update=_tuning_update,
        description=(
            "Restitution of the ragdoll bodies. 0 lands dead, higher "
            "values rebound off surfaces"
        ),
    )
    bake_start: IntProperty(
        name="Bake Start",
        default=1,
        min=-1048574,
        max=1048574,
        description="First simulated frame to bake onto the skeleton",
    )
    bake_end: IntProperty(
        name="Bake End",
        default=120,
        min=-1048574,
        max=1048574,
        description="Last simulated frame to bake onto the skeleton",
    )
    bake_step: IntProperty(
        name="Frame Step",
        description="Frames between bone keys; physics evaluates every frame and the last frame is always keyed",
        default=1,
        min=1,
        max=1048574,
        soft_max=10,
    )
def get_armature(scene):
    settings = scene.hhp_rd_settings
    if settings.armature and settings.armature.name in scene.objects:
        return settings.armature
    for obj in scene.objects:
        if obj.type == "ARMATURE" and obj.name != SOURCE_NAME:
            if getattr(obj.data, "hhp_ragdoll_built", False):
                return obj
    return None


def activate(obj):
    for selected in tuple(bpy.context.selected_objects):
        selected.select_set(False)
    obj.hide_set(False)
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj


def _testing_floor_update(scene, context):
    floor = bpy.data.objects.get(TESTING_FLOOR_NAME)
    if not scene.hhp_rd_testing_floor:
        if floor is not None:
            mesh = floor.data if floor.type == "MESH" else None
            bpy.data.objects.remove(floor, do_unlink=True)
            if mesh is not None and mesh.users == 0:
                bpy.data.meshes.remove(mesh)
        return

    if floor is not None:
        return

    mesh = cube_mesh(f"{TESTING_FLOOR_NAME} Mesh", 3.0, 3.0, 0.02)
    floor = bpy.data.objects.new(TESTING_FLOOR_NAME, mesh)
    scene.collection.objects.link(floor)
    floor.location = (0.0, 0.0, -0.02)
    floor.rotation_euler = (0.0, 0.0, 0.0)
    floor.scale = (1.0, 1.0, 1.0)

    previous_active = context.view_layer.objects.active
    previous_mode = (
        previous_active.mode if previous_active is not None else "OBJECT")
    previous_selection = tuple(context.selected_objects)
    if previous_mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    activate(floor)
    bpy.ops.rigidbody.object_add()
    floor.rigid_body.type = "PASSIVE"
    floor.rigid_body.kinematic = True
    floor.rigid_body.collision_shape = "BOX"

    floor.select_set(False)
    for obj in previous_selection:
        if obj.name in context.view_layer.objects:
            obj.select_set(True)
    if previous_active and previous_active.name in context.view_layer.objects:
        context.view_layer.objects.active = previous_active
        if previous_mode != "OBJECT":
            bpy.ops.object.mode_set(mode=previous_mode)


def _state_property_update(armature_data, context):
    _mirror_state_properties(armature_data, context)


def _mirror_state_properties(armature_data, _context=None, frame=None):
    """Keep independent HHP5 switch dependencies separate from morph values."""
    if 'hip(drv)' not in armature_data.bones:
        return
    paths = ('hhp_ragdoll_enabled', 'hhp_ragdoll_bake_enabled',
             'hhp_ragdoll_keys_enabled', 'hhp_ragdoll_pose_override') + tuple(
                 item[0] for item in PART_TOGGLES)
    changed = False
    animated = {}
    ad = armature_data.animation_data
    if frame is not None and ad and ad.action and ad.action_slot:
        for layer in ad.action.layers:
            for strip in layer.strips:
                bag = strip.channelbag(ad.action_slot)
                if bag:
                    for fc in bag.fcurves:
                        if fc.data_path in paths and not fc.mute:
                            animated[fc.data_path] = bool(fc.evaluate(frame) >= 0.5)
    for path in paths:
        key = '_state_' + path
        value = animated.get(path, bool(getattr(armature_data, path)))
        if armature_data.get(key) != value:
            armature_data[key] = value
            changed = True
    if armature_data.is_evaluated:
        return changed
    if changed:
        armature_data.update_tag()
    for obj in bpy.data.objects:
        if obj.type == 'ARMATURE' and obj.data == armature_data:
            changed = sync_transform_driver_overrides(
                obj, armature_data.get('_state_hhp_ragdoll_keys_enabled'), frame=frame) or changed
    return changed


def _restore_state_mapping(owner, key):
    """Empty optional state is absent; corrupt restoration data needs recovery."""
    raw = owner.get(key)
    if raw is None or raw == '':
        return {}
    try:
        value = json.loads(raw)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(
            f"Ragdoll restoration state '{key}' is damaged. Undo the last change "
            "or reopen a saved iteration before changing the ragdoll.") from exc
    if not isinstance(value, dict):
        raise RuntimeError(
            f"Ragdoll restoration state '{key}' is not a mapping. Undo the last "
            "change or reopen a saved iteration before changing the ragdoll.")
    valid = all(isinstance(name, str) for name in value)
    if key == 'hhp_rd_transform_driver_mutes':
        valid = valid and all(isinstance(item, bool) for item in value.values())
    elif key == NATIVE_BAKE_MODES_KEY:
        valid = valid and all(item in {'QUATERNION', 'AXIS_ANGLE', 'XYZ', 'XZY',
                                      'YXZ', 'YZX', 'ZXY', 'ZYX'}
                              for item in value.values() if isinstance(item, str))
        valid = valid and all(isinstance(item, str) for item in value.values())
    elif key == NATIVE_BAKE_MUTES_KEY:
        valid = valid and all(isinstance(item, dict) and isinstance(item.get('mute'), bool)
                              and (item.get('driver_mute') is None
                                   or isinstance(item.get('driver_mute'), bool))
                              for item in value.values())
    if not valid:
        raise RuntimeError(
            f"Ragdoll restoration state '{key}' has invalid entries. Undo the last "
            "change or reopen a saved iteration before changing the ragdoll.")
    return value


def prepare_transform_driver_overrides(armature, names):
    """Preserve direct bone drivers that would otherwise overwrite FK keys."""
    saved = _restore_state_mapping(armature.data, 'hhp_rd_transform_driver_mutes')
    if armature.animation_data:
        paths = {armature.pose.bones[name].path_from_id(channel)
                 for name in names for channel in (
                     'location', 'rotation_euler', 'rotation_quaternion',
                     'rotation_axis_angle', 'scale')}
        for fc in armature.animation_data.drivers:
            if is_uniform_root_scale_driver(armature, fc):
                continue
            if fc.data_path in paths:
                key = fc.data_path + ':' + str(fc.array_index)
                saved.setdefault(key, bool(fc.mute))
    encoded = json.dumps(saved)
    if armature.data.get('hhp_rd_transform_driver_mutes') != encoded:
        armature.data['hhp_rd_transform_driver_mutes'] = encoded


def uniform_root_bone(armature):
    root = armature.pose.bones.get('root')
    return root if root is not None and 'Uniform Scale' in root else None


def is_uniform_root_scale_driver(armature, curve):
    root = uniform_root_bone(armature)
    if root is None or curve.data_path != root.path_from_id('scale'):
        return False
    variables = curve.driver.variables
    return (len(variables) == 1 and variables[0].type == 'SINGLE_PROP'
            and variables[0].targets[0].id == armature
            and variables[0].targets[0].data_path == root.path_from_id() + '["Uniform Scale"]')


def sync_transform_driver_overrides(armature, keys_enabled=None, frame=None,
                                    portable_enabled=None):
    saved = _restore_state_mapping(armature.data, 'hhp_rd_transform_driver_mutes')
    changed = False
    if saved and armature.animation_data:
        for fc in armature.animation_data.drivers:
            key = fc.data_path + ':' + str(fc.array_index)
            if key not in saved:
                continue
            if keys_enabled is None:
                keys_enabled = getattr(armature.data, 'hhp_ragdoll_keys_enabled', False)
            control_mode = bool(armature.get('hhp_rigify_built') and armature.get('hhp_rigify_active'))
            if (frame is not None and armature.get('hhp_rigify_built')
                    and armature.animation_data.action_influence > 0.000001):
                mode_curve = control_rig_mode_curve(armature)
                if mode_curve is not None:
                    control_mode = mode_curve.evaluate(frame) >= 0.5
            if portable_enabled is None:
                portable_enabled = bool(portable_action_bones(armature, frame))
            muted = bool(saved[key] or portable_enabled or (keys_enabled and not control_mode))
            if fc.mute != muted:
                fc.mute = muted
                changed = True
        if changed:
            armature.update_tag()
    return changed


def action_property_curve(armature, path):
    """Read the active object's action slot, including multi-slot actions."""
    ad = armature.animation_data
    if ad and ad.action:
        for layer in ad.action.layers:
            for strip in layer.strips:
                for bag in strip.channelbags:
                    if bag.slot_handle == ad.action_slot_handle:
                        return next((fc for fc in bag.fcurves
                                     if fc.data_path == path and not fc.mute), None)
    return None


def native_bake_metadata(action, slot_handle=None):
    if action is None:
        return {}
    try:
        value = json.loads(action.get(NATIVE_BAKE_ACTION_KEY, '{}'))
    except (TypeError, ValueError):
        return {}
    if not isinstance(value, dict) or value.get('version') not in {1, 2}:
        return {}
    if value.get('version') == 2 and isinstance(value.get('slots'), dict):
        if slot_handle is not None:
            return value['slots'].get(str(slot_handle), {})
        if len(value['slots']) == 1:
            return next(iter(value['slots'].values()))
    return value


def _store_native_bake_metadata(armature, metadata):
    """Keep ownership local to the baked object slot in a multi-slot Action."""
    ad = armature.animation_data
    action = ad.action
    try:
        previous = json.loads(action.get(NATIVE_BAKE_ACTION_KEY, '{}'))
    except (TypeError, ValueError):
        previous = {}
    slots = dict(previous.get('slots', {})) if isinstance(previous, dict) else {}
    if metadata:
        slots[str(ad.action_slot_handle)] = metadata
    else:
        slots.pop(str(ad.action_slot_handle), None)
    if slots:
        action[NATIVE_BAKE_ACTION_KEY] = json.dumps(dict(version=2, slots=slots))
    elif NATIVE_BAKE_ACTION_KEY in action:
        del action[NATIVE_BAKE_ACTION_KEY]


def portable_action_bones(armature, frame=None):
    """Native destinations owned by a tagged action at this frame.

    New clips carry static range metadata instead of state keyframes. Legacy
    clips keep their original keyed playback envelope.
    """
    ad = armature.animation_data
    metadata = native_bake_metadata(ad.action if ad and ad.action_slot
                                   and ad.action_influence > 0.000001 else None,
                                   ad.action_slot_handle if ad else None)
    if not metadata:
        return set()
    if (armature.get('_hhp_rd_simulation_action') == ad.action
            and armature.get('_hhp_rd_simulation_slot') == ad.action_slot_handle):
        return set()
    evaluating_frame = frame is not None
    if frame is None:
        frame = bpy.context.scene.frame_current_final
    if not any(start <= frame <= end for start, end in metadata.get('ranges', [])):
        return set()
    if metadata['version'] == 1:
        if 'hip(drv)' not in armature.data.bones:
            return set()
        curve = action_property_curve(armature, '["' + NATIVE_BAKE_ACTION_KEY + '"]')
        if curve is None or curve.evaluate(frame) < 0.5:
            return set()
        mode = action_property_curve(armature, '["hhp_rigify_active"]') if evaluating_frame else None
        control_mode = mode.evaluate(frame) >= 0.5 if mode else bool(armature.get('hhp_rigify_active'))
        if armature.get('hhp_rigify_built') and control_mode:
            return set()
    elif metadata.get('rig_version', 5) != hhp_rig_version(armature):
        return set()
    return {name for name in metadata.get('bones', [])
            if name in armature.pose.bones and not name.endswith('(drv)')
            and (metadata.get('playback', 'NATIVE') != 'CONTROLS'
                 or control_name(name) in armature.pose.bones)
            and (metadata.get('rig_version', 5) < 5
                 or name in {'hip', 'root'} or armature.data.bones[name].use_deform)
            and not name.startswith((CTRL_PREFIX, HELPER_PREFIX))}


def _sync_portable_constraints(armature, names):
    """Mute visual-pose modifiers reversibly without replacing their drivers."""
    saved = _restore_state_mapping(armature, NATIVE_BAKE_MUTES_KEY)
    if not names and not saved:
        return False
    wanted = {}
    ad = armature.animation_data
    metadata = native_bake_metadata(ad.action if ad else None,
                                    ad.action_slot_handle if ad else None)
    owns_all = metadata.get('version') == 2
    controls = metadata.get('playback') == 'CONTROLS'
    for name in names:
        for constraint in armature.pose.bones[name].constraints:
            if owns_all or not constraint.name.startswith((PHYSICS_PREFIX, BAKE_PREFIX)):
                wanted[constraint.path_from_id('mute')] = constraint
    drivers = ({fc.data_path: fc for fc in armature.animation_data.drivers}
               if armature.animation_data else {})
    changed = False
    for path in set(saved) - set(wanted):
        previous = saved.pop(path)
        try:
            constraint = armature.path_resolve(path.rsplit('.', 1)[0])
        except (ValueError, KeyError):
            continue
        curve = drivers.get(path)
        if curve is not None and previous['driver_mute'] is not None:
            curve.mute = previous['driver_mute']
        constraint.mute = previous['mute']
        if 'influence' in previous:
            influence_curve = drivers.get(constraint.path_from_id('influence'))
            if influence_curve and previous.get('influence_driver_mute') is not None:
                influence_curve.mute = previous['influence_driver_mute']
            constraint.influence = previous['influence']
        changed = True
    for path, constraint in wanted.items():
        curve = drivers.get(path)
        drives_control = controls and constraint.name.startswith(BAKE_PREFIX)
        if path not in saved:
            saved[path] = dict(mute=bool(constraint.mute),
                               driver_mute=bool(curve.mute) if curve else None)
        if curve is not None and not curve.mute:
            curve.mute = True
            changed = True
        if constraint.mute != (not drives_control):
            constraint.mute = not drives_control
            changed = True
        if drives_control:
            influence_curve = drivers.get(constraint.path_from_id('influence'))
            if 'influence' not in saved[path]:
                saved[path].update(influence=float(constraint.influence),
                                   influence_driver_mute=(bool(influence_curve.mute)
                                                          if influence_curve else None))
            if influence_curve and not influence_curve.mute:
                influence_curve.mute = True
                changed = True
            if constraint.influence != 1.0:
                constraint.influence = 1.0
                changed = True
    encoded = json.dumps(saved)
    if saved:
        if armature.get(NATIVE_BAKE_MUTES_KEY) != encoded:
            armature[NATIVE_BAKE_MUTES_KEY] = encoded
    elif NATIVE_BAKE_MUTES_KEY in armature:
        del armature[NATIVE_BAKE_MUTES_KEY]
    return changed


def _sync_portable_rotation_modes(armature, names):
    """Use the source channel convention while a native clip owns the pose."""
    saved = _restore_state_mapping(armature, NATIVE_BAKE_MODES_KEY)
    ad = armature.animation_data
    modes = native_bake_metadata(ad.action if ad else None,
                                 ad.action_slot_handle if ad else None).get('rotation_modes', {})
    valid_modes = {'QUATERNION', 'AXIS_ANGLE', 'XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX'}
    wanted = {name: modes[name] for name in names
              if name in modes and modes[name] in valid_modes}
    changed = False
    for name in set(saved) - set(wanted):
        previous = saved.pop(name)
        bone = armature.pose.bones.get(name)
        if bone and bone.rotation_mode != previous:
            bone.rotation_mode = previous
            changed = True
    for name, mode in wanted.items():
        bone = armature.pose.bones[name]
        if name not in saved:
            saved[name] = bone.rotation_mode
        if bone.rotation_mode != mode:
            bone.rotation_mode = mode
            changed = True
    if saved:
        encoded = json.dumps(saved)
        if armature.get(NATIVE_BAKE_MODES_KEY) != encoded:
            armature[NATIVE_BAKE_MODES_KEY] = encoded
    elif NATIVE_BAKE_MODES_KEY in armature:
        del armature[NATIVE_BAKE_MODES_KEY]
    return changed


def sync_portable_action_playback(armature, frame=None):
    """Prepare an imported native bake; safe without registered ragdoll UI."""
    if armature.type != 'ARMATURE':
        return False
    armature = armature.original
    ad = armature.animation_data
    if (not (ad and ad.action and NATIVE_BAKE_ACTION_KEY in ad.action)
            and NATIVE_BAKE_MUTES_KEY not in armature
            and NATIVE_BAKE_MODES_KEY not in armature
            and 'hhp_rd_transform_driver_mutes' not in armature.data):
        return False
    names = portable_action_bones(armature, frame)
    if names:
        prepare_transform_driver_overrides(armature, names)
    changed = _sync_portable_constraints(armature, names)
    changed = _sync_portable_rotation_modes(armature, names) or changed
    changed = sync_transform_driver_overrides(
        armature, frame=frame, portable_enabled=bool(names)) or changed
    if changed:
        armature.update_tag()
    return changed


def restore_portable_action_playback(armature):
    """Release only imported-action overrides, retaining live ragdoll state."""
    if armature.type != 'ARMATURE':
        return False
    armature = armature.original
    changed = _sync_portable_constraints(armature, set())
    changed = _sync_portable_rotation_modes(armature, set()) or changed
    changed = sync_transform_driver_overrides(armature, portable_enabled=False) or changed
    if changed:
        armature.update_tag()
    return changed


def suspend_native_action_playback(armature):
    """Explicit physics use can replace a native clip without editing its keys."""
    ad = armature.animation_data
    if not ad or not ad.action or not ad.action_slot:
        return False
    if not native_bake_metadata(ad.action, ad.action_slot_handle):
        return False
    armature['_hhp_rd_simulation_action'] = ad.action
    armature['_hhp_rd_simulation_slot'] = ad.action_slot_handle
    restore_portable_action_playback(armature)
    return True


def resume_native_action_playback(armature):
    """Return to clip ownership after explicitly stopping or baking physics."""
    changed = False
    for key in ('_hhp_rd_simulation_action', '_hhp_rd_simulation_slot'):
        if key in armature:
            del armature[key]
            changed = True
    return changed


def tag_native_bake_action(armature, names, start, end, playback='NATIVE'):
    """Carry native playback ownership with the object action when exported."""
    action = armature.animation_data.action
    resume_native_action_playback(armature)
    previous = native_bake_metadata(action, armature.animation_data.action_slot_handle)
    if previous.get('playback', 'NATIVE') != playback:
        # The two bake tools use different destinations. Their playback modes
        # cannot claim the same Action simultaneously.
        previous = {}
    ranges = sorted(previous.get('ranges', []) + [[start, end]])
    merged = []
    for first, last in ranges:
        if merged and first <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], last)
        else:
            merged.append([first, last])
    rotation_modes = dict(previous.get('rotation_modes', {}))
    rotation_modes.update({name: armature.pose.bones[name].rotation_mode for name in names})
    _store_native_bake_metadata(armature, dict(
        version=2, rig_version=hhp_rig_version(armature), playback=playback,
        bones=sorted(set(previous.get('bones', [])) | set(names)),
        ranges=merged, rotation_modes=rotation_modes))


def _ragdoll_enabled_update(armature_data, context):
    global _TOGGLING_RAGDOLL
    _mirror_state_properties(armature_data, context)
    if (_TOGGLING_RAGDOLL or context is None
            or context.scene is None
            or not armature_data.hhp_ragdoll_enabled):
        return

    _TOGGLING_RAGDOLL = True
    try:
        # Capture the animated pose before physics constraints take control.
        armature_data.hhp_ragdoll_enabled = False
        context.view_layer.update()
        sync_bodies(context.scene, force=True)
        armature = get_armature(context.scene)
        if armature and armature.data == armature_data:
            # Capture the current native pose into the bodies before releasing
            # its constraint overrides, so enabling physics does not pop.
            suspend_native_action_playback(armature)
        armature_data.hhp_ragdoll_enabled = True
        context.scene.sync_mode = "NONE"
        context.view_layer.update()
    finally:
        _TOGGLING_RAGDOLL = False


def _part_enabled_update(property_name, segments):
    def update(armature_data, context):
        global _TOGGLING_PART
        _mirror_state_properties(armature_data, context)
        if (_TOGGLING_PART or context is None
                or context.scene is None):
            return
        cache = rigid_body_point_cache(context.scene)
        if cache is not None and cache.is_baked:
            enforce_baked_part_toggles(context.scene)
            return
        _TOGGLING_PART = True
        try:
            armature = get_armature(context.scene)
            runtime_segments = (
                active_part_segments(armature, property_name)
                if armature is not None and armature.data == armature_data
                else set(segments)
            )
            enabling = getattr(armature_data, property_name)
            if enabling and armature_data.hhp_ragdoll_enabled:
                # Capture the animated transform before releasing only these
                # bodies back to physics.
                setattr(armature_data, property_name, False)
                context.view_layer.update()
                sync_bodies(
                    context.scene, force=True, segments=runtime_segments)
                setattr(armature_data, property_name, True)
            else:
                # Evaluate animation before snapping a newly kinematic part.
                context.view_layer.update()
                sync_bodies(
                    context.scene, force=True, segments=runtime_segments)
            context.scene.sync_mode = "NONE"
            context.view_layer.update()
        finally:
            _TOGGLING_PART = False
    return update


def enable_all_ragdoll_parts(armature_data):
    """Force every optional ragdoll segment on without running sync callbacks."""
    set_ragdoll_part_state_mask(
        armature_data, (1 << len(PART_TOGGLES)) - 1)


def set_ragdoll_part_state_mask(armature_data, state_mask):
    """Apply a packed part-toggle state without running sync callbacks."""
    global _TOGGLING_PART
    previous_state = _TOGGLING_PART
    _TOGGLING_PART = True
    try:
        for index, item in enumerate(PART_TOGGLES):
            enabled = bool(state_mask & (1 << index))
            if getattr(armature_data, item[0], True) != enabled:
                setattr(armature_data, item[0], enabled)
    finally:
        _TOGGLING_PART = previous_state


def saved_bake_part_state_mask(armature_data):
    """Read a saved mask, defaulting newly added toggles to enabled."""
    state_mask = int(armature_data[BAKE_PART_STATE_KEY])
    saved_count = int(armature_data.get(BAKE_PART_COUNT_KEY, 8))
    for index in range(saved_count, len(PART_TOGGLES)):
        state_mask |= 1 << index
    return state_mask


def enforce_baked_part_toggles(scene):
    """Preserve part states through sim start and lock later baked frames on."""
    cache = rigid_body_point_cache(scene)
    restore_cache_end_if_unbaked(scene, cache)
    armature = get_armature(scene)
    if armature is None:
        return
    armature_data = armature.data
    if cache is not None and cache.is_baked:
        if BAKE_PART_STATE_KEY not in armature_data:
            state_mask = 0
            for index, item in enumerate(PART_TOGGLES):
                if getattr(armature_data, item[0], True):
                    state_mask |= 1 << index
            armature_data[BAKE_PART_STATE_KEY] = state_mask
            armature_data[BAKE_PART_COUNT_KEY] = len(PART_TOGGLES)
        state_mask = saved_bake_part_state_mask(armature_data)
        if scene.frame_current > cache.frame_start:
            state_mask = (1 << len(PART_TOGGLES)) - 1
        set_ragdoll_part_state_mask(armature_data, state_mask)
        return
    if BAKE_PART_STATE_KEY not in armature_data:
        return

    state_mask = saved_bake_part_state_mask(armature_data)
    set_ragdoll_part_state_mask(armature_data, state_mask)
    del armature_data[BAKE_PART_STATE_KEY]
    if BAKE_PART_COUNT_KEY in armature_data:
        del armature_data[BAKE_PART_COUNT_KEY]
    sync_bodies(scene)


def add_rigid_body(obj, body_type):
    activate(obj)
    bpy.ops.rigidbody.object_add()
    obj.rigid_body.type = body_type


def cube_mesh(name, x, y, z):
    verts = [
        (-x, -y, -z), (x, -y, -z), (x, y, -z), (-x, y, -z),
        (-x, -y, z), (x, -y, z), (x, y, z), (-x, y, z),
    ]
    faces = [
        (0, 1, 2, 3), (4, 7, 6, 5), (0, 4, 5, 1),
        (1, 5, 6, 2), (2, 6, 7, 3), (4, 0, 3, 7),
    ]
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    return mesh


def segment_matrix(start, end):
    direction = end - start
    if direction.length < .001:
        direction = Vector((0, 0, .1))
    return Matrix.LocRotScale(
        (start + end) * .5,
        direction.to_track_quat("Z", "Y"),
        Vector((1, 1, 1)),
    )


def joint_frame(position, direction, reference):
    z_axis = direction.normalized()
    ref = reference.normalized()
    if abs(z_axis.dot(ref)) > .9:
        ref = UP if abs(z_axis.dot(UP)) <= .9 else FORWARD
    x_axis = z_axis.cross(ref).normalized()
    y_axis = z_axis.cross(x_axis).normalized()
    return Matrix((
        (x_axis.x, y_axis.x, z_axis.x, position.x),
        (x_axis.y, y_axis.y, z_axis.y, position.y),
        (x_axis.z, y_axis.z, z_axis.z, position.z),
        (0, 0, 0, 1),
    ))


def bone_axis_joint_frame(armature, bone_name, position):
    """Align constraint X to anatomical bone-local X flexion."""
    basis = (armature.matrix_world @ armature.pose.bones[bone_name].matrix)
    rotation = basis.to_3x3().normalized()
    # Blender bone local X = flex, local Y = length, local Z = secondary.
    # Constraint Z follows bone length so limit_ang_x curls into the palm.
    x_axis = rotation.col[0].normalized()
    z_axis = rotation.col[1].normalized()
    y_axis = z_axis.cross(x_axis).normalized()
    x_axis = y_axis.cross(z_axis).normalized()
    return Matrix((
        (x_axis.x, y_axis.x, z_axis.x, position.x),
        (x_axis.y, y_axis.y, z_axis.y, position.y),
        (x_axis.z, y_axis.z, z_axis.z, position.z),
        (0, 0, 0, 1),
    ))


def point_world(armature, bone_name, endpoint, evaluated=False):
    obj = armature
    if evaluated:
        obj = armature.evaluated_get(bpy.context.evaluated_depsgraph_get())
    bone = obj.pose.bones[bone_name]
    point = bone.head if endpoint == "HEAD" else bone.tail
    return obj.matrix_world @ point


def bone_world(armature, bone_name, evaluated=False):
    obj = armature
    if evaluated:
        obj = armature.evaluated_get(bpy.context.evaluated_depsgraph_get())
    return obj.matrix_world @ obj.pose.bones[bone_name].matrix


def flatten_matrix(matrix):
    return [float(matrix[row][col]) for row in range(4) for col in range(4)]


def unflatten_matrix(values):
    return Matrix([values[index:index + 4] for index in range(0, 16, 4)])


def add_state_variables(driver, armature, segment_name=None):
    def state_path(path):
        if hhp_rig_version(armature) >= 5:
            # HHP5 also drives morph values on this armature datablock.
            # A precise ID-property dependency avoids depending on every
            # evaluated parameter, which would loop back through the pose.
            _mirror_state_properties(armature.data)
            return '["_state_' + path + '"]'
        return path

    for name, path in (
        ("ragdoll", "hhp_ragdoll_enabled"),
        ("bake", "hhp_ragdoll_bake_enabled"),
        ("keys", "hhp_ragdoll_keys_enabled"),
        ("override", "hhp_ragdoll_pose_override"),
    ):
        variable = driver.variables.new()
        variable.name = name
        variable.type = "SINGLE_PROP"
        target = variable.targets[0]
        target.id_type = "ARMATURE"
        target.id = armature.data
        target.data_path = state_path(path)
    part_property = SEGMENT_PART_PROPERTIES.get(segment_name)
    if armature.get('hhp_rigify_built'):
        variable = driver.variables.new()
        variable.name = 'controlrig'
        variable.type = 'SINGLE_PROP'
        variable.targets[0].id = armature
        variable.targets[0].data_path = '["hhp_rigify_active"]'
    if part_property is not None:
        variable = driver.variables.new()
        variable.name = "part"
        variable.type = "SINGLE_PROP"
        target = variable.targets[0]
        target.id_type = "ARMATURE"
        target.id = armature.data
        target.data_path = state_path(part_property)


def add_state_driver(owner, path, armature, expression, segment_name=None):
    expression = (expression.replace('keys', '(keys and not controlrig)')
                  if armature.get('hhp_rigify_built') else expression)
    animation = owner.id_data.animation_data
    fcurve = animation.drivers.find(owner.path_from_id(path)) if animation else None
    if fcurve is not None and fcurve.driver.type == 'SCRIPTED':
        paths = dict(ragdoll='hhp_ragdoll_enabled', bake='hhp_ragdoll_bake_enabled',
                     keys='hhp_ragdoll_keys_enabled', override='hhp_ragdoll_pose_override')
        part = SEGMENT_PART_PROPERTIES.get(segment_name)
        if part is not None:
            paths['part'] = part
        version = hhp_rig_version(armature)
        wanted = {name: (armature.data, '["_state_' + prop + '"]' if version >= 5 else prop)
                  for name, prop in paths.items()}
        if armature.get('hhp_rigify_built'):
            wanted['controlrig'] = (armature, '["hhp_rigify_active"]')
        variables = fcurve.driver.variables
        if len(variables) == len(wanted) and all(
                variable.name in wanted and variable.type == 'SINGLE_PROP'
                and (variable.targets[0].id, variable.targets[0].data_path) == wanted[variable.name]
                for variable in variables):
            if fcurve.driver.expression != expression:
                fcurve.driver.expression = expression
            return fcurve
    try:
        owner.driver_remove(path)
    except (TypeError, RuntimeError):
        pass
    fcurve = owner.driver_add(path)
    fcurve.driver.type = "SCRIPTED"
    add_state_variables(fcurve.driver, armature, segment_name)
    fcurve.driver.expression = expression
    return fcurve


def part_driver_expression(segment_name, enabled_expression,
                           disabled_expression):
    if segment_name in SEGMENT_PART_PROPERTIES:
        return f"({enabled_expression}) if part else ({disabled_expression})"
    return enabled_expression


def physics_driver_expression(segment_name):
    expression = "1.0 if (ragdoll and not override) else 0.0"
    return part_driver_expression(segment_name, expression, "0.0")


def joint_driver_expression(segment_name):
    """Disconnect a disabled part so its kinematic body cannot pin its parent."""
    return part_driver_expression(segment_name, "1.0", "0.0")


def purge_dead_drivers(armature):
    removed = 0
    if armature.animation_data:
        for fcurve in list(armature.animation_data.drivers):
            try:
                armature.path_resolve(fcurve.data_path)
            except ValueError:
                armature.animation_data.drivers.remove(fcurve)
                removed += 1
    print(f"HHP_RD_PURGED_DEAD_DRIVERS={removed}")


def remove_old_system(armature):
    old_source = bpy.data.objects.get(SOURCE_NAME)
    if old_source:
        bpy.data.objects.remove(old_source, do_unlink=True)
    legacy_collections = ("HHP Ragdoll Temp", "Ragdoll System")
    for collection_name in (COLLECTION_NAME,) + legacy_collections:
        collection = bpy.data.collections.get(collection_name)
        if collection:
            for obj in list(collection.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
            bpy.data.collections.remove(collection)
    for pose_bone in armature.pose.bones:
        base_influences = pose_bone.get("hhp_rd_base_influences", {})
        base_mutes = pose_bone.get("hhp_rd_base_mutes", {})
        for constraint in list(pose_bone.constraints):
            if (constraint.name.startswith(PHYSICS_PREFIX)
                    or constraint.name.startswith(BAKE_PREFIX)
                    or constraint.name.startswith("Ragdoll Physics")):
                pose_bone.constraints.remove(constraint)
            elif constraint.name in base_influences:
                base = float(base_influences[constraint.name])
                try:
                    constraint.driver_remove("influence")
                except (TypeError, RuntimeError):
                    pass
                constraint.influence = base
            elif constraint.name in base_mutes:
                try:
                    constraint.driver_remove("mute")
                except (TypeError, RuntimeError):
                    pass
                constraint.mute = bool(base_mutes[constraint.name])
        if "hhp_rd_base_influences" in pose_bone:
            del pose_bone["hhp_rd_base_influences"]
        if "hhp_rd_base_mutes" in pose_bone:
            del pose_bone["hhp_rd_base_mutes"]

    control_bones = [
        bone.name for bone in armature.data.bones
        if bone.name.startswith(CTRL_PREFIX) or bone.name.startswith(HELPER_PREFIX)
    ]
    if control_bones:
        activate(armature)
        bpy.ops.object.mode_set(mode="EDIT")
        for name in control_bones:
            edit_bone = armature.data.edit_bones.get(name)
            if edit_bone:
                armature.data.edit_bones.remove(edit_bone)
        bpy.ops.object.mode_set(mode="OBJECT")
    for name in (BAKE_COLLECTION_NAME, "HHP Ragdoll Bake Controls"):
        bake_collection = armature.data.collections.get(name)
        if bake_collection:
            armature.data.collections.remove(bake_collection)


def collect_vertex_weights(mesh_obj):
    names = [group.name for group in mesh_obj.vertex_groups]
    result = []
    for vertex in mesh_obj.data.vertices:
        entry = {}
        for item in vertex.groups:
            if item.weight > .01 and item.group < len(names):
                entry[names[item.group]] = item.weight
        result.append(entry)
    return result


def capture_generation_mesh(mesh_obj, generation_shape):
    """Snapshot base or fully evaluated mesh data before physics is created."""
    source = mesh_obj
    if generation_shape == "FINAL":
        depsgraph = bpy.context.evaluated_depsgraph_get()
        source = mesh_obj.evaluated_get(depsgraph)
    return {
        "coordinates": [vertex.co.copy() for vertex in source.data.vertices],
        "weights": collect_vertex_weights(source),
        "group_names": {group.name for group in source.vertex_groups},
        "matrix_world": source.matrix_world.copy(),
        "is_final": generation_shape == "FINAL",
    }


def segment_groups(spec, all_names):
    names = set(spec["bones"]) | set(spec["hull_extras"])
    for prefix in spec["hull_prefixes"]:
        for name in all_names:
            if name.startswith(prefix):
                if spec["hull_suffix"] and not name.endswith(
                        spec["hull_suffix"]):
                    continue
                names.add(name)
    return names


def hull_points(spec, generation_mesh, armature, body_matrix):
    wanted = segment_groups(spec, generation_mesh["group_names"])
    body_inverse = body_matrix.inverted()
    if generation_mesh["is_final"]:
        point_transform = body_inverse @ generation_mesh["matrix_world"]
    else:
        rest = armature.data.bones[spec["reference"]].matrix_local
        current = bone_world(armature, spec["reference"])
        remap = body_inverse @ current @ rest.inverted()
        mesh_to_arm = (
            armature.matrix_world.inverted()
            @ generation_mesh["matrix_world"]
        )
        point_transform = remap @ mesh_to_arm
    points = []
    for index, coordinate in enumerate(generation_mesh["coordinates"]):
        total = sum(
            generation_mesh["weights"][index].get(name, 0.0)
            for name in wanted
        )
        if total >= WEIGHT_THRESHOLD:
            points.append(point_transform @ coordinate)
    if len(points) > MAX_HULL_POINTS:
        stride = len(points) / MAX_HULL_POINTS
        points = [points[int(i * stride)] for i in range(MAX_HULL_POINTS)]
    return points


def convex_mesh(name, points):
    bm = bmesh.new()
    for point in points:
        bm.verts.new(point)
    bm.verts.ensure_lookup_table()
    bmesh.ops.convex_hull(bm, input=list(bm.verts))
    loose = list({vertex for vertex in bm.verts if not vertex.link_faces})
    if loose:
        bmesh.ops.delete(bm, geom=loose, context="VERTS")
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()
    return mesh


def mute_animation_constraints(pose_bone, armature, segment_name, physics=True):
    if "hhp_rd_base_influences" not in pose_bone:
        pose_bone["hhp_rd_base_influences"] = {}
    base_influences = pose_bone["hhp_rd_base_influences"]
    for constraint in pose_bone.constraints:
        if (constraint.name.startswith(PHYSICS_PREFIX)
                or constraint.name.startswith(BAKE_PREFIX)):
            continue
        if constraint.name == "(HHP) Rigify Control" and armature.get("hhp_rigify_built"):
            # The rig selector already drives influence. Gate mute instead so
            # its live driver survives physics, rebuilding and removal.
            if "hhp_rd_base_mutes" not in pose_bone:
                pose_bone["hhp_rd_base_mutes"] = {}
            base_mutes = pose_bone["hhp_rd_base_mutes"]
            if constraint.name not in base_mutes:
                base_mutes[constraint.name] = bool(constraint.mute)
            base = bool(base_mutes[constraint.name])
            disabled = f"{base} or bake or keys or override"
            expression = (part_driver_expression(
                segment_name, f"{base} or ragdoll or bake or keys or override", disabled)
                if physics else disabled)
            add_state_driver(constraint, "mute", armature, expression, segment_name)
            continue
        if constraint.name not in base_influences:
            base_influences[constraint.name] = float(constraint.influence)
        base = float(base_influences[constraint.name])
        enabled_expression = (
            f"{base} if (not ragdoll and not bake and not keys "
            "and not override) else 0.0"
        )
        disabled_expression = f"{base} if (not bake and not keys and not override) else 0.0"
        expression = (part_driver_expression(segment_name, enabled_expression, disabled_expression)
                      if physics else disabled_expression)
        add_state_driver(
            constraint, "influence", armature,
            expression,
            segment_name,
        )


def create_body(armature, collection, generation_mesh, name, spec):
    start = point_world(armature, *spec["start"])
    end = point_world(armature, *spec["end"])
    matrix = segment_matrix(start, end)
    points = hull_points(spec, generation_mesh, armature, matrix)
    if len(points) >= 12:
        mesh = convex_mesh(f"HHP_Ragdoll Hull {name}", points)
        shape = "CONVEX_HULL"
    else:
        length = max((end - start).length, spec["radius"] * 2.2)
        mesh = cube_mesh(
            f"HHP_Ragdoll Hull {name}", spec["radius"], spec["radius"],
            length * .46)
        shape = "BOX"

    body = bpy.data.objects.new(BODY_PREFIX + name, mesh)
    collection.objects.link(body)
    body.matrix_world = matrix
    body.display_type = "WIRE"
    body.color = (.9, .12, .02, 1)
    body.hide_render = True
    body["hhp_rd_segment"] = name
    body["hhp_rd_reference"] = spec["reference"]
    reference = bone_world(armature, spec["reference"])
    body["hhp_rd_reference_offset"] = flatten_matrix(
        reference.inverted() @ matrix)
    body["description"] = (
        f"Fitted rigid body for {name}; follows the evaluated real armature "
        "until the Ragdoll boolean is enabled."
    )
    body["hhp_rd_base_mass"] = float(spec["mass"])
    add_rigid_body(body, "ACTIVE")
    rigid = body.rigid_body
    rigid.collision_shape = shape
    rigid.mass = spec["mass"]
    rigid.friction = .7
    rigid.restitution = .05
    rigid.linear_damping = .15
    rigid.angular_damping = .6
    rigid.use_margin = True
    rigid.collision_margin = spec.get("collision_margin", .004)
    rigid.use_deactivation = True
    add_state_driver(
        body, "rigid_body.kinematic", armature,
        part_driver_expression(name, "1.0 - ragdoll", "1.0"),
        name,
    )

    for bone_name in spec["bones"]:
        pose_bone = armature.pose.bones[bone_name]
        part_segment = bone_part_segment(name, bone_name)
        mute_animation_constraints(pose_bone, armature, part_segment)
        target = bpy.data.objects.new(TARGET_PREFIX + bone_name, None)
        collection.objects.link(target)
        target.parent = body
        target.matrix_world = bone_world(armature, bone_name)
        target.empty_display_type = "PLAIN_AXES"
        target.empty_display_size = spec["radius"] * .5
        target.hide_render = True
        target.hide_set(True)
        constraint = pose_bone.constraints.new("COPY_TRANSFORMS")
        constraint.name = f"{PHYSICS_PREFIX} · {name}"
        constraint.target = target
        constraint.target_space = "WORLD"
        constraint.owner_space = "WORLD"
        constraint.mix_mode = "REPLACE"
        add_state_driver(
            constraint, "influence", armature,
            physics_driver_expression(part_segment),
            part_segment,
        )
    return body, start, end, shape, len(mesh.vertices)


def body_world_mesh(body):
    """Return world-space vertices and polygon indices for one rigid body."""
    matrix = body.matrix_world
    vertices = [matrix @ vertex.co for vertex in body.data.vertices]
    polygons = [tuple(polygon.vertices) for polygon in body.data.polygons]
    return vertices, polygons


def unique_collision_axes(axes):
    """Normalize and deduplicate unoriented SAT axes."""
    unique = {}
    for axis in axes:
        if axis.length_squared <= 1.0e-12:
            continue
        normalized = axis.normalized()
        for component in normalized:
            if abs(component) <= 1.0e-8:
                continue
            if component < 0.0:
                normalized.negate()
            break
        key = tuple(round(component, 7) for component in normalized)
        unique.setdefault(key, normalized)
    return list(unique.values())


def body_collision_axes(body):
    """Return exact world face normals and edge directions for a convex body."""
    matrix = body.matrix_world
    normal_matrix = matrix.to_3x3().inverted().transposed()
    face_axes = unique_collision_axes(
        normal_matrix @ polygon.normal for polygon in body.data.polygons)
    edge_axes = unique_collision_axes(
        matrix.to_3x3() @ (
            body.data.vertices[edge.vertices[1]].co
            - body.data.vertices[edge.vertices[0]].co
        )
        for edge in body.data.edges
    )
    return face_axes, edge_axes


def exact_collision_cut_plane(body_a, body_b):
    """Find the exact minimum-overlap SAT plane shared by two convex hulls."""
    vertices_a, polygons_a = body_world_mesh(body_a)
    vertices_b, polygons_b = body_world_mesh(body_b)
    if not vertices_a or not vertices_b or not polygons_a or not polygons_b:
        return None
    for coordinate in range(3):
        overlap = (
            min(
                max(vertex[coordinate] for vertex in vertices_a),
                max(vertex[coordinate] for vertex in vertices_b),
            )
            - max(
                min(vertex[coordinate] for vertex in vertices_a),
                min(vertex[coordinate] for vertex in vertices_b),
            )
        )
        if overlap <= 1.0e-7:
            return None
    face_axes_a, edge_axes_a = body_collision_axes(body_a)
    face_axes_b, edge_axes_b = body_collision_axes(body_b)
    axes = face_axes_a + face_axes_b
    axes.extend(
        edge_a.cross(edge_b)
        for edge_a in edge_axes_a for edge_b in edge_axes_b
    )
    axes = unique_collision_axes(axes)
    center_a = sum(vertices_a, Vector()) / len(vertices_a)
    center_b = sum(vertices_b, Vector()) / len(vertices_b)
    center_direction = center_b - center_a
    from ..modules.ragdoll_collision import projected_cut
    return projected_cut(vertices_a, vertices_b, axes, center_direction)


def body_meshes_overlap(body_a, body_b):
    """Check exact convex collision-volume overlap using the SAT."""
    return exact_collision_cut_plane(body_a, body_b) is not None


def bisect_collision_body(body, plane_point, plane_normal):
    """Clip the positive side of a collision hull and close the cut."""
    inverse = body.matrix_world.inverted()
    local_point = inverse @ plane_point
    local_normal = (
        body.matrix_world.to_3x3().transposed() @ plane_normal
    ).normalized()
    mesh = body.data
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        result = bmesh.ops.bisect_plane(
            bm,
            geom=list(bm.verts) + list(bm.edges) + list(bm.faces),
            plane_co=local_point,
            plane_no=local_normal,
            dist=1.0e-7,
            clear_outer=True,
            clear_inner=False,
        )
        cut_edges = [
            element for element in result["geom_cut"]
            if isinstance(element, bmesh.types.BMEdge)
            and element.is_valid
        ]
        if cut_edges:
            bmesh.ops.holes_fill(bm, edges=cut_edges, sides=0)
        bm.normal_update()
        bm.to_mesh(mesh)
    finally:
        bm.free()
    mesh.update()
    if body.rigid_body is not None:
        body.rigid_body.collision_shape = "CONVEX_HULL"
    body["hhp_rd_clipped_collisions"] = True


def collision_category(segment_name):
    """Classify a generated segment for selective collision clipping."""
    part_property = SEGMENT_PART_PROPERTIES.get(segment_name)
    if part_property in {
            "hhp_ragdoll_fingers_l_enabled",
            "hhp_ragdoll_fingers_r_enabled"}:
        return "FINGERS"
    if part_property in {
            "hhp_ragdoll_toes_l_enabled",
            "hhp_ragdoll_toes_r_enabled"}:
        return "TOES"
    return "BODY"


def clip_collision_overlaps(
        bodies, enabled_categories=frozenset({"BODY", "FINGERS", "TOES"})):
    """Exactly separate every intersecting generated rigid-body pair."""
    clipped_pairs = 0
    for (name_a, body_a), (name_b, body_b) in itertools.combinations(
            bodies.items(), 2):
        if (
            collision_category(name_a) not in enabled_categories
            or collision_category(name_b) not in enabled_categories
        ):
            continue
        cut = exact_collision_cut_plane(body_a, body_b)
        if cut is None:
            continue
        _overlap, plane_point, normal = cut
        bisect_collision_body(body_a, plane_point, normal)
        bisect_collision_body(body_b, plane_point, -normal)
        clipped_pairs += 1
    return clipped_pairs


def clip_toe_collision_overlaps(bodies):
    """Compatibility wrapper for the former toe-only clipping function."""
    return clip_collision_overlaps(bodies)


def configure_joint_angular_limits(armature, joint, spec):
    """Apply the rig's anatomical angular limits, including upgrade metadata."""
    profile = joint_profile(armature, spec)
    rigid = joint.rigid_body_constraint
    limits = profile.get('limits', (profile['x'], (-profile['y'], profile['y']),
                                    (-profile['z'], profile['z'])))
    # Bullet reports the relative orientation opposite the child's geometric
    # right-hand rotation in the joint frame.
    for axis, (lower, upper) in zip('xyz', limits):
        setattr(rigid, f'limit_ang_{axis}_lower', math.radians(-upper))
        setattr(rigid, f'limit_ang_{axis}_upper', math.radians(-lower))
    if hhp_rig_version(armature) >= 5:
        joint['hhp_rd_anatomical_limits'] = True
        joint['hhp_rd_max_flex'] = max(0.0, float(limits[0][1]))
    for axis in 'xyz':
        for bound in ('lower', 'upper'):
            path = f'limit_ang_{axis}_{bound}'
            joint['hhp_rd_base_' + path] = float(getattr(rigid, path))
    return profile


def create_joint(armature, collection, name, spec, parent, child):
    profile = joint_profile(armature, spec)
    position = point_world(armature, *spec["start"])
    direction = point_world(armature, *spec["end"]) - position
    joint = bpy.data.objects.new(JOINT_PREFIX + name, None)
    collection.objects.link(joint)
    joint.matrix_world = (
        bone_axis_joint_frame(armature, spec.get("joint_bone", spec["reference"]), position)
        if spec.get("use_bone_axes")
        else joint_frame(position, direction, profile["ref"])
    )
    joint.empty_display_type = "ARROWS"
    joint.empty_display_size = .05
    joint.hide_render = True
    joint.hide_set(True)
    joint["description"] = (
        f"Anatomical {spec['joint']} hinge from {spec['parent']} to {name}."
    )
    joint["hhp_rd_joint_segment"] = name
    activate(joint)
    bpy.ops.rigidbody.constraint_add()
    rigid = joint.rigid_body_constraint
    rigid.type = "GENERIC_SPRING"
    rigid.object1 = parent
    rigid.object2 = child
    rigid.disable_collisions = True
    add_state_driver(
        rigid, "enabled", armature,
        joint_driver_expression(name),
        name,
    )
    for axis in "xyz":
        setattr(rigid, f"use_limit_lin_{axis}", True)
        setattr(rigid, f"limit_lin_{axis}_lower", 0.0)
        setattr(rigid, f"limit_lin_{axis}_upper", 0.0)
        setattr(rigid, f"use_limit_ang_{axis}", True)
    configure_joint_angular_limits(armature, joint, spec)
    joint["hhp_rd_joint_profile"] = spec["joint"]
    joint["hhp_rd_natural_curl_factor"] = float(
        spec.get("natural_curl_factor", 1.0))
    joint["hhp_rd_base_stiffness"] = float(profile["stiffness"])
    joint["hhp_rd_base_damping"] = float(profile["damping"])
    for axis in "xyz":
        setattr(rigid, f"use_spring_ang_{axis}", True)
        setattr(rigid, f"spring_stiffness_ang_{axis}",
                profile["stiffness"])
        setattr(rigid, f"spring_damping_ang_{axis}",
                profile["damping"])
    return joint


def create_bake_controls(armature, bodies, segments):
    armature_inverse = armature.matrix_world.inverted()
    initial_bone_matrices = {
        bone_name: armature_inverse @ bone_world(armature, bone_name)
        for spec in segments.values() for bone_name in spec["bones"]
    }
    activate(armature)
    bpy.ops.object.mode_set(mode="EDIT")
    root_control_parent = (armature.data.edit_bones.get("root")
                           or armature.data.edit_bones.get("hip(drv)"))
    for segment, spec in segments.items():
        for bone_name in spec["bones"]:
            source = armature.data.edit_bones[bone_name]
            control = armature.data.edit_bones.new(control_name(bone_name))
            control.parent = root_control_parent
            control.matrix = initial_bone_matrices[bone_name]
            control.length = max(source.length * .45, .04)
            control.use_deform = False
    bpy.ops.object.mode_set(mode="OBJECT")

    bone_collection = armature.data.collections.new(BAKE_COLLECTION_NAME)
    for segment, spec in segments.items():
        for bone_name in spec["bones"]:
            control = armature.data.bones[control_name(bone_name)]
            bone_collection.assign(control)
            control.color.palette = "THEME04"
            control["description"] = (
                f"Editable baked ragdoll control for {bone_name} "
                f"on the {segment} segment."
            )
            pose_bone = armature.pose.bones[bone_name]
            constraint = pose_bone.constraints.new("COPY_TRANSFORMS")
            constraint.name = f"{BAKE_PREFIX} · {segment}"
            constraint.target = armature
            constraint.subtarget = control.name
            constraint.target_space = "WORLD"
            constraint.owner_space = "WORLD"
            constraint.mix_mode = "REPLACE"
            add_state_driver(
                constraint, "influence", armature,
                "1.0 if ((bake or override) and not ragdoll "
                "and not keys) else 0.0",
            )
    bone_collection.is_visible = False


def configure_world(scene):
    if scene.rigidbody_world is None:
        bpy.ops.rigidbody.world_add()
    world = scene.rigidbody_world
    world.substeps_per_frame = 20
    world.solver_iterations = 30
    world.time_scale = 1.0
    world.point_cache.frame_start = scene.frame_start
    world.point_cache.frame_end = max(scene.frame_end, 250)


def collection_contains(collection, obj):
    if obj.name in collection.objects:
        return True
    return any(
        collection_contains(child, obj) for child in collection.children)


def find_char_collection(scene, armature, mesh_obj):
    """Locate the character's "<Char> (HHP)" collection per Ref_HHP Struct.

    Returns the shallowest scene collection whose name tags it as an HHP
    character and that actually contains the character. Falls back to the
    scene root so the build never fails on non-HHP files.
    """
    queue = list(scene.collection.children)
    while queue:
        collection = queue.pop(0)
        if "(HHP)" in collection.name and (
                collection_contains(collection, armature)
                or collection_contains(collection, mesh_obj)):
            return collection
        queue.extend(collection.children)
    return scene.collection


def disconnect_controlled_bones(armature, segments):
    controlled = {
        bone for spec in segments.values() for bone in spec["bones"]
    }
    activate(armature)
    bpy.ops.object.mode_set(mode="EDIT")
    for bone in armature.data.edit_bones:
        if bone.name in controlled and bone.use_connect:
            bone.use_connect = False
    bpy.ops.object.mode_set(mode="OBJECT")


def build_system(scene, armature, mesh_obj, generation_shape,
                 finger_mode="SINGLE", toe_mode="SINGLE",
                 clip_body_collisions=True,
                 clip_finger_collisions=True,
                 clip_toe_collisions=True):
    segments = compose_segments(finger_mode, toe_mode, armature)
    required = {
        name for spec in segments.values()
        for name in (
            [spec["reference"], spec["start"][0], spec["end"][0]]
            + spec["bones"])
    }
    missing = sorted(required.difference(armature.pose.bones.keys()))
    if missing:
        raise RuntimeError(f"Required bones missing: {', '.join(missing)}")
    if armature.mode != "OBJECT":
        activate(armature)
        bpy.ops.object.mode_set(mode="OBJECT")
    scene.frame_set(scene.frame_start)
    remove_old_system(armature)
    purge_dead_drivers(armature)
    disconnect_controlled_bones(armature, segments)
    armature.data.hhp_ragdoll_enabled = False
    armature.data.hhp_ragdoll_bake_enabled = False
    armature.data.hhp_ragdoll_keys_enabled = False
    armature.data.hhp_ragdoll_pose_override = False
    bpy.context.view_layer.update()
    generation_mesh = capture_generation_mesh(mesh_obj, generation_shape)

    collection = bpy.data.collections.new(COLLECTION_NAME)
    parent_collection = find_char_collection(scene, armature, mesh_obj)
    parent_collection.children.link(collection)
    print(f"HHP_RD_PARENT_COLLECTION={parent_collection.name}")
    collection["description"] = (
        "Single-armature HHP ragdoll bodies, joints, and hidden targets."
    )
    collection.hide_render = True
    bodies = {}
    stats = []
    for name, spec in segments.items():
        body, start, end, shape, vertices = create_body(
            armature, collection, generation_mesh, name, spec)
        bodies[name] = body
        stats.append(f"{name}:{shape}:{vertices}")
    clipped_pairs = 0
    clip_categories = {
        category for category, enabled in (
            ("BODY", clip_body_collisions),
            ("FINGERS", clip_finger_collisions),
            ("TOES", clip_toe_collisions),
        )
        if enabled
    }
    if clip_categories:
        clipped_pairs = clip_collision_overlaps(bodies, clip_categories)
    for name, spec in segments.items():
        if spec["parent"]:
            create_joint(
                armature, collection, name, spec,
                bodies[spec["parent"]], bodies[name])
    armature.data[FINGER_MODE_KEY] = finger_mode
    armature.data[TOE_MODE_KEY] = toe_mode
    armature.data[CLIP_BODY_COLLISIONS_KEY] = clip_body_collisions
    armature.data[CLIP_FINGER_COLLISIONS_KEY] = clip_finger_collisions
    armature.data[CLIP_TOE_COLLISIONS_KEY] = clip_toe_collisions
    armature.data[ACTIVE_SEGMENTS_KEY] = json.dumps(list(segments))
    create_bake_controls(armature, bodies, segments)
    configure_world(scene)
    apply_tuning(scene)
    armature.data.hhp_ragdoll_built = True
    armature.data["hhp_ragdoll_version"] = RAGDOLL_VERSION
    scene.hhp_rd_settings.armature = armature
    scene.hhp_rd_settings.body_mesh = mesh_obj
    sync_bodies(scene, force=True)
    armature.data.hhp_ragdoll_enabled = True
    layer = find_layer_collection(
        bpy.context.view_layer.layer_collection, collection)
    if layer is not None:
        layer.hide_viewport = True
    activate(armature)
    armature.show_in_front = True
    print("HHP_RD_HULLS " + " | ".join(stats))
    print(
        f"HHP_RD_BUILT bodies={len(bodies)} joints={len(bodies) - 1} "
        f"bones={sum(len(s['bones']) for s in segments.values())} "
        f"clipped_collision_pairs={clipped_pairs}"
    )


def apply_tuning(scene):
    """Push the panel's tuning multipliers onto bodies, joints, and world."""
    settings = scene.hhp_rd_settings
    armature = get_armature(scene)
    collection = bpy.data.collections.get(COLLECTION_NAME)
    if collection is None:
        return
    for obj in collection.objects:
        rigid = obj.rigid_body
        if rigid is not None and rigid.type == "ACTIVE":
            base_mass = obj.get("hhp_rd_base_mass")
            if base_mass is not None:
                rigid.mass = float(base_mass) * settings.weight
            rigid.friction = settings.friction
            rigid.restitution = settings.bounciness
        constraint = obj.rigid_body_constraint
        if constraint is not None and constraint.type == "GENERIC_SPRING":
            base_stiffness = obj.get("hhp_rd_base_stiffness")
            base_damping = obj.get("hhp_rd_base_damping")
            if base_stiffness is None or base_damping is None:
                continue
            segment_name = obj.get("hhp_rd_joint_segment")
            if segment_name is None and obj.name.startswith(JOINT_PREFIX):
                segment_name = obj.name[len(JOINT_PREFIX):]
            segment = (
                segment_spec(armature, segment_name)
                if armature and segment_name else
                SEGMENT_CATALOG.get(segment_name)
            )
            joint_profile = obj.get("hhp_rd_joint_profile")
            if joint_profile is None:
                joint_profile = segment["joint"] if segment else None
            if joint_profile in {"FINGER_BASE", "FINGER_HINGE"}:
                stiffness = settings.finger_stiffness
            elif joint_profile in {"BALL", "TOE"}:
                stiffness = settings.toe_stiffness
            else:
                stiffness = settings.stiffness
            for axis in "xyz":
                setattr(constraint, f"spring_stiffness_ang_{axis}",
                        float(base_stiffness) * stiffness)
                setattr(constraint, f"spring_damping_ang_{axis}",
                        float(base_damping) * settings.damping)
            if joint_profile in {"FINGER_BASE", "FINGER_HINGE"}:
                profile = JOINT_PROFILES[joint_profile]
                anatomical_limits = bool(obj.get('hhp_rd_anatomical_limits'))
                max_flex = (float(obj.get('hhp_rd_max_flex', profile['x'][0]))
                            if anatomical_limits else abs(float(profile["x"][0])))
                base_natural_curl = abs(float(profile["x"][1]))
                curl_factor = float(obj.get(
                    "hhp_rd_natural_curl_factor",
                    segment.get("natural_curl_factor", 1.0)
                    if segment else 1.0,
                ))
                bend = settings.finger_bending
                natural_curl = min(
                    max_flex,
                    base_natural_curl
                    * curl_factor
                    * settings.finger_natural_curling,
                )
                if anatomical_limits:
                    constraint.limit_ang_x_lower = math.radians(-max_flex * bend)
                    constraint.limit_ang_x_upper = math.radians(-natural_curl * bend)
                else:
                    constraint.limit_ang_x_lower = math.radians(natural_curl * bend)
                    constraint.limit_ang_x_upper = math.radians(max_flex * bend)
                for axis in "yz":
                    if anatomical_limits:
                        for bound in ('lower', 'upper'):
                            path = f'limit_ang_{axis}_{bound}'
                            setattr(constraint, path, float(obj['hhp_rd_base_' + path]) * bend)
                    else:
                        angle = math.radians(float(profile[axis]) * bend)
                        setattr(constraint, f"limit_ang_{axis}_lower", -angle)
                        setattr(constraint, f"limit_ang_{axis}_upper", angle)
            elif joint_profile in {"BALL", "TOE"}:
                for axis in "xyz":
                    for bound in ("lower", "upper"):
                        property_name = f"limit_ang_{axis}_{bound}"
                        base_key = f"hhp_rd_base_{property_name}"
                        base_value = obj.get(base_key)
                        if base_value is None:
                            base_value = float(
                                getattr(constraint, property_name))
                            obj[base_key] = base_value
                        setattr(
                            constraint,
                            property_name,
                            float(base_value) * settings.toe_rotation,
                        )
    if scene.rigidbody_world is not None:
        scene.rigidbody_world.time_scale = settings.speed


def sync_bodies(scene, force=False, segments=None):
    global _SYNCING
    if _SYNCING:
        return
    armature = get_armature(scene)
    if armature is None or not getattr(
            armature.data, "hhp_ragdoll_built", False):
        return
    collection = bpy.data.collections.get(COLLECTION_NAME)
    if collection is None:
        return
    _SYNCING = True
    try:
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = armature.evaluated_get(depsgraph)
        runtime_segments = active_segments(armature)
        for obj in collection.objects:
            joint_segment = obj.get("hhp_rd_joint_segment")
            if joint_segment is None and obj.name.startswith(JOINT_PREFIX):
                joint_segment = obj.name[len(JOINT_PREFIX):]
            spec = runtime_segments.get(joint_segment)
            if spec is not None and spec["joint"] is not None:
                part_property = SEGMENT_PART_PROPERTIES.get(joint_segment)
                part_enabled = (
                    part_property is None
                    or getattr(armature.data, part_property, True)
                )
                if segments is not None and joint_segment not in segments:
                    continue
                if (armature.data.hhp_ragdoll_enabled
                        and part_enabled and not force):
                    continue
                start_bone, start_endpoint = spec["start"]
                end_bone, end_endpoint = spec["end"]
                start_pose = evaluated.pose.bones[start_bone]
                end_pose = evaluated.pose.bones[end_bone]
                start = evaluated.matrix_world @ (
                    start_pose.head
                    if start_endpoint == "HEAD"
                    else start_pose.tail
                )
                end = evaluated.matrix_world @ (
                    end_pose.head
                    if end_endpoint == "HEAD"
                    else end_pose.tail
                )
                profile = JOINT_PROFILES[spec["joint"]]
                obj.matrix_world = (
                    bone_axis_joint_frame(
                        evaluated, spec.get("joint_bone", spec["reference"]), start)
                    if spec.get("use_bone_axes")
                    else joint_frame(start, end - start, profile["ref"])
                )
                obj.update_tag()
                continue
            reference_name = obj.get("hhp_rd_reference")
            offset_values = obj.get("hhp_rd_reference_offset")
            if not reference_name or not offset_values:
                continue
            body_segment = obj.get("hhp_rd_segment")
            part_property = SEGMENT_PART_PROPERTIES.get(body_segment)
            part_enabled = (
                part_property is None
                or getattr(armature.data, part_property, True)
            )
            if segments is not None and body_segment not in segments:
                continue
            if (armature.data.hhp_ragdoll_enabled
                    and part_enabled and not force):
                continue
            reference = (
                evaluated.matrix_world
                @ evaluated.pose.bones[reference_name].matrix
            )
            obj.matrix_world = reference @ unflatten_matrix(offset_values)
            obj.update_tag()
    finally:
        _SYNCING = False


def ensure_part_toggle_drivers(armature):
    """Upgrade an already-built ragdoll with per-part state drivers."""
    if (not getattr(armature.data, "hhp_ragdoll_built", False)
            or armature.data.get("hhp_ragdoll_version") == RAGDOLL_VERSION):
        return
    collection = bpy.data.collections.get(COLLECTION_NAME)
    if collection is None:
        return
    existing_segments = {
        obj.get("hhp_rd_segment") for obj in collection.objects
        if obj.get("hhp_rd_segment")
    }
    runtime_segments = active_segments(armature)
    for obj in collection.objects:
        segment_name = obj.get("hhp_rd_segment")
        if segment_name in runtime_segments and obj.rigid_body is not None:
            add_state_driver(
                obj,
                "rigid_body.kinematic",
                armature,
                part_driver_expression(segment_name, "1.0 - ragdoll", "1.0"),
                segment_name,
            )
        joint_segment = obj.get("hhp_rd_joint_segment")
        if (joint_segment in runtime_segments
                and obj.rigid_body_constraint is not None):
            if hhp_rig_version(armature) >= 5:
                spec = runtime_segments[joint_segment]
                configure_joint_angular_limits(armature, obj, spec)
                position = point_world(armature, *spec['start'])
                obj.matrix_world = bone_axis_joint_frame(
                    armature, spec.get('joint_bone', spec['reference']), position)
            add_state_driver(
                obj.rigid_body_constraint,
                "enabled",
                armature,
                joint_driver_expression(joint_segment),
                joint_segment,
            )
    for segment_name, spec in runtime_segments.items():
        if segment_name not in existing_segments:
            continue
        for bone_name in spec["bones"]:
            pose_bone = armature.pose.bones.get(bone_name)
            if pose_bone is None:
                continue
            part_segment = bone_part_segment(segment_name, bone_name)
            mute_animation_constraints(pose_bone, armature, part_segment)
            physics_name = f"{PHYSICS_PREFIX} · {segment_name}"
            constraint = pose_bone.constraints.get(physics_name)
            if constraint is not None:
                add_state_driver(
                    constraint,
                    "influence",
                    armature,
                    physics_driver_expression(part_segment),
                    part_segment,
                )
    expected_segments = set(compose_segments(*generation_modes(armature)))
    if expected_segments.issubset(existing_segments):
        armature.data["hhp_ragdoll_version"] = RAGDOLL_VERSION


def migrate_loaded_ragdolls():
    """Upgrade loaded ragdolls after Blender finishes addon registration."""
    for scene in bpy.data.scenes:
        armature = get_armature(scene)
        if armature is not None:
            collection = bpy.data.collections.get(COLLECTION_NAME)
            existing = [
                obj.get("hhp_rd_segment") for obj in collection.objects
                if obj.get("hhp_rd_segment")
            ] if collection else []
            if FINGER_MODE_KEY not in armature.data:
                finger_mode, toe_mode = infer_generation_modes(set(existing))
                armature.data[FINGER_MODE_KEY] = finger_mode
                armature.data[TOE_MODE_KEY] = toe_mode
            elif armature.data.get(FINGER_MODE_KEY) == "LEGACY":
                armature.data[FINGER_MODE_KEY] = "INDIVIDUAL"
            if ACTIVE_SEGMENTS_KEY not in armature.data and existing:
                armature.data[ACTIVE_SEGMENTS_KEY] = json.dumps(existing)
            ensure_part_toggle_drivers(armature)
            apply_tuning(scene)
    return None


def key_bool(data, path, frame, value):
    setattr(data, path, value)
    data.keyframe_insert(data_path=path, frame=frame)
    action = data.animation_data.action if data.animation_data else None
    slot = data.animation_data.action_slot if data.animation_data else None
    if action and slot and action.layers and action.layers[0].strips:
        bag = action.layers[0].strips[0].channelbag(slot)
        if bag:
            for fcurve in bag.fcurves:
                if fcurve.data_path == path:
                    for point in fcurve.keyframe_points:
                        point.interpolation = "CONSTANT"


def control_rig_mode_curve(armature, action=None, slot_handle=None):
    """Find the Rigify selector curve without assuming a particular action slot."""
    ad = armature.animation_data
    action = action or (ad.action if ad else None)
    if action is None:
        return None
    slot_handle = slot_handle if slot_handle is not None else ad.action_slot_handle
    for layer in action.layers:
        for strip in layer.strips:
            for bag in strip.channelbags:
                if bag.slot_handle == slot_handle:
                    return next((fc for fc in bag.fcurves
                                 if fc.data_path == '["hhp_rigify_active"]'), None)
    return None


def restore_control_rig_bake_mode(armature, start, end, frame):
    """Remove our mode interval and restore the original action's selector keys."""
    data = armature.data
    saved_action = data.get('hhp_rd_rig_action_before_bake')
    handle = data.get('hhp_rd_rig_slot_before_bake')
    saved_curve = (control_rig_mode_curve(armature, saved_action, handle)
                   if isinstance(saved_action, bpy.types.Action) else None)
    snapshot = json.loads(data.get('hhp_rd_rig_curve_before_bake', 'null'))
    remove_keys_in_range(armature, '["hhp_rigify_active"]', start - 1, end + 1)
    curve = control_rig_mode_curve(armature)
    if snapshot is None and saved_curve is not None:
        snapshot = snapshot_mode_curve(saved_curve)
    if curve is not None and snapshot is not None:
        for original in snapshot:
            if start - 1 <= original['co'][0] <= end + 1:
                point = curve.keyframe_points.insert(*original['co'], options={'FAST'})
                for name, value in original.items():
                    if name not in {'co', 'handle_left', 'handle_right'}:
                        setattr(point, name, value)
                point.handle_left = original['handle_left']
                point.handle_right = original['handle_right']
        curve.update()
    if curve is not None and not curve.keyframe_points:
        action = armature.animation_data.action
        for layer in action.layers:
            for strip in layer.strips:
                for bag in strip.channelbags:
                    if curve in list(bag.fcurves):
                        bag.fcurves.remove(curve)
                        curve = None
                        break
    armature['hhp_rigify_active'] = int(round(curve.evaluate(frame))) if curve and curve.keyframe_points else int(
        data.get('hhp_rd_rig_mode_before_bake', 0))
    for key in ('hhp_rd_rig_action_before_bake', 'hhp_rd_rig_slot_before_bake',
                'hhp_rd_rig_mode_before_bake', 'hhp_rd_rig_curve_before_bake'):
        if key in data:
            del data[key]


def snapshot_mode_curve(curve):
    fields = ('interpolation', 'easing', 'amplitude', 'back', 'period',
              'type', 'handle_left_type', 'handle_right_type')
    return [dict(co=list(point.co), handle_left=list(point.handle_left),
                 handle_right=list(point.handle_right),
                 **{field: getattr(point, field) for field in fields})
            for point in curve.keyframe_points]


def controlled_bones(armature):
    return [
        bone_name for spec in active_segments(armature).values()
        for bone_name in spec["bones"]
    ]


def desired_basis(armature, evaluated, bone_name, desired_map):
    """Local basis reproducing an armature-space pose with constraints off.

    Parents inside the controlled set use their own desired matrices so the
    whole pose is solved against itself, not against a half-applied state.
    """
    bone = armature.data.bones[bone_name]
    parent = bone.parent
    args = {}
    if parent is not None:
        args["parent_matrix"] = desired_map.get(
            parent.name, evaluated.pose.bones[parent.name].matrix)
        args["parent_matrix_local"] = parent.matrix_local
    return bone.convert_local_to_pose(
        desired_map[bone_name], bone.matrix_local, invert=True, **args)



def _native_pose_precision_ok(armature, evaluated, desired_map):
    """Accept only bounded HHP5 float roundoff after exact matrix matching.

    Deep Daz chains can settle above the matrix-element epsilon even when
    additional passes make no change. Check physical displacement, rotation,
    scale and basis-axis endpoints; visible pose mismatches still fail.
    """
    if hhp_rig_version(armature) < 5:
        return False
    unit_scale = bpy.context.scene.unit_settings.scale_length
    for name, desired in desired_map.items():
        actual = armature.matrix_world @ evaluated.pose.bones[name].matrix
        wanted = armature.matrix_world @ desired
        displacement = (actual.translation - wanted.translation).length * unit_scale
        if not math.isfinite(displacement) or displacement > 1e-5:
            return False
        first, second = actual.to_quaternion(), wanted.to_quaternion()
        norm_a = math.sqrt(sum(float(value)**2 for value in first))
        norm_b = math.sqrt(sum(float(value)**2 for value in second))
        if not all(math.isfinite(value) and value > 1e-12 for value in (norm_a, norm_b)):
            return False
        first = [float(value)/norm_a for value in first]
        second = [float(value)/norm_b for value in second]
        sign = 1.0 if sum(a*b for a,b in zip(first, second)) >= 0.0 else -1.0
        distance = math.sqrt(sum((a-sign*b)**2 for a,b in zip(first, second)))
        angle = 4.0 * math.asin(min(1.0, distance/2.0))
        if not math.isfinite(angle) or angle > math.radians(.005):
            return False
        for a, b in zip(actual.to_scale(), wanted.to_scale()):
            relative = abs(float(a)-float(b))/max(abs(float(a)), abs(float(b)), 1e-12)
            if not math.isfinite(relative) or relative > 1e-5:
                return False
        # Also bound shear: matching quaternion/scale alone can hide it.
        length = armature.data.bones[name].length
        for column in range(3):
            delta = math.sqrt(sum((float(actual[row][column])-float(wanted[row][column]))**2
                                  for row in range(3))) * length * unit_scale
            if not math.isfinite(delta) or delta > 1e-5:
                return False
    return True


def apply_pose_basis(armature, desired_map):
    # Carpal and other intermediate parents are not ragdoll destinations.
    # Evaluate them after each ancestor depth before solving their children.
    levels = {}
    for name in desired_map:
        depth = len(armature.data.bones[name].parent_recursive)
        levels.setdefault(depth, []).append(name)
    for _pass in range(4):
        for depth in sorted(levels):
            evaluated = armature.evaluated_get(bpy.context.evaluated_depsgraph_get())
            for bone_name in levels[depth]:
                armature.pose.bones[bone_name].matrix_basis = desired_basis(
                    armature, evaluated, bone_name, desired_map)
            bpy.context.view_layer.update()
        # HHP4 carpals are detached roots constrained to hand controllers.
        # Another pass resolves these constraint links after the hand moves.
        evaluated = armature.evaluated_get(bpy.context.evaluated_depsgraph_get())
        error = max((abs(a - b) for name, matrix in desired_map.items()
                     for actual, wanted in zip(evaluated.pose.bones[name].matrix, matrix)
                     for a, b in zip(actual, wanted)), default=0.0)
        if error < 0.00001:
            return
    if _native_pose_precision_ok(armature, evaluated, desired_map):
        return
    raise RuntimeError("The rig could not reproduce the sampled pose; undo the transfer")


def key_pose_on_bones(armature, desired_map, frame):
    apply_pose_basis(armature, desired_map)
    for bone_name in desired_map:
        pose_bone = armature.pose.bones[bone_name]
        pose_bone.keyframe_insert("location", frame=frame)
        rotation_path = ("rotation_quaternion" if pose_bone.rotation_mode == "QUATERNION"
                         else "rotation_axis_angle" if pose_bone.rotation_mode == "AXIS_ANGLE"
                         else "rotation_euler")
        pose_bone.keyframe_insert(rotation_path, frame=frame)
        if bone_name != 'root' or uniform_root_bone(armature) is None:
            pose_bone.keyframe_insert("scale", frame=frame)


def capture_basis(scene, armature, frame):
    """Snapshot original animation channel values to guard-key later."""
    scene.frame_set(frame)
    bpy.context.view_layer.update()
    return {
        bone_name: armature.pose.bones[bone_name].matrix_basis.copy()
        for bone_name in controlled_bones(armature)
    }


def key_guard_basis(armature, basis_map, frame):
    for bone_name, basis in basis_map.items():
        pose_bone = armature.pose.bones[bone_name]
        pose_bone.matrix_basis = basis
        pose_bone.keyframe_insert("location", frame=frame)
        rotation_path = ("rotation_quaternion" if pose_bone.rotation_mode == "QUATERNION"
                         else "rotation_axis_angle" if pose_bone.rotation_mode == "AXIS_ANGLE"
                         else "rotation_euler")
        pose_bone.keyframe_insert(rotation_path, frame=frame)
        if bone_name != 'root' or uniform_root_bone(armature) is None:
            pose_bone.keyframe_insert("scale", frame=frame)


def sampled_pose(armature):
    """Armature-space matrices of every controlled bone, fully evaluated."""
    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = armature.evaluated_get(depsgraph)
    names = (transfer_bones(armature) if armature.get('hhp_rigify_built')
             and hhp_rig_version(armature) >= 5 else controlled_bones(armature))
    return {
        bone_name: evaluated.pose.bones[bone_name].matrix.copy()
        for bone_name in names
    }


def remove_bone_keys_in_range(armature, bone_names, start, end):
    animation = armature.animation_data
    if not animation or not animation.action or not animation.action_slot:
        return
    action = animation.action
    if not action.layers or not action.layers[0].strips:
        return
    bag = action.layers[0].strips[0].channelbag(animation.action_slot)
    if not bag:
        return
    prefixes = tuple(f'pose.bones["{name}"].' for name in bone_names)
    for fcurve in bag.fcurves:
        if not fcurve.data_path.startswith(prefixes):
            continue
        indexes = [
            index for index, point in enumerate(fcurve.keyframe_points)
            if start <= point.co.x <= end
        ]
        for index in reversed(indexes):
            fcurve.keyframe_points.remove(
                fcurve.keyframe_points[index], fast=True)
        fcurve.update()


def remove_keys_in_range(data, path, start, end):
    if not data.animation_data or not data.animation_data.action:
        return
    action = data.animation_data.action
    slot = data.animation_data.action_slot
    if not slot or not action.layers or not action.layers[0].strips:
        return
    bag = action.layers[0].strips[0].channelbag(slot)
    if not bag:
        return
    for fcurve in bag.fcurves:
        if fcurve.data_path == path:
            indexes = [
                index for index, point in enumerate(fcurve.keyframe_points)
                if start <= point.co.x <= end
            ]
            for index in reversed(indexes):
                fcurve.keyframe_points.remove(
                    fcurve.keyframe_points[index], fast=True)
            fcurve.update()


class HHP_RD_OT_build(Operator):
    """Open setup, auto-detect the visible HHP character, then build or rebuild its fitted ragdoll."""

    bl_idname = "hhp_rd.build"
    bl_label = "Build / Rebuild Ragdoll"
    bl_options = {"REGISTER", "UNDO"}

    generation_shape: EnumProperty(
        name="Generation Shape",
        items=(
            (
                "FINAL",
                "Final Shape",
                "Fit rigid bodies to the mesh after shape keys, armature "
                "deformation, and modifiers",
            ),
            (
                "BASE",
                "Base Shape",
                "Fit rigid bodies to the undeformed base mesh",
            ),
        ),
        default="FINAL",
        description="Choose which mesh shape is used to fit rigid bodies",
    )
    finger_generation: EnumProperty(
        name="Finger Generation",
        items=(
            (
                "SINGLE", "Single Block",
                "Use only the hand rigid body with no separate finger bodies",
            ),
            (
                "COMBINED", "Combined Fingers",
                "Generate articulated thumb and index fingers, plus one "
                "combined body for the middle, ring, and pinky fingers",
            ),
            (
                "INDIVIDUAL", "Individual Fingers",
                "Generate a separate articulated rigid body for every "
                "phalanx of every finger",
            ),
        ),
        default="SINGLE",
        description="Choose how finger rigid bodies are generated",
    )
    toe_generation: EnumProperty(
        name="Toe Generation",
        items=(
            (
                "SINGLE", "Single Block",
                "Use the current single toe block for each foot",
            ),
            (
                "COMBINED", "Combined Toes",
                "Generate one big-toe body and one body for the smaller toes",
            ),
            (
                "INDIVIDUAL", "Individual Toes",
                "Generate one rigid body for each whole toe",
            ),
        ),
        default="SINGLE",
        description="Choose how toe rigid bodies are generated",
    )
    clip_body_collisions: BoolProperty(
        name="Body",
        default=True,
        description=(
            "Clip overlapping body rigid-body hulls against other enabled "
            "collision categories"
        ),
    )
    clip_finger_collisions: BoolProperty(
        name="Fingers",
        default=True,
        description=(
            "Clip overlapping finger rigid-body hulls against other enabled "
            "collision categories"
        ),
    )
    clip_toe_collisions: BoolProperty(
        name="Toes",
        default=True,
        description=(
            "Clip overlapping toe rigid-body hulls against other enabled "
            "collision categories"
        ),
    )

    def invoke(self, context, _event):
        armature, mesh = auto_hhp_character(context)
        settings = context.scene.hhp_rd_settings
        settings.armature = armature or settings.armature
        settings.body_mesh = mesh or settings.body_mesh
        if armature is not None and getattr(
                armature.data, "hhp_ragdoll_built", False):
            finger_mode, toe_mode = generation_modes(armature)
            self.finger_generation = (
                "INDIVIDUAL" if finger_mode == "LEGACY" else finger_mode)
            self.toe_generation = toe_mode
            legacy_clip = bool(
                armature.data.get(
                    CLIPPED_COLLISIONS_KEY,
                    armature.data.get(TOE_CLIPPED_COLLISIONS_KEY, True),
                ))
            self.clip_body_collisions = bool(armature.data.get(
                CLIP_BODY_COLLISIONS_KEY, legacy_clip))
            self.clip_finger_collisions = bool(armature.data.get(
                CLIP_FINGER_COLLISIONS_KEY, legacy_clip))
            self.clip_toe_collisions = bool(armature.data.get(
                CLIP_TOE_COLLISIONS_KEY, legacy_clip))
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        settings = context.scene.hhp_rd_settings
        column = self.layout.column(align=True)
        column.prop(settings, "armature", icon="ARMATURE_DATA")
        column.prop(settings, "body_mesh", icon="MESH_DATA")
        column.label(text="Finger and toe generation")
        finger_row = column.row(align=True)
        finger_row.prop(self, "finger_generation", expand=True)
        toe_row = column.row(align=True)
        toe_row.prop(self, "toe_generation", expand=True)
        column.label(text="clip collisions for")
        clipped_row = column.row(align=True)
        clipped_row.prop(self, "clip_body_collisions")
        clipped_row.prop(self, "clip_finger_collisions")
        clipped_row.prop(self, "clip_toe_collisions")
        column.separator()
        shape_row = column.row(align=True)
        shape_row.prop(self, "generation_shape", expand=True)

    def execute(self, context):
        settings = context.scene.hhp_rd_settings
        armature = settings.armature
        mesh_obj = settings.body_mesh
        if armature is None or mesh_obj is None:
            detected_armature, detected_mesh = auto_hhp_character(context)
            armature = armature or detected_armature
            mesh_obj = mesh_obj or detected_mesh
        if armature is None or mesh_obj is None:
            self.report(
                {"ERROR"},
                "No visible HHP character and armature could be detected")
            return {"CANCELLED"}
        settings.armature = armature
        settings.body_mesh = mesh_obj
        try:
            build_system(
                context.scene, armature, mesh_obj, self.generation_shape,
                self.finger_generation, self.toe_generation,
                self.clip_body_collisions,
                self.clip_finger_collisions,
                self.clip_toe_collisions)
        except Exception as exc:
            self.report({"ERROR"}, f"Ragdoll build failed: {exc}")
            raise
        segments = active_segments(armature)
        self.report(
            {"INFO"},
            f"Built {len(segments)} bodies and "
            f"{sum(bool(spec['parent']) for spec in segments.values())} "
            "anatomical joints")
        return {"FINISHED"}


class HHP_RD_OT_activate_here(Operator):
    """Release physics at this frame from the real armature's evaluated pose."""

    bl_idname = "hhp_rd.activate_here"
    bl_label = "Ragdoll From Here"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        armature = get_armature(context.scene)
        if armature is None:
            self.report({"ERROR"}, "Build the ragdoll first")
            return {"CANCELLED"}
        frame = context.scene.frame_current
        from ..modules import hhp_rigify
        hhp_rigify._pause_preview_action(armature.data)
        armature.data.hhp_ragdoll_enabled = False
        context.view_layer.update()
        sync_bodies(context.scene, force=True)
        heal_ragdoll_collection_visibility(context)
        armature.data.hhp_ragdoll_enabled = True
        self.report({"INFO"}, f"Ragdoll enabled at frame {frame}; no keyframes added")
        return {"FINISHED"}


class HHP_RD_OT_return_here(Operator):
    """Return from physics to the armature's animation at this frame."""

    bl_idname = "hhp_rd.return_here"
    bl_label = "Animation From Here"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        armature = get_armature(context.scene)
        if armature is None:
            return {"CANCELLED"}
        frame = context.scene.frame_current
        from ..modules import hhp_rigify
        hhp_rigify._pause_preview_action(armature.data)
        saved_pose = armature.data.get("hhp_rd_pose_before_copy")
        if saved_pose:
            for name, values in json.loads(saved_pose).items():
                bone = armature.pose.bones.get(name)
                if bone is not None:
                    bone.matrix_basis = unflatten_matrix(values)
            del armature.data["hhp_rd_pose_before_copy"]
        if armature.get('hhp_rigify_built') and 'hhp_rd_rig_before_copy' in armature.data:
            armature['hhp_rigify_active'] = int(armature.data['hhp_rd_rig_before_copy'])
            del armature.data['hhp_rd_rig_before_copy']
        armature.data.hhp_ragdoll_pose_override = False
        for path in ("hhp_ragdoll_keys_enabled", "hhp_ragdoll_bake_enabled"):
            setattr(armature.data, path, False)
        armature.data.hhp_ragdoll_enabled = False
        resume_native_action_playback(armature)
        hhp_rigify._resume_preview_action(armature)
        sync_portable_action_playback(armature)
        self.report({"INFO"}, f"Animation restored at frame {frame}; no keyframes added")
        return {"FINISHED"}


class HHP_RD_OT_toggle_helpers(Operator):
    """Show or hide the HHP_Ragdoll collection in the viewport (eye visibility only, so the physics keeps simulating either way)."""

    bl_idname = "hhp_rd.toggle_helpers"
    bl_label = "Toggle Ragdoll Collection"

    def execute(self, context):
        collection = bpy.data.collections.get(COLLECTION_NAME)
        if collection is None:
            self.report({"ERROR"}, "Build the ragdoll first")
            return {"CANCELLED"}
        # Self-heal files saved while the collection was disabled in the
        # viewport, which silently freezes the rigid bodies.
        collection.hide_viewport = False
        layer = find_layer_collection(
            context.view_layer.layer_collection, collection)
        if layer is None:
            self.report({"ERROR"}, "HHP_Ragdoll is not in this view layer")
            return {"CANCELLED"}
        layer.hide_viewport = not layer.hide_viewport
        context.view_layer.update()
        self.report(
            {"INFO"},
            "Ragdoll collection hidden in viewport"
            if layer.hide_viewport
            else "Ragdoll collection shown in viewport")
        return {"FINISHED"}


class HHP_RD_OT_bake(Operator):
    """Bake the simulated range onto separate editable control bones instead of the bones' own keyframes."""

    bl_idname = "hhp_rd.bake"
    bl_label = "Bake to Edit Controls"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        settings = scene.hhp_rd_settings
        armature = get_armature(scene)
        if armature is None:
            self.report({"ERROR"}, "Build the ragdoll first")
            return {"CANCELLED"}
        start, end = settings.bake_start, settings.bake_end
        if start > end:
            self.report({"ERROR"}, "Bake Start must not exceed Bake End")
            return {"CANCELLED"}
        bodies = {
            obj["hhp_rd_segment"]: obj
            for obj in bpy.data.collections[COLLECTION_NAME].objects
            if obj.name.startswith(BODY_PREFIX)
        }
        segments = active_segments(armature)
        missing = [name for name in segments if name not in bodies]
        if missing:
            self.report({"ERROR"}, "Ragdoll bodies are incomplete")
            return {"CANCELLED"}

        original_frame = scene.frame_current
        for frame in range(scene.frame_start, end + 1):
            scene.frame_set(frame)
            context.view_layer.update()
            if frame < start:
                continue
            depsgraph = context.evaluated_depsgraph_get()
            evaluated = armature.evaluated_get(depsgraph)
            for spec in segments.values():
                for bone_name in spec["bones"]:
                    control = armature.pose.bones[control_name(bone_name)]
                    control.rotation_mode = "QUATERNION"
                    control.matrix = evaluated.pose.bones[bone_name].matrix
                    control.keyframe_insert("location", frame=frame)
                    control.keyframe_insert(
                        "rotation_quaternion", frame=frame)
                    control.keyframe_insert("scale", frame=frame)

        armature.data.hhp_ragdoll_enabled = False
        armature.data.hhp_ragdoll_bake_enabled = True
        armature.data.hhp_ragdoll_keys_enabled = False
        tag_native_bake_action(armature, set(controlled_bones(armature)),
                               start, end, playback='CONTROLS')
        armature.data['hhp_rd_action_bake_range'] = [start, end]
        armature.data['hhp_rd_action_bake_version'] = 2
        scene.frame_set(original_frame)
        sync_portable_action_playback(armature)
        self.report(
            {"INFO"}, f"Baked frames {start}-{end} to real-armature controls")
        return {"FINISHED"}


FALLBACK_POSE_CONTROLLER_TARGETS = {
    "Collar Controller.l": "lCollar",
    "Collar Controller.r": "rCollar",
    "Hand.l": "lHand",
    "Hand.r": "rHand",
    "Foot.l": "lFoot",
    "Foot.r": "rFoot",
}

DIRECT_POSE_BONES = (
    "hip", "pelvis",
    "abdomenLower", "abdomenUpper", "chestLower", "chestUpper",
    "neckLower", "neckUpper", "head",
    "Metatarsals.l", "Toe.l",
    "Metatarsals.r", "Toe.r",
) + tuple(
    bone
    for suffix in ("l", "r")
    for bone in (
        f"BigToe.{suffix}", f"BigToe_2.{suffix}",
        *(name for index in range(1, 5) for name in (
            f"SmallToe{index}.{suffix}",
            f"SmallToe{index}_2.{suffix}",
        )),
    )
)

LIMB_POLE_CHAINS = (
    ("lForearmBend", "lShldrBend", "lForearmBend", "lHand"),
    ("rForearmBend", "rShldrBend", "rForearmBend", "rHand"),
    ("lShin", "lThighBend", "lShin", "lFoot"),
    ("rShin", "rThighBend", "rShin", "rFoot"),
)


def upstream_pose_control(armature, bone_name):
    """Follow same-armature control constraints to the user-facing control."""
    visited = set()
    current = bone_name
    while current in armature.pose.bones and current not in visited:
        visited.add(current)
        pose_bone = armature.pose.bones[current]
        driving_constraint = next(
            (
                constraint for constraint in pose_bone.constraints
                if constraint.type in {
                    "CHILD_OF", "COPY_TRANSFORMS",
                    "COPY_LOCATION", "COPY_ROTATION",
                }
                and constraint.target == armature
                and constraint.subtarget
                and constraint.subtarget in armature.pose.bones
            ),
            None,
        )
        if driving_constraint is None:
            break
        current = driving_constraint.subtarget
    return current


def ragdoll_pose_controller_targets(armature):
    """Find the actual HHP controls that drive ragdoll-controlled chains."""
    result = {}

    for source_name in ("lCollar", "rCollar"):
        if source_name not in armature.pose.bones:
            continue
        control_name = upstream_pose_control(armature, source_name)
        if control_name != source_name:
            result[control_name] = source_name

    for ik_bone, _start, _bend, end_bone in LIMB_POLE_CHAINS:
        pose_bone = armature.pose.bones.get(ik_bone)
        if pose_bone is None:
            continue
        constraint = next(
            (
                item for item in pose_bone.constraints
                if item.type == "IK"
                and item.target == armature
                and item.subtarget
            ),
            None,
        )
        if constraint is None:
            continue
        control_name = upstream_pose_control(
            armature, constraint.subtarget)
        result[control_name] = end_bone

    for prefix in ("l", "r"):
        for digit in FINGER_DIGITS:
            ik_bone = armature.pose.bones.get(f"{prefix}{digit}2")
            if ik_bone is None:
                continue
            constraint = next(
                (
                    item for item in ik_bone.constraints
                    if item.type == "IK"
                    and item.target == armature
                    and item.subtarget
                ),
                None,
            )
            if constraint is None:
                continue
            control_name = upstream_pose_control(
                armature, constraint.subtarget)
            result[control_name] = f"{prefix}{digit}3"

    for control_name, source_name in FALLBACK_POSE_CONTROLLER_TARGETS.items():
        if source_name not in result.values():
            resolved_name = upstream_pose_control(armature, control_name)
            if resolved_name in armature.pose.bones:
                result[resolved_name] = source_name
    return result


def ragdoll_pose_pole_controls(armature):
    """Map each IK pole control to the ragdoll bones defining its bend plane."""
    result = {}
    for ik_bone, start, bend, end in LIMB_POLE_CHAINS:
        pose_bone = armature.pose.bones.get(ik_bone)
        if pose_bone is None:
            continue
        constraint = next(
            (
                item for item in pose_bone.constraints
                if item.type == "IK"
                and item.pole_target == armature
                and item.pole_subtarget
            ),
            None,
        )
        if constraint is not None:
            control_name = upstream_pose_control(
                armature, constraint.pole_subtarget)
            result[control_name] = (
                constraint.pole_subtarget, (start, bend, end))
    return result


def set_pole_from_ragdoll(armature, pole_name, pole_data, desired_pose):
    """Place an IK pole in the bend plane of the simulated limb."""
    pole_source, chain = pole_data
    start_name, bend_name, end_name = chain
    if not all(name in desired_pose for name in chain):
        return
    start = desired_pose[start_name].translation
    bend = desired_pose[bend_name].translation
    end = desired_pose[end_name].translation
    line = end - start
    if line.length_squared < 1e-10:
        return
    projection = start + line * ((bend - start).dot(line) / line.length_squared)
    direction = bend - projection
    if direction.length_squared < 1e-10:
        return
    distance = max((bend - start).length + (end - bend).length, 0.25)
    desired_position = bend + direction.normalized() * distance
    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = armature.evaluated_get(depsgraph)
    matrix = evaluated.pose.bones[pole_name].matrix.copy()
    matrix.translation += (
        desired_position
        - evaluated.pose.bones[pole_source].matrix.translation
    )
    armature.pose.bones[pole_name].matrix = matrix


def transfer_bones(armature):
    """Use HHP5's weighted Daz bones and native hip, or the HHP4 skeleton."""
    controlled = set(controlled_bones(armature))
    if hhp_rig_version(armature) < 5:
        return controlled
    settings = bpy.context.scene.hhp_rd_settings
    mesh = settings.body_mesh
    if mesh is None or mesh.find_armature() != armature:
        mesh = next((obj for obj in bpy.data.objects
                     if is_hhp_character_mesh(obj)
                     and obj.find_armature() == armature), None)
    if mesh is None:
        raise RuntimeError("Select the HHP5 body mesh to identify weighted bones")
    groups = {group.index: group.name for group in mesh.vertex_groups}
    weighted = {groups[item.group] for vertex in mesh.data.vertices
                for item in vertex.groups
                if item.weight > 0.0 and item.group in groups}
    if armature.get('hhp_rigify_built'):
        # A single hand body still carries the current finger pose. Rigify's
        # manifest records the unchanged Daz destinations, never its controls,
        # generated deformation bones, or mechanism bones.
        from ..modules import hhp_rigify
        manifest = hhp_rigify.manifest(armature)
        controlled.update(name for name in manifest.get('bindings', {})
                          if name in armature.pose.bones)
    names = {name for name in controlled.intersection(weighted)
            if armature.data.bones[name].use_deform
            and not name.endswith("(drv)")
            and not name.startswith((CTRL_PREFIX, HELPER_PREFIX))}
    # Hip is a native Daz structural parent, even though it has no weights.
    # Keeping its motion preserves the parent-relative abdomen/pelvis rotations
    # used by corrective shape drivers. Child world matrices alone are not
    # enough: compensating for a reset hip changes the visible JCM deformation.
    if 'hip' in controlled:
        names.add('hip')
    return names


def prepare_transfer_constraints(armature, names):
    """Additional control-rig bones keep animating during grouped physics."""
    physical = set(controlled_bones(armature))
    for name in names - physical:
        mute_animation_constraints(armature.pose.bones[name], armature, None, physics=False)


def copy_selected_pose(armature, names):
    """Copy exactly the destination bones while preserving viewport selection."""
    data = armature.data
    collections = getattr(data, "collections_all", data.collections)
    saved_selection = {b.name: b.select for b in armature.pose.bones}
    saved_pose_hide = {name: armature.pose.bones[name].hide for name in names}
    saved_hide = {name: (data.bones[name].hide, data.bones[name].hide_select)
                  for name in names}
    saved_visibility = {c.name: c.is_visible for c in collections}
    mode = armature.mode
    try:
        for c in collections:
            c.is_visible = True
        for name in names:
            armature.pose.bones[name].hide = False
            data.bones[name].hide = False
            data.bones[name].hide_select = False
        activate(armature)
        bpy.ops.object.mode_set(mode="POSE")
        for bone in armature.pose.bones:
            bone.select = bone.name in names
        bpy.ops.pose.copy()
    finally:
        for bone in armature.pose.bones:
            bone.select = saved_selection.get(bone.name, False)
        for name, (hide, hide_select) in saved_hide.items():
            armature.pose.bones[name].hide = saved_pose_hide[name]
            data.bones[name].hide = hide
            data.bones[name].hide_select = hide_select
        for c in collections:
            c.is_visible = saved_visibility[c.name]
        if armature.mode != mode:
            bpy.ops.object.mode_set(mode=mode)


@contextmanager
def _copy_pose_transaction(armature, names):
    """A failed clipboard/pose transfer must release newly paused Actions."""
    from ..modules import hhp_rigify
    global _TOGGLING_RAGDOLL
    channels = ('location', 'rotation_euler', 'rotation_quaternion',
                'rotation_axis_angle', 'scale')
    bases = {name: {channel: tuple(getattr(armature.pose.bones[name], channel))
                    for channel in channels} for name in names}
    flags = {name: getattr(armature.data, name) for name in (
        'hhp_ragdoll_enabled', 'hhp_ragdoll_bake_enabled',
        'hhp_ragdoll_keys_enabled', 'hhp_ragdoll_pose_override')}
    rig_mode = armature.get('hhp_rigify_active')
    owners = (armature, armature.data)
    already_paused = {owner: hhp_rigify._PAUSE_STATE in owner for owner in owners}
    state_keys = ('hhp_rd_pose_before_copy', 'hhp_rd_rig_before_copy',
                  'hhp_rd_transform_driver_mutes')
    saved_data = {key: armature.data.get(key) for key in state_keys}
    driver_mutes = {(fc.data_path, fc.array_index): bool(fc.mute)
                    for fc in armature.animation_data.drivers} if armature.animation_data else {}
    try:
        yield
    except Exception:
        previous_toggling = _TOGGLING_RAGDOLL
        _TOGGLING_RAGDOLL = True
        try:
            for name, value in flags.items():
                setattr(armature.data, name, value)
            if rig_mode is not None:
                armature['hhp_rigify_active'] = rig_mode
            for name, values in bases.items():
                for channel, value in values.items():
                    setattr(armature.pose.bones[name], channel, value)
            for key, value in saved_data.items():
                if value is None:
                    if key in armature.data:
                        del armature.data[key]
                else:
                    armature.data[key] = value
            if armature.animation_data:
                for fc in armature.animation_data.drivers:
                    key = (fc.data_path, fc.array_index)
                    if key in driver_mutes:
                        fc.mute = driver_mutes[key]
            for owner in owners:
                if not already_paused[owner]:
                    hhp_rigify._resume_preview_action(owner)
            _mirror_state_properties(armature.data)
            armature.update_tag()
        finally:
            _TOGGLING_RAGDOLL = previous_toggling
        raise


class HHP_RD_OT_copy_pose(Operator):
    """Transfer the visible pose to Daz bones and their native hip anchor in HHP5 or root-parented pose controls in HHP4, then copy those bones to the pose clipboard. No keys are created."""

    bl_idname = "hhp_rd.copy_pose"
    bl_label = "Copy Ragdoll Pose"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        armature = get_armature(context.scene)
        return bool(armature and armature.data.hhp_ragdoll_built)

    def execute(self, context):
        armature = get_armature(context.scene)
        context.view_layer.update()
        captured = sampled_pose(armature)
        version = hhp_rig_version(armature)
        if version >= 5:
            names = transfer_bones(armature)
            desired = {name: captured[name] for name in names}
        else:
            desired = {control_name(name): matrix for name, matrix
                       in captured.items()}
            names = set(desired)
        if not names:
            self.report({"ERROR"}, "No weighted ragdoll bones were found")
            return {"CANCELLED"}
        with _copy_pose_transaction(armature, names):
            from ..modules import hhp_rigify
            hhp_rigify._pause_preview_action(armature.data)
            if "hhp_rd_pose_before_copy" not in armature.data:
                armature.data["hhp_rd_pose_before_copy"] = json.dumps({
                    name: flatten_matrix(armature.pose.bones[name].matrix_basis)
                    for name in names})
            if version >= 5:
                # An authored rig-mode or bone curve otherwise reevaluates over the
                # unkeyed handoff. Pausing this object's slot leaves shared Actions
                # untouched and resumes normally on the next frame.
                from ..modules import hhp_rigify
                hhp_rigify._pause_preview_action(armature)
                prepare_transform_driver_overrides(armature, names)
                prepare_transfer_constraints(armature, names)
                if armature.get('hhp_rigify_built'):
                    if 'hhp_rd_rig_before_copy' not in armature.data:
                        armature.data['hhp_rd_rig_before_copy'] = int(armature.get('hhp_rigify_active', 0))
                    armature['hhp_rigify_active'] = 0
            armature.data.hhp_ragdoll_enabled = False
            armature.data.hhp_ragdoll_bake_enabled = False
            armature.data.hhp_ragdoll_keys_enabled = version >= 5
            armature.data.hhp_ragdoll_pose_override = version < 5
            context.view_layer.update()
            apply_pose_basis(armature, desired)
            context.view_layer.update()
            copy_selected_pose(armature, names)
        self.report({"INFO"}, f"Copied {len(names)} " + (
            "Daz bones including the hip anchor" if version >= 5 else "HHP4 pose controls")
            + "; pose retained without keyframes")
        return {"FINISHED"}


class HHP_RD_OT_paste_pose(Operator):
    """Apply the copied ragdoll pose through root-parented pose controls - no keyframes. The pose remains intact when the root bone moves."""

    bl_idname = "hhp_rd.paste_pose"
    bl_label = "Paste Ragdoll Pose"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        armature = get_armature(scene)
        if armature is None:
            self.report({"ERROR"}, "Build the ragdoll first")
            return {"CANCELLED"}
        buffer = scene.get("hhp_rd_pose_buffer")
        if not buffer:
            self.report({"ERROR"}, "Copy a ragdoll pose first")
            return {"CANCELLED"}
        desired_map = {
            bone_name: unflatten_matrix(list(values))
            for bone_name, values in buffer.items()
        }
        missing = [
            bone_name for bone_name in desired_map
            if control_name(bone_name) not in armature.pose.bones
        ]
        if missing:
            self.report(
                {"ERROR"},
                "Rebuild the ragdoll once to create pose override controls")
            return {"CANCELLED"}

        # Store the unkeyed pose on dedicated bones parented to root. The
        # deform channels remain animation-owned; moving root carries the
        # complete pasted pose rigidly instead of triggering a reevaluation
        # that mixes pasted and animated channels.
        armature.data.hhp_ragdoll_pose_override = False
        context.view_layer.update()
        for bone_name, desired_matrix in desired_map.items():
            control = armature.pose.bones[control_name(bone_name)]
            control.rotation_mode = "QUATERNION"
            control.matrix = desired_matrix
        armature.data.hhp_ragdoll_pose_override = True
        context.view_layer.update()
        self.report(
            {"INFO"},
            f"Pasted ragdoll pose onto {len(desired_map)} bones - "
            "no keyframes; root-safe pose override is active")
        return {"FINISHED"}


class HHP_RD_OT_bake_action(Operator):
    """Sample simulated motion onto the original skeleton. HHP5 writes weighted Daz bones and their native hip anchor. Original actions are kept as backups."""

    bl_idname = "hhp_rd.bake_action"
    bl_label = "Bake Ragdoll to Action"
    bl_options = {"REGISTER", "UNDO"}
    bake_mode: EnumProperty(
        name="Bake Mode",
        description="Choose a new action copy or replace bone keys in the current action within the bake range",
        items=(
            ('NEW', 'Bake to New Action', 'Bake into a private action copy and preserve the original action'),
            ('OVERWRITE', 'Overwrite Current Action', 'Overwrite bone keys in the active action within the range; preserve other channels and outside keys, or create an action if none is active'),
        ),
        default='NEW',
    )

    @classmethod
    def poll(cls, context):
        armature = get_armature(context.scene)
        return bool(armature and armature.data.hhp_ragdoll_built)

    def invoke(self, context, _event):
        settings = context.scene.hhp_rd_settings
        settings.bake_start = context.scene.frame_start
        settings.bake_end = context.scene.frame_end
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        settings = context.scene.hhp_rd_settings
        col = self.layout.column(align=True)
        mode = col.row(align=True)
        mode.prop(self, 'bake_mode', expand=True)
        frame_range = col.row(align=True)
        frame_range.prop(settings, "bake_start")
        frame_range.prop(settings, "bake_end")
        col.prop(settings, "bake_step")
        col.label(text=("Original action is preserved" if self.bake_mode == 'NEW'
                        else "Keys in this range replace the current action"), icon="ACTION")

    def execute(self, context):
        scene = context.scene
        settings = scene.hhp_rd_settings
        armature = get_armature(scene)
        start, end = settings.bake_start, settings.bake_end
        step = max(1, settings.bake_step)
        if start > end or start < scene.frame_start:
            self.report({"ERROR"}, "Choose a range beginning at or after the scene start")
            return {"CANCELLED"}
        key_frame_set = set(range(start, end + 1, step)) | {end}
        key_frames = sorted(key_frame_set)
        names = transfer_bones(armature)
        if hhp_rig_version(armature) >= 5 and 'root' in armature.pose.bones:
            names.add('root')
        if not names:
            self.report({"ERROR"}, "No weighted ragdoll bones were found")
            return {"CANCELLED"}
        original_frame = scene.frame_current
        if hhp_rig_version(armature) >= 5:
            prepare_transform_driver_overrides(armature, names)
            prepare_transfer_constraints(armature, names)
        before = start - 1
        guards = {}
        root_uniform = uniform_root_bone(armature) if 'root' in names else None
        root_scale_guards = {}
        root_scale_samples = {}
        for frame in (before, end + 1):
            scene.frame_set(frame)
            guards[frame] = {name: armature.pose.bones[name].matrix_basis.copy()
                             for name in names}
            if root_uniform:
                root_scale_guards[frame] = float(root_uniform['Uniform Scale'])
        sampled = {}
        for frame in range(scene.frame_start, end + 1):
            scene.frame_set(frame)
            context.view_layer.update()
            if frame in key_frame_set:
                sampled[frame] = {name: matrix for name, matrix
                                  in sampled_pose(armature).items()
                                  if name in names}
                if 'root' in names:
                    evaluated = armature.evaluated_get(context.evaluated_depsgraph_get())
                    sampled[frame]['root'] = evaluated.pose.bones['root'].matrix.copy()
                    if root_uniform:
                        root_scale_samples[frame] = float(sampled[frame]['root'].to_scale().x)

        # Only bone animation belongs in this operation's Action. Playback
        # ownership travels as static metadata; existing state keys stay intact.
        ad = armature.animation_data_create()
        if ad.action and self.bake_mode == 'NEW':
            original = ad.action
            original.use_fake_user = True
            action = original.copy()
            action.name = original.name + " - Ragdoll Bake"
            slot_handle = ad.action_slot_handle
            ad.action = action
            ad.action_slot_handle = slot_handle
        elif ad.action is None:
            ad.action = bpy.data.actions.new("HHP Ragdoll Bone Bake")
        if ad.action_slot is None:
            ad.action_slot = ad.action.slots.new(id_type='OBJECT', name=armature.name)
        tag_native_bake_action(armature, names, start, end)
        if armature.get('hhp_rigify_built'):
            armature['hhp_rigify_active'] = 0
        for path, value in (("hhp_ragdoll_enabled", False),
                            ("hhp_ragdoll_bake_enabled", False),
                            ("hhp_ragdoll_keys_enabled", True)):
            setattr(armature.data, path, value)
        armature.data.hhp_ragdoll_pose_override = False
        remove_bone_keys_in_range(armature, names, start, end)
        if root_uniform:
            scale_path = root_uniform.path_from_id() + '["Uniform Scale"]'
            remove_keys_in_range(armature, scale_path, start, end)
            for frame in key_frames:
                root_uniform['Uniform Scale'] = root_scale_samples[frame]
                root_uniform.keyframe_insert('["Uniform Scale"]', frame=frame)
            for frame, value in root_scale_guards.items():
                root_uniform['Uniform Scale'] = value
                root_uniform.keyframe_insert('["Uniform Scale"]', frame=frame)
        for frame in key_frames:
            scene.frame_set(frame)
            sync_portable_action_playback(armature, frame)
            context.view_layer.update()
            key_pose_on_bones(armature, sampled[frame], frame)
        for frame, bases in guards.items():
            key_guard_basis(armature, bases, frame)
        armature.data["hhp_rd_action_bake_range"] = [start, end]
        armature.data['hhp_rd_action_bake_version'] = 2
        if "hhp_rd_pose_before_copy" in armature.data:
            del armature.data["hhp_rd_pose_before_copy"]
        if 'hhp_rd_rig_before_copy' in armature.data:
            del armature.data['hhp_rd_rig_before_copy']
        scene.frame_set(original_frame)
        self.report({"INFO"}, f"Baked {len(key_frames)} poses across frames {start}-{end} onto {len(names)} bones (step {step})")
        return {"FINISHED"}


class HHP_RD_OT_clear_bake(Operator):
    """Remove addon-created control curves, action-baked bone keys, and baked-playback keys."""

    bl_idname = "hhp_rd.clear_bake"
    bl_label = "Clear Ragdoll Bake"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        armature = get_armature(context.scene)
        if armature is None:
            return {"CANCELLED"}
        from ..modules import hhp_rigify
        hhp_rigify._resume_preview_action(armature)
        data = armature.data
        legacy_state_keys = data.get('hhp_rd_action_bake_version', 1) < 2
        bake_range = data.get("hhp_rd_action_bake_range")
        if bake_range:
            start, end = int(bake_range[0]), int(bake_range[1])
            action = armature.animation_data.action if armature.animation_data else None
            metadata = native_bake_metadata(action, armature.animation_data.action_slot_handle)
            if metadata.get('version') == 2:
                legacy_state_keys = False
                baked_names = metadata.get('bones', [])
                if metadata.get('playback') == 'CONTROLS':
                    baked_names = [control_name(name) for name in baked_names]
            else:
                baked_names = controlled_bones(armature)
            if metadata:
                ranges = []
                for first, last in metadata['ranges']:
                    if first < start:
                        ranges.append([first, min(last, start - 1)])
                    if last > end:
                        ranges.append([max(first, end + 1), last])
                metadata['ranges'] = ranges
                if metadata['version'] == 2:
                    _store_native_bake_metadata(armature, metadata if ranges else None)
                elif ranges:
                    action[NATIVE_BAKE_ACTION_KEY] = json.dumps(metadata)
                else:
                    del action[NATIVE_BAKE_ACTION_KEY]
                if metadata['version'] == 1:
                    remove_keys_in_range(armature, '["' + NATIVE_BAKE_ACTION_KEY + '"]', start - 1, end + 1)
                restore_portable_action_playback(armature)
            if legacy_state_keys and 'hhp_rd_rig_mode_before_bake' in data:
                restore_control_rig_bake_mode(armature, start, end, context.scene.frame_current)
            remove_bone_keys_in_range(
                armature, baked_names,
                max(context.scene.frame_start, start - 1), end + 1)
            root = uniform_root_bone(armature)
            if not legacy_state_keys and root and 'root' in baked_names:
                remove_keys_in_range(armature, root.path_from_id() + '["Uniform Scale"]',
                                     start - 1, end + 1)
            del data["hhp_rd_action_bake_range"]
            if 'hhp_rd_action_bake_version' in data:
                del data['hhp_rd_action_bake_version']
        animation = armature.animation_data
        if legacy_state_keys and animation and animation.action and animation.action_slot:
            action = animation.action
            if action.layers and action.layers[0].strips:
                bag = action.layers[0].strips[0].channelbag(
                    animation.action_slot)
                if bag:
                    for fcurve in list(bag.fcurves):
                        if f'pose.bones["{CTRL_PREFIX}' in fcurve.data_path:
                            bag.fcurves.remove(fcurve)
        if legacy_state_keys and data.animation_data and data.animation_data.action:
            action = data.animation_data.action
            slot = data.animation_data.action_slot
            if slot and action.layers and action.layers[0].strips:
                bag = action.layers[0].strips[0].channelbag(slot)
                if bag:
                    for fcurve in list(bag.fcurves):
                        if fcurve.data_path in (
                                "hhp_ragdoll_bake_enabled",
                                "hhp_ragdoll_keys_enabled"):
                            bag.fcurves.remove(fcurve)
        data.hhp_ragdoll_bake_enabled = False
        data.hhp_ragdoll_keys_enabled = False
        data.hhp_ragdoll_pose_override = False
        self.report({"INFO"}, "Ragdoll bake keys and curves cleared")
        return {"FINISHED"}


def make_mesh_single_user(obj):
    """Give an object private mesh data so transforms can be applied safely."""
    if obj.data.users > 1:
        obj.data = obj.data.copy()


class HHP_RD_OT_assign_active_rigid_body(Operator):
    """Apply transforms and assign active convex-hull rigid-body physics to every selected mesh."""

    bl_idname = "hhp_rd.assign_active_rigid_body"
    bl_label = "Assign Active"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(
            obj.type == "MESH" and obj.mode == "OBJECT"
            for obj in context.selected_objects
        )

    def execute(self, context):
        objects = [
            obj for obj in context.selected_objects
            if obj.type == "MESH" and obj.mode == "OBJECT"
        ]
        for obj in objects:
            make_mesh_single_user(obj)
            with context.temp_override(
                    object=obj,
                    active_object=obj,
                    selected_objects=[obj],
                    selected_editable_objects=[obj]):
                bpy.ops.object.transform_apply(
                    location=True, rotation=True, scale=True)
                bpy.ops.object.origin_set(
                    type="ORIGIN_GEOMETRY", center="MEDIAN")
                if obj.rigid_body is not None:
                    bpy.ops.rigidbody.object_remove()
                bpy.ops.rigidbody.object_add()
                obj.rigid_body.type = "ACTIVE"
                obj.rigid_body.collision_shape = "CONVEX_HULL"
                obj.rigid_body.mesh_source = "BASE"
        self.report({"INFO"}, f"Assigned active rigid bodies to {len(objects)} objects")
        return {"FINISHED"}


class HHP_RD_OT_assign_passive_rigid_body(Operator):
    """Apply transforms and assign passive kinematic rigid-body physics to every selected mesh."""

    bl_idname = "hhp_rd.assign_passive_rigid_body"
    bl_label = "Assign Passive"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(
            obj.type == "MESH" and obj.mode == "OBJECT"
            for obj in context.selected_objects
        )

    def execute(self, context):
        objects = [
            obj for obj in context.selected_objects
            if obj.type == "MESH" and obj.mode == "OBJECT"
        ]
        for obj in objects:
            make_mesh_single_user(obj)
            with context.temp_override(
                    object=obj,
                    active_object=obj,
                    selected_objects=[obj],
                    selected_editable_objects=[obj]):
                bpy.ops.object.transform_apply(
                    location=True, rotation=True, scale=True)
                bpy.ops.object.origin_set(
                    type="ORIGIN_GEOMETRY", center="MEDIAN")
                if obj.rigid_body is not None:
                    bpy.ops.rigidbody.object_remove()
                bpy.ops.rigidbody.object_add()
                obj.rigid_body.type = "PASSIVE"
                obj.rigid_body.kinematic = True
                obj.rigid_body.mesh_source = "BASE"
        self.report({"INFO"}, f"Assigned passive rigid bodies to {len(objects)} objects")
        return {"FINISHED"}


class HHP_RD_OT_remove_rigid_body(Operator):
    """Remove rigid-body physics from every selected object that has it."""

    bl_idname = "hhp_rd.remove_rigid_body"
    bl_label = "Remove Rigid body"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(
            obj.mode == "OBJECT" and obj.rigid_body is not None
            for obj in context.selected_objects
        )

    def execute(self, context):
        objects = [
            obj for obj in context.selected_objects
            if obj.mode == "OBJECT" and obj.rigid_body is not None
        ]
        for obj in objects:
            with context.temp_override(
                    object=obj,
                    active_object=obj,
                    selected_objects=[obj],
                    selected_editable_objects=[obj]):
                bpy.ops.rigidbody.object_remove()
        self.report({"INFO"}, f"Removed rigid bodies from {len(objects)} objects")
        return {"FINISHED"}


class HHP_RD_OT_select_rigid_bodies(Operator):
    """Select every rigid-body object of the chosen active or passive type."""

    bl_idname = "hhp_rd.select_rigid_bodies"
    bl_label = "Select Rigid Bodies"
    bl_options = {"REGISTER", "UNDO"}

    body_type: EnumProperty(
        name="Rigid Body Type",
        items=(
            ("ACTIVE", "Active", "Select all active rigid bodies"),
            ("PASSIVE", "Passive", "Select all passive rigid bodies"),
        ),
        default="ACTIVE",
        options={"HIDDEN"},
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT"

    def execute(self, context):
        ragdoll_collection = bpy.data.collections.get(COLLECTION_NAME)
        targets = [
            obj for obj in context.view_layer.objects
            if obj.rigid_body is not None
            and obj.rigid_body.type == self.body_type
            and (
                ragdoll_collection is None
                or not collection_contains(ragdoll_collection, obj)
            )
        ]
        if not targets:
            self.report(
                {"WARNING"}, f"No {self.body_type.lower()} rigid bodies found")
            return {"CANCELLED"}

        bpy.ops.object.select_all(action="DESELECT")
        selected = []
        for obj in targets:
            try:
                obj.select_set(True)
                selected.append(obj)
            except RuntimeError:
                continue
        if selected:
            context.view_layer.objects.active = selected[0]
        self.report(
            {"INFO"},
            f"Selected {len(selected)} {self.body_type.lower()} rigid bodies")
        return {"FINISHED"}


def rigid_body_point_cache(scene):
    world = scene.rigidbody_world
    return world.point_cache if world is not None else None


def restore_cache_end_if_unbaked(scene, cache=None):
    """Restore the simulation end saved before Current Cache to Bake."""
    if BAKE_END_STATE_KEY not in scene:
        return
    if cache is None:
        cache = rigid_body_point_cache(scene)
    if cache is not None and cache.is_baked:
        return
    if cache is not None:
        cache.frame_end = int(scene[BAKE_END_STATE_KEY])
    del scene[BAKE_END_STATE_KEY]


def bake_current_cache(scene, context):
    """Bake through the current frame while preserving the previous end."""
    global _AUTO_BAKING
    cache = rigid_body_point_cache(scene)
    if (cache is None or cache.is_baked or _AUTO_BAKING
            or scene.frame_current < cache.frame_start):
        return False
    if BAKE_END_STATE_KEY not in scene:
        scene[BAKE_END_STATE_KEY] = int(cache.frame_end)
    cache.frame_end = scene.frame_current
    _AUTO_BAKING = True
    succeeded = False
    try:
        with context.temp_override(scene=scene, point_cache=cache):
            result = bpy.ops.ptcache.bake_from_cache()
        succeeded = "FINISHED" in result
        if succeeded:
            enforce_baked_part_toggles(scene)
        return succeeded
    finally:
        if not succeeded:
            restore_cache_end_if_unbaked(scene, cache)
        _AUTO_BAKING = False


class HHP_RD_OT_bake_current_cache(Operator):
    """Bake the current rigid-body cache through this frame; deleting the bake restores the previous simulation end."""

    bl_idname = "hhp_rd.bake_current_cache"
    bl_label = "Current Cache to Bake"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        cache = rigid_body_point_cache(context.scene)
        return cache is not None and not cache.is_baked

    def execute(self, context):
        if not bake_current_cache(context.scene, context):
            self.report({"ERROR"}, "Current rigid-body cache could not be baked")
            return {"CANCELLED"}
        self.report({"INFO"}, "Current rigid-body cache converted to a bake")
        return {"FINISHED"}


class HHP_RD_OT_update_cache_to_scene(Operator):
    """Pause playback, match the simulation range, flush its cache, and refresh body positions."""

    bl_idname = "hhp_rd.update_cache_to_scene"
    bl_label = "Rebind Ragdoll"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        cache = rigid_body_point_cache(context.scene)
        return cache is not None and not cache.is_baked

    def execute(self, context):
        if context.screen is not None and context.screen.is_animation_playing:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        scene = context.scene
        cache = rigid_body_point_cache(scene)
        scene.frame_set(scene.frame_start)
        cache.frame_start = scene.frame_start
        cache.frame_end = scene.frame_end
        settings = scene.hhp_rd_settings
        original_bounciness = settings.bounciness
        try:
            settings.bounciness = 1.0
            context.view_layer.update()
        finally:
            settings.bounciness = original_bounciness
            context.view_layer.update()
        armature = get_armature(scene)
        if armature is not None:
            original_ragdoll = armature.data.hhp_ragdoll_enabled
            armature.data.hhp_ragdoll_enabled = not original_ragdoll
            context.view_layer.update()
            armature.data.hhp_ragdoll_enabled = original_ragdoll
            context.view_layer.update()
        self.report(
            {"INFO"},
            f"Simulation range updated to {scene.frame_start}-{scene.frame_end}")
        return {"FINISHED"}


class HHP_RD_OT_delete_cache_bake(Operator):
    """Delete the baked rigid-body simulation cache."""

    bl_idname = "hhp_rd.delete_cache_bake"
    bl_label = "Delete Bake"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        cache = rigid_body_point_cache(context.scene)
        return cache is not None and cache.is_baked

    def execute(self, context):
        cache = rigid_body_point_cache(context.scene)
        with context.temp_override(point_cache=cache):
            bpy.ops.ptcache.free_bake()
        enforce_baked_part_toggles(context.scene)
        self.report({"INFO"}, "Rigid-body simulation bake deleted")
        return {"FINISHED"}


def draw_ragdoll_tools(layout, context):
    """Draw ragdoll controls inside the host addon's experimental UI."""
    settings = context.scene.hhp_rd_settings
    setup = layout.column(align=True)
    setup.operator("hhp_rd.build", icon="PHYSICS")
    armature = get_armature(context.scene)
    if armature is None:
        armature, _mesh = auto_hhp_character(context)
    built = bool(armature and armature.data.hhp_ragdoll_built)
    finger_mode, toe_mode = (generation_modes(armature)
                             if built else ("SINGLE", "SINGLE"))
    if not built:
        layout.label(text="Choose settings, then build the ragdoll", icon="INFO")
    layout.separator()
    if armature is not None:
        ragdoll_controls = layout.column(align=True)
        ragdoll_controls.enabled = built
        toggle = ragdoll_controls.row(align=True)
        toggle.scale_y = 1.5
        toggle.prop(
            context.scene, "hhp_rd_testing_floor",
            text="", icon="MESH_PLANE", toggle=True)
        toggle.prop(
            armature.data, "hhp_ragdoll_enabled",
            text="Ragdoll", toggle=True, icon="PHYSICS")
        toggle.prop(
            context.scene, "hhp_rd_auto_bake",
            text="", icon="REC", toggle=True)
        cache = rigid_body_point_cache(context.scene)
        cache_is_baked = bool(cache and cache.is_baked)
        parts_enabled = (
            armature.data.hhp_ragdoll_enabled and not cache_is_baked)
        expected_segments = compose_segments(finger_mode, toe_mode, armature)
        finger_segments = {
            name for name in expected_segments
            if SEGMENT_PART_PROPERTIES.get(name) in {
                "hhp_ragdoll_fingers_l_enabled",
                "hhp_ragdoll_fingers_r_enabled",
            }
        }
        finger_ragdoll_built = bool(finger_segments) and all(
            bpy.data.objects.get(BODY_PREFIX + name) is not None
            for name in finger_segments
        )
        part_rows = [
            (PART_TOGGLES[0], PART_TOGGLES[1]),
            (PART_TOGGLES[2], PART_TOGGLES[3]),
            (PART_TOGGLES[4], PART_TOGGLES[5]),
            (PART_TOGGLES[6], PART_TOGGLES[7]),
            (PART_TOGGLES[10],),
        ]
        if finger_mode != "SINGLE":
            part_rows.insert(2, (PART_TOGGLES[8], PART_TOGGLES[9]))
        for entries in part_rows:
            row = ragdoll_controls.row(align=True)
            is_finger_row = (
                entries[0][0] == "hhp_ragdoll_fingers_l_enabled")
            row.enabled = (
                parts_enabled
                and (
                    not is_finger_row
                    or (finger_mode != "SINGLE" and finger_ragdoll_built)
                )
            )
            for property_name, label, _segments, icon in entries:
                row.prop(
                    armature.data,
                    property_name,
                    text=label,
                    icon=icon,
                    toggle=True,
                )
        if finger_mode == "LEGACY" or (
                finger_mode != "SINGLE" and not finger_ragdoll_built):
            ragdoll_controls.label(
                text="Rebuild Ragdoll for the selected finger method",
                icon="INFO",
            )
        controls = layout.column(align=True)
        controls.enabled = built
        if cache is not None:
            cache_range = controls.row(align=True)
            cache_range.enabled = not cache.is_baked
            cache_range.prop(cache, "frame_start", text="Simulation Start")
            cache_range.prop(cache, "frame_end", text="Simulation End")
        cache_actions = controls.row(align=True)
        cache_actions.operator("hhp_rd.bake_current_cache", icon="REC")
        cache_actions.operator("hhp_rd.update_cache_to_scene", icon="FILE_REFRESH")
        delete_bake = cache_actions.row(align=True)
        delete_bake.alert = cache_is_baked
        delete_bake.operator("hhp_rd.delete_cache_bake", icon="TRASH")
        controls.separator()
        handoff = controls.column(align=True)
        handoff.operator("hhp_rd.activate_here", icon="PLAY")
        handoff.operator("hhp_rd.return_here", icon="ARMATURE_DATA")
        ragdoll_layer = ragdoll_layer_collection(context)
        collection_hidden = (
            ragdoll_layer is None or ragdoll_layer.hide_viewport)
        handoff.operator("hhp_rd.copy_pose", icon="COPYDOWN")
        handoff.operator("hhp_rd.bake_action", icon="ACTION")
        handoff.operator(
            "hhp_rd.toggle_helpers",
            text=("Show Ragdoll Collection"
                  if collection_hidden
                  else "Hide Ragdoll Collection"),
            icon="HIDE_ON" if collection_hidden else "HIDE_OFF",
        )
    layout.separator()
    layout.label(text="Tuning", icon="OPTIONS")
    tuning = layout.column(align=True)
    tuning.prop(settings, "preset", text="")
    tuning_columns = tuning.row(align=True)
    body_tuning = tuning_columns.column(align=True)
    body_tuning.prop(settings, "stiffness")
    body_tuning.prop(settings, "damping")
    body_tuning.prop(settings, "weight")
    body_tuning.prop(settings, "speed")
    body_tuning.prop(settings, "friction")
    body_tuning.prop(settings, "bounciness")
    detail_tuning = tuning_columns.column(align=True)
    if not built or finger_mode != "SINGLE":
        detail_tuning.prop(settings, "finger_stiffness")
        detail_tuning.prop(settings, "finger_bending")
    detail_tuning.prop(settings, "toe_stiffness")
    detail_tuning.prop(settings, "toe_rotation")
    if not built or finger_mode != "SINGLE":
        detail_tuning.prop(settings, "finger_natural_curling")
    layout.label(text="Rigid Body World", icon="WORLD")
    rigid_body_row = layout.row(align=True)
    select_active = rigid_body_row.operator(
        "hhp_rd.select_rigid_bodies", text="", icon="RESTRICT_SELECT_OFF")
    select_active.body_type = "ACTIVE"
    rigid_body_row.operator(
        "hhp_rd.assign_active_rigid_body", icon="PHYSICS")
    select_passive = rigid_body_row.operator(
        "hhp_rd.select_rigid_bodies", text="", icon="RESTRICT_SELECT_OFF")
    select_passive.body_type = "PASSIVE"
    rigid_body_row.operator(
        "hhp_rd.assign_passive_rigid_body", icon="MESH_CUBE")
    rigid_body_row.operator("hhp_rd.remove_rigid_body", icon="X")


@persistent
def hhp_rd_frame_pre(scene, _depsgraph=None):
    armature = get_armature(scene)
    if armature:
        _mirror_state_properties(armature.original.data, frame=scene.frame_current)
    enforce_baked_part_toggles(scene)


@persistent
def hhp_rd_frame_post(scene, _depsgraph=None):
    enforce_baked_part_toggles(scene)
    sync_bodies(scene)
    cache = rigid_body_point_cache(scene)
    playing_window = physics_autobake.playing_window(scene)
    if (playing_window is not None
            and scene.hhp_rd_auto_bake
            and cache is not None
            and scene.frame_current == cache.frame_end):
        armature = get_armature(scene)
        if armature is not None and getattr(
                armature.data, "hhp_ragdoll_built", False):
            try:
                if bake_current_cache(scene, bpy.context):
                    # Set only after a successful ragdoll auto-bake. The manual
                    # Current Cache to Bake operator intentionally does not do this.
                    scene.sync_mode = 'AUDIO_SYNC'
                    physics_autobake.resume_playback_after_bake(playing_window)
            except RuntimeError as exc:
                print(f"HHP ragdoll auto bake failed: {exc}")


@persistent
def hhp_rd_load_post(_dummy):
    if bpy.context.view_layer is not None:
        heal_ragdoll_collection_visibility(bpy.context)
    for scene in bpy.data.scenes:
        enforce_baked_part_toggles(scene)
        armature = get_armature(scene)
        if armature is not None:
            ensure_part_toggle_drivers(armature)
        sync_bodies(scene)


@persistent
def hhp_rd_depsgraph_post(scene, _depsgraph=None):
    enforce_baked_part_toggles(scene)
    armature = get_armature(scene)
    if armature and armature.get('hhp_rigify_built'):
        sync_transform_driver_overrides(armature.original)


def set_handlers_enabled(enabled):
    """Run ragdoll frame/load handlers only while Experimental is enabled."""
    frame_pre_handlers = bpy.app.handlers.frame_change_pre
    frame_handlers = bpy.app.handlers.frame_change_post
    load_handlers = bpy.app.handlers.load_post
    depsgraph_handlers = bpy.app.handlers.depsgraph_update_post
    if enabled:
        if hhp_rd_frame_pre not in frame_pre_handlers:
            frame_pre_handlers.append(hhp_rd_frame_pre)
        if hhp_rd_frame_post not in frame_handlers:
            frame_handlers.append(hhp_rd_frame_post)
        if hhp_rd_load_post not in load_handlers:
            load_handlers.append(hhp_rd_load_post)
        if hhp_rd_depsgraph_post not in depsgraph_handlers:
            depsgraph_handlers.append(hhp_rd_depsgraph_post)
    else:
        if hhp_rd_frame_pre in frame_pre_handlers:
            frame_pre_handlers.remove(hhp_rd_frame_pre)
        if hhp_rd_frame_post in frame_handlers:
            frame_handlers.remove(hhp_rd_frame_post)
        if hhp_rd_load_post in load_handlers:
            load_handlers.remove(hhp_rd_load_post)
        if hhp_rd_depsgraph_post in depsgraph_handlers:
            depsgraph_handlers.remove(hhp_rd_depsgraph_post)


classes = (
    HHP_RD_Settings,
    HHP_RD_OT_build,
    HHP_RD_OT_activate_here,
    HHP_RD_OT_return_here,
    HHP_RD_OT_toggle_helpers,
    HHP_RD_OT_copy_pose,
    HHP_RD_OT_bake_action,
    HHP_RD_OT_assign_active_rigid_body,
    HHP_RD_OT_assign_passive_rigid_body,
    HHP_RD_OT_remove_rigid_body,
    HHP_RD_OT_select_rigid_bodies,
    HHP_RD_OT_bake_current_cache,
    HHP_RD_OT_update_cache_to_scene,
    HHP_RD_OT_delete_cache_bake,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.hhp_rd_settings = PointerProperty(type=HHP_RD_Settings)
    bpy.types.Scene.hhp_rd_testing_floor = BoolProperty(
        name="Testing Floor",
        default=False,
        update=_testing_floor_update,
        description=(
            "Create or remove a temporary passive rigid-body floor beneath "
            "the character for testing ragdoll physics"
        ),
    )
    bpy.types.Scene.hhp_rd_auto_bake = BoolProperty(
        name="Auto Bake",
        default=False,
        description=(
            "Automatically convert the current rigid-body cache to a bake "
            "when playback reaches the simulation's end frame"
        ),
    )
    bpy.types.Armature.hhp_ragdoll_enabled = BoolProperty(
        name="Ragdoll",
        default=False,
        update=_ragdoll_enabled_update,
        description=(
            "Release the fitted rigid bodies from the evaluated animation "
            "and drive the real armature with physics"
        ),
    )
    for property_name, label, segments, _icon in PART_TOGGLES:
        setattr(
            bpy.types.Armature,
            property_name,
            BoolProperty(
                name=label,
                default=True,
                update=_part_enabled_update(property_name, segments),
                description=(
                    (
                        "Include the torso, upper and lower arms, thighs, "
                        "and shins in ragdoll physics"
                    )
                    if property_name == "hhp_ragdoll_followers_enabled"
                    else (
                        f"Include the {label.lower()} in ragdoll physics; "
                        "turn off to keep this part controlled by animation"
                    )
                ),
            ),
        )
    bpy.types.Armature.hhp_ragdoll_bake_enabled = BoolProperty(
        name="Baked Control Playback",
        default=False,
        update=_state_property_update,
        description=(
            "Drive deform bones from editable ragdoll bake controls "
            "instead of the normal animation controls"
        ),
    )
    bpy.types.Armature.hhp_ragdoll_keys_enabled = BoolProperty(
        name="Keyframed Ragdoll",
        default=False,
        update=_state_property_update,
        description=(
            "Drive deform bones from ragdoll keyframes baked or pasted "
            "directly onto them, muting the normal animation controls"
        ),
    )
    bpy.types.Armature.hhp_ragdoll_pose_override = BoolProperty(
        name="Ragdoll Pose Override",
        default=False,
        update=_state_property_update,
        options=set(),
        description=(
            "Show a pasted or hand-tweaked ragdoll pose exactly by muting "
            "IK, animation, and physics constraints. Never keyframed; "
            "turn off to return to normal animation"
        ),
    )
    bpy.types.Armature.hhp_ragdoll_built = BoolProperty(
        name="HHP Ragdoll Built",
        default=False,
        options={"HIDDEN"},
    )
    if not bpy.app.timers.is_registered(migrate_loaded_ragdolls):
        bpy.app.timers.register(migrate_loaded_ragdolls, first_interval=0.0)


def unregister():
    set_handlers_enabled(False)
    if bpy.app.timers.is_registered(migrate_loaded_ragdolls):
        bpy.app.timers.unregister(migrate_loaded_ragdolls)
    for attr in (
        "hhp_ragdoll_built",
        "hhp_ragdoll_pose_override",
        "hhp_ragdoll_keys_enabled",
        "hhp_ragdoll_bake_enabled",
        *(item[0] for item in reversed(PART_TOGGLES)),
        "hhp_ragdoll_enabled",
    ):
        if hasattr(bpy.types.Armature, attr):
            delattr(bpy.types.Armature, attr)
    if hasattr(bpy.types.Scene, "hhp_rd_settings"):
        del bpy.types.Scene.hhp_rd_settings
    if hasattr(bpy.types.Scene, "hhp_rd_testing_floor"):
        del bpy.types.Scene.hhp_rd_testing_floor
    if hasattr(bpy.types.Scene, "hhp_rd_auto_bake"):
        del bpy.types.Scene.hhp_rd_auto_bake
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
