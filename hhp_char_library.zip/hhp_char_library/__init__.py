bl_info = {
    "name": "(BS) Custom | HHP Char Library",
    "author": "Bulging Senpai",
    "description": "Bulging senpai's character library",
    "blender": (3, 0, 0),
    "version": (1, 9, 6),
    "location": "",
    "warning": "",
    "doc_url": "https://www.patreon.com/posts/character-addon-113747469",
    "tracker_url": "",
    "category": "3D View"
}

# -----------------------------------------------------------------------------------------
#   Update URLs
#   Make sure these URLs actually exist in your repo. For example, you must have:
#   - hhp_char_library.zip committed in the repo
#   - version.txt with "1.6.5" or higher to test updates, etc.
# -----------------------------------------------------------------------------------------
UPDATE_ZIP_URL = "https://github.com/BS-Creative/hhp_char_library/raw/main/hhp_char_library.zip"
VERSION_URL = "https://raw.githubusercontent.com/BS-Creative/hhp_char_library/main/version.txt"
GET_CHARACTERS_URL = "https://www.patreon.com/collection/785672?view=condensed"
NEWS_URL = "https://raw.githubusercontent.com/BS-Creative/hhp_char_library/main/news.txt"
HELP_INSTALLATION_URL = "https://raw.githubusercontent.com/BS-Creative/hhp_char_library/refs/heads/main/Tut%20image_C.jpg"
BASICS_URL = "https://www.patreon.com/posts/hhp-basics-120215078"
ALL_TUTORIALS_URL = "https://www.patreon.com/collection/632163?view=expanded"

from .Proxies_HHP import register as proxies_register
from .Proxies_HHP import unregister as proxies_unregister
from . import Customize_HHP
from . import Optimize_HHP
from . import Animation_HHP
from . import Scene_HHP
from . import Dynamics_HHP
from . import Creator_Tools_HHP
from .modules import anim_preview
from .modules import shader_sss_converter
from .modules import import_facs_json
from .modules import facs_shapekey_editor
from .modules import quick_menu
from .modules import dynamic_pressure_canvas, dynamic_pressure_brush, rebind_dynamic_paint  # Added rebind module

import bpy
import os
import bpy.utils.previews
from bpy.types import (
    Operator,
    Panel,
    AddonPreferences,
    PropertyGroup,
    UIList
)
from bpy.props import (
    StringProperty,
    CollectionProperty,
    IntProperty,
    BoolProperty,
    FloatProperty,
    EnumProperty
)

import time
import threading

# -----------------------------------------------------------------------------------------
#   Global variable to store custom icons
# -----------------------------------------------------------------------------------------
custom_icons = None

# -----------------------------------------------------------------------------------------
#   Addon Preferences
# -----------------------------------------------------------------------------------------
class DirectoryItem(PropertyGroup):
    path: StringProperty(
        name="Path",
        subtype='DIR_PATH',
        default=""
    )

class CollectionNameItem(PropertyGroup):
    name: StringProperty(
        name="Collection Name",
        default="Char (HHP)"
    )

class HHPCharLibraryPreferences(AddonPreferences):
    bl_idname = __name__

    # Mode selector for Character/Scene
    mode: EnumProperty(
        name="Mode",
        items=[
            ('CHARACTER', "Character", "Character mode"),
            ('SCENE', "Scene", "Scene mode")
        ],
        default='CHARACTER',
        description="Switch between Character and Scene modes"
    )

    # Character mode settings
    directories: CollectionProperty(type=DirectoryItem)
    active_directory_index: IntProperty()

    collection_names: CollectionProperty(type=CollectionNameItem)
    active_collection_index: IntProperty()
    
    force_recursive_search_char: BoolProperty(
        name="Forced recursive search (Not recommended)",
        default=False,
        description="Recursively search all subdirectories for blend files. This will create an unorganized list showing all blend files within directories. Only use as a last resort."
    )

    # Scene mode settings
    scene_directories: CollectionProperty(type=DirectoryItem)
    active_scene_directory_index: IntProperty()

    scene_collection_names: CollectionProperty(type=CollectionNameItem)
    active_scene_collection_index: IntProperty()
    
    force_recursive_search: BoolProperty(
        name="Forced recursive search (Not recommended)",
        default=False,
        description="Recursively search all subdirectories for blend files. This will create an unorganized list showing all blend files within directories. Only use as a last resort."
    )

    auto_update_enabled: BoolProperty(
        name="Auto Update",
        default=True,
        description="Enable automatic addon update once on Blender startup"
    )

    # Removed the old update_frequency / last_update_check to simplify logic

    update_available: BoolProperty(
        name="Update Available",
        default=False,
        description="Is an update available"
    )

    debug_mode: BoolProperty(
        name="Debug mode / Dev extras",
        default=False,
        description="Enable additional debugging and developer extras"
    )

    def draw(self, context):
        layout = self.layout
        
        # Mode selector
        row = layout.row(align=True)
        row.prop(self, "mode", expand=True)
        
        layout.separator()
        
        # Initialize scene directories and collection names if empty
        # Removed automatic addition of a directory slot
        # if self.mode == 'SCENE' and len(self.scene_directories) == 0:
        #     # Add an empty directory slot
        #     item = self.scene_directories.add()
        #     item.path = ""
        
        # Add default collection name
        # Removed automatic addition of a collection name slot
        # if self.mode == 'SCENE' and len(self.scene_collection_names) == 0:
        #     item = self.scene_collection_names.add()
        #     item.name = "Scene (HHP)"
        
        if self.mode == 'CHARACTER':
            # Character Mode UI
            dir_row = layout.row()
            dir_row.label(text="Character Directories:")
            sub = dir_row.row()
            sub.alignment = 'RIGHT'
            sub.prop(self, "force_recursive_search_char")
            
            # Directories UI
            row = layout.row()
            row.template_list(
                "HHP_UL_Directories", "",
                self, "directories",
                self, "active_directory_index"
            )

            col = row.column(align=True)
            col.operator("hhp.add_directory", icon='ADD', text="")
            col.operator("hhp.remove_directory", icon='REMOVE', text="")

            layout.label(text="Collection Names to Append:")
            row = layout.row()
            row.template_list(
                "HHP_UL_CollectionNames", "",
                self, "collection_names",
                self, "active_collection_index"
            )

            col = row.column(align=True)
            col.operator("hhp.add_collection_name", icon='ADD', text="")
            col.operator("hhp.remove_collection_name", icon='REMOVE', text="")
        else:
            # Scene Mode UI
            dir_row = layout.row()
            dir_row.label(text="Scene Directories:")
            sub = dir_row.row()
            sub.alignment = 'RIGHT'
            sub.prop(self, "force_recursive_search")
            
            # Directories UI
            row = layout.row()
            row.template_list(
                "HHP_UL_Directories", "",
                self, "scene_directories",
                self, "active_scene_directory_index"
            )

            col = row.column(align=True)
            col.operator("hhp.add_scene_directory", icon='ADD', text="")
            col.operator("hhp.remove_scene_directory", icon='REMOVE', text="")

            layout.label(text="Scene Collection Names to Append:")
            row = layout.row()
            row.template_list(
                "HHP_UL_CollectionNames", "",
                self, "scene_collection_names",
                self, "active_scene_collection_index"
            )

            col = row.column(align=True)
            col.operator("hhp.add_scene_collection_name", icon='ADD', text="")
            col.operator("hhp.remove_scene_collection_name", icon='REMOVE', text="")
            
        layout.separator()
        layout.label(text="Update Options:")
        layout.prop(self, "auto_update_enabled")

        # Manual check button
        layout.operator("hhp.check_for_update", text="Check for Update")

        # "Update to latest version" appears if update_available is True
        if self.update_available:
            layout.operator("hhp.update_to_latest_version", text="Update to Latest Version")

# -----------------------------------------------------------------------------------------
#   UI Lists
# -----------------------------------------------------------------------------------------
class HHP_UL_Directories(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.prop(item, "path", text="Directory", emboss=True)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.prop(item, "path", text="", emboss=False)

class HHP_UL_CollectionNames(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.prop(item, "name", text="Collection Name", emboss=True)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.prop(item, "name", text="", emboss=False)

# -----------------------------------------------------------------------------------------
#   Directory & Collection Name Operators
# -----------------------------------------------------------------------------------------
class HHP_OT_AddDirectory(Operator):
    bl_idname = "hhp.add_directory"
    bl_label = "Add Directory"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        new_item = preferences.directories.add()
        new_item.path = ""
        preferences.active_directory_index = len(preferences.directories) - 1
        return {'FINISHED'}

class HHP_OT_RemoveDirectory(Operator):
    bl_idname = "hhp.remove_directory"
    bl_label = "Remove Directory"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        preferences.directories.remove(preferences.active_directory_index)
        preferences.active_directory_index = min(
            max(0, preferences.active_directory_index - 1),
            len(preferences.directories) - 1
        )
        return {'FINISHED'}

class HHP_OT_AddCollectionName(Operator):
    bl_idname = "hhp.add_collection_name"
    bl_label = "Add Collection Name"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        new_item = preferences.collection_names.add()
        new_item.name = "Char (HHP)"
        preferences.active_collection_index = len(preferences.collection_names) - 1
        return {'FINISHED'}

class HHP_OT_RemoveCollectionName(Operator):
    bl_idname = "hhp.remove_collection_name"
    bl_label = "Remove Collection Name"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        preferences.collection_names.remove(preferences.active_collection_index)
        preferences.active_collection_index = min(
            max(0, preferences.active_collection_index - 1),
            len(preferences.collection_names) - 1
        )
        return {'FINISHED'}

# -----------------------------------------------------------------------------------------
#   Scene Directory & Collection Name Operators
# -----------------------------------------------------------------------------------------
class HHP_OT_AddSceneDirectory(Operator):
    bl_idname = "hhp.add_scene_directory"
    bl_label = "Add Scene Directory"
    
    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        item = prefs.scene_directories.add()
        item.path = ""
        prefs.active_scene_directory_index = len(prefs.scene_directories) - 1
        return {'FINISHED'}

class HHP_OT_RemoveSceneDirectory(Operator):
    bl_idname = "hhp.remove_scene_directory"
    bl_label = "Remove Scene Directory"
    
    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        if prefs.active_scene_directory_index >= 0 and len(prefs.scene_directories) > 0:
            prefs.scene_directories.remove(prefs.active_scene_directory_index)
            prefs.active_scene_directory_index = min(max(0, prefs.active_scene_directory_index - 1), len(prefs.scene_directories) - 1)
        return {'FINISHED'}

class HHP_OT_AddSceneCollectionName(Operator):
    bl_idname = "hhp.add_scene_collection_name"
    bl_label = "Add Scene Collection Name"
    
    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        item = prefs.scene_collection_names.add()
        item.name = "Scene (HHP)"  # Default collection name for scene
        prefs.active_scene_collection_index = len(prefs.scene_collection_names) - 1
        return {'FINISHED'}

class HHP_OT_RemoveSceneCollectionName(Operator):
    bl_idname = "hhp.remove_scene_collection_name"
    bl_label = "Remove Scene Collection Name"
    
    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        if prefs.active_scene_collection_index >= 0 and len(prefs.scene_collection_names) > 0:
            prefs.scene_collection_names.remove(prefs.active_scene_collection_index)
            prefs.active_scene_collection_index = min(max(0, prefs.active_scene_collection_index - 1), len(prefs.scene_collection_names) - 1)
        return {'FINISHED'}

# -----------------------------------------------------------------------------------------
#   Utility Functions
# -----------------------------------------------------------------------------------------
def get_most_recent_blend_files(directories):
    """Find the most recent .blend file in each top-level subfolder of the given directories.
    If recursive search is enabled, find all .blend files in the directory structure."""
    blend_files = {}
    addon_prefs = bpy.context.preferences.addons[__name__].preferences
    
    # Check if recursive search is enabled for characters - either from preferences or quick toggle
    recursive_search = getattr(addon_prefs, "force_recursive_search_char", False) or bpy.context.scene.get("char_quick_recursive_search", False)
    
    for directory in directories:
        abs_dir = bpy.path.abspath(directory.path)  # Convert relative path to an absolute path
        if os.path.isdir(abs_dir):
            if recursive_search:
                # Recursive search - find all blend files in directory structure
                for dirpath, dirnames, filenames in os.walk(abs_dir):
                    for filename in filenames:
                        if filename.endswith(".blend") and not filename.startswith("._"):
                            file_path = os.path.join(dirpath, filename)
                            try:
                                # Use only the filename without .blend extension as the key
                                key_name = filename.replace('.blend', '')
                                if key_name not in blend_files:
                                    blend_files[key_name] = file_path
                            except Exception as e:
                                print(f"Error accessing file {file_path}: {e}")
            else:
                # Standard search - only top-level subfolders
                for subfolder in os.listdir(abs_dir):
                    subfolder_path = os.path.join(abs_dir, subfolder)
                    if os.path.isdir(subfolder_path):
                        recent_file = None
                        recent_time = -1
                        for file in os.listdir(subfolder_path):
                            if file.endswith(".blend") and not file.startswith("._"):
                                file_path = os.path.join(subfolder_path, file)
                                try:
                                    file_time = os.path.getmtime(file_path)
                                    if file_time > recent_time:
                                        recent_time = file_time
                                        recent_file = file_path
                                except Exception as e:
                                    print(f"Error accessing file {file_path}: {e}")
                        if recent_file:
                            blend_files[subfolder] = recent_file
    return blend_files

def append_collections(filepath, collection_names):
    """Append the specified collections from a .blend file."""
    filepath = bpy.path.abspath(filepath)  # Convert relative path to absolute
    if not filepath:
        print("File path is empty. Please set the path in Addon Preferences.")
        return []
    appended_collections = []
    try:
        with bpy.data.libraries.load(filepath, link=False) as (data_from, data_to):
            collections_to_append = [
                citem.name for citem in collection_names
                if citem.name in data_from.collections
            ]
            data_to.collections = collections_to_append

        if data_to.collections:
            for collection in data_to.collections:
                if collection is not None:
                    bpy.context.scene.collection.children.link(collection)
                    appended_collections.append(collection)
                    bpy.ops.object.select_all(action='DESELECT')
                    for obj in collection.objects:
                        obj.select_set(True)
                    bpy.context.view_layer.objects.active = collection.objects[0]
    except Exception as e:
        print(f"Error appending collections from {filepath}: {e}")

    return appended_collections

def load_thumbnails(blend_files):
    """Load thumbnails for each subfolder's .blend file (from thumbnail.png/jpg/jpeg or the .blend itself)."""
    global custom_icons
    thumbnails = {}
    for subfolder, file_path in blend_files.items():
        try:
            blend_dir = os.path.dirname(file_path)
            
            # Check for thumbnail files in different formats
            thumbnail_found = False
            for ext in ['.png', '.jpg', '.jpeg']:
                thumbnail_path = os.path.join(blend_dir, f'thumbnail{ext}')
                if os.path.isfile(thumbnail_path):
                    thumb = custom_icons.load(file_path, thumbnail_path, 'IMAGE')
                    thumbnails[file_path] = thumb
                    thumbnail_found = True
                    break
            
            # Fall back to using the blend file itself if no thumbnail image was found
            if not thumbnail_found:
                thumb = custom_icons.load(file_path, file_path, 'BLEND')
                thumbnails[file_path] = thumb
                
        except Exception as e:
            print(f"Error loading thumbnail for {file_path}: {e}")
    return thumbnails

# -----------------------------------------------------------------------------------------
#   Property Group for Blend Files
# -----------------------------------------------------------------------------------------
class BlendFileItem(PropertyGroup):
    name: StringProperty()
    file_path: StringProperty()
    icon_id: IntProperty()

# -----------------------------------------------------------------------------------------
#   UIList for Blend Files
# -----------------------------------------------------------------------------------------
class APPEND_UL_BlendFileList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        blend_file = item
        display_name = blend_file.name.replace('.blend', '')
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.label(text=display_name, icon_value=blend_file.icon_id)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon_value=blend_file.icon_id)

# Add a property to store quick toggle state for char recursive search
class HHP_OT_ToggleCharRecursiveSearch(Operator):
    bl_idname = "hhp.toggle_char_recursive_search"
    bl_label = "Forced recursive search (Not recommended)"
    bl_description = "Recursively search all subdirectories for blend files. This will create an unorganized list showing all blend files within directories. Only use as a last resort."
    
    def execute(self, context):
        # Toggle the char_quick_recursive_search property
        context.scene.char_quick_recursive_search = not context.scene.char_quick_recursive_search
        # Refresh the list to apply the new search method
        bpy.ops.wm.append_collection_from_directory()
        return {'FINISHED'}

# -----------------------------------------------------------------------------------------
#   Main Panel
# -----------------------------------------------------------------------------------------

# Panel Mode Property Group
class HHPPanelModeProperty(bpy.types.PropertyGroup):
    selected_panel: bpy.props.EnumProperty(
        name="Panel Mode",
        description="Select which panel to display",
        items=[
            ('NONE', "None", "No panel selected", 'X', 0),
            ('PROXIES', "Physics", "Show Physics/Proxies panel", 'PHYSICS', 1),
            ('OPTIMIZE', "Optimize", "Show Optimize/Tools panel", 'MOD_REMESH', 2),
            ('CUSTOMIZE', "Customize", "Show Customize panel", 'MOD_HUE_SATURATION', 3),
            ('ANIMATION', "Animation", "Show Animation panel", 'ACTION', 4),
            ('DYNAMICS', "Dynamics / Fluids", "Show Dynamics panel", 'MOD_FLUIDSIM', 5)
        ],
        default='NONE'  # All modes off by default
    )

class CHAR_HHP_PT_Panel(Panel):
    bl_label = "Char (HHP)"
    bl_idname = "CHAR_HHP_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'
    bl_ui_units_x = 30  # Make panel wider

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__name__].preferences

        # NEW: If no directory is selected (i.e. all paths are empty),
        # display a warning message and two vertically aligned buttons.
        if not any(directory.path.strip() for directory in prefs.directories):
            warning_box = layout.box()
            warning_box.alert = True  # Make the entire box appear as an alert
            warning_box.label(text="Please select where you'd like characters stored", icon='ERROR')
            col = warning_box.column(align=True)  # Vertically aligned buttons
            btn = col.operator("wm.url_open", text="Setup guide", icon='HELP')
            btn.url = HELP_INSTALLATION_URL
            # Use our custom operator to switch to character mode in preferences
            col.operator("hhp.open_char_preferences", text="Open character preferences", icon='PREFERENCES')
            return

        # News and Help button in same row
        news_row = layout.row(align=True)
        news_row.label(text="News: " + context.window_manager.news_text, icon='WORLD')
        
        # Add spacer to push help button to the right
        news_row.separator(factor=1.0)
        
        # Add bypass toggle button (only if debug mode is enabled)
        if prefs.debug_mode:
            news_row.prop(context.scene, "char_bypass_collection", text="", icon='GHOST_ENABLED', toggle=True)
        
        # Existing recursive search toggle
        sub = news_row.row(align=True)
        sub.alignment = 'RIGHT'
        sub.prop(context.scene, "char_quick_recursive_search", text="", icon='VIEWZOOM', toggle=True)
        sub.menu("HELP_MT_menu", text="", icon='HELP')

        # Buttons
        box = layout.box()
        row = box.row(align=True)
        
        if prefs.update_available:
            row.operator("hhp.update_to_latest_version", text="Update", icon='FILE_REFRESH')
        else:
            row.operator("hhp.check_for_update", text="Check for Update")

        row.operator('wm.append_collection_from_directory', text="Refresh List")
        row.operator("wm.url_open", text="Get Characters", icon='ARMATURE_DATA').url = GET_CHARACTERS_URL

        # Blend file list
        layout.template_list(
            "APPEND_UL_BlendFileList", "",
            context.scene, "blend_file_list",
            context.scene, "blend_file_list_index"
        )

        if context.scene.blend_file_list_index >= 0 and context.scene.blend_file_list:
            blend_file = context.scene.blend_file_list[context.scene.blend_file_list_index]
            row = layout.row()
            row.template_icon(blend_file.icon_id, scale=6)

            # Top buttons box with better alignment
            button_box = layout.box()
            col = button_box.column(align=True)
            
            # Open/Append buttons in a row, now set to double tall for easier clicking
            buttons_row = col.row(align=True)
            open_button = buttons_row.operator('wm.open_blend_file', text="Open", icon='FILE_FOLDER')
            open_button.filepath = blend_file.file_path
            append_button = buttons_row.operator('wm.load_blend_file', text="Append Selected File", icon='COLLECTION_COLOR_01')
            append_button.filepath = blend_file.file_path
            
            # Add Studio and Animation buttons to the same box
            bottom_row = col.row(align=True)
            append_studio_button = bottom_row.operator(
                'wm.append_studio_from_file',
                text="Append Studio",
                icon='RENDER_STILL'
            )
            append_studio_button.filepath = blend_file.file_path
            append_actions_button = bottom_row.operator(
                'wm.append_actions_from_file',
                text="Append animation library",
                icon='ACTION'
            )
            append_actions_button.filepath = blend_file.file_path

            # Add mode selector in the same box as the append buttons
            mode_row = col.row(align=True)
            
            # Physics button with proper name in the description, clean icon
            physics_btn = mode_row.operator("hhp.toggle_panel_mode_physics", text="", icon='PHYSICS', depress=context.scene.hhp_panel_mode.selected_panel=='PROXIES')
            
            # Optimize button with proper name in the description, clean icon
            optimize_btn = mode_row.operator("hhp.toggle_panel_mode_optimize", text="", icon='MOD_REMESH', depress=context.scene.hhp_panel_mode.selected_panel=='OPTIMIZE')
            
            # Customize button with proper name in the description, clean icon
            customize_btn = mode_row.operator("hhp.toggle_panel_mode_customize", text="", icon='MOD_HUE_SATURATION', depress=context.scene.hhp_panel_mode.selected_panel=='CUSTOMIZE')
            
            # Create a sub-row for the Animation and Dynamics buttons with reduced alpha
            premium_row = mode_row.row(align=True)
            premium_row.alert = False  # This affects text color (red if True)
            premium_row.enabled = True  # Keep buttons clickable
            premium_row.active = False  # This will make them appear greyed out
            premium_row.use_property_split = False
            premium_row.use_property_decorate = False

            # Animation button with proper name in the description, clean icon
            animation_btn = premium_row.operator("hhp.toggle_panel_mode_animation", text="", icon='ACTION', depress=context.scene.hhp_panel_mode.selected_panel=='ANIMATION')
            
            # Dynamics button with proper name in the description, clean icon
            dynamics_btn = premium_row.operator("hhp.toggle_panel_mode_dynamics", text="", icon='MOD_FLUIDSIM', depress=context.scene.hhp_panel_mode.selected_panel=='DYNAMICS')
            
            # Add preset dropdown in the same row if Genesis8Female is selected
            if (context.active_object and context.active_object.type == 'MESH'
                    and context.active_object.data and "Genesis8Female" in context.active_object.data.name
                    and "Deform Proxy" not in context.active_object.name):
                mode_row.prop(context.active_object, "active_preset", text="", icon="MOD_CLOTH")

            # Add the anim preview box here, after the append buttons
            anim_preview.draw_anim_preview_box(layout, context)
            
    def draw_header(self, context):
        self.layout.label(icon='OUTLINER_OB_ARMATURE')  # Icon for Char (HHP)

# -----------------------------------------------------------------------------------------
#   Operators to Load/Append from .blend
# -----------------------------------------------------------------------------------------
class WM_OT_AppendCollectionFromDirectory(Operator):
    bl_idname = 'wm.append_collection_from_directory'
    bl_label = 'Refresh List'
    bl_description = 'Refresh the list of blend files from the directories'
    thumbnails = None

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        recent_blend_files = get_most_recent_blend_files(prefs.directories)

        global custom_icons
        custom_icons.clear()

        self.thumbnails = load_thumbnails(recent_blend_files)

        sorted_blend_files = sorted(recent_blend_files.items(), key=lambda item: item[0])

        context.scene.blend_file_list.clear()
        for subfolder, file_path in sorted_blend_files:
            icon_id = self.thumbnails[file_path].icon_id if file_path in self.thumbnails else 0
            display_name = subfolder
            new_item = context.scene.blend_file_list.add()
            new_item.name = display_name
            new_item.file_path = file_path
            new_item.icon_id = icon_id

        if context.scene.blend_file_list:
            context.scene.blend_file_list_index = 0

        return {'FINISHED'}

class WM_OT_LoadBlendFile(Operator):
    bl_idname = 'wm.load_blend_file'
    bl_label = 'Load Blend File'
    bl_description = 'Append the selected character to scene'
    filepath: StringProperty(subtype="FILE_PATH")
    append_mode: EnumProperty(
        name="Append Mode",
        items=[
            ('CHARACTER', "Character", "Append from the Char (HHP) panel"),
            ('SCENE', "Scene", "Append from the Scene (HHP) panel")
        ],
        default='CHARACTER'
    )

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        
        # NEW: Check if bypass is enabled based on append mode
        if self.append_mode == 'CHARACTER' and context.scene.char_bypass_collection:
            bpy.ops.wm.append_char_options('INVOKE_DEFAULT', filepath=self.filepath)
            return {'FINISHED'}
        elif self.append_mode == 'SCENE' and context.scene.scene_bypass_collection:
            bpy.ops.wm.append_scene_options('INVOKE_DEFAULT', filepath=self.filepath)
            return {'FINISHED'}
        
        # Existing append collections logic
        appended_collections = append_collections(self.filepath, prefs.collection_names)
        if not appended_collections:
            if self.append_mode == 'CHARACTER':
                bpy.ops.wm.append_char_options('INVOKE_DEFAULT', filepath=self.filepath)
            else:
                bpy.ops.wm.append_scene_options('INVOKE_DEFAULT', filepath=self.filepath)
            return {'FINISHED'}

        # Switch to Object mode and deselect all
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')

        # Attempt to select an Armature in the appended collections
        for collection in appended_collections:
            for obj in collection.objects:
                if obj.type == 'ARMATURE':
                    obj.select_set(True)
                    bpy.context.view_layer.objects.active = obj
                    obj.data.pose_position = 'POSE'
                    break
        return {'FINISHED'}

class WM_OT_AppendStudioFromFile(Operator):
    bl_idname = 'wm.append_studio_from_file'
    bl_label = 'Append Studio'
    bl_description = 'Append the "Studio and lights" collection from the selected file'

    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        collection_name = "Studio and lights"
        try:
            abs_filepath = bpy.path.abspath(self.filepath)
            with bpy.data.libraries.load(abs_filepath, link=False) as (data_from, data_to):
                if collection_name in data_from.collections:
                    data_to.collections = [collection_name]
                else:
                    self.report({'WARNING'}, f'Collection "{collection_name}" not found in {abs_filepath}')
                    return {'CANCELLED'}
            for collection in data_to.collections:
                if collection is not None:
                    bpy.context.scene.collection.children.link(collection)
                    # Make the collection visible, enabled in viewport and render
                    collection.hide_viewport = False
                    collection.hide_render = False
            self.report({'INFO'}, f'Appended "{collection_name}" from {abs_filepath}')
        except Exception as e:
            self.report({'ERROR'}, f'Error appending "{collection_name}": {e}')
        return {'FINISHED'}

class WM_OT_AppendActionsFromFile(Operator):
    bl_idname = 'wm.append_actions_from_file'
    bl_label = 'Append Animation Library'
    bl_description = 'Append all actions from the selected file and flag them as fake user'
    filepath: StringProperty(subtype="FILE_PATH")
    # New property for our popup checkbox
    set_fps: BoolProperty(
        name="Set Scene FPS to 60",
        description="Set scene fps to 60fps to match HHP animations base frame rate",
        default=True
    )
    
    def invoke(self, context, event):
        # Check fps; if not 60, show the popup dialog with wider width
        if context.scene.render.fps != 60:
            return context.window_manager.invoke_props_dialog(self, width=300)
        return self.execute(context)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="HHP animations are 60fps. Set scene fps to 60?")
        layout.prop(self, "set_fps", text="Set fps to 60 (recommended)")
    
    def execute(self, context):
        # If not 60fps and the user checked the option, update the scene fps to 60.
        if context.scene.render.fps != 60 and self.set_fps:
            context.scene.render.fps = 60
        try:
            abs_filepath = bpy.path.abspath(self.filepath)
            with bpy.data.libraries.load(abs_filepath, link=False) as (data_from, data_to):
                data_to.actions = data_from.actions[:]
            for action in data_to.actions:
                if action is not None:
                    action.use_fake_user = True
            self.report({'INFO'}, f'Appended {len(data_to.actions)} actions from {abs_filepath}')
        except Exception as e:
            self.report({'ERROR'}, f"Error appending actions: {e}")
        return {'FINISHED'}

class WM_OT_OpenBlendFile(Operator):
    bl_idname = 'wm.open_blend_file'
    bl_label = 'Open Blend File'
    bl_description = 'Open the selected character blend file (requires confirmation)'
    filepath: StringProperty(subtype="FILE_PATH")

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_confirm(self, event)
        
    def execute(self, context):
        bpy.ops.wm.open_mainfile(filepath=bpy.path.abspath(self.filepath))
        return {'FINISHED'}

# -----------------------------------------------------------------------------------------
#   Update Check Operators
# -----------------------------------------------------------------------------------------
class HHP_OT_CheckForUpdate(Operator):
    bl_idname = "hhp.check_for_update"
    bl_label = "Check for Update"
    bl_description = "Check if a new version is available"

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        try:
            # Compare local vs remote version
            current_version = bl_info['version']
            import urllib.request
            response = urllib.request.urlopen(VERSION_URL)
            latest_version_str = response.read().decode('utf-8').strip()
            latest_version = tuple(map(int, latest_version_str.split('.')))

            if latest_version > current_version:
                prefs.update_available = True
                self.report({'INFO'}, f"Update available! New version: {latest_version}")
            else:
                prefs.update_available = False
                self.report({'INFO'}, "Addon is up to date.")
        except Exception as e:
            prefs.update_available = False
            self.report({'ERROR'}, f"Failed to check for updates: {e}")

        return {'FINISHED'}

class HHP_OT_UpdateToLatestVersion(Operator):
    bl_idname = "hhp.update_to_latest_version"
    bl_label = "Update to Latest Version"
    bl_description = "Update the addon to the latest version"

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        try:
            import urllib.request
            import tempfile
            import zipfile
            import shutil

            tmp_dir = tempfile.mkdtemp()
            zip_path = os.path.join(tmp_dir, "update.zip")
            urllib.request.urlretrieve(UPDATE_ZIP_URL, zip_path)

            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(tmp_dir)

            # Find the extracted addon folder
            addon_folder_name = None
            for item in os.listdir(tmp_dir):
                if os.path.isdir(os.path.join(tmp_dir, item)):
                    addon_folder_name = item
                    break

            if not addon_folder_name:
                self.report({'ERROR'}, "Failed to find the addon folder in the zip file.")
                shutil.rmtree(tmp_dir)
                return {'CANCELLED'}

            addon_folder_path = os.path.join(tmp_dir, addon_folder_name)

            # Current addon folder
            addon_dir = os.path.dirname(os.path.abspath(__file__))

            # Copy new files over existing ones
            for item in os.listdir(addon_folder_path):
                s = os.path.join(addon_folder_path, item)
                d = os.path.join(addon_dir, item)
                if os.path.isdir(s):
                    if os.path.exists(d):
                        shutil.rmtree(d)
                    shutil.copytree(s, d)
                else:
                    if os.path.exists(d):
                        os.remove(d)
                    shutil.copy2(s, d)

            shutil.rmtree(tmp_dir)

            prefs.update_available = False
            self.report({'INFO'}, "Addon updated successfully. Please restart Blender.")

        except Exception as e:
            prefs.update_available = False
            self.report({'ERROR'}, f"Failed to update addon: {e}")

        return {'FINISHED'}

# -----------------------------------------------------------------------------------------
#   News Fetching
# -----------------------------------------------------------------------------------------
def fetch_news():
    try:
        import urllib.request
        response = urllib.request.urlopen(NEWS_URL)
        news_text = response.read().decode('utf-8').strip()
        bpy.context.window_manager.news_text = news_text
    except Exception as e:
        bpy.context.window_manager.news_text = "Failed to fetch news."
        print(f"Failed to fetch news: {e}")

def update_news_timer():
    fetch_news()
    # Reschedule every 30 minutes
    return 1800

from bpy.app.handlers import persistent
@persistent
def fetch_news_handler(dummy):
    fetch_news()

# NEW: Refresh blend file list on file load
@persistent
def refresh_blend_file_list_handler(dummy):
    try:
        bpy.ops.wm.append_collection_from_directory()
    except Exception as e:
        print("Failed to refresh blend file list on file load:", e)

# -----------------------------------------------------------------------------------------
#   Auto-Update on Startup (via timer)
# -----------------------------------------------------------------------------------------
def auto_update_on_startup():
    """
    Called once after Blender starts (via bpy.app.timers).
    If auto-update is enabled, check for an update and automatically install if available.
    """
    prefs = bpy.context.preferences.addons[__name__].preferences

    if prefs.auto_update_enabled:
        # Check for update
        bpy.ops.hhp.check_for_update()
        # If found, run update
        if prefs.update_available:
            bpy.ops.hhp.update_to_latest_version()

    # Return None so the timer doesn't re-run
    return None

# -----------------------------------------------------------------------------------------
#   Register / Unregister
# -----------------------------------------------------------------------------------------
def register():
    global custom_icons

    bpy.utils.register_class(DirectoryItem)
    bpy.utils.register_class(CollectionNameItem)
    bpy.utils.register_class(HHPCharLibraryPreferences)
    bpy.utils.register_class(HHP_UL_Directories)
    bpy.utils.register_class(HHP_UL_CollectionNames)
    bpy.utils.register_class(HHP_OT_AddDirectory)
    bpy.utils.register_class(HHP_OT_RemoveDirectory)
    bpy.utils.register_class(HHP_OT_AddCollectionName)
    bpy.utils.register_class(HHP_OT_RemoveCollectionName)
    bpy.utils.register_class(HHP_OT_AddSceneDirectory)
    bpy.utils.register_class(HHP_OT_RemoveSceneDirectory)
    bpy.utils.register_class(HHP_OT_AddSceneCollectionName)
    bpy.utils.register_class(HHP_OT_RemoveSceneCollectionName)
    bpy.utils.register_class(BlendFileItem)
    bpy.utils.register_class(APPEND_UL_BlendFileList)
    bpy.utils.register_class(HELP_MT_Menu)
    bpy.utils.register_class(HHP_OT_OpenCharPreferences)
    bpy.utils.register_class(HHP_OT_ToggleCharRecursiveSearch)
    bpy.utils.register_class(HHPPanelModeProperty)
    bpy.utils.register_class(HHP_OT_TogglePanelModePhysics)
    bpy.utils.register_class(HHP_OT_TogglePanelModeOptimize)
    bpy.utils.register_class(HHP_OT_TogglePanelModeCustomize)
    bpy.utils.register_class(HHP_OT_TogglePanelModeAnimation)
    bpy.utils.register_class(HHP_OT_TogglePanelModeDynamics)
    bpy.utils.register_class(CHAR_HHP_PT_Panel)
    bpy.utils.register_class(WM_OT_AppendCollectionFromDirectory)
    bpy.utils.register_class(WM_OT_LoadBlendFile)
    bpy.utils.register_class(WM_OT_OpenBlendFile)
    bpy.utils.register_class(WM_OT_AppendStudioFromFile)
    bpy.utils.register_class(WM_OT_AppendActionsFromFile)
    bpy.utils.register_class(HHP_OT_CheckForUpdate)
    bpy.utils.register_class(HHP_OT_UpdateToLatestVersion)
    
    # Register the panel mode property to the scene
    bpy.types.Scene.hhp_panel_mode = bpy.props.PointerProperty(type=HHPPanelModeProperty)

    # Register submodules
    proxies_register()
    Customize_HHP.register()
    Optimize_HHP.register()
    Animation_HHP.register()
    Scene_HHP.register()
    Dynamics_HHP.register()
    Creator_Tools_HHP.register()
    anim_preview.register()
    shader_sss_converter.register()
    import_facs_json.register()
    facs_shapekey_editor.register()
    quick_menu.register()
    dynamic_pressure_canvas.register()  
    dynamic_pressure_brush.register()
    rebind_dynamic_paint.register()  # Register the new rebind operator

    # Collection for blend files
    bpy.types.Scene.blend_file_list = CollectionProperty(type=BlendFileItem)
    bpy.types.Scene.blend_file_list_index = IntProperty(name="Index for blend_file_list", default=-1)
    
    # Quick toggle for recursive search
    bpy.types.Scene.char_quick_recursive_search = BoolProperty(
        name="Forced recursive search", 
        default=False,
        description="Recursively search all subdirectories for blend files. This will create an unorganized list showing all blend files within directories.",
        update=char_quick_recursive_update
    )

    # NEW: Bypass collection names toggle (debug feature)
    bpy.types.Scene.char_bypass_collection = BoolProperty(
        name="Bypass Collection",
        description="When enabled, bypasses specified collection names and directly opens the fallback append popup for Char (HHP)",
        default=False
    )

    # Ensure default directory/collections if empty
    prefs = bpy.context.preferences.addons[__name__].preferences
    if len(prefs.directories) == 0:
        new_dir_item = prefs.directories.add()
        new_dir_item.path = ""
    if len(prefs.collection_names) == 0:
        new_col_item = prefs.collection_names.add()
        new_col_item.name = "Char (HHP)"
    
    # Ensure default scene directory/collections if empty
    if len(prefs.scene_directories) == 0:
        new_scene_dir_item = prefs.scene_directories.add()
        new_scene_dir_item.path = ""
    if len(prefs.scene_collection_names) == 0:
        new_scene_col_item = prefs.scene_collection_names.add()
        new_scene_col_item.name = "Scene (HHP)"

    # Initialize icon previews
    custom_icons = bpy.utils.previews.new()

    # News text property
    bpy.types.WindowManager.news_text = StringProperty(name="News Text", default="")

    # Start news update timer (fetch news now, then every 30 min)
    bpy.app.timers.register(update_news_timer, first_interval=1)

    # Fetch news after file load
    bpy.app.handlers.load_post.append(fetch_news_handler)
    # NEW: Also refresh the blend file list after file load
    bpy.app.handlers.load_post.append(refresh_blend_file_list_handler)

    # -----------------------------------------------
    #   Schedule a one-time auto-update check
    # -----------------------------------------------
    bpy.app.timers.register(auto_update_on_startup, first_interval=1)

    # New operator for appending character blend files when no specified collection is found
    bpy.utils.register_class(WM_OT_AppendCharOptions)

def unregister():
    global custom_icons

    # Remove property group data
    del bpy.types.Scene.blend_file_list
    del bpy.types.Scene.blend_file_list_index
    del bpy.types.Scene.char_quick_recursive_search
    del bpy.types.Scene.char_bypass_collection
    del bpy.types.Scene.hhp_panel_mode
    
    # Remove custom icons
    if custom_icons is not None:
        bpy.utils.previews.remove(custom_icons)
        custom_icons = None

    # Remove the news text property
    del bpy.types.WindowManager.news_text

    # Remove the handlers
    if fetch_news_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(fetch_news_handler)
    # NEW: Remove refresh blend file list handler
    if refresh_blend_file_list_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(refresh_blend_file_list_handler)

    # Unregister submodules
    proxies_unregister()
    Customize_HHP.unregister()
    Optimize_HHP.unregister()
    Animation_HHP.unregister()
    Scene_HHP.unregister()
    Dynamics_HHP.unregister()
    Creator_Tools_HHP.unregister()
    anim_preview.unregister()
    shader_sss_converter.unregister()
    import_facs_json.unregister()
    facs_shapekey_editor.unregister()
    quick_menu.unregister()
    dynamic_pressure_canvas.unregister()  
    dynamic_pressure_brush.unregister()
    rebind_dynamic_paint.unregister()  # Unregister the new rebind operator

    # Unregister classes (reverse order)
    bpy.utils.unregister_class(HHP_OT_UpdateToLatestVersion)
    bpy.utils.unregister_class(HHP_OT_CheckForUpdate)
    bpy.utils.unregister_class(WM_OT_AppendActionsFromFile)
    bpy.utils.unregister_class(WM_OT_AppendStudioFromFile)
    bpy.utils.unregister_class(WM_OT_OpenBlendFile)
    bpy.utils.unregister_class(WM_OT_LoadBlendFile)
    bpy.utils.unregister_class(WM_OT_AppendCollectionFromDirectory)
    bpy.utils.unregister_class(CHAR_HHP_PT_Panel)
    bpy.utils.unregister_class(HHP_OT_TogglePanelModeDynamics)
    bpy.utils.unregister_class(HHP_OT_TogglePanelModeAnimation)
    bpy.utils.unregister_class(HHP_OT_TogglePanelModeCustomize)
    bpy.utils.unregister_class(HHP_OT_TogglePanelModeOptimize)
    bpy.utils.unregister_class(HHP_OT_TogglePanelModePhysics)
    bpy.utils.unregister_class(HHPPanelModeProperty)
    bpy.utils.unregister_class(HHP_OT_ToggleCharRecursiveSearch)
    bpy.utils.unregister_class(HHP_OT_OpenCharPreferences)
    bpy.utils.unregister_class(HELP_MT_Menu)
    bpy.utils.unregister_class(APPEND_UL_BlendFileList)
    bpy.utils.unregister_class(BlendFileItem)
    bpy.utils.unregister_class(HHP_OT_RemoveSceneCollectionName)
    bpy.utils.unregister_class(HHP_OT_AddSceneCollectionName)
    bpy.utils.unregister_class(HHP_OT_RemoveSceneDirectory)
    bpy.utils.unregister_class(HHP_OT_AddSceneDirectory)
    bpy.utils.unregister_class(HHP_OT_RemoveCollectionName)
    bpy.utils.unregister_class(HHP_OT_AddCollectionName)
    bpy.utils.unregister_class(HHP_OT_RemoveDirectory)
    bpy.utils.unregister_class(HHP_OT_AddDirectory)
    bpy.utils.unregister_class(HHP_UL_CollectionNames)
    bpy.utils.unregister_class(HHP_UL_Directories)
    bpy.utils.unregister_class(HHPCharLibraryPreferences)
    bpy.utils.unregister_class(CollectionNameItem)
    bpy.utils.unregister_class(DirectoryItem)

    # Remove the new operator
    bpy.utils.unregister_class(WM_OT_AppendCharOptions)

# -----------------------------------------------------------------------------------------
#   Help Menu
# -----------------------------------------------------------------------------------------
class HELP_MT_Menu(bpy.types.Menu):
    bl_idname = "HELP_MT_menu"
    bl_label = "Help and Tutorials"   # Tooltip description for the dropdown.
    
    def draw(self, context):
        layout = self.layout
        layout.operator("wm.url_open", text="Setup", icon='HELP').url = HELP_INSTALLATION_URL
        layout.operator("wm.url_open", text="Setup Video", icon='HELP').url = bl_info["doc_url"]
        layout.separator()
        layout.operator("wm.url_open", text="Basics", icon='HELP').url = BASICS_URL
        layout.operator("wm.url_open", text="All Char Library Tutorials", icon='URL').url = ALL_TUTORIALS_URL

# -----------------------------------------------------------------------------------------
#   Open Preferences Operators
# -----------------------------------------------------------------------------------------
class HHP_OT_OpenCharPreferences(Operator):
    bl_idname = "hhp.open_char_preferences"
    bl_label = "Character Preferences"
    bl_description = "Open addon preferences and switch to Character mode"
    
    def execute(self, context):
        # Switch to character mode first
        prefs = context.preferences.addons[__name__].preferences
        prefs.mode = 'CHARACTER'
        
        # Then open preferences
        bpy.ops.preferences.addon_show(module=__name__)
        return {'FINISHED'}

def char_quick_recursive_update(self, context):
    """Update callback to refresh character list when quick recursive search is toggled"""
    bpy.ops.wm.append_collection_from_directory()

# Operator to toggle panel modes - separate classes for each mode
class HHP_OT_TogglePanelModePhysics(bpy.types.Operator):
    bl_idname = "hhp.toggle_panel_mode_physics"
    bl_label = "Physics / Proxies"
    bl_description = "Physics / Proxies - Manage character physics and proxies"
    
    def execute(self, context):
        if context.scene.hhp_panel_mode.selected_panel == 'PROXIES':
            # If clicking the same mode again, turn it off
            context.scene.hhp_panel_mode.selected_panel = 'NONE'
        else:
            # Otherwise, switch to the clicked mode
            context.scene.hhp_panel_mode.selected_panel = 'PROXIES'
        return {'FINISHED'}

class HHP_OT_TogglePanelModeOptimize(bpy.types.Operator):
    bl_idname = "hhp.toggle_panel_mode_optimize"
    bl_label = "Optimize / Tools"
    bl_description = "Optimize / Tools - Tools for optimizing character performance"
    
    def execute(self, context):
        if context.scene.hhp_panel_mode.selected_panel == 'OPTIMIZE':
            # If clicking the same mode again, turn it off
            context.scene.hhp_panel_mode.selected_panel = 'NONE'
        else:
            # Otherwise, switch to the clicked mode
            context.scene.hhp_panel_mode.selected_panel = 'OPTIMIZE'
        return {'FINISHED'}

class HHP_OT_TogglePanelModeCustomize(bpy.types.Operator):
    bl_idname = "hhp.toggle_panel_mode_customize"
    bl_label = "Customize"
    bl_description = "Customize - Character customization options"
    
    def execute(self, context):
        if context.scene.hhp_panel_mode.selected_panel == 'CUSTOMIZE':
            # If clicking the same mode again, turn it off
            context.scene.hhp_panel_mode.selected_panel = 'NONE'
        else:
            # Otherwise, switch to the clicked mode
            context.scene.hhp_panel_mode.selected_panel = 'CUSTOMIZE'
        return {'FINISHED'}

class HHP_OT_TogglePanelModeAnimation(bpy.types.Operator):
    bl_idname = "hhp.toggle_panel_mode_animation"
    bl_label = "Animation"
    bl_description = "Animation - Animation controls and tools"
    
    def execute(self, context):
        if context.scene.hhp_panel_mode.selected_panel == 'ANIMATION':
            # If clicking the same mode again, turn it off
            context.scene.hhp_panel_mode.selected_panel = 'NONE'
        else:
            # Otherwise, switch to the clicked mode
            context.scene.hhp_panel_mode.selected_panel = 'ANIMATION'
        return {'FINISHED'}

# Original toggle panel mode operator - keep for backward compatibility
class HHP_OT_TogglePanelMode(bpy.types.Operator):
    bl_idname = "hhp.toggle_panel_mode"
    bl_label = "Toggle Panel Mode"
    bl_description = "Toggle between different panel modes"
    
    mode: bpy.props.StringProperty()
    description: bpy.props.StringProperty(default="")
    
    def execute(self, context):
        if context.scene.hhp_panel_mode.selected_panel == self.mode:
            # If clicking the same mode again, turn it off
            context.scene.hhp_panel_mode.selected_panel = 'NONE'
        else:
            # Otherwise, switch to the clicked mode
            context.scene.hhp_panel_mode.selected_panel = self.mode
        return {'FINISHED'}

# New operator for appending character blend files when no specified collection is found
class WM_OT_AppendCharOptions(Operator):
    bl_idname = 'wm.append_char_options'
    bl_label = 'Append Options'
    bl_description = 'Choose what to append from the blend file for Character HHP'
    bl_options = {'REGISTER', 'INTERNAL'}

    filepath: StringProperty(subtype="FILE_PATH")

    action: EnumProperty(
        items=[
            ('ROOT_COLLECTION', 'Append Root Collection', 'Append the root collection with its full hierarchy intact', 'FILE_VOLUME', 0),
            ('SELECT_COLLECTIONS', 'User Selection', 'Select specific collections to append', 'RESTRICT_SELECT_OFF', 1)
        ],
        name="Action",
        description="What to append from the blend file",
        default='ROOT_COLLECTION'
    )

    def invoke(self, context, event):
        # Clear any previous collection selection lists
        context.scene.scene_available_collections.clear()
        context.scene.scene_selected_collections.clear()
        if os.path.exists(self.filepath):
            with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
                for name in data_from.collections:
                    item = context.scene.scene_available_collections.add()
                    item.name = name
        return context.window_manager.invoke_props_dialog(self, width=500)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Specified collection names not found in file.")
        layout.label(text="What would you like to append?")
        layout.prop(self, "action", expand=True)
        if self.action == 'SELECT_COLLECTIONS':
            layout.separator()
            row = layout.row()
            # Left column: Available collections
            left_col = row.column()
            left_col.label(text=f"Available Collections: {len(context.scene.scene_available_collections)}")
            button_row = left_col.row(align=True)
            button_row.operator('wm.add_all_collections', text="Add All")
            button_row.operator('wm.add_collection', text="Add >>")
            left_col.template_list(
                "SCENE_UL_AvailableCollections", "", 
                context.scene, "scene_available_collections", 
                context.scene, "scene_available_collections_index", 
                rows=9
            )
            # Right column: Selected collections
            right_col = row.column()
            right_col.label(text=f"Selected Collections: {len(context.scene.scene_selected_collections)}")
            button_row = right_col.row(align=True)
            button_row.operator('wm.remove_collection', text="<< Remove")
            button_row.operator('wm.remove_all_collections', text="Remove All")
            right_col.template_list(
                "SCENE_UL_SelectedCollections", "", 
                context.scene, "scene_selected_collections", 
                context.scene, "scene_selected_collections_index", 
                rows=9
            )

    def execute(self, context):
        if not self.filepath or not os.path.exists(self.filepath):
            self.report({'ERROR'}, "Selected file does not exist")
            return {'CANCELLED'}

        # Create a main collection for the character append
        main_collection = None
        base_collection_name = "Char (F)"
        collection_name = base_collection_name

        if base_collection_name in bpy.data.collections:
            counter = 1
            while True:
                numbered_name = f"{base_collection_name}.{counter:03d}"
                if numbered_name not in bpy.data.collections:
                    collection_name = numbered_name
                    break
                counter += 1

        main_collection = bpy.data.collections.new(collection_name)
        # Set the collection color for Char HHP to COLOR_01
        main_collection.color_tag = 'COLOR_01'
        context.scene.collection.children.link(main_collection)

        if self.action == 'ROOT_COLLECTION':
            # Append the scene to gain access to its root collection
            original_scenes = set(bpy.data.scenes.keys())
            with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
                if data_from.scenes:
                    data_to.scenes = [data_from.scenes[0]]
            new_scenes = [scene for scene in bpy.data.scenes if scene.name not in original_scenes]
            if not new_scenes:
                self.report({'WARNING'}, "Could not append scene from file")
                return {'CANCELLED'}
            appended_scene = new_scenes[0]
            collections_to_copy = list(appended_scene.collection.children)
            objects_to_copy = list(appended_scene.collection.objects)

            for collection in collections_to_copy:
                if collection.name not in main_collection.children:
                    main_collection.children.link(collection)
            for obj in objects_to_copy:
                if obj.name not in main_collection.objects:
                    main_collection.objects.link(obj)

            bpy.data.scenes.remove(appended_scene)
            self.report({'INFO'}, f"Appended {len(collections_to_copy)} collections and {len(objects_to_copy)} loose objects to '{collection_name}'")
        else:  # 'SELECT_COLLECTIONS'
            if len(context.scene.scene_selected_collections) == 0:
                self.report({'WARNING'}, "No collections selected")
                return {'CANCELLED'}
            collection_names = [item.name for item in context.scene.scene_selected_collections]
            with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
                data_to.collections = [name for name in data_from.collections if name in collection_names]
            for collection in data_to.collections:
                if collection is not None:
                    main_collection.children.link(collection)
            self.report({'INFO'}, f"Appended {len(data_to.collections)} selected collections to '{collection_name}'")
        return {'FINISHED'}

# New operator for the Dynamics panel
class HHP_OT_TogglePanelModeDynamics(bpy.types.Operator):
    bl_idname = "hhp.toggle_panel_mode_dynamics"
    bl_label = "Dynamics / Fluids"
    bl_description = "Dynamics - Control things like fluid effects, dynamic paint, dynamic deformation, destruction, etc... related to HHP based characters"
    
    def execute(self, context):
        if context.scene.hhp_panel_mode.selected_panel == 'DYNAMICS':
            # If clicking the same mode again, turn it off
            context.scene.hhp_panel_mode.selected_panel = 'NONE'
        else:
            # Otherwise, switch to the clicked mode
            context.scene.hhp_panel_mode.selected_panel = 'DYNAMICS'
        return {'FINISHED'}

if __name__ == "__main__":
    register()
