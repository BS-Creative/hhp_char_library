bl_info = {
    "name": "(BS) Custom | HHP Char Library",
    "author": "Bulging Senpai",
    "description": "Bulging senpai's character library",
    "blender": (4, 3, 0),
    "version": (2, 3, 6),
    "location": "",
    "warning": "",
    "doc_url": "https://www.patreon.com/posts/character-addon-113747469",
    "tracker_url": "",
    "category": "3D View"
}

# -----------------------------------------------------------------------------------------
#   Update URLs
#   Make sure these URLs actually exist in your repo. For example, you must have:
#   - hhp_char_library.zip committed in the repo
#   - version.txt with "1.6.5" or higher to test updates, etc.
# -----------------------------------------------------------------------------------------
UPDATE_ZIP_URL = "https://github.com/BS-Creative/hhp_char_library/raw/main/hhp_char_library.zip"
VERSION_URL = "https://raw.githubusercontent.com/BS-Creative/hhp_char_library/main/version.txt"
GET_CHARACTERS_URL = "https://www.patreon.com/collection/785672?view=condensed"
NEWS_URL = "https://raw.githubusercontent.com/BS-Creative/hhp_char_library/main/news.txt"
HELP_INSTALLATION_URL = "https://raw.githubusercontent.com/BS-Creative/hhp_char_library/refs/heads/main/Tut%20image_C.jpg"
BASICS_URL = "https://www.patreon.com/posts/hhp-basics-120215078"
ALL_TUTORIALS_URL = "https://www.patreon.com/collection/632163?view=expanded"

from .Proxies_HHP import register as proxies_register
from .Proxies_HHP import unregister as proxies_unregister
from . import Animation_HHP
from . import Customize_HHP
from . import Dynamics_HHP
from . import Optimize_HHP
from . import Render_HHP
from . import Scene_HHP
from .modules import anim_preview
from .modules import append_clothing
from .modules import CMN_setup
from .modules import dynamic_pressure_brush
from .modules import dynamic_pressure_canvas
from .modules import facs_shapekey_editor
from .modules import import_facs_csv
from .modules import import_facs_json
from .modules import export_facs_csv
from .modules import export_facs_json
from .modules import light_creator
from .modules import quick_menu
from .modules import rebind_dynamic_paint
from .modules import shader_sss_converter
from . import modules

import bpy
import os
import bpy.utils.previews
from bpy.types import (
    Operator,
    Panel,
    AddonPreferences,
    PropertyGroup,
    UIList
)
from bpy.props import (
    StringProperty,
    CollectionProperty,
    IntProperty,
    BoolProperty,
    FloatProperty,
    EnumProperty
)

import time
import threading

# -----------------------------------------------------------------------------------------
#   Global variable to store custom icons
# -----------------------------------------------------------------------------------------
custom_icons = None

# -----------------------------------------------------------------------------------------
#   Addon Preferences
# -----------------------------------------------------------------------------------------
class DirectoryItem(PropertyGroup):
    path: StringProperty(
        name="Path",
        subtype='DIR_PATH',
        default=""
    )

class CollectionNameItem(PropertyGroup):
    name: StringProperty(
        name="Collection Name",
        default="Char (HHP)"
    )

class HHPCharLibraryPreferences(AddonPreferences):
    bl_idname = __name__

    # Mode selector for Character/Scene
    mode: EnumProperty(
        name="Mode",
        items=[
            ('CHARACTER', "Character", "Character mode"),
            ('SCENE', "Scene", "Scene mode")
        ],
        default='CHARACTER',
        description="Switch between Character and Scene modes"
    )

    # Character mode settings
    directories: CollectionProperty(type=DirectoryItem)
    active_directory_index: IntProperty()

    collection_names: CollectionProperty(type=CollectionNameItem)
    active_collection_index: IntProperty()
    
    force_recursive_search_char: BoolProperty(
        name="Forced recursive search (Not recommended)",
        default=False,
        description="Recursively search all subdirectories for blend files. This will create an unorganized list showing all blend files within directories. Only use as a last resort.",
        update=lambda self, context: bpy.ops.wm.append_collection_from_directory()
    )

    sort_char_list_by_newest: BoolProperty(
        name="Sort by Newest (Last Modified)",
        default=False,
        description="Sort the Character list by last modified date instead of alphabetically. Refreshes list on change.",
        update=lambda self, context: bpy.ops.wm.append_collection_from_directory()
    )

    # Scene mode settings
    scene_directories: CollectionProperty(type=DirectoryItem)
    active_scene_directory_index: IntProperty()

    scene_collection_names: CollectionProperty(type=CollectionNameItem)
    active_scene_collection_index: IntProperty()
    
    force_recursive_search: BoolProperty(
        name="Forced recursive search (Not recommended)",
        default=False,
        description="Recursively search all subdirectories for blend files. This will create an unorganized list showing all blend files within directories. Only use as a last resort.",
        update=lambda self, context: bpy.ops.wm.append_scene_from_directory() if hasattr(bpy.ops.wm, 'append_scene_from_directory') else None
    )

    sort_scene_list_by_newest: BoolProperty(
        name="Sort by Newest (Last Modified)",
        default=False,
        description="Sort the Scene list by last modified date instead of alphabetically. Refreshes list on change.",
        update=lambda self, context: bpy.ops.wm.append_scene_from_directory() if hasattr(bpy.ops.wm, 'append_scene_from_directory') else None
    )

    auto_update_enabled: BoolProperty(
        name="Auto Update",
        default=True,
        description="Enable automatic addon update once on Blender startup"
    )

    # Removed the old update_frequency / last_update_check to simplify logic

    update_available: BoolProperty(
        name="Update Available",
        default=False,
        description="Is an update available"
    )

    debug_mode: BoolProperty(
        name="Debug mode / Dev extras",
        default=False,
        description="Enable additional debugging and developer extras"
    )
    
    enable_aha: BoolProperty(
        name="Enable Automatic Helper Agent, AHA!",
        default=True,
        description="Enable automatic helper popups for user guidance (assisted mode)"
    )
    
    last_aha_shader_option: StringProperty(
        name="Last AHA Shader Option",
        default="EEVEE_RESTORE",
        description="Remembers the last selected shader option in the AHA popup"
    )
    
    focus_on_appended_character: BoolProperty(
        name="Focus on appended character",
        default=False,
        description="Automatically focus the viewport on the character mesh after appending"
    )
    
    clear_preview_on_append: BoolProperty(
        name="Clear preview animation on append",
        default=True,
        description="Automatically clear preview actions and reset pose on appended armatures"
    )
    
    def update_default_shapekey_view(self, context):
        """Update the current shapekey view when preference changes"""
        scene = context.scene
        # Set the view to match the preference (inverted logic since we're tracking "use new view")
        scene.shapekey_legacy_view = not self.default_shapekey_view_new
    
    default_shapekey_view_new: BoolProperty(
        name="Default to New Categorized Shapekey View",
        default=True,
        description="Start with the new categorized shapekey system instead of the legacy 2-column view by default",
        update=update_default_shapekey_view
    )

    def draw(self, context):
        layout = self.layout
        
        # Mode selector
        row = layout.row(align=True)
        row.prop(self, "mode", expand=True)
        
        layout.separator()
        
        # Initialize scene directories and collection names if empty
        # Removed automatic addition of a directory slot
        # if self.mode == 'SCENE' and len(self.scene_directories) == 0:
        #     # Add an empty directory slot
        #     item = self.scene_directories.add()
        #     item.path = ""
        
        # Add default collection name
        # Removed automatic addition of a collection name slot
        # if self.mode == 'SCENE' and len(self.scene_collection_names) == 0:
        #     item = self.scene_collection_names.add()
        #     item.name = "Scene (HHP)"
        
        if self.mode == 'CHARACTER':
            # Character Mode UI
            split = layout.split(factor=0.4) # Adjust factor as needed for label vs controls
            left_col = split.column()
            right_col = split.column()

            left_col.label(text="Character Directories:") # Label in the left part of the split
            
            # Options in the right part of the split, aligned to their own column
            char_options_col = right_col.column(align=True) 
            char_options_col.prop(self, "force_recursive_search_char")
            char_options_col.prop(self, "sort_char_list_by_newest") # Removed text override, uses default
            
            # Directories UI (below the options)
            row = layout.row()
            row.template_list(
                "HHP_UL_Directories", "",
                self, "directories",
                self, "active_directory_index"
            )

            col = row.column(align=True)
            col.operator("hhp.add_directory", icon='ADD', text="")
            col.operator("hhp.remove_directory", icon='REMOVE', text="")

            layout.label(text="Collection Names to Append:")
            row = layout.row()
            row.template_list(
                "HHP_UL_CollectionNames", "",
                self, "collection_names",
                self, "active_collection_index"
            )

            col = row.column(align=True)
            col.operator("hhp.add_collection_name", icon='ADD', text="")
            col.operator("hhp.remove_collection_name", icon='REMOVE', text="")
        else:
            # Scene Mode UI
            split = layout.split(factor=0.4) # Adjust factor as needed
            left_col = split.column()
            right_col = split.column()

            left_col.label(text="Scene Directories:") # Label in the left part of the split

            # Options in the right part of the split
            scene_options_col = right_col.column(align=True)
            scene_options_col.prop(self, "force_recursive_search")
            scene_options_col.prop(self, "sort_scene_list_by_newest") # Removed text override
            
            # Directories UI (below the options)
            row = layout.row()
            row.template_list(
                "HHP_UL_Directories", "",
                self, "scene_directories",
                self, "active_scene_directory_index"
            )

            col = row.column(align=True)
            col.operator("hhp.add_scene_directory", icon='ADD', text="")
            col.operator("hhp.remove_scene_directory", icon='REMOVE', text="")

            layout.label(text="Scene Collection Names to Append:")
            row = layout.row()
            row.template_list(
                "HHP_UL_CollectionNames", "",
                self, "scene_collection_names",
                self, "active_scene_collection_index"
            )

            col = row.column(align=True)
            col.operator("hhp.add_scene_collection_name", icon='ADD', text="")
            col.operator("hhp.remove_scene_collection_name", icon='REMOVE', text="")
            
        layout.separator()
        
        # General Settings Box (consolidated)
        general_settings_box = layout.box()
        general_settings_box.label(text="General Settings & Update Options:")
        general_settings_box.prop(self, "debug_mode")
        general_settings_box.prop(self, "enable_aha")
        general_settings_box.prop(self, "focus_on_appended_character")
        general_settings_box.prop(self, "clear_preview_on_append")
        general_settings_box.prop(self, "default_shapekey_view_new")
        
        # Call the method from quick_menu.py to draw pie menu shortcut settings here
        if hasattr(self, 'draw_pie_menu_shortcut_pref'):
            self.draw_pie_menu_shortcut_pref(general_settings_box) # Pass the box layout

        general_settings_box.separator() # Add a separator for visual grouping before update options
        
        general_settings_box.prop(self, "auto_update_enabled")
        general_settings_box.operator("hhp.check_for_update", text="Check for Update")
        if self.update_available:
            general_settings_box.operator("hhp.update_to_latest_version", text="Update to Latest Version")

# -----------------------------------------------------------------------------------------
#   UI Lists
# -----------------------------------------------------------------------------------------
class HHP_UL_Directories(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.prop(item, "path", text="Directory", emboss=True)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.prop(item, "path", text="", emboss=False)

class HHP_UL_CollectionNames(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.prop(item, "name", text="Collection Name", emboss=True)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.prop(item, "name", text="", emboss=False)

# -----------------------------------------------------------------------------------------
#   Directory & Collection Name Operators
# -----------------------------------------------------------------------------------------
class HHP_OT_AddDirectory(Operator):
    bl_idname = "hhp.add_directory"
    bl_label = "Add Directory"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        new_item = preferences.directories.add()
        new_item.path = ""
        preferences.active_directory_index = len(preferences.directories) - 1
        return {'FINISHED'}

class HHP_OT_RemoveDirectory(Operator):
    bl_idname = "hhp.remove_directory"
    bl_label = "Remove Directory"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        preferences.directories.remove(preferences.active_directory_index)
        preferences.active_directory_index = min(
            max(0, preferences.active_directory_index - 1),
            len(preferences.directories) - 1
        )
        return {'FINISHED'}

class HHP_OT_AddCollectionName(Operator):
    bl_idname = "hhp.add_collection_name"
    bl_label = "Add Collection Name"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        new_item = preferences.collection_names.add()
        new_item.name = "Char (HHP)"
        preferences.active_collection_index = len(preferences.collection_names) - 1
        return {'FINISHED'}

class HHP_OT_RemoveCollectionName(Operator):
    bl_idname = "hhp.remove_collection_name"
    bl_label = "Remove Collection Name"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        preferences.collection_names.remove(preferences.active_collection_index)
        preferences.active_collection_index = min(
            max(0, preferences.active_collection_index - 1),
            len(preferences.collection_names) - 1
        )
        return {'FINISHED'}

# -----------------------------------------------------------------------------------------
#   Scene Directory & Collection Name Operators
# -----------------------------------------------------------------------------------------
class HHP_OT_AddSceneDirectory(Operator):
    bl_idname = "hhp.add_scene_directory"
    bl_label = "Add Scene Directory"
    
    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        item = prefs.scene_directories.add()
        item.path = ""
        prefs.active_scene_directory_index = len(prefs.scene_directories) - 1
        return {'FINISHED'}

class HHP_OT_RemoveSceneDirectory(Operator):
    bl_idname = "hhp.remove_scene_directory"
    bl_label = "Remove Scene Directory"
    
    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        if prefs.active_scene_directory_index >= 0 and len(prefs.scene_directories) > 0:
            prefs.scene_directories.remove(prefs.active_scene_directory_index)
            prefs.active_scene_directory_index = min(max(0, prefs.active_scene_directory_index - 1), len(prefs.scene_directories) - 1)
        return {'FINISHED'}

class HHP_OT_AddSceneCollectionName(Operator):
    bl_idname = "hhp.add_scene_collection_name"
    bl_label = "Add Scene Collection Name"
    
    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        item = prefs.scene_collection_names.add()
        item.name = "Scene (HHP)"  # Default collection name for scene
        prefs.active_scene_collection_index = len(prefs.scene_collection_names) - 1
        return {'FINISHED'}

class HHP_OT_RemoveSceneCollectionName(Operator):
    bl_idname = "hhp.remove_scene_collection_name"
    bl_label = "Remove Scene Collection Name"
    
    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        if prefs.active_scene_collection_index >= 0 and len(prefs.scene_collection_names) > 0:
            prefs.scene_collection_names.remove(prefs.active_scene_collection_index)
            prefs.active_scene_collection_index = min(max(0, prefs.active_scene_collection_index - 1), len(prefs.scene_collection_names) - 1)
        return {'FINISHED'}

# -----------------------------------------------------------------------------------------
#   Utility Functions
# -----------------------------------------------------------------------------------------
def get_most_recent_blend_files(directories):
    """Find the most recent .blend file in each top-level subfolder of the given directories.
    If recursive search is enabled, find all .blend files in the directory structure.
    Sorts according to the 'sort_by_newest' preference."""
    blend_files_with_time = {} # Store path and mtime
    addon_prefs = bpy.context.preferences.addons[__name__].preferences
    
    recursive_search = addon_prefs.force_recursive_search_char # Simplified: only use preference
    
    for directory in directories:
        abs_dir = bpy.path.abspath(directory.path)  # Convert relative path to an absolute path
        if os.path.isdir(abs_dir):
            if recursive_search:
                # Recursive search - find all blend files in directory structure
                for dirpath, dirnames, filenames in os.walk(abs_dir):
                    for filename in filenames:
                        if filename.endswith(".blend") and not filename.startswith("._"):
                            file_path = os.path.join(dirpath, filename)
                            try:
                                # Use only the filename without .blend extension as the key
                                key_name = filename.replace('.blend', '')
                                if key_name not in blend_files_with_time:
                                    blend_files_with_time[key_name] = (file_path, os.path.getmtime(file_path))
                                elif os.path.getmtime(file_path) > blend_files_with_time[key_name][1]: # Keep newest if duplicate names
                                    blend_files_with_time[key_name] = (file_path, os.path.getmtime(file_path))
                            except Exception as e:
                                print(f"Error accessing file {file_path}: {e}")
            else:
                # Standard search - only top-level subfolders
                for subfolder in os.listdir(abs_dir):
                    subfolder_path = os.path.join(abs_dir, subfolder)
                    if os.path.isdir(subfolder_path):
                        recent_file = None
                        recent_time = -1
                        for file in os.listdir(subfolder_path):
                            if file.endswith(".blend") and not file.startswith("._"):
                                file_path = os.path.join(subfolder_path, file)
                                try:
                                    file_time = os.path.getmtime(file_path)
                                    if file_time > recent_time:
                                        recent_time = file_time
                                        recent_file = file_path
                                except Exception as e:
                                    print(f"Error accessing file {file_path}: {e}")
                        if recent_file:
                            blend_files_with_time[subfolder] = (recent_file, recent_time) # Store path and mtime
    
    # Sort based on preference
    if addon_prefs.sort_char_list_by_newest:
        # Sort by modification time (newest first), then by name for tie-breaking
        sorted_items = sorted(blend_files_with_time.items(), key=lambda item: (item[1][1], item[0].lower()), reverse=True)
    else:
        # Sort alphabetically by name (subfolder or filename key)
        sorted_items = sorted(blend_files_with_time.items(), key=lambda item: item[0].lower())

    # Reconstruct blend_files dictionary with only names and paths for compatibility with load_thumbnails
    blend_files = {name: path for name, (path, mtime) in sorted_items}
    return blend_files

# Function to check if render settings match "Setup Render Basics"
def check_render_settings_match():
    scene = bpy.context.scene
    
    # Check general render settings
    if (scene.unit_settings.system != 'METRIC' or
        not scene.render.use_simplify or
        scene.render.simplify_subdivision != 0 or
        scene.render.simplify_subdivision_render != 3 or
        scene.render.use_motion_blur or
        scene.sync_mode != 'AUDIO_SYNC' or
        not scene.render.use_persistent_data):
        return False
    
    # Check Cycles settings
    if scene.cycles.transparent_max_bounces < 100:
        return False
    
    # Check Eevee settings (only if relevant)
    if (scene.eevee.use_taa_reprojection or
        scene.eevee.use_shadow_jitter_viewport or
        scene.eevee.taa_samples != 64 or
        scene.eevee.taa_render_samples != 64 or
        not scene.eevee.use_overscan or
        scene.eevee.overscan_size != 3 or
        not scene.eevee.use_shadows or
        scene.eevee.shadow_resolution_scale != 0.5 or
        scene.eevee.shadow_ray_count != 1 or
        scene.eevee.shadow_step_count != 6 or
        not scene.eevee.use_raytracing or
        scene.eevee.ray_tracing_method != 'SCREEN'):
        return False
    
    return True

class WM_OT_RenderSettingsPopup(Operator):
    bl_idname = "wm.render_settings_popup"
    bl_label = "Render Settings & Shader Setup"
    bl_description = "Choose render settings and shader conversion options"
    
    filepath: StringProperty()
    append_mode: StringProperty()
    
    current_page: IntProperty(default=1)
    
    setup_render_basics: BoolProperty(
        name="Setup render basics",
        default=True,
        description="Apply basic render settings for optimal character rendering"
    )
    
    selected_option: EnumProperty(
        name="Options",
        items=[
            ('EEVEE_RESTORE', "EEVEE (Default)", "Reverts the subsurface conversion and restores original subsurface values when stored", 'SHADING_RENDERED', 0),
            ('EEVEE_ALTERNATE', "EEVEE (Alternate)", "Applies alternate look for EEVEE with less colored light scattering in the skin", 'SHADING_RENDERED', 1),
            ('CYCLES_V3', "Cycles V3", "Applies intended subsurface values for softer more realistic skin", 'SHADING_RENDERED', 2),
            ('CYCLES_V3_SHARPER', "Cycles V3 (Sharper Skin)", "Applies lower subsurface values for skin (skin details are more defined due to lower light diffusion)", 'SHADING_RENDERED', 3),
            ('PROCEED', "Proceed with append only", "Continue with append operation without changing render or shader settings", 'COLLECTION_COLOR_01', 4)
        ],
        default='EEVEE_RESTORE'  # Default to EEVEE (Default)
    )
    
    project_framerate: EnumProperty(
        name="Project Framerate",
        items=[
            ('24', '24 fps', ''), ('25', '25 fps', ''), ('30', '30 fps', ''),
            ('48', '48 fps', ''), ('50', '50 fps', ''), ('60', '60 fps', ''),
            ('120', '120 fps', ''), ('CUSTOM', 'Custom', '')
        ],
        default='24'
    )
    
    custom_fps: IntProperty(
        name='Custom FPS', 
        description='Custom frame rate for the project',
        default=60, min=1, soft_min=1, soft_max=240
    )
    
    def invoke(self, context, event):
        # Set the default to the last selected option
        prefs = context.preferences.addons[__name__].preferences
        self.selected_option = prefs.last_aha_shader_option
        return context.window_manager.invoke_props_dialog(self, width=380)
    
    def draw(self, context):
        layout = self.layout
        
        if self.current_page == 1:
            # Page 1: Shader selection
            # Add icon and message
            row = layout.row()
            row.label(text="", icon='USER')
            col = row.column()
            col.label(text="This is the Automatic Helper Agent, AHA!")
            col.label(text="I am here to help you setup your shaders for your intended")
            col.label(text="render engine. Please select how you would like to")
            col.label(text="see your character rendered.")
            
            layout.separator()
            
            col.label(text="Hovering over the selection will give you a more detailed")
            col.label(text="description.")
            
            layout.separator()
            
            col.label(text="You can always revert to")
            col.label(text="original settings from the shader setup menu next to the preset")
            col.label(text="dropdown.")
            
            layout.separator()
            
            # Setup render basics checkbox - grey out if "Proceed with append only" is selected
            checkbox_row = layout.row()
            checkbox_row.enabled = (self.selected_option != 'PROCEED')
            checkbox_row.prop(self, "setup_render_basics")
            
            layout.separator()
            
            # Shader options in single column layout
            col = layout.column(align=True)
            col.prop_enum(self, "selected_option", 'EEVEE_RESTORE')
            col.prop_enum(self, "selected_option", 'EEVEE_ALTERNATE')
            col.prop_enum(self, "selected_option", 'CYCLES_V3')
            col.prop_enum(self, "selected_option", 'CYCLES_V3_SHARPER')
            col.prop_enum(self, "selected_option", 'PROCEED')
            
        elif self.current_page == 2:
            # Page 2: Framerate selection
            # Add icon and message
            row = layout.row()
            row.label(text="", icon='USER')
            col = row.column()
            col.label(text="What is the framerate this project will be animated at?")
            
            layout.separator()
            
            # Framerate dropdown
            col = layout.column(align=True)
            col.prop(self, "project_framerate", text="")
            if self.project_framerate == 'CUSTOM':
                col.prop(self, "custom_fps")
    
    def execute(self, context):
        if self.current_page == 1:
            # Store the selected option for next time
            prefs = context.preferences.addons[__name__].preferences
            prefs.last_aha_shader_option = self.selected_option
            
            # If "Proceed with append only" is selected, skip to final execution
            if self.selected_option == 'PROCEED':
                # Continue with append operation directly
                bpy.ops.wm.load_blend_file_execute(filepath=self.filepath, append_mode=self.append_mode)
                return {'FINISHED'}
            else:
                # Go to page 2 - match current scene FPS
                current_fps = context.scene.render.fps
                # Check if current FPS matches any of the predefined options
                fps_options = ['24', '25', '30', '48', '50', '60', '120']
                if str(current_fps) in fps_options:
                    self.project_framerate = str(current_fps)
                else:
                    self.project_framerate = 'CUSTOM'
                    self.custom_fps = current_fps
                
                self.current_page = 2
                return context.window_manager.invoke_props_dialog(self, width=380)
        
        elif self.current_page == 2:
            # Final execution: Apply settings and proceed
            # Set the framerate
            new_fps = self.custom_fps if self.project_framerate == 'CUSTOM' else int(self.project_framerate)
            context.scene.render.fps = new_fps
            
            # Apply render settings if checkbox is enabled
            if self.setup_render_basics:
                from . import Optimize_HHP
                Optimize_HHP.setup_render_basics()
            
            # Store shader choice to apply after append
            context.scene['hhp_shader_choice'] = self.selected_option
            
            # Continue with append operation
            bpy.ops.wm.load_blend_file_execute(filepath=self.filepath, append_mode=self.append_mode)
            
            # Run match to scene framerate function after append
            try:
                bpy.ops.object.physics_framerate_multiplier(action='CONVERT')
            except:
                # If no physics objects are selected, that's okay
                pass
            
            return {'FINISHED'}
        
        return {'FINISHED'}


def append_collections(filepath, collection_names):
    """Append the specified collections from a .blend file."""
    filepath = bpy.path.abspath(filepath)  # Convert relative path to absolute
    if not filepath:
        print("File path is empty. Please set the path in Addon Preferences.")
        return []
    appended_collections = []
    try:
        with bpy.data.libraries.load(filepath, link=False) as (data_from, data_to):
            collections_to_append = [
                citem.name for citem in collection_names
                if citem.name in data_from.collections
            ]
            data_to.collections = collections_to_append

        if data_to.collections:
            for collection in data_to.collections:
                if collection is not None:
                    bpy.context.scene.collection.children.link(collection)
                    appended_collections.append(collection)
                    bpy.ops.object.select_all(action='DESELECT')
                    for obj in collection.objects:
                        obj.select_set(True)
                    bpy.context.view_layer.objects.active = collection.objects[0]
    except Exception as e:
        print(f"Error appending collections from {filepath}: {e}")

    return appended_collections

# -----------------------------------------------------------------------------------------
#   Animation Preview Utilities
# -----------------------------------------------------------------------------------------
def _iter_armatures_in_collection(collection):
    """Yield all armature objects contained in a collection, recursively."""
    try:
        for obj in collection.objects:
            if obj and obj.type == 'ARMATURE':
                yield obj
        for child in collection.children:
            yield from _iter_armatures_in_collection(child)
    except Exception:
        return

def clear_preview_animation(obj):
    """Clear preview animation state on an armature: clears action/slot and resets pose transforms."""
    if not obj or obj.type != 'ARMATURE':
        return
    # Clear the anim preview selected action property if available
    try:
        if hasattr(obj, 'hhp_anim_preview_props'):
            obj.hhp_anim_preview_props.action = None
    except Exception:
        pass
    # Clear active action and slot
    try:
        obj.animation_data_create()
        obj.animation_data.action = None
        if hasattr(obj.animation_data, 'action_slot'):
            obj.animation_data.action_slot = None
    except Exception:
        pass
    # Reset pose transforms to defaults
    try:
        if obj.pose:
            for bone in obj.pose.bones:
                bone.location = (0, 0, 0)
                bone.rotation_quaternion = (1, 0, 0, 0)
                bone.rotation_euler = (0, 0, 0)
                bone.rotation_axis_angle = (0, 0, 1, 0)
                bone.scale = (1, 1, 1)
    except Exception:
        pass
    # Ensure depsgraph updates
    try:
        if bpy.context.view_layer:
            bpy.context.view_layer.update()
    except Exception:
        pass

def load_thumbnails(blend_files):
    """Load thumbnails for each subfolder's .blend file (from thumbnail.png/jpg/jpeg or the .blend itself)."""
    global custom_icons
    thumbnails = {}
    for subfolder, file_path in blend_files.items():
        try:
            blend_dir = os.path.dirname(file_path)
            
            # Check for thumbnail files in different formats
            thumbnail_found = False
            for ext in ['.png', '.jpg', '.jpeg']:
                thumbnail_path = os.path.join(blend_dir, f'thumbnail{ext}')
                if os.path.isfile(thumbnail_path):
                    thumb = custom_icons.load(file_path, thumbnail_path, 'IMAGE')
                    thumbnails[file_path] = thumb
                    thumbnail_found = True
                    break
            
            # Fall back to using the blend file itself if no thumbnail image was found
            if not thumbnail_found:
                thumb = custom_icons.load(file_path, file_path, 'BLEND')
                thumbnails[file_path] = thumb
                
        except Exception as e:
            print(f"Error loading thumbnail for {file_path}: {e}")
    return thumbnails

# -----------------------------------------------------------------------------------------
#   Property Group for Blend Files
# -----------------------------------------------------------------------------------------
class BlendFileItem(PropertyGroup):
    name: StringProperty()
    file_path: StringProperty()
    icon_id: IntProperty()

# -----------------------------------------------------------------------------------------
#   UIList for Blend Files
# -----------------------------------------------------------------------------------------
class APPEND_UL_BlendFileList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        blend_file = item
        display_name = blend_file.name.replace('.blend', '')
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.label(text=display_name, icon_value=blend_file.icon_id)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon_value=blend_file.icon_id)

# -----------------------------------------------------------------------------------------
#   Main Panel
# -----------------------------------------------------------------------------------------

# Panel Mode Property Group
class HHPPanelModeProperty(bpy.types.PropertyGroup):
    selected_panel: bpy.props.EnumProperty(
        name="Panel Mode",
        description="Select which panel to display",
        items=[
            ('NONE', "None", "No panel selected", 'X', 0),
            ('PROXIES', "Physics", "Show Physics/Proxies panel", 'PHYSICS', 1),
            ('OPTIMIZE', "Optimize", "Show Optimize/Tools panel", 'MOD_REMESH', 2),
            ('CUSTOMIZE', "Customize", "Show Customize panel", 'MOD_HUE_SATURATION', 3),
            ('RENDER', "Render / Lighting", "Show Render/Lighting panel", 'LIGHT', 4),
            ('ANIMATION', "Animation", "Show Animation panel", 'ACTION', 5),
            ('DYNAMICS', "Dynamics / Fluids", "Show Dynamics panel", 'MOD_FLUIDSIM', 6)
        ],
        default='NONE'  # All modes off by default
    )

class CHAR_HHP_PT_Panel(Panel):
    bl_label = "Char (HHP)"
    bl_idname = "CHAR_HHP_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'
    bl_ui_units_x = 30  # Make panel wider

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__name__].preferences

        # NEW: If no directory is selected (i.e. all paths are empty),
        # display a warning message and two vertically aligned buttons.
        if not any(directory.path.strip() for directory in prefs.directories):
            warning_box = layout.box()
            warning_box.alert = True  # Make the entire box appear as an alert
            warning_box.label(text="Please select where you'd like characters stored", icon='ERROR')
            col = warning_box.column(align=True)  # Vertically aligned buttons
            btn = col.operator("wm.url_open", text="Setup guide", icon='HELP')
            btn.url = HELP_INSTALLATION_URL
            # Use our custom operator to switch to character mode in preferences
            col.operator("hhp.open_char_preferences", text="Open character preferences", icon='PREFERENCES')
            return

        # News and Help button in same row
        news_row = layout.row(align=True)
        news_row.label(text="News: " + context.window_manager.news_text, icon='WORLD')
        
        # Add spacer to push help button to the right
        news_row.separator(factor=1.0)
        
        # Add debug mode toggles (only if debug mode is enabled)
        if prefs.debug_mode:
            news_row.prop(prefs, "enable_aha", text="", icon='USER', toggle=True)
            news_row.prop(context.scene, "char_bypass_collection", text="", icon='GHOST_ENABLED', toggle=True)
        
        # Sort by newest and Recursive search toggles
        sub = news_row.row(align=True)
        sub.alignment = 'RIGHT'
        sub.prop(prefs, "sort_char_list_by_newest", text="", icon='SORTTIME', toggle=True)
        sub.prop(prefs, "force_recursive_search_char", text="", icon='VIEWZOOM', toggle=True)
        sub.menu("HELP_MT_menu", text="", icon='HELP')

        # Buttons
        box = layout.box()
        row = box.row(align=True)
        
        if prefs.update_available:
            row.operator("hhp.update_to_latest_version", text="Update", icon='FILE_REFRESH')
        else:
            row.operator("hhp.check_for_update", text="Check for Update")

        row.operator('wm.append_collection_from_directory', text="Refresh List")
        row.operator("wm.url_open", text="Get Characters", icon='ARMATURE_DATA').url = GET_CHARACTERS_URL

        # Blend file list
        layout.template_list(
            "APPEND_UL_BlendFileList", "",
            context.scene, "blend_file_list",
            context.scene, "blend_file_list_index"
        )

        if context.scene.blend_file_list_index >= 0 and context.scene.blend_file_list:
            blend_file = context.scene.blend_file_list[context.scene.blend_file_list_index]
            row = layout.row()
            row.template_icon(blend_file.icon_id, scale=6)

            # Top buttons box with better alignment
            button_box = layout.box()
            col = button_box.column(align=True)
            
            # Open/Append buttons in a row, now set to double tall for easier clicking
            buttons_row = col.row(align=True)
            open_button = buttons_row.operator('wm.open_blend_file', text="Open (Edit Blend)", icon='FILE_FOLDER')
            open_button.filepath = blend_file.file_path
            # Determine if the active object is an HHP mesh (used for swap workflow)
            active_obj = context.active_object
            is_hhp_mesh = (
                active_obj is not None
                and active_obj.type == 'MESH'
                and "Genesis8Female.Shape" in active_obj.name
                and getattr(active_obj.data, "name", None) is not None
                and "Genesis8Female" in active_obj.data.name
            )

            # Also check if there's already a "Char (HHP)" collection in the scene
            has_char_hhp_collection = False
            try:
                stack = list(context.scene.collection.children)
                while stack and not has_char_hhp_collection:
                    child_col = stack.pop()
                    if "Char (HHP)" in child_col.name:
                        has_char_hhp_collection = True
                        break
                    stack.extend(child_col.children)
            except Exception:
                has_char_hhp_collection = False

            if is_hhp_mesh or has_char_hhp_collection:
                # For HHP meshes, clicking Append opens a menu with Append / Swap options
                append_button = buttons_row.operator(
                    'wm.call_hhp_append_char_menu',
                    text="Append Character",
                    icon='COLLECTION_COLOR_01'
                )
                append_button.filepath = blend_file.file_path
            else:
                # Default behavior: directly append the character
                append_button = buttons_row.operator(
                    'wm.load_blend_file',
                    text="Append Character",
                    icon='COLLECTION_COLOR_01'
                )
                append_button.filepath = blend_file.file_path
            
            # Add "Append Assets..." button
            assets_row = col.row(align=True)
            append_assets_op = assets_row.operator(WM_OT_CallAppendAssetsMenu.bl_idname, text="Append Assets...", icon='ASSET_MANAGER')
            append_assets_op.filepath = blend_file.file_path

            # Add mode selector in the same box as the append buttons
            mode_row = col.row(align=True)
            
            # Physics button with proper name in the description, clean icon
            physics_btn = mode_row.operator("hhp.toggle_panel_mode_physics", text="", icon='PHYSICS', depress=context.scene.hhp_panel_mode.selected_panel=='PROXIES')
            
            # Optimize button with proper name in the description, clean icon
            optimize_btn = mode_row.operator("hhp.toggle_panel_mode_optimize", text="", icon='MODIFIER_DATA', depress=context.scene.hhp_panel_mode.selected_panel=='OPTIMIZE')
            
            # Customize button with proper name in the description, clean icon
            customize_btn = mode_row.operator("hhp.toggle_panel_mode_customize", text="", icon='MOD_HUE_SATURATION', depress=context.scene.hhp_panel_mode.selected_panel=='CUSTOMIZE')
            
            # Render / Lighting button with proper name in the description, clean icon
            render_btn = mode_row.operator("hhp.toggle_panel_mode_render", text="", icon='LIGHT', depress=context.scene.hhp_panel_mode.selected_panel=='RENDER')
            
            # Animation button with proper name in the description, clean icon
            animation_btn = mode_row.operator("hhp.toggle_panel_mode_animation", text="", icon='ACTION', depress=context.scene.hhp_panel_mode.selected_panel=='ANIMATION')
            
            # Dynamics button with proper name in the description, clean icon
            dynamics_btn = mode_row.operator("hhp.toggle_panel_mode_dynamics", text="", icon='MOD_FLUIDSIM', depress=context.scene.hhp_panel_mode.selected_panel=='DYNAMICS')
            
            # Add preset dropdown in the same row if Genesis8Female is selected
            if (context.active_object and context.active_object.type == 'MESH'
                    and context.active_object.data and "Genesis8Female" in context.active_object.data.name
                    and "Deform Proxy" not in context.active_object.name):
                mode_row.prop(context.active_object, "active_preset", text="", icon="MOD_CLOTH")
                mode_row.menu("SHADER_SSS_MT_menu", text="", icon='NODE_MATERIAL')

            # Add the anim preview box here, after the append buttons
            anim_preview.draw_anim_preview_box(layout, context)
            
    def draw_header(self, context):
        self.layout.label(icon='OUTLINER_OB_ARMATURE')  # Icon for Char (HHP)

# -----------------------------------------------------------------------------------------
#   Operators to Load/Append from .blend
# -----------------------------------------------------------------------------------------
class WM_OT_AppendCollectionFromDirectory(Operator):
    bl_idname = 'wm.append_collection_from_directory'
    bl_label = 'Refresh List'
    bl_description = 'Refresh the list of blend files from the directories'
    thumbnails = None

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        # get_most_recent_blend_files now handles sorting based on preferences
        recent_blend_files = get_most_recent_blend_files(prefs.directories)

        global custom_icons
        custom_icons.clear()

        self.thumbnails = load_thumbnails(recent_blend_files) # This expects {name: path}

        # The recent_blend_files is already sorted correctly by get_most_recent_blend_files
        # No need to sort again here. The items() will preserve insertion order (Python 3.7+)
        # For older versions, this might not be guaranteed, but recent_blend_files is now an OrderedDict implicitly
        # due to its construction from sorted_items if we ensure that part.
        # However, load_thumbnails expects a dict, and passing items directly is fine for iteration.

        context.scene.blend_file_list.clear()
        for subfolder, file_path in recent_blend_files.items(): # Iterate directly over the sorted dict
            icon_id = self.thumbnails[file_path].icon_id if file_path in self.thumbnails else 0
            display_name = subfolder
            new_item = context.scene.blend_file_list.add()
            new_item.name = display_name
            new_item.file_path = file_path
            new_item.icon_id = icon_id

        if context.scene.blend_file_list:
            context.scene.blend_file_list_index = 0

        return {'FINISHED'}

class WM_OT_LoadBlendFileExecute(Operator):
    bl_idname = 'wm.load_blend_file_execute'
    bl_label = 'Load Blend File Execute'
    bl_description = 'Execute the append operation'
    filepath: StringProperty(subtype="FILE_PATH")
    append_mode: EnumProperty(
        name="Append Mode",
        items=[
            ('CHARACTER', "Character", "Append from the Char (HHP) panel"),
            ('SCENE', "Scene", "Append from the Scene (HHP) panel")
        ],
        default='CHARACTER'
    )

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences

        # Internal: track whether this append operation had to fall back to the manual append popup.
        # Used by tools like "Swap Character Animation" to prevent running on non-HHP/fallback appends.
        if hasattr(context.window_manager, "hhp_last_append_used_fallback"):
            context.window_manager.hhp_last_append_used_fallback = False
        if hasattr(context.window_manager, "hhp_last_append_fallback_reason"):
            context.window_manager.hhp_last_append_fallback_reason = ""
        
        # NEW: Check if bypass is enabled based on append mode
        if self.append_mode == 'CHARACTER' and context.scene.char_bypass_collection:
            if hasattr(context.window_manager, "hhp_last_append_used_fallback"):
                context.window_manager.hhp_last_append_used_fallback = True
            if hasattr(context.window_manager, "hhp_last_append_fallback_reason"):
                context.window_manager.hhp_last_append_fallback_reason = "bypass_collection_enabled"
            bpy.ops.wm.append_char_options('INVOKE_DEFAULT', filepath=self.filepath)
            return {'FINISHED'}
        elif self.append_mode == 'SCENE' and context.scene.scene_bypass_collection:
            bpy.ops.wm.append_scene_options('INVOKE_DEFAULT', filepath=self.filepath)
            return {'FINISHED'}
        
        # Existing append collections logic
        appended_collections = append_collections(self.filepath, prefs.collection_names)
        if not appended_collections:
            if self.append_mode == 'CHARACTER':
                if hasattr(context.window_manager, "hhp_last_append_used_fallback"):
                    context.window_manager.hhp_last_append_used_fallback = True
                if hasattr(context.window_manager, "hhp_last_append_fallback_reason"):
                    context.window_manager.hhp_last_append_fallback_reason = "no_matching_hhp_collections"
                bpy.ops.wm.append_char_options('INVOKE_DEFAULT', filepath=self.filepath)
            else:
                bpy.ops.wm.append_scene_options('INVOKE_DEFAULT', filepath=self.filepath)
            return {'FINISHED'}

        # Clear preview animation on any appended armatures (if enabled)
        if prefs.clear_preview_on_append:
            try:
                for col in appended_collections:
                    for arm in _iter_armatures_in_collection(col):
                        clear_preview_animation(arm)
            except Exception:
                pass

        # Switch to Object mode and deselect all
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')

        # Attempt to select an Armature in the appended collections
        armature_found = False
        for collection in appended_collections:
            for obj in collection.objects:
                if obj.type == 'ARMATURE':
                    obj.select_set(True)
                    bpy.context.view_layer.objects.active = obj
                    obj.data.pose_position = 'POSE'
                    armature_found = True
                    break
            if armature_found:
                break
        
        # After appending, select the main character mesh to be ready for customization
        # NEW: Now, select the 'Genesis8Female.Shape' mesh
        bpy.ops.object.select_all(action='DESELECT')
        for collection in appended_collections:
            for obj in collection.objects:
                if obj.type == 'MESH' and obj.name.startswith("Genesis8Female.Shape"):
                    obj.select_set(True)
                    bpy.context.view_layer.objects.active = obj
                    # Check preference before focusing
                    prefs = bpy.context.preferences.addons[__name__].preferences
                    if prefs.focus_on_appended_character:
                        # Focus on the selected character mesh and switch to 3/4 perspective view
                        bpy.ops.view3d.view_selected()
                        # Set to perspective view (not orthographic)
                        for area in bpy.context.screen.areas:
                            if area.type == 'VIEW_3D':
                                area.spaces[0].region_3d.view_perspective = 'PERSP'
                                break
                        # Position at a nice 3/4 angle
                        bpy.ops.view3d.view_axis(type='FRONT', align_active=True)
                        bpy.ops.view3d.view_orbit(angle=0.5, type='ORBITRIGHT')
                    break
        
        # Apply shader conversion if one was selected
        if (self.append_mode == 'CHARACTER' and 'hhp_shader_choice' in context.scene):
            shader_choice = context.scene['hhp_shader_choice']
            
            # Check if model is on optimized materials and switch back to original materials first
            from . import Optimize_HHP
            selected_objects = context.selected_objects
            if Optimize_HHP.is_material_linked_by_object(selected_objects):
                print("Model is using optimized materials. Switching back to original materials before shader conversion.")
                Optimize_HHP.toggle_material_link(selected_objects)
            
            # Apply the selected shader conversion
            if shader_choice == 'EEVEE_RESTORE':
                bpy.ops.shader_sss.revert()
            elif shader_choice == 'EEVEE_ALTERNATE':
                bpy.ops.shader_sss.use_eevee_v3()
            elif shader_choice == 'CYCLES_V3':
                bpy.ops.shader_sss.use_cycles_v3()
            elif shader_choice == 'CYCLES_V3_SHARPER':
                bpy.ops.shader_sss.use_cycles_v3_sharper()
            
            # Clean up the scene property
            del context.scene['hhp_shader_choice']
        
        return {'FINISHED'}

class WM_OT_LoadBlendFile(Operator):
    bl_idname = 'wm.load_blend_file'
    bl_label = 'Load Blend File'
    bl_description = 'Append the selected character to scene'
    filepath: StringProperty(subtype="FILE_PATH")
    append_mode: EnumProperty(
        name="Append Mode",
        items=[
            ('CHARACTER', "Character", "Append from the Char (HHP) panel"),
            ('SCENE', "Scene", "Append from the Scene (HHP) panel")
        ],
        default='CHARACTER'
    )

    def execute(self, context):
        # Check if AHA is enabled and if it's a character append
        prefs = bpy.context.preferences.addons[__name__].preferences
        if prefs.enable_aha and self.append_mode == 'CHARACTER':
            # Show popup for render settings and shader setup
            bpy.ops.wm.render_settings_popup('INVOKE_DEFAULT', 
                                           filepath=self.filepath, 
                                           append_mode=self.append_mode)
            return {'FINISHED'}
        
        # If AHA is disabled or it's not a character append, proceed directly
        bpy.ops.wm.load_blend_file_execute(filepath=self.filepath, append_mode=self.append_mode)
        return {'FINISHED'}

class WM_OT_AppendStudioFromFile(Operator):
    bl_idname = 'wm.append_studio_from_file'
    bl_label = 'Append Studio'
    bl_description = 'Append the "Studio and lights" collection and all worlds from the selected file, then set the appended world as active'

    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        collection_name = "Studio and lights"
        try:
            abs_filepath = bpy.path.abspath(self.filepath)
            with bpy.data.libraries.load(abs_filepath, link=False) as (data_from, data_to):
                if collection_name in data_from.collections:
                    data_to.collections = [collection_name]
                else:
                    self.report({'WARNING'}, f'Collection "{collection_name}" not found in {abs_filepath}')
                    return {'CANCELLED'}
            for collection in data_to.collections:
                if collection is not None:
                    bpy.context.scene.collection.children.link(collection)
                    # Make the collection visible, enabled in viewport and render
                    collection.hide_viewport = False
                    collection.hide_render = False
            self.report({'INFO'}, f'Appended "{collection_name}" from {abs_filepath}')
        except Exception as e:
            self.report({'ERROR'}, f'Error appending "{collection_name}": {e}')
            # Do not proceed to world appending if collection append failed severely or filepath is bad
            # However, if the collection just wasn't found, we might still want to append worlds.
            # For now, let's assume if an error occurs here, we might not want to proceed.
            # If collection_name was not found, it returns CANCELLED, so world logic won't run.
            # If other error, it also might return before this.

        # --- Start World Appending Logic ---
        if not os.path.exists(self.filepath):
            # This check is a bit redundant if abs_filepath above already failed, but good for safety
            self.report({'ERROR'}, "Filepath for worlds does not exist.")
            return {'CANCELLED'} # or just let the previous return handle it.

        # 1. Flag all existing worlds as fake users
        for world_item in bpy.data.worlds:
            world_item.use_fake_user = True
        if bpy.data.worlds:
            self.report({'INFO'}, f"Flagged {len(bpy.data.worlds)} existing world(s) as fake user.")

        # 2. Append worlds from the file
        original_world_names = set(w.name for w in bpy.data.worlds)
        worlds_appended_count = 0
        newly_appended_world = None

        try:
            with bpy.data.libraries.load(bpy.path.abspath(self.filepath), link=False) as (data_from, data_to):
                data_to.worlds = data_from.worlds
            
            for world in data_to.worlds:
                if world and world.name not in original_world_names:
                    world.use_fake_user = True # Ensure newly appended are also flagged
                    worlds_appended_count += 1
                    if newly_appended_world is None:
                        newly_appended_world = world # Keep track of the first new world
            
            if newly_appended_world:
                context.scene.world = newly_appended_world
                self.report({'INFO'}, f"Appended {worlds_appended_count} world(s) from studio file. '{newly_appended_world.name}' set as active.")
            elif worlds_appended_count > 0:
                 self.report({'INFO'}, f"Appended {worlds_appended_count} world(s) from studio file, but none were newly unique to set as active.")
            else:
                self.report({'INFO'}, "No new worlds found in the studio file to append.")

        except Exception as e:
            self.report({'WARNING'}, f"Could not append worlds from studio file: {e}")
        # --- End World Appending Logic ---

        return {'FINISHED'}

class WM_OT_AppendActionsFromFile(Operator):
    bl_idname = "wm.append_actions_from_file"
    bl_label = "Append Animation/Poses"  # Renamed
    bl_description = "Append all actions (animations and poses) from the selected blend file and flag them as fake users"
    filepath: StringProperty(subtype="FILE_PATH")
    # New property for our popup checkbox
    set_fps: BoolProperty(
        name="Set Scene FPS to 60",
        description="Set scene fps to 60fps to match HHP animations base frame rate",
        default=True
    )
    
    def invoke(self, context, event):
        # Check fps; if not 60, show the popup dialog with wider width
        if context.scene.render.fps != 60:
            return context.window_manager.invoke_props_dialog(self, width=300)
        return self.execute(context)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="HHP animations are 60fps. Set scene fps to 60?")
        layout.prop(self, "set_fps", text="Set fps to 60 (recommended)")
    
    def execute(self, context):
        # If not 60fps and the user checked the option, update the scene fps to 60.
        if context.scene.render.fps != 60 and self.set_fps:
            context.scene.render.fps = 60
        try:
            abs_filepath = bpy.path.abspath(self.filepath)
            with bpy.data.libraries.load(abs_filepath, link=False) as (data_from, data_to):
                data_to.actions = data_from.actions[:]
            for action in data_to.actions:
                if action is not None:
                    action.use_fake_user = True
            self.report({'INFO'}, f'Appended {len(data_to.actions)} actions from {abs_filepath}')
        except Exception as e:
            self.report({'ERROR'}, f"Error appending actions: {e}")
        return {'FINISHED'}

class WM_OT_OpenBlendFile(Operator):
    bl_idname = 'wm.open_blend_file'
    bl_label = 'Open Blend File'
    bl_description = 'Open the selected character blend file (requires confirmation)'
    filepath: StringProperty(subtype="FILE_PATH")

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_confirm(self, event)
        
    def execute(self, context):
        bpy.ops.wm.open_mainfile(filepath=bpy.path.abspath(self.filepath))
        return {'FINISHED'}

# -----------------------------------------------------------------------------------------
#   Update Check Operators
# -----------------------------------------------------------------------------------------
class HHP_OT_CheckForUpdate(Operator):
    bl_idname = "hhp.check_for_update"
    bl_label = "Check for Update"
    bl_description = "Check if a new version is available"

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        try:
            # Compare local vs remote version
            current_version = bl_info['version']
            import urllib.request
            response = urllib.request.urlopen(VERSION_URL)
            latest_version_str = response.read().decode('utf-8').strip()
            latest_version = tuple(map(int, latest_version_str.split('.')))

            if latest_version > current_version:
                prefs.update_available = True
                self.report({'INFO'}, f"Update available! New version: {latest_version}")
            else:
                prefs.update_available = False
                self.report({'INFO'}, "Addon is up to date.")
        except Exception as e:
            prefs.update_available = False
            self.report({'ERROR'}, f"Failed to check for updates: {e}")

        return {'FINISHED'}

class HHP_OT_UpdateToLatestVersion(Operator):
    bl_idname = "hhp.update_to_latest_version"
    bl_label = "Update to Latest Version"
    bl_description = "Update the addon to the latest version"

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        try:
            import urllib.request
            import tempfile
            import zipfile
            import shutil

            tmp_dir = tempfile.mkdtemp()
            zip_path = os.path.join(tmp_dir, "update.zip")
            urllib.request.urlretrieve(UPDATE_ZIP_URL, zip_path)

            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(tmp_dir)

            # Find the extracted addon folder
            addon_folder_name = None
            for item in os.listdir(tmp_dir):
                if os.path.isdir(os.path.join(tmp_dir, item)):
                    addon_folder_name = item
                    break

            if not addon_folder_name:
                self.report({'ERROR'}, "Failed to find the addon folder in the zip file.")
                shutil.rmtree(tmp_dir)
                return {'CANCELLED'}

            addon_folder_path = os.path.join(tmp_dir, addon_folder_name)

            # Current addon folder
            addon_dir = os.path.dirname(os.path.abspath(__file__))

            # Copy new files over existing ones
            for item in os.listdir(addon_folder_path):
                s = os.path.join(addon_folder_path, item)
                d = os.path.join(addon_dir, item)
                if os.path.isdir(s):
                    if os.path.exists(d):
                        shutil.rmtree(d)
                    shutil.copytree(s, d)
                else:
                    if os.path.exists(d):
                        os.remove(d)
                    shutil.copy2(s, d)

            shutil.rmtree(tmp_dir)

            prefs.update_available = False
            self.report({'INFO'}, "Addon updated successfully. Please restart Blender.")

        except Exception as e:
            prefs.update_available = False
            self.report({'ERROR'}, f"Failed to update addon: {e}")

        return {'FINISHED'}

# -----------------------------------------------------------------------------------------
#   News Fetching
# -----------------------------------------------------------------------------------------
def fetch_news():
    try:
        import urllib.request
        response = urllib.request.urlopen(NEWS_URL)
        news_text = response.read().decode('utf-8').strip()
        bpy.context.window_manager.news_text = news_text
    except Exception as e:
        bpy.context.window_manager.news_text = "Failed to fetch news."
        print(f"Failed to fetch news: {e}")

def update_news_timer():
    fetch_news()
    # Reschedule every 30 minutes
    return 1800

from bpy.app.handlers import persistent
@persistent
def fetch_news_handler(dummy):
    fetch_news()

# NEW: Refresh blend file list on file load
@persistent
def refresh_blend_file_list_handler(dummy):
    try:
        bpy.ops.wm.append_collection_from_directory()
    except Exception as e:
        print("Failed to refresh blend file list on file load:", e)

# Initialize shapekey view from addon preferences for new files
@persistent
def initialize_shapekey_view_handler(dummy):
    """
    Initialize shapekey view from addon preferences for new files
    """
    scene = bpy.context.scene
    # Only set default if the property doesn't exist (new file) or is at default value
    if not hasattr(scene, 'shapekey_legacy_view'):
        try:
            prefs = bpy.context.preferences.addons[__name__].preferences
            # Invert the logic since preference tracks "use new view" but we need "use legacy view"
            scene.shapekey_legacy_view = not prefs.default_shapekey_view_new
        except:
            # Fallback to True (legacy view) if preferences can't be accessed
            scene.shapekey_legacy_view = True

# -----------------------------------------------------------------------------------------
#   Auto-Update on Startup (via timer)
# -----------------------------------------------------------------------------------------
def auto_update_on_startup():
    """
    Called once after Blender starts (via bpy.app.timers).
    If auto-update is enabled, check for an update and automatically install if available.
    """
    prefs = bpy.context.preferences.addons[__name__].preferences

    if prefs.auto_update_enabled:
        # Check for update
        bpy.ops.hhp.check_for_update()
        # If found, run update
        if prefs.update_available:
            bpy.ops.hhp.update_to_latest_version()

    # Return None so the timer doesn't re-run
    return None

# -----------------------------------------------------------------------------------------
#   Register / Unregister
# -----------------------------------------------------------------------------------------
def register():
    global custom_icons

    bpy.utils.register_class(DirectoryItem)
    bpy.utils.register_class(CollectionNameItem)
    bpy.utils.register_class(HHPCharLibraryPreferences)
    bpy.utils.register_class(HHP_UL_Directories)
    bpy.utils.register_class(HHP_UL_CollectionNames)
    bpy.utils.register_class(HHP_OT_AddDirectory)
    bpy.utils.register_class(HHP_OT_RemoveDirectory)
    bpy.utils.register_class(HHP_OT_AddCollectionName)
    bpy.utils.register_class(HHP_OT_RemoveCollectionName)
    bpy.utils.register_class(HHP_OT_AddSceneDirectory)
    bpy.utils.register_class(HHP_OT_RemoveSceneDirectory)
    bpy.utils.register_class(HHP_OT_AddSceneCollectionName)
    bpy.utils.register_class(HHP_OT_RemoveSceneCollectionName)
    bpy.utils.register_class(BlendFileItem)
    bpy.utils.register_class(APPEND_UL_BlendFileList)
    bpy.utils.register_class(HELP_MT_Menu)
    bpy.utils.register_class(HHP_OT_OpenCharPreferences)
    bpy.utils.register_class(HHPPanelModeProperty)
    bpy.utils.register_class(HHP_OT_TogglePanelModePhysics)
    bpy.utils.register_class(HHP_OT_TogglePanelModeOptimize)
    bpy.utils.register_class(HHP_OT_TogglePanelModeCustomize)
    bpy.utils.register_class(HHP_OT_TogglePanelModeRender)
    bpy.utils.register_class(HHP_OT_TogglePanelModeAnimation)
    bpy.utils.register_class(HHP_OT_TogglePanelModeDynamics)
    bpy.utils.register_class(CHAR_HHP_PT_Panel)
    bpy.utils.register_class(HHP_OT_SwapCharacter)
    bpy.utils.register_class(HHP_MT_AppendCharacterMenu)
    bpy.utils.register_class(WM_OT_CallAppendCharMenu)
    bpy.utils.register_class(WM_OT_AppendCollectionFromDirectory)
    bpy.utils.register_class(WM_OT_RenderSettingsPopup)
    bpy.utils.register_class(WM_OT_LoadBlendFileExecute)
    bpy.utils.register_class(WM_OT_LoadBlendFile)
    bpy.utils.register_class(WM_OT_OpenBlendFile)
    bpy.utils.register_class(WM_OT_AppendStudioFromFile)
    bpy.utils.register_class(WM_OT_AppendActionsFromFile)
    bpy.utils.register_class(WM_OT_CallAppendAssetsMenu)
    bpy.utils.register_class(HHP_MT_AppendAssetsMenu)
    bpy.utils.register_class(HHP_OT_CheckForUpdate)
    bpy.utils.register_class(HHP_OT_UpdateToLatestVersion)
    
    # Register the panel mode property to the scene
    bpy.types.Scene.hhp_panel_mode = bpy.props.PointerProperty(type=HHPPanelModeProperty)

    # Register submodules
    proxies_register()
    Customize_HHP.register()
    Optimize_HHP.register()
    Animation_HHP.register()
    Scene_HHP.register()
    Dynamics_HHP.register()
    Render_HHP.register()
    anim_preview.register()
    shader_sss_converter.register()
    import_facs_json.register()
    facs_shapekey_editor.register()
    light_creator.register()
    quick_menu.register()
    dynamic_pressure_canvas.register()  
    dynamic_pressure_brush.register()
    rebind_dynamic_paint.register()  # Register the new rebind operator
    append_clothing.register() # Register the new module
    modules.register()  # Register modules package

    # Collection for blend files
    bpy.types.Scene.blend_file_list = CollectionProperty(type=BlendFileItem)
    bpy.types.Scene.blend_file_list_index = IntProperty(name="Index for blend_file_list", default=-1)

    # NEW: Bypass collection names toggle (debug feature)
    bpy.types.Scene.char_bypass_collection = BoolProperty(
        name="Bypass Collection",
        description="When enabled, bypasses specified collection names and directly opens the fallback append popup for Char (HHP)",
        default=False
    )

    # Ensure default directory/collections if empty
    prefs = bpy.context.preferences.addons[__name__].preferences
    if len(prefs.directories) == 0:
        new_dir_item = prefs.directories.add()
        new_dir_item.path = ""
    if len(prefs.collection_names) == 0:
        new_col_item = prefs.collection_names.add()
        new_col_item.name = "Char (HHP)"
    
    # Ensure default scene directory/collections if empty
    if len(prefs.scene_directories) == 0:
        new_scene_dir_item = prefs.scene_directories.add()
        new_scene_dir_item.path = ""
    if len(prefs.scene_collection_names) == 0:
        new_scene_col_item = prefs.scene_collection_names.add()
        new_scene_col_item.name = "Scene (HHP)"

    # Initialize icon previews
    custom_icons = bpy.utils.previews.new()

    # News text property
    bpy.types.WindowManager.news_text = StringProperty(name="News Text", default="")
    # Temporary filepath storage for the append assets menu
    bpy.types.WindowManager.hhp_filepath_for_assets_menu = StringProperty()
    # Temporary filepath storage for the append character menu
    bpy.types.WindowManager.hhp_filepath_for_char_menu = StringProperty()
    # Internal: used to detect fallback append so swap tools can show a clear message.
    bpy.types.WindowManager.hhp_last_append_used_fallback = BoolProperty(
        name="HHP Last Append Used Fallback",
        description="Internal flag used to detect if the last append operation used the fallback append popup",
        default=False,
        options={'HIDDEN'}
    )
    bpy.types.WindowManager.hhp_last_append_fallback_reason = StringProperty(
        name="HHP Last Append Fallback Reason",
        description="Internal reason string for why fallback append was used",
        default="",
        options={'HIDDEN'}
    )

    # Start news update timer (fetch news now, then every 30 min)
    bpy.app.timers.register(update_news_timer, first_interval=1)

    # Fetch news after file load
    bpy.app.handlers.load_post.append(fetch_news_handler)
    # NEW: Also refresh the blend file list after file load
    bpy.app.handlers.load_post.append(refresh_blend_file_list_handler)
    # Initialize shapekey view from preferences after file load
    bpy.app.handlers.load_post.append(initialize_shapekey_view_handler)

    # -----------------------------------------------
    #   Schedule a one-time auto-update check
    # -----------------------------------------------
    bpy.app.timers.register(auto_update_on_startup, first_interval=1)

    # New operator for appending character blend files when no specified collection is found
    bpy.utils.register_class(WM_OT_AppendCharOptions)

def unregister():
    global custom_icons

    # Remove property group data
    del bpy.types.Scene.blend_file_list
    del bpy.types.Scene.blend_file_list_index
    del bpy.types.Scene.char_bypass_collection
    del bpy.types.Scene.hhp_panel_mode
    
    # Remove custom icons
    if custom_icons is not None:
        bpy.utils.previews.remove(custom_icons)
        custom_icons = None

    # Remove the news text property
    del bpy.types.WindowManager.news_text
    # Remove the temporary filepath storage
    if hasattr(bpy.types.WindowManager, 'hhp_filepath_for_assets_menu'):
        del bpy.types.WindowManager.hhp_filepath_for_assets_menu
    if hasattr(bpy.types.WindowManager, 'hhp_filepath_for_char_menu'):
        del bpy.types.WindowManager.hhp_filepath_for_char_menu
    if hasattr(bpy.types.WindowManager, 'hhp_last_append_used_fallback'):
        del bpy.types.WindowManager.hhp_last_append_used_fallback
    if hasattr(bpy.types.WindowManager, 'hhp_last_append_fallback_reason'):
        del bpy.types.WindowManager.hhp_last_append_fallback_reason

    # Remove the handlers
    if fetch_news_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(fetch_news_handler)
    # NEW: Remove refresh blend file list handler
    if refresh_blend_file_list_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(refresh_blend_file_list_handler)
    # Remove shapekey view initialization handler
    if initialize_shapekey_view_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(initialize_shapekey_view_handler)

    # Unregister submodules
    proxies_unregister()
    Customize_HHP.unregister()
    Optimize_HHP.unregister()
    Animation_HHP.unregister()
    Render_HHP.unregister()
    Scene_HHP.unregister()
    Dynamics_HHP.unregister()
    anim_preview.unregister()
    shader_sss_converter.unregister()
    import_facs_json.unregister()
    facs_shapekey_editor.unregister()
    light_creator.unregister()
    quick_menu.unregister()
    dynamic_pressure_canvas.unregister()  
    dynamic_pressure_brush.unregister()
    rebind_dynamic_paint.unregister()  # Unregister the new rebind operator
    append_clothing.unregister() # Unregister the new module
    modules.unregister()  # Unregister modules package

    # Unregister classes (reverse order)
    bpy.utils.unregister_class(HHP_OT_UpdateToLatestVersion)
    bpy.utils.unregister_class(HHP_OT_CheckForUpdate)
    bpy.utils.unregister_class(WM_OT_AppendActionsFromFile)
    bpy.utils.unregister_class(WM_OT_AppendStudioFromFile)
    bpy.utils.unregister_class(WM_OT_OpenBlendFile)
    bpy.utils.unregister_class(WM_OT_LoadBlendFile)
    bpy.utils.unregister_class(WM_OT_LoadBlendFileExecute)
    bpy.utils.unregister_class(WM_OT_RenderSettingsPopup)
    bpy.utils.unregister_class(WM_OT_AppendCollectionFromDirectory)
    bpy.utils.unregister_class(CHAR_HHP_PT_Panel)
    bpy.utils.unregister_class(WM_OT_CallAppendCharMenu)
    bpy.utils.unregister_class(HHP_MT_AppendCharacterMenu)
    bpy.utils.unregister_class(HHP_OT_SwapCharacter)
    bpy.utils.unregister_class(HHP_OT_TogglePanelModeDynamics)
    bpy.utils.unregister_class(HHP_OT_TogglePanelModeAnimation)
    bpy.utils.unregister_class(HHP_OT_TogglePanelModeRender)
    bpy.utils.unregister_class(HHP_OT_TogglePanelModeCustomize)
    bpy.utils.unregister_class(HHP_OT_TogglePanelModeOptimize)
    bpy.utils.unregister_class(HHP_OT_TogglePanelModePhysics)
    bpy.utils.unregister_class(HHPPanelModeProperty)
    bpy.utils.unregister_class(HHP_OT_OpenCharPreferences)
    bpy.utils.unregister_class(HELP_MT_Menu)
    bpy.utils.unregister_class(APPEND_UL_BlendFileList)
    bpy.utils.unregister_class(BlendFileItem)
    bpy.utils.unregister_class(HHP_OT_RemoveSceneCollectionName)
    bpy.utils.unregister_class(HHP_OT_AddSceneCollectionName)
    bpy.utils.unregister_class(HHP_OT_RemoveSceneDirectory)
    bpy.utils.unregister_class(HHP_OT_AddSceneDirectory)
    bpy.utils.unregister_class(HHP_OT_RemoveCollectionName)
    bpy.utils.unregister_class(HHP_OT_AddCollectionName)
    bpy.utils.unregister_class(HHP_OT_RemoveDirectory)
    bpy.utils.unregister_class(HHP_OT_AddDirectory)
    bpy.utils.unregister_class(HHP_OT_AddCollectionName)
    bpy.utils.unregister_class(HHP_OT_RemoveCollectionName)
    bpy.utils.unregister_class(HHP_OT_AddDirectory)
    bpy.utils.unregister_class(HHP_OT_AddSceneDirectory)
    bpy.utils.unregister_class(HHP_OT_RemoveSceneDirectory)
    bpy.utils.unregister_class(HHP_OT_AddSceneCollectionName)
    bpy.utils.unregister_class(HHP_OT_RemoveSceneCollectionName)
    bpy.utils.unregister_class(HHP_OT_RemoveCollectionName)
    bpy.utils.unregister_class(HHP_OT_AddCollectionName)
    bpy.utils.unregister_class(HHP_OT_RemoveDirectory)
    bpy.utils.unregister_class(HHP_OT_AddDirectory)
    bpy.utils.unregister_class(HHP_UL_CollectionNames)
    bpy.utils.unregister_class(HHP_UL_Directories)
    bpy.utils.unregister_class(HHPCharLibraryPreferences)
    bpy.utils.unregister_class(CollectionNameItem)
    bpy.utils.unregister_class(DirectoryItem)

    # Remove the new operator
    bpy.utils.unregister_class(WM_OT_AppendCharOptions)

    # Remove the operator for calling the menu and the menu itself
    bpy.utils.unregister_class(WM_OT_CallAppendAssetsMenu)

# -----------------------------------------------------------------------------------------
#   Help Menu
# -----------------------------------------------------------------------------------------
class HELP_MT_Menu(bpy.types.Menu):
    bl_idname = "HELP_MT_menu"
    bl_label = "Help and Tutorials"   # Tooltip description for the dropdown.
    
    def draw(self, context):
        layout = self.layout
        layout.operator("wm.url_open", text="Setup", icon='HELP').url = HELP_INSTALLATION_URL
        layout.operator("wm.url_open", text="Setup Video", icon='HELP').url = bl_info["doc_url"]
        layout.separator()
        layout.operator("wm.url_open", text="Basics", icon='HELP').url = BASICS_URL
        layout.operator("wm.url_open", text="All Char Library Tutorials", icon='URL').url = ALL_TUTORIALS_URL

# -----------------------------------------------------------------------------------------
#   Open Preferences Operators
# -----------------------------------------------------------------------------------------
class HHP_OT_OpenCharPreferences(Operator):
    bl_idname = "hhp.open_char_preferences"
    bl_label = "Character Preferences"
    bl_description = "Open addon preferences and switch to Character mode"
    
    def execute(self, context):
        # Switch to character mode first
        prefs = context.preferences.addons[__name__].preferences
        prefs.mode = 'CHARACTER'
        
        # Then open preferences
        bpy.ops.preferences.addon_show(module=__name__)
        return {'FINISHED'}

# Operator to toggle panel modes - separate classes for each mode
class HHP_OT_TogglePanelModePhysics(bpy.types.Operator):
    bl_idname = "hhp.toggle_panel_mode_physics"
    bl_label = "Physics / Proxies"
    bl_description = "Physics / Proxies - Manage character physics and proxies"
    
    def execute(self, context):
        if context.scene.hhp_panel_mode.selected_panel == 'PROXIES':
            # If clicking the same mode again, turn it off
            context.scene.hhp_panel_mode.selected_panel = 'NONE'
        else:
            # Otherwise, switch to the clicked mode
            context.scene.hhp_panel_mode.selected_panel = 'PROXIES'
        return {'FINISHED'}

class HHP_OT_TogglePanelModeOptimize(bpy.types.Operator):
    bl_idname = "hhp.toggle_panel_mode_optimize"
    bl_label = "Optimize / Tools"
    bl_description = "Tools for optimizing character performance and general purpose tools"
    
    def execute(self, context):
        if context.scene.hhp_panel_mode.selected_panel == 'OPTIMIZE':
            # If clicking the same mode again, turn it off
            context.scene.hhp_panel_mode.selected_panel = 'NONE'
        else:
            # Otherwise, switch to the clicked mode
            context.scene.hhp_panel_mode.selected_panel = 'OPTIMIZE'
        return {'FINISHED'}

class HHP_OT_TogglePanelModeCustomize(bpy.types.Operator):
    bl_idname = "hhp.toggle_panel_mode_customize"
    bl_label = "Customize"
    bl_description = "Customize - Character customization options"
    
    def execute(self, context):
        if context.scene.hhp_panel_mode.selected_panel == 'CUSTOMIZE':
            # If clicking the same mode again, turn it off
            context.scene.hhp_panel_mode.selected_panel = 'NONE'
        else:
            # Otherwise, switch to the clicked mode
            context.scene.hhp_panel_mode.selected_panel = 'CUSTOMIZE'
        return {'FINISHED'}

class HHP_OT_TogglePanelModeRender(bpy.types.Operator):
    bl_idname = "hhp.toggle_panel_mode_render"
    bl_label = "Render / Lighting"
    bl_description = "Render / Lighting - Render settings and lighting controls"
    
    def execute(self, context):
        if context.scene.hhp_panel_mode.selected_panel == 'RENDER':
            # If clicking the same mode again, turn it off
            context.scene.hhp_panel_mode.selected_panel = 'NONE'
        else:
            # Otherwise, switch to the clicked mode
            context.scene.hhp_panel_mode.selected_panel = 'RENDER'
        return {'FINISHED'}

class HHP_OT_TogglePanelModeAnimation(bpy.types.Operator):
    bl_idname = "hhp.toggle_panel_mode_animation"
    bl_label = "Animation"
    bl_description = "Animation - Animation controls and tools"
    
    def execute(self, context):
        if context.scene.hhp_panel_mode.selected_panel == 'ANIMATION':
            # If clicking the same mode again, turn it off
            context.scene.hhp_panel_mode.selected_panel = 'NONE'
        else:
            # Otherwise, switch to the clicked mode
            context.scene.hhp_panel_mode.selected_panel = 'ANIMATION'
        return {'FINISHED'}

# Original toggle panel mode operator - keep for backward compatibility
class HHP_OT_TogglePanelMode(bpy.types.Operator):
    bl_idname = "hhp.toggle_panel_mode"
    bl_label = "Toggle Panel Mode"
    bl_description = "Toggle between different panel modes"
    
    mode: bpy.props.StringProperty()
    description: bpy.props.StringProperty(default="")
    
    def execute(self, context):
        if context.scene.hhp_panel_mode.selected_panel == self.mode:
            # If clicking the same mode again, turn it off
            context.scene.hhp_panel_mode.selected_panel = 'NONE'
        else:
            # Otherwise, switch to the clicked mode
            context.scene.hhp_panel_mode.selected_panel = self.mode
        return {'FINISHED'}

# New operator for appending character blend files when no specified collection is found
class WM_OT_AppendCharOptions(Operator):
    bl_idname = 'wm.append_char_options'
    bl_label = 'Append Options'
    bl_description = 'Choose what to append from the blend file for Character HHP'
    bl_options = {'REGISTER', 'INTERNAL'}

    filepath: StringProperty(subtype="FILE_PATH")

    action: EnumProperty(
        items=[
            ('ROOT_COLLECTION', 'Append Root Collection', 'Append the root collection with its full hierarchy intact', 'FILE_VOLUME', 0),
            ('SELECT_COLLECTIONS', 'User Selection', 'Select specific collections to append', 'RESTRICT_SELECT_OFF', 1)
        ],
        name="Action",
        description="What to append from the blend file",
        default='ROOT_COLLECTION'
    )

    def invoke(self, context, event):
        # Clear any previous collection selection lists
        context.scene.scene_available_collections.clear()
        context.scene.scene_selected_collections.clear()
        if os.path.exists(self.filepath):
            with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
                for name in data_from.collections:
                    item = context.scene.scene_available_collections.add()
                    item.name = name
        return context.window_manager.invoke_props_dialog(self, width=500)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Specified collection names not found in file.")
        layout.label(text="What would you like to append?")
        layout.prop(self, "action", expand=True)
        if self.action == 'SELECT_COLLECTIONS':
            layout.separator()
            row = layout.row()
            # Left column: Available collections
            left_col = row.column()
            left_col.label(text=f"Available Collections: {len(context.scene.scene_available_collections)}")
            button_row = left_col.row(align=True)
            button_row.operator('wm.add_all_collections', text="Add All")
            button_row.operator('wm.add_collection', text="Add >>")
            left_col.template_list(
                "SCENE_UL_AvailableCollections", "", 
                context.scene, "scene_available_collections", 
                context.scene, "scene_available_collections_index", 
                rows=9
            )
            # Right column: Selected collections
            right_col = row.column()
            right_col.label(text=f"Selected Collections: {len(context.scene.scene_selected_collections)}")
            button_row = right_col.row(align=True)
            button_row.operator('wm.remove_collection', text="<< Remove")
            button_row.operator('wm.remove_all_collections', text="Remove All")
            right_col.template_list(
                "SCENE_UL_SelectedCollections", "", 
                context.scene, "scene_selected_collections", 
                context.scene, "scene_selected_collections_index", 
                rows=9
            )

    def execute(self, context):
        if not self.filepath or not os.path.exists(self.filepath):
            self.report({'ERROR'}, "Selected file does not exist")
            return {'CANCELLED'}

        # Create a main collection for the character append
        main_collection = None
        base_collection_name = "Char (F)"
        collection_name = base_collection_name

        if base_collection_name in bpy.data.collections:
            counter = 1
            while True:
                numbered_name = f"{base_collection_name}.{counter:03d}"
                if numbered_name not in bpy.data.collections:
                    collection_name = numbered_name
                    break
                counter += 1

        main_collection = bpy.data.collections.new(collection_name)
        # Set the collection color for Char HHP to COLOR_01
        main_collection.color_tag = 'COLOR_01'
        context.scene.collection.children.link(main_collection)

        if self.action == 'ROOT_COLLECTION':
            # Append the scene to gain access to its root collection
            original_scenes = set(bpy.data.scenes.keys())
            with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
                if data_from.scenes:
                    data_to.scenes = [data_from.scenes[0]]
            new_scenes = [scene for scene in bpy.data.scenes if scene.name not in original_scenes]
            if not new_scenes:
                self.report({'WARNING'}, "Could not append scene from file")
                return {'CANCELLED'}
            appended_scene = new_scenes[0]
            collections_to_copy = list(appended_scene.collection.children)
            objects_to_copy = list(appended_scene.collection.objects)

            for collection in collections_to_copy:
                if collection.name not in main_collection.children:
                    main_collection.children.link(collection)
            for obj in objects_to_copy:
                if obj.name not in main_collection.objects:
                    main_collection.objects.link(obj)

            bpy.data.scenes.remove(appended_scene)
            self.report({'INFO'}, f"Appended {len(collections_to_copy)} collections and {len(objects_to_copy)} loose objects to '{collection_name}'")

            # Flag all worlds as fake users
            for world_item in bpy.data.worlds:
                world_item.use_fake_user = True
            self.report({'INFO'}, f"All {len(bpy.data.worlds)} current worlds flagged as fake user.")

        else:  # 'SELECT_COLLECTIONS'
            if len(context.scene.scene_selected_collections) == 0:
                self.report({'WARNING'}, "No collections selected")
                return {'CANCELLED'}
            collection_names = [item.name for item in context.scene.scene_selected_collections]
            with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
                data_to.collections = [name for name in data_from.collections if name in collection_names]
            for collection in data_to.collections:
                if collection is not None:
                    main_collection.children.link(collection)
            self.report({'INFO'}, f"Appended {len(data_to.collections)} selected collections to '{collection_name}'")

        # After appending (either mode), clear preview animation on armatures inside the new main collection (if enabled)
        prefs = bpy.context.preferences.addons[__name__].preferences
        if prefs.clear_preview_on_append:
            try:
                for arm in _iter_armatures_in_collection(main_collection):
                    clear_preview_animation(arm)
            except Exception:
                pass
        return {'FINISHED'}

# New operator for the Dynamics panel
class HHP_OT_TogglePanelModeDynamics(bpy.types.Operator):
    bl_idname = "hhp.toggle_panel_mode_dynamics"
    bl_label = "Dynamics / Fluids"
    bl_description = "Dynamics - Control things like fluid effects, dynamic paint, dynamic deformation, destruction, etc... related to HHP based characters"
    
    def execute(self, context):
        if context.scene.hhp_panel_mode.selected_panel == 'DYNAMICS':
            # If clicking the same mode again, turn it off
            context.scene.hhp_panel_mode.selected_panel = 'NONE'
        else:
            # Otherwise, switch to the clicked mode
            context.scene.hhp_panel_mode.selected_panel = 'DYNAMICS'
        return {'FINISHED'}

# New menu for appending assets
class HHP_MT_AppendAssetsMenu(bpy.types.Menu):
    bl_idname = "HHP_MT_APPEND_ASSETS_MENU" # Changed bl_idname to be more unique
    bl_label = "Append Assets"

    def draw(self, context):
        layout = self.layout
        # Retrieve the filepath from the WindowManager
        filepath = getattr(context.window_manager, 'hhp_filepath_for_assets_menu', "") # Safer getattr

        col = layout.column(align=True)

        # Append Studio button
        append_studio_op = col.operator('wm.append_studio_from_file', text="Append Studio/World", icon='RENDER_STILL')
        append_studio_op.filepath = filepath

        # Append Animation/Poses button - Ensure its invoke() method is called
        current_op_context = layout.operator_context
        layout.operator_context = 'INVOKE_DEFAULT' # Set context before operator
        append_animation_op = col.operator('wm.append_actions_from_file', text="Append Animation/Poses", icon='ACTION')
        append_animation_op.filepath = filepath
        layout.operator_context = current_op_context # Restore context after operator

        # Separator before clothing button
        col.separator()

        # Append Clothing & Accessories button
        append_clothing_op = col.operator(append_clothing.WM_OT_AppendClothing.bl_idname, text="Append Clothing & Accessories", icon='MOD_CLOTH')
        append_clothing_op.filepath = filepath

# Operator to call the Append Assets Menu
class WM_OT_CallAppendAssetsMenu(Operator):
    bl_idname = "wm.call_hhp_append_assets_menu"
    bl_label = "Append Assets..."
    bl_description = "Choose additional assets to append"
    bl_options = {'REGISTER'}

    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        # Store the filepath in the WindowManager for the menu to access
        context.window_manager.hhp_filepath_for_assets_menu = self.filepath
        # Call the menu
        bpy.ops.wm.call_menu(name=HHP_MT_AppendAssetsMenu.bl_idname)
        return {'FINISHED'}


# Menu for character append / swap options
class HHP_MT_AppendCharacterMenu(bpy.types.Menu):
    bl_idname = "HHP_MT_APPEND_CHAR_MENU"
    bl_label = "Append Character Options"

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        filepath = getattr(wm, 'hhp_filepath_for_char_menu', "")

        col = layout.column(align=True)

        # Standard append character option
        append_op = col.operator(
            WM_OT_LoadBlendFile.bl_idname,
            text="Append Character",
            icon='COLLECTION_COLOR_01'
        )
        append_op.filepath = filepath
        append_op.append_mode = 'CHARACTER'

        col.separator()

        # Swap character animation option: append and then open Animation Transfer +
        swap_op = col.operator(
            "hhp.swap_character",
            text="Swap Character Animation",
            icon='MOD_DATA_TRANSFER'
        )
        swap_op.filepath = filepath


# Operator to call the Append Character Menu
class WM_OT_CallAppendCharMenu(Operator):
    bl_idname = "wm.call_hhp_append_char_menu"
    bl_label = "Append Character"
    bl_description = "Choose whether to append the character normally or swap with animation transfer"
    bl_options = {'REGISTER'}

    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        # Store the filepath in the WindowManager for the menu to access
        context.window_manager.hhp_filepath_for_char_menu = self.filepath
        # Call the menu
        bpy.ops.wm.call_menu(name=HHP_MT_AppendCharacterMenu.bl_idname)
        return {'FINISHED'}


class HHP_OT_SwapCharacter(Operator):
    bl_idname = "hhp.swap_character"
    bl_label = "Swap Character Animation"
    bl_description = "Append the selected character and open Animation Transfer + to swap animation from the active HHP mesh"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        # Validate active mesh as HHP mesh
        source_mesh = context.active_object
        if not (
            source_mesh is not None
            and source_mesh.type == 'MESH'
            and "Genesis8Female.Shape" in source_mesh.name
            and getattr(source_mesh.data, "name", None) is not None
            and "Genesis8Female" in source_mesh.data.name
        ):
            self.report({'INFO'}, "Select the HHP character mesh before using Swap Character.")
            return {'CANCELLED'}

        # Ensure we have a filepath; if not, try to pull it from the current blend list selection
        if not self.filepath:
            blend_list = context.scene.blend_file_list
            idx = context.scene.blend_file_list_index
            if 0 <= idx < len(blend_list):
                self.filepath = blend_list[idx].file_path

        if not self.filepath:
            self.report({'ERROR'}, "No character blend file selected")
            return {'CANCELLED'}

        # Reset the internal fallback tracking flag before appending.
        if hasattr(context.window_manager, "hhp_last_append_used_fallback"):
            context.window_manager.hhp_last_append_used_fallback = False
        if hasattr(context.window_manager, "hhp_last_append_fallback_reason"):
            context.window_manager.hhp_last_append_fallback_reason = ""

        # Append the new character using the existing append pipeline
        bpy.ops.wm.load_blend_file_execute(
            filepath=self.filepath,
            append_mode='CHARACTER'
        )

        # If the append pipeline went into the fallback append popup, stop here and tell the user.
        if getattr(context.window_manager, "hhp_last_append_used_fallback", False):
            self.report(
                {'WARNING'},
                "Character swap cannot be done using fallback append / non-HHP characters. "
                "Append an HHP character normally (Char (HHP) collection) and try again."
            )
            return {'CANCELLED'}

        # After append, the appended character mesh should be the active object
        target_mesh = context.active_object
        if target_mesh == source_mesh:
            # Safety net: if active object didn't change, assume append didn't create/select a new HHP target.
            self.report(
                {'WARNING'},
                "Character swap could not start because the appended character was not detected. "
                "This can happen on fallback append / non-HHP characters."
            )
            return {'CANCELLED'}
        if not (
            target_mesh is not None
            and target_mesh.type == 'MESH'
            and "Genesis8Female.Shape" in target_mesh.name
        ):
            self.report(
                {'ERROR'},
                "Could not find the appended HHP character mesh to use as swap target"
            )
            return {'CANCELLED'}

        # Prepare selection for mesh-based Animation Transfer +
        bpy.ops.object.select_all(action='DESELECT')
        source_mesh.select_set(True)
        target_mesh.select_set(True)
        context.view_layer.objects.active = source_mesh

        # Invoke the existing Animation Transfer + popup in mesh mode
        result = bpy.ops.hhp.bs_anim_transfer('INVOKE_DEFAULT')
        if result != {'FINISHED'} and result != {'RUNNING_MODAL'}:
            # If the operator was cancelled or failed, report but keep appended character
            self.report({'INFO'}, "Animation Transfer + was cancelled or did not start")

        return {'FINISHED'}

if __name__ == "__main__":
    register()
