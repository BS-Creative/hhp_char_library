bl_info = {
    "name": "(BS) Custom | HHP Char Library",
    "author": "Bulging Senpai",
    "description": "Bulging senpai's character library",
    "blender": (3, 0, 0),
    "version": (1, 8, 7),
    "location": "",
    "warning": "",
    "doc_url": "https://www.patreon.com/posts/character-addon-113747469",
    "tracker_url": "",
    "category": "3D View"
}

# -----------------------------------------------------------------------------------------
#   Update URLs
#   Make sure these URLs actually exist in your repo. For example, you must have:
#   - hhp_char_library.zip committed in the repo
#   - version.txt with "1.6.5" or higher to test updates, etc.
# -----------------------------------------------------------------------------------------
UPDATE_ZIP_URL = "https://github.com/BS-Creative/hhp_char_library/raw/main/hhp_char_library.zip"
VERSION_URL = "https://raw.githubusercontent.com/BS-Creative/hhp_char_library/main/version.txt"
GET_CHARACTERS_URL = "https://www.patreon.com/collection/785672?view=condensed"
NEWS_URL = "https://raw.githubusercontent.com/BS-Creative/hhp_char_library/main/news.txt"

from .Proxies_HHP import register as proxies_register
from .Proxies_HHP import unregister as proxies_unregister
from . import Customize_HHP
from . import Optimize_HHP
## Removed Clothing_HHP import (its functionality is now moved into Customize_HHP)
from . import Creator_Tools_HHP
from .modules import anim_preview
from .modules import shader_sss_converter

import bpy
import os
import bpy.utils.previews
from bpy.types import (
    Operator,
    Panel,
    AddonPreferences,
    PropertyGroup,
    UIList
)
from bpy.props import (
    StringProperty,
    CollectionProperty,
    IntProperty,
    BoolProperty,
    FloatProperty
)

import time
import threading

# -----------------------------------------------------------------------------------------
#   Global variable to store custom icons
# -----------------------------------------------------------------------------------------
custom_icons = None

# -----------------------------------------------------------------------------------------
#   Addon Preferences
# -----------------------------------------------------------------------------------------
class DirectoryItem(PropertyGroup):
    path: StringProperty(
        name="Path",
        subtype='DIR_PATH',
        default=""
    )

class CollectionNameItem(PropertyGroup):
    name: StringProperty(
        name="Collection Name",
        default="Char (HHP)"
    )

class HHPCharLibraryPreferences(AddonPreferences):
    bl_idname = __name__

    directories: CollectionProperty(type=DirectoryItem)
    active_directory_index: IntProperty()

    collection_names: CollectionProperty(type=CollectionNameItem)
    active_collection_index: IntProperty()

    auto_update_enabled: BoolProperty(
        name="Auto Update",
        default=True,
        description="Enable automatic addon update once on Blender startup"
    )

    # Removed the old update_frequency / last_update_check to simplify logic

    update_available: BoolProperty(
        name="Update Available",
        default=False,
        description="Is an update available"
    )

    def draw(self, context):
        layout = self.layout

        # Directories UI
        row = layout.row()
        row.template_list(
            "HHP_UL_Directories", "",
            self, "directories",
            self, "active_directory_index"
        )

        col = row.column(align=True)
        col.operator("hhp.add_directory", icon='ADD', text="")
        col.operator("hhp.remove_directory", icon='REMOVE', text="")

        layout.label(text="Collection Names to Append:")
        row = layout.row()
        row.template_list(
            "HHP_UL_CollectionNames", "",
            self, "collection_names",
            self, "active_collection_index"
        )

        col = row.column(align=True)
        col.operator("hhp.add_collection_name", icon='ADD', text="")
        col.operator("hhp.remove_collection_name", icon='REMOVE', text="")

        layout.separator()
        layout.label(text="Update Options:")
        layout.prop(self, "auto_update_enabled")

        # Manual check button
        layout.operator("hhp.check_for_update", text="Check for Update")

        # "Update to latest version" appears if update_available is True
        if self.update_available:
            layout.operator("hhp.update_to_latest_version", text="Update to Latest Version")

# -----------------------------------------------------------------------------------------
#   UI Lists
# -----------------------------------------------------------------------------------------
class HHP_UL_Directories(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.prop(item, "path", text="Directory", emboss=True)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.prop(item, "path", text="", emboss=False)

class HHP_UL_CollectionNames(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.prop(item, "name", text="Collection Name", emboss=True)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.prop(item, "name", text="", emboss=False)

# -----------------------------------------------------------------------------------------
#   Directory & Collection Name Operators
# -----------------------------------------------------------------------------------------
class HHP_OT_AddDirectory(Operator):
    bl_idname = "hhp.add_directory"
    bl_label = "Add Directory"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        new_item = preferences.directories.add()
        new_item.path = ""
        preferences.active_directory_index = len(preferences.directories) - 1
        return {'FINISHED'}

class HHP_OT_RemoveDirectory(Operator):
    bl_idname = "hhp.remove_directory"
    bl_label = "Remove Directory"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        preferences.directories.remove(preferences.active_directory_index)
        preferences.active_directory_index = min(
            max(0, preferences.active_directory_index - 1),
            len(preferences.directories) - 1
        )
        return {'FINISHED'}

class HHP_OT_AddCollectionName(Operator):
    bl_idname = "hhp.add_collection_name"
    bl_label = "Add Collection Name"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        new_item = preferences.collection_names.add()
        new_item.name = "Char (HHP)"
        preferences.active_collection_index = len(preferences.collection_names) - 1
        return {'FINISHED'}

class HHP_OT_RemoveCollectionName(Operator):
    bl_idname = "hhp.remove_collection_name"
    bl_label = "Remove Collection Name"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        preferences.collection_names.remove(preferences.active_collection_index)
        preferences.active_collection_index = min(
            max(0, preferences.active_collection_index - 1),
            len(preferences.collection_names) - 1
        )
        return {'FINISHED'}

# -----------------------------------------------------------------------------------------
#   Utility Functions
# -----------------------------------------------------------------------------------------
def get_most_recent_blend_files(directories):
    """Find the most recent .blend file in each top-level subfolder of the given directories."""
    blend_files = {}
    for directory in directories:
        abs_dir = bpy.path.abspath(directory.path)  # Convert relative path to an absolute path
        if os.path.isdir(abs_dir):
            for subfolder in os.listdir(abs_dir):
                subfolder_path = os.path.join(abs_dir, subfolder)
                if os.path.isdir(subfolder_path):
                    recent_file = None
                    recent_time = -1
                    for file in os.listdir(subfolder_path):
                        if file.endswith(".blend") and not file.startswith("._"):
                            file_path = os.path.join(subfolder_path, file)
                            try:
                                file_time = os.path.getmtime(file_path)
                                if file_time > recent_time:
                                    recent_time = file_time
                                    recent_file = file_path
                            except Exception as e:
                                print(f"Error accessing file {file_path}: {e}")
                    if recent_file:
                        blend_files[subfolder] = recent_file
    return blend_files

def append_collections(filepath, collection_names):
    """Append the specified collections from a .blend file."""
    filepath = bpy.path.abspath(filepath)  # Convert relative path to absolute
    if not filepath:
        print("File path is empty. Please set the path in Addon Preferences.")
        return []
    appended_collections = []
    try:
        with bpy.data.libraries.load(filepath, link=False) as (data_from, data_to):
            collections_to_append = [
                citem.name for citem in collection_names
                if citem.name in data_from.collections
            ]
            data_to.collections = collections_to_append

        if data_to.collections:
            for collection in data_to.collections:
                if collection is not None:
                    bpy.context.scene.collection.children.link(collection)
                    appended_collections.append(collection)
                    bpy.ops.object.select_all(action='DESELECT')
                    for obj in collection.objects:
                        obj.select_set(True)
                    bpy.context.view_layer.objects.active = collection.objects[0]
    except Exception as e:
        print(f"Error appending collections from {filepath}: {e}")

    return appended_collections

def load_thumbnails(blend_files):
    """Load thumbnails for each subfolder's .blend file (from thumbnail.png or the .blend itself)."""
    global custom_icons
    thumbnails = {}
    for subfolder, file_path in blend_files.items():
        try:
            blend_dir = os.path.dirname(file_path)
            thumbnail_png_path = os.path.join(blend_dir, 'thumbnail.png')
            if os.path.isfile(thumbnail_png_path):
                thumb = custom_icons.load(file_path, thumbnail_png_path, 'IMAGE')
            else:
                thumb = custom_icons.load(file_path, file_path, 'BLEND')
            thumbnails[file_path] = thumb
        except Exception as e:
            print(f"Error loading thumbnail for {file_path}: {e}")
    return thumbnails

# -----------------------------------------------------------------------------------------
#   Property Group for Blend Files
# -----------------------------------------------------------------------------------------
class BlendFileItem(PropertyGroup):
    name: StringProperty()
    file_path: StringProperty()
    icon_id: IntProperty()

# -----------------------------------------------------------------------------------------
#   UIList for Blend Files
# -----------------------------------------------------------------------------------------
class APPEND_UL_BlendFileList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        blend_file = item
        display_name = blend_file.name.replace('.blend', '')
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.label(text=display_name, icon_value=blend_file.icon_id)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon_value=blend_file.icon_id)

# -----------------------------------------------------------------------------------------
#   Main Panel
# -----------------------------------------------------------------------------------------
class CHAR_HHP_PT_Panel(Panel):
    bl_label = "Char (HHP)"
    bl_idname = "CHAR_HHP_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__name__].preferences

        # News
        layout.label(text="News: " + context.window_manager.news_text, icon='WORLD')

        # Buttons
        box = layout.box()
        row = box.row(align=True)

        if prefs.update_available:
            row.operator("hhp.update_to_latest_version", text="Update", icon='FILE_REFRESH')
        else:
            row.operator("hhp.check_for_update", text="Check for Update")

        row.operator('wm.append_collection_from_directory', text="Refresh List")
        row.operator("wm.url_open", text="Get Characters", icon='ARMATURE_DATA').url = GET_CHARACTERS_URL

        # Blend file list
        layout.template_list(
            "APPEND_UL_BlendFileList", "",
            context.scene, "blend_file_list",
            context.scene, "blend_file_list_index"
        )

        if context.scene.blend_file_list_index >= 0 and context.scene.blend_file_list:
            blend_file = context.scene.blend_file_list[context.scene.blend_file_list_index]
            row = layout.row()
            row.template_icon(blend_file.icon_id, scale=6)

            # Top 2 buttons
            button_box = layout.box()
            buttons_row = button_box.row(align=True)
            open_button = buttons_row.operator('wm.open_blend_file', text="Open", icon='FILE_FOLDER')
            open_button.filepath = blend_file.file_path

            append_button = buttons_row.operator('wm.load_blend_file', text="Append Selected File")
            append_button.filepath = blend_file.file_path

            # Bottom 2 buttons
            bottom_row = layout.row(align=True)
            append_studio_button = bottom_row.operator(
                'wm.append_studio_from_file',
                text="Append Studio",
                icon='RENDER_STILL'
            )
            append_studio_button.filepath = blend_file.file_path

            append_actions_button = bottom_row.operator(
                'wm.append_actions_from_file',
                text="Append animation library",
                icon='ACTION'
            )
            append_actions_button.filepath = blend_file.file_path

            # Only show the preset selector if the active mesh's data name contains "Genesis8Female"
            if (context.active_object and context.active_object.type == 'MESH'
                    and context.active_object.data and "Genesis8Female" in context.active_object.data.name
                    and "Deform Proxy" not in context.active_object.name):
                preset_box = layout.box()
                preset_box.label(text="Selected Preset:")
                preset_row = preset_box.row(align=True)
                preset_row.prop(context.active_object, "active_preset", text="")

            # Add the anim preview box here, after the append buttons
            anim_preview.draw_anim_preview_box(layout, context)

# -----------------------------------------------------------------------------------------
#   Operators to Load/Append from .blend
# -----------------------------------------------------------------------------------------
class WM_OT_AppendCollectionFromDirectory(Operator):
    bl_idname = 'wm.append_collection_from_directory'
    bl_label = 'Refresh List'
    bl_description = 'Refresh the list of blend files from the directories'
    thumbnails = None

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        recent_blend_files = get_most_recent_blend_files(prefs.directories)

        global custom_icons
        custom_icons.clear()

        self.thumbnails = load_thumbnails(recent_blend_files)

        sorted_blend_files = sorted(recent_blend_files.items(), key=lambda item: item[0])

        context.scene.blend_file_list.clear()
        for subfolder, file_path in sorted_blend_files:
            icon_id = self.thumbnails[file_path].icon_id if file_path in self.thumbnails else 0
            display_name = subfolder
            new_item = context.scene.blend_file_list.add()
            new_item.name = display_name
            new_item.file_path = file_path
            new_item.icon_id = icon_id

        return {'FINISHED'}

class WM_OT_LoadBlendFile(Operator):
    bl_idname = 'wm.load_blend_file'
    bl_label = 'Load Blend File'
    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences

        # Append the collections
        appended_collections = append_collections(self.filepath, prefs.collection_names)

        # Switch to Object mode and deselect all
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')

        # Attempt to select an Armature in the appended collections
        for collection in appended_collections:
            for obj in collection.objects:
                if obj.type == 'ARMATURE':
                    obj.select_set(True)
                    bpy.context.view_layer.objects.active = obj
                    obj.data.pose_position = 'POSE'
                    break
        return {'FINISHED'}

class WM_OT_AppendStudioFromFile(Operator):
    bl_idname = 'wm.append_studio_from_file'
    bl_label = 'Append Studio'
    bl_description = 'Append the "Studio and lights" collection from the selected file'

    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        collection_name = "Studio and lights"
        try:
            abs_filepath = bpy.path.abspath(self.filepath)
            with bpy.data.libraries.load(abs_filepath, link=False) as (data_from, data_to):
                if collection_name in data_from.collections:
                    data_to.collections = [collection_name]
                else:
                    self.report({'WARNING'}, f'Collection "{collection_name}" not found in {abs_filepath}')
                    return {'CANCELLED'}
            for collection in data_to.collections:
                if collection is not None:
                    bpy.context.scene.collection.children.link(collection)
                    # Make the collection visible, enabled in viewport and render
                    collection.hide_viewport = False
                    collection.hide_render = False
            self.report({'INFO'}, f'Appended "{collection_name}" from {abs_filepath}')
        except Exception as e:
            self.report({'ERROR'}, f'Error appending "{collection_name}": {e}')
        return {'FINISHED'}

class WM_OT_AppendActionsFromFile(Operator):
    bl_idname = 'wm.append_actions_from_file'
    bl_label = 'Append Animation Library'
    bl_description = 'Append all actions from the selected file and flag them as fake user'
    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        try:
            abs_filepath = bpy.path.abspath(self.filepath)
            with bpy.data.libraries.load(abs_filepath, link=False) as (data_from, data_to):
                data_to.actions = data_from.actions[:]
            for action in data_to.actions:
                if action is not None:
                    action.use_fake_user = True
            self.report({'INFO'}, f'Appended {len(data_to.actions)} actions from {abs_filepath}')
        except Exception as e:
            self.report({'ERROR'}, f"Error appending actions: {e}")
        return {'FINISHED'}

class WM_OT_OpenBlendFile(Operator):
    bl_idname = 'wm.open_blend_file'
    bl_label = 'Open Blend File'
    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        bpy.ops.wm.open_mainfile(filepath=bpy.path.abspath(self.filepath))
        return {'FINISHED'}

# -----------------------------------------------------------------------------------------
#   Update Check Operators
# -----------------------------------------------------------------------------------------
class HHP_OT_CheckForUpdate(Operator):
    bl_idname = "hhp.check_for_update"
    bl_label = "Check for Update"
    bl_description = "Check if a new version is available"

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        try:
            # Compare local vs remote version
            current_version = bl_info['version']
            import urllib.request
            response = urllib.request.urlopen(VERSION_URL)
            latest_version_str = response.read().decode('utf-8').strip()
            latest_version = tuple(map(int, latest_version_str.split('.')))

            if latest_version > current_version:
                prefs.update_available = True
                self.report({'INFO'}, f"Update available! New version: {latest_version}")
            else:
                prefs.update_available = False
                self.report({'INFO'}, "Addon is up to date.")
        except Exception as e:
            prefs.update_available = False
            self.report({'ERROR'}, f"Failed to check for updates: {e}")

        return {'FINISHED'}

class HHP_OT_UpdateToLatestVersion(Operator):
    bl_idname = "hhp.update_to_latest_version"
    bl_label = "Update to Latest Version"
    bl_description = "Update the addon to the latest version"

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        try:
            import urllib.request
            import tempfile
            import zipfile
            import shutil

            tmp_dir = tempfile.mkdtemp()
            zip_path = os.path.join(tmp_dir, "update.zip")
            urllib.request.urlretrieve(UPDATE_ZIP_URL, zip_path)

            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(tmp_dir)

            # Find the extracted addon folder
            addon_folder_name = None
            for item in os.listdir(tmp_dir):
                if os.path.isdir(os.path.join(tmp_dir, item)):
                    addon_folder_name = item
                    break

            if not addon_folder_name:
                self.report({'ERROR'}, "Failed to find the addon folder in the zip file.")
                shutil.rmtree(tmp_dir)
                return {'CANCELLED'}

            addon_folder_path = os.path.join(tmp_dir, addon_folder_name)

            # Current addon folder
            addon_dir = os.path.dirname(os.path.abspath(__file__))

            # Copy new files over existing ones
            for item in os.listdir(addon_folder_path):
                s = os.path.join(addon_folder_path, item)
                d = os.path.join(addon_dir, item)
                if os.path.isdir(s):
                    if os.path.exists(d):
                        shutil.rmtree(d)
                    shutil.copytree(s, d)
                else:
                    if os.path.exists(d):
                        os.remove(d)
                    shutil.copy2(s, d)

            shutil.rmtree(tmp_dir)

            prefs.update_available = False
            self.report({'INFO'}, "Addon updated successfully. Please restart Blender.")

        except Exception as e:
            prefs.update_available = False
            self.report({'ERROR'}, f"Failed to update addon: {e}")

        return {'FINISHED'}

# -----------------------------------------------------------------------------------------
#   News Fetching
# -----------------------------------------------------------------------------------------
def fetch_news():
    try:
        import urllib.request
        response = urllib.request.urlopen(NEWS_URL)
        news_text = response.read().decode('utf-8').strip()
        bpy.context.window_manager.news_text = news_text
    except Exception as e:
        bpy.context.window_manager.news_text = "Failed to fetch news."
        print(f"Failed to fetch news: {e}")

def update_news_timer():
    fetch_news()
    # Reschedule every 30 minutes
    return 1800

from bpy.app.handlers import persistent
@persistent
def fetch_news_handler(dummy):
    fetch_news()

# NEW: Refresh blend file list on file load
@persistent
def refresh_blend_file_list_handler(dummy):
    try:
        bpy.ops.wm.append_collection_from_directory()
    except Exception as e:
        print("Failed to refresh blend file list on file load:", e)

# -----------------------------------------------------------------------------------------
#   Auto-Update on Startup (via timer)
# -----------------------------------------------------------------------------------------
def auto_update_on_startup():
    """
    Called once after Blender starts (via bpy.app.timers).
    If auto-update is enabled, check for an update and automatically install if available.
    """
    prefs = bpy.context.preferences.addons[__name__].preferences

    if prefs.auto_update_enabled:
        # Check for update
        bpy.ops.hhp.check_for_update()
        # If found, run update
        if prefs.update_available:
            bpy.ops.hhp.update_to_latest_version()

    # Return None so the timer doesn't re-run
    return None

# -----------------------------------------------------------------------------------------
#   Register / Unregister
# -----------------------------------------------------------------------------------------
def register():
    global custom_icons

    bpy.utils.register_class(DirectoryItem)
    bpy.utils.register_class(CollectionNameItem)
    bpy.utils.register_class(HHPCharLibraryPreferences)
    bpy.utils.register_class(HHP_UL_Directories)
    bpy.utils.register_class(HHP_UL_CollectionNames)
    bpy.utils.register_class(HHP_OT_AddDirectory)
    bpy.utils.register_class(HHP_OT_RemoveDirectory)
    bpy.utils.register_class(HHP_OT_AddCollectionName)
    bpy.utils.register_class(HHP_OT_RemoveCollectionName)
    bpy.utils.register_class(BlendFileItem)
    bpy.utils.register_class(APPEND_UL_BlendFileList)
    bpy.utils.register_class(CHAR_HHP_PT_Panel)
    bpy.utils.register_class(WM_OT_AppendCollectionFromDirectory)
    bpy.utils.register_class(WM_OT_LoadBlendFile)
    bpy.utils.register_class(WM_OT_OpenBlendFile)
    bpy.utils.register_class(WM_OT_AppendStudioFromFile)
    bpy.utils.register_class(WM_OT_AppendActionsFromFile)
    bpy.utils.register_class(HHP_OT_CheckForUpdate)
    bpy.utils.register_class(HHP_OT_UpdateToLatestVersion)

    # Register submodules
    proxies_register()
    Customize_HHP.register()
    Optimize_HHP.register()
    Creator_Tools_HHP.register()
    anim_preview.register()
    shader_sss_converter.register()

    # Collection for blend files
    bpy.types.Scene.blend_file_list = CollectionProperty(type=BlendFileItem)
    bpy.types.Scene.blend_file_list_index = IntProperty(name="Index for blend_file_list", default=-1)

    # Ensure default directory/collections if empty
    prefs = bpy.context.preferences.addons[__name__].preferences
    if len(prefs.directories) == 0:
        new_dir_item = prefs.directories.add()
        new_dir_item.path = ""
    if len(prefs.collection_names) == 0:
        new_col_item = prefs.collection_names.add()
        new_col_item.name = "Char (HHP)"

    # Initialize icon previews
    custom_icons = bpy.utils.previews.new()

    # News text property
    bpy.types.WindowManager.news_text = StringProperty(name="News Text", default="")

    # Start news update timer (fetch news now, then every 30 min)
    bpy.app.timers.register(update_news_timer, first_interval=1)

    # Fetch news after file load
    bpy.app.handlers.load_post.append(fetch_news_handler)
    # NEW: Also refresh the blend file list after file load
    bpy.app.handlers.load_post.append(refresh_blend_file_list_handler)

    # -----------------------------------------------
    #   Schedule a one-time auto-update check
    # -----------------------------------------------
    bpy.app.timers.register(auto_update_on_startup, first_interval=1)

def unregister():
    global custom_icons

    # Remove property group data
    del bpy.types.Scene.blend_file_list
    del bpy.types.Scene.blend_file_list_index

    # Remove custom icons
    if custom_icons is not None:
        bpy.utils.previews.remove(custom_icons)
        custom_icons = None

    # Remove the news text property
    del bpy.types.WindowManager.news_text

    # Remove the handlers
    if fetch_news_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(fetch_news_handler)
    # NEW: Remove refresh blend file list handler
    if refresh_blend_file_list_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(refresh_blend_file_list_handler)

    # Unregister submodules
    proxies_unregister()
    Customize_HHP.unregister()
    Optimize_HHP.unregister()
    Creator_Tools_HHP.unregister()
    anim_preview.unregister()
    shader_sss_converter.unregister()

    # Unregister classes (reverse order)
    bpy.utils.unregister_class(HHP_OT_UpdateToLatestVersion)
    bpy.utils.unregister_class(HHP_OT_CheckForUpdate)
    bpy.utils.unregister_class(WM_OT_AppendActionsFromFile)
    bpy.utils.unregister_class(WM_OT_AppendStudioFromFile)
    bpy.utils.unregister_class(WM_OT_OpenBlendFile)
    bpy.utils.unregister_class(WM_OT_LoadBlendFile)
    bpy.utils.unregister_class(WM_OT_AppendCollectionFromDirectory)
    bpy.utils.unregister_class(CHAR_HHP_PT_Panel)
    bpy.utils.unregister_class(APPEND_UL_BlendFileList)
    bpy.utils.unregister_class(BlendFileItem)
    bpy.utils.unregister_class(HHP_OT_RemoveCollectionName)
    bpy.utils.unregister_class(HHP_OT_AddCollectionName)
    bpy.utils.unregister_class(HHP_OT_RemoveDirectory)
    bpy.utils.unregister_class(HHP_OT_AddDirectory)
    bpy.utils.unregister_class(HHP_UL_CollectionNames)
    bpy.utils.unregister_class(HHP_UL_Directories)
    bpy.utils.unregister_class(HHPCharLibraryPreferences)
    bpy.utils.unregister_class(CollectionNameItem)
    bpy.utils.unregister_class(DirectoryItem)

if __name__ == "__main__":
    register()
