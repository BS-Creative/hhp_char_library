bl_info = {
    "name": "(BS) Custom | HHP Char Library",
    "author": "Bulging Senpai",
    "description": "Bulging senpai's character library",
    "blender": (3, 0, 0),
    "version": (1, 6, 3),
    "location": "",
    "warning": "",
    "doc_url": "https://www.patreon.com/posts/character-addon-113747469",
    "tracker_url": "",
    "category": "3D View"
}

# Update URLs (Change these URLs to point to your own resources)
UPDATE_ZIP_URL = "https://github.com/BS-Creative/hhp_char_library/raw/refs/heads/main/hhp_char_library.zip"
VERSION_URL = "https://raw.githubusercontent.com/BS-Creative/hhp_char_library/refs/heads/main/version.txt"

# Note: Change UPDATE_ZIP_URL and VERSION_URL to point to your own resources.
# Note: Change GET_CHARACTERS_URL to point to your own resource.
GET_CHARACTERS_URL = "https://www.patreon.com/collection/785672?view=condensed"

# News URL (You can change this later)
NEWS_URL = "https://raw.githubusercontent.com/BS-Creative/hhp_char_library/refs/heads/main/news.txt"

from .Proxies_HHP import register as proxies_register
from .Proxies_HHP import unregister as proxies_unregister
from . import Customize_HHP
from . import Optimize_HHP
from . import Clothing_HHP
from . import Creator_Tools_HHP
from . import Anim_Builder
import bpy
import os
import bpy.utils.previews
from bpy.types import Operator, Panel, AddonPreferences, PropertyGroup, UIList
from bpy.props import StringProperty, CollectionProperty, IntProperty, BoolProperty, EnumProperty, FloatProperty

import time
import threading

# Global variable to store custom icons
custom_icons = None

# Preferences for the addon
class DirectoryItem(PropertyGroup):
    path: StringProperty(
        name="Path",
        subtype='DIR_PATH',
        default=""
    )

class CollectionNameItem(PropertyGroup):
    name: StringProperty(
        name="Collection Name",
        default="Char (HHP)"
    )

class HHPCharLibraryPreferences(AddonPreferences):
    bl_idname = __name__

    directories: CollectionProperty(type=DirectoryItem)
    active_directory_index: IntProperty()

    collection_names: CollectionProperty(type=CollectionNameItem)
    active_collection_index: IntProperty()

    auto_update_enabled: BoolProperty(
        name="Auto Update",
        default=True,
        description="Enable automatic updates"
    )

    update_frequency: EnumProperty(
        name="Update Frequency",
        items=[
            ('8H', 'Every 8 Hours', ''),
            ('DAILY', 'Daily', ''),
            ('WEEKLY', 'Weekly', '')
        ],
        default='DAILY',
        description="Frequency to check for updates"
    )

    last_update_check: FloatProperty(
        name="Last Update Check",
        default=0.0,
        description="Timestamp of last update check"
    )

    update_available: BoolProperty(
        name="Update Available",
        default=False,
        description="Is an update available"
    )

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.template_list("HHP_UL_Directories", "", self, "directories", self, "active_directory_index")

        col = row.column(align=True)
        col.operator("hhp.add_directory", icon='ADD', text="")
        col.operator("hhp.remove_directory", icon='REMOVE', text="")

        layout.label(text="Collection Names to Append:")
        row = layout.row()
        row.template_list("HHP_UL_CollectionNames", "", self, "collection_names", self, "active_collection_index")

        col = row.column(align=True)
        col.operator("hhp.add_collection_name", icon='ADD', text="")
        col.operator("hhp.remove_collection_name", icon='REMOVE', text="")

        # New update options
        layout.separator()
        layout.label(text="Update Options:")
        layout.prop(self, "auto_update_enabled")
        layout.prop(self, "update_frequency")

        # Check for update button
        layout.operator("hhp.check_for_update", text="Check for Update")

        # Update to latest version button (will be shown conditionally)
        if self.update_available:
            layout.operator("hhp.update_to_latest_version", text="Update to Latest Version")

class HHP_UL_Directories(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.prop(item, "path", text="Directory", emboss=True)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.prop(item, "path", text="", emboss=False)

class HHP_UL_CollectionNames(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.prop(item, "name", text="Collection Name", emboss=True)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.prop(item, "name", text="", emboss=False)

class HHP_OT_AddDirectory(Operator):
    bl_idname = "hhp.add_directory"
    bl_label = "Add Directory"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        new_item = preferences.directories.add()
        new_item.path = ""
        preferences.active_directory_index = len(preferences.directories) - 1
        return {'FINISHED'}

class HHP_OT_RemoveDirectory(Operator):
    bl_idname = "hhp.remove_directory"
    bl_label = "Remove Directory"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        preferences.directories.remove(preferences.active_directory_index)
        preferences.active_directory_index = min(max(0, preferences.active_directory_index - 1), len(preferences.directories) - 1)
        return {'FINISHED'}

class HHP_OT_AddCollectionName(Operator):
    bl_idname = "hhp.add_collection_name"
    bl_label = "Add Collection Name"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        new_item = preferences.collection_names.add()
        new_item.name = "Char (HHP)"
        preferences.active_collection_index = len(preferences.collection_names) - 1
        return {'FINISHED'}

class HHP_OT_RemoveCollectionName(Operator):
    bl_idname = "hhp.remove_collection_name"
    bl_label = "Remove Collection Name"

    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        preferences.collection_names.remove(preferences.active_collection_index)
        preferences.active_collection_index = min(max(0, preferences.active_collection_index - 1), len(preferences.collection_names) - 1)
        return {'FINISHED'}

# Function to find the most recent blend file in each top-level subfolder of given directories
def get_most_recent_blend_files(directories):
    blend_files = {}
    for directory in directories:
        if os.path.isdir(directory.path):
            for subfolder in os.listdir(directory.path):
                subfolder_path = os.path.join(directory.path, subfolder)
                if os.path.isdir(subfolder_path):
                    recent_file = None
                    recent_time = -1
                    for file in os.listdir(subfolder_path):
                        if file.endswith(".blend"):
                            file_path = os.path.join(subfolder_path, file)
                            try:
                                file_time = os.path.getmtime(file_path)
                                if file_time > recent_time:
                                    recent_time = file_time
                                    recent_file = file_path
                            except Exception as e:
                                print(f"Error accessing file {file_path}: {e}")
                    if recent_file:
                        blend_files[subfolder] = recent_file
    return blend_files

# Function to append collections from a Blender file
def append_collections(filepath, collection_names):
    if not filepath:
        print("File path is empty. Please set the bs_lib variable to your Blender file path.")
        return []

    appended_collections = []
    try:
        with bpy.data.libraries.load(filepath, link=False) as (data_from, data_to):
            collections_to_append = [name.name for name in collection_names if name.name in data_from.collections]
            data_to.collections = collections_to_append

        if data_to.collections:
            for collection in data_to.collections:
                if collection is not None:
                    bpy.context.scene.collection.children.link(collection)
                    appended_collections.append(collection)
                    bpy.ops.object.select_all(action='DESELECT')
                    for obj in collection.objects:
                        obj.select_set(True)
                    bpy.context.view_layer.objects.active = collection.objects[0]
    except Exception as e:
        print(f"Error appending collections from {filepath}: {e}")

    return appended_collections

# Load thumbnails for blend files
def load_thumbnails(blend_files):
    global custom_icons
    thumbnails = {}
    for subfolder, file_path in blend_files.items():
        try:
            # First, check if 'thumbnail.png' exists in the folder of the blend file
            blend_dir = os.path.dirname(file_path)
            thumbnail_png_path = os.path.join(blend_dir, 'thumbnail.png')
            if os.path.isfile(thumbnail_png_path):
                # Load the thumbnail from the 'thumbnail.png' file
                thumb = custom_icons.load(file_path, thumbnail_png_path, 'IMAGE')
            else:
                # Load the thumbnail from the blend file itself
                thumb = custom_icons.load(file_path, file_path, 'BLEND')
            thumbnails[file_path] = thumb
        except Exception as e:
            print(f"Error loading thumbnail for {file_path}: {e}")
    return thumbnails

class BlendFileItem(PropertyGroup):
    name: StringProperty()
    file_path: StringProperty()
    icon_id: IntProperty()

class APPEND_UL_BlendFileList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        blend_file = item
        display_name = blend_file.name.replace('.blend', '')
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.label(text=display_name, icon_value=blend_file.icon_id)
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.label(text="", icon_value=blend_file.icon_id)

class CHAR_HHP_PT_Panel(Panel):
    bl_label = "Char (HHP)"
    bl_idname = "CHAR_HHP_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Char (HHP)'

    def draw(self, context):
        layout = self.layout

        # Access the addon preferences
        prefs = context.preferences.addons[__name__].preferences

        # Add the news label
        layout.label(text="News: " + context.window_manager.news_text, icon='WORLD')

        # Create a box for the buttons
        box = layout.box()

        # Create a row for the buttons inside the box
        row = box.row(align=True)

        # Add the "Update" or "Check for Update" button
        if prefs.update_available:
            row.operator("hhp.update_to_latest_version", text="Update", icon='FILE_REFRESH')
        else:
            row.operator("hhp.check_for_update", text="Check for Update")

        # Add the "Refresh List" button
        row.operator('wm.append_collection_from_directory', text="Refresh List")

        # Add the "Get Characters" button with a character icon
        row.operator("wm.url_open", text="Get Characters", icon='ARMATURE_DATA').url = GET_CHARACTERS_URL

        # Display the list of blend files
        layout.template_list("APPEND_UL_BlendFileList", "", context.scene, "blend_file_list", context.scene, "blend_file_list_index")

        if context.scene.blend_file_list_index >= 0 and context.scene.blend_file_list:
            blend_file = context.scene.blend_file_list[context.scene.blend_file_list_index]
            row = layout.row()
            row.template_icon(blend_file.icon_id, scale=6)

            # Create a box for the top two buttons
            button_box = layout.box()
            buttons_row = button_box.row(align=True)
            # First column: 'Open' button
            open_button = buttons_row.operator('wm.open_blend_file', text="Open", icon='FILE_FOLDER')
            open_button.filepath = blend_file.file_path
            # Second column: 'Append Selected File' button
            append_button = buttons_row.operator('wm.load_blend_file', text="Append Selected File")
            append_button.filepath = blend_file.file_path

            # Outside the box, create a row for the bottom two buttons
            bottom_row = layout.row(align=True)
            # First button: 'Append Studio' with render icon
            append_studio_button = bottom_row.operator('wm.append_studio_from_file', text="Append Studio", icon='RENDER_STILL')
            append_studio_button.filepath = blend_file.file_path
            # Second button: 'Append animation library' with action icon
            append_actions_button = bottom_row.operator('wm.append_actions_from_file', text="Append animation library", icon='ACTION')
            append_actions_button.filepath = blend_file.file_path

class WM_OT_AppendCollectionFromDirectory(Operator):
    bl_idname = 'wm.append_collection_from_directory'
    bl_label = 'Refresh List'
    bl_description = 'Refresh the list of blend files from the directories'
    thumbnails = None

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        recent_blend_files = get_most_recent_blend_files(prefs.directories)

        global custom_icons
        custom_icons.clear()

        self.thumbnails = load_thumbnails(recent_blend_files)

        sorted_blend_files = sorted(recent_blend_files.items(), key=lambda item: item[0])

        context.scene.blend_file_list.clear()
        for subfolder, file_path in sorted_blend_files:
            icon_id = self.thumbnails[file_path].icon_id if file_path in self.thumbnails else 0
            display_name = subfolder
            new_item = context.scene.blend_file_list.add()
            new_item.name = display_name
            new_item.file_path = file_path
            new_item.icon_id = icon_id

        return {'FINISHED'}

class WM_OT_LoadBlendFile(Operator):
    bl_idname = 'wm.load_blend_file'
    bl_label = 'Load Blend File'
    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences

        # Get existing collections before appending
        existing_collections = set(bpy.data.collections)

        # Append the collections
        appended_collections = append_collections(self.filepath, prefs.collection_names)

        # Switch to Object mode
        bpy.ops.object.mode_set(mode='OBJECT')

        # Deselect all objects
        bpy.ops.object.select_all(action='DESELECT')

        # Iterate over the appended collections
        for collection in appended_collections:
            for obj in collection.objects:
                if obj.type == 'ARMATURE':
                    # Select the armature
                    obj.select_set(True)
                    bpy.context.view_layer.objects.active = obj
                    # Set pose position
                    obj.data.pose_position = 'POSE'
                    break  # Assuming only one armature per collection
        return {'FINISHED'}

# New Operator to append "Studio and lights" collection
class WM_OT_AppendStudioFromFile(Operator):
    bl_idname = 'wm.append_studio_from_file'
    bl_label = 'Append Studio'
    bl_description = 'Append the "Studio and lights" collection from the selected file'

    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        collection_name = "Studio and lights"
        try:
            with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
                if collection_name in data_from.collections:
                    data_to.collections = [collection_name]
                else:
                    self.report({'WARNING'}, f'Collection "{collection_name}" not found in {self.filepath}')
                    return {'CANCELLED'}
            for collection in data_to.collections:
                if collection is not None:
                    bpy.context.scene.collection.children.link(collection)
                    # Make the collection visible, enabled in viewport and render
                    collection.hide_viewport = False
                    collection.hide_render = False
            self.report({'INFO'}, f'Appended "{collection_name}" from {self.filepath}')
        except Exception as e:
            self.report({'ERROR'}, f'Error appending "{collection_name}": {e}')
        return {'FINISHED'}

# New Operator to append all actions and set fake user
class WM_OT_AppendActionsFromFile(Operator):
    bl_idname = 'wm.append_actions_from_file'
    bl_label = 'Append Animation Library'
    bl_description = 'Append all actions from the selected file and flag them as fake user'
    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        try:
            with bpy.data.libraries.load(self.filepath, link=False) as (data_from, data_to):
                data_to.actions = data_from.actions[:]
            for action in data_to.actions:
                if action is not None:
                    action.use_fake_user = True
            self.report({'INFO'}, f'Appended {len(data_to.actions)} actions from {self.filepath}')
        except Exception as e:
            self.report({'ERROR'}, f"Error appending actions: {e}")
        return {'FINISHED'}

# New Operator to open the blend file
class WM_OT_OpenBlendFile(Operator):
    bl_idname = 'wm.open_blend_file'
    bl_label = 'Open Blend File'
    filepath: StringProperty(subtype="FILE_PATH")

    def execute(self, context):
        bpy.ops.wm.open_mainfile(filepath=self.filepath)
        return {'FINISHED'}

# Operator to check for updates
class HHP_OT_CheckForUpdate(Operator):
    bl_idname = "hhp.check_for_update"
    bl_label = "Check for Update"
    bl_description = "Check if a new version is available"

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences

        try:
            # Get the current version
            current_version = bl_info['version']

            # Fetch the latest version from the version.txt file
            import urllib.request
            response = urllib.request.urlopen(VERSION_URL)
            latest_version_str = response.read().decode('utf-8').strip()
            latest_version = tuple(map(int, latest_version_str.split('.')))

            if latest_version > current_version:
                self.report({'INFO'}, "Update available!")
                prefs.update_available = True
            else:
                self.report({'INFO'}, "Addon is up to date.")
                prefs.update_available = False

            prefs.last_update_check = time.time()  # Update the last check time

        except Exception as e:
            self.report({'ERROR'}, f"Failed to check for updates: {e}")
            prefs.update_available = False

        return {'FINISHED'}

# Operator to update to the latest version
class HHP_OT_UpdateToLatestVersion(Operator):
    bl_idname = "hhp.update_to_latest_version"
    bl_label = "Update to Latest Version"
    bl_description = "Update the addon to the latest version"

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences

        try:
            import urllib.request
            import tempfile
            import zipfile
            import shutil

            # Download the zip file
            tmp_dir = tempfile.mkdtemp()
            zip_path = os.path.join(tmp_dir, "update.zip")
            urllib.request.urlretrieve(UPDATE_ZIP_URL, zip_path)

            # Extract the zip file
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(tmp_dir)

            # Find the extracted addon folder
            addon_folder_name = None
            for item in os.listdir(tmp_dir):
                if os.path.isdir(os.path.join(tmp_dir, item)):
                    addon_folder_name = item
                    break

            if not addon_folder_name:
                self.report({'ERROR'}, "Failed to find the addon in the zip file.")
                return {'CANCELLED'}

            addon_folder_path = os.path.join(tmp_dir, addon_folder_name)

            # Get the addon directory path
            addon_dir = os.path.dirname(os.path.abspath(__file__))

            # Copy new files over existing ones
            for item in os.listdir(addon_folder_path):
                s = os.path.join(addon_folder_path, item)
                d = os.path.join(addon_dir, item)
                if os.path.isdir(s):
                    # Remove existing directory
                    if os.path.exists(d):
                        shutil.rmtree(d)
                    shutil.copytree(s, d)
                else:
                    # Remove existing file
                    if os.path.exists(d):
                        os.remove(d)
                    shutil.copy2(s, d)

            # Remove temp directory
            shutil.rmtree(tmp_dir)

            # Notify the user
            self.report({'INFO'}, "Addon updated successfully. Please restart Blender to complete the update.")

            prefs.update_available = False

        except Exception as e:
            self.report({'ERROR'}, f"Failed to update addon: {e}")
            prefs.update_available = False

        return {'FINISHED'}

# Function to automatically check for updates for the panel every 8 hours
def check_for_updates_panel():
    prefs = bpy.context.preferences.addons[__name__].preferences

    current_time = time.time()
    time_since_last_check = current_time - prefs.last_update_check

    eight_hours = 8 * 3600  # 8 hours in seconds

    if time_since_last_check >= eight_hours:
        # Perform update check
        try:
            # Get the current version
            current_version = bl_info['version']

            # Fetch the latest version from the version.txt file
            import urllib.request
            response = urllib.request.urlopen(VERSION_URL)
            latest_version_str = response.read().decode('utf-8').strip()
            latest_version = tuple(map(int, latest_version_str.split('.')))

            if latest_version > current_version:
                prefs.update_available = True
            else:
                prefs.update_available = False

            prefs.last_update_check = current_time

        except Exception as e:
            print(f"Failed to check for updates: {e}")
            prefs.update_available = False
            # Don't update last_update_check so it will try again later

    # Reschedule the timer to run again in 8 hours
    return eight_hours

# Existing function to automatically check for updates based on preferences
def check_for_updates_auto():
    prefs = bpy.context.preferences.addons[__name__].preferences

    if not prefs.auto_update_enabled:
        return None  # Don't reschedule the timer

    current_time = time.time()

    # Check if it's time to check for updates
    time_since_last_check = current_time - prefs.last_update_check

    frequency_seconds = {
        '8H': 8 * 3600,
        'DAILY': 24 * 3600,
        'WEEKLY': 7 * 24 * 3600
    }[prefs.update_frequency]

    if time_since_last_check >= frequency_seconds:
        # Perform update check
        try:
            # Get the current version
            current_version = bl_info['version']

            # Fetch the latest version from the version.txt file
            import urllib.request
            response = urllib.request.urlopen(VERSION_URL)
            latest_version_str = response.read().decode('utf-8').strip()
            latest_version = tuple(map(int, latest_version_str.split('.')))

            if latest_version > current_version:
                prefs.update_available = True
                # If auto-update is enabled, perform the update
                bpy.ops.hhp.update_to_latest_version()
            else:
                prefs.update_available = False

            prefs.last_update_check = current_time

        except Exception as e:
            print(f"Failed to check for updates: {e}")
            prefs.update_available = False
            # Don't update last_update_check so it will try again later

    # Reschedule the timer
    return frequency_seconds

# Function to fetch news
def fetch_news():
    try:
        import urllib.request
        response = urllib.request.urlopen(NEWS_URL)
        news_text = response.read().decode('utf-8').strip()
        bpy.context.window_manager.news_text = news_text
    except Exception as e:
        print(f"Failed to fetch news: {e}")
        bpy.context.window_manager.news_text = "Failed to fetch news."

# Timer function to update news every 30 minutes
def update_news_timer():
    fetch_news()
    return 1800  # 30 minutes in seconds

# Handler to fetch news after loading a scene
from bpy.app.handlers import persistent

@persistent
def fetch_news_handler(dummy):
    fetch_news()

def register():
    global custom_icons
    bpy.utils.register_class(DirectoryItem)
    bpy.utils.register_class(CollectionNameItem)
    bpy.utils.register_class(HHPCharLibraryPreferences)
    bpy.utils.register_class(HHP_UL_Directories)
    bpy.utils.register_class(HHP_UL_CollectionNames)
    bpy.utils.register_class(HHP_OT_AddDirectory)
    bpy.utils.register_class(HHP_OT_RemoveDirectory)
    bpy.utils.register_class(HHP_OT_AddCollectionName)
    bpy.utils.register_class(HHP_OT_RemoveCollectionName)
    bpy.utils.register_class(BlendFileItem)
    bpy.utils.register_class(APPEND_UL_BlendFileList)
    bpy.utils.register_class(CHAR_HHP_PT_Panel)
    bpy.utils.register_class(WM_OT_AppendCollectionFromDirectory)
    bpy.utils.register_class(WM_OT_LoadBlendFile)
    bpy.utils.register_class(WM_OT_OpenBlendFile)
    bpy.utils.register_class(WM_OT_AppendStudioFromFile)
    bpy.utils.register_class(WM_OT_AppendActionsFromFile)
    bpy.utils.register_class(HHP_OT_CheckForUpdate)
    bpy.utils.register_class(HHP_OT_UpdateToLatestVersion)
    proxies_register()
    Customize_HHP.register()
    Optimize_HHP.register()
    Clothing_HHP.register()
    Creator_Tools_HHP.register()
    Anim_Builder.register()
    bpy.types.Scene.blend_file_list = CollectionProperty(type=BlendFileItem)
    bpy.types.Scene.blend_file_list_index = IntProperty(name="Index for blend_file_list", default=-1)

    # Add default directory and collection name
    prefs = bpy.context.preferences.addons[__name__].preferences
    if len(prefs.directories) == 0:
        new_dir_item = prefs.directories.add()
        new_dir_item.path = ""
    if len(prefs.collection_names) == 0:
        new_col_item = prefs.collection_names.add()
        new_col_item.name = "Char (HHP)"

    # Start the update check timer for the panel button (every 8 hours)
    bpy.app.timers.register(check_for_updates_panel, first_interval=1)

    # Start the auto-update check timer based on preferences
    bpy.app.timers.register(check_for_updates_auto, first_interval=1)

    # Initialize the custom icons previews collection
    custom_icons = bpy.utils.previews.new()

    # Add news_text property to WindowManager
    bpy.types.WindowManager.news_text = StringProperty(name="News Text", default="")

    # Start the news update timer
    bpy.app.timers.register(update_news_timer, first_interval=1)

    # Add handler to fetch news after loading a scene
    bpy.app.handlers.load_post.append(fetch_news_handler)

def unregister():
    global custom_icons
    bpy.utils.unregister_class(DirectoryItem)
    bpy.utils.unregister_class(CollectionNameItem)
    bpy.utils.unregister_class(HHPCharLibraryPreferences)
    bpy.utils.unregister_class(HHP_UL_Directories)
    bpy.utils.unregister_class(HHP_UL_CollectionNames)
    bpy.utils.unregister_class(HHP_OT_AddDirectory)
    bpy.utils.unregister_class(HHP_OT_RemoveDirectory)
    bpy.utils.unregister_class(HHP_OT_AddCollectionName)
    bpy.utils.unregister_class(HHP_OT_RemoveCollectionName)
    bpy.utils.unregister_class(BlendFileItem)
    bpy.utils.unregister_class(APPEND_UL_BlendFileList)
    bpy.utils.unregister_class(CHAR_HHP_PT_Panel)
    bpy.utils.unregister_class(WM_OT_AppendCollectionFromDirectory)
    bpy.utils.unregister_class(WM_OT_LoadBlendFile)
    bpy.utils.unregister_class(WM_OT_OpenBlendFile)
    bpy.utils.unregister_class(WM_OT_AppendStudioFromFile)
    bpy.utils.unregister_class(WM_OT_AppendActionsFromFile)
    bpy.utils.unregister_class(HHP_OT_CheckForUpdate)
    bpy.utils.unregister_class(HHP_OT_UpdateToLatestVersion)
    proxies_unregister()
    Customize_HHP.unregister()
    Optimize_HHP.unregister()
    Clothing_HHP.unregister()
    Creator_Tools_HHP.unregister()
    Anim_Builder.unregister()
    del bpy.types.Scene.blend_file_list
    del bpy.types.Scene.blend_file_list_index

    # Remove the custom icons previews collection
    if custom_icons is not None:
        bpy.utils.previews.remove(custom_icons)
        custom_icons = None

    # Remove the news_text property from WindowManager
    del bpy.types.WindowManager.news_text

    # Remove the handler
    bpy.app.handlers.load_post.remove(fetch_news_handler)

if __name__ == "__main__":
    register()
