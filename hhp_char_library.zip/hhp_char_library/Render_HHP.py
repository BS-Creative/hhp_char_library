import bpy
from bpy.types import Panel

try:
    from .modules import compositing_toggle
except Exception:
    compositing_toggle = None


class RenderLightingPanel(Panel):
    bl_label = "Render / Lighting (HHP)"
    bl_idname = "CHAR_PT_RenderLighting_HHP"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Char (HHP)"
    bl_parent_id = "CHAR_HHP_PT_Panel"
    bl_options = {'HIDE_HEADER'}
    bl_order = 25

    @classmethod
    def poll(cls, context):
        return context.scene.hhp_panel_mode.selected_panel == 'RENDER'

    def draw(self, context):
        layout = self.layout
        main_col = layout.column(align=True)

        # Light Creation section
        box = main_col.box()
        header = box.row(align=True)
        header.alignment = 'LEFT'
        icon = 'TRIA_DOWN' if context.window_manager.render_light_creation_expanded else 'TRIA_RIGHT'
        header.prop(context.window_manager, "render_light_creation_expanded", text="", icon=icon, emboss=False, icon_only=True)
        header.prop(context.window_manager, "render_light_creation_expanded", text="Light Creation", icon='LIGHT', emboss=False)

        if context.window_manager.render_light_creation_expanded:
            col = box.column(align=True)
            col.operator("hhp.setup_light_system", text="Setup Light System", icon='LIGHT_AREA')
            col.separator()
            col.operator("hhp.create_targeted_light", text="Create Targeted Light", icon='EYEDROPPER')
            col.operator("hhp.create_targeted_reflection_light", text="Create Targeted Light (Reflection)", icon='EYEDROPPER')
            col.operator("hhp.create_reflection_light", text="Create Light (Reflection)", icon='LIGHT_POINT')
            col.operator("hhp.create_sunset_light", text="Create Sunset Light", icon='LIGHT_SUN')

        # Rendering section
        box = main_col.box()
        header = box.row(align=True)
        header.alignment = 'LEFT'
        icon = 'TRIA_DOWN' if context.window_manager.render_rendering_expanded else 'TRIA_RIGHT'
        header.prop(context.window_manager, "render_rendering_expanded", text="", icon=icon, emboss=False, icon_only=True)
        header.prop(context.window_manager, "render_rendering_expanded", text="Rendering", icon='RENDER_STILL', emboss=False)

        if context.window_manager.render_rendering_expanded:
            col = box.column(align=True)
            if compositing_toggle:
                compositing_toggle.draw_ui(col, context)
            else:
                col.label(text="Compositing module not available.", icon='ERROR')


def register():
    wm = bpy.types.WindowManager
    wm.render_light_creation_expanded = bpy.props.BoolProperty(
        name="Light Creation Expanded",
        description="Whether the Light Creation section is expanded",
        default=True
    )
    wm.render_rendering_expanded = bpy.props.BoolProperty(
        name="Rendering Expanded",
        description="Whether the Rendering section is expanded",
        default=True
    )

    if compositing_toggle:
        compositing_toggle.register()

    bpy.utils.register_class(RenderLightingPanel)


def unregister():
    wm = bpy.types.WindowManager
    del wm.render_light_creation_expanded
    del wm.render_rendering_expanded

    if compositing_toggle:
        compositing_toggle.unregister()

    bpy.utils.unregister_class(RenderLightingPanel)


if __name__ == "__main__":
    register()

